package com.websystique.springmvc.service;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.websystique.springmvc.model.User;

@Service("userService")
@Transactional
public class UserServiceImplTransact implements UserService {

    @Autowired
    SessionFactory sessionFactory;

    public List<User> findAllUsers() {
        Session session = sessionFactory.getCurrentSession();
        Criteria cri = session.createCriteria(User.class);
        List<User> users = cri.list();
        return users;
    }

    public User findById(long id) {
        Session session = sessionFactory.getCurrentSession();
        User user = (User) session.get(User.class, id);
        return user;
    }

    public User findByName(String name) {
        Session session = sessionFactory.getCurrentSession();        
        Query query = session.createQuery("from User where username = '" + name + "'");
        List<User> users = query.list();
        if (users != null && !users.isEmpty()) {
            return users.get(0);
        }
        return null;
    }

    public void saveUser(User user) {
        Session session = sessionFactory.getCurrentSession();
        session.save(user);
        /*
         * user.setId(counter.incrementAndGet()); users.add(user);
         */
    }

    public void updateUser(User user) {
        Session session = sessionFactory.getCurrentSession();
        User user1 = (User) session.load(User.class, user.getId());
        session.merge(user);
        // int index = users.indexOf(user);
        // users.set(index, user);
    }

    public boolean deleteUserById(long id) {
        Session session = sessionFactory.getCurrentSession();
        User user = (User) session.get(User.class, id);
        if(user != null) {
            System.out.println("Goin to delete user");
            session.delete(user);
            return true;
        }
        return false;

        /*
         * for (Iterator<User> iterator = users.iterator(); iterator.hasNext();
         * ) { User user = iterator.next(); if (user.getId() == id) {
         * iterator.remove(); } }
         */
    }

    public boolean isUserExist(User user) {
        User userExist = findByName(user.getUsername());
        if (userExist != null) {
            return true;
        }
        return false;
    }

    public void deleteAllUsers() {
        Session session = sessionFactory.getCurrentSession();
        Query query = session.createQuery("delete from User");
        query.executeUpdate();
        // users.clear();
    }
}
