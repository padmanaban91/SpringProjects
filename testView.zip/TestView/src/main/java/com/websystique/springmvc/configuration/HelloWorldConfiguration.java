package com.websystique.springmvc.configuration;

import java.sql.SQLException;
import java.util.Properties;

import javax.sql.DataSource;

import org.h2.tools.Server;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.LocalSessionFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewResolverRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
@EnableTransactionManagement
@EnableWebMvc
@ComponentScan(basePackages = "com.websystique.springmvc")
@PropertySource(value = "classpath:application.properties")
public class HelloWorldConfiguration extends WebMvcConfigurerAdapter{
    
    @Autowired
    Environment environment;
    @Value(value="${value}")
    String value;
  
	
	@Override
	public void configureViewResolvers(ViewResolverRegistry registry) {
		InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
		//viewResolver.setViewClass(JstlView.class);
		viewResolver.setPrefix("/WEB-INF/views/");
		viewResolver.setSuffix(".jsp");
		registry.viewResolver(viewResolver);
	}

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/static/**").addResourceLocations("/static/");
	}
	
	@Bean
	@DependsOn({"h2TcpServer"})
	DriverManagerDataSource getDataSource() {
	    System.out.println("from propertty file: " + value );
	    DriverManagerDataSource dataS = new DriverManagerDataSource();
	    dataS.setDriverClassName("org.h2.Driver");	    
	    dataS.setUrl("jdbc:h2:tcp://localhost/test");
//	    dataS.setUrl("jdbc:h2:mem:test_db;DB_CLOSE_DELAY=1000");
	    //dataS.setUrl("jdbc:h2:file:~/stapler;AUTO_SERVER=true");
	    //dataS.setUrl("jdbc:h2:file:~/stapler;");
	    dataS.setUsername("sa");
	    return dataS;
	}	
	
	@Bean
	LocalSessionFactoryBean getLocalSessionFactoryBean(DataSource dataSource) {
	    LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
	    sessionFactory.setDataSource(dataSource);
	    Properties props = new Properties();
	    props.put("hibernate.dialect", "org.hibernate.dialect.H2Dialect");
	    props.put("hibernate.hbm2ddl.auto", "update");
	    props.put("hibernate.show_sql", "true");
	    sessionFactory.setHibernateProperties(props);
	    sessionFactory.setPackagesToScan(new String[] {"com.websystique.springmvc.model"});
	    return  sessionFactory;
	}
	
	/*
	 *https://stackoverflow.com/questions/17803718/view-content-of-embedded-h2-database-started-by-spring
	 *https://stackoverflow.com/questions/28639396/how-to-start-h2-webserver-using-spring-without-xml
	 *https://stackoverflow.com/questions/7309359/view-content-of-h2-or-hsqldb-in-memory-database
	 *http://bitbybitblog.com/introduction-to-test-driven-development/ 
	 *https://martinfowler.com/articles/mocksArentStubs.html
	 */
	
	/*
	 * <bean id="h2WebServer" class="org.h2.tools.Server" factory-method="createWebServer" init-method="start" destroy-method="stop">
    <constructor-arg value="-web,-webAllowOthers,-webPort,8082"/>
</bean>
	 */
	@Bean(name = "h2Server", initMethod="start", destroyMethod="stop")
	Server startH2Server() {
	    System.out.println("Starting h server");
	    Server server = null;
	    try {
            server = Server.createWebServer("-web","-webAllowOthers","-webPort","8082");
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
	    return server;
	}
	
	@Bean(name = "h2TcpServer", initMethod="start", destroyMethod="stop")
	@DependsOn({"h2Server"})
    Server startH2TCPServer() {
        System.out.println("Starting h w server");
        Server server = null;
        try {
            server = Server.createTcpServer("-tcp", "-tcpAllowOthers", "-tcpPort", "9092");
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return server;
    }
	
	@Bean
	HibernateTransactionManager getTransactionManager(SessionFactory sessionFactory) {
	    return new HibernateTransactionManager(sessionFactory);
	}
	
	/*
	 * https://www.codechef.com/problems/easy
	 * http://codeforces.com/problemset
	 * https://community.topcoder.com/tc?module=ProblemArchive
	 * https://www.hackerrank.com/domains/algorithms/warmup
	 * https://projecteuler.net/
	 * http://www.geeksforgeeks.org/data-structures/
	 * 
	 * http://ressources.unisciel.fr/algoprog/s00aaroot/aa00module1/res/%5BCormen-AL2011%5DIntroduction_To_Algorithms-A3.pdf
	 * https://justincayce.files.wordpress.com/2016/09/the-art-of-thinking-clearly-by-rolf-dobelli.pdf
	 */

}