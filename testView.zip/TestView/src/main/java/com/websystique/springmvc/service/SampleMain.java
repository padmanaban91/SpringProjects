package com.websystique.springmvc.service;

public class SampleMain {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        String ccrID= "312312.2";
        String processId = ccrID.substring(0, ccrID.indexOf("."));
        String version = ccrID.substring(ccrID.indexOf(".") + 1, ccrID.length());
        
        System.out.println(processId + " dasda " + version);

    }

}
