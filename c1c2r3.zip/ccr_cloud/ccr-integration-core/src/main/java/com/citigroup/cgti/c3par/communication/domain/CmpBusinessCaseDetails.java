package com.citigroup.cgti.c3par.communication.domain;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * @author ky38518
 * 
 */
public class CmpBusinessCaseDetails implements Serializable {
    private String additionalComments;
    private String businessJustification;
    private String citiGroupData;
    private String customerData;
    private String technicalDetails;
    private String gocCode;
    private String typeOfEntity;
    private String directAccess;
    private String reasonsDirectConArr;
    private String requestUrgency;

    /**
     * @return the additionalComments
     */
    public String getAdditionalComments() {
        return additionalComments;
    }

    /**
     * @param additionalComments
     *            the additionalComments to set
     */
    public void setAdditionalComments(String additionalComments) {
        this.additionalComments = additionalComments;
    }

    /**
     * @return the businessJustification
     */
    public String getBusinessJustification() {
        return businessJustification;
    }

    /**
     * @param businessJustification
     *            the businessJustification to set
     */
    public void setBusinessJustification(String businessJustification) {
        this.businessJustification = businessJustification;
    }

    /**
     * @return the citiGroupData
     */

    public String getCitiGroupData() {
        return citiGroupData;
    }

    /**
     * @param citiGroupData
     *            the citiGroupData to set
     */
    public void setCitiGroupData(String citiGroupData) {
        this.citiGroupData = citiGroupData;
    }

    /**
     * @return the customerData
     */
    public String getCustomerData() {
        return customerData;
    }

    /**
     * @param customerData
     *            the customerData to set
     */
    public void setCustomerData(String customerData) {
        this.customerData = customerData;
    }

    /**
     * @return the technicalDetails
     */
    public String getTechnicalDetails() {
        return technicalDetails;
    }

    /**
     * @param technicalDetails
     *            the technicalDetails to set
     */
    public void setTechnicalDetails(String technicalDetails) {
        this.technicalDetails = technicalDetails;
    }

    /**
     * @return the gocCode
     */
    public String getGocCode() {
        return gocCode;
    }

    /**
     * @param gocCode
     *            the gocCode to set
     */
    public void setGocCode(String gocCode) {
        this.gocCode = gocCode;
    }

    /**
     * @return the typeOfEntity
     */
    public String getTypeOfEntity() {
        return typeOfEntity;
    }

    /**
     * @param typeOfEntity
     *            the typeOfEntity to set
     */
    public void setTypeOfEntity(String typeOfEntity) {
        this.typeOfEntity = typeOfEntity;
    }

    /**
     * @return the directAccess
     */
    public String getDirectAccess() {
        return directAccess;
    }

    /**
     * @param directAccess
     *            the directAccess to set
     */
    public void setDirectAccess(String directAccess) {
        this.directAccess = directAccess;
    }

    /**
     * @return the reasonsDirectConArr
     */
    public String getReasonsDirectConArr() {
        return reasonsDirectConArr;
    }

    /**
     * @param reasonsDirectConArr
     *            the reasonsDirectConArr to set
     */
    public void setReasonsDirectConArr(String reasonsDirectConArr) {
        this.reasonsDirectConArr = reasonsDirectConArr;
    }

    /**
     * @return the requestUrgency
     */
    public String getRequestUrgency() {
        return requestUrgency;
    }

    /**
     * @param requestUrgency
     *            the requestUrgency to set
     */
    public void setRequestUrgency(String requestUrgency) {
        this.requestUrgency = requestUrgency;
    }

}
