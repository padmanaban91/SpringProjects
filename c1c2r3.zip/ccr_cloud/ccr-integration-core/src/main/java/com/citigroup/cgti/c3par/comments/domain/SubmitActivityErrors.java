package com.citigroup.cgti.c3par.comments.domain;

public class SubmitActivityErrors {
	
public static final String REL_RESOURCE_A="Missing Requester Resource Type for Connection in Relationship";
public static final String REL_RESOURCE_B="Missing Target Resource Type for Connection in Relationship";
public static final String REL_THIRDPARTY_A="Missing Requester Third Party for Connection in Relationship";
public static final String REL_THIRDPARTY_A_CASP="Missing CASP for Third Party in Relationship";
public static final String REL_THIRDPARTY_A_DETAIL="Missing Detail of CASP for Third Party in Relationship";
public static final String REL_THIRDPARTY_B="Missing Target Third Party for Connection in Relationship"	;
public static final String REL_THIRDPARTY_B_CASP="Missing CASP for Target Third Party in Relationship";
public static final String REL_THIRDPARTY_B_DETAIL="Missing Detail of CASP for Target Third Party in Relationship";
public static final String REL_UTURN_THIRDPARTY="Missing Uturn Third Party for Connection in Relationship";
public static final String REL_BUSINESS_UNIT="Missing Business Unit Details for Connection in Relationship";
public static final String REL_REQ_TARGET_THIRD="Data should not be same for both target and requester in third party";
public static final String CASP_STATUS_NOT_UPDATED="The CASP Supplier and Detail status are not updated in third party";

public static final String SUPPLIER_STATUS_INACTIVE="The CASP Supplier ID { #ID# } is Inactive in third party, Please update valid CASP Supplier ID.";
public static final String DETAIL_STATUS_INACTIVE="The CASP Detail ID { #ID# } is Inactive in third party, Please update valid CASP Detail ID.";

public static final String UTURN_CASP_STATUS_NOT_UPDATED="The CASP Supplier/Detail status is not updated in Uturn third party";

public static final String UTURN_SUPPLIER_STATUS_INACTIVE="The CASP Supplier ID { #ID# } is Inactive in Uturn third party, Please update valid CASP Supplier ID.";
public static final String UTURN_DETAIL_STATUS_INACTIVE="The CASP Detail ID { #ID# }  is Inactive in Uturn third party, Please update valid CASP Detail ID.";

public static final String REL_THIRDPARTY_CONTS="Atleast one Third party contacts should be assigned to the relationship";
public static final String REL_THIRDPARTY_LOCS="Atleast one Third party location should be assigned to the relationship";
public static final String REL_THIRDPARTY_LOCS_CONTS="Atleast one Third party contact/location should be assigned to the relationship";

public static final String BJ_RATIONALE  = "Missing Business Justification for Connection in Business Case.";
public static final String BJ_PLCODE  = "Missing GOC Code in Business Case.";
public static final String BJ_BENEFIT  = "Missing Benefit of the Connection in Business Case.";
public static final String BJ_FACILITIES  = "Missing Facilities Affected in Business Case.";

public static final String BJ_EXPORT_LICENSE_CORDINATOR_NEW  = "Missing Export License Coordinator in Business Case.";
public static final String BJ_CONN_FOR_CUST_CLIENT  = "Missing Is this connectivity for a customer or client yes or no in Business Case.";
public static final String BJ_CONN_ESTIMATE  = "Missing Please estimate how frequently this connectivity will be used in Business Case.";
public static final String BJ_DETAILED_INFORMATION  = "Missing How detailed was the information provided in Business Case.";

public static final String BJ_CUSTOMER_DATA  = "Missing Customer Data in Business Case.";
public static final String BJ_CITIGROUP_DATA  = "Missing Citi Group Data in Business Case.";
public static final String BJ_DIRECT_ACCESSBY_THIRDPRT  = "Missing direct B2B or B2B VPN or Remote Services access by a Third Party in Business Case.";
public static final String BJ_VIRTUAL_CONN_REASON  = "Missing The reasons that B2B or B2B VPN is being used in lieu of a virtualized connectivity solution  in Business Case.";

public static final String BJ_CONNECTION  = "Missing Connection Name in Business Case.";
public static final String BJ_CRITICALITY  = "Missing Criticality in Business Case.";
public static final String BJ_PRIORITY  = "Missing Priority in Business Case.";
public static final String BJ_JUSTIFICATION  = "Missing EMER - BUSCRIT justification in Business Case.";

public static final String BJ_BUSCRITMETHODS  = "Missing data for BUSCRIT request in Business Case.";
public static final String BJ_BUSCRITACCESS  = "Missing data for BUSCRIT request in Business Case.";
public static final String BJ_DATE  = "Missing Planned Activation Date in Business Case.";
public static final String BJ_DNTDATE  = "Missing Do Not Implement Before Date in Business Case.";

public static final String BJ_SERVICE  = "Missing Service Category in Business Case.";
public static final String BJ_ANSWER  = "Missing Affected Business in Business Case.";
public static final String BJ_CONTACTS  = "Missing Primary Contacts for Project Coordinator,Technical Coordinator and ISO Role or or Responsibility rejected by Project Coordinator,Technical Coordinator and ISO Role in Target Contacts .";
public static final String BJ_CONTACTS_Requestor  = "Missing Primary Contact for Requestor or Responsibility rejected by requestor in Contacts.";

public static final String BJ_CONTACTS_BusinessOwner  = "Missing Primary Contact for BusinessOwner or Responsibility rejected by BusinessOwner in Contacts.";
public static final String BJ_CONTACTS_BusinessTester  = "Missing Primary Contacts for BusinessTester or Responsibility rejected by BusinessTester in Contacts.";
public static final String BJ_CONTACTS_EMPTYPE  = "Contacts for Technical Coordinator and ISO Role should be an Employee in Target Contacts as primary contact.";
public static final String BJ_CON_ReqEMP  = "Missing Primary Contact for Manager or Responsibility rejected by Manager in Contacts.";

public static final String BJ_CON_ReqEmp_PC  = "Missing Primary Contact for Manager or Responsibility rejected by Manager in Contacts.";
public static final String BJ_CON_ReqEmp_PC_EMP  = "Contacts for Manager should be an Employee in Contacts as primary contact.";
public static final String BJ_REQCONTACTS  = "Missing Primary Contacts for Project Coordinator,Technical Coordinator and ISO Role or Responsibility rejected by Project Coordinator,Technical Coordinator and ISO Role in Requester Contacts.";
public static final String BJ_NOTIFY_CITI_CONTACTS  = "Atleast one contact has to be marked Notify as Yes.";

public static final String BJ_DATASIZE  = "Missing Expected Data Size in Data Information.";
public static final String BJ_DATAFRQ  = "Missing Data Frequency in Data Information.";
public static final String BJ_DOCUMENT  = "Missing EMER - BUSCRIT Director Approval Document for this cycle.";
public static final String BJ_LEGALREVIEW  = "Missing Legal Review Document for U TURN in Documents.";

public static final String BJ_BULKREQ  = "Missing Firewall Document for Bulk Request in Data Information.";
public static final String BJ_CERTIFICATION  = "Relationship Certification is pending for this Connection.";
public static final String BJ_DIRECTOR  = "Missing Primary Contact for Director. Primary Contact must be a Citi Employee.";
public static final String BJ_EMER_ERROR_MSG1  = "Missing answer for name/SOE id of the approving Senior Manager in Emer Buscrit Questions.";

public static final String BJ_EMER_ERROR_MSG2  = "Missing answer for Business Change in Emer Buscrit Questions.";
public static final String BJ_EMER_ERROR_MSG3  = "Missing answer for Impact of Business in Emer Buscrit Questions.";
public static final String BJ_EMER_ERROR_MSG4  = "Missing answer for Process Failed in Emer Buscrit Questions.";
public static final String BJ_EMER_ERROR_MSG5  = "Missing answer for Department Owner in Emer Buscrit Questions.";

public static final String BJ_EMER_ERROR_MSG6  = "Missing answer for Time Frame in Emer Buscrit Questions.";
public static final String BJ_EMER_ERROR_MSG7  = "Missing answer for Additional Bussiness Testing in Emer Buscrit Questions.";
public static final String BJ_RISK_UNPLANNED_CHANGE  = "Missing answer for risk unplanned change in Emer Buscrit Questions.";
public static final String BJ_ADDITIONAL_BUSINESS_TESTING  = "Missing answer for additional business testing in Emer Buscrit Questions.";

public static final String BJ_TESTING_PLAN_CONTACT_PERSON  = "Missing answer for testing plan contact person in Emer Buscrit Questions.";
public static final String BJ_CMPID_SERVICENOWID  = "Provide CMP ID or ServiceNow ID in Business Case.";
public static final String BJ_USER_ENTITLEMET_NOT_EXIST_TARGET  = "UserEntitlement is not exist for one or more target contacts. Select contacts and click NotifiyContacts to create UserEntitlement.";
public static final String BJ_USER_ENTITLEMET_NOT_EXIST_REQUESTER  = "UserEntitlement is not exist for one or more requester contacts. Select contacts and click NotifiyContacts to create UserEntitlement.";

public static final String BJ_ISO_CONTACTS_LIST  = "The user selected for ISO is not found on the ISO Directory. Please ensure the user is an ISO by reviewing the directory http://www.citigroup.net/informationsecurity/locate_biso.htm. Contact *IS GLOBAL CCR if the user is found on the list.";
public static final String BJ_BUSSINESS_OWNER  = "The user selected for Business Owner as Primary is already available for the connection. Please change existing role as secondary in order to proceed.";

public static final String TA_FIREWALLTAB  = "Missing data in Firewall and Circuit Details";
public static final String TA_IPDESTINATION  = "Missing IP data in Add Ips";
public static final String TA_APPLICATION  = "Missing Application Info in IP Details for Firewall";
public static final String TA_APPLICATION_IPREG  = "Missing Application Info in IP Details for IP Registration";

public static final String ACCESS_FORM_PRODUCT_ERR_MSG="Atleast one access form should be generated for this connection";

public static final String TA_JUSTIFICATION  = "Missing Private IP Justification in Add IPs";
public static final String TA_PAIRS  = "Missing Pairs data in IP Pairs";
public static final String TA_PORT  = "Missing Port data in IPPair";
public static final String TA_PROXY_CONNECTION  = "Missing Primary Contact for Proxy Owner in Contacts page";

public static final String TA_PROXY_CONNECTION_EMP  = "Contact for Proxy Owner data should be an Employee in Contacts page";
public static final String TA_PROXY_IP  = "Missing Proxy Owner data in IP Contacts Page";
public static final String TA_CONTACTS_EMPTYPE  = "Contacts for Technical Coordinator and ISO Role should be an Employee in Manage Contacts";
public static final String TA_CONTACTS  = "Missing Primary Contacts for Project Coordinator, Technical Coordinator and ISO Role in Manage Contacts";

public static final String TA_CON_ReqEMP  = "Missing Primary Contacts for Manager in Contacts page";
public static final String TA_CON_ReqEmp_PC  = "Missing Primary Contacts for Manager in Contacts page";
public static final String TA_CON_ReqEmp_PC_EMP  = "Manager should be as Employee in Contacts page";
public static final String TA_REQCONTACTS  = "Missing Primary Contacts for Project Coordinator, Technical Coordinator and ISO Role in Manage Contacts";

public static final String TA_IPROLE  = "Missing Contacts for ISO and Manager Role in Manage Contacts.";
public static final String TA_IPROLE_EMP  = "ISO and Manager Role should be an Employee in Manage Contacts.";
public static final String TA_IPROLE_ReqEMP  = "Project coordinator and Manager are mandatory in Manage Contacts.";
public static final String TA_IPROLE_ReqEmp_PC  = "Missing Project coordinator contact in Manage Contacts.";

public static final String TA_IPROLE_ReqEmp_PC_EMP  = "Project coordinator should be as Employee in Manage Contacts.";
public static final String TA_IPROLE_EMP_DE  = "Technical coordinator should be as Employee in Manage Contacts.";
public static final String TA_FIREWALL  = "Missing Firewall data in IPPair.";
public static final String TA_OSTIAERROR  = "Missing data risk ports in Ostia Questions.";

public static final String TA_OSTIACONFIRMATION  = "Confirmation of Ostia tab for EMER and BUSCRIT.";
public static final String TA_DOCUMENT  = "Missing Firewall Detailed Level Design in Documents";
public static final String TA_SPREADSHEET_DOCUMENT  = "Missing Business Request Spreadsheet in Documents";
public static final String TA_CERTIFYCONFIRMATION  = "Confirmation of Certification for EMER and BUSCRIT";
public static final String TA_APPSENSEPOLICY  = "Missing Application Data in Appsense Policy";
public static final String TA_CART_DOCUMNET  = "Missing CART approval in Documents";

public static final String TA_APPSENSEUSER  = "Missing User Data in Appsense Policy";
public static final String TA_APPSENSEOSTIA  = "Missing Data in Appsense Ostia";
public static final String TA_PROXYFILTER  = "Missing Application Data for Proxy Filter";
public static final String TA_MANAGEPROXYPACFILE  = "Missing Application Data for PAC File in Proxy";
public static final String TA_MANAGEPROXYRFC  = "Proxy Change is incomplete. please click Proxy Change button in Proxy"; 
public static final String TA_MANAGEPROXYSOCKS  = "Missing Application Data for Socks in Proxy";
public static final String TA_MANAGEPROXYPLUG  = "Missing Application Data for Plug in Proxy";
public static final String TA_COMPLETIONCHECK  = "Data has to be entered either for Proxy or Firewall or IP Registration or App Sense  or Sec ACL";
public static final String TA_COMPUTATIONCHECK  = "Please wait for the completion of Access Form/AAF/PAF review";

public static final String TA_DIVISIONCODE  = "Missing Division Code for Firewall and Circuit Details";
public static final String TA_DIRECTOR  = "Missing Primary Contact for Director. Primary Contact must be a Citi Employee";
public static final String TA_DOCUMENT_PROXY  = "Missing Proxy Detailed Level Design in Documents for Socks/Plug";
public static final String TA_DOCUMENT_ACL_CURRENT  = "Missing ACL Current Document";

public static final String TA_DOCUMENT_ACL_CHANGE  = "Missing ACL Changes Document";
public static final String TA_DOCUMENT_DIRAPP  = "Missing EMER - BUSCRIT Director Approval Document for this cycle";
public static final String TA_RFC_COMPLETE  = "Please complete Change for Firewall before submit Technical Architecture";
public static final String TA_RFC_COMPLETE_IPReg  = "Please complete Change for IP Registration before submit Technical Architecture";

public static final String TA_FAF_COMPLETE  = "Please complete Access Form for Firewall before submit Technical Architecture";
public static final String TA_FAF_COMPLETE_IPReg  = "Please complete Access Form for IP Registration before submit Technical Architecture";
public static final String TA_OSTIA_COMPLETE  = "Please complete Ostia in Firewall before submit Technical Architecture";
public static final String TA_OSTIA_COMPLETE_IPReg  = "Please complete Ostia in IP Registration before submit Technical Architecture";

public static final String TA_FW_RULE_MIGRATION_CHECK  = "Please change the Firewall Rules Group Name from  FW_RULE_MIGRATION  to Valid Firewall Group to proceed forward";
public static final String TA_COMPLETIONCHECKFORTEMPLATE  = "Data has to be entered for Template";
public static final String TA_TERMINATECOMPLETIONCHECK  = "Missing Delete Rule in Firewall or IP Registration";
public static final String TA_FW_RULE_GRP_REQ  = "Please change the Firewall Rules Group Name from  TEMPLATE_FIREWALLGROUP to Valid Firewall Group to proceed forward";

public static final String TA_FW_RULE_REC_TYP  = "There should be atleast one Firewall Rule between the Relationship Endpoint A and Endpoint B Resource Types";
public static final String TA_CONTACTS_Requestor  = "Missing Primary Contacts for Requestor in Contacts";
public static final String TA_CONTACTS_BusinessOwner  = "Missing Primary Contacts for BusinessOwner in Contacts";
public static final String TA_CONTACTS_BusinessTester  = "Missing Primary Contacts for BusinessTester in Contacts";

public static final String TA_FW_RULE_COMPLETE  = "Please complete the Firewall Rules. There are IPs or Ports missing in Firewall Rules";
public static final String TA_FW_RULE_COMPLETE_IPReg  = "Please complete the IP Registration Rules. There are IPs or Ports missing in IP Registration Rules";
public static final String TA_CMP_DOCUMENT  = "Upload Missing Business Request Document";
public static final String TA_TERMINATION_EVIDENCE = "Upload Document for Termination";

public static final String ISO_DOCUMENT  = "Missing technical notification documents for both the 3rd parties in Documents.";

public static final String OS_OSTIAERROR  = "Missing data risk ports in Ostia Questions.";
public static final String OS_OSTIA_COMPLETE  = "Please complete Ostia in Firewall before submit Technical Architecture.";
public static final String OS_OSTIA_COMPLETE_IPReg  = "Please complete Ostia in IP Registration before submit Technical Architecture.";
public static final String OS_CERTIFICATION  = "Relationship Certification is pending for this Connection.";

public static final String FWIMPL_FIREFLOW_TICKET_VALIDATED  = "All related fireflow tickets should be validated to proceed forward. Login to Fireflow to validate tickets.";

public static final String LQ_LOGGING_DOCUMENT = "Please upload the Logging Document.";

public static final String RISO_Approval = "Please upload the RISO Approval Mail.";

public static final String SNOW_VALIDATION_WARNING  = "There is an open Change Request(s) @CHANGE_NUMBERS@ associated with this CCR ID. Please insure all changes are completed before setting implementation as complete. You can proceed with Submit.";

}
