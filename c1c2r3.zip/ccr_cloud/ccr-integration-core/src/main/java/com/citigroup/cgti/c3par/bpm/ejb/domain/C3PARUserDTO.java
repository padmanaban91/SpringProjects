package com.citigroup.cgti.c3par.bpm.ejb.domain;

import java.io.Serializable;
import java.util.Date;


/**
 * The Class C3PARUserDTO.
 */
public class C3PARUserDTO implements Serializable{

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -6479260085503393408L;
    /*	NAME					DISPLAY_NAME 				FROM SECURITY_ROLE
     * 	Support Agent          	Support Agent
		Entitlement Requester  	Entitlement Requester
		Security Engineer      	Security Engineer
		ISTG_Chair             	ACL Variance Approver
		Developer              	Developer
		Operational_Analyst    	Operation Analyst
		WWDS                   	WWDS
		Remote_Access_Engineer 	Remote Access Engineer
		Manager                	Business Manager
		Internal_Audit         	Internal Audit
		Regulatory             	Regulatory
		Privacy                	Privacy
		Legal                  	Legal
		TPASWG                 	TPASWG
		Design_Engineer        	Technical Coordinator
		BISO                   	ISO
		Project_Coordinator    	Project Coordinator
		C3PARSYSTEMADMIN       	System Administrator
		ISS                    	ISS
		C3PARUSER              	C3par User
		C3PARSECURITYADMIN     	ISA
		OTRM					OTRM
		MAD						MAD
     */
    /** The Constant ROLE_DE. */
    public static final String ROLE_DE = "Design_Engineer";

    /** The Constant ROLE_PC. */
    public static final String ROLE_PC = "Project_Coordinator";

    /** The Constant ROLE_BISO. */
    public static final String ROLE_BISO = "BISO";

    /** The Constant ROLE_ISA. */
    public static final String ROLE_ISA = "C3PARSECURITYADMIN";

    /** The Constant ROLE_ISTG. */
    public static final String ROLE_ISTG = "ISTG_Chair";

    /** The Constant ROLE_OA. */
    public static final String ROLE_OA = "Operational_Analyst";

    /** The Constant ROLE_SA. */
    public static final String ROLE_SA = "C3PARSYSTEMADMIN";

    /** The Constant ROLE_TPASWG. */
    public static final String ROLE_TPASWG = "TPASWG";

    /** The Constant ROLE_SE. */
    public static final String ROLE_SE = "Security Engineer";

    /** The Constant ROLE_SUPPORT. */
    public static final String ROLE_SUPPORT = "Support Agent";

    /** The Constant ROLE_C3PARUSER. */
    public static final String ROLE_C3PARUSER = "C3PARUSER";

    /** The Constant ROLE_ENTREQUESTER. */
    public static final String ROLE_ENTREQUESTER = "Entitlement Requester";

    /** The Constant ROLE_Manager. */
    public static final String ROLE_Manager = "Manager";

    /** The Constant ROLE_OTRM. */
    public static final String ROLE_OTRM = "OTRM";

    /** The Constant ROLE_MAD. */
    public static final String ROLE_MAD = "MAD";

    /** The Constant ROLE_APSIMPL. */
    public static final String ROLE_APSIMPL = "Appsense_Implementer";

    /** The Constant ROLE_PRXIMPL. */
    public static final String ROLE_PRXIMPL = "Proxy_Implementer";
    // Attributes
    /** The sso id. */
    private	String	ssoId;

    /** The first name. */
    private	String	firstName;

    /** The last name. */
    private	String	lastName;

    /** The display name. */
    private	String	displayName;

    /** The active. */
    private	boolean	active;

    /** The password. */
    private	String	password;

    /** The email. */
    private	String	email;

    /** The telephone. */
    private String  telephone;

    /** The fax. */
    private String  fax;

    /** The requested by. */
    private	String	requestedBy;

    /** The manager approver. */
    private	String	managerApprover;

    /** The sysadmin approver. */
    private	String	sysadminApprover;

    /** The comments. */
    private	String	comments;

    /** The manager reviewed date. */
    private Date 	managerReviewedDate;

    /** The sysadmin reviewed date. */
    private Date 	sysadminReviewedDate;

    /** The roles. */
    private String[]  	roles;

    /** The entitlements. */
    private String[]  	entitlements;

    /** The display roles. */
    private String displayRoles;

    /** The display entitlements. */
    private String displayEntitlements;

    /** The organization unit. */
    private String  organizationUnit;

    private String wfStatus;
    /**
     * Gets the sso id.
     *
     * @return the sso id
     */
    public String getSsoId() {
	return ssoId;
    }

    /**
     * Sets the sso id.
     *
     * @param ssoId the new sso id
     */
    public void setSsoId(String ssoId) {
	this.ssoId = ssoId;
    }

    /**
     * Gets the first name.
     *
     * @return the first name
     */
    public String getFirstName() {
	return firstName;
    }

    /**
     * Sets the first name.
     *
     * @param firstName the new first name
     */
    public void setFirstName(String firstName) {
	this.firstName = firstName;
    }

    /**
     * Gets the last name.
     *
     * @return the last name
     */
    public String getLastName() {
	return lastName;
    }

    /**
     * Sets the last name.
     *
     * @param lastName the new last name
     */
    public void setLastName(String lastName) {
	this.lastName = lastName;
    }

    /**
     * Gets the display name.
     *
     * @return the display name
     */
    public String getDisplayName() {
	return displayName;
    }

    /**
     * Sets the display name.
     *
     * @param displayName the new display name
     */
    public void setDisplayName(String displayName) {
	this.displayName = displayName;
    }

    /**
     * Checks if is active.
     *
     * @return true, if is active
     */
    public boolean isActive() {
	return active;
    }

    /**
     * Sets the active.
     *
     * @param active the new active
     */
    public void setActive(boolean active) {
	this.active = active;
    }

    /**
     * Gets the password.
     *
     * @return the password
     */
    public String getPassword() {
	return password;
    }

    /**
     * Sets the password.
     *
     * @param password the new password
     */
    public void setPassword(String password) {
	this.password = password;
    }

    /**
     * Gets the email.
     *
     * @return the email
     */
    public String getEmail() {
	return email;
    }

    /**
     * Sets the email.
     *
     * @param email the new email
     */
    public void setEmail(String email) {
	this.email = email;
    }

    /**
     * Gets the telephone.
     *
     * @return the telephone
     */
    public String getTelephone() {
	return telephone;
    }

    /**
     * Sets the telephone.
     *
     * @param telephone the new telephone
     */
    public void setTelephone(String telephone) {
	this.telephone = telephone;
    }

    /**
     * Gets the fax.
     *
     * @return the fax
     */
    public String getFax() {
	return fax;
    }

    /**
     * Sets the fax.
     *
     * @param fax the new fax
     */
    public void setFax(String fax) {
	this.fax = fax;
    }

    /**
     * Gets the organization unit.
     *
     * @return the organization unit
     */
    public String getOrganizationUnit() {
	return organizationUnit;
    }

    /**
     * Sets the organization unit.
     *
     * @param organizationUnit the new organization unit
     */
    public void setOrganizationUnit(String organizationUnit) {
	this.organizationUnit = organizationUnit;
    }

    /**
     * Gets the roles.
     *
     * @return the roles
     */
    public String[] getRoles() {
	return roles;
    }

    /**
     * Sets the roles.
     *
     * @param roles the new roles
     */
    public void setRoles(String[] roles) {
	this.roles = roles;
    }

    /**
     * Gets the entitlements.
     *
     * @return the entitlements
     */
    public String[] getEntitlements() {
	return entitlements;
    }

    /**
     * Sets the entitlements.
     *
     * @param entitlements the new entitlements
     */
    public void setEntitlements(String[] entitlements) {
	this.entitlements = entitlements;
    }

    /**
     * Gets the requested by.
     *
     * @return the requested by
     */
    public String getRequestedBy() {
	return requestedBy;
    }

    /**
     * Sets the requested by.
     *
     * @param requestedBy the new requested by
     */
    public void setRequestedBy(String requestedBy) {
	this.requestedBy = requestedBy;
    }

    /**
     * Gets the manager approver.
     *
     * @return the manager approver
     */
    public String getManagerApprover() {
	return managerApprover;
    }

    /**
     * Sets the manager approver.
     *
     * @param managerApprover the new manager approver
     */
    public void setManagerApprover(String managerApprover) {
	this.managerApprover = managerApprover;
    }

    /**
     * Gets the comments.
     *
     * @return the comments
     */
    public String getComments() {
	return comments;
    }

    /**
     * Sets the comments.
     *
     * @param comments the new comments
     */
    public void setComments(String comments) {
	this.comments = comments;
    }

    /**
     * Gets the manager reviewed date.
     *
     * @return the manager reviewed date
     */
    public Date getManagerReviewedDate() {
	return managerReviewedDate;
    }

    /**
     * Sets the manager reviewed date.
     *
     * @param managerReviewedDate the new manager reviewed date
     */
    public void setManagerReviewedDate(Date managerReviewedDate) {
	this.managerReviewedDate = managerReviewedDate;
    }

    /**
     * Gets the display roles.
     *
     * @return the display roles
     */
    public String getDisplayRoles() {
	return displayRoles;
    }

    /**
     * Sets the display roles.
     *
     * @param displayRoles the new display roles
     */
    public void setDisplayRoles(String displayRoles) {
	this.displayRoles = displayRoles;
    }

    /**
     * Gets the display entitlements.
     *
     * @return the display entitlements
     */
    public String getDisplayEntitlements() {
	return displayEntitlements;
    }

    /**
     * Sets the display entitlements.
     *
     * @param displayEntitlements the new display entitlements
     */
    public void setDisplayEntitlements(String displayEntitlements) {
	this.displayEntitlements = displayEntitlements;
    }

    /**
     * Gets the sysadmin approver.
     *
     * @return the sysadmin approver
     */
    public String getSysadminApprover() {
	return sysadminApprover;
    }

    /**
     * Sets the sysadmin approver.
     *
     * @param sysadminApprover the new sysadmin approver
     */
    public void setSysadminApprover(String sysadminApprover) {
	this.sysadminApprover = sysadminApprover;
    }

    /**
     * Gets the sysadmin reviewed date.
     *
     * @return the sysadmin reviewed date
     */
    public Date getSysadminReviewedDate() {
	return sysadminReviewedDate;
    }

    /**
     * Sets the sysadmin reviewed date.
     *
     * @param sysadminReviewedDate the new sysadmin reviewed date
     */
    public void setSysadminReviewedDate(Date sysadminReviewedDate) {
	this.sysadminReviewedDate = sysadminReviewedDate;
    }

	public String getWfStatus() {
		return wfStatus;
	}

	public void setWfStatus(String wfStatus) {
		this.wfStatus = wfStatus;
	}
}
