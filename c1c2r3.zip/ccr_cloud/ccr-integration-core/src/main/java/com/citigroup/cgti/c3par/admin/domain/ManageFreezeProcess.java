package com.citigroup.cgti.c3par.admin.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.citigroup.cgti.c3par.common.domain.FirewallLocation;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;


/**
 * The Class ManageFreezeProcess
 */
public class ManageFreezeProcess {
	
	private DailyLoad dLoad;
	
	private VacationFreeze vacationFreeze;
	
	private FirewallFreeze firewallFreeze;
	
	List<DailyLoad> dlList;
	
	List<VacationFreeze> vFreezeList;
	
	List<FirewallFreeze> fwFreezeList;
	
	List<ProxyFreeze> proxyFreezeList;
	
	private CommonsMultipartFile fileUpload;
    CCRBeanFactory ccrBeanFactory;
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}	
	public List<DailyLoad> getDlList() {
		return dlList;
	}

	public void setDlList(List<DailyLoad> dlList) {
		this.dlList = dlList;
	}

	public List<VacationFreeze> getvFreezeList() {
		return vFreezeList;
	}

	
	public void setvFreezeList(List<VacationFreeze> vFreezeList) {
		this.vFreezeList = vFreezeList;
	}

	public List<FirewallFreeze> getFwFreezeList() {
		return fwFreezeList;
	}

	public void setFwFreezeList(List<FirewallFreeze> fwFreezeList) {
		this.fwFreezeList = fwFreezeList;
	}
	
    public List<ProxyFreeze> getProxyFreezeList() {
        return proxyFreezeList;
    }

    public void setProxyFreezeList(List<ProxyFreeze> proxyFreezeList) {
        this.proxyFreezeList = proxyFreezeList;
    }

    public DailyLoad getdLoad() {
		return dLoad;
	}

	public void setdLoad(DailyLoad dLoad) {
		this.dLoad = dLoad;
	}

	public VacationFreeze getVacationFreeze() {
		return vacationFreeze;
	}

	public void setVacationFreeze(VacationFreeze vacationFreeze) {
		this.vacationFreeze = vacationFreeze;
	}

	public FirewallFreeze getFirewallFreeze() {
		return firewallFreeze;
	}

	public void setFirewallFreeze(FirewallFreeze firewallFreeze) {
		this.firewallFreeze = firewallFreeze;
	}
	
	public CommonsMultipartFile getFileUpload() {
		return fileUpload;
	}

	public void setFileUpload(CommonsMultipartFile fileUpload) {
		this.fileUpload = fileUpload;
	}

	
	 @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	 public void saveDailyLoad(List<DailyLoad> uploadedFile){
		 ccrBeanFactory.getCommonServicePersistable().saveDailyLoad(uploadedFile);
	 }

	 
	 public List<DailyLoad> getDailyLoad(){
		 return ccrBeanFactory.getCommonServicePersistable().getDailyLoad();
	 }
	 
	 
	 public FirewallLocation getFirewallLocByName(String name){
		 return ccrBeanFactory.getCommonServicePersistable().getFirewallLocByName(name);
	 }
	 
	 
	 public GenericLookup getDay(String day){
		 return ccrBeanFactory.getCommonServicePersistable().getDay(day);
	 }
	 
	 
	 @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	 public void saveFirewallFreeze(List<FirewallFreeze> uploadedFile){
		 ccrBeanFactory.getCommonServicePersistable().saveFirewallFreeze(uploadedFile);
	 }
	 
     @Transactional
     public void saveProxyFreeze(List<ProxyFreeze> uploadedFile){
         ccrBeanFactory.getCommonServicePersistable().saveProxyFreeze(uploadedFile);
     }
	 
	 public List<FirewallFreeze> getFwFreeze(){
		 return ccrBeanFactory.getCommonServicePersistable().getFwFreeze();
	 }
	 public List<ProxyFreeze> getProxyFreeze(){
         return ccrBeanFactory.getCommonServicePersistable().getProxyFreeze();
     }

	 @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	 public void saveVacationFreeze(List<VacationFreeze> uploadedFile){
		 ccrBeanFactory.getCommonServicePersistable().saveVacationFreeze(uploadedFile);
	 }

	 
	 public List<VacationFreeze> getVFreeze(){
		 return ccrBeanFactory.getCommonServicePersistable().getVFreeze();
	 }

	
	
}