package com.citigroup.cgti.c3par.connection.domain;

import java.util.Date;

import com.citigroup.cgti.c3par.performer.dao.PerformerDO;
import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;



/**
 * The Class ConnectionFWRuleXref.
 */
public class ConnectionFWRuleXref extends PerformerPagerDO {

    /** The connection fw rule master. */
    private ConnectionFWRuleMaster connectionFWRuleMaster;

    /** The created_date. */
    private Date created_date;

    /** The updated_date. */
    private Date updated_date;

    /** The natted. */
    private String natted;

    /** The zone_id. */
    private Long zone_id;

    /** The connection fw zone master. */
    private ConnectionFWZoneMaster connectionFWZoneMaster;

    /**
     * Instantiates a new connection fw rule xref.
     */
    public ConnectionFWRuleXref() {
	//		 ---------------------
	setTableName(PerformerTypes.CON_FW_RULE_XREF_TABLE);
	setSequenceName(PerformerTypes.CON_FW_RULE_XREF_SEQ);
	// ---------------------
	addToDBMapping("connectionFWRuleMaster", "FIREWALL_RULE_ID",1);
	addToDBMapping("created_date", "created_date",2);
	addToDBMapping("updated_date", "updated_date",3);
	addToDBMapping("natted", "NATTING_FLAG",4);
	addToDBMapping("zone_id", "zone_id",5);
	// ----------------------
	addToNonCompositionList("connectionFWRuleMaster");

	addToNonPersistanceList("connectionFWZoneMaster");
	// ----------------------
	addToParentsMap(
		"com.citigroup.cgti.c3par.connection.domain.ConnectionIPPairXref",
	"IP_PAIR_XREF_ID");


	// ----------------------
    }


    /**
     * Gets the connection fw rule master.
     *
     * @return the connection fw rule master
     */
    public ConnectionFWRuleMaster getConnectionFWRuleMaster() {
	return connectionFWRuleMaster;
    }

    /**
     * Sets the connection fw rule master.
     *
     * @param connectionFWRuleMaster the new connection fw rule master
     */
    public void setConnectionFWRuleMaster(
	    ConnectionFWRuleMaster connectionFWRuleMaster) {
	this.connectionFWRuleMaster = connectionFWRuleMaster;
    }

    /**
     * Gets the created_date.
     *
     * @return Returns the created_date.
     */
    public Date getCreated_date() {
	return created_date;
    }

    /**
     * Sets the created_date.
     *
     * @param created_date The created_date to set.
     */
    public void setCreated_date(Date created_date) {
	this.created_date = created_date;
    }

    /**
     * Gets the updated_date.
     *
     * @return Returns the updated_date.
     */
    public Date getUpdated_date() {
	return updated_date;
    }

    /**
     * Sets the updated_date.
     *
     * @param updated_date The updated_date to set.
     */
    public void setUpdated_date(Date updated_date) {
	this.updated_date = updated_date;
    }


    /**
     * Gets the natted.
     *
     * @return the natted
     */
    public String getNatted() {
	return natted;
    }


    /**
     * Sets the natted.
     *
     * @param natted the new natted
     */
    public void setNatted(String natted) {
	this.natted = natted;
    }


    /**
     * Gets the zone_id.
     *
     * @return the zone_id
     */
    public Long getZone_id() {
	return zone_id;
    }


    /**
     * Sets the zone_id.
     *
     * @param zoneId the new zone_id
     */
    public void setZone_id(Long zoneId) {
	zone_id = zoneId;
    }


    /**
     * Gets the connection fw zone master.
     *
     * @return the connection fw zone master
     */
    public ConnectionFWZoneMaster getConnectionFWZoneMaster() {
	return connectionFWZoneMaster;
    }


    /**
     * Sets the connection fw zone master.
     *
     * @param connectionFWZoneMaster the new connection fw zone master
     */
    public void setConnectionFWZoneMaster(
	    ConnectionFWZoneMaster connectionFWZoneMaster) {
	this.connectionFWZoneMaster = connectionFWZoneMaster;
    }


}
