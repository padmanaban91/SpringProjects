package com.citigroup.cgti.c3par.connection.domain.logic;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.type.LongType;
import org.springframework.beans.factory.annotation.Autowired;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.C3parSessionFactory;
import com.citigroup.cgti.c3par.Exception.BusinessException;
import com.citigroup.cgti.c3par.appsense.domain.ConnectionIPMaster;
import com.citigroup.cgti.c3par.configuation.CCRQueries;
import com.citigroup.cgti.c3par.configuation.QueryConstants;
import com.citigroup.cgti.c3par.connection.domain.ConnectionFWRuleMaster;
import com.citigroup.cgti.c3par.connection.domain.ConnectionFWRuleXref;
import com.citigroup.cgti.c3par.connection.domain.ConnectionIPPairXref;
import com.citigroup.cgti.c3par.connection.domain.ConnectionIPXref;
import com.citigroup.cgti.c3par.connection.domain.ConnectionPortXref;
import com.citigroup.cgti.c3par.connection.domain.ConnectionProcess;
import com.citigroup.cgti.c3par.connection.domain.IPPairRequest;
import com.citigroup.cgti.c3par.dao.PortServiceMappingDAO;
import com.citigroup.cgti.c3par.model.PortServiceMappingEntity;
import com.citigroup.cgti.c3par.performer.dao.PerformerDAO;
import com.citigroup.cgti.c3par.performer.dao.PerformerDO;
import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;
import com.citigroup.cgti.c3par.performer.dao.PerformerQueryBuilder;
import com.citigroup.cgti.c3par.performer.dao.PerformerUtil;
import com.citigroup.cgti.c3par.performer.util.PerformerException;
import com.citigroup.cgti.c3par.performer.util.PerformerFilter;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;

public class TechnicalArchitectureUtil {

    /** The c3par session. */
    private C3parSession c3parSession;

    
    @Autowired
    private SessionFactory sessionFactory;
    
    @Autowired
    private CCRQueries ccrQueries;

    /** The log. */
    private static Logger LOGGER = Logger.getLogger(TechnicalArchitectureUtil.class);

    /**
     * Gets the i ps.
     * 
     * @param fromIP
     *            the from ip
     * @param toIP
     *            the to ip
     * @return the i ps
     * @throws Exception
     *             the exception
     */
    public static List getIPs(String fromIP, String toIP) throws Exception {
        List ips = new ArrayList();
        long fromIPLong = ip2Long(fromIP);
        long toIPLong = ip2Long(toIP);

        if (fromIPLong > toIPLong)
            throw new Exception("From address is greater than To address");

        for (long i = fromIPLong; i <= toIPLong; i++) {
            ips.add(long2IP(i));
        }
        // if(ips.size()>512){
        // throw new Exception("Cannot enter more than 512 IP's");
        // }else{
        return ips;
        // }
    }

    /**
     * Gets the number of i ps.
     * 
     * @param fromIP
     *            the from ip
     * @param toIP
     *            the to ip
     * @return the number of i ps
     * @throws Exception
     *             the exception
     */
    public static String getNumberOfIPs(String fromIP, String toIP) throws Exception {
        String numberOfips = null;
        try {
            long fromIPLong = ip2Long(fromIP);
            long toIPLong = ip2Long(toIP);

            if (fromIPLong > toIPLong)
                throw new Exception("From address is greater than To address");

            numberOfips = (Long.valueOf((toIPLong - fromIPLong) + 1)).toString();
        } catch (Exception e) {
            LOGGER.error(e);
            numberOfips = e.getMessage();
        }
        return numberOfips;
    }

    /**
     * Ip2 long.
     * 
     * @param ip
     *            the ip
     * @return the long
     * @throws Exception
     *             the exception
     */
    public static long ip2Long(String ip) throws Exception {
        StringTokenizer st = new StringTokenizer(ip, ".");
        String[] num = new String[st.countTokens()];
        int counter = 0;
        while (st.hasMoreTokens()) {
            num[counter] = st.nextToken();
            counter++;
        }
        // String[] num = ip.split("\\.");
        if (num.length != 4)
            throw new Exception("Wrong number of octets");

        long r = 0;
        for (int i = 0; i < 4; i++) {
            int t = Integer.parseInt(num[i]);
            if ((t < 0) || (t > 255))
                throw new Exception("Illegal IP");
            r <<= 8;
            r |= t;
        }
        return r;
    }

    /**
     * Long2 ip.
     * 
     * @param ip
     *            the ip
     * @return the string
     */
    public static String long2IP(long ip) {

        StringBuffer b = new StringBuffer(15);

        b.append(Integer.toString((int) ((ip >> 24) & 0xff)));
        b.append('.');
        b.append(Integer.toString((int) ((ip >> 16) & 0xff)));
        b.append('.');
        b.append(Integer.toString((int) ((ip >> 8) & 0xff)));
        b.append('.');
        b.append(Integer.toString((int) (ip & 0xff)));
        return b.toString();
    }

    /**
     * Gets the connection ip master.
     * 
     * @param cIPM
     *            the c ipm
     * @return the connection ip master
     */
    public static ConnectionIPMaster getConnectionIPMaster(ConnectionIPMaster cIPM) {
        ConnectionIPMaster connectionIPMaster = new ConnectionIPMaster();
        // connectionIPMaster.setBroadCastAddress(cIPM.getBroadCastAddress());
        connectionIPMaster.setCreated_date(cIPM.getCreated_date());
        connectionIPMaster.setDeleteFlag(cIPM.getDeleteFlag());
        // connectionIPMaster.setEndIPAddress(cIPM.getEndIPAddress());
        // connectionIPMaster.setFormattedEndIP(cIPM.getFormattedEndIP());
        // connectionIPMaster.setFormattedIP(getFormattedIP(cIPM.getIpAddress()));
        // connectionIPMaster.setFormattedStartIP(cIPM.getFormattedStartIP());
        connectionIPMaster.setHostName(cIPM.getHostName());
        // connectionIPMaster.setIpAddress(cIPM.getIpAddress());
        // connectionIPMaster.setNatIPAddress(cIPM.getIpAddress());
        connectionIPMaster.setNoOfHost(cIPM.getNoOfHost());
        connectionIPMaster.setResourceType(cIPM.getResourceType());
        connectionIPMaster.setResourceTypeOld(cIPM.getResourceTypeOld());
        connectionIPMaster.setShareFlag(cIPM.getShareFlag());
        // connectionIPMaster.setStartIPAddress(cIPM.getStartIPAddress());
        // connectionIPMaster.setSubnet(cIPM.getSubnet());
        connectionIPMaster.setUpdated_date(cIPM.getUpdated_date());
        connectionIPMaster.setUserInputType(cIPM.getUserInputType());
        connectionIPMaster.setNetworkFunctionalArea(cIPM.getNetworkFunctionalArea());
        return connectionIPMaster;
    }

    /**
     * Gets the ids.
     * 
     * @param data
     *            the data
     * @return the ids
     */
    public static List getIds(List data) {
        List returnList = new ArrayList();
        Set returnSet = new HashSet();
        if (data != null && data.size() > 0) {
            Iterator iter = data.iterator();
            while (iter.hasNext()) {
                PerformerDO domainObj = (PerformerDO) iter.next();
                returnSet.add(domainObj.getId());
                // returnList.add(domainObj.getId());
            }
            returnList.addAll(returnSet);
        }
        return returnList;
    }

    /**
     * Gets the formatted ip.
     * 
     * @param ip
     *            the ip
     * @return the formatted ip
     */
    public static String getFormattedIP(String ip) {
        StringTokenizer ipTokenizer = new StringTokenizer(ip.trim(), ".");
        String formattedIP = "";
        while (ipTokenizer.hasMoreTokens()) {
            formattedIP = formattedIP + ".";
            formattedIP = formattedIP + getPaddedNumber((String) ipTokenizer.nextToken());
        }
        return formattedIP.substring(1);
    }

    /**
     * Gets the padded number.
     * 
     * @param nonpaddednumber
     *            the nonpaddednumber
     * @return the padded number
     */
    public static String getPaddedNumber(String nonpaddednumber) {
        String paddedNumber = "";
        if (nonpaddednumber != null && !nonpaddednumber.equals("")) {
            switch (nonpaddednumber.trim().length()) {
                case 1:
                    paddedNumber = "00" + nonpaddednumber.trim();
                    break;
                case 2:
                    paddedNumber = "0" + nonpaddednumber.trim();
                    break;
                case 3:
                    paddedNumber = nonpaddednumber.trim();
                    break;
                default:
                    break;
            }
        }
        return paddedNumber;
    }

    /**
     * Query for pairs.
     * 
     * @param iPPairRequest
     *            the i p pair request
     * @param id
     *            the id
     * @param forDuplicateCheck
     *            the for duplicate check
     * @param endAFilterMap
     *            the end a filter map
     * @param endBFilterMap
     *            the end b filter map
     * @return the string buffer
     */
    public static StringBuffer queryForPairs(IPPairRequest iPPairRequest, Long id, boolean forDuplicateCheck,
            Map endAFilterMap, Map endBFilterMap) {
        List startIPList = iPPairRequest.getStartPointIPMasterList();
        List endIPList = iPPairRequest.getEndPointIPMasterList();
        boolean isStartSelectedAll = iPPairRequest.isStartPointSelectAll();
        boolean isEndSelectedAll = iPPairRequest.isEndPointSelectAll();
        StringBuffer sqlBufferEndPointA = new StringBuffer(
                " select 1 tempId ,a.* from con_ip_master a,con_ip_xref b where ");
        StringBuffer sqlBufferEndPointB = new StringBuffer(
                " select 1 tempId ,a.* from con_ip_master a,con_ip_xref b where ");
        StringBuffer sqlBuffer = null;

        // sqlBufferEndPointA.append(iPPairRequest.getStartResourceType());
        // sqlBufferEndPointB.append(iPPairRequest.getEndResourceType());

        sqlBufferEndPointA.append(" a.id=b.IP_ID and b.CONNECTION_REQUEST_ID= ");
        sqlBufferEndPointB.append(" a.id=b.IP_ID and b.CONNECTION_REQUEST_ID= ");

        sqlBufferEndPointA.append(id);
        sqlBufferEndPointB.append(id);

        /*
         * select a.ip_address || '-' || b.ip_address display from (select 1
         * tempId ,a.* from con_ip_master a,con_ip_xref b where b.RESOURCE_TYPE
         * = "+iPPairRequest.getStartPointIPMasterList()+" and a.id=b.IP_ID and
         * b.CONNECTION_REQUEST_ID="+id+") a, (select 1 tempId ,a.* from
         * con_ip_master a,con_ip_xref b where b.RESOURCE_TYPE =
         * "+iPPairRequest.getStartPointIPMasterList()+" and a.id=b.IP_ID and
         * b.CONNECTION_REQUEST_ID="+id+) b where a.tempId = b.tempId
         */
        if (forDuplicateCheck) {
            sqlBuffer = new StringBuffer("select a.ip_address || '-' || b.ip_address from ");
        } else {
            sqlBuffer = new StringBuffer("select a.ip_address || '-' || b.ip_address,a.ID, b.id  from ");
        }

        List startIPIDList = new ArrayList();
        List endIPIDList = new ArrayList();
        List ipPairNameList = new ArrayList();

        PerformerQueryBuilder pqbEndAFilterQuery = null;
        PerformerQueryBuilder pqbEndBFilterQuery = null;

        if (endAFilterMap != null && endAFilterMap.size() > 0) {
            pqbEndAFilterQuery = PerformerUtil.getPerformerQueryBuilder(new ConnectionIPXref(), endAFilterMap, false);
        }

        if (endBFilterMap != null && endBFilterMap.size() > 0) {
            pqbEndBFilterQuery = PerformerUtil.getPerformerQueryBuilder(new ConnectionIPXref(), endBFilterMap, false);
        }

        if (startIPList != null && startIPList.size() > 0) {
            if (isStartSelectedAll) {
                Iterator startIPListIter = startIPList.iterator();
                while (startIPListIter.hasNext()) {
                    ConnectionIPMaster startConnectionIPMaster = (ConnectionIPMaster) startIPListIter.next();
                    if (!startConnectionIPMaster.isSelected()) {
                        startIPIDList.add(startConnectionIPMaster.getId());
                    }
                }
                if (startIPIDList != null && startIPIDList.size() > 0) {
                    sqlBufferEndPointA.append(" and a.id NOT IN (");
                    sqlBufferEndPointA.append(PerformerUtil.listToString(startIPIDList));
                    sqlBufferEndPointA.append(")");
                }
            } else {
                Iterator startIPListIter = startIPList.iterator();
                while (startIPListIter.hasNext()) {
                    ConnectionIPMaster startConnectionIPMaster = (ConnectionIPMaster) startIPListIter.next();
                    if (startConnectionIPMaster.isSelected()) {
                        startIPIDList.add(startConnectionIPMaster.getId());
                    }
                }
                if (startIPIDList != null && startIPIDList.size() > 0) {
                    sqlBufferEndPointA.append(" and a.id IN (");
                    sqlBufferEndPointA.append(PerformerUtil.listToString(startIPIDList));
                    sqlBufferEndPointA.append(")");
                }
            }

            if (pqbEndAFilterQuery != null) {
                sqlBufferEndPointA.append(" and b.id IN (" + pqbEndAFilterQuery.toString(true) + ") ");
            }
        }

        if (endIPList != null && endIPList.size() > 0) {
            if (isEndSelectedAll) {
                Iterator endIPListIter = endIPList.iterator();
                while (endIPListIter.hasNext()) {
                    ConnectionIPMaster endConnectionIPMaster = (ConnectionIPMaster) endIPListIter.next();
                    if (!endConnectionIPMaster.isSelected()) {
                        endIPIDList.add(endConnectionIPMaster.getId());
                    }
                }
                if (endIPIDList != null && endIPIDList.size() > 0) {
                    sqlBufferEndPointB.append(" and a.id NOT IN (");
                    sqlBufferEndPointB.append(PerformerUtil.listToString(endIPIDList));
                    sqlBufferEndPointB.append(")");
                }
            } else {
                Iterator endIPListIter = endIPList.iterator();
                while (endIPListIter.hasNext()) {
                    ConnectionIPMaster endConnectionIPMaster = (ConnectionIPMaster) endIPListIter.next();
                    if (endConnectionIPMaster.isSelected()) {
                        endIPIDList.add(endConnectionIPMaster.getId());
                    }
                }
                if (endIPIDList != null && endIPIDList.size() > 0) {
                    sqlBufferEndPointB.append(" and a.id IN (");
                    sqlBufferEndPointB.append(PerformerUtil.listToString(endIPIDList));
                    sqlBufferEndPointB.append(")");
                }
            }

            if (pqbEndBFilterQuery != null) {
                sqlBufferEndPointB.append(" and b.id IN (" + pqbEndBFilterQuery.toString(true) + ") ");
            }

        }

        sqlBuffer.append("(");
        sqlBuffer.append(sqlBufferEndPointA);
        sqlBuffer.append(")");
        sqlBuffer.append(" a,");
        sqlBuffer.append("(");
        sqlBuffer.append(sqlBufferEndPointB);
        sqlBuffer.append(")");
        sqlBuffer.append(" b ");
        sqlBuffer.append(" where a.tempId = b.tempId ");
        return sqlBuffer;
    }

    /**
     * Gets the app running.
     * 
     * @param portID
     *            the port id
     * @return the app running
     * @throws Exception
     *             the exception
     */
    public static String getAppRunning(Long portID) throws Exception {
        List searchResults = new ArrayList();
        PortServiceMappingDAO portServiceMappingDAO = new PortServiceMappingDAO(C3parSessionFactory.getC3parSession());
        searchResults = portServiceMappingDAO.findByPortId(portID);
        if (searchResults == null) {
            throw new BusinessException("Service for portID - " + portID + " does not exist");
        }
        Long id = (Long) searchResults.get(0);
        PortServiceMappingEntity portServiceMappingEntity = portServiceMappingDAO.get(id);
        // return portServiceMappingEntity.getServiceType();
        String serviceType = portServiceMappingEntity.getServiceType();
        if (serviceType == null) {
            throw new BusinessException("Service for portID - " + portID + " does not exist");
        } else {
            return serviceType;
        }
    }

    /**
     * Gets the app running.
     * 
     * @param startPortId
     *            the start port id
     * @param endPortId
     *            the end port id
     * @return the app running
     * @throws Exception
     *             the exception
     */
    public static String getAppRunning(Long startPortId, Long endPortId) throws Exception {
        List searchResults = new ArrayList();
        String serviceType = "";
        PortServiceMappingDAO portServiceMappingDAO = new PortServiceMappingDAO(C3parSessionFactory.getC3parSession());

        for (int portId = startPortId.intValue(); portId <= endPortId.intValue(); portId++) {
            searchResults = portServiceMappingDAO.findByPortId(Long.valueOf(portId));
            if (searchResults == null) {

                break;
            } else {
                /*
                 * if(searchResults.size()>0){ break; }
                 */
            }
        }
        if (searchResults == null) {
            throw new BusinessException("Service for port range:" + startPortId + "-" + endPortId + " does not exist");
        }
        return serviceType;
        // Long id = (Long) searchResults.get(0);
        // PortServiceMappingEntity portServiceMappingEntity =
        // portServiceMappingDAO
        // .get(id);
        // return portServiceMappingEntity.getServiceType();
        // String serviceType = portServiceMappingEntity.getServiceType();
        /*
         * if (serviceType == null) { throw new
         * BusinessException("Service for port range:"+ startPortId+
         * "-"+endPortId + " does not exist"); } else { return serviceType; }
         */
    }

    /**
     * Gets the seletected pairs sql.
     * 
     * @param conProcess
     *            the con process
     * @param performerFilterMap
     *            the performer filter map
     * @param isOstia
     *            the is ostia
     * @return the seletected pairs sql
     */
    public static String getSeletectedPairsSQL(ConnectionProcess conProcess, Map performerFilterMap, boolean isOstia) {
        List connProcessIpPairXrefList = conProcess.getConnectionIPPairXrefList();
        Iterator iter = connProcessIpPairXrefList.iterator();
        ConnectionIPPairXref connProcessIpPairXref = null;
        List conditionList = new ArrayList();
        List ipPairXrefIDList = new ArrayList();
        List filterList = null;
        PerformerFilter filter = null;
        List pairs = new ArrayList();
        List connProcessIpPairMasterIds = null;
        PerformerPagerDO pairObj = null;
        StringBuffer sql = null;
        if (conProcess.isSelectAll()) {
            while (iter.hasNext()) {
                connProcessIpPairXref = (ConnectionIPPairXref) iter.next();
                ipPairXrefIDList.add(connProcessIpPairXref.getConnectionIPPairMaster().getId());
                if (!connProcessIpPairXref.isSelected()) {
                    conditionList.add(connProcessIpPairXref.getConnectionIPPairMaster());
                }
            }
            connProcessIpPairMasterIds = TechnicalArchitectureUtil.getIds(conditionList);
            if (isOstia) {
                sql = new StringBuffer(
                        "select CON_IP_PAIR_MASTER.id  FROM CON_IP_PAIR_MASTER, con_ip_pair_xref, con_port_xref, con_riskport_ostia "
                                + "WHERE CON_IP_PAIR_MASTER.id = CON_IP_PAIR_xref.IP_PAIR_ID and con_riskport_ostia.port_id = con_port_xref.port_id AND "
                                + "con_port_xref.ip_pair_xref_id = con_ip_pair_xref.id AND "
                                + "CON_IP_PAIR_xref.CONNECTION_REQUEST_ID = ");
            } else {
                sql = new StringBuffer("select CON_IP_PAIR_MASTER.id from CON_IP_PAIR_MASTER, "
                        + "CON_IP_PAIR_xref where CON_IP_PAIR_MASTER.id = CON_IP_PAIR_xref.IP_PAIR_ID and "
                        + "CON_IP_PAIR_xref.CONNECTION_REQUEST_ID = ");
            }
            sql.append(conProcess.getId());
            if (!isOstia && performerFilterMap != null && performerFilterMap.size() > 0) {
                sql.append("AND CON_IP_PAIR_xref.IP_PAIR_ID IN(");
                sql.append(PerformerUtil.listToString(ipPairXrefIDList));
                sql.append(")");
            }

            if (connProcessIpPairMasterIds != null && connProcessIpPairMasterIds.size() > 0) {
                sql.append(" and CON_IP_PAIR_xref.IP_PAIR_ID not in (");
                sql.append(PerformerUtil.listToString(connProcessIpPairMasterIds));
                sql.append(")");
            }

            if (sql.length() != 0 && performerFilterMap != null && performerFilterMap.size() > 0) {
                ConnectionIPPairXref conIPPairXref = new ConnectionIPPairXref();
                PerformerUtil.intialiseObject(conIPPairXref);
                /*
                 * StringBuffer objectSql =
                 * PerformerUtil.getSQLQueryForObject(conIPPairXref,
                 * performerFilterMap); if (objectSql != null &&
                 * !objectSql.toString().trim().equals("")) {
                 * sql.append(objectSql); }
                 */
                String sibblingSubQuery = PerformerUtil.getSibblingQuery(conIPPairXref, performerFilterMap);
                if (sibblingSubQuery != null && !sibblingSubQuery.trim().equals("")) {
                    sql.append(sibblingSubQuery);
                }
                /*
                 * String childSql = PerformerUtil.getChildQuery(conIPPairXref,
                 * performerFilterMap); if (childSql != null &&
                 * !childSql.trim().equals("")) { sql.append(childSql); }
                 */

            }
            sql.append(" group by CON_IP_PAIR_MASTER.id");
        } else {
            while (iter.hasNext()) {
                connProcessIpPairXref = (ConnectionIPPairXref) iter.next();
                if (connProcessIpPairXref.getConnectionIPPairMaster().isSelected()) {
                    conditionList.add(connProcessIpPairXref.getConnectionIPPairMaster());
                }
            }
            connProcessIpPairMasterIds = TechnicalArchitectureUtil.getIds(conditionList);

            sql = new StringBuffer("select CON_IP_PAIR_MASTER.id from CON_IP_PAIR_MASTER, "
                    + "CON_IP_PAIR_xref where CON_IP_PAIR_MASTER.id = CON_IP_PAIR_xref.IP_PAIR_ID and "
                    + "CON_IP_PAIR_xref.CONNECTION_REQUEST_ID = ");
            sql.append(conProcess.getId());
            if (connProcessIpPairMasterIds != null && connProcessIpPairMasterIds.size() > 0) {
                sql.append(" and CON_IP_PAIR_xref.IP_PAIR_ID in (");
                sql.append(PerformerUtil.listToString(connProcessIpPairMasterIds));
                sql.append(")");
            }

            if (sql.length() != 0 && performerFilterMap != null && performerFilterMap.size() > 0 && !isOstia) {
                ConnectionPortXref conPortXref = new ConnectionPortXref();
                PerformerUtil.intialiseObject(conPortXref);
                String sibblingSubQuery = PerformerUtil.getSibblingQuery(conPortXref, performerFilterMap);
                if (sibblingSubQuery != null && !sibblingSubQuery.trim().equals("")) {
                    sql.append(sibblingSubQuery);
                }
                String childSql = PerformerUtil.getChildQuery(conPortXref, performerFilterMap);
                if (childSql != null && !childSql.trim().equals("")) {
                    sql.append(childSql);
                }

            }
            sql.append(" group by CON_IP_PAIR_MASTER.id");
        }

        return sql.toString();
    }

    /**
     * Gets the common ports query string.
     * 
     * @param conProcess
     *            the con process
     * @param pairFilters
     *            the pair filters
     * @param portFiltersMap
     *            the port filters map
     * @return the common ports query string
     */
    public static String getCommonPortsQueryString(ConnectionProcess conProcess, Map pairFilters, Map portFiltersMap) {
        String queryForPairs = getSeletectedPairsSQL(conProcess, pairFilters, false);
        /*
         * StringBuffer sql = new StringBuffer("FROM CON_PORT_XREF " +
         * "WHERE port_id IN ( " + "SELECT j.id " +
         * "FROM (SELECT   MIN (b.id) id, b.PORT_LOOKUP_ID " +
         * "FROM (SELECT   COUNT (prt2.PORT_LOOKUP_ID) cnt, " +
         * "prt2.PORT_LOOKUP_ID " + "FROM (SELECT DISTINCT a.* " +
         * "FROM con_port_master a, " + "con_port_xref b, " +
         * "con_ip_pair_xref c " +
         * ", (SELECT MIN (id) id FROM c3par.con_ip_pair_master WHERE id IN ("
         * +queryForPairs+"))d WHERE c.ip_pair_id = d.id "
         * 
         * + "WHERE c.ip_pair_id IN (SELECT MIN ( " + "id " + ") " +
         * "FROM con_ip_pair_master " + "WHERE id IN (" + queryForPairs + ")) "
         * + "AND c.id = " + "b.ip_pair_xref_id " + "AND b.port_id = a.id " +
         * "and c.CONNECTION_REQUEST_ID = " + conProcess.getId() + ") prt1, " +
         * "(SELECT DISTINCT a.* " + "FROM con_port_master a, " +
         * "con_port_xref b, " + "con_ip_pair_xref c " + " , ("+queryForPairs+
         * " group by con_ip_pair_master.id ) d WHERE c.ip_pair_id = d.id "
         * 
         * + "WHERE c.ip_pair_id IN (" + queryForPairs + ") " + "AND c.id = " +
         * "b.ip_pair_xref_id " + "AND b.port_id = a.id " +
         * "and c.CONNECTION_REQUEST_ID = " + conProcess.getId() + ") prt2 " +
         * "WHERE prt1.PORT_LOOKUP_ID = prt2.PORT_LOOKUP_ID  " +
         * "GROUP BY prt2.PORT_LOOKUP_ID) prtcnt, " + "con_port_master b " +
         * "WHERE prtcnt.cnt = (SELECT COUNT (id) " + "FROM con_ip_pair_master "
         * + "WHERE id IN (" + queryForPairs + ")) " +
         * "AND b.PORT_LOOKUP_ID = prtcnt.PORT_LOOKUP_ID ");
         * 
         * sql.append("AND b.ip_pair_id IN (" + queryForPairs + ") " +
         * "GROUP BY b.PORT_LOOKUP_ID) j, " + "con_port_master " +
         * "WHERE j.id = con_port_master.id)");
         */
        StringBuffer sql = new StringBuffer("FROM CON_PORT_XREF, (SELECT min(pm.id) minportid, pm.port_lookup_id  "
                + " FROM CON_PORT_XREF pxref, CON_PORT_MASTER pm,con_ip_pair_xref iprx WHERE port_id IN ( select a.ID"
                + " FROM con_port_master a," + " con_port_lookup  b, " + " con_port_xref c "
                + " where a.ip_pair_id in (" + queryForPairs + " )"
                + " and a.port_lookup_id = b.id and c.port_id = a.id )"
                + " AND pxref.port_id=pm.id and iprx.connection_request_id=" + conProcess.getId()
                + " AND pxref.IP_PAIR_XREF_ID=iprx.ID  group by pm.port_lookup_id ) b "
                + " where con_port_xref.port_id=b.minportid");
        if (sql.length() != 0 && portFiltersMap != null && portFiltersMap.size() > 0) {
            ConnectionPortXref conPortXref = new ConnectionPortXref();
            PerformerUtil.intialiseObject(conPortXref);
            StringBuffer objectSql = PerformerUtil.getSQLQueryForObject(conPortXref, portFiltersMap);
            if (objectSql != null && !objectSql.toString().trim().equals("")) {
                sql.append(objectSql);
            }
            String sibblingSubQuery = PerformerUtil.getSibblingQuery(conPortXref, portFiltersMap);
            if (sibblingSubQuery != null && !sibblingSubQuery.trim().equals("")) {
                sql.append(sibblingSubQuery);
            }
            String childSql = PerformerUtil.getChildQuery(conPortXref, portFiltersMap);
            if (childSql != null && !childSql.trim().equals("")) {
                sql.append(childSql);
            }

        }
        // sql .append(" ORDER BY ID DESC");

        LOGGER.info("common port Query------" + sql.toString());
        return sql.toString();
    }

    /**
     * Gets the firewall query string.
     * 
     * @param conProcess
     *            the con process
     * @param pairFilters
     *            the pair filters
     * @param firewallFiltersMap
     *            the firewall filters map
     * @return the firewall query string
     */
    public static String getFirewallQueryString(ConnectionProcess conProcess, Map pairFilters, Map firewallFiltersMap) {
        String queryForPairs = getSeletectedPairsSQL(conProcess, pairFilters, false);

        StringBuffer sql = new StringBuffer(" FROM CON_FIREWALL_RULE_XREF WHERE ID IN("
                + " SELECT DISTINCT A.ID  FROM CON_FIREWALL_RULE_XREF A "
                + " WHERE A.IP_PAIR_XREF_ID IN(SELECT ID FROM CON_IP_PAIR_XREF WHERE IP_PAIR_ID IN(" + queryForPairs
                + ") ) " + " ) ");

        if (sql.length() != 0 && firewallFiltersMap != null && firewallFiltersMap.size() > 0) {
            ConnectionFWRuleXref conFwRuleXref = new ConnectionFWRuleXref();
            PerformerUtil.intialiseObject(conFwRuleXref);
            StringBuffer objectSql = PerformerUtil.getSQLQueryForObject(conFwRuleXref, firewallFiltersMap);
            if (objectSql != null && !objectSql.toString().trim().equals("")) {
                sql.append(objectSql);
            }
            String sibblingSubQuery = PerformerUtil.getSibblingQuery(conFwRuleXref, firewallFiltersMap);
            if (sibblingSubQuery != null && !sibblingSubQuery.trim().equals("")) {
                sql.append(sibblingSubQuery);
            }
            String childSql = PerformerUtil.getChildQuery(conFwRuleXref, firewallFiltersMap);
            if (childSql != null && !childSql.trim().equals("")) {
                sql.append(childSql);
            }

        }
        return sql.toString();
    }

    /**
     * Update master share status.
     * 
     * @param ids
     *            the ids
     * @param xref
     *            the xref
     * @param master
     *            the master
     * @param masterColumnName
     *            the master column name
     * @param dao
     *            the dao
     * @param masterObj
     *            the master obj
     * @throws PerformerException
     *             the performer exception
     */
    public static void updateMasterShareStatus(List ids, String xref, String master, String masterColumnName,
            PerformerDAO dao, Object masterObj) throws PerformerException {

        if (ids == null || ids.size() == 0)
            return;

        List updateSqlList = new ArrayList();
        String updateStatement = null;
        List subIds = new ArrayList();
        for (int idCounter = 0; idCounter < ids.size(); idCounter = idCounter + 1000) {
            if (idCounter == 0) {
                if (ids.size() > 1000) {
                    subIds = ids.subList(0, 1000);
                } else {
                    subIds = ids;
                }
            } else {
                if (ids.size() > idCounter + 1000) {
                    subIds = ids.subList(idCounter, idCounter + 1000);
                } else {
                    subIds = ids.subList(idCounter, ids.size());
                }
            }

            updateStatement = "update " + master + " set share_flag='F' where id in (select id from " + master
                    + " d where id in (select a.id from " + master + " a, " + xref + " b where a.id " + "= b."
                    + masterColumnName + "(+) and b.id is null and a.id in (" + PerformerUtil.listToString(subIds)
                    + ")))";

            // String updateStatement = "update "+master+" set share_flag='F'
            // where id in (select c.id from " +
            // "(select a.id, count(*) cnt from "+master+" a, "+xref+" b where
            // a.id = b."+masterColumnName+" and " +
            // "b.id is not null and a.id in
            // ("+PerformerUtil.listToString(subIds)+") " +
            // "group by a.id) c where c.cnt=1)";

            // deleteSqlList.add(deleteStatement);
            updateSqlList.add(updateStatement);
        }
        // if(deleteSqlList!=null && deleteSqlList.size()>0){
        // Iterator iter = deleteSqlList.iterator();
        // while (iter.hasNext()) {
        // deleteStatement = iter.next().toString();
        // List deleteIds = dao.mapQueryToObject(Long.valueOf(0),
        // deleteStatement);
        // List filterList = new ArrayList();
        // PerformerFilter filter = new PerformerFilter();
        // filter.setAttribute("ID");
        // filter.setFunction(PerformerTypes.IN);
        // filter.setValue(deleteIds);
        // filterList.add(filter);
        // dao.deleteUsingFilter(masterObj, filterList);
        // }
        // }
        dao.executeBatch(updateSqlList);

    }

    /**
     * Delete from master.
     * 
     * @param ids
     *            the ids
     * @param xref
     *            the xref
     * @param master
     *            the master
     * @param masterColumnName
     *            the master column name
     * @param dao
     *            the dao
     * @param masterObj
     *            the master obj
     * @throws PerformerException
     *             the performer exception
     */
    public static void deleteFromMaster(List ids, String xref, String master, String masterColumnName,
            PerformerDAO dao, Object masterObj) throws PerformerException {

        if (ids == null || ids.size() == 0)
            return;

        List deleteSqlList = new ArrayList();
        List updateSqlList = new ArrayList();
        String deleteStatement = null;
        List subIds = new ArrayList();
        for (int idCounter = 0; idCounter < ids.size(); idCounter = idCounter + 1000) {
            if (idCounter == 0) {
                if (ids.size() > 1000) {
                    subIds = ids.subList(0, 1000);
                } else {
                    subIds = ids;
                }
            } else {
                if (ids.size() > idCounter + 1000) {
                    subIds = ids.subList(idCounter, idCounter + 1000);
                } else {
                    subIds = ids.subList(idCounter, ids.size());
                }
            }

            deleteStatement = "select id from " + master + " d where id in (select a.id from " + master + " a, " + xref
                    + " b where a.id " + "= b." + masterColumnName + "(+) and b.id is null and a.id in ("
                    + PerformerUtil.listToString(subIds) + "))";

            String updateStatement = "update " + master + " set share_flag='F' where id in (select c.id from "
                    + "(select a.id, count(*) cnt from " + master + " a, " + xref + " b where a.id = b."
                    + masterColumnName + " and " + "b.id is not null and a.id in ("
                    + PerformerUtil.listToString(subIds) + ") " + "group by a.id) c where c.cnt=1)";

            deleteSqlList.add(deleteStatement);
            updateSqlList.add(updateStatement);
        }
        if (deleteSqlList != null && deleteSqlList.size() > 0) {
            Iterator iter = deleteSqlList.iterator();
            while (iter.hasNext()) {
                deleteStatement = iter.next().toString();
                List deleteIds = dao.mapQueryToObject(Long.valueOf(0), deleteStatement, 0);
                List filterList = new ArrayList();
                PerformerFilter filter = new PerformerFilter();
                filter.setAttribute("ID");
                filter.setFunction(PerformerTypes.IN);
                filter.setValue(deleteIds);
                filterList.add(filter);
                dao.deleteUsingFilter(masterObj, filterList);
            }
        }
        dao.executeBatch(updateSqlList);

    }

    /**
     * Delete fw rule master.
     * 
     * @param ids
     *            the ids
     * @param xref
     *            the xref
     * @param master
     *            the master
     * @param masterColumnName
     *            the master column name
     * @param dao
     *            the dao
     * @param masterObj
     *            the master obj
     * @throws PerformerException
     *             the performer exception
     */
    public static void deleteFWRuleMaster(List ids, String xref, String master, String masterColumnName,
            PerformerDAO dao, Object masterObj) throws PerformerException {

        if (ids == null || ids.size() == 0)
            return;

        List deleteSqlList = new ArrayList();
        // List updateSqlList = new ArrayList();
        String deleteStatement = null;
        List subIds = new ArrayList();
        for (int idCounter = 0; idCounter < ids.size(); idCounter = idCounter + 1000) {
            if (idCounter == 0) {
                if (ids.size() > 1000) {
                    subIds = ids.subList(0, 1000);
                } else {
                    subIds = ids;
                }
            } else {
                if (ids.size() > idCounter + 1000) {
                    subIds = ids.subList(idCounter, idCounter + 1000);
                } else {
                    subIds = ids.subList(idCounter, ids.size());
                }
            }

            deleteStatement = "select id from " + master + " d where id in (select a.id from " + master + " a, " + xref
                    + " b where a.id " + "= b." + masterColumnName + "(+) and b.id is null and a.id in ("
                    + PerformerUtil.listToString(subIds) + "))";

            // String updateStatement = "update "+master+" set share_flag='F'
            // where id in (select c.id from " +
            // "(select a.id, count(*) cnt from "+master+" a, "+xref+" b where
            // a.id = b."+masterColumnName+" and " +
            // "b.id is not null and a.id in
            // ("+PerformerUtil.listToString(subIds)+") " +
            // "group by a.id) c where c.cnt=1)";

            deleteSqlList.add(deleteStatement);
            // updateSqlList.add(updateStatement);
        }
        if (deleteSqlList != null && deleteSqlList.size() > 0) {
            Iterator iter = deleteSqlList.iterator();
            while (iter.hasNext()) {
                deleteStatement = iter.next().toString();
                List deleteIds = dao.mapQueryToObject(Long.valueOf(0), deleteStatement, 0);
                List filterList = new ArrayList();
                PerformerFilter filter = new PerformerFilter();
                filter.setAttribute("ipMstId");
                filter.setFunction(PerformerTypes.IN);
                filter.setValue(deleteIds);
                filterList.add(filter);
                dao.deleteUsingFilter(new ConnectionFWRuleMaster(), filterList);
            }
        }
        // dao.executeBatch(updateSqlList);

    }

    /**
     * Gets the common ports query string on ostia page.
     * 
     * @param conProcess
     *            the con process
     * @param pairFilters
     *            the pair filters
     * @param portFiltersMap
     *            the port filters map
     * @return the common ports query string on ostia page
     */
    public static String getCommonPortsQueryStringOnOstiaPage(ConnectionProcess conProcess, Map pairFilters,
            Map portFiltersMap) {

        String queryForPairs = getSeletectedPairsSQL(conProcess, pairFilters, true);

        /*
         * StringBuffer sql = new StringBuffer("FROM con_port_xref " +
         * "WHERE port_id IN ( " + "SELECT j.id " +
         * "FROM (SELECT   MIN (b.id) id, b.PORT_LOOKUP_ID " +
         * "FROM (SELECT   COUNT (prt2.PORT_LOOKUP_ID) cnt, " +
         * "prt2.PORT_LOOKUP_ID " +
         * "FROM (SELECT a.id, a.port_lookup_id, f.GROUP_ID " +
         * "FROM con_port_master a, " + "con_port_xref b, " +
         * "con_ip_pair_xref c, " + "con_riskport_ostia f " +
         * "WHERE c.ip_pair_id IN (SELECT MIN ( " + "id " + ") " +
         * "FROM con_ip_pair_master " + "WHERE id IN (" + queryForPairs + ")) "
         * + "AND c.id = " + "b.ip_pair_xref_id " + "AND b.port_id = a.id " +
         * "AND a.id = f.port_id " + "AND c.connection_request_id = " +
         * conProcess.getId() +
         * " GROUP BY a.id, a.port_lookup_id, f.GROUP_ID) prt1, " +
         * "(SELECT a.id, a.port_lookup_id, f.GROUP_ID " +
         * "FROM con_port_master a, " + "con_port_xref b, " +
         * "con_ip_pair_xref c, " + "con_riskport_ostia f " +
         * "WHERE c.ip_pair_id IN (" + queryForPairs + ") " + "AND c.id = " +
         * "b.ip_pair_xref_id " + "AND b.port_id = a.id " +
         * "AND a.id = f.port_id " + "AND c.connection_request_id = " +
         * conProcess.getId() +
         * " GROUP BY a.id, a.port_lookup_id, f.GROUP_ID) prt2 " +
         * "WHERE prt1.PORT_LOOKUP_ID = prt2.PORT_LOOKUP_ID  " +
         * "AND NVL (prt1.GROUP_ID, 0) = " + "NVL (prt2.GROUP_ID, 0) " +
         * "GROUP BY prt2.PORT_LOOKUP_ID) prtcnt, " + "con_port_master b " +
         * "WHERE prtcnt.cnt = (SELECT COUNT (id) " + "FROM con_ip_pair_master "
         * + "WHERE id IN (" + queryForPairs + ")) " +
         * "AND b.PORT_LOOKUP_ID = prtcnt.PORT_LOOKUP_ID ");
         * 
         * sql.append("AND b.ip_pair_id IN (" + queryForPairs + ") " +
         * "GROUP BY b.PORT_LOOKUP_ID) j, " + "con_port_master " +
         * "WHERE j.id = con_port_master.id ) ");
         */
        StringBuffer sql = new StringBuffer(
                "FROM CON_PORT_XREF, (SELECT min(pm.id) minportid, pm.port_lookup_id  "
                        + " FROM CON_PORT_MASTER pm, con_port_xref pxref,con_ip_pair_xref IPRX WHERE pm.ID IN ( select c.port_id"
                        + " from CON_PORT_XREF a," + " CON_IP_PAIR_XREF b ," + " con_riskport_ostia c "
                        + " where a.ip_pair_xref_id=b.ID " + " and a.port_id=c.port_id and " + " b.ip_pair_id in ("
                        + queryForPairs + " ) )" + " AND pxref.port_id = pm.ID AND IPRX.connection_request_id ="
                        + conProcess.getId() + " AND pxref.IP_PAIR_XREF_ID=IPRX.ID group by pm.port_lookup_id ) b"
                        + " where con_port_xref.port_id=b.minportid");
        if (sql.length() != 0 && portFiltersMap != null && portFiltersMap.size() > 0) {
            ConnectionPortXref conPortXref = new ConnectionPortXref();
            PerformerUtil.intialiseObject(conPortXref);
            StringBuffer objectSql = PerformerUtil.getSQLQueryForObject(conPortXref, portFiltersMap);
            if (objectSql != null && !objectSql.toString().trim().equals("")) {
                sql.append(objectSql);
            }
            String sibblingSubQuery = PerformerUtil.getSibblingQuery(conPortXref, portFiltersMap);
            if (sibblingSubQuery != null && !sibblingSubQuery.trim().equals("")) {
                sql.append(sibblingSubQuery);
            }
            String childSql = PerformerUtil.getChildQuery(conPortXref, portFiltersMap);
            if (childSql != null && !childSql.trim().equals("")) {
                sql.append(childSql);
            }

        }
        return sql.toString();
    }

    /**
     * Update pair xref status.
     * 
     * @param sqlToSelectPairs
     *            the sql to select pairs
     * @param groupId
     *            the group id
     * @param dao
     *            the dao
     * @param status
     *            the status
     * @throws PerformerException
     *             the performer exception
     */
    public static void updatePairXrefStatus(String sqlToSelectPairs, Long groupId, PerformerDAO dao, String status)
            throws PerformerException {
        String sql;
        if (status.equalsIgnoreCase("complete")) {
            // sql = "update con_ip_pair_xref set con_ip_pair_xref.STATUS =
            // 'COMPLETE' WHERE con_ip_pair_xref.ID IN " +
            // "("+sqlToSelectPairs+" MINUS SELECT con_port_master.ip_pair_id
            // FROM con_riskport_ostia," +
            // "con_port_master, CON_OSTIA_GROUP WHERE con_port_master.id =
            // con_riskport_ostia.port_id AND (con_riskport_ostia.GROUP_ID IS
            // NULL " +
            // "OR con_riskport_ostia.GROUP_ID <> "+groupId+") AND
            // con_riskport_ostia.GROUP_ID = CON_OSTIA_GROUP.ID(+) AND
            // (UPPER(CON_OSTIA_GROUP.STATUS) " +
            // "= 'INCOMPLETE' OR CON_OSTIA_GROUP.STATUS IS NULL) AND
            // con_port_master.ip_pair_id IN ("+sqlToSelectPairs+"))";
            sql = "update con_ip_pair_xref set status='COMPLETE', updated_date = to_date('"
                    + PerformerUtil
                            .getFormatedDate((new Date(System.currentTimeMillis())), PerformerTypes.DATE_FORMAT3)
                    + "','" + PerformerTypes.DATE_FORMAT4 + "') where id in ("
                    + " select ID from con_ip_pair_xref where ip_pair_id in (" + sqlToSelectPairs + ")" + " MINUS"
                    + " SELECT b.id" + " FROM con_port_xref a," + " con_ip_pair_xref b," + " con_riskport_ostia c,"
                    + " con_ostia_group d" + " WHERE a.ip_pair_xref_id = b.id" + " AND b.ip_pair_id IN ("
                    + sqlToSelectPairs + ")" + " AND c.port_id = a.port_id" + " AND (   c.GROUP_ID IS NULL"
                    + " OR c.GROUP_ID <> " + groupId + " )" + " AND c.GROUP_ID = d.id(+)"
                    + " AND (   UPPER (d.status) = 'INCOMPLETE'" + " OR d.status IS NULL))";

        } else {
            sql = "update con_ip_pair_xref set con_ip_pair_xref.STATUS = 'INCOMPLETE', updated_date = to_date('"
                    + PerformerUtil
                            .getFormatedDate((new Date(System.currentTimeMillis())), PerformerTypes.DATE_FORMAT3)
                    + "','" + PerformerTypes.DATE_FORMAT4 + "') WHERE con_ip_pair_xref.IP_PAIR_ID IN " + "("
                    + sqlToSelectPairs + ")";
        }
        dao.executeDMLQuery(sql);
    }

    /**
     * Checks if is firewall rule used in fa f.
     * 
     * @param FirewallRuleId
     *            the firewall rule id
     * @param dao
     *            the dao
     * @return true, if is firewall rule used in fa f
     * @throws PerformerException
     *             the performer exception
     */
    public static boolean isFirewallRuleUsedInFaF(Long FirewallRuleId, PerformerDAO dao) throws PerformerException {

        String sql = "Select id from faf_history where FIREWALL_RULE_ID = " + FirewallRuleId;
        List data = dao.mapQueryToObject(Long.valueOf(0), sql, 0);

        if (data != null && data.size() > 0) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Checks if is firewall rule used in fa f.
     * 
     * @param FirewallRuleIds
     *            the firewall rule ids
     * @param dao
     *            the dao
     * @return true, if is firewall rule used in fa f
     * @throws PerformerException
     *             the performer exception
     */
    public static boolean isFirewallRuleUsedInFaF(List FirewallRuleIds, PerformerDAO dao) throws PerformerException {

        String sql = "Select id from faf_history where FIREWALL_RULE_ID IN ("
                + PerformerUtil.listToString(FirewallRuleIds) + ")";
        List data = dao.mapQueryToObject(Long.valueOf(0), sql, 0);

        if (data != null && data.size() > 0) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Pairs having firewall rules used in faf.
     * 
     * @param ipPairList
     *            the ip pair list
     * @param dao
     *            the dao
     * @return the list
     * @throws PerformerException
     *             the performer exception
     */
    public static List pairsHavingFirewallRulesUsedInFAF(List ipPairList, PerformerDAO dao) throws PerformerException {
        List pairsHavingFirewallRulesInFAF = null;
        if (ipPairList != null && ipPairList.size() > 0) {
            List subIds = null;
            for (int idCounter = 0; idCounter < ipPairList.size(); idCounter = idCounter + 1000) {
                if (idCounter == 0) {
                    if (ipPairList.size() > 1000) {
                        subIds = ipPairList.subList(0, 1000);
                    } else {
                        subIds = ipPairList;
                    }
                } else {
                    if (ipPairList.size() > idCounter + 1000) {
                        subIds = ipPairList.subList(idCounter, idCounter + 1000);
                    } else {
                        subIds = ipPairList.subList(idCounter, ipPairList.size());
                    }
                }

                String sql = "Select c.id from c3par.faf_history a, c3par.con_firewall_rule_master b, c3par.con_ip_pair_master c "
                        + "where a.FIREWALL_RULE_ID = b.id and b.ip_pair_id = c.id and c.ID in ("
                        + PerformerUtil.listToString(subIds) + ") group by c.id";

                List data = dao.mapQueryToObject(Long.valueOf(0), sql, 0);
                if (data != null && data.size() > 0) {
                    if (pairsHavingFirewallRulesInFAF == null)
                        pairsHavingFirewallRulesInFAF = new ArrayList();
                    pairsHavingFirewallRulesInFAF.addAll(data);
                }
            }
        }
        if (pairsHavingFirewallRulesInFAF == null)
            pairsHavingFirewallRulesInFAF = new ArrayList(0);
        Set pairsSet = new HashSet();
        pairsSet.addAll(pairsHavingFirewallRulesInFAF);
        List sortedPairsList = new LinkedList();
        sortedPairsList.addAll(pairsSet);

        return sortedPairsList;
    }

    /**
     * Checks if is vip used in fa f.
     * 
     * @param vIPMasterIds
     *            the v ip master ids
     * @param dao
     *            the dao
     * @return true, if is vip used in fa f
     * @throws PerformerException
     *             the performer exception
     */
    public static boolean isVipUsedInFaF(List vIPMasterIds, PerformerDAO dao) throws PerformerException {
        LOGGER.debug("TechnicalArchitectureUtil.isVipUsedInFaF()" + vIPMasterIds.size());
        String sql = "Select id from con_firewall_rule_master where VIRTUAL_IP_ID IN ("
                + PerformerUtil.listToString(vIPMasterIds) + ")";
        List data = dao.mapQueryToObject(Long.valueOf(0), sql, 0);

        if (data != null && data.size() > 0) {
            return true;
        } else {
            LOGGER.debug("TechnicalArchitectureUtil.isVipUsedInFaF() inside else false");
            return false;
        }
    }

    /**
     * Check pair status.
     * 
     * @param pairs
     *            the pairs
     * @param dao
     *            the dao
     * @return the list
     */
    public static List checkPairStatus(List pairs, PerformerDAO dao) {
        List data = new ArrayList();
        String sql = "select con_ip_pair_master.id from con_ip_pair_master, con_riskport_ostia,con_port_master, "
                + "CON_OSTIA_GROUP where con_port_master.ip_pair_id = con_ip_pair_master.ID and con_port_master.id = "
                + "con_riskport_ostia.port_id and con_riskport_ostia.GROUP_ID = CON_OSTIA_GROUP.ID(+) and (UPPER(CON_OSTIA_GROUP.STATUS) "
                + "=  'INCOMPLETE' or CON_OSTIA_GROUP.STATUS is null) AND con_port_master.ip_pair_id IN ("
                + PerformerUtil.listToString(pairs) + ") " + "order by ID DESC";
        try {
            data = dao.mapQueryToObject(Long.valueOf(0), sql, 0);
        } catch (PerformerException e) {
            LOGGER.error(e.toString(), e);
        }
        return data;
    }

    /**
     * Checks if is vip used in firewall.
     * 
     * @param connectionProcessId
     *            the connection process id
     * @param vIpId
     *            the v ip id
     * @param dao
     *            the dao
     * @return true, if is vip used in firewall
     */
    public static boolean isVipUsedInFirewall(Long connectionProcessId, Long vIpId, PerformerDAO dao) {

        List data = new ArrayList();
        String sql = "select ID from CON_FIREWALL_RULE_xref where IP_PAIR_XREF_ID in (select id from CON_ip_pair_xref where "
                + "CONNECTION_REQUEST_ID = "
                + connectionProcessId
                + ") and FIREWALL_RULE_ID in (select id from CON_FIREWALL_RULE_master "
                + "where VIRTUAL_IP_ID = "
                + vIpId + ")";

        try {
            data = dao.mapQueryToObject(Long.valueOf(0), sql, 0);
        } catch (PerformerException e) {
            LOGGER.error(e.toString(), e);
        }

        if (data == null || data.size() == 0) {
            return false;
        } else {
            return true;
        }

    }

    /**
     * Does pair have risk port.
     * 
     * @param connectionPortXrefList
     *            the connection port xref list
     * @return true, if successful
     */
    public static boolean doesPairHaveRiskPort(List connectionPortXrefList) {
        for (int j = 0; j < connectionPortXrefList.size(); j++) {
            ConnectionPortXref connectionPortXref = (ConnectionPortXref) connectionPortXrefList.get(j);
            if (connectionPortXref.getConnectionPortMst().getRiskPortOstia() != null) {
                return true;
            }
        }
        return false;
    }

    /**
     * Does pair have risk port.
     * 
     * @param connectionIPPairXref
     *            the connection ip pair xref
     * @param dao
     *            the dao
     * @return true, if successful
     */
    public static boolean doesPairHaveRiskPort(ConnectionIPPairXref connectionIPPairXref, PerformerDAO dao) {
        List data = new ArrayList();
        String sql = "select CON_RISKPORT_OSTIA.id from CON_RISKPORT_OSTIA,  con_port_xref, con_ip_pair_xref where "
                + "CON_RISKPORT_OSTIA.PORT_ID = con_port_xref.PORT_ID and con_port_xref.IP_PAIR_XREF_ID  = con_ip_pair_xref.ID "
                + "and con_ip_pair_xref.ID = " + connectionIPPairXref.getId();

        try {
            data = dao.mapQueryToObject(Long.valueOf(0), sql, 0);
        } catch (PerformerException e) {
            LOGGER.error(e.toString(), e);
        }

        if (data == null || data.size() == 0) {
            return false;
        } else {
            return true;
        }

    }

    /**
     * Checks if is private ip.
     * 
     * @param ipAddress
     *            the ip address
     * @param startIPAddress
     *            the start ip address
     * @param endIPAddress
     *            the end ip address
     * @param ipType
     *            the ip type
     * @return true, if is private ip
     */
    public static boolean isPrivateIP(String ipAddress, String startIPAddress, String endIPAddress, String ipType) {
        boolean isPrivateIP = false;
        if (ipType != null) {
            if ("SINGLE".equalsIgnoreCase(ipType) || "ANY_IP".equalsIgnoreCase(ipType)) {
                String[] ipArray = ipAddress.split("[.]");
                if (ipArray != null && ipArray.length == 4) {
                    boolean isFirstSegment192 = false;
                    boolean isFirstSegment172 = false;
                    for (int i = 0; (i < ipArray.length && isPrivateIP == false); i++) {
                        int ipSegment = Integer.parseInt(ipArray[i]);
                        if (i == 0) {
                            if (ipSegment == 10) {
                                isPrivateIP = true;
                            } else if (ipSegment == 172) {
                                isFirstSegment172 = true;
                            } else if (ipSegment == 192) {
                                isFirstSegment192 = true;
                            }
                        } else if (i == 1) {
                            if (isFirstSegment172) {
                                if (ipSegment >= 16 && ipSegment <= 31) {
                                    isPrivateIP = true;
                                }
                            } else if (isFirstSegment192) {
                                if (ipSegment == 168) {
                                    isPrivateIP = true;
                                }
                            }
                        }
                    }
                }
            } else if ("MULTIPLE".equalsIgnoreCase(ipType)) {
                String[] startIpArray = startIPAddress.split("[.]");
                String[] endIpArray = endIPAddress.split("[.]");
                if (startIpArray != null && startIpArray.length == 4) {
                    boolean isFirstSegment192 = false;
                    boolean isFirstSegment172 = false;
                    for (int i = 0; (i < startIpArray.length && isPrivateIP == false); i++) {
                        int startIpSegment = Integer.parseInt(startIpArray[i]);
                        int endIpSegment = Integer.parseInt(endIpArray[i]);
                        if (i == 0) {
                            if (startIpSegment <= 10 && endIpSegment >= 10) {
                                isPrivateIP = true;
                            } else if (startIpSegment <= 172 && endIpSegment >= 172) {
                                isFirstSegment172 = true;
                            } else if (startIpSegment <= 192 && endIpSegment >= 192) {
                                isFirstSegment192 = true;
                            }
                        } else if (i == 1) {
                            if (isFirstSegment172) {
                                if ((startIpSegment >= 16 && startIpSegment <= 31)
                                        || (endIpSegment >= 16 && endIpSegment <= 31)) {
                                    isPrivateIP = true;
                                }
                            } else if (isFirstSegment192) {
                                if (startIpSegment <= 168 && endIpSegment >= 168) {
                                    isPrivateIP = true;
                                }
                            }
                        }
                    }
                }
            } else if ("SUBNET".equalsIgnoreCase(ipType)) {
                String[] ipArray = startIPAddress.split("[.]");
                if (ipArray != null && ipArray.length == 4) {
                    boolean isFirstSegment192 = false;
                    boolean isFirstSegment172 = false;
                    for (int i = 0; (i < ipArray.length && isPrivateIP == false); i++) {
                        int ipSegment = Integer.parseInt(ipArray[i]);
                        if (i == 0) {
                            if (ipSegment == 10) {
                                isPrivateIP = true;
                            } else if (ipSegment == 172) {
                                isFirstSegment172 = true;
                            } else if (ipSegment == 192) {
                                isFirstSegment192 = true;
                            }
                        } else if (i == 1) {
                            if (isFirstSegment172) {
                                if (ipSegment >= 16 && ipSegment <= 31) {
                                    isPrivateIP = true;
                                }
                            } else if (isFirstSegment192) {
                                if (ipSegment == 168) {
                                    isPrivateIP = true;
                                }
                            }
                        }
                    }
                }
            }
        }
        return isPrivateIP;
    }

    /**
     * Clone.
     * 
     * @param obj
     *            the obj
     * @return the object
     */
    public static Object clone(Object obj) {

        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(baos);
            oos.writeObject(obj);
            ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
            ObjectInputStream ois = new ObjectInputStream(bais);
            Object deepCopy = ois.readObject();
            return deepCopy;
        } catch (Exception e) {
            LOGGER.error(e.toString(), e);
            throw new RuntimeException(e);
        }
    }

    /**
     * Gets the iP list for vip.
     * 
     * @param ipPairIDList
     *            the ip pair id list
     * @return the iP list for vip
     */
    public List getIPListForVIP(List ipPairIDList) {

        List ipAddress = new ArrayList();
        C3parSession c3parSession = new C3parSession();
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        StringBuffer sb = new StringBuffer(
                "select distinct  c.IP_ADDRESS,e.id from con_ip_pair_xref a,con_ip_pair_master b,con_ip_master c,con_ip_xref d ,con_virtual_ip_xref e where ");
        try {
            sb.append(" a.IP_PAIR_ID=b.id and (c.id=b.end_point_ip_id or c.id=b.START_POINT_IP_ID )");
            sb.append(" and d.IP_ID=c.id and e.IP_XREF_ID(+)=d.id");
            sb.append(" and a.IP_PAIR_ID in (" + listToString(ipPairIDList, false) + ")");
            con = c3parSession.getConnection();
            stmt = con.prepareStatement(sb.toString());
            rs = stmt.executeQuery();
            while (rs.next()) {

                if (rs.getString(2) == null || "".equals(rs.getString(2))) {
                    ipAddress.add(rs.getString(1));
                }
            }

        } catch (Exception e) {
            LOGGER.error(e.toString(), e);
        } finally {
            try {
                rs.close();
                stmt.close();
                con.close();
            } catch (Exception ex) {
                LOGGER.error(ex);
            }
        }

        return ipAddress;
    }

    /**
     * Copy prx filter data.
     * 
     * @param processId
     *            the process id
     * @param tiRequestId
     *            the ti request id
     * @return the string
     * @throws Exception
     *             the exception
     */
    private String copyPRXFilterData(Long processId, Long tiRequestId) throws Exception {
        C3parSession c3parSession = new C3parSession();
        Connection con = null;
        CallableStatement stmt = null;
        String result = null;
        try {
            con = c3parSession.getConnection();
            stmt = con.prepareCall("{call COPY_PRX_PROXY_FILTER(?,?,?)}");
            stmt.setLong(1, tiRequestId.longValue());
            stmt.setLong(2, processId.longValue());
            stmt.registerOutParameter(3, Types.VARCHAR);
            stmt.execute();
            result = stmt.getString(3);
            if (result != null && result.equalsIgnoreCase("true")) {
                updateProcessId(processId, tiRequestId, PerformerTypes.PRX_PROXY_FILTER_TABLE);
            }
        } catch (Exception ex) {
            LOGGER.error(ex.toString(), ex);
        } finally {
            if (stmt != null)
                stmt.close();
            if (con != null)
                con.close();
        }
        return result;

    }

    /**
     * Copy acl variance data.
     * 
     * @param processId
     *            the process id
     * @param tiRequestId
     *            the ti request id
     * @return the string
     * @throws Exception
     *             the exception
     */
    public String copyACLVarianceData(Long processId, Long tiRequestId) throws Exception {
        C3parSession c3parSession = new C3parSession();
        Connection con = null;
        CallableStatement stmt = null;
        String result = null;
        try {
            con = c3parSession.getConnection();
            stmt = con.prepareCall("{call COPY_ACL_VARIANCE(?,?,?)}");
            stmt.setLong(1, tiRequestId.longValue());
            stmt.setLong(2, processId.longValue());
            stmt.registerOutParameter(3, Types.VARCHAR);
            stmt.execute();
            result = stmt.getString(3);
        } catch (Exception ex) {
            LOGGER.error(ex.toString(), ex);
        } finally {
            c3parSession.closeStatement(stmt);
            c3parSession.releaseConnection();
        }
        return result;

    }

    /**
     * Copy aps policy data.
     * 
     * @param processId
     *            the process id
     * @param tiRequestId
     *            the ti request id
     * @return the string
     * @throws Exception
     *             the exception
     */
    private String copyAPSPolicyData(Long processId, Long tiRequestId) throws Exception {
        C3parSession c3parSession = new C3parSession();
        Connection con = null;
        CallableStatement stmt = null;
        String result = null;
        try {
            con = c3parSession.getConnection();
            stmt = con.prepareCall("{call COPY_APS_APPSENSE_POLICY(?,?,?)}");
            stmt.setLong(1, tiRequestId.longValue());
            stmt.setLong(2, processId.longValue());
            stmt.registerOutParameter(3, Types.VARCHAR);
            stmt.execute();
            result = stmt.getString(3);
            if (result != null && result.equalsIgnoreCase("true")) {
                updateProcessId(processId, tiRequestId, PerformerTypes.APS_APPSENSE_POLICY_TABLE);
            }
        } catch (Exception ex) {
            LOGGER.error(ex.toString(), ex);
        } finally {
            if (stmt != null)
                stmt.close();
            if (con != null)
                con.close();
        }
        return result;

    }

    /**
     * Copy taip xref data.
     * 
     * @param processId
     *            the process id
     * @param tiRequestId
     *            the ti request id
     * @return the string
     * @throws Exception
     *             the exception
     */
    private String copyTAIPXrefData(Long processId, Long tiRequestId) throws Exception {
        C3parSession c3parSession = new C3parSession();
        Connection con = null;
        CallableStatement stmt = null;
        String result = null;
        try {
            con = c3parSession.getConnection();
            stmt = con.prepareCall("{call COPY_TA_IP_XREF(?,?,?)}");
            stmt.setLong(1, tiRequestId.longValue());
            stmt.setLong(2, processId.longValue());
            stmt.registerOutParameter(3, Types.VARCHAR);
            stmt.execute();
            result = stmt.getString(3);
            if (result != null && result.equalsIgnoreCase("true")) {
                updateConnectionReqId(processId, tiRequestId, PerformerTypes.CONN_IP_XREF_TABEL);
            }
        } catch (Exception ex) {
            LOGGER.error(ex.toString(), ex);
        } finally {
            if (stmt != null)
                stmt.close();
            if (con != null)
                con.close();
        }
        return result;

    }

    /**
     * Copy taip pair xref data.
     * 
     * @param processId
     *            the process id
     * @param tiRequestId
     *            the ti request id
     * @return the string
     * @throws Exception
     *             the exception
     */
    private String copyTAIPPairXrefData(Long processId, Long tiRequestId) throws Exception {
        LOGGER.debug("copyTAIPPairXrefData START::");
        C3parSession c3parSession = new C3parSession();
        Connection con = null;
        CallableStatement stmt = null;
        String result = null;
        try {
            con = c3parSession.getConnection();
            stmt = con.prepareCall("{call COPY_TA_IP_PAIR_XREF(?,?,?)}");
            stmt.setLong(1, tiRequestId.longValue());
            stmt.setLong(2, processId.longValue());
            stmt.registerOutParameter(3, Types.VARCHAR);
            stmt.execute();
            result = stmt.getString(3);
            if (result != null && result.equalsIgnoreCase("true")) {
                updateConnectionReqId(processId, tiRequestId, PerformerTypes.CONN_IP_PAIR_XREF_TABEL);

            }
        } catch (Exception ex) {
            LOGGER.error(ex.toString(), ex);
        } finally {
            if (stmt != null)
                stmt.close();
            if (con != null)
                con.close();
        }
        LOGGER.debug("result of copyTAIPPairXrefData :" + result);
        return result;

    }

    /**
     * Copy fw policy data.
     * 
     * @param processId
     *            the process id
     * @param tiRequestId
     *            the ti request id
     * @return the string
     * @throws Exception
     *             the exception
     */
    private String copyFwPolicyData(Long processId, Long tiRequestId) throws Exception {
        C3parSession c3parSession = new C3parSession();
        Connection con = null;
        CallableStatement stmt = null;
        String result = null;
        try {
            con = c3parSession.getConnection();
            stmt = con.prepareCall("{call COPY_FW_POLICY_XREF(?,?,?)}");
            stmt.setLong(1, tiRequestId.longValue());
            stmt.setLong(2, processId.longValue());
            stmt.registerOutParameter(3, Types.VARCHAR);
            stmt.execute();
            result = stmt.getString(3);
            if (result != null && result.equalsIgnoreCase("true")) {
                updateConnectionReqId(processId, tiRequestId, PerformerTypes.CON_FW_POLICY_XREF);
            }
        } catch (Exception ex) {
            LOGGER.error(ex.toString(), ex);
        } finally {
            if (stmt != null)
                stmt.close();
            if (con != null)
                con.close();
        }
        return result;

    }

    /**
     * Copy ta maintenance data.
     * 
     * @param processId
     *            the process id
     * @param tiRequestId
     *            the ti request id
     * @return the string
     * @throws Exception
     *             the exception
     */
    public String copyTAMaintenanceData(Long processId, Long tiRequestId, String requestType) throws Exception {
        LOGGER.debug("copyTAMaintenanceData START::");
        String result = null;

        /*
         * result=copyTAIPXrefData(processId, tiRequestId);
         * log.debug("copy of Add Ips Tab is completed Result is:"+result);
         * 
         * if(result!=null && result.equalsIgnoreCase("true")){
         * result=copyTAIPPairXrefData(processId, tiRequestId);
         * log.debug("copy of IP Pairs Tab is completed Result is:"+result); }
         * //Added for defect 4619 result=copyFwPolicyData(processId,
         * tiRequestId);
         * log.debug("copy of Firewall Policy is completed Result is:"+result);
         */
        result = copyAPSPolicyData(processId, tiRequestId);
        LOGGER.debug("copy of Appsense Policy is completed Result is:" + result);

        result = copyPRXFilterData(processId, tiRequestId);
        LOGGER.debug("copy of PROXY FILTER is completed Result is:" + result);

        result = copyFwRuleData(processId, tiRequestId, requestType, "");
        LOGGER.debug("copy of FW RULE is completed Result is:" + result);

        result = copyOstiaData(processId, tiRequestId, requestType);
        LOGGER.debug("copy of OSTIA is completed Result is:" + result);

        // 10612
        /*
         * result=copyACLVarianceData(processId, tiRequestId);
         * log.debug("copy of ACLVariance is completed Result is:"+result);
         */
        LOGGER.debug("copyTAMaintenanceData END::");
        return result;

    }

    private String copyFwRuleData(Long processId, Long tiRequestId, String requestType, String controlFlag)
            throws Exception {
        C3parSession c3parSession = new C3parSession();
        Connection con = null;
        CallableStatement stmt = null;
        String result = null;
        try {
            con = c3parSession.getConnection();
            stmt = con.prepareCall("{call COPY_FW_RULE(?,?,?,?,?)}");
            stmt.setLong(1, tiRequestId.longValue());
            stmt.setLong(2, processId.longValue());
            stmt.setString(3, requestType);
            stmt.setString(4, controlFlag);
            stmt.registerOutParameter(5, Types.VARCHAR);
            stmt.execute();
            result = stmt.getString(5);
        } catch (Exception ex) {
            LOGGER.error(ex.toString(), ex);
        } finally {

            if (stmt != null)
                stmt.close();
            if (con != null)
                con.close();

        }
        return result;
    }

    private String copyOstiaData(Long processId, Long tiRequestId, String requestType) throws Exception {
        C3parSession c3parSession = new C3parSession();
        Connection con = null;
        CallableStatement stmt = null;
        String result = null;
        try {
            con = c3parSession.getConnection();
            stmt = con.prepareCall("{call COPY_OSTIA(?,?,?)}");
            stmt.setLong(1, tiRequestId.longValue());
            stmt.setLong(2, processId.longValue());
            stmt.registerOutParameter(3, Types.VARCHAR);
            stmt.execute();
            result = stmt.getString(3);
        } catch (Exception ex) {
            LOGGER.error(ex.toString(), ex);
        } finally {

            if (stmt != null)
                stmt.close();
            if (con != null)
                con.close();

        }
        return result;
    }

    public String copyUploadedDocuments(Long processId, Long tiRequestId) throws Exception {
        LOGGER.debug("TechArchUtil::copyUploadedDocuments Starts::");
        C3parSession c3parSession = new C3parSession();
        Connection con = null;
        CallableStatement stmt = null;
        String result = null;
        try {
            con = c3parSession.getConnection();
            stmt = con.prepareCall("{call COPY_UPLOADED_DOCUMENT(?,?,?)}");
            stmt.setLong(1, tiRequestId.longValue());
            stmt.setLong(2, processId.longValue());
            stmt.registerOutParameter(3, Types.VARCHAR);
            stmt.execute();
            result = stmt.getString(3);
            LOGGER.debug("TechArchUtil::copyUploadedDocuments Ends::");
        } catch (Exception ex) {
            LOGGER.error(ex.toString(), ex);
        } finally {

            if (stmt != null)
                stmt.close();
            if (con != null)
                con.close();

        }
        return result;
    }

    /**
     * Abort tech arch data.
     * 
     * @param processId
     *            the process id
     * @param tiRequestId
     *            the ti request id
     * @throws Exception
     *             the exception
     */
    public void abortTechArchData(Long processId, Long tiRequestId) throws Exception {
        LOGGER.debug("abortTechArchData START::");

        updateAbortedProcessIdFWRule(processId, tiRequestId);

        updateAbortedProcessId(processId, tiRequestId, PerformerTypes.APS_APPSENSE_POLICY_TABLE);
        updateAbortedProcessId(processId, tiRequestId, PerformerTypes.PRX_PROXY_FILTER_TABLE);
        updateAbortedProcessId(processId, tiRequestId, PerformerTypes.ACL_VARIANCE_TABLE);

        // The following code is written for rules disappearing after abort
        // issue.
        // If this id has been aborted in the current cycle, then find the last
        // non-aborted non-acv cycle
        // pull that id's rules from history table and save them con_fw_rule and
        // associated tables.

        // putting this within try catch block so that it doesn't break while
        // testing.Monitor these logs while aborting.
        try {
            Long lastValidTiRequest = getLastActiveNonACVTIRequestId(processId);
            if(null== lastValidTiRequest){
                //something has gone wrong. Print a log and send the ti request id forward. Nothing else can be done. 
                LOGGER.error("Exception while fetching the last stable ti request id , check if PREVIOUS_NON_DELETED_TI_REQUEST_QUERY_VER2 is in CCR Queries table ,  passing the default id =" + tiRequestId );
                lastValidTiRequest = tiRequestId;
            }
            copyFWRulesFromHistoryForAbortScenario(processId, lastValidTiRequest);
        } catch (Exception ex) {
            LOGGER.error("Exception thrown while copying last non-acv non-aborted ti request id", ex);
            LOGGER.error(ex.toString(), ex);
        }

        LOGGER.debug("abortTechArchData END::");

    }

    /**
     * Update process id.
     * 
     * @param processId
     *            the process id
     * @param tiRequestId
     *            the ti request id
     * @param tableName
     *            the table name
     * @throws Exception
     *             the exception
     */
    private void updateProcessId(Long processId, Long tiRequestId, String tableName) throws Exception {
        LOGGER.debug("updateProcessId START::");
        C3parSession c3parSession = new C3parSession();
        PreparedStatement pstmt = null;
        Connection con = null;
        int rows = 0;
        try {
            con = c3parSession.getConnection();
            String sql = "UPDATE "
                    + tableName
                    + " a SET a.PROCESS_ID = NULL"
                    + " WHERE a.ti_request_id IN ( SELECT MAX (ID) FROM c3par.ti_request a WHERE a.process_id = ?"
                    + "  AND (a.is_deleted = 'N' OR a.is_deleted IS NULL) AND ti_request_type_id IN ( SELECT ID FROM ti_request_type"
                    + " WHERE request_type IN ('Create', 'Maintain')) AND ID NOT IN (?))";
            pstmt = con.prepareStatement(sql);
            pstmt.setLong(1, processId.longValue());
            pstmt.setLong(2, tiRequestId.longValue());
            rows = pstmt.executeUpdate();
            LOGGER.debug(rows + ": Rows of " + tableName + ".PROCESS_ID is set to NULL");
        } catch (Exception e) {
            LOGGER.error(e.toString(), e);
        } finally {
            if (pstmt != null)
                pstmt.close();
            if (con != null)
                con.close();
        }
        LOGGER.debug("updateProcessId END::");
    }

    /**
     * Update connection req id.
     * 
     * @param processId
     *            the process id
     * @param tiRequestId
     *            the ti request id
     * @param tableName
     *            the table name
     * @throws Exception
     *             the exception
     */
    private void updateConnectionReqId(Long processId, Long tiRequestId, String tableName) throws Exception {
        LOGGER.debug("updateConnectionReqId START::");
        C3parSession c3parSession = new C3parSession();
        PreparedStatement pstmt = null;
        Connection con = null;
        int rows = 0;
        try {
            con = c3parSession.getConnection();
            String sql = "UPDATE "
                    + tableName
                    + " a SET a.connection_request_id = NULL"
                    + " WHERE a.ti_request_id IN ( SELECT MAX (ID) FROM c3par.ti_request a WHERE a.process_id = ?"
                    + "  AND (a.is_deleted = 'N' OR a.is_deleted IS NULL) AND ti_request_type_id IN ( SELECT ID FROM ti_request_type"
                    + " WHERE request_type IN ('Create', 'Maintain')) AND ID NOT IN (?))";
            pstmt = con.prepareStatement(sql);
            pstmt.setLong(1, processId.longValue());
            pstmt.setLong(2, tiRequestId.longValue());
            rows = pstmt.executeUpdate();
            LOGGER.debug(rows + ": Rows of " + tableName + "connection_request_id is set to NULL");
        } catch (Exception e) {
            LOGGER.error(e.toString(), e);
        } finally {
            if (pstmt != null)
                pstmt.close();
            if (con != null)
                con.close();
        }
        LOGGER.debug("updateConnectionReqId END::");
    }

    /**
     * Update aborted process id.
     * 
     * @param processId
     *            the process id
     * @param tiRequestId
     *            the ti request id
     * @param tableName
     *            the table name
     * @throws Exception
     *             the exception
     */
    private void updateAbortedProcessId(Long processId, Long tiRequestId, String tableName) throws Exception {
        LOGGER.debug("updateAbortedProcessId START::");
        C3parSession c3parSession = new C3parSession();
        Statement stmt = null;
        Connection con = null;

        try {
            con = c3parSession.getConnection();
            String sql1 = "UPDATE " + tableName + " a SET a.PROCESS_ID =" + processId
                    + " WHERE a.ti_request_id IN ( SELECT MAX (ID) " + " FROM c3par.ti_request a WHERE a.process_id = "
                    + processId
                    + " AND (a.is_deleted = 'N' OR a.is_deleted IS NULL) AND ti_request_type_id IN ( SELECT ID "
                    + " FROM ti_request_type WHERE request_type IN ('Create', 'Maintain')) AND ID NOT IN ("
                    + tiRequestId + "))";

            String sql2 = " UPDATE " + tableName + " a SET a.PROCESS_ID = NULL  WHERE a.ti_request_id =" + tiRequestId;

            con.setAutoCommit(false);
            stmt = con.createStatement();
            stmt.addBatch(sql1);
            stmt.addBatch(sql2);
            int[] updateCounts = stmt.executeBatch();
            con.commit();
            LOGGER.debug(updateCounts + ": Rows of " + tableName + ".PROCESS_ID is updated");
        } catch (Exception e) {
            LOGGER.error(e.toString(), e);
        } finally {
            if (stmt != null)
                stmt.close();
            if (con != null)
                con.close();
        }
        LOGGER.debug("updateAbortedProcessId END::");
    }

    /**
     * Gets the copy data.
     * 
     * @param processId
     *            the process id
     * @param tiRequestId
     *            the ti request id
     * @return the copy data
     */
    private long getCopyData(Long processId, Long tiRequestId) {
        Long count = Long.valueOf(0);
        Statement stmt = null;
        ResultSet result = null;
        Connection connection = null;

        try {
            String sql = " SELECT COUNT(*) FROM con_ip_pair_xref a WHERE a.ti_request_id IN ( SELECT MAX (ID) "
                    + " FROM c3par.ti_request a WHERE a.process_id = " + processId
                    + "  AND (a.is_deleted = 'N' OR a.is_deleted IS NULL) AND ti_request_type_id IN ( SELECT ID "
                    + " FROM ti_request_type WHERE request_type IN ('Create', 'Maintain')) AND ID NOT IN ("
                    + tiRequestId + "))";
            connection = new C3parSession().getConnection();
            stmt = connection.createStatement();
            result = stmt.executeQuery(sql);
            if (result.next()) {
                count = Long.valueOf(result.getLong(1));
            }

        } catch (Exception e) {
            LOGGER.error(e.toString(), e);
        } finally {
            try {
                if (result != null)
                    result.close();
                if (stmt != null)
                    stmt.close();
                if (connection != null)
                    connection.close();
            } catch (Exception ie) {
                LOGGER.error(ie);
            }
        }

        if (count == null) {
            count = Long.valueOf(0);
        }
        LOGGER.debug("count-----" + count);
        return (count.longValue());
    }

    /**
     * Update aborted con req id.
     * 
     * @param processId
     *            the process id
     * @param tiRequestId
     *            the ti request id
     * @param tableName
     *            the table name
     * @throws Exception
     *             the exception
     */
    private void updateAbortedConReqId(Long processId, Long tiRequestId, String tableName) throws Exception {
        LOGGER.debug("updateAbortedConReqId START::");
        C3parSession c3parSession = new C3parSession();
        Statement stmt = null;
        Connection con = null;

        try {
            con = c3parSession.getConnection();
            String sql1 = "UPDATE " + tableName + " a SET a.connection_request_id =" + processId
                    + " WHERE a.ti_request_id IN ( SELECT MAX (ID) " + " FROM c3par.ti_request a WHERE a.process_id = "
                    + processId
                    + " AND (a.is_deleted = 'N' OR a.is_deleted IS NULL) AND ti_request_type_id IN ( SELECT ID "
                    + " FROM ti_request_type WHERE request_type IN ('Create', 'Maintain')) AND ID NOT IN ("
                    + tiRequestId + "))";

            String sql2 = " UPDATE " + tableName + " a SET a.connection_request_id = NULL  WHERE a.ti_request_id ="
                    + tiRequestId;

            con.setAutoCommit(false);
            stmt = con.createStatement();
            stmt.addBatch(sql1);
            stmt.addBatch(sql2);
            int[] updateCounts = stmt.executeBatch();
            con.commit();
            LOGGER.debug(updateCounts + ": Rows of " + tableName + ".connection_request_id is updated");
        } catch (Exception e) {
            LOGGER.error(e.toString(), e);
        } finally {
            if (stmt != null)
                stmt.close();
            if (con != null)
                con.close();
        }
        LOGGER.debug("updateAbortedConReqId END::");
    }

    /**
     * List to string.
     * 
     * @param data
     *            the data
     * @param isString
     *            the is string
     * @return the string
     */
    private String listToString(List data, boolean isString) {
        if (data == null || data.size() == 0)
            return null;
        Iterator iter = data.iterator();
        StringBuffer output = new StringBuffer();
        String dataString = null;
        Object dataObject = null;
        while (iter.hasNext()) {
            dataObject = iter.next();
            dataString = dataObject.toString();
            output.append(",");
            if (isString) {
                output.append("'");
            }
            output.append(dataString);
            if (isString) {
                output.append("'");
            }
        }
        return output.toString().substring(1);
    }

    /**
     * Gets the appsense process data.
     * 
     * @param processId
     *            the process id
     * @return the appsense process data
     */
    public Map getAppsenseProcessData(long processId) {

        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        HashMap processData = new HashMap();
        try {
            StringBuffer sb = new StringBuffer(
                    "select r.name,rr.name, r.relationship_type from relationship r,ti_process tp,resourcetype rr where tp.relationship_id=r.id and r.TARGET_RESOURCE_TYPE_ID = rr.id and tp.id= ?");
            con = c3parSession.getConnection();
            stmt = con.prepareStatement(sb.toString());
            stmt.setLong(1, processId);
            LOGGER.debug("TechnicalArchitectureUtil.getAppsenseProcessData()QUERY--" + sb.toString());
            rs = stmt.executeQuery();
            while (rs.next()) {
                processData.put("POLICY_NAME", (String) rs.getString(1));
                processData.put("RESOURCE_TYPE", (String) rs.getString(2));
                processData.put("RELATIONSHIP_TYPE", (String) rs.getString(3));
            }

        } catch (Exception e) {
            LOGGER.error(e.toString(), e);
        } finally {
            try {
                if (rs != null) {
                    c3parSession.closeResultSet(rs);
                }
                if (stmt != null) {
                    c3parSession.closeStatement(stmt);
                }
                if (con != null) {
                    c3parSession.releaseConnection();
                }
            } catch (Exception ex) {
                LOGGER.error(ex.toString(), ex);
            }
        }

        return processData;
    }

    /**
     * Gets the risk pairs.
     * 
     * @param startId
     *            the start id
     * @param endId
     *            the end id
     * @param conReq
     *            the con req
     * @return the risk pairs
     */
    public String getRiskPairs(Long startId, Long endId, Long conReq) {

        String isAnyIP = "N";
        C3parSession c3parSession = new C3parSession();
        Connection con = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        StringBuffer sb = new StringBuffer(
                " select 'I' as INTERNET from con_ip_xref,con_ip_master where con_ip_xref.RESOURCE_TYPE in(select id from resourcetype where name='Internet')");
        sb.append(" and con_ip_xref.IP_ID in(" + startId + "," + endId
                + ")and con_ip_xref.ip_id=con_ip_master.ID and con_ip_master.IS_ANY_IP='Y' and rownum<2 ");

        StringBuffer sb1 = new StringBuffer(" select 'Y' as ANY_IP from con_ip_xref ipx,con_ip_master ipm where");
        sb1.append(" ipx.CONNECTION_REQUEST_ID=" + conReq);
        sb1.append(" and ipx.IP_ID in(" + startId + "," + endId + ")");
        sb1.append(" and ipm.id=ipx.ip_id and ipm.IS_ANY_IP='Y' and rownum<2 ");
        try {
            con = c3parSession.getConnection();
            stmt = con.prepareStatement(sb.toString());
            rs = stmt.executeQuery();
            if (rs.next()) {
                isAnyIP = rs.getString(1);

            } else {
                stmt = con.prepareStatement(sb1.toString());
                rs = stmt.executeQuery();
                while (rs.next()) {
                    isAnyIP = rs.getString(1);

                }

            }

            LOGGER.debug("Returning IS_ANY_IP_PAIR --" + isAnyIP);
        } catch (Exception e) {
            LOGGER.error(e.toString(), e);
        } finally {
            try {
                rs.close();
                stmt.close();
                con.close();
            } catch (Exception ex) {
                LOGGER.error(ex);
            }
        }

        return isAnyIP;
    }

    /*
     * 
     * 
     * SELECT * FROM con_port_xref WHERE port_id IN ( SELECT j.id FROM (SELECT
     * MIN (b.id) id, b.port_number FROM (SELECT COUNT (prt2.port_number) cnt,
     * prt2.port_number FROM (SELECT DISTINCT a.*, d.protocol protocol, NVL
     * (e.control_msg, 0) control_msg, f.GROUP_ID FROM con_port_master a,
     * con_port_xref b, con_ip_pair_xref c, (SELECT SUM ( protocol_id
     * protocol_id ) AS protocol, port_id FROM con_port_protocol_xref GROUP BY
     * port_id) d, (SELECT SUM ( control_msg_id control_msg_id ) AS control_msg,
     * port_id FROM con_port_ctrlmsg_xref GROUP BY port_id) e,
     * con_riskport_ostia f WHERE c.ip_pair_id IN (SELECT MIN ( id ) FROM
     * con_ip_pair_master WHERE id IN (SELECT con_ip_pair_master.id FROM
     * con_ip_pair_master, con_ip_pair_xref WHERE con_ip_pair_master.id =
     * con_ip_pair_xref.ip_pair_id AND con_ip_pair_xref.connection_request_id =
     * 504)) AND c.id = b.ip_pair_xref_id AND b.port_id = a.id AND a.id =
     * d.port_id AND a.id = e.port_id(+) AND a.id = f.port_id) prt1, (SELECT
     * DISTINCT a.*, d.protocol protocol, NVL (e.control_msg, 0) control_msg,
     * f.GROUP_ID FROM con_port_master a, con_port_xref b, con_ip_pair_xref c,
     * (SELECT SUM ( protocol_id protocol_id ) AS protocol, port_id FROM
     * con_port_protocol_xref GROUP BY port_id) d, (SELECT SUM ( control_msg_id
     * control_msg_id ) AS control_msg, port_id FROM con_port_ctrlmsg_xref GROUP
     * BY port_id) e, con_riskport_ostia f WHERE c.ip_pair_id IN (SELECT
     * con_ip_pair_master.id FROM con_ip_pair_master, con_ip_pair_xref WHERE
     * con_ip_pair_master.id = con_ip_pair_xref.ip_pair_id AND
     * con_ip_pair_xref.connection_request_id = 504) AND c.id =
     * b.ip_pair_xref_id AND b.port_id = a.id AND a.id = d.port_id AND a.id =
     * e.port_id(+) AND a.id = f.port_id) prt2 WHERE prt1.port_number =
     * prt2.port_number AND prt1.flow_of_data = prt2.flow_of_data AND
     * prt1.default_service_flag = prt2.default_service_flag AND NVL
     * (prt1.service_name, '-') = NVL (prt2.service_name, '-') AND NVL
     * (prt1.other_service_text, '-') = NVL (prt2.other_service_text, '-') AND
     * prt1.protocol = prt2.protocol AND prt1.control_msg = prt2.control_msg AND
     * NVL (prt1.GROUP_ID, 0) = NVL (prt2.GROUP_ID, 0) GROUP BY
     * prt2.port_number) prtcnt, con_port_master b WHERE prtcnt.cnt = (SELECT
     * COUNT (id) FROM con_ip_pair_master WHERE id IN (SELECT
     * con_ip_pair_master.id FROM con_ip_pair_master, con_ip_pair_xref WHERE
     * con_ip_pair_master.id = con_ip_pair_xref.ip_pair_id AND
     * con_ip_pair_xref.connection_request_id = 504)) AND b.port_number =
     * prtcnt.port_number AND b.ip_pair_id IN (SELECT con_ip_pair_master.id FROM
     * con_ip_pair_master, con_ip_pair_xref WHERE con_ip_pair_master.id =
     * con_ip_pair_xref.ip_pair_id AND con_ip_pair_xref.connection_request_id =
     * 504) GROUP BY b.port_number) j, con_port_master WHERE j.id =
     * con_port_master.id) AND id > 0 AND ip_pair_xref_id IN (SELECT id FROM
     * con_ip_pair_xref WHERE connection_request_id = 504) ORDER BY id DESC
     */

    /**
     * Gets the c3par session.
     * 
     * @return the c3par session
     */
    public C3parSession getC3parSession() {
        return c3parSession;
    }

    /**
     * Sets the c3par session.
     * 
     * @param session
     *            the new c3par session
     */
    public void setC3parSession(C3parSession session) {
        c3parSession = session;
    }

    private void updateAbortedProcessIdFWRule(Long processId, Long tiRequestId) throws Exception {
        LOGGER.debug("updateAbortedProcessIdFWRule STARTs...........");
        C3parSession c3parSession = new C3parSession();
        PreparedStatement pstmt = null;
        PreparedStatement pstmt1 = null;
        PreparedStatement pstmt2 = null;
        Connection con = null;
        int rows = 0;
        try {
            con = c3parSession.getConnection();
            String sql = "UPDATE con_fw_rule a SET a.status = 'DELETE',a.deleted_ti_request_id = ?"
                    + " WHERE a.TI_REQUEST_ID = ?";
            pstmt = con.prepareStatement(sql);
            pstmt.setLong(1, tiRequestId.longValue());
            pstmt.setLong(2, tiRequestId.longValue());
            rows = pstmt.executeUpdate();
            LOGGER.debug(rows + ": Rows of con_fw_rule status is set to DELETE");

            String sql1 = "UPDATE CON_FW_RULE_APPLICATION a SET a.deleted_ti_request_id = ?"
                    + " WHERE a.TI_REQUEST_ID = ?";
            pstmt1 = con.prepareStatement(sql1);
            pstmt1.setLong(1, tiRequestId.longValue());
            pstmt1.setLong(2, tiRequestId.longValue());
            rows = pstmt1.executeUpdate();
            LOGGER.debug(rows + ": Rows of CON_FW_RULE_APPLICATION status is set deleted_ti_request_id");

            String sql2 = "UPDATE CON_FW_RULE_QUESTIONNAIRE a SET a.deleted_ti_request_id = ?"
                    + " WHERE a.UPDATED_TI_REQUEST_ID = ?";
            pstmt2 = con.prepareStatement(sql2);
            pstmt2.setLong(1, tiRequestId.longValue());
            pstmt2.setLong(2, tiRequestId.longValue());
            rows = pstmt2.executeUpdate();
            LOGGER.debug(rows + ": Rows of CON_FW_RULE_QUESTIONNAIRE status is set deleted_ti_request_id");
        } catch (Exception e) {
            LOGGER.error(e.toString(), e);
        } finally {
            if (pstmt != null)
                pstmt.close();
            if (pstmt1 != null)
                pstmt1.close();
            if (pstmt2 != null)
                pstmt2.close();
            if (con != null)
                con.close();
        }
        LOGGER.debug("updateAbortedProcessIdFWRule ENDs............");
    }

    private String copyFWRulesFromHistoryForAbortScenario(Long processId, Long tiRequestId) throws Exception {
        LOGGER.debug(processId + "Process Id :: Ti Request Id (this should be last non-aborted id" + tiRequestId);
        C3parSession c3parSession = new C3parSession();
        Connection con = null;
        CallableStatement stmt = null;
        String result = null;
        try {
            con = c3parSession.getConnection();
            stmt = con.prepareCall("{call COPY_FWRULE_FOR_ABORT(?,?,?)}");
            stmt.setLong(1, processId.longValue());
            stmt.setLong(2, tiRequestId.longValue());

            stmt.registerOutParameter(3, Types.VARCHAR);
            stmt.execute();
            result = stmt.getString(3);
        } catch (Exception ex) {
            LOGGER.error(ex.toString(), ex);
        } finally {

            if (stmt != null)
                stmt.close();
            if (con != null)
                con.close();
            LOGGER.debug("The stored prc has been executed, result " + result);
        }
        return result;
    }

    /**
     * This function is called when an cycle is aborted. 
     * It fetches the last ti request id (maintenance or planning ) which was approved or temporarily approved. 
     * It does this by fetching the last /max ti request id from history_con_fw_rule table for the given process id. 
     * 
     * @param processId = CCR id or process id of the connection for which the ti request id is required. 
     * @return Tirequest id : Long : Last ti request id from history table. If there is an exception it returns null.(please be careful about null being returned) 
     */
    private Long getLastActiveNonACVTIRequestId(Long processId) {
        Long tiRequest = null;
        if(null!=sessionFactory && null!=ccrQueries){
            LOGGER.debug("Entering with processId : "+processId);
            //This method is being modified due to the following failed test case:
            //It was correctly fetching the last non-acv,non-soft deleted cycle but in the case of rejected cycle it was fecthign the rejected cycle's id as it is not soft deleted. 
            //The rejected cycle doesn't have an entry into con_fw_rule or history_con_fw_rule table therefore this query should go an look for the max ti request id for a given process id. 
            
            // Using CCR Queries table to get the query to be fired.
            //Ideally this query should be same as PREVIOUS_NON_DELETED_TI_REQUEST_QUERY but this is untested . 
            //Since this a last minute change,we are creating a new query, if things are stable we can replace the following query with PREVIOUS_NON_DELETED_TI_REQUEST_QUERY and change  it accodingly. 
            String previousTIRequestQuery = ccrQueries.getQueryByName(QueryConstants.PREVIOUS_NON_DELETED_TI_REQUEST_QUERY_VER2);
            Session session = sessionFactory.getCurrentSession();

            // The output of the query should be the last non-deleted,
            // non-acv,non-manage contact id.
            SQLQuery query = session.createSQLQuery(previousTIRequestQuery);
            query.setLong(0, processId);
            query.addScalar("id", LongType.INSTANCE);
            tiRequest = (Long) query.uniqueResult();
            LOGGER.debug("Existing with tiRequest : "+tiRequest);
        }else{
            LOGGER.debug("Entering else : sessionFactory or ccrQueries is null..!!! ");
        }
        return tiRequest;
    }

}
