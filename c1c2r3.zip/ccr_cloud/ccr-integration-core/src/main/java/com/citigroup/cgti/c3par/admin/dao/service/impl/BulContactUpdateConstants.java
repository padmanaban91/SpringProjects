package com.citigroup.cgti.c3par.admin.dao.service.impl;

/**
 * @author ka58098
 *
 */
public interface BulContactUpdateConstants {
public  String CONTACT_SELECTED="Y";
public  String PRIMARY_YES="Primary=Yes";
public  String PRIMARY_NO="Primary=No";

public  String NOTIFY_NO="Notify=No";
public  String NOTIFY_YES="Notify=Yes";
}
