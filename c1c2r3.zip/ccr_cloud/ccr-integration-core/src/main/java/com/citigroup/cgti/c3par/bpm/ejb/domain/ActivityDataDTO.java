package com.citigroup.cgti.c3par.bpm.ejb.domain;
import java.io.Serializable;


/**
 * The Class ActivityDataDTO.
 */
public class ActivityDataDTO implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -6921569060771938620L;

    // Activty Mode values
    /** The Constant IS_NEW. */
    public static final String IS_NEW = "NEW";

    /** The Constant IS_REWORK. */
    public static final String IS_REWORK = "REWORK";

    /** The Constant IS_RECONSILE. */
    public static final String IS_RECONSILE = "RECONCILE";

    // Activity Type
    /** The Constant TYPE_APPROVAL. */
    public static final String TYPE_APPROVAL = "APPROVAL";

    /** The Constant TYPE_PROVIDEINFO. */
    public static final String TYPE_PROVIDEINFO = "PROVIDEINFO";

    // Activity Names
    /** The Constant ACTIVITY_START_PROCESS. */
    public static final String ACTIVITY_START_PROCESS = "start_process";

    /** The Constant ACTIVITY_BUS_JUS. */
    public static final String ACTIVITY_BUS_JUS = "bus_jus";

    /** The Constant ACTIVITY_TEC_ARC. */
    public static final String ACTIVITY_TEC_ARC = "tec_arc";

    /** The Constant ACTIVITY_ISO_APP. */
    public static final String ACTIVITY_ISO_APP = "iso_app";

    /** The Constant ACTIVITY_SE_APP. */
    public static final String ACTIVITY_SE_APP = "se_app";

    /** The Constant ACTIVITY_TPW_APP. */
    public static final String ACTIVITY_TPW_APP = "tpw_app";

    /** The Constant ACTIVITY_IST_APP. */
    public static final String ACTIVITY_IST_APP = "ist_app";

    /** The Constant ACTIVITY_MGR_APP. */
    public static final String ACTIVITY_MGR_APP = "bu_mgr_app";

    /** The Constant ACTIVITY_OPE_IMP. */
    public static final String ACTIVITY_OPE_IMP = "ope_imp";
    
    /** The Constant ACTIVITY_OPE_IPREG_IMP. */
    public static final String ACTIVITY_OPE_IPREG_IMP = "ope_ipreg_imp";

    /** The Constant ACTIVITY_ACT_CON. */
    public static final String ACTIVITY_ACT_CON = "act_con";

    /** The Constant ACTIVITY_IP_DET. */
    public static final String ACTIVITY_IP_DET = "ip_det";

    /** The Constant Activity_ROL_FW_IMP. */
    public static final String Activity_ROL_FW_IMP="rol_fw_imp";

    /** The Constant ACTIVITY_APPSENSE_IMP. */
    public static final String ACTIVITY_APPSENSE_IMP = "appsense_imp";
    public static final String ACTIVITY_UAT_APPSENSE_IMP = "uat_appsense_imp";
    public static final String ACTIVITY_UAT_APPSNSE_PRO_INF = "uat_appsense_provide_info";
    public static final String ACTIVITY_UAT_REQUEST_VALIDATION = "uat_request_validation";

    /** The Constant ACTIVITY_PROXY_IMP. */
    public static final String ACTIVITY_PROXY_IMP = "proxy_imp";

    /** The Constant ACTIVITY_GNCC_IMP. */
    public static final String ACTIVITY_GNCC_IMP = "gncc_imp";

    /** The Constant Activity_Business_User. */
    public static final String Activity_Business_User="business_user";

    //new Activities introduced in 4.1
    /** The Constant Activity_OTRM_APP. */
    public static final String Activity_OTRM_APP="otrm_app";

    /** The Constant Activity_MAD_APP. */
    public static final String Activity_MAD_APP="mad_app";

    /** The Constant Activity_OTRM_RET_APP. */
    public static final String Activity_OTRM_RET_APP="otrm_ret_app";

    /** The Constant Activity_MAD_RET_APP. */
    public static final String Activity_MAD_RET_APP="mad_ret_app";

    /** The Constant Activity_TPW_RET_APP. */
    public static final String Activity_TPW_RET_APP="tpw_ret_app";

    /** The Constant Activity_FIX_CON. */
    public static final String Activity_FIX_CON="fix_con";

    /** The Constant Activity_OST_UPD. */
    public static final String Activity_OST_UPD="ost_upd";

    /** The Constant Activity_COM_WAT. */
    public static final String Activity_COM_WAT="com_wat";

    //Activity for ACV process
    /** The Constant Activity_VER_SOW. */
    public static final String Activity_VER_SOW="ver_sow";

    /** The Constant ACTIVITY_PC_PRO_INF. */
    public static final String ACTIVITY_PC_PRO_INF = "pro_inf";

    /** The Constant ACTIVITY_DE_PRO_INF. */
    public static final String ACTIVITY_DE_PRO_INF = "pro_inf1";

    /** The Constant ACTIVITY_BISO_PRO_INF. */
    public static final String ACTIVITY_BISO_PRO_INF = "pro_inf2";

    /** The Constant ACTIVITY_SE_PRO_INF. */
    public static final String ACTIVITY_SE_PRO_INF = "pro_inf6";

    /** The Constant ACTIVITY_TPAWG_PRO_INF. */
    public static final String ACTIVITY_TPAWG_PRO_INF = "pro_inf3";

    /** The Constant ACTIVITY_ISTG_PRO_INF. */
    public static final String ACTIVITY_ISTG_PRO_INF = "pro_inf4";

    /** The Constant ACTIVITY_OA_PRO_INF. */
    public static final String ACTIVITY_OA_PRO_INF = "pro_inf5";

    /** The Constant ACTIVITY_MGR_PRO_INF. */
    public static final String ACTIVITY_MGR_PRO_INF = "pro_inf7";

    /** The Constant ACTIVITY_PRO_INF. */
    public static final String ACTIVITY_PRO_INF = "pro_inf";

    /** The Constant ACTIVITY_OTRM_PRO_INF. */
    public static final String ACTIVITY_OTRM_PRO_INF = "otrm_pro_inf";

    /** The Constant ACTIVITY_MAD_PRO_INF. */
    public static final String ACTIVITY_MAD_PRO_INF = "mad_pro_inf";

    /** The Constant ACTIVITY_APSNSE_PRO_INF. */
    public static final String ACTIVITY_APSNSE_PRO_INF = "pro_inf8";

    /** The Constant ACTIVITY_PRXY_PRO_INF. */
    public static final String ACTIVITY_PRXY_PRO_INF = "pro_inf9";

    /** The Constant ACTIVITY_HAN_RFC_EXC. */
    public static final String ACTIVITY_HAN_RFC_EXC = "han_rfc_exc";

    /** The Constant ACTIVITY_HAN_RFC_EXC_PROXY. */
    public static final String ACTIVITY_HAN_RFC_EXC_PROXY = "han_rfc_exc_proxy";

    /** The Constant ACTIVITY_GNCC_PRO_INF. */
    public static final String ACTIVITY_GNCC_PRO_INF = "pro_inf10";

    public static final String ACTIVITY_HAN_FIREFLOW_EXC = "han_fireflow_exc";
    public static final String ACTIVITY_IPREG_PRO_INF = "pro_inf11";

    //these 3 statuses are used onlt in Tiprocess when a process is ended  
    /** The Constant ACTIVITY_ACTIVE. */
    public static final String ACTIVITY_ACTIVE = "Active";

    /** The Constant ACTIVITY_TERMINATED. */
    public static final String ACTIVITY_TERMINATED = "Terminated";

    /** The Constant ACTIVITY_ABORTED. */
    public static final String ACTIVITY_ABORTED = "Aborted";

    /** The Constant ACTIVITY_ROLLEDBACK. */
    public static final String ACTIVITY_ROLLEDBACK = "Rolledback";

    /** The Constant ACTIVITY_REJECTED. */
    public static final String ACTIVITY_REJECTED = "Rejected";
    //Exceptions
    /** The Constant ACTIVITY_EXCEPTION. */
    public static final String ACTIVITY_EXCEPTION = "Exception";

    /** The Constant ACTIVITY_IMPL_EXCEPTION. */
    public static final String ACTIVITY_IMPL_EXCEPTION = "Implementation Exception";

    /** The Constant ACTIVITY_PAFIMPL_EXCEPTION. */
    public static final String ACTIVITY_PAFIMPL_EXCEPTION = "PAF Implementation Exception";

    /** The Constant ACTIVITY_FAFIMPL_EXCEPTION. */
    public static final String ACTIVITY_FAFIMPL_EXCEPTION = "FAF Implementation Exception";

    /** The Constant ACTIVITY_AAFIMPL_EXCEPTION. */
    public static final String ACTIVITY_AAFIMPL_EXCEPTION = "AAF Implementation Exception";


    //Expiration Activities
    /** The Constant ACTIVITY_INC_EXP. */
    public static final String ACTIVITY_INC_EXP = "inc_exp";

    /** The Constant ACTIVITY_APP_EXP. */
    public static final String ACTIVITY_APP_EXP = "app_exp";

    /** The Constant ACTIVITY_IMPL_EXP. */
    public static final String ACTIVITY_IMPL_EXP = "impl_exp";

    /** The Constant ACTIVITY_ACV_EXP. */
    public static final String ACTIVITY_ACV_EXP = "acv_exp";

    /** The Constant ACTIVITY_REC_EXP. */
    public static final String ACTIVITY_REC_EXP = "rec_exp";

    /** The Constant ACTIVITY_TMP_EXP. */
    public static final String ACTIVITY_TMP_EXP = "tmp_exp";

    /** The Constant ACTIVITY_ACT_EXP. */
    public static final String ACTIVITY_ACT_EXP = "act_exp";

    /** The Constant ACTIVITY_GNCC_EXP. */
    public static final String ACTIVITY_GNCC_EXP = "gncc_exp";

    // Activty Status
    /** The Constant STATUS_COMPLETED. */
    public static final String STATUS_COMPLETED = "COMPLETED";

    /** The Constant STATUS_REJECTED. */
    public static final String STATUS_REJECTED = "REJECTED";

    /** The Constant STATUS_REQUIRED. */
    public static final String STATUS_REQUIRED = "REQUIRED";

    /** The Constant STATUS_EXPIRED. */
    public static final String STATUS_EXPIRED = "EXPIRED";

    /** The Constant STATUS_TERMINATED. */
    public static final String STATUS_TERMINATED = "TERMINATED";

    /** The Constant STATUS_EXCEPTION. */
    public static final String STATUS_EXCEPTION = "EXCEPTION";

    /** The Constant STATUS_COMPLETED. */
    public static final String COMPLETED_FORCEFULLY = "COMPLETED_FORCEFULLY";

    // activity currently being worked upon will have status scheduled.There can
    // be only one activity with scheduled status
    /** The Constant STATUS_SCHEDULED. */
    public static final String STATUS_SCHEDULED = "SCHEDULED";
    // Activity which spawned a new provide info activity will have  provideinfo status

    /** The Constant STATUS_PROVIDEINFO. */
    public static final String STATUS_PROVIDEINFO = "PROVIDEINFO"; 

    /** The Constant STATUS_UNLOCK. */
    public static final String STATUS_UNLOCK = "UNLOCKED";

    /** The Constant STATUS_ABORTED. */
    public static final String STATUS_ABORTED = "ABORTED";

    /** The Constant STATUS_EXTENDED. */
    public static final String STATUS_EXTENDED = "EXTENDED";

    /** The Constant STATUS_ROLLEDBACK. */
    public static final String STATUS_ROLLEDBACK = "ROLLEDBACK";

    /** The Constant STATUS_MOVED. */
    public static final String STATUS_MOVED = "MOVED";
    
    /** The Constant STATUS_MOVED. */
    public static final String STATUS_MOVED_TO_TPASWG = "MOVED_TO_TPASWG";
    
    /**
     * 
     */
    public static final String STATUS_MOVED_TO_HQUEUE = "MOVED_TO_LOG_QUEUE";

    /** The Constant STATUS_DEFERRED. */
    public static final String STATUS_DEFERRED = "DEFERRED";

    /** The Constant STATUS_TEMP_APPROVED. */
    public static final String STATUS_TEMP_APPROVED = "TEMP_APPROVED";

    /** The Constant STATUS_RESCHEDULE. */
    public static final String STATUS_RESCHEDULE = "RESCHEDULED";

    /** The Constant STATUS_END. */
    public static final String STATUS_END = "END";

    /** The Constant STATUS_SUSPENDED. */
    public static final String STATUS_SUSPENDED = "SUSPENDED";

    /** The Constant STATUS_ERROR. */
    public static final String STATUS_ERROR = "ERROR";

    /** The Constant STATUS_RETRY. */
    public static final String STATUS_RETRY = "RETRY";   

    /** The Constant STATUS_UNLOCK_TEXT. */
    public static final String STATUS_UNLOCK_TEXT = "Unlock Task";
    
    /** The Constant STATUS_STARTED. */
    public static final String STATUS_STARTED = "STARTED";   


    // Roles
    /** The Constant ROLE_PC. */
    public static final String ROLE_PC = "PROJECT COORDINATOR";

    /** The Constant ROLE_SA. */
    public static final String ROLE_SA = "C3PARSYSTEMADMIN";

    /** The Constant ROLE_TPWG. */
    public static final String ROLE_TPWG = "TPASWG";

    /** The Constant ROLE_OA. */
    public static final String ROLE_OA = "Operational_Analyst";
    
    /** The Constant ROLE_OA. */
    public static final String ROLE_OA_IP = "Operational_Analyst_IP";

    /** The Constant ROLE_ISO. */
    public static final String ROLE_ISO = "BISO";

    /** The Constant ROLE_DE. */
    public static final String ROLE_DE = "DESIGN ENGINEER";

    /** The Constant ROLE_ISTG. */
    public static final String ROLE_ISTG = "ISTG_Chair";

    /** The Constant ROLE_SE. */
    public static final String ROLE_SE = "Security Engineer";

    /** The Constant ROLE_MGR. */
    public static final String ROLE_MGR = "Manager";

    /** The Constant ROLE_SAG. */
    public static final String ROLE_SAG = "Support Agent";
    //new roles introduced in 4.1
    /** The Constant ROLE_OTRM. */
    public static final String ROLE_OTRM = "OTRM";

    /** The Constant ROLE_MAD. */
    public static final String ROLE_MAD = "MAD";

    /** The Constant ROLE_APSIMPL. */
    public static final String ROLE_APSIMPL = "Appsense_Implementer";

    /** The Constant ROLE_PRXIMPL. */
    public static final String ROLE_PRXIMPL = "Proxy_Implementer";

    /** The Constant ROLE_GNCCIMPL. */
    public static final String ROLE_GNCCIMPL = "GNCC";

    /** The Constant ROLE_BUSINESS_USER. */
    public static final String ROLE_BUSINESS_USER= "Business User";

    public static final String ROLE_ECM= "ECM";


    // Stage DATACOLLECTION,APPROVAL,IMPLEMENTATION,VERIFICATION
    /** The Constant STAGE_DATACOLLECTION. */
    public static final String STAGE_DATACOLLECTION = "DC";

    /** The Constant STAGE_APPROVAL. */
    public static final String STAGE_APPROVAL = "AP";

    /** The Constant STAGE_IMPLEMENTAION. */
    public static final String STAGE_IMPLEMENTAION = "IM";

    /** The Constant STAGE_VALIDATION. */
    public static final String STAGE_VALIDATION = "VA";
    
    public static final String ACTIVITY_TEMP_APP_EXP = "tmp_exp";
    
    public static final String ACTIVITY_OTRM_RECONCILE_EXP = "rec_exp";
    
    public static final String ACTIVITY_LOGGING_QUEUE="oa_log";
    
    /** The Constant BY_PASS_SERVICE_NOW. */
    public static final String FW_BY_PASS_SERVICE_NOW = "impl_sn_bypass";
    
    /** The Constant BY_PASS_SERVICE_NOW. */
    public static final String PROXY_BY_PASS_SERVICE_NOW = "proxy_impl_sn_bypass";
    
    public static final String REVERTED="REVERTED";
    
    public static final String FORCE_FULLY_ABORTED="FORCEFULLYABORTEd";
    
    public static final String STATUS_MOVED_TO_RECON_ADMIN = "MOVED_TO_RECON_ADMIN";
    
    public static final String STATUS_MOVED_TO_GIS = "MOVED_TO_GIS";
    
    public static final String ACTIVITY_RECON_ADR = "recon_adr";
    
    public static final String ACTIVITY_EXTEND_RISO_TEMP_APPROVE = "extend_riso_temp_app";
    
    public static final String STATUS_RISO_APPROVAL_RECEIVED = "RISO_APPROVAL_RECEIVED";

    /** The id. */
    private Long id;

    // could be AP for Approval and PI for Process Info Mode
    /** The activity type. */
    private String activityType = "";

    // Represents Logical work group
    // -DataCollection,Approval,Implementation,Validation
    /** The activity stage. */
    private String activityStage = "";

    /** The activity name. */
    private String activityName = "";

    /** The activity code. */
    private String activityCode="";

    /** The activity status. */
    private String activityStatus = "";
    //		 SSO ID of the user who worked on it
    /** The user id. */
    private String userID = "";

    // PC/DE/ISTG
    /** The user role. */
    private String userRole = " ";

    /** The display user role. */
    private String displayUserRole = " ";

    // Could be New Rework or Reconsile
    /** The activity mode. */
    private String activityMode = "";

    //TODO see if we can clear these
    /** The locked by. */
    private String lockedBy = "";


    // if infoMode is true infoUserRole represents the role form whom the
    // information is requested
    /** The info user role. */
    private String infoUserRole = " ";

    /** The display info user role. */
    private String displayInfoUserRole = " ";

    /** The pr info activity data dto. */
    private ActivityDataDTO prInfoActivityDataDTO;
    
    
    public static final String Activity_ADMIN_EXT_ACV="AdminOptionalAnnualConnectivityVerification";
    public static final String Activity_BU_EXT_ACV="BUAnnualConnectivityVerification";
    public static final String Activity_PC_EXT_ACV="PCAnnualConnectivityVerification";
    public static final String Activity_TC_EXT_ACV="TCAnnualConnectivityVerification";
    public static final String Activity_ISO_EXT_ACV="ISOAnnualConnectivityVerification";
    public static final String Activity_ADMIN_INT_ACV="VerifySOW3";
    public static final String Activity_BU_INT_ACV="BUVerifySOW";
    public static final String Activity_PC_INT_ACV="VerifySOW4";
    public static final String Activity_TC_INT_ACV="VerifySOW";
    public static final String Activity_ISO_INT_ACV="VerifySOW2";

    public static final String ACTIVITY_ACV_LOGGING_REQUEST = "acv_logging_request";

    public static final String ACTIVITY_ACV_LOGGING = "acv_logging";

    public static final String ACTIVITY_ACV_LOGGING_COMPLETED = "acv_logging_completed";

    public static final String ACTIVITY_ACV_LOGGING_QUEUE = "LOGGING_QUEUE";

    public static final String ACTIVITY_SEND_TO_ACV = "SEND_TO_ACV";
    
    public static final String MASTER_ACTIVITY_CODE_LOGGING_QUEUE = "oa_log";
    //oa_log
    public static final String ACTIVITY_LOGGINGQUEUE_PC = "pc_log" ;
    public static final String ACTIVITY_LOGGINGQUEUE_OA = "oa_log" ;
    public static final String ACTIVITY_LOGGINGQUEUE_TC = "tc_log" ;
    

    /**
     * Gets the pr info activity data dto.
     *
     * @return the pr info activity data dto
     */
    public ActivityDataDTO getPrInfoActivityDataDTO() {
	return prInfoActivityDataDTO;
    }

    /**
     * Sets the pr info activity data dto.
     *
     * @param prInfoActivityDataDTO the new pr info activity data dto
     */
    public void setPrInfoActivityDataDTO(ActivityDataDTO prInfoActivityDataDTO) {
	this.prInfoActivityDataDTO = prInfoActivityDataDTO;
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    public Long getId() {
	return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
	this.id = id;
    }

    /**
     * Gets the activity mode.
     *
     * @return the activity mode
     */
    public String getActivityMode() {
	return activityMode;
    }

    /**
     * Sets the activity mode.
     *
     * @param activityMode the new activity mode
     */
    public void setActivityMode(String activityMode) {
	this.activityMode = activityMode;
    }

    /**
     * Gets the activity name.
     *
     * @return the activity name
     */
    public String getActivityName() {
	return activityName;
    }

    /**
     * Sets the activity name.
     *
     * @param activityName the new activity name
     */
    public void setActivityName(String activityName) {
	this.activityName = activityName;
    }

    /**
     * Gets the activity stage.
     *
     * @return the activity stage
     */
    public String getActivityStage() {
	return activityStage;
    }

    /**
     * Sets the activity stage.
     *
     * @param activityStage the new activity stage
     */
    public void setActivityStage(String activityStage) {
	this.activityStage = activityStage;
    }


    /**
     * Gets the activity status.
     *
     * @return the activity status
     */
    public String getActivityStatus() {
	return activityStatus;
    }

    /**
     * Sets the activity status.
     *
     * @param activityStatus the new activity status
     */
    public void setActivityStatus(String activityStatus) {
	this.activityStatus = activityStatus;
    }

    /**
     * Gets the info user role.
     *
     * @return the info user role
     */
    public String getInfoUserRole() {
	return infoUserRole;
    }

    /**
     * Sets the info user role.
     *
     * @param infoUserRole the new info user role
     */
    public void setInfoUserRole(String infoUserRole) {
	this.infoUserRole = infoUserRole;
    }


    /**
     * Gets the locked by.
     *
     * @return the locked by
     */
    public String getLockedBy() {
	return lockedBy;
    }

    /**
     * Sets the locked by.
     *
     * @param lockedBy the new locked by
     */
    public void setLockedBy(String lockedBy) {
	this.lockedBy = lockedBy;
    }

    /**
     * Gets the user id.
     *
     * @return the user id
     */
    public String getUserID() {
	return userID;
    }

    /**
     * Sets the user id.
     *
     * @param userID the new user id
     */
    public void setUserID(String userID) {
	this.userID = userID;
    }

    /**
     * Gets the user role.
     *
     * @return the user role
     */
    public String getUserRole() {
	return userRole;
    }

    /**
     * Sets the user role.
     *
     * @param userRole the new user role
     */
    public void setUserRole(String userRole) {
	this.userRole = userRole;
    }

    /**
     * Gets the activity type.
     *
     * @return the activity type
     */
    public String getActivityType() {
	return activityType;
    }

    /**
     * Sets the activity type.
     *
     * @param activityType the new activity type
     */
    public void setActivityType(String activityType) {
	this.activityType = activityType;
    }

    /**
     * Gets the activity code.
     *
     * @return the activity code
     */
    public String getActivityCode() {
	return activityCode;
    }

    /**
     * Sets the activity code.
     *
     * @param activityCode the new activity code
     */
    public void setActivityCode(String activityCode) {
	this.activityCode = activityCode;
    }

    /**
     * Gets the display info user role.
     *
     * @return the display info user role
     */
    public String getDisplayInfoUserRole() {
	return displayInfoUserRole;
    }

    /**
     * Sets the display info user role.
     *
     * @param displayInfoUserRole the new display info user role
     */
    public void setDisplayInfoUserRole(String displayInfoUserRole) {
	this.displayInfoUserRole = displayInfoUserRole;
    }

    /**
     * Gets the display user role.
     *
     * @return the display user role
     */
    public String getDisplayUserRole() {
	return displayUserRole;
    }

    /**
     * Sets the display user role.
     *
     * @param displayUserRole the new display user role
     */
    public void setDisplayUserRole(String displayUserRole) {
	this.displayUserRole = displayUserRole;
    }

    public static final String STATUS_MOVED_TO_RISO = "MOVED_TO_RISO";
    /*
     * constant added for acl by pass - workitem ID - 105197
     */
    public static final String ACL_BY_PASS_SERVICE_NOW = "gncc_impl_sn_bypass";


}
