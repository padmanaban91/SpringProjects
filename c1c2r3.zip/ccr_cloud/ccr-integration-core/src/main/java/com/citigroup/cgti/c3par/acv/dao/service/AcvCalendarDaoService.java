package com.citigroup.cgti.c3par.acv.dao.service;

import java.util.List;
import java.util.Map;

import com.citi.cgti.c3par.acv.domain.AcvCalendarDTO;
import com.citigroup.cgti.c3par.Exception.ApplicationException;

/**
 * @author ky38518
 * 
 */
public interface AcvCalendarDaoService {

    public Map<String, Integer> getMonthlyAcvConCntDetails(AcvCalendarDTO acvCalendarDto) throws ApplicationException;

    public List<AcvCalendarDTO> getAcvConnectionsMonthlyDetails(AcvCalendarDTO acvCalendarDto)
            throws ApplicationException;

    public List<AcvCalendarDTO> getAcvConnectionsyearlyDetails(AcvCalendarDTO acvCalendarDto)
            throws ApplicationException;

    public List<String> getAcvYearList() throws ApplicationException;

    public Map<String, String> getAcvInstanceId(Long tiRequestId, String ssoId) throws Exception;

    public boolean isUserEligibleForACV(String ssoId) throws Exception;

    public int updateAuditDetails(String ssoId, long tiRequestId) throws Exception;

    public String getRoleNameForUser(String ssoId) throws Exception;

    public String getCcrEntitilementCMPProductURL() throws ApplicationException;

    public boolean isACVScheduled(long processId);

    public boolean isConnectionActive(long processId);

}
