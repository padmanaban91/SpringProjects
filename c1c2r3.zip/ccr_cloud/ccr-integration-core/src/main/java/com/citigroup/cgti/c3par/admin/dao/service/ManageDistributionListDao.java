package com.citigroup.cgti.c3par.admin.dao.service;

import java.util.List;

import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;

/**
 * @author ac81662
 *
 */
public interface ManageDistributionListDao {

    /**
     * @param citiContact
     * @return
     */
    public Long addDL(CitiContact citiContact) throws Exception;

    /**
     * @return
     * @throws Exception
     */
    public List<CitiContact> getManageDLList() throws Exception;

    /**
     * @param citiContact
     * @return
     */
    public boolean saveDL(CitiContact citiContact) throws Exception;

    /**
     * @param citiContact
     * @return
     */
    public boolean deleteDL(CitiContact citiContact) throws Exception;

}
