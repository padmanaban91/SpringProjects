package com.citigroup.cgti.c3par.admin.dao.service.impl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.admin.dao.service.FirewallPolicyUpdateDaoService;
import com.citigroup.cgti.c3par.common.domain.ApplicationInstance;
import com.citigroup.cgti.c3par.common.domain.FirewallLocation;
import com.citigroup.cgti.c3par.fw.domain.FireWallPolicyGroup;
import com.citigroup.cgti.c3par.fw.domain.FirewallPolicy;
import com.citigroup.cgti.c3par.fw.domain.FirewallRegion;

/**
 * 
 *
 * @author ac81662
 */

/* Dao Service Class for Manage Policy functionality */
@Repository
@Transactional
public class FirewallPolicyUpdateDaoServiceImpl implements FirewallPolicyUpdateDaoService {

    private static final Logger log = Logger.getLogger(FirewallPolicyUpdateDaoServiceImpl.class.getName());

    @Autowired
    private SessionFactory sessionFactory;

    @Autowired
    @Qualifier("jdbcTemplate_ccr")
    private JdbcTemplate jdbcTemplate;

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * Search Policy Dao method
     * @param searchPolicyName
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
	@Override
    public List<FirewallPolicy> getPolicyList(String searchPolicyName) throws Exception {
        log.info("Dao method getPolicyList starts");
        Session session = sessionFactory.getCurrentSession();
        List<FirewallPolicy> resultList = null;
        try {
            Query query = session.createQuery(
                    "FROM FirewallPolicy where upper(name) like :policyName order by id desc");
            query.setParameter("policyName", "%" + searchPolicyName.toUpperCase() + "%");
            resultList = (List<FirewallPolicy>) query.list();
        } catch (Exception e) {
            log.error("Exception occurred while getting thePolicy List : " + e.toString());
            log.error(e, e);
            throw new ApplicationException("Exception has occurred :: getPolicyList() ", e);
        }
        log.info("Dao method getPolicyList ends");
        return resultList;
    }

    /* Dao method to get Firewall Region Object for a Firewall Region name */
    @Override
    public FirewallRegion getFirewallRegion(String mgmtRegion) throws Exception {
        log.info("Dao method getFirewallRegion starts");
        Session session = sessionFactory.getCurrentSession();
        List<FirewallRegion> resultList = null;
        FirewallRegion firewallRegion = new FirewallRegion();
        try {
            Query query = session.createQuery("FROM FirewallRegion where region like :regionName");
            query.setParameter("regionName", mgmtRegion);
            resultList = query.list();
            if (resultList != null) {
                firewallRegion = resultList.get(0);
            }
        } catch (Exception e) {
            log.error("Exception occurred while getting getFirewallRegion : " + e.toString());
            log.error(e, e);
            throw new ApplicationException("Exception has occurred :: getFirewallRegion() ", e);
        }
        log.info("Dao method getFirewallRegion ends");
        return firewallRegion;
    }

    /*
     * Dao method to get Firewall Policy Group Object for a Firewall Policy
     * Group name
     */
    @Override
    public FireWallPolicyGroup getFireWallPolicyGroup(String group) throws Exception {
        log.info("Dao method getFireWallPolicyGroup starts");
        Session session = sessionFactory.getCurrentSession();
        List<FireWallPolicyGroup> resultList = null;
        FireWallPolicyGroup fireWallPolicyGroup = new FireWallPolicyGroup();
        try {
            Query query = session.createQuery("FROM FireWallPolicyGroup where name like :groupName and active='Y'");
            query.setParameter("groupName", group);
            resultList = query.list();
            if (resultList != null) {
                fireWallPolicyGroup = resultList.get(0);
            }
        } catch (Exception e) {
            log.error("Exception occurred while getting getFireWallPolicyGroup : " + e.toString());
            log.error(e, e);
            throw new ApplicationException("Exception has occurred :: getFireWallPolicyGroup() ", e);
        }
        log.info("Dao method getFireWallPolicyGroup ends");
        return fireWallPolicyGroup;
    }

    /* Dao method to save the policy */
    @Override
    public Long savePolicy(FirewallPolicy firewallPolicy) throws Exception {
        log.info("Dao method savePolicy starts");
        Session session = sessionFactory.getCurrentSession();
        Long policyId = 0L;
        try {
            policyId = (Long) session.save(firewallPolicy);
        } catch (Exception e) {
            log.error("Exception occurred while savePolicy : " + e.toString());
            log.error(e, e);
            throw new ApplicationException("Exception has occurred :: savePolicy() ", e);
        }
        log.info("Dao method savePolicy ends");
        return policyId;
    }

    /* Get List of Firewall Locations for Dropdown */
    @Override
    public List<String> getFwLocationList() throws Exception {
        log.info("Dao method getFwLocationList starts");
        Session session = sessionFactory.getCurrentSession();
        List<FirewallLocation> firewallLocationList = new ArrayList<FirewallLocation>();
        List<String> resultList = new ArrayList<String>();
        Set<String> resultSet = new HashSet<String>();
        try {
            Query query = session.createQuery("FROM FirewallLocation");
            firewallLocationList = query.list();
            if (firewallLocationList != null && firewallLocationList.size() > 0) {
                for (FirewallLocation firewallLocation : firewallLocationList) {
                    resultSet.add(firewallLocation.getFwLocation());
                }
                resultList.addAll(resultSet);
                Collections.sort(resultList);
            }
        } catch (Exception e) {
            log.error("Exception occurred while getFwLocationList : " + e.toString());
            log.error(e, e);
            throw new ApplicationException("Exception has occurred :: getFwLocationList() ", e);
        }
        log.info("Dao method getFwLocationList ends");
        return resultList;
    }

    /* Get List of Firewall region for Dropdown */
    @Override
    public List<String> getMgmtRegionList() throws Exception {
        log.info("Dao method getMgmtRegionList starts");
        Session session = sessionFactory.getCurrentSession();
        List<FirewallRegion> firewallRegionList = new ArrayList<FirewallRegion>();
        List<String> resultList = new ArrayList<String>();
        Set<String> resultSet = new HashSet<String>();
        try {
            Query query = session.createQuery("FROM FirewallRegion");
            firewallRegionList = query.list();
            if (firewallRegionList != null && firewallRegionList.size() > 0) {
                for (FirewallRegion firewallRegion : firewallRegionList) {
                    resultSet.add(firewallRegion.getRegion());
                }
                resultList.addAll(resultSet);
                Collections.sort(resultList);
            }
        } catch (Exception e) {
            log.error("Exception occurred while getMgmtRegionList : " + e.toString());
            log.error(e, e);
            throw new ApplicationException("Exception has occurred :: getMgmtRegionList() ", e);
        }
        log.info("Dao method getMgmtRegionList ends");
        return resultList;
    }

    /* Get List of Policy Group for Dropdown */
    @Override
    public List<String> getGroupList() throws Exception {
        log.info("Dao method getGroupList starts");
        Session session = sessionFactory.getCurrentSession();
        List<FireWallPolicyGroup> fireWallPolicyGroupList = new ArrayList<FireWallPolicyGroup>();
        List<String> resultList = new ArrayList<String>();
        Set<String> resultSet = new HashSet<String>();
        try {
            Query query = session.createQuery("FROM FireWallPolicyGroup where active='Y'");
            fireWallPolicyGroupList = query.list();
            if (fireWallPolicyGroupList != null && fireWallPolicyGroupList.size() > 0) {
                for (FireWallPolicyGroup fireWallPolicyGroup : fireWallPolicyGroupList) {
                    resultSet.add(fireWallPolicyGroup.getName());
                }
                resultList.addAll(resultSet);
                Collections.sort(resultList);
            }
        } catch (Exception e) {
            log.error("Exception occurred while getGroupList : " + e.toString());
            log.error(e, e);
            throw new ApplicationException("Exception has occurred :: getGroupList() ", e);
        }
        log.info("Dao method getGroupList ends");
        return resultList;
    }

    /* Get List of Application instances for Dropdown */
    @Override
    public List<String> getApplicationInstanceList() throws Exception {
        log.info("Dao method getApplicationInstanceList starts");
        Session session = sessionFactory.getCurrentSession();
        List<ApplicationInstance> applicationInstanceList = new ArrayList<ApplicationInstance>();
        List<String> resultList = new ArrayList<String>();
        Set<String> resultSet = new HashSet<String>();
        try {
            Query query = session.createQuery("FROM ApplicationInstance");
            applicationInstanceList = query.list();
            if (applicationInstanceList != null && applicationInstanceList.size() > 0) {
                for (ApplicationInstance applicationInstance : applicationInstanceList) {
                    resultSet.add(applicationInstance.getName());
                }
                resultList.addAll(resultSet);
                Collections.sort(resultList);
            }
        } catch (Exception e) {
            log.error("Exception occurred while getApplicationInstanceList : " + e.toString());
            log.error(e, e);
            throw new ApplicationException("Exception has occurred :: getApplicationInstanceList() ", e);
        }
        log.info("Dao method getApplicationInstanceList ends");
        return resultList;
    }

    /*
     * Dao method to get ApplicationInstance Object for a ApplicationInstance
     * name
     */
    @Override
    public ApplicationInstance getApplicationInstance(String applicationInstanceName) throws Exception {
        log.info("Dao method getApplicationInstance starts");
        Session session = sessionFactory.getCurrentSession();
        List<ApplicationInstance> resultList = null;
        ApplicationInstance applicationInstance = new ApplicationInstance();
        try {
            Query query = session.createQuery("FROM ApplicationInstance where name like :applicationInstanceName");
            query.setParameter("applicationInstanceName", applicationInstanceName);
            resultList = query.list();

            if (resultList != null) {
                applicationInstance = resultList.get(0);
            }
        } catch (Exception e) {
            log.error("Exception occurred while getApplicationInstance : " + e.toString());
            log.error(e, e);
            throw new ApplicationException("Exception has occurred :: getApplicationInstance() ", e);
        }
        log.info("Dao method getApplicationInstance ends");
        return applicationInstance;
    }

    /* Dao method to get FirewallLocation Object for a FirewallLocation name */
    @Override
    public FirewallLocation getFirewallLocation(String fwLocation) throws Exception {
        log.info("Dao method getFirewallLocation starts");
        Session session = sessionFactory.getCurrentSession();
        List<FirewallLocation> resultList = null;
        FirewallLocation firewallLocation = new FirewallLocation();
        try {
            Query query = session.createQuery("FROM FirewallLocation where fwLocation like :fwLocationName");
            query.setParameter("fwLocationName", fwLocation);
            resultList = query.list();

            if (resultList != null) {
                firewallLocation = resultList.get(0);
            }
        } catch (Exception e) {
            log.error("Exception occurred while getFirewallLocation : " + e.toString());
            log.error(e, e);
            throw new ApplicationException("Exception has occurred :: getFirewallLocation() ", e);
        }
        log.info("Dao method getFirewallLocation ends");
        return firewallLocation;
    }

    /**
     * Dao method to update Firewall Policy Record
     * @param firewallPolicy
     * @return
     */
    @Override
	public boolean updateFirewallPolicy(final FirewallPolicy firewallPolicy) {
		log.info("Dao method updateFirewallPolicy starts");
		boolean success = true;
		try {
			String updatePolicyQuery = "update c3par.con_fw_policy SET POLICY_NAME = ?, FW_TYPE= ?, MGMT_REGION_ID=?, UPDATED_DATE=?,"
					+ " IS_ZONED=?, GROUP_ID=?, DELETE_FLAG=?, FW_LOCATION_ID=?, APPLICATION_INSTANCE_ID=?, COMMENTS=? WHERE ID = ?";
			jdbcTemplate.update(updatePolicyQuery, new PreparedStatementSetter() {
				public void setValues(PreparedStatement ps) throws SQLException {
					ps.setString(1, firewallPolicy.getName());
					ps.setString(2, firewallPolicy.getFwType());
					if (firewallPolicy.getFirewallRegion().getId() != 0L) {
						ps.setLong(3, firewallPolicy.getFirewallRegion().getId());
					} else {
						ps.setNull(3, java.sql.Types.NULL);
					}
					ps.setTimestamp(4, new java.sql.Timestamp(firewallPolicy.getUpdated_date().getTime()));
					ps.setString(5, firewallPolicy.getIsZoned());
					if (firewallPolicy.getFireWallPolicyGroup().getId() != 0L) {
						ps.setLong(6, firewallPolicy.getFireWallPolicyGroup().getId());
					} else {
						ps.setNull(6, java.sql.Types.NULL);
					}
					ps.setString(7, firewallPolicy.getDeleteFlag());
					if (firewallPolicy.getFirewallLocation().getId() != 0L) {
						ps.setLong(8, firewallPolicy.getFirewallLocation().getId());
					} else {
						ps.setNull(8, java.sql.Types.NULL);
					}
					if (firewallPolicy.getApplicationInstance().getId() != 0L) {
						ps.setLong(9, firewallPolicy.getApplicationInstance().getId());
					} else {
						ps.setNull(9, java.sql.Types.NULL);
					}
					ps.setString(10, firewallPolicy.getComments());
					ps.setLong(11, firewallPolicy.getId());
				}
			});

		} catch (Exception e) {
			success = false;
			log.error("Exception occurred while updateFirewallPolicy : " + e.toString());
			log.error(e, e);
			throw new ApplicationException("Exception has occurred :: updateFirewallPolicy() ", e);
		}
		log.info("Dao method updateFirewallPolicy ends");
		return success;
	}
}
