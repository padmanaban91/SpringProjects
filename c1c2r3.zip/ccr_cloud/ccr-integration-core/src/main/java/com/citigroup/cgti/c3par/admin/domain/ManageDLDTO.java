package com.citigroup.cgti.c3par.admin.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author ac81662
 *
 */
public class ManageDLDTO implements Serializable {
    
    private static final long serialVersionUID = 1L;
    private String ssoId;
    private String displayName;
    private String emailAddress;
    private List<ManageDLDTO> manageDLDTOList = new ArrayList<ManageDLDTO>();
    private boolean isSelected;

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public List<ManageDLDTO> getManageDLDTOList() {
        return manageDLDTOList;
    }

    public void setManageDLDTOList(List<ManageDLDTO> manageDLDTOList) {
        this.manageDLDTOList = manageDLDTOList;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean isSelected) {
        this.isSelected = isSelected;
    }

    public String getSsoId() {
        return ssoId;
    }

    public void setSsoId(String ssoId) {
        this.ssoId = ssoId;
    }

}
