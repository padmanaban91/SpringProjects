package com.citigroup.cgti.c3par.common.domain;

import com.citigroup.cgti.c3par.domain.Base;


/**
 * The Class FirewallLocation.
 */
public class FirewallLocation extends Base {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/** The fw location. */
    private String fwLocation;



    /**
     * Gets the fw location.
     *
     * @return the fw location
     */
    public String getFwLocation() {
	return fwLocation;
    }

    /**
     * Sets the fw location.
     *
     * @param fwLocation the new fw location
     */
    public void setFwLocation(String fwLocation) {
	this.fwLocation = fwLocation;
    }




}
