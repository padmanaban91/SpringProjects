package com.citigroup.cgti.c3par.admin.domain;

import java.io.Serializable;
import java.util.List;

import com.citigroup.cgti.c3par.common.domain.TITaskType;

public class MigrateBPMProcess implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 154865L;
	private List<TITaskType> activityNameList;
	private String selectedActivityName;

	public List<TITaskType> getActivityNameList() {
		return activityNameList;
	}

	public void setActivityNameList(List<TITaskType> activityNameList) {
		this.activityNameList = activityNameList;
	}

	public String getSelectedActivityName() {
		return selectedActivityName;
	}

	public void setSelectedActivityName(String selectedActivityName) {
		this.selectedActivityName = selectedActivityName;
	}

}
