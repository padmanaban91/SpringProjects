/*
 * Created on Aug 4, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.citigroup.cgti.c3par.Exception;


/**
 * The Class ApplicationException.
 *
 * @author dr97938
 * 
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ApplicationException extends C3PARException {

    /**
     * Instantiates a new application exception.
     */
    public ApplicationException(){
	super();
    }

    /**
     * Instantiates a new application exception.
     *
     * @param message the message
     */
    public ApplicationException(String message){
	super(message);
    }


    public ApplicationException (String errMsg,Throwable xe){
    	super(errMsg,xe);
    }


}
