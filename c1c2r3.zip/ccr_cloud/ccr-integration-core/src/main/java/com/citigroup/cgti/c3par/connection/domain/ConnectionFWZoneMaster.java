package com.citigroup.cgti.c3par.connection.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.citigroup.cgti.c3par.performer.dao.PerformerDO;
import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;



/**
 * The Class ConnectionFWZoneMaster.
 */
public class ConnectionFWZoneMaster extends PerformerPagerDO {

    /** The firewall policy master. */
    private ConnectionFWPolicyMaster firewallPolicyMaster;

    /** The zone_name. */
    private String zone_name;

    /** The zone_type. */
    private String zone_type;

    /**
     * Instantiates a new connection fw zone master.
     */
    public ConnectionFWZoneMaster() {
	//		 ---------------------
	setTableName(PerformerTypes.CON_FW_ZONE_MASTER_TABLE);
	setSequenceName(PerformerTypes.CON_FW_ZONE_MASTER_SEQ);
	// ---------------------
	addToDBMapping("zone_name", "zone_name",1);
	addToDBMapping("zone_type", "zone_type",2);
	// ----------------------
	addToNonPersistanceList("firewallPolicyMaster");
	addToParentsMap(
		"com.citigroup.cgti.c3par.connection.domain.ConnectionFWPolicyMaster",
	"FW_POLICY_ID");

    }



    /**
     * Gets the firewall policy master.
     *
     * @return the firewall policy master
     */
    public ConnectionFWPolicyMaster getFirewallPolicyMaster() {
	return firewallPolicyMaster;
    }



    /**
     * Sets the firewall policy master.
     *
     * @param firewallPolicyMaster the new firewall policy master
     */
    public void setFirewallPolicyMaster(
	    ConnectionFWPolicyMaster firewallPolicyMaster) {
	this.firewallPolicyMaster = firewallPolicyMaster;
    }



    /**
     * Gets the zone_name.
     *
     * @return the zone_name
     */
    public String getZone_name() {
	return zone_name;
    }


    /**
     * Sets the zone_name.
     *
     * @param zoneName the new zone_name
     */
    public void setZone_name(String zoneName) {
	zone_name = zoneName;
    }


    /**
     * Gets the zone_type.
     *
     * @return the zone_type
     */
    public String getZone_type() {
	return zone_type;
    }


    /**
     * Sets the zone_type.
     *
     * @param zoneType the new zone_type
     */
    public void setZone_type(String zoneType) {
	zone_type = zoneType;
    }



    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
	return "ConnectionFWZoneMaster [firewallPolicyMaster="
	+ firewallPolicyMaster + ", zone_name=" + zone_name
	+ ", zone_type=" + zone_type + "]";
    }



}
