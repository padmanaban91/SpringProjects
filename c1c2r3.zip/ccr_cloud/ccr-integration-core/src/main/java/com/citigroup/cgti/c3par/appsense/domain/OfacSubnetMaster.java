package com.citigroup.cgti.c3par.appsense.domain;


import java.io.Serializable;
import java.util.Date;

import com.citigroup.cgti.c3par.domain.Base;


public class OfacSubnetMaster extends Base implements Serializable  {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5645783L;
	/** The id. */
    private Long id;
    
   	/** The ip address. */
    private String ipAddress;
    
    /** The start ip address. */
    private String startIPAddress;
    
    /** The end ip address. */
    private String endIPAddress;
    
    /** The subnet. */
    private String subnet;                         

    /** The no of host. */
    private Long noOfHost;                     

    /** The broad cast address. */
    private String broadCastAddress;
    
    /** The connection is Active. */
    private String isActive;
    
    /** The created by user. */
    private String createdBy;
    
    /** The updated by user. */
    private String updatedBy;
    
    private Date created_date;
    
    private Date updated_date;
    

	public Date getUpdated_date() {
		return updated_date;
	}

	public void setUpdated_date(Date updated_date) {
		this.updated_date = updated_date;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getStartIPAddress() {
		return startIPAddress;
	}

	public void setStartIPAddress(String startIPAddress) {
		this.startIPAddress = startIPAddress;
	}

	public String getEndIPAddress() {
		return endIPAddress;
	}

	public void setEndIPAddress(String endIPAddress) {
		this.endIPAddress = endIPAddress;
	}

	public String getSubnet() {
		return subnet;
	}

	public void setSubnet(String subnet) {
		this.subnet = subnet;
	}

	public Long getNoOfHost() {
		return noOfHost;
	}

	public void setNoOfHost(Long noOfHost) {
		this.noOfHost = noOfHost;
	}

	public String getBroadCastAddress() {
		return broadCastAddress;
	}

	public void setBroadCastAddress(String broadCastAddress) {
		this.broadCastAddress = broadCastAddress;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getCreated_date() {
		return created_date;
	}

	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

   
}
