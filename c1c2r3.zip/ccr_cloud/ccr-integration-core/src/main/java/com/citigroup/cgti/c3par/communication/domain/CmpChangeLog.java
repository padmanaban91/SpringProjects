package com.citigroup.cgti.c3par.communication.domain;

import java.io.Serializable;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.transform.stream.StreamSource;

import com.citigroup.cgti.c3par.domain.Base;

/**
 * @author ky38518
 * 
 */

public class CmpChangeLog extends Base implements Serializable {
    private Long cmpRequestId;
    private String fieldName;
    private String originalValue;
    private String newValue;
    private Date updateDate;
    private String updatedUser;
    private String action;
    private String oldValueRef;
    private String newVlaueRef;

    /**
     * @return the cmpRequestId
     */
    public Long getCmpRequestId() {
        return cmpRequestId;
    }

    /**
     * @param cmpRequestId
     *            the cmpRequestId to set
     */
    public void setCmpRequestId(Long cmpRequestId) {
        this.cmpRequestId = cmpRequestId;
    }

    /**
     * @return the fieldName
     */
    public String getFieldName() {
        return fieldName;
    }

    /**
     * @param fieldName
     *            the fieldName to set
     */
    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    /**
     * @return the originalValue
     */
    public String getOriginalValue() {
        return originalValue;
    }

    /**
     * @param originalValue
     *            the originalValue to set
     */
    public void setOriginalValue(String originalValue) {
        this.originalValue = originalValue;
    }

    /**
     * @return the newValue
     */
    public String getNewValue() {
        return newValue;
    }

    /**
     * @param newValue
     *            the newValue to set
     */
    public void setNewValue(String newValue) {
        this.newValue = newValue;
    }

    /**
     * @return the updateDate
     */
    public Date getUpdateDate() {
        return updateDate;
    }

    /**
     * @param updateDate
     *            the updateDate to set
     */
    public void setUpdateDate(Date updateDate) {
        this.updateDate = updateDate;
    }

    /**
     * @return the updatedUser
     */
    public String getUpdatedUser() {
        return updatedUser;
    }

    /**
     * @param updatedUser
     *            the updatedUser to set
     */
    public void setUpdatedUser(String updatedUser) {
        this.updatedUser = updatedUser;
    }

    /**
     * @return the action
     */
    public String getAction() {
        return action;
    }

    /**
     * @param action
     *            the action to set
     */
    public void setAction(String action) {
        this.action = action;
    }

    /**
     * @return the oldValueRef
     */
    public String getOldValueRef() {
        return oldValueRef;
    }

    /**
     * @param oldValueRef
     *            the oldValueRef to set
     */
    public void setOldValueRef(String oldValueRef) {
        this.oldValueRef = oldValueRef;
    }

    /**
     * @return the newVlaueRef
     */
    public String getNewVlaueRef() {
        return newVlaueRef;
    }

    /**
     * @param newVlaueRef
     *            the newVlaueRef to set
     */
    public void setNewVlaueRef(String newVlaueRef) {
        this.newVlaueRef = newVlaueRef;
    }

}
