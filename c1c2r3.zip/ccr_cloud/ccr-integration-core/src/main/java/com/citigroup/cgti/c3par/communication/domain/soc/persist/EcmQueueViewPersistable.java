package com.citigroup.cgti.c3par.communication.domain.soc.persist;

import java.util.List;

import com.citigroup.cgti.c3par.communication.domain.EcmQueue;
import com.citigroup.cgti.c3par.communication.domain.EcmQueueUsers;
import com.citigroup.cgti.c3par.communication.domain.EcmQueueViewProcess;
import com.citigroup.cgti.c3par.persistance.Persistable;


public interface EcmQueueViewPersistable extends Persistable {
  
	public List<EcmQueue> selectQueueDetails(EcmQueueViewProcess ecmQueueViewProcess); 
	
	public List<EcmQueueUsers> ecmUserRoleList(long ecmqueueId) throws Exception;

	public boolean mapEcmUsertoSector(Long sector, String ecmUser,String userId);

	public List<Long> selectedEcmSector(long ecmqueueId) throws Exception;
	
	public void updateEcmQueueViewDetails(EcmQueueViewProcess ecmqueueViewProcess);
	
	
}
 
