package com.citigroup.cgti.c3par.communication.domain;

/**
 * @author bv49858
 * 
 */
public interface ECMConstants {

	public static final String GENERIC_LOOKUP_PROCESS_PRIORITY = "Process Priority";
	public static final String GENERIC_LOOKUP_REGION = "Region";
	public static final String GENERIC_LOOKUP_COUNTRY = "Country";

	public static final String GENERIC_LOOKUP_TYPE_OF_CONNECTIVITY_INVOLVED = "TYPE_OF_CONNECTIVITY_INVOLVED";
	public static final String CMP_REQUEST_TYPE = "CMP_REQUEST_TYPE";
	public static final String GENERIC_LOOKUP_AFFECTED_BUSINESS = "AFFECTED_BUSINESS";
	public static final String GENERIC_LOOKUP_GROUP_SECTOR_MAPPING = "GROUP_SECTOR_MAPPING";
	public static final String EMAIL_TEMPLATE_NAME = "COMMUNICATION_EMAIL_TEMPLATE_NAME";
	public static final String SLO_DAYS = "SLO_Days";
	public static final String GENERIC_LOOKUP_REQUEST_URGENCY = "REQUEST_URGENCY";
	public static final String STATUS_COMPLETED = "COMPLETED";
	public static final String IS_NEW = "NEW";
	public static final String STATUS_STARTED = "STARTED";
	public static final String CMP_REQUEST_CREATED = "CMP Request Created";
	public static final String CMP_REQUEST_ASSIGNED = "ECM Agent Assigned";
	public static final String CMP_REQUEST_REASSIGNED = "ECM Agent Reassigned";
	public static final String CMP_REQUEST_AWAITING = "Awaiting ECM Input";
	public static final String RESPONSE_ADDITIONAL_INFO = "Additional Information Received";
	public static final String AWAITING_PAF_FAF_VERIFICATION = "Awaiting PAF/FAF Verification";
	public static final String RESPONSE_PAF_FAF_VERIFICATION = "PAF/FAF Response Received";
	public static final String CMP_REQUEST_CREATION = "cmp_request_create";
	public static final String TRANSFER_AGENT_TASK_CODE = "cmp_reassign_user";
	public static final String CANCEL_TASK_CODE = "cmp_cancel_request";
	public static final String CMP_USER_CREATION = "system";
	public static final String ASSIGN_AGENT_TASK_CODE = "cmp_assign_user";
	public static final String ECM = "ECM";
	public static final String EMAIL = "EMAIL";
	public static final String SERVICE_DESK="SD";
	public static final String[] SEC_ACL_APPSENSE={"AppSense","Security Access Control List"};

	public static final String APPROVED = "Approved";
	public static final String ECM_TIMER = "ECM TIMER";
	public static final String BUSINESS_TIMER = "BUSINESS TIMER";
	public static final String GENERIC_LOOKUP_SLO_DAYS = "SLO_DAYS_REQUEST_URGENCY";
	public static final String CMP_STATUS = "CMP_STATUS";
	public static final String ERROR_MSG_SOA = "An error occurred while trying to fetch the details. Please enter valid input or contact helpdesk for assistance.";

	public static final String CMP_ID = "CMP ID";
	public static final String Date_Assigned = "Date Assigned";
	public static final String Current_Status = "Current Status";
	public static final String SLO = "SLO";
	public static final String SLO_Status = "SLO Status";
	public static final String Request_Type = "Request Type";
	public static final String CCR_ID = "CCR ID";
	public static final String Change_ID = "Change ID";
	public static final String Change_Date = "Change Date";
	public static final String Order_By = "Order By";
	public static final String Order_For = "Order For";
	public static final String Date_Active = "Date Active";
	public static final String Region = "Region";
	public static final String SLO_Hours = "SLO Hours";
	public static final String History = "History";
	public static final String Agent_Name = "Agent Name";
	public static final String AgentView = "AgentView";
	public static final String LeadView = "LeadView";
	public static final String TeamView = "TeamView";
	public static final String Assign_To = "Assign To";
	public static final String Assign_All = "Assign All";
	public static final String Assignment_Comments = "Assignment Comments";
	public static final String GENERIC_MD_QUESTIONS = "CMP_MD_APP_QUESTIONS";
	public static final String DIRECTOR = "Director";
	public static final String DIRECTOR_APPROVAL = "DIRECTOR_APPROVAL";
	public static final String REQUESTOR = "Requestor";
	public static final String COORDINATOR = "coordinator";
	public static final String MANAGING_DIRECTOR = "Managing Director";
	public static final String BUSINESS_OWNER = "Business_Owner";
	public static final String SEC_BUSINESS_OWNER = "Sec_Business_Owner";
	public static final String BISO = "BISO";
	public static final String DESIGN_ENGINEER = "design_engineer";
	public static final String CMP_SEARCH_VIEW_ID = "ECM_CMP_SERACH";
	public static final String AWAITING_PAF_FAF_VERIFY = "awaiting_paf_faf_verify";
	public static final String AWAITING_ADDITIONAL_INFO = "awaiting_additional_info";
	public static final String AWAITING_ASSIST_TERM_LOG = "awaiting_assist_term_log";
	public static final String AWAITING_ADDITIONAL_INFO_ASSIGN = "awaiting_additional_info_assign";
	public static final String AWAITING_ADDITIONAL_INFO_ASSIGN_RESP = "awaiting_additional_info_assign_resp";
	public static final String AWAITING_ASSIST_TERM_LOG_RESP = "awaiting_assist_term_log_resp";
	public static final String AWAITING_PAF_FAF_VERIFY_RESP = "awaiting_paf_faf_verify_resp";
	public static final String AWAITING_ADDITIONAL_INFO_RESP = "awaiting_additional_info_resp";
	public static final String AWAITING_ECM_INPUT = "awaiting_ecm_input";
	public static final String ACCESS_FORM_VERIFICATION = "ACCESS_FORM_VERIFICATION";
	public static final String REQ_ON_HOLD = "req_on_hold";
	public static final String CMP_CANCEL_REQUEST = "cmp_cancel_request";
	public static final String CLOSED_ASSITANCE_REQ = "closed_assitance_req";
	public static final String REQ_HOLD_RELEASED = "req_hold_released";
	public static final String AWAITING_PC_PROVIDE_INFO_RESP = "awaiting_pc_pro_inf_resp";
	public static final String AWAITING_PC_PROVIDE_INFO = "awaiting_pc_pro_inf";
	public static final String PC_PROVIDE_INFO = "pro_inf";
	public static final String PC_PROVIDE_INFO_ECM = "pro_inf_ecm";

	public static final String CMPID = "CMP_ID";
	public static final String CCRID = "CCR_ID";
	public static final String VERSION = "VERSION";
	public static final String REQUEST_TYPE = "REQUEST_TYPE";
	public static final String REQUEST_URGENCY = "REQUEST_URGENCY";
	public static final String STATUS = "STATUS";
	public static final String TYPE_OF_CONN_INVOLVED = "TYPE_OF_CONN_INVOLVED";
	public static final String REJECTED = "REJECTED";

	public final String[] PRODUCTS = { "AppSense", "Proxy", "Security Access Control List", "Firewall",
			"IP Registration" };
	public final String[] PRIORITY = { "BUSCRIT", "BAU", "EMER" };
	public final String[] PCPROVIDEINFO = { "Pc Provide Info", "Rejected" };

	public static final String IP = "IP Registration";
	public static final String PROXY = "Proxy";
	public static final String FIREWALL = "Firewall";
	public static final String PAF_FAF_VERIFICATION = "PAF_FAF_VERIFICATION";
	public static final String FAF_FILE_EXTENSION = "_faf.txt";
	public static final String FAF_IP_FILE_EXTENSION = "_faf_ip.txt";
	public static final String PAF_FILE_EXTENSION = "_paf.txt";

	public static final String PORT_RES_TYPE = "Port Template";
	public static final String IP_RES_TYPE = "IP Template";
	public static final String RE_SEND = "RESEND:";
	public static final String SINGLE_NEW_LINE = "\n";
	public static final String DOUBLE_NEW_LINE = "\n\n";
	public static final String DATE_FORMAT_WITH_ZONE = "dd-MM-yy HH:mm:SS Z";

	public static final String ECM_QUEUE_ID = "ECM_QUEUE_ID";
	public static final String ECM_QUEUE_NAME = "ECM_QUEUE_NAME";
	public static final String ECM_LEAD = "ECM Lead";
	public static final String ECM_MANAGER = "ECM Manager";
	public static final String ECM_AGENT = "ECM Agent";
	public static final String CMP_REOPEN = "cmp_reopen";
	public static final String ROLE = "ROLE";
	public static final String SM_USER = "SM_USER";
	public static final String DISPLAY_MODE = "displayMode";
	public static String EDIT = "Edit";
	public static final String FALSE = "false";
	public static final String TRUE = "true";
	public static final String UPDATE = "Update";
	public static final String APPLICATION = "Application";
	public static final String LOAD_CSI_DETAILS = "forward:/loadCSIDetails.act";
	public static final String EDIT_APPLICATION = "/pages/jsp/fw/EditApplication";
	public static final String VIEW_APPLICATIONS_APP = "forward:/viewApplications.act?fromScreen=APP";
	public static final String ID = "id";
	public static int IN_CLAUSE_MAX_RECORD = 999;
	public static final String ICMP = "ICMP";
	public static final String TCP = "TCP";
	public static final String UDP = "UDP";
	public static final String ORDER_ITEM_ID = "ORDER_ITEM_ID";
	public static final String PROCESS_ID = "PROCESS_ID";
	public static final String VERSION_NO = "VERSION_NO";
	public static final String TASK_CODE = "TASK_CODE";
	public static final String BUS_JUSTIFICATION = "BUS_JUSTIFICATION";
	public static final String REQUEST_ID = "REQUEST_ID";
	public static final String USER_ID = "USER_ID";
	public static final String ECM_COMMENTS = "ECM_COMMENTS";
	public static final String CMPC_ID = "CMPC_ID";
	public static final String ADD_INFO = "ADD_INFO";
	public static final String TI_REQUEST_ID = "TI_REQUEST_ID";
	public static final String BUSINESS_JUSTIFICATION = "BUSINESS_JUSTIFICATION";
	public static final String id = "ID";
	public static final String NAME = "NAME";
	public static final String FIRST_NAME = "FIRST_NAME";
	public static final String LAST_NAME = "LAST_NAME";
	public static final String PC_PROVIDE_REMAINDER = "PC_PROVIDE_INFO_REMAINDER";

	public static final String POLICY_ID = "policyId";
	public static final String SRC_NW_ZONE = "srcNwZone";
	public static final String DEST_NW_ZONE = "destNwZone";
	public static final String SRC_ZONE = "srcZone";
	public static final String DEST_ZONE = "destZone";
	public static final String RULE_TYPE = "ruleType";
	
	public static final String RULE_NUMBER="ruleNumber";
    public static final String PROCESSID="processId";
    public static final String IP_START_LONG="ipStartLong";
    public static final String IP_END_LONG="ipEndLong";
    public static final String CONTROL_MESSAGE_ID="controlMessageId";
    public static final String PORT_NUMBER="portNumber";
    public static final String IP_ADDRESS="ipAddress";
    public static final String IP_TYPE="ipType";
    public static final String PROTOCOL="protocol";

	
	public static final String WILD_CARD_ASTERISK = "*";
	public static final String WILD_CARD_PERCENT = "%";
	public static final String EMPTY_STRING = "";
	public static final String PERCENT = "_percent";
	public static final String CMP_GENERAL_INFO = "cmp_general_info";
	public static final String REQ_ASSIGNED_ASSISTANCE_ADDITIONAL_INFO_REMINDER = "REQ_ASSIGNED_ASSISTANCE_ADDITIONAL_INFO_REMINDER";
	public static final String LOAD_GROUP_DETAILS = "/loadGroupDetails.act";
	public static final String UNASSIGN_CMP = "UNASSIGN_CMP";
	public static final String REDIRECT_LEAD_VIEW = "redirect:/leadViewController.act";
	public static final String UN_ASSIGN_CMP = "/unAssignCmp.act";
	public static final String CMP_ID_SEARCH = "WS";
	public static final String INVALID_CMP = "INVALID_CMP";

	public static final String ECM_AGENT_VIEW = "ECM_AGENT";
	public static final String ECM_LEAD_VIEW = "ECM_LEAD";
	public static final String ECM_TEAM_VIEW = "ECM_TEAM";
	public static final String INBOX_VIEW = "INBOX";
	public static final String RISK_REVIEW_VIEW = "RISK_REVIEW";
	public static final String ASC = "asc";
	public static final String DESC = "desc";

	// Team View Constants
	public static final String ORDER_ITEM_ID_HBM_NAME = "orderItemId";
	public static final String AGENT_NAME_HBM_NAME = "agentName";
	public static final String CURRENT_STATUS_HBM_NAME = "currentStatus";
	public static final String TYPE_OF_CONN_INVOLVED_HBM_NAME = "typeofConnectivityInvolved";
	public static final String CHANGE_ID_HBM_NAME = "chgId";
	public static final String CHANGE_DATE_HBM_NAME = "chgDate";
	public static final String ORDER_BY_USER_HBM_NAME = "orderByUser";
	public static final String ORDER_FOR_USER_HBM_NAME = "orderForUser";
	public static final String REQUEST_TYPE_HBM_NAME = "requestType";
	public static final String CCR_ID_HBM_NAME = "ccrId";
	public static final String DATE_FORMAT = "MM/dd/yyyy";

	// CMP Search constants
	public static final String GOC_CODE_HBM_NAME = "gocCode";
	public static final String CMP_ID_HBM_NAME = "cmpId";
	public static final String VERSION_HBM_NAME = "version";
	public static final String CMP_STATUS_HBM_NAME = "status";
	public static final String AVAILABLE_DATE_HBM_NAME = "availableDate";
	public static final String UPDATED_ASSIGNED_DATE_HBM_NAME = "updateAssignedUserDate";
	public static final String DISPLAY_NAME_HBM_NAME = "displayName";
	public static final String FIRST_NAME_HBM_NAME = "firstName";
	public static final String LAST_NAME_HBM_NAME = "lastName";
	public static final String DATE_ASSIGNED_HBM_NAME = "dateAssigned";
	public static final String CCR_ID_WITH_VERSION_NO_HBM_NAME = "ccrIdWithVerNo";
	public static final String IS_MANAGER_COMPLETED_HBM_NAME = "isManagerCompleted";
	public static final String MGR_COMPLETE = "MGRComplete";
	public static final String COMPLETED = "COMPLETED";

	// Lead view Constants
	public static final String REGION_HBM_NAME = "region";
	public static final String REQUEST_URGENCY_HBM_NAME = "requestUrgency";
	public static final String GET_TEAM_QUEUE_LIST = "GETTEAMQUEUELIST";
	public static final String GET_HEADER_FOR_TEAMQUEUE = "GETHEADERFORTEAMQUEUE";
	public static final String TEAMVIEW_ROLE_CONDITION_SEARCH = "TEAMVIEWROLECONDITIONSEARCH";
	public static final String AGENTQUEUE_FILTER_COLUMN = "agentQueueFilterColumn";
	public static final String AGENTQUEUE_FILTER_VALUE = "agentQueueFilterValue";
	public static final String SELECTED_TAB = "AGENT_QUEUE";
	public static final String ECM_LEAD_COMMENT_TO_AGENT = "CCR_ECM_LEAD_COMMENT";
	public static final String REQUEST_TYPE_VALUE_HBM_NAME = "requestTypeValue";
	// Agent View Constants
	public static final String CMP_ASSIGN_USER = "cmp_assign_user";
	public static final String CMP_REASSIGN_USER = "cmp_reassign_user";
	public static final String CHG_APPROVED = "chg_approved";
	public static final String AWAITING_CHG = "awaiting_chg";
	public static final String BUS_JUS = "bus_jus";
	public static final String PRO_INF = "pro_inf";
	public static final String BUS_JUS_ECM_START = "bus_jus_ecm_start";
	public static final String AWAITING_ASSIST_TERM_LOG_NO_ADD_INOFRM_REQ = "awaiting_assist_term_log_no_add_inofrm_req";
	public static final String TEC_ARC = "tec_arc";
	public static final String MAD_RET_APP = "mad_ret_app";
	public static final String TPW_RET_APP = "tpw_ret_app";
	public static final String OTRM_RET_APP = "otrm_ret_app";
	public static final String MAD_APP = "mad_app";
	public static final String OTRM_APP = "otrm_app";
	public static final String ISA_APP = "isa_app";
	public static final String BU_MGR_APP = "bu_mgr_app";
	public static final String IST_APP = "ist_app";
	public static final String TPW_APP = "tpw_app";
	public static final String SE_APP = "se_app";
	public static final String ISO_APP = "iso_app";
	public static final String ACT_EXP = "act_exp";
	public static final String TMP_EXP = "tmp_exp";
	public static final String REC_EXP = "rec_exp";
	public static final String ACV_EXP = "acv_exp";
	public static final String IMPL_EXP = "impl_exp";
	public static final String APP_EXP = "app_exp";
	public static final String INC_EXP = "inc_exp";
	public static final String GNCC_IMP = "gncc_imp";
	public static final String PROXY_IMP = "proxy_imp";
	public static final String APPSENSE_IMP = "appsense_imp";
	public static final String OPE_IMP = "ope_imp";
	public static final String OPE_IPREG_IMP = "ope_ipreg_imp";

	public static final String REQUEST_TYPE_NEW_CONNECTION = "New Connection {Creation of Entirely New CCR ID}";
	public static final String IP_REGISTRATION = "IP Registration";
	public static final String APPSENSE = "AppSense";
	public static final String SEC_ACC_CON_LST = "Security Access Control List";

	public static final String GREEN = "Green";
	public static final String YELLOW = "Yellow";
	public static final String RED = "Red";

	public static final String FILTER_COLUMN = "filterColumn";
	public static final String FILTER_VALUE = "filterValue";
	public static final String CONNECTION_TYPE = "connectionType";
	public static final String STYLE = " style='color: #00bdf2;text-decoration: underline;'>";
	public static final String REQUESTTYPEVAL = "requestTypeVal";
	public static final String TASKNAME = "taskName";

	public static final String AGENT_USER_ID = "agentUserId";
	public static final String FROM_PAGE = "fromPage";
	public static final String EMER_BUSCRIT_QUESTIONNAIRE = "emer_buscrit_questionnaire";
	public static final String EMER_BUSCRIT_QUESTIONNAIRE_RESPONSE = "EMER_BUSCRIT_QUESTIONNAIRE_RESPONSE";
	public static final String CMPSearchView = "CMPSearchView";
	public static final String CMP_Status = "CMP Status";

	public static final String IPREG = "IP Registration";
	public static final String TERMINATION = "Termination {Existing CCR ID: Termination of the entire CCR ID and all rules}";
	public static final String Completed = "Completed";
	public static final String CANCELLED = "Cancelled";
	public static final String INPROGRESS = "In Progress";
	public static final String ASSIST_REQ = "Assistance Request";

	public static final String UPDATED_YEAR = "extract(year from UPDATED_DATE)=?";
	public static final String CLOSED_YEAR = "extract(year from CLOSED_DATE)=?";


    public static final String AWAITING_PC_PRO_INF="awaiting_pc_pro_inf";
    public static final String LOAD_IP_DETAILS = "/loadIpDetails.act";
    public static final String LOAD_BUSINESS_CASE_DETAILS = "/loadBusinessCaseDetails";
    public static final String SSO_ID = "ssoId";
    public static final String ADMIN_SA_UPDATE = "AdminSaUpdate";
    public static final String NEW = "new";
    
    public static final String SUCCESS = "SUCCESS";
    public static final String OVERRIDED = "OVERRIDED";

    public static final String DIRECTOR_APPROVAL_FOR_EMAIL = "Director_Approval";
    public static final String BUSINESS_TESTER = "business_tester";
    public static final String ADDITIONAL_ROLE = "Additional_Role";
    public static final String ECOMM_VIEW_FLAG = "ecommViewFlag";
    public static final String SRC_IP_START_STR = "srcIpStartStr";
    public static final String SRC_IP_END_STR = "srcIpEndStr";
    public static final String DEST_IP_START_STR = "destIpStartStr";
    public static final String DEST_IP_END_STR = "destIpEndStr";
    public static final String PORT_STR = "portStr";
    public static final String PROTOCOL_STR = "protocolStr";
    public static final String SRC_COUNT = "srcCount";
    public static final String DST_COUNT = "dstCount";
   
}
