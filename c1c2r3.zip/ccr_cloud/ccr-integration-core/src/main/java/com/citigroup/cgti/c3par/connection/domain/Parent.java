package com.citigroup.cgti.c3par.connection.domain;

import java.io.Serializable;

import com.citigroup.cgti.c3par.performer.dao.PerformerDO;


/**
 * The Class Parent.
 */
public class Parent extends PerformerDO implements Serializable {

    /** The key1. */
    String key1;

    /** The key2. */
    String key2;

    /** The key3. */
    String key3;

    /** The key4. */
    String key4;

    /** The key5. */
    String key5;

    /** The key6. */
    String key6;

    /** The key7. */
    String key7;

    /** The key8. */
    String key8;

    /** The key9. */
    String key9;

    /** The key10. */
    String key10;

    /**
     * Gets the key1.
     *
     * @return the key1
     */
    public String getKey1() {
	return key1;
    }

    /**
     * Sets the key1.
     *
     * @param key1 the key1 to set
     */
    public void setKey1(String key1) {
	this.key1 = key1;
    }

    /**
     * Gets the key10.
     *
     * @return the key10
     */
    public String getKey10() {
	return key10;
    }

    /**
     * Sets the key10.
     *
     * @param key10 the key10 to set
     */
    public void setKey10(String key10) {
	this.key10 = key10;
    }

    /**
     * Gets the key2.
     *
     * @return the key2
     */
    public String getKey2() {
	return key2;
    }

    /**
     * Sets the key2.
     *
     * @param key2 the key2 to set
     */
    public void setKey2(String key2) {
	this.key2 = key2;
    }

    /**
     * Gets the key3.
     *
     * @return the key3
     */
    public String getKey3() {
	return key3;
    }

    /**
     * Sets the key3.
     *
     * @param key3 the key3 to set
     */
    public void setKey3(String key3) {
	this.key3 = key3;
    }

    /**
     * Gets the key4.
     *
     * @return the key4
     */
    public String getKey4() {
	return key4;
    }

    /**
     * Sets the key4.
     *
     * @param key4 the key4 to set
     */
    public void setKey4(String key4) {
	this.key4 = key4;
    }

    /**
     * Gets the key5.
     *
     * @return the key5
     */
    public String getKey5() {
	return key5;
    }

    /**
     * Sets the key5.
     *
     * @param key5 the key5 to set
     */
    public void setKey5(String key5) {
	this.key5 = key5;
    }

    /**
     * Gets the key6.
     *
     * @return the key6
     */
    public String getKey6() {
	return key6;
    }

    /**
     * Sets the key6.
     *
     * @param key6 the key6 to set
     */
    public void setKey6(String key6) {
	this.key6 = key6;
    }

    /**
     * Gets the key7.
     *
     * @return the key7
     */
    public String getKey7() {
	return key7;
    }

    /**
     * Sets the key7.
     *
     * @param key7 the key7 to set
     */
    public void setKey7(String key7) {
	this.key7 = key7;
    }

    /**
     * Gets the key8.
     *
     * @return the key8
     */
    public String getKey8() {
	return key8;
    }

    /**
     * Sets the key8.
     *
     * @param key8 the key8 to set
     */
    public void setKey8(String key8) {
	this.key8 = key8;
    }

    /**
     * Gets the key9.
     *
     * @return the key9
     */
    public String getKey9() {
	return key9;
    }

    /**
     * Sets the key9.
     *
     * @param key9 the key9 to set
     */
    public void setKey9(String key9) {
	this.key9 = key9;
    }
}
