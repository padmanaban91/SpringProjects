


/** CONFIDENTIAL  AND PROPRIETARY
 * Copyright @ 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is
 * strictly prohibited.
 */

package com.citigroup.cgti.c3par.dao;

import java.io.Serializable;
import java.sql.*;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.model.*;
import com.citigroup.cgti.c3par.dao.lookup.*;
import com.mentisys.model.*;
import com.mentisys.dao.*;
import com.mentisys.dao.query.*;
import com.mentisys.dao.audit.*;


// Reference imports

// Entity name = RelationshipDAO
// Table name = RELATIONSHIP
// Superclass = <none>
// Subclasses = <none>

/**
 * The Class RelationshipDAO.
 */
public class CitiHierMasterDAO
extends DatabaseAccessObject
implements Serializable
{

    public CitiHierMasterDAO(DatabaseSession session) {
		super(session);
		// TODO Auto-generated constructor stub
	}

	/** The Constant TABLE. */
    public static final String	TABLE = "CITI_HIERARCHY_MASTER";

    /** The custom sequence. */
    private String customSequence;

    /** The database sequence. */
    private String databaseSequence;

    /** The log. */
    private static Logger log = Logger.getLogger(CitiHierMasterDAO.class);

    /** The Constant ENTITY_NAME. */
    public static final String	ENTITY_NAME = "CitiHierMaster";

    /** The Constant COLUMN_ID. */
    public static final String	COLUMN_ID = "ID";

    // Column names
    /** The Constant COLUMN_NAME. */
    public static final String	COLUMN_REGION_ID = "REGION_ID";

    /** The Constant COLUMN_PURPOSE. */
    public static final String	COLUMN_SECTOR_ID = "SECTOR_ID";

    /** The Constant COLUMN_CONNECTIVITYEXISTS. */
    public static final String	COLUMN_BU_ID = "BU_ID";
    
    private static String SELECT_STMT = "SELECT "  + COLUMN_ID
    + ", " + COLUMN_BU_ID
    + ", " + COLUMN_REGION_ID
    + ", " + COLUMN_SECTOR_ID
    + " FROM " + CitiHierMasterDAO.TABLE;
    
    private static String SELECT_BY_ID_STMT = CitiHierMasterDAO.SELECT_STMT + " WHERE " + COLUMN_ID + " = ?";
    
	@Override
	protected void buildEntity(ResultSet rs, Entity obj)
			throws DatabaseException {
		CitiHierMasterEntity entity = (CitiHierMasterEntity) obj;
		try
		{
		    // TODO: Figure a better way of dealing with the absence of any attribute
		    dummyExceptionTosser(false);

		    int index = 1;

		    entity.setBuId(getLongFromResultSetIndexed(rs, ++index));
		    entity.setRegionId(getLongFromResultSetIndexed(rs, ++index));
		    entity.setSectorId(getLongFromResultSetIndexed(rs, ++index));
		    
		    //loadReferenceIds(entity);

		    obj.setModified(false);
		}
		catch (DatabaseException e)
		{	
			log.error(e,e);
		    throw new DatabaseException("Cannot build database entity object from result set", e);
		}
		
	}

	@Override
	protected Entity createEntity(ResultSet rs) throws DatabaseException {
		CitiHierMasterEntity entity = null;
		try
		{
		    // get the ID of the entity we're to create, and check if that is already held in the session. Thereby allowing us to
		    // bypass the creation altogether and reuse the one in existence.			
		    Long _id = getLongFromResultSet(rs, COLUMN_ID);
		    entity = (CitiHierMasterEntity) getSession().getObjectFromSession(ENTITY_NAME, _id);
		    if (entity == null)
		    {        
			entity = new CitiHierMasterEntity(_id);
			buildEntity(rs, entity);
			getSession().addObjectToSession(entity, ENTITY_NAME, _id);
		    }
		}
		catch (DatabaseException e)
		{
			log.error(e,e);
		    throw new DatabaseException("Cannot create database entity object from result set", e);
		}
		return entity;
	}
	

	@Override
	protected void loadReferences(Entity obj) throws DatabaseException {
		if (obj.isReferencesLoaded())
		{
		    log.debug("CitiHierMasterDAO.loadReferences(): References for CitiHierMasterEntity [" + obj.getId() + "] already loaded");
		    return;
		}
		log.debug("CitiHierMasterDAO.loadReferences(): Loading references for CitiHierMasterEntity [" + obj.getId() + "].");
		obj.setReferencesLoaded(true);
		try
		{
		CitiHierMasterEntity entity = (CitiHierMasterEntity)obj;
		
		Long businessUnitId = entity.getBuId();
	    if (businessUnitId != null)
	    {
	    	log.debug("bu id" +businessUnitId);
		//			BusinessUnitDAO businessUnitDAO = new BusinessUnitDAO(getSession());
		BusinessUnitDAO businessUnitDAO = getBusinessUnitDAO();
		entity.setBusUnit((BusinessUnitEntity)businessUnitDAO.get(businessUnitId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriBusUnit(entity.getBusUnit());
	    }
	    
	    Long secId = entity.getSectorId();
	    if (secId != null)
	    {
	    	log.debug("secId id" +secId);
		//			BusinessUnitDAO businessUnitDAO = new BusinessUnitDAO(getSession());
		SectorDAO sectorDAO = getSectorDAO();
		entity.setSector((SectorEntity)sectorDAO.get(secId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriSector(entity.getSector());
	    }
	    
	    Long regId = entity.getRegionId();
	    if (regId != null)
	    {
	    	log.debug("regId id" +regId);
		//			BusinessUnitDAO businessUnitDAO = new BusinessUnitDAO(getSession());
		RegionDAO regionDAO = getRegionDAO();
		entity.setRegion((RegionEntity)regionDAO.get(regId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriRegion(entity.getRegion());
	    }
		}
		catch(Exception e)
		{
			log.error(e,e);
		    obj.setReferencesLoaded(false);
		    throw new DatabaseException("Failed to load references for RelationshipEntity [" + obj.getId() + "].", e);
		}
		
	}

	@Override
	protected int updateReferences(PreparedStatement arg0, Entity arg1, int arg2)
			throws DatabaseException, SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	protected String getQuerySelectString() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	 
	 public CitiHierMasterEntity get(Long id, boolean load_refs) throws DatabaseException
	    {
		Long id_to_get = id;
		CitiHierMasterEntity obj = (CitiHierMasterEntity) getSession().getObjectFromSession(ENTITY_NAME, id_to_get);
		log.debug("Getting EntitlementDataEntity with id = " + id_to_get); 
		if(obj != null)
		{
		    log.debug(">>> EntitlementDataEntity >>> already LOADED !!!"); 
		}

		if(obj == null)
		{
		    DatabaseSession session = getSession();
		    Connection connection = null;

		    PreparedStatement st = null;
		    ResultSet rs = null;

		    try
		    {
			connection = session.getConnection();
			log.debug("quer" +SELECT_BY_ID_STMT);
			//				st = session.getPreparedStatement(SELECT_BY_ID_STMT);
			st = connection.prepareStatement(SELECT_BY_ID_STMT);
			setLongToStatement(st, 1, id_to_get);
			rs = st.executeQuery();

			if (rs.next())
			{
			    obj = (CitiHierMasterEntity) createEntity(rs);
			}
		    }
		    catch (SQLException e)
		    {
		    	log.error(e,e);
			throw new DatabaseException("Could not load " + EntitlementDataDAO.ENTITY_NAME + " with id = " + id_to_get, e);
		    }
		    finally
		    {
			closeResultSet(rs);
			closeStatement(st);
			session.releaseConnection();
		    }
		}

		if (obj != null && load_refs)
		{
		    try
		    {
			// Load the associated objects
			loadReferences(obj);
			obj.setModified(false);
		    }
		    catch (DatabaseException e)
		    {
			throw new DatabaseException("Failed to load references of " + EntitlementDataDAO.ENTITY_NAME + " with id = " + id_to_get, e);
		    }
		}
		log.debug("DONE Getting EntitlementDataEntity with id = " + id_to_get); 

		return obj;
	    }
	 
	 protected BusinessUnitDAO getBusinessUnitDAO()
	    {
		BusinessUnitDAO dao = (BusinessUnitDAO)getSession().getDAO("BusinessUnit");  
		if(dao == null)
		{
		    dao = new BusinessUnitDAO(getSession());  		
		    getSession().putDAO("BusinessUnit", dao);
		}		
		return dao;
	    }
	 
	 protected SectorDAO getSectorDAO()
	    {
		SectorDAO dao = (SectorDAO)getSession().getDAO("Sector");  
		if(dao == null)
		{
		    dao = new SectorDAO(getSession());  		
		    getSession().putDAO("Sector", dao);
		}		
		return dao;
	    }
	 
	 protected RegionDAO getRegionDAO()
	    {
		RegionDAO dao = (RegionDAO)getSession().getDAO("Region");  
		if(dao == null)
		{
		    dao = new RegionDAO(getSession());  		
		    getSession().putDAO("Region", dao);
		}		
		return dao;
	    }
	 
	 
	 protected void dummyExceptionTosser(boolean flag) throws DatabaseException
	    {
		if(flag)
		{
		    throw new DatabaseException("This exception should never be thrown....", new Exception("Another dummy"));
		}
	    }
	

   }
