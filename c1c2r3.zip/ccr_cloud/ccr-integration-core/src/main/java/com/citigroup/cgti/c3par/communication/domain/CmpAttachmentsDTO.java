package com.citigroup.cgti.c3par.communication.domain;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

public class CmpAttachmentsDTO {

	private Long documentContentId;
	private String cmpOrderItemId;
	private String fileName;
	private String documentName;
	private String documentMimeType;
	private String createdBy;
	private Date createdDate;
	private String updatedBy;
	private String cmpDownloadUrl;
	private byte[] documentContent;

	public Long getDocumentContentId() {
		return documentContentId;
	}

	public void setDocumentContentId(Long documentContentId) {
		this.documentContentId = documentContentId;
	}

	public String getCmpOrderItemId() {
		return cmpOrderItemId;
	}

	public void setCmpOrderItemId(String cmpOrderItemId) {
		this.cmpOrderItemId = cmpOrderItemId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getDocumentMimeType() {
		return documentMimeType;
	}

	public void setDocumentMimeType(String documentMimeType) {
		this.documentMimeType = documentMimeType;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate == null ? null : (Date) createdDate.clone();
	}

	public void setCreatedDate(Date createdDate) {
		if (createdDate == null) {
			this.createdDate = null;
		} else {
			this.createdDate = new Date(createdDate.getTime());
		}
	}
	
	public String getUpdatedBy() {
		return updatedBy;
	}
	
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	
	public String getCmpDownloadUrl() {
		return cmpDownloadUrl;
	}

	public void setCmpDownloadUrl(String cmpDownloadUrl) {
		this.cmpDownloadUrl = cmpDownloadUrl;
	}

	public byte[] getDocumentContent() {
		return documentContent;
	}

	public void setDocumentContent(byte[] documentContent) {
		this.documentContent = documentContent;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
