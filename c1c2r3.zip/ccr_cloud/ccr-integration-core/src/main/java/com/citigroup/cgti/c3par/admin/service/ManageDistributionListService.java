package com.citigroup.cgti.c3par.admin.service;

import java.util.List;

import com.citigroup.cgti.c3par.admin.domain.ManageDLDTO;

/**
 * @author ac81662
 *
 */
public interface ManageDistributionListService {

    /**
     * @param manageDLDTO
     * @return
     * @throws Exception
     */
    public Long addDL(ManageDLDTO manageDLDTO) throws Exception;

    /**
     * @param manageDLDTO
     * @return
     * @throws Exception
     */
    public boolean saveDL(ManageDLDTO manageDLDTO) throws Exception;

    /**
     * @return
     * @throws Exception
     */
    public List<ManageDLDTO> getManageDLList() throws Exception;

    /**
     * @param manageDLDTO
     * @return
     * @throws Exception
     */
    public boolean deleteDL(ManageDLDTO manageDLDTO) throws Exception;

}
