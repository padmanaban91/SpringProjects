package com.citigroup.cgti.c3par.appsense.domain;

import java.util.List;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;


/**
 * The Class AppsenseProcess.
 */
public class AppsenseDTO extends Base{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** The appsense application list. */
    private List<AppsenseApplication> appsenseApplicationList = null;

    /** The appsense user list. */
    private List<AppsenseUser> appsenseUserList =null;

    /** The appsense policy name. */
    private String appsensePolicyName;

    /** The resource type. */
    private String resourceType;

    /** The relationship type. */
    private String relationshipType;

    /** The total appsense apps. */
    private int totalAppsenseApps;

    /** The total appsense users. */
    private int totalAppsenseUsers;
    
    private TIRequest tireq;
    
    private TIProcess tiProcess;
    

    public TIRequest getTireq() {
		return tireq;
	}

	public void setTireq(TIRequest tireq) {
		this.tireq = tireq;
	}

	public TIProcess getTiProcess() {
		return tiProcess;
	}

	public void setTiProcess(TIProcess tiProcess) {
		this.tiProcess = tiProcess;
	}

	/**
     * Gets the appsense policy name.
     *
     * @return the appsense policy name
     */
    public String getAppsensePolicyName() {
	return appsensePolicyName;
    }

    /**
     * Sets the appsense policy name.
     *
     * @param appsensePolicyName the new appsense policy name
     */
    public void setAppsensePolicyName(String appsensePolicyName) {
	this.appsensePolicyName = appsensePolicyName;
    }

    /**
     * Gets the resource type.
     *
     * @return the resource type
     */
    public String getResourceType() {
	return resourceType;
    }

    /**
     * Sets the resource type.
     *
     * @param resourceType the new resource type
     */
    public void setResourceType(String resourceType) {
	this.resourceType = resourceType;
    }

    /**
     * Gets the appsense application list.
     *
     * @return the appsense application list
     */
    
    /**
     * Gets the relationship type.
     *
     * @return the relationship type
     */
    public String getRelationshipType() {
	return relationshipType;
    }

    public List<AppsenseApplication> getAppsenseApplicationList() {
		return appsenseApplicationList;
	}

	public void setAppsenseApplicationList(
			List<AppsenseApplication> appsenseApplicationList) {
		this.appsenseApplicationList = appsenseApplicationList;
	}

	public List<AppsenseUser> getAppsenseUserList() {
		return appsenseUserList;
	}

	public void setAppsenseUserList(List<AppsenseUser> appsenseUserList) {
		this.appsenseUserList = appsenseUserList;
	}

	/**
     * Sets the relationship type.
     *
     * @param relationshipType the new relationship type
     */
    public void setRelationshipType(String relationshipType) {
	this.relationshipType = relationshipType;
    }

    /**
     * Gets the total appsense apps.
     *
     * @return the total appsense apps
     */
    public int getTotalAppsenseApps() {
	return totalAppsenseApps;
    }

    /**
     * Sets the total appsense apps.
     *
     * @param totalAppsenseApps the new total appsense apps
     */
    public void setTotalAppsenseApps(int totalAppsenseApps) {
	this.totalAppsenseApps = totalAppsenseApps;
    }

    /**
     * Gets the total appsense users.
     *
     * @return the total appsense users
     */
    public int getTotalAppsenseUsers() {
	return totalAppsenseUsers;
    }

    /**
     * Sets the total appsense users.
     *
     * @param totalAppsenseUsers the new total appsense users
     */
    public void setTotalAppsenseUsers(int totalAppsenseUsers) {
	this.totalAppsenseUsers = totalAppsenseUsers;
    }


}
