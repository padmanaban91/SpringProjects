/**
 *
 */
package com.citigroup.cgti.c3par.common.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.audit.domain.AuditC3parUsersData;
import com.citigroup.cgti.c3par.relationship.domain.CitiHierarchyMaster;
import com.citigroup.cgti.c3par.relationship.domain.Region;
import com.citigroup.cgti.c3par.relationship.domain.Sector;
import com.citigroup.cgti.c3par.user.domain.C3parUser;
import com.citigroup.cgti.c3par.user.domain.SecurityRole;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

/**
 * @author pc79439
 * 
 */
public class AdminProcess {
	
	CCRBeanFactory ccrBeanFactory;
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}
    //properties used for pagination
    private int rowCount;
    private int offset;
    private int limit;
    private int pageNo;
    private int totalPages;
    private boolean paginationRequired;
    /** The is select all. */
    private boolean isSelectAll;
    
	private String soeID;
	
	private String firstName;
	
	private String lastName;
	
	private String isDeleted;
	
	private List<ISOContacts> isoContactList;
	
	private C3parUser c3parUser;
	
	private List<Region> regionList;
	
    private List<Sector> sectorList;
    
    private List<SecurityRole> securityRoleList;
    
    private List<Long> selectedRoles;
    
    private Long selectedRegion;
    
    private List<Long> selectedSectors;
    
    private List<C3parUser> c3parUsers;
    
    private AuditC3parUsersData auditC3parUsersData;
	
	public int getRowCount() {
		return rowCount;
	}

	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}

	public int getOffset() {
		return offset;
	}

	public void setOffset(int offset) {
		this.offset = offset;
	}

	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public int getPageNo() {
		return pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public int getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

	public String getSoeID() {
		return soeID;
	}

	public void setSoeID(String soeID) {
		this.soeID = soeID;
	}

	public String getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(String isDeleted) {
		this.isDeleted = isDeleted;
	}

	public List<ISOContacts> getIsoContactList() {
		return isoContactList;
	}

	public void setIsoContactList(List<ISOContacts> isoContactList) {
		this.isoContactList = isoContactList;
	}
	
	public boolean isPaginationRequired() {
		return paginationRequired;
	}

	public void setPaginationRequired(boolean paginationRequired) {
		this.paginationRequired = paginationRequired;
	}
		
	public boolean isSelectAll() {
		return isSelectAll;
	}

	public void setSelectAll(boolean isSelectAll) {
		this.isSelectAll = isSelectAll;
	}
	
	/**
	 * @return the c3parUser
	 */
	public C3parUser getC3parUser() {
		return c3parUser;
	}

	/**
	 * @param c3parUser the c3parUser to set
	 */
	public void setC3parUser(C3parUser c3parUser) {
		this.c3parUser = c3parUser;
	}

	/**
	 * @return the regionList
	 */
	public List<Region> getRegionList() {
		return regionList;
	}

	/**
	 * @param regionList the regionList to set
	 */
	public void setRegionList(List<Region> regionList) {
		this.regionList = regionList;
	}

	/**
	 * @return the sectorList
	 */
	public List<Sector> getSectorList() {
		return sectorList;
	}

	/**
	 * @param sectorList the sectorList to set
	 */
	public void setSectorList(List<Sector> sectorList) {
		this.sectorList = sectorList;
	}

	/**
	 * @return the securityRoleList
	 */
	public List<SecurityRole> getSecurityRoleList() {
		return securityRoleList;
	}
	
	/**
	 * @return the selectedRoles
	 */
	public List<Long> getSelectedRoles() {
		return selectedRoles;
	}

	/**
	 * @param selectedRoles the selectedRoles to set
	 */
	public void setSelectedRoles(List<Long> selectedRoles) {
		this.selectedRoles = selectedRoles;
	}

	/**
	 * @param securityRoleList the securityRoleList to set
	 */
	public void setSecurityRoleList(List<SecurityRole> securityRoleList) {
		this.securityRoleList = securityRoleList;
	}

	/**
	 * @return the selectedRegion
	 */
	public Long getSelectedRegion() {
		return selectedRegion;
	}

	/**
	 * @param selectedRegion the selectedRegion to set
	 */
	public void setSelectedRegion(Long selectedRegion) {
		this.selectedRegion = selectedRegion;
	}

	/**
	 * @return the selectedSectors
	 */
	public List<Long> getSelectedSectors() {
		return selectedSectors;
	}

	/**
	 * @param selectedSectors the selectedSectors to set
	 */
	public void setSelectedSectors(List<Long> selectedSectors) {
		this.selectedSectors = selectedSectors;
	}
	
	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	/**
	 * @return the c3parUsers
	 */
	public List<C3parUser> getC3parUsers() {
		return c3parUsers;
	}
	
	public AuditC3parUsersData getAuditC3parUsersData() {
		return auditC3parUsersData;
	}

	public void setAuditC3parUsersData(AuditC3parUsersData auditC3parUsersData) {
		this.auditC3parUsersData = auditC3parUsersData;
	}

	/**
	 * @param c3parUsers the c3parUsers to set
	 */
	public void setC3parUsers(List<C3parUser> c3parUsers) {
		this.c3parUsers = c3parUsers;
	}

	
	public List<Region> getRegions() {
		return ccrBeanFactory.getRelationshipServicePersistable().getRegionList();
	}

	
	public List<Sector> getSectors(String regionIDs) {
		return ccrBeanFactory.getRelationshipServicePersistable().getSectorList(regionIDs);
	}
	
	
	public List<SecurityRole> getSecurityRoles() {
		return ccrBeanFactory.getAdminServicePersistable().getSecurityRoles();
	}
	
	public List<SecurityRole> getSecurityRolesForCitiUser(){
		return  ccrBeanFactory.getAdminServicePersistable().getSecurityRolesForCitiUser();
	}
	
	public C3parUser retrieveC3parUser(Long id) {
		return ccrBeanFactory.getAdminServicePersistable().retrieveC3parUser(id);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public Long saveC3parUser() {
		return ccrBeanFactory.getAdminServicePersistable().saveUser(this.getC3parUser());
	}
	
	
	public C3parUser validateC3parUser() {
		return ccrBeanFactory.getAdminServicePersistable().validateC3parUser(this.getC3parUser());
	}
	
	
	public List<C3parUser> listC3ParUsers() {
		return ccrBeanFactory.getAdminServicePersistable().listC3ParUsers(this);
	}

	
	public List<CitiHierarchyMaster> getConnectionRegSecBU(Long conId){
		return ccrBeanFactory.getAdminServicePersistable().getConnectionRegSecBU(conId);
	}
	
	
	public Long getUserId(String ssoId){
		return ccrBeanFactory.getAdminServicePersistable().getUserId(ssoId);
	}

	
	public C3parUser retrieveC3parUser(String ssoId) {
		return ccrBeanFactory.getAdminServicePersistable().retrieveC3parUser(ssoId);
	}

	/**
	 * Insert data into audit_c3par_users_data
	 * @return
	 */
	
	public int saveAuditUsersData() {
		return ccrBeanFactory.getAdminServicePersistable().saveAuditUsersDate(this.getAuditC3parUsersData());
	}
	
	/**
	 * Method to retrieve current user information from audit_c3par_users_data
	 * @param userId
	 * @return
	 */
	
	public AuditC3parUsersData getLastAuditUsersData(Long userId) {
		return ccrBeanFactory.getAdminServicePersistable().getLastAuditUsersData(userId);
	}
	
	
}

