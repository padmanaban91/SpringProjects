package com.citigroup.cgti.c3par.acl.dao;

import java.util.List;

import com.citigroup.cgti.c3par.domain.TIRequest;

// TODO: Auto-generated Javadoc
/**
 * The Interface FireFlowProcessPersistable.
 */
public interface FireFlowProcessPersistable {

    /**
     * Gets the fire flow requests.
     *
     * @param tiRequest the ti request
     * @return the fire flow requests
     */
    public List getFireFlowRequests(TIRequest tiRequest);

    /**
     * Gets the fire flow requests.
     *
     * @param processId the process id
     * @param pageNo the page no
     * @param noOfRecords the no of records
     * @return the fire flow requests
     */
    public List getFireFlowRequests(long processId, int pageNo,
	    int noOfRecords);

    /**
     * Gets the total number.
     *
     * @param processId the process id
     * @return the total number
     */
    public int getTotalNumber(long processId);

}
