package com.citigroup.cgti.c3par.communication.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author ky38518
 *
 */
public class CmpChangeLogDetails implements Serializable {
private static final long serialVersionUID = 1L;
private String cmpRequestId;
private String userId;
private Date modifiedDate;
private CmpRelationShipDetails cmpOldCmpRelationShipDetails;
private CmpBusinessCaseDetails cmpOldBusinessCaseDetails;
private CmpRelationShipDetails cmpNewCmpRelationShipDetails;
private CmpBusinessCaseDetails cmpNewBusinessCaseDetails;

private List<CmpContactDetails> cmpContactDetails;
/**
 * @return the cmpRequestId
 */
public String getCmpRequestId() {
    return cmpRequestId;
}
/**
 * @param cmpRequestId the cmpRequestId to set
 */
public void setCmpRequestId(String cmpRequestId) {
    this.cmpRequestId = cmpRequestId;
}
/**
 * @return the userId
 */
public String getUserId() {
    return userId;
}
/**
 * @param userId the userId to set
 */
public void setUserId(String userId) {
    this.userId = userId;
}

/**
 * @return the cmpOldRealCmpRelationShipDetails
 */
public CmpRelationShipDetails getCmpOldCmpRelationShipDetails() {
    return cmpOldCmpRelationShipDetails;
}
/**
 * @param cmpOldRealCmpRelationShipDetails the cmpOldRealCmpRelationShipDetails to set
 */
public void setCmpOldCmpRelationShipDetails(CmpRelationShipDetails cmpOldCmpRelationShipDetails) {
    this.cmpOldCmpRelationShipDetails = cmpOldCmpRelationShipDetails;
}
/**
 * @return the cmpOldBusinessCaseDetails
 */
public CmpBusinessCaseDetails getCmpOldBusinessCaseDetails() {
    return cmpOldBusinessCaseDetails;
}
/**
 * @param cmpOldBusinessCaseDetails the cmpOldBusinessCaseDetails to set
 */
public void setCmpOldBusinessCaseDetails(CmpBusinessCaseDetails cmpOldBusinessCaseDetails) {
    this.cmpOldBusinessCaseDetails = cmpOldBusinessCaseDetails;
}
/**
 * @return the cmpNewRealCmpRelationShipDetails
 */
public CmpRelationShipDetails getCmpNewCmpRelationShipDetails() {
    return cmpNewCmpRelationShipDetails;
}
/**
 * @param cmpNewRealCmpRelationShipDetails the cmpNewRealCmpRelationShipDetails to set
 */
public void setCmpNewCmpRelationShipDetails(CmpRelationShipDetails cmpNewCmpRelationShipDetails) {
    this.cmpNewCmpRelationShipDetails = cmpNewCmpRelationShipDetails;
}
/**
 * @return the cmpNewBusinessCaseDetails
 */
public CmpBusinessCaseDetails getCmpNewBusinessCaseDetails() {
    return cmpNewBusinessCaseDetails;
}
/**
 * @param cmpNewBusinessCaseDetails the cmpNewBusinessCaseDetails to set
 */
public void setCmpNewBusinessCaseDetails(CmpBusinessCaseDetails cmpNewBusinessCaseDetails) {
    this.cmpNewBusinessCaseDetails = cmpNewBusinessCaseDetails;
}
/**
 * @return the cmpContactDetails
 */
public List<CmpContactDetails> getCmpContactDetails() {
    return cmpContactDetails;
}
/**
 * @param cmpContactDetails the cmpContactDetails to set
 */
public void setCmpContactDetails(List<CmpContactDetails> cmpContactDetails) {
    this.cmpContactDetails = cmpContactDetails;
}
/**
 * @return the modifiedDate
 */
public Date getModifiedDate() {
    return modifiedDate;
}
/**
 * @param modifiedDate the modifiedDate to set
 */
public void setModifiedDate(Date modifiedDate) {
    this.modifiedDate = modifiedDate;
}






}
