package com.citigroup.cgti.c3par.communication.domain;

import java.sql.Blob;
import java.util.List;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

public class BusinessUserProcess {
	
	private CMPRequest cmpRequest;
	private String addNote;
	

	private static Blob userUploadFileName;
	
	private CommonsMultipartFile addUploadfile;
	
	CCRBeanFactory ccrBeanFactory;
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}
	
	private String cmpId;
	private String actCode;
	private String resolveItDetailUrl;
	private String caspUrl;
	private String assignedUser;
	private String assistanceRequested;
	private String cancelReason;
	private String textForSubject;
	private String additionalText;
	private String tiRequestId;
    private String addInfoId;

    private CMPComments cmpAddInfoRequested;
    private Map<String, String> mailAttachements;
    private List<CcrCmpXrefDto> ccrList;
    private String activeCcrId;
    private String cmpCcrId;
    private List<CommonsMultipartFile> attachedFile;
    
    private String businessJustificationReqInfo;

    private String citiGrpDataReqInfo;

    private String customerDataReqInfo;

    private String connectionFreqencyReqInfo;

    private String gocCodeReqInfo;

    private String typeOfEntityReqInfo;

    private String directAccessReqInfo;

    private String reasonReqInfo;

    private String urgencyReqInfo;

    private String affectedBusinessReqInfo;

    private String businessJustificationResponseInfo;

    private String citiGrpDataResponseInfo;

    private String customerDataResponseInfo;

    private String connectionFreqencyResponseInfo;

    private String gocCodeResponseInfo;

    private String typeOfEntityResponseInfo;

    private String directAccessResponseInfo;

    private String reasonResponseInfo;

    private String urgencyResponseInfo;

    private String affectedBusinessResponseInfo;

    private String regionReqInfo;

    private String sectorReqInfo;

    private String businessUnitReqInfo;

    private String companyNameReqInfo;

    private String tptContactNameReqInfo;

    private String caspSuppIdReqInfo;

    private String tptContactTypeReqInfo;

    private String caspDetailIdReqInfo;

    private String tptContactPhoneReqInfo;

    private String tptContactEmailReqInfo;

    private String regionResponseInfo;

    private String sectorResponseInfo;

    private String businessUnitResponseInfo;

    private String companyNameResponseInfo;

    private String tptContactNameResponseInfo;

    private String caspSuppIdResponseInfo;

    private String tptContactTypeResponseInfo;

    private String caspDetailIdResponseInfo;

    private String tptContactPhoneResponseInfo;

    private String tptContactEmailResponseInfo;
    

	
	public String getTextForSubject() {
		return textForSubject;
	}

	public void setTextForSubject(String textForSubject) {
		this.textForSubject = textForSubject;
	}

	public String getAdditionalText() {
		return additionalText;
	}

	public void setAdditionalText(String additionalText) {
		this.additionalText = additionalText;
	}

	public String getAssignedUser() {
		return assignedUser;
	}

	public void setAssignedUser(String assignedUser) {
		this.assignedUser = assignedUser;
	}

	public String getAssistanceRequested() {
		return assistanceRequested;
	}

	public void setAssistanceRequested(String assistanceRequested) {
		this.assistanceRequested = assistanceRequested;
	}

	public String getCancelReason() {
		return cancelReason;
	}

	public void setCancelReason(String cancelReason) {
		this.cancelReason = cancelReason;
	}

	public CommonsMultipartFile getAddUploadfile() {
		return addUploadfile;
	}

	public void setAddUploadfile(CommonsMultipartFile addUploadfile) {
		this.addUploadfile = addUploadfile;
	}

	public static Blob getUserUploadFileName() {
		return userUploadFileName;
	}

	public void setUserUploadFileName(Blob userUploadFileName) {
		this.userUploadFileName = userUploadFileName;
	}
	
	public CMPRequest getCmpRequest() {
		return cmpRequest;
	}

	public void setCmpRequest(CMPRequest cmpRequest) {
		this.cmpRequest = cmpRequest;
	}
	
	public String getAddNote() {
		return addNote;
	}

	public void setAddNote(String addNote) {
		this.addNote = addNote;
	}
	
	public String getCmpId() {
		return cmpId;
	}

	public void setCmpId(String cmpId) {
		this.cmpId = cmpId;
	}

	public String getActCode() {
		return actCode;
	}

	public void setActCode(String actCode) {
		this.actCode = actCode;
	}
	public String getResolveItDetailUrl() {
		return resolveItDetailUrl;
	}

	public void setResolveItDetailUrl(String resolveItDetailUrl) {
		this.resolveItDetailUrl = resolveItDetailUrl;
	}
	public String getCaspUrl() {
		return caspUrl;
	}

	public void setCaspUrl(String caspUrl) {
		this.caspUrl = caspUrl;
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void updateAddNoteDetails(CMPRequestNotes cmpRequestNotes) {
		ccrBeanFactory.getEmailGenViewServicePersistable().updateAddNoteDetails(cmpRequestNotes);
	}
	
	public CitiContact getAgentDetails(String ssoId) {
		return ccrBeanFactory.getEmailGenViewServicePersistable().getAgentDetails(ssoId);		
	}
	
	public void cmpActivityTrail(Long cmpId, String ssoId, String taskCode, String activityStatus) {
		ccrBeanFactory.getCmpRequestPersistable().cmpActivityTrail(cmpId, ssoId, taskCode, activityStatus,0l);
	}
	
	
	public List<GenericLookup> loadGenericLookupByName(String name) {
		return ccrBeanFactory.getCommonServicePersistable().getGenericLookupByName(name);
	}
	
	
	public int updateCMPRequestStatus(Long cmpId,String status) {
		return ccrBeanFactory.getEmailGenViewServicePersistable().updateCMPRequestStatus(cmpId,status);
	}
	
	
	public CMPRequest getCMPRequestDetails(String cmpReqId) {
		return ccrBeanFactory.getEmailGenViewServicePersistable().getCMPRequestDetails(cmpReqId);
	}
	
	
	public void sendEmailGenerationView(String userComments , CmpRequestDTO commEmail) {
		ccrBeanFactory.getiMailModule().sendEcmEmailViewGeneration(userComments ,commEmail); 
	}
	
	
	public List<Map<String, String>> getChangeRequestDetails(Long conReqId, String cmpId) {
		return ccrBeanFactory.getEmailGenViewServicePersistable().getChangeRequestDetails(conReqId, cmpId);
	}
	public List<Map<String, String>> getChangeRequestDetails(Long tiRequestId) {
        return ccrBeanFactory.getEmailGenViewServicePersistable().getChangeRequestDetails(tiRequestId);
    }
	
	
	public CMPRequest getCMPRequestDetailsByOerderId(String cmpReqId) {
		return ccrBeanFactory.getEmailGenViewServicePersistable().getCMPRequestDetailsByOrderId(cmpReqId);
	}
	
	
	public List<GenericLookup> loadGenericLookupData(List<String> names) {
		return ccrBeanFactory.getCommonServicePersistable().getGenericLookupData(names);
	} 

	
	
	public void isWaitingforECMUserReply(CMPRequest cmpRequest) {
		 ccrBeanFactory.getEmailGenViewServicePersistable().isWaitingforECMUserReply(cmpRequest);
	}

	public void getTiActivityTrial(CMPRequest cmpRequest,Long tiRequestId) {
         ccrBeanFactory.getEmailGenViewServicePersistable().getTiActivityTrial(cmpRequest, tiRequestId);
    }

    /**
     * @return the tiRequestId
     */
    public String getTiRequestId() {
        return tiRequestId;
    }

    /**
     * @param tiRequestId the tiRequestId to set
     */
    public void setTiRequestId(String tiRequestId) {
        this.tiRequestId = tiRequestId;
    }

    /**
     * @return the addInfoId
     */
    public String getAddInfoId() {
        return addInfoId;
    }

    /**
     * @param addInfoId
     *            the addInfoId to set
     */
    public void setAddInfoId(String addInfoId) {
        this.addInfoId = addInfoId;
    }

    /**
     * @return the cmpAddInfoRequested
     */
    public CMPComments getCmpAddInfoRequested() {
        return cmpAddInfoRequested;
    }

    /**
     * @param cmpAddInfoRequested
     *            the cmpAddInfoRequested to set
     */
    public void setCmpAddInfoRequested(CMPComments cmpAddInfoRequested) {
        this.cmpAddInfoRequested = cmpAddInfoRequested;
    }

    /**
     * @return the mailAttachements
     */
    public Map<String, String> getMailAttachements() {
        return mailAttachements;
    }

    /**
     * @param mailAttachements
     *            the mailAttachements to set
     */
    public void setMailAttachements(Map<String, String> mailAttachements) {
        this.mailAttachements = mailAttachements;
    }

    /**
     * @return the ccrList
     */
    public List<CcrCmpXrefDto> getCcrList() {
        return ccrList;
    }

    /**
     * @param ccrList
     *            the ccrList to set
     */
    public void setCcrList(List<CcrCmpXrefDto> ccrList) {
        this.ccrList = ccrList;
    }

    /**
     * @return the activeCcrId
     */
    public String getActiveCcrId() {
        return activeCcrId;
    }

    /**
     * @param activeCcrId
     *            the activeCcrId to set
     */
    public void setActiveCcrId(String activeCcrId) {
        this.activeCcrId = activeCcrId;
    }

    /**
     * @param cmpAddInfoRequestedId
     * @return
     */
    public CMPComments getcmpAddInfoRequested(Long cmpAddInfoRequestedId) {
        return ccrBeanFactory.getEmailGenViewServicePersistable().getcmpAddInfoRequested(cmpAddInfoRequestedId);
    }

    /**
     * @param cmprequest
     * @param tiRequestId
     */
    public void checkColourstatus(CMPRequest cmprequest, String tiRequestId) {
        ccrBeanFactory.getEmailGenViewServicePersistable().checkColourstatus(cmprequest, tiRequestId);
    }

    /**
     * @return the cmpCcrId
     */
    public String getCmpCcrId() {
        return cmpCcrId;
    }

    /**
     * @param cmpCcrId
     *            the cmpCcrId to set
     */
    public void setCmpCcrId(String cmpCcrId) {
        this.cmpCcrId = cmpCcrId;
    }

    /**
     * @return the attachedFile
     */
    public List<CommonsMultipartFile> getAttachedFile() {
        return attachedFile;
    }

    /**
     * @param attachedFile the attachedFile to set
     */
    public void setAttachedFile(List<CommonsMultipartFile> attachedFile) {
        this.attachedFile = attachedFile;
    }

    public String getBusinessJustificationReqInfo() {
        return businessJustificationReqInfo;
    }

    public void setBusinessJustificationReqInfo(String businessJustificationReqInfo) {
        this.businessJustificationReqInfo = businessJustificationReqInfo;
    }

    public String getCitiGrpDataReqInfo() {
        return citiGrpDataReqInfo;
    }

    public void setCitiGrpDataReqInfo(String citiGrpDataReqInfo) {
        this.citiGrpDataReqInfo = citiGrpDataReqInfo;
    }

    public String getCustomerDataReqInfo() {
        return customerDataReqInfo;
    }

    public void setCustomerDataReqInfo(String customerDataReqInfo) {
        this.customerDataReqInfo = customerDataReqInfo;
    }

    public String getConnectionFreqencyReqInfo() {
        return connectionFreqencyReqInfo;
    }

    public void setConnectionFreqencyReqInfo(String connectionFreqencyReqInfo) {
        this.connectionFreqencyReqInfo = connectionFreqencyReqInfo;
    }

    public String getGocCodeReqInfo() {
        return gocCodeReqInfo;
    }

    public void setGocCodeReqInfo(String gocCodeReqInfo) {
        this.gocCodeReqInfo = gocCodeReqInfo;
    }

    public String getTypeOfEntityReqInfo() {
        return typeOfEntityReqInfo;
    }

    public void setTypeOfEntityReqInfo(String typeOfEntityReqInfo) {
        this.typeOfEntityReqInfo = typeOfEntityReqInfo;
    }

    public String getDirectAccessReqInfo() {
        return directAccessReqInfo;
    }

    public void setDirectAccessReqInfo(String directAccessReqInfo) {
        this.directAccessReqInfo = directAccessReqInfo;
    }

    public String getReasonReqInfo() {
        return reasonReqInfo;
    }

    public void setReasonReqInfo(String reasonReqInfo) {
        this.reasonReqInfo = reasonReqInfo;
    }

    public String getUrgencyReqInfo() {
        return urgencyReqInfo;
    }

    public void setUrgencyReqInfo(String urgencyReqInfo) {
        this.urgencyReqInfo = urgencyReqInfo;
    }

    public String getAffectedBusinessReqInfo() {
        return affectedBusinessReqInfo;
    }

    public void setAffectedBusinessReqInfo(String affectedBusinessReqInfo) {
        this.affectedBusinessReqInfo = affectedBusinessReqInfo;
    }

    public String getBusinessJustificationResponseInfo() {
        return businessJustificationResponseInfo;
    }

    public void setBusinessJustificationResponseInfo(String businessJustificationResponseInfo) {
        this.businessJustificationResponseInfo = businessJustificationResponseInfo;
    }

    public String getCitiGrpDataResponseInfo() {
        return citiGrpDataResponseInfo;
    }

    public void setCitiGrpDataResponseInfo(String citiGrpDataResponseInfo) {
        this.citiGrpDataResponseInfo = citiGrpDataResponseInfo;
    }

    public String getCustomerDataResponseInfo() {
        return customerDataResponseInfo;
    }

    public void setCustomerDataResponseInfo(String customerDataResponseInfo) {
        this.customerDataResponseInfo = customerDataResponseInfo;
    }

    public String getConnectionFreqencyResponseInfo() {
        return connectionFreqencyResponseInfo;
    }

    public void setConnectionFreqencyResponseInfo(String connectionFreqencyResponseInfo) {
        this.connectionFreqencyResponseInfo = connectionFreqencyResponseInfo;
    }

    public String getGocCodeResponseInfo() {
        return gocCodeResponseInfo;
    }

    public void setGocCodeResponseInfo(String gocCodeResponseInfo) {
        this.gocCodeResponseInfo = gocCodeResponseInfo;
    }

    public String getTypeOfEntityResponseInfo() {
        return typeOfEntityResponseInfo;
    }

    public void setTypeOfEntityResponseInfo(String typeOfEntityResponseInfo) {
        this.typeOfEntityResponseInfo = typeOfEntityResponseInfo;
    }

    public String getDirectAccessResponseInfo() {
        return directAccessResponseInfo;
    }

    public void setDirectAccessResponseInfo(String directAccessResponseInfo) {
        this.directAccessResponseInfo = directAccessResponseInfo;
    }

    public String getReasonResponseInfo() {
        return reasonResponseInfo;
    }

    public void setReasonResponseInfo(String reasonResponseInfo) {
        this.reasonResponseInfo = reasonResponseInfo;
    }

    public String getUrgencyResponseInfo() {
        return urgencyResponseInfo;
    }

    public void setUrgencyResponseInfo(String urgencyResponseInfo) {
        this.urgencyResponseInfo = urgencyResponseInfo;
    }

    public String getAffectedBusinessResponseInfo() {
        return affectedBusinessResponseInfo;
    }

    public void setAffectedBusinessResponseInfo(String affectedBusinessResponseInfo) {
        this.affectedBusinessResponseInfo = affectedBusinessResponseInfo;
    }

    public String getRegionReqInfo() {
        return regionReqInfo;
    }

    public void setRegionReqInfo(String regionReqInfo) {
        this.regionReqInfo = regionReqInfo;
    }

    public String getSectorReqInfo() {
        return sectorReqInfo;
    }

    public void setSectorReqInfo(String sectorReqInfo) {
        this.sectorReqInfo = sectorReqInfo;
    }

    public String getBusinessUnitReqInfo() {
        return businessUnitReqInfo;
    }

    public void setBusinessUnitReqInfo(String businessUnitReqInfo) {
        this.businessUnitReqInfo = businessUnitReqInfo;
    }

    public String getCompanyNameReqInfo() {
        return companyNameReqInfo;
    }

    public void setCompanyNameReqInfo(String companyNameReqInfo) {
        this.companyNameReqInfo = companyNameReqInfo;
    }

    public String getTptContactNameReqInfo() {
        return tptContactNameReqInfo;
    }

    public void setTptContactNameReqInfo(String tptContactNameReqInfo) {
        this.tptContactNameReqInfo = tptContactNameReqInfo;
    }

    public String getCaspSuppIdReqInfo() {
        return caspSuppIdReqInfo;
    }

    public void setCaspSuppIdReqInfo(String caspSuppIdReqInfo) {
        this.caspSuppIdReqInfo = caspSuppIdReqInfo;
    }

    public String getTptContactTypeReqInfo() {
        return tptContactTypeReqInfo;
    }

    public void setTptContactTypeReqInfo(String tptContactTypeReqInfo) {
        this.tptContactTypeReqInfo = tptContactTypeReqInfo;
    }

    public String getCaspDetailIdReqInfo() {
        return caspDetailIdReqInfo;
    }

    public void setCaspDetailIdReqInfo(String caspDetailIdReqInfo) {
        this.caspDetailIdReqInfo = caspDetailIdReqInfo;
    }

    public String getTptContactPhoneReqInfo() {
        return tptContactPhoneReqInfo;
    }

    public void setTptContactPhoneReqInfo(String tptContactPhoneReqInfo) {
        this.tptContactPhoneReqInfo = tptContactPhoneReqInfo;
    }

    public String getTptContactEmailReqInfo() {
        return tptContactEmailReqInfo;
    }

    public void setTptContactEmailReqInfo(String tptContactEmailReqInfo) {
        this.tptContactEmailReqInfo = tptContactEmailReqInfo;
    }

    public String getRegionResponseInfo() {
        return regionResponseInfo;
    }

    public void setRegionResponseInfo(String regionResponseInfo) {
        this.regionResponseInfo = regionResponseInfo;
    }

    public String getSectorResponseInfo() {
        return sectorResponseInfo;
    }

    public void setSectorResponseInfo(String sectorResponseInfo) {
        this.sectorResponseInfo = sectorResponseInfo;
    }

    public String getBusinessUnitResponseInfo() {
        return businessUnitResponseInfo;
    }

    public void setBusinessUnitResponseInfo(String businessUnitResponseInfo) {
        this.businessUnitResponseInfo = businessUnitResponseInfo;
    }

    public String getCompanyNameResponseInfo() {
        return companyNameResponseInfo;
    }

    public void setCompanyNameResponseInfo(String companyNameResponseInfo) {
        this.companyNameResponseInfo = companyNameResponseInfo;
    }

    public String getTptContactNameResponseInfo() {
        return tptContactNameResponseInfo;
    }

    public void setTptContactNameResponseInfo(String tptContactNameResponseInfo) {
        this.tptContactNameResponseInfo = tptContactNameResponseInfo;
    }

    public String getCaspSuppIdResponseInfo() {
        return caspSuppIdResponseInfo;
    }

    public void setCaspSuppIdResponseInfo(String caspSuppIdResponseInfo) {
        this.caspSuppIdResponseInfo = caspSuppIdResponseInfo;
    }

    public String getTptContactTypeResponseInfo() {
        return tptContactTypeResponseInfo;
    }

    public void setTptContactTypeResponseInfo(String tptContactTypeResponseInfo) {
        this.tptContactTypeResponseInfo = tptContactTypeResponseInfo;
    }

    public String getCaspDetailIdResponseInfo() {
        return caspDetailIdResponseInfo;
    }

    public void setCaspDetailIdResponseInfo(String caspDetailIdResponseInfo) {
        this.caspDetailIdResponseInfo = caspDetailIdResponseInfo;
    }

    public String getTptContactPhoneResponseInfo() {
        return tptContactPhoneResponseInfo;
    }

    public void setTptContactPhoneResponseInfo(String tptContactPhoneResponseInfo) {
        this.tptContactPhoneResponseInfo = tptContactPhoneResponseInfo;
    }

    public String getTptContactEmailResponseInfo() {
        return tptContactEmailResponseInfo;
    }

    public void setTptContactEmailResponseInfo(String tptContactEmailResponseInfo) {
        this.tptContactEmailResponseInfo = tptContactEmailResponseInfo;
    }	
}
