package com.citigroup.cgti.c3par.admin.service;

import java.util.List;

import com.citigroup.cgti.c3par.admin.domain.ManageTpaMasterDTO;
import com.citigroup.cgti.c3par.appsense.domain.TpaSubnetMaster;

public interface ManageTpaMasterService {
	
	public void saveManageTpaMasterList(ManageTpaMasterDTO manageTpaMasterDTO);
	
	public List<TpaSubnetMaster> getIpDetails(String ipAddress);
	
	public List<TpaSubnetMaster> getExactIpDetails(String ipAddress);
	
	public void deleteManageTpaMasterList(String ipAddress,String updatedUser);

}
