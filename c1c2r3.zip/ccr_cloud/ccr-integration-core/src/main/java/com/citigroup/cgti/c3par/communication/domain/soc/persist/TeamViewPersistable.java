package com.citigroup.cgti.c3par.communication.domain.soc.persist;

import java.util.List;

import com.citigroup.cgti.c3par.communication.domain.ColumnsSortOrderSettings;
import com.citigroup.cgti.c3par.communication.domain.TeamView;
import com.citigroup.cgti.c3par.communication.domain.TeamViewProcess;
import com.citigroup.cgti.c3par.persistance.Persistable;

public interface TeamViewPersistable extends Persistable {

	public List<TeamView> getTeamViewCmpReqData(
			TeamViewProcess teamViewProcess, boolean isExport, List<ColumnsSortOrderSettings> ecmColumnsOrderSettingsList);
	
	List<String> getAssignedLastNameList();
	
	List<String> getSectorList();

}
