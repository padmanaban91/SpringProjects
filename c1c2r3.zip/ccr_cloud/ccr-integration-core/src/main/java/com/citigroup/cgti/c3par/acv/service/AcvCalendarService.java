package com.citigroup.cgti.c3par.acv.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.citi.cgti.c3par.acv.domain.AcvCalendarDTO;
import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.comments.domain.SubmitActivityProcess;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;

/**
 * @author ky38518
 * 
 */
public interface AcvCalendarService {
    public Map<String, Integer> getMonthlyAcvConCntDetails(AcvCalendarDTO acvCalendarDto) throws ApplicationException;

    public List<AcvCalendarDTO> getAcvConnectionsMonthlyDetails(AcvCalendarDTO acvCalendarDto)
            throws ApplicationException;

    public List<AcvCalendarDTO> getAcvConnectionsyearlyDetails(AcvCalendarDTO acvCalendarDto)
            throws ApplicationException;

    public List<String> getAcvYearList() throws ApplicationException;

    public List<GenericLookup> getACVExtensionOptions();

    public Map<String, String> getAcvInstanceId(Long tiRequestId, String ssoId) throws Exception;

    public void updateACVFlag(Long tiRequestId, String sow_number, String instanceId,
            SubmitActivityProcess submitActivityProcess) throws Exception;

    public void updateACVCalanderComments(Long tiRequestId, String comments, String actualRole, String requesterSOEId,
            SubmitActivityProcess submitActivityProcess) throws Exception;

    public void updateRoleId(Long activityTrialId, String actualRole, SubmitActivityProcess submitActivityProcess)
            throws Exception;

    public long acvProActiveComplete(Long processId, String userId, int extensionValue, String extendedDate)
            throws Exception;

    public boolean isUserEligibleForACV(String ssoId) throws Exception;

    public int updateAuditDetails(String ssoId, long tiRequestId) throws Exception;

    public String getRoleNameForUser(String ssoId) throws Exception;

    public String getCcrEntitilementCMPProductURL() throws ApplicationException;

    public boolean isConnectionActive(long processId) throws Exception;

    public boolean isACVScheduled(long processId) throws Exception;
    
    public void uploadDocumentForTiRequest(String processId, String tirequestId, MultipartFile file, String userId) throws Exception;

}
