package com.citigroup.cgti.c3par.admin.service;

import java.util.List;
import com.citigroup.cgti.c3par.admin.domain.FirewallPolicyDTO;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;

/**
 * 
 *
 * @author ac81662
 */

public interface FirewallPolicyUpdateService {

    public List<FirewallPolicyDTO> getPolicyList(String searchPolicyName) throws Exception;

    public Long savePolicy(FirewallPolicyDTO firewallPolicy) throws Exception;

    public List<String> getFwLocationList() throws Exception;

    public List<String> getMgmtRegionList() throws Exception;

    public List<String> getGroupList() throws Exception;

    public List<String> getApplicationInstanceList() throws Exception;

    public void deleteFirewallPolicy(FirewallPolicyDTO firewallPolicyDTO);

    public boolean updateFirewallPolicy(FirewallPolicyDTO firewallPolicyDTO);

    public List<GenericLookup> getFwTypeList() throws Exception;

}
