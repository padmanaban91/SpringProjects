package com.citigroup.cgti.c3par.common.domain;

import java.io.Serializable;
import java.util.Date;

import com.citigroup.cgti.c3par.admin.domain.CCRTags;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.user.domain.C3parUser;

/**
 * @author ac81662
 *
 */
public class TIRequestTags implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    
    private Long id;
    private TIRequest tiRequest;
    private CCRTags ccrTags;
    private Long tagId;
    private Date createdDate;
    private C3parUser userParticipated;
    
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public TIRequest getTiRequest() {
        return tiRequest;
    }
    public void setTiRequest(TIRequest tiRequest) {
        this.tiRequest = tiRequest;
    }
    public CCRTags getCcrTags() {
        return ccrTags;
    }
    public void setCcrTags(CCRTags ccrTags) {
        this.ccrTags = ccrTags;
    }
    public Date getCreatedDate() {
        return createdDate;
    }
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }
    public C3parUser getUserParticipated() {
        return userParticipated;
    }
    public void setUserParticipated(C3parUser userParticipated) {
        this.userParticipated = userParticipated;
    }
    public Long getTagId() {
        return tagId;
    }
    public void setTagId(Long tagId) {
        this.tagId = tagId;
    }

}
