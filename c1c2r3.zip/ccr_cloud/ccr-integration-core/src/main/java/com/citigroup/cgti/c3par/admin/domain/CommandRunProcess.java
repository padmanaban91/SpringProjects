package com.citigroup.cgti.c3par.admin.domain;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.network.ConsoleCommandThreaded;

public class CommandRunProcess {
    
    private static Logger LOGGER = Logger.getLogger(CommandRunProcess.class);

    private String commandText;
    private String commandOutText;

    public String getCommandText() {
		return commandText;
	}
    
    public void setCommandText(String commandText) {
		this.commandText = commandText;
	}

    public void runCommand() {
    	ConsoleCommandThreaded cc = new ConsoleCommandThreaded();
		cc.setCommand(getCommandText());
		cc.start();
		try {
			cc.join(0);
		} catch (InterruptedException e) {
		    LOGGER.error("Exception in CommandRunProcess : runCommand() :" + e);
            LOGGER.error(e.toString(), e);
		}
		LOGGER.debug("cc.getCmdOutput() :"+cc.getCmdOutput());
		setCommandOutText(cc.getCmdOutput());
    }



	public String getCommandOutText() {
		return commandOutText;
	}



	public void setCommandOutText(String commandOutText) {
		this.commandOutText = commandOutText;
	}
}
