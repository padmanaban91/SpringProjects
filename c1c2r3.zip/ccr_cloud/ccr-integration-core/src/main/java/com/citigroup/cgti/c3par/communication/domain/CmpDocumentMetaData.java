package com.citigroup.cgti.c3par.communication.domain;

import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;

public class CmpDocumentMetaData {

	private Long id;
	private String cmpOrderItemId;
	private String fileName;
	private String documentName;
	private String cmpDownloadUrl;
	private String documentMimeType;
	private String deletedFlag;
	private Date createdDate;
	private String createdBy;
	private Date deletedDate;
	private String deletedBy;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCmpOrderItemId() {
		return cmpOrderItemId;
	}

	public void setCmpOrderItemId(String cmpOrderItemId) {
		this.cmpOrderItemId = cmpOrderItemId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getCmpDownloadUrl() {
		return cmpDownloadUrl;
	}

	public void setCmpDownloadUrl(String cmpDownloadUrl) {
		this.cmpDownloadUrl = cmpDownloadUrl;
	}

	public String getDocumentMimeType() {
		return documentMimeType;
	}

	public void setDocumentMimeType(String documentMimeType) {
		this.documentMimeType = documentMimeType;
	}

	public String getDeletedFlag() {
		return deletedFlag;
	}

	public void setDeletedFlag(String deletedFlag) {
		this.deletedFlag = deletedFlag;
	}

	public Date getCreatedDate() {
		return createdDate == null ? null : (Date) createdDate.clone();
	}

	public void setCreatedDate(Date createdDate) {
		if (createdDate == null) {
			this.createdDate = null;
		} else {
			this.createdDate = new Date(createdDate.getTime());
		}
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getDeletedBy() {
		return deletedBy;
	}

	public void setDeletedBy(String deletedBy) {
		this.deletedBy = deletedBy;
	}

	public Date getDeletedDate() {
		return deletedDate == null ? null : (Date) deletedDate.clone();
	}

	public void setDeletedDate(Date deletedDate) {
		if (deletedDate == null) {
			this.deletedDate = null;
		} else {
			this.deletedDate = new Date(deletedDate.getTime());
		}
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
