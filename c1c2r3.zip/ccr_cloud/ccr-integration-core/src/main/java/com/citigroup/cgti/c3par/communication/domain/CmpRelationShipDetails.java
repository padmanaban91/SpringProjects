package com.citigroup.cgti.c3par.communication.domain;

import java.io.Serializable;

/**
 * @author ky38518
 * 
 */
public class CmpRelationShipDetails implements Serializable {
    private static final long serialVersionUID = 1L;
    private String region;
    private String sector;
    private String businessUnit;
    private String companyName;
    private String caspSupplierId;
    private String caspDeatilsId;
    private String thirdPartyContactName;
    private String thirdPartyContactType;
    private String thirdPartyContactPhone;
    private String thirdPartyContactEmail;

    /**
     * @return the region
     */
    public String getRegion() {
        return region;
    }

    /**
     * @param region
     *            the region to set
     */
    public void setRegion(String region) {
        this.region = region;
    }

    /**
     * @return the sector
     */
    public String getSector() {
        return sector;
    }

    /**
     * @param sector
     *            the sector to set
     */
    public void setSector(String sector) {
        this.sector = sector;
    }

    /**
     * @return the businessUnit
     */
    public String getBusinessUnit() {
        return businessUnit;
    }

    /**
     * @param businessUnit
     *            the businessUnit to set
     */
    public void setBusinessUnit(String businessUnit) {
        this.businessUnit = businessUnit;
    }

    /**
     * @return the companyName
     */
    public String getCompanyName() {
        return companyName;
    }

    /**
     * @param companyName
     *            the companyName to set
     */
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    /**
     * @return the caspSupplierId
     */
    public String getCaspSupplierId() {
        return caspSupplierId;
    }

    /**
     * @param caspSupplierId
     *            the caspSupplierId to set
     */
    public void setCaspSupplierId(String caspSupplierId) {
        this.caspSupplierId = caspSupplierId;
    }

    /**
     * @return the caspDeatilsId
     */
    public String getCaspDeatilsId() {
        return caspDeatilsId;
    }

    /**
     * @param caspDeatilsId
     *            the caspDeatilsId to set
     */
    public void setCaspDeatilsId(String caspDeatilsId) {
        this.caspDeatilsId = caspDeatilsId;
    }

    /**
     * @return the thirdPartyContactName
     */
    public String getThirdPartyContactName() {
        return thirdPartyContactName;
    }

    /**
     * @param thirdPartyContactName
     *            the thirdPartyContactName to set
     */
    public void setThirdPartyContactName(String thirdPartyContactName) {
        this.thirdPartyContactName = thirdPartyContactName;
    }

    /**
     * @return the thirdPartyContactType
     */
    public String getThirdPartyContactType() {
        return thirdPartyContactType;
    }

    /**
     * @param thirdPartyContactType
     *            the thirdPartyContactType to set
     */
    public void setThirdPartyContactType(String thirdPartyContactType) {
        this.thirdPartyContactType = thirdPartyContactType;
    }

    /**
     * @return the thirdPartyContactPhone
     */
    public String getThirdPartyContactPhone() {
        return thirdPartyContactPhone;
    }

    /**
     * @param thirdPartyContactPhone
     *            the thirdPartyContactPhone to set
     */
    public void setThirdPartyContactPhone(String thirdPartyContactPhone) {
        this.thirdPartyContactPhone = thirdPartyContactPhone;
    }

    /**
     * @return the thirdPartyContactEmail
     */
    public String getThirdPartyContactEmail() {
        return thirdPartyContactEmail;
    }

    /**
     * @param thirdPartyContactEmail
     *            the thirdPartyContactEmail to set
     */
    public void setThirdPartyContactEmail(String thirdPartyContactEmail) {
        this.thirdPartyContactEmail = thirdPartyContactEmail;
    }

}
