package com.citigroup.cgti.c3par.businessjustification.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.businessjustification.domain.soc.persist.BusinessJustificationServicePersistable;
import com.citigroup.cgti.c3par.common.domain.Application;
import com.citigroup.cgti.c3par.domain.Role;

public class SearchInCSIProcess {
	
	private String acronym;
	
	private String applicationName;
	
	private String applicationId;
	
	private String selectedId;

	private Application application;
	
    private List<Application> applicationList;
    
    private List<CitiResource> citiResourceList;
   
    private String editApplicationsMode;
    
	/**
	 * @return the selectedId
	 */
	public String getSelectedId() {
		return selectedId;
	}


	/**
	 * @param selectedId the selectedId to set
	 */
	public void setSelectedId(String selectedId) {
		this.selectedId = selectedId;
	}


	/**
	 * @return the citiResourceList
	 */
	public List<CitiResource> getCitiResourceList() {
		return citiResourceList;
	}


	/**
	 * @param citiResourceList the citiResourceList to set
	 */
	public void setCitiResourceList(List<CitiResource> citiResourceList) {
		this.citiResourceList = citiResourceList;
	}


	public String getAcronym() {
		return acronym;
	}


	public void setAcronym(String acronym) {
		this.acronym = acronym;
	}


	public String getApplicationName() {
		return applicationName;
	}


	public void setApplicationName(String applicationName) {
		this.applicationName = applicationName;
	}


	public String getApplicationId() {
		return applicationId;
	}


	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}


	public Application getApplication() {
		return application;
	}


	public void setApplication(Application application) {
		this.application = application;
	}

	public List<Application> getApplicationList() {
		return applicationList;
	}

	public void setApplicationList(List<Application> applicationList) {
		this.applicationList = applicationList;
	}


    /**
     * @return the editApplicationsMode
     */
    public String getEditApplicationsMode() {
        return editApplicationsMode;
    }

    /**
     * @param editApplicationsMode
     *            the editApplicationsMode to set
     */
    public void setEditApplicationsMode(String editApplicationsMode) {
        this.editApplicationsMode = editApplicationsMode;
    }
	
	

}
