package com.citigroup.cgti.c3par.bpm.ejb.rel.domain;

import java.io.Serializable;


/**
 * The Class RelationshipDTO.
 */
public class RelationshipDTO implements Serializable{

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 5710116385488421523L;

    /** The id. */
    private Long id;

    /** The name. */
    private String name;

    /** The type. */
    private String type;

    /** The status. */
    private String status;

    /** The requestor soe id. */
    private String requestorSOEId;

    /** The end point a res type id. */
    private Long endPointAResTypeId;

    /** The end point b res type id. */
    private Long endPointBResTypeId;
    
    private String businessName;

    /** The Constant CERTIFIED. */
    public static final String CERTIFIED = "CERTIFIED";
    //public static final String CERTIFICATION_REQUEST = "CERTIFICATION REQUEST";
    /** The Constant CERTIFICATION_REQUEST. */
    public static final String CERTIFICATION_REQUEST = "CERTIFICATION PENDING";

    /** The Constant PENDING. */
    public static final String PENDING = "CERTIFICATION PENDING";

    /** The Constant NOT_CERTIFIED. */
    public static final String NOT_CERTIFIED = "NOT CERTIFIED";

    /** The Constant THIRD_PARTY. */
    static public final String THIRD_PARTY = "THIRD_PARTY";

    /** The Constant CITI_CON. */
    static public final String CITI_CON = "CITI_CON";

    /** The Constant CITI_IP. */
    static public final String CITI_IP = "CITI_IP";

    /** The Constant INTERNAL. */
    static public final String INTERNAL = "Internal";

    /** The Constant EXTERNAL. */
    static public final String EXTERNAL = "External";

    /** The Constant U_TURN. */
    static public final String U_TURN= "U_TURN";
    
    /** The Constant TEMPLATE. */
    static public final String TEMPLATE = "TEMPLATE";
    
    /** The Constant IP_TEMPLATE. */
    static public final String IP_TEMPLATE = "IP_TEMPLATE";
    
    /** The Constant PORT_TEMPLATE. */
    static public final String PORT_TEMPLATE = "PORT_TEMPLATE";

    /**
     * Gets the id.
     *
     * @return the id
     */
    public Long getId() {
	return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
	this.id = id;
    }

    /**
     * Gets the name.
     *
     * @return the name
     */
    public String getName() {
	return name;
    }

    /**
     * Sets the name.
     *
     * @param name the new name
     */
    public void setName(String name) {
	this.name = name;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
	return status;
    }

    /**
     * Sets the status.
     *
     * @param relationshipStatus the new status
     */
    public void setStatus(String relationshipStatus) {
	this.status = relationshipStatus;
    }

    /**
     * Gets the type.
     *
     * @return the type
     */
    public String getType() {
	return type;
    }

    /**
     * Sets the type.
     *
     * @param relationshipType the new type
     */
    public void setType(String relationshipType) {
	this.type = relationshipType;
    }

    /**
     * Gets the requestor soe id.
     *
     * @return the requestor soe id
     */
    public String getRequestorSOEId() {
	return requestorSOEId;
    }

    /**
     * Sets the requestor soe id.
     *
     * @param requestorSOEId the new requestor soe id
     */
    public void setRequestorSOEId(String requestorSOEId) {
	this.requestorSOEId = requestorSOEId;
    }

    /**
     * Gets the end point a res type id.
     *
     * @return the end point a res type id
     */
    public Long getEndPointAResTypeId() {
	return endPointAResTypeId;
    }

    /**
     * Sets the end point a res type id.
     *
     * @param endPointAResTypeId the new end point a res type id
     */
    public void setEndPointAResTypeId(Long endPointAResTypeId) {
	this.endPointAResTypeId = endPointAResTypeId;
    }

    /**
     * Gets the end point b res type id.
     *
     * @return the end point b res type id
     */
    public Long getEndPointBResTypeId() {
	return endPointBResTypeId;
    }

    /**
     * Sets the end point b res type id.
     *
     * @param endPointBResTypeId the new end point b res type id
     */
    public void setEndPointBResTypeId(Long endPointBResTypeId) {
	this.endPointBResTypeId = endPointBResTypeId;
    }

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}
    
    
    
}
