


/** CONFIDENTIAL  AND PROPRIETARY
 * Copyright @ 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is
 * strictly prohibited.
 */

package com.citigroup.cgti.c3par.dao;

import java.io.Serializable;
import java.sql.*;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.model.*;
import com.citigroup.cgti.c3par.dao.lookup.*;
import com.mentisys.model.*;
import com.mentisys.dao.*;
import com.mentisys.dao.query.*;
import com.mentisys.dao.audit.*;


// Reference imports

// Entity name = TIApplicationDAO
// Table name = TI_APPLICATION
// Superclass = <none>
// Subclasses = <none>

/**
 * The Class TIApplicationDAO.
 */
public class TIApplicationDAO
extends DatabaseAccessObject
implements Serializable
{

    /** The Constant TABLE. */
    public static final String	TABLE = "TI_APPLICATION";

    /** The custom sequence. */
    private String customSequence;

    /** The database sequence. */
    private String databaseSequence;

    /** The log. */
    private static Logger log = Logger.getLogger(TIApplicationDAO.class);

    /** The Constant ENTITY_NAME. */
    public static final String	ENTITY_NAME = "TIApplication";

    /** The Constant COLUMN_ID. */
    public static final String	COLUMN_ID = "ID";

    // Column names
    /** The Constant COLUMN_APPLICATIONID. */
    public static final String	COLUMN_APPLICATIONID = "APPLICATION_ID";

    /** The Constant COLUMN_APPLICATIONNAME. */
    public static final String	COLUMN_APPLICATIONNAME = "APPLICATION_NAME";

    /** The Constant COLUMN_APPLICATIONNAME_LEN. */
    public static final int		COLUMN_APPLICATIONNAME_LEN = 100;

    /** The Constant COLUMN_APPLICAITONDESC. */
    public static final String	COLUMN_APPLICAITONDESC = "APPLICAITON_DESC";

    /** The Constant COLUMN_APPLICAITONDESC_LEN. */
    public static final int		COLUMN_APPLICAITONDESC_LEN = 500;

    /** The Constant COLUMN_APPOWNERFULLNAME. */
    public static final String	COLUMN_APPOWNERFULLNAME = "APP_OWNER_FULL_NAME";

    /** The Constant COLUMN_APPOWNERFULLNAME_LEN. */
    public static final int		COLUMN_APPOWNERFULLNAME_LEN = 100;

    /** The Constant COLUMN_APPOWNERGEID. */
    public static final String	COLUMN_APPOWNERGEID = "APP_OWNER_GEID";

    /** The Constant COLUMN_APPOWNERGEID_LEN. */
    public static final int		COLUMN_APPOWNERGEID_LEN = 150;

    /** The Constant COLUMN_ISDEVICE. */
    public static final String	COLUMN_ISDEVICE = "IS_DEVICE";

    /** The Constant COLUMN_ISDEVICE_LEN. */
    public static final int		COLUMN_ISDEVICE_LEN = 1;

    /** The Constant COLUMN_DEVICEMODEL. */
    public static final String	COLUMN_DEVICEMODEL = "DEVICE_MODEL";

    /** The Constant COLUMN_DEVICEMODEL_LEN. */
    public static final int		COLUMN_DEVICEMODEL_LEN = 250;

    /** The Constant COLUMN_DEVICEOTHERTEXT. */
    public static final String	COLUMN_DEVICEOTHERTEXT = "DEVICE_OTHER_TEXT";

    /** The Constant COLUMN_DEVICEOTHERTEXT_LEN. */
    public static final int		COLUMN_DEVICEOTHERTEXT_LEN = 250;

    /** The Constant COLUMN_ISCSI. */
    public static final String	COLUMN_ISCSI = "IS_CSI";

    /** The Constant COLUMN_ISCSI_LEN. */
    public static final int		COLUMN_ISCSI_LEN = 1;

    /** The Constant COLUMN_APPOWNEREMAIL. */
    public static final String	COLUMN_APPOWNEREMAIL = "APP_OWNER_EMAIL";

    /** The Constant COLUMN_APPOWNEREMAIL_LEN. */
    public static final int		COLUMN_APPOWNEREMAIL_LEN = 150;
    // Column names of references
    /** The Constant COLUMN_DEVICETYPE_ID. */
    public static final String	COLUMN_DEVICETYPE_ID = "DEVICE_TYPE_ID";

    // DAO Queries
    /** The SELEC t_ i d_ stmt. */
    private static String SELECT_ID_STMT = "SELECT "  + COLUMN_ID + " FROM " + TIApplicationDAO.TABLE;

    /** The SELEC t_ stmt. */
    private static String SELECT_STMT = "SELECT "  + COLUMN_ID
    + ", " + COLUMN_APPLICATIONID
    + ", " + COLUMN_APPLICATIONNAME
    + ", " + COLUMN_APPLICAITONDESC
    + ", " + COLUMN_APPOWNERFULLNAME
    + ", " + COLUMN_APPOWNERGEID
    + ", " + COLUMN_ISDEVICE
    + ", " + COLUMN_DEVICEMODEL
    + ", " + COLUMN_DEVICEOTHERTEXT
    + ", " + COLUMN_ISCSI
    + ", " + COLUMN_APPOWNEREMAIL
    + ", " + COLUMN_DEVICETYPE_ID
    + " FROM " + TIApplicationDAO.TABLE;

    /** The SELEC t_ b y_ i d_ stmt. */
    private static String SELECT_BY_ID_STMT = TIApplicationDAO.SELECT_STMT + " WHERE " + COLUMN_ID + " = ?";

    /** The UPDAT e_ b y_ i d_ stmt. */
    private static String UPDATE_BY_ID_STMT = "UPDATE " + TIApplicationDAO.TABLE + " SET "
    + COLUMN_APPLICATIONID + " = ? "
    + ", " + COLUMN_APPLICATIONNAME + " = ? "
    + ", " + COLUMN_APPLICAITONDESC + " = ? "
    + ", " + COLUMN_APPOWNERFULLNAME + " = ? "
    + ", " + COLUMN_APPOWNERGEID + " = ? "
    + ", " + COLUMN_ISDEVICE + " = ? "
    + ", " + COLUMN_DEVICEMODEL + " = ? "
    + ", " + COLUMN_DEVICEOTHERTEXT + " = ? "
    + ", " + COLUMN_ISCSI + " = ? "
    + ", " + COLUMN_APPOWNEREMAIL + " = ? "
    + ", " + COLUMN_DEVICETYPE_ID + " = ? "
    + " WHERE " + COLUMN_ID + " = ?";

    /** The INSER t_ stmt. */
    private static String INSERT_STMT = "INSERT INTO " + TIApplicationDAO.TABLE
    + "(" + COLUMN_ID
    + ", " + COLUMN_APPLICATIONID 
    + ", " + COLUMN_APPLICATIONNAME 
    + ", " + COLUMN_APPLICAITONDESC 
    + ", " + COLUMN_APPOWNERFULLNAME 
    + ", " + COLUMN_APPOWNERGEID 
    + ", " + COLUMN_ISDEVICE 
    + ", " + COLUMN_DEVICEMODEL 
    + ", " + COLUMN_DEVICEOTHERTEXT 
    + ", " + COLUMN_ISCSI 
    + ", " + COLUMN_APPOWNEREMAIL 
    + ", " + COLUMN_DEVICETYPE_ID
    + ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    /** The DELET e_ stmt. */
    private static String DELETE_STMT = "DELETE FROM " + TIApplicationDAO.TABLE + " WHERE ID = ?";



    //======================================================================
    /**
     * Simple factory method.
     *
     * @param session the session
     * @return the tI application dao
     */
    public static TIApplicationDAO createInstance(DatabaseSession session)
    {
	return new TIApplicationDAO(session);
    }

    // Contructors
    //======================================================================
    /**
     * Instantiates a new tI application dao.
     *
     * @param session the session
     */
    public TIApplicationDAO(DatabaseSession session)
    {
	super(session);
	log.debug("Creating TIApplicationDAO (" + s_CreateCount + ")");
    }

    //Sequence Generator
    /**
     * Sets the custom sequence.
     *
     * @param customSequence the new custom sequence
     */
    public void setCustomSequence(String customSequence){

	this.customSequence=customSequence;
    }

    //Sequence Generator
    /**
     * Sets the database sequence.
     *
     * @param databaseSequence the new database sequence
     */
    public void setDatabaseSequence(String databaseSequence){

	this.databaseSequence=databaseSequence;
    }


    // Insert
    //======================================================================
    /**
     * Insert an entity into the database.
     *
     * @param entity The TIApplicationEntity to insert
     * @return The id that was assigned to the entity
     * @throws DatabaseException the database exception
     */
    public Long insert(TIApplicationEntity entity) throws DatabaseException
    {
	return insert(entity, null, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long insert(TIApplicationEntity entity, boolean reset) throws DatabaseException
    {
	return insert(entity, null, reset);
    }

    //======================================================================
    /**
     * Insert an entity into the database.
     *
     * @param entity The TIApplicationEntity to insert
     * @param archiver The archiver object used for tracking changes to the entity
     * @return The id that was assigned to the entity
     * @throws DatabaseException the database exception
     */
    public Long insert(TIApplicationEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	return insert(entity, archiver, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param archiver the archiver
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long insert(TIApplicationEntity entity, AuditArchiver archiver, boolean reset) throws DatabaseException
    {
	log.debug("Inserting TIApplicationEntity");
	DatabaseSession session = getSession();

	if(primaryKeyExists(entity, false, session))
	    throw new DatabaseException("Could not insert '" + TIApplicationDAO.ENTITY_NAME + "' with id = " + entity.getId() + " due to unique key constraint violation", null);

	Connection connection = null;

	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    // Update FOREIGN_KEY references for which we are the OWNER

	    // Generate a new id
	    long id=-1;
	    if(customSequence !=null)
		id = KeyGenerator.getInstance().getNextKey(session, customSequence);
	    else if(databaseSequence != null){
		try{
		    st=connection.prepareStatement("Select "+databaseSequence+".nextval from dual");
		    rs = st.executeQuery();
		    if (rs.next())
		    {
			id=rs.getLong(1);
		    }
		}finally{
		    try{
			if(rs!=null)rs.close();
			if(st!=null)st.close();
		    }catch(Exception xe){}

		}
	    }
	    else
		id = KeyGenerator.getInstance().getNextKey(session, TIApplicationDAO.ENTITY_NAME);
	    entity.setId(Long.valueOf(id));
	    int position = 1;
	    st = connection.prepareStatement(INSERT_STMT);
	    setLongToStatement(st, position++, entity.getId());

	    // Attributes
	    position = setLongToStatement(st, position, entity.getApplicationId());
	    position = setStringToStatement(st, position, entity.getApplicationName(), COLUMN_APPLICATIONNAME_LEN);
	    position = setStringToStatement(st, position, entity.getApplicaitonDesc(), COLUMN_APPLICAITONDESC_LEN);
	    position = setStringToStatement(st, position, entity.getAppOwnerFullName(), COLUMN_APPOWNERFULLNAME_LEN);
	    position = setStringToStatement(st, position, entity.getAppOwnerGeid(), COLUMN_APPOWNERGEID_LEN);
	    position = setStringToStatement(st, position, entity.getIsDevice(), COLUMN_ISDEVICE_LEN);
	    position = setStringToStatement(st, position, entity.getDeviceModel(), COLUMN_DEVICEMODEL_LEN);
	    position = setStringToStatement(st, position, entity.getDeviceOtherText(), COLUMN_DEVICEOTHERTEXT_LEN);
	    position = setStringToStatement(st, position, entity.getIsCsi(), COLUMN_ISCSI_LEN);
	    position = setStringToStatement(st, position, entity.getAppOwnerEmail(), COLUMN_APPOWNEREMAIL_LEN);

	    // Association references
	    position = updateReferences(st, entity, position);

	    st.executeUpdate();
	    entity.setPrimaryKey(Long.valueOf(id));

	    // Update FOREIGN_KEY references for which we are the OWNER
	    if (archiver != null)
	    {
		archiver.storeSnapshotAuditLogForEntity(entity, "create");
	    }
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not insert '" + TIApplicationDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return entity.getPrimaryKey();
    }

    //======================================================================
    /**
     * Update the state of an entity. If the entity doesn't exist in the database it gets automatically added.
     *
     * @param entity The TIApplicationEntity to update.
     * @return The Id of the entity. If the entity had to be inserted this is the id assigned to it.
     * @throws DatabaseException the database exception
     */
    public Long update(TIApplicationEntity entity) throws DatabaseException
    {
	return update(entity, null, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(TIApplicationEntity entity, boolean reset) throws DatabaseException
    {
	return update(entity, null, reset);
    }

    //======================================================================
    /**
     * Update the state of an entity. If the entity doesn't exist in the database it gets automatically added.
     *
     * @param entity The TIApplicationEntity to update
     * @param archiver The archiver object used for tracking changes to the entity
     * @return The Id of the entity. If the entity had to be inserted this is the id assigned to it.
     * @throws DatabaseException the database exception
     */
    public Long update(TIApplicationEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	return update(entity, archiver, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param archiver the archiver
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(TIApplicationEntity entity, AuditArchiver archiver, boolean reset) throws DatabaseException
    {
	if (entity.getPrimaryKey() == null)
	{
	    // Not created yet
	    return insert(entity, archiver, reset);
	}
	if (!entity.isModified())
	{
	    return entity.getPrimaryKey();
	}
	log.debug("Updating TIApplicationEntity [" + entity.getId() + "]");
	DatabaseSession session = getSession();

	if(primaryKeyExists(entity, true, session))
	    throw new DatabaseException("Could not update '" + TIApplicationDAO.ENTITY_NAME + "' with id = " + entity.getId() + " due to unique key constraint violation", null);

	Connection		connection = null;
	PreparedStatement st = null;
	ResultSet 		rs = null;

	try
	{
	    connection = session.getConnection();
	    // Update FOREIGN_KEY references for which we are the OWNER

	    int position = 1;
	    st = connection.prepareStatement(UPDATE_BY_ID_STMT);

	    // Attributes
	    position = setLongToStatement(st, position, entity.getApplicationId());
	    position = setStringToStatement(st, position, entity.getApplicationName(), COLUMN_APPLICATIONNAME_LEN);
	    position = setStringToStatement(st, position, entity.getApplicaitonDesc(), COLUMN_APPLICAITONDESC_LEN);
	    position = setStringToStatement(st, position, entity.getAppOwnerFullName(), COLUMN_APPOWNERFULLNAME_LEN);
	    position = setStringToStatement(st, position, entity.getAppOwnerGeid(), COLUMN_APPOWNERGEID_LEN);
	    position = setStringToStatement(st, position, entity.getIsDevice(), COLUMN_ISDEVICE_LEN);
	    position = setStringToStatement(st, position, entity.getDeviceModel(), COLUMN_DEVICEMODEL_LEN);
	    position = setStringToStatement(st, position, entity.getDeviceOtherText(), COLUMN_DEVICEOTHERTEXT_LEN);
	    position = setStringToStatement(st, position, entity.getIsCsi(), COLUMN_ISCSI_LEN);
	    position = setStringToStatement(st, position, entity.getAppOwnerEmail(), COLUMN_APPOWNEREMAIL_LEN);

	    // Association references
	    position = updateReferences(st, entity, position);

	    // where
	    setLongToStatement(st, position++, entity.getPrimaryKey());

	    st.executeUpdate();

	    // Update FOREIGN_KEY references for which we are the OWNER
	    if (archiver != null)
	    {
		archiver.storeAuditLogForEntity(entity, "update");
	    }
	    if (reset)
	    {
		session.addToResetList(entity);
	    }
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not update '" + TIApplicationDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return entity.getPrimaryKey();
    }

    //======================================================================
    /**
     * Get the entity determined by the id. This method automatically loads all references maintained by the entity.
     *
     * @param id A Long identifying the entity to get.
     * @return The entity or null if no entity with that id exists.
     * @throws DatabaseException the database exception
     */
    public TIApplicationEntity get(Long id) throws DatabaseException
    {
	return get(id, true);
    }

    //======================================================================
    /**
     * Get the entity determined by the id.
     *
     * @param id A Long identifying the entity to get.
     * @param load_refs A boolean that determines wether to load all the entities references. True to load, false to defer loading until later.
     * @return The entity or null if no entity with that id exists.
     * @throws DatabaseException the database exception
     */
    public TIApplicationEntity get(Long id, boolean load_refs) throws DatabaseException
    {
	Long id_to_get = id;
	TIApplicationEntity obj = (TIApplicationEntity) getSession().getObjectFromSession(ENTITY_NAME, id_to_get);
	log.debug("Getting TIApplicationEntity with id = " + id_to_get); 
	if(obj != null)
	{
	    log.debug(">>> TIApplicationEntity >>> already LOADED !!!"); 
	}

	if(obj == null)
	{
	    DatabaseSession session = getSession();
	    Connection connection = null;

	    PreparedStatement st = null;
	    ResultSet rs = null;

	    try
	    {
		connection = session.getConnection();
		//				st = session.getPreparedStatement(SELECT_BY_ID_STMT);
		st = connection.prepareStatement(SELECT_BY_ID_STMT);
		setLongToStatement(st, 1, id_to_get);
		rs = st.executeQuery();

		if (rs.next())
		{
		    obj = (TIApplicationEntity) createEntity(rs);
		}
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not load " + TIApplicationDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	}

	if (obj != null && load_refs)
	{
	    try
	    {
		// Load the associated objects
		loadReferences(obj);
		obj.setModified(false);
	    }
	    catch (DatabaseException e)
	    {
		throw new DatabaseException("Failed to load references of " + TIApplicationDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	}
	log.debug("DONE Getting TIApplicationEntity with id = " + id_to_get); 

	return obj;
    }


    //======================================================================
    /**
     * Retrieve the entities indicated by the list argument provided.
     *
     * @param id_list list of entity ids to load
     * @param load_refs Flag that determines wether the references should be loaded as part of the operation
     * @return A List of all the entities loaded.
     * @throws DatabaseException the database exception
     */
    public List get(List id_list, boolean load_refs) throws DatabaseException
    {
	List 	entity_list = new ArrayList(16);
	if(id_list != null && id_list.size() > 0)
	{
	    DatabaseSession 	session = getSession();
	    Connection 			connection = null;
	    Statement 			st = null;
	    ResultSet 			rs = null;
	    TIApplicationEntity 		entity = null;

	    try
	    {
		StringBuffer statement = new StringBuffer(SELECT_STMT + " WHERE " + COLUMN_ID + " IN (");

		Long only = null;
		long count = 0;
		Iterator iter = id_list.iterator();
		while(iter.hasNext())
		{
		    Long id = (Long)iter.next();
		    entity = (TIApplicationEntity) getSession().getObjectFromSession(ENTITY_NAME, id);
		    if(entity != null)
		    {
			if(load_refs)
			{
			    loadReferences(entity);
			}
			entity_list.add(entity);
		    }
		    else // add the the id to the statement
		    {
			if(count++ > 0)
			{
			    statement.append(",");					
			}
			statement.append(id.toString());					
			only = id;
		    }
		}

		// check if we need to explicitly load any entities
		if(count == 1)
		{
		    entity_list.add(get(only, load_refs));					
		}
		else if(count > 1)
		{
		    statement.append(")");	// Close the statenemt's IN clause					
		    log.debug("DAO.get(List): executing statement. Count = (" + count + ") --> " + statement.toString());
		    connection = session.getConnection();
		    //					st = connection.prepareStatement(statement.toString());
		    //					rs = st.executeQuery();
		    st = connection.createStatement();
		    rs = st.executeQuery(statement.toString());

		    while(rs.next())
		    {
			entity = (TIApplicationEntity) createEntity(rs);
			if(load_refs)
			{
			    loadReferences(entity);
			    entity.setModified(false);
			}
			entity_list.add(entity);					
		    }
		}
	    }
	    catch(SQLException e)
	    {
		throw new DatabaseException("Failed to load all entities of type " + TIApplicationDAO.ENTITY_NAME + ".", e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		if(connection != null)
		{
		    session.releaseConnection();
		}
	    }
	}

	return entity_list;	
    }

    //======================================================================
    /**
     * Retrieve all entities.
     *
     * @param load_refs Flag that determines wether the references should be loaded as part of the operation
     * @return The list of all entities of type TIApplicationEntity
     * @throws DatabaseException the database exception
     */
    public List getAll(boolean load_refs) throws DatabaseException
    {
	List 				entity_list = query(new Condition(), load_refs);
	/*
		DatabaseSession 	session = getSession();
		Connection 			connection = null;
		Statement 	st = null;
		ResultSet 			rs = null;
		TIApplicationEntity 		entity = null;

		try
		{
			String select_stmt = "SELECT * FROM TI_APPLICATION";
			connection = session.getConnection();

			st = connection.createStatement();
			rs = st.executeQuery(select_stmt.toString());

			while(rs.next())
			{
				entity = (TIApplicationEntity) createEntity(rs);
				if(load_refs)
				{
					loadReferences(entity);
					entity.setModified(false);
				}
				entity_list.add(entity);					
			}
		}
		catch(SQLException e)
		{
			throw new DatabaseException("Failed to load all entities of type " + TIApplicationDAO.ENTITY_NAME + ".", e);
		}
		finally
		{
			closeResultSet(rs);
			closeStatement(st);
			session.releaseConnection();
		}
	 */
	return entity_list;	
    }	

    //======================================================================
    /**
     * Retrieve the IDs of all entities.
     *
     * @return A list of IDs of all the entities of type TIApplicationEntity
     * @throws DatabaseException the database exception
     */
    public List getAllIds() throws DatabaseException
    {
	return queryForId(new Condition());
    }

    //======================================================================
    /**
     * Checks wether the entity with the given ID already exists in the database.
     *
     * @param id The id of the entity to test.
     * @return A boolean that indicates exsitence (true) or lack thereof (false)
     * @throws DatabaseException the database exception
     */
    public boolean exists(String id) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;

	PreparedStatement st = null;
	ResultSet rs = null;
	boolean exists = false;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_BY_ID_STMT);
	    st.setString(1, id);
	    rs = st.executeQuery();
	    exists = rs.next();
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not verify existence of '" + TIApplicationDAO.ENTITY_NAME + "' with id = "
		    + id, e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return exists;
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param id The id of the entity to be deleted from the database.
     * @throws DatabaseException the database exception
     */
    public void delete(Long id) throws DatabaseException
    {
	if(id != null)
	{
	    TIApplicationEntity entity = get(id, false);
	    delete(entity, null);
	}
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param id The id of the entity to be deleted from the database.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(Long id, AuditArchiver archiver) throws DatabaseException
    {
	if(id != null)
	{
	    TIApplicationEntity entity = get(id, false);
	    delete(entity, archiver);
	}
    }

    //======================================================================
    /**
     * Delete a list of entities from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity_ids A list of Long objects providing the ids of the entities to be deleted.
     * @throws DatabaseException the database exception
     */
    public void delete(List entity_ids) throws DatabaseException
    {
	delete(entity_ids, null);
    }

    //======================================================================
    /**
     * Delete a list of entities from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity_ids A list of Long objects providing the ids of the entities to be deleted.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(List entity_ids, AuditArchiver archiver) throws DatabaseException
    {
	if(entity_ids != null)
	{
	    Iterator iter = entity_ids.iterator();
	    while(iter.hasNext())
	    {
		Long id = (Long)iter.next();		
		delete(id, archiver);
	    }
	}
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity The entity to be deleted from the database.
     * @throws DatabaseException the database exception
     */
    public void delete(TIApplicationEntity entity) throws DatabaseException
    {
	delete(entity, null);
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity The entity to be deleted from the database.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(TIApplicationEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	if(entity != null && entity.getId() != null)
	{
	    DatabaseSession session = getSession();
	    Connection connection = null;

	    if (archiver != null)
	    {
		archiver.storeSnapshotAuditLogForEntity(entity, "delete");
	    }


	    // Clear all associations and remove all compositions
	    deleteManyAssociations(entity);

	    // Delete ourself
	    PreparedStatement st = null;
	    ResultSet rs = null;

	    try
	    {
		connection = session.getConnection();
		// Generate a new id
		int position = 1;
		st = connection.prepareStatement(DELETE_STMT);
		position = setLongToStatement(st, position, entity.getPrimaryKey());

		st.execute();

		// COMPOSITION Delete ONE objects...

		entity.setPrimaryKey(null);
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not delete '" + TIApplicationDAO.ENTITY_NAME + "' with id = "
			+ entity.getId(), e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	}
    }

    //======================================================================
    /**
     * Delete many associations.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    protected void deleteManyAssociations(TIApplicationEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;

	try
	{
	    connection = session.getConnection();
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to perform association clean up during delete of'" + TIApplicationDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    session.releaseConnection();
	}

    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#buildEntity(java.sql.ResultSet, com.mentisys.model.Entity)
     */
    protected void buildEntity(ResultSet rs, Entity obj) throws DatabaseException
    {
	TIApplicationEntity entity = (TIApplicationEntity) obj;
	try
	{
	    // TODO: Figure a better way of dealing with the absence of any attribute
	    dummyExceptionTosser(false);

	    int index = 1;

	    //			entity.setApplicationId(getLongFromResultSet(rs, COLUMN_APPLICATIONID));
	    entity.setApplicationId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalApplicationId(entity.getApplicationId());
	    //			entity.setApplicationName(getStringFromResultSet(rs, COLUMN_APPLICATIONNAME));
	    entity.setApplicationName(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalApplicationName(entity.getApplicationName());
	    //			entity.setApplicaitonDesc(getStringFromResultSet(rs, COLUMN_APPLICAITONDESC));
	    entity.setApplicaitonDesc(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalApplicaitonDesc(entity.getApplicaitonDesc());
	    //			entity.setAppOwnerFullName(getStringFromResultSet(rs, COLUMN_APPOWNERFULLNAME));
	    entity.setAppOwnerFullName(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalAppOwnerFullName(entity.getAppOwnerFullName());
	    //			entity.setAppOwnerGeid(getStringFromResultSet(rs, COLUMN_APPOWNERGEID));
	    entity.setAppOwnerGeid(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalAppOwnerGeid(entity.getAppOwnerGeid());
	    //			entity.setIsDevice(getStringFromResultSet(rs, COLUMN_ISDEVICE));
	    entity.setIsDevice(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalIsDevice(entity.getIsDevice());
	    //			entity.setDeviceModel(getStringFromResultSet(rs, COLUMN_DEVICEMODEL));
	    entity.setDeviceModel(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalDeviceModel(entity.getDeviceModel());
	    //			entity.setDeviceOtherText(getStringFromResultSet(rs, COLUMN_DEVICEOTHERTEXT));
	    entity.setDeviceOtherText(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalDeviceOtherText(entity.getDeviceOtherText());
	    //			entity.setIsCsi(getStringFromResultSet(rs, COLUMN_ISCSI));
	    entity.setIsCsi(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalIsCsi(entity.getIsCsi());
	    //			entity.setAppOwnerEmail(getStringFromResultSet(rs, COLUMN_APPOWNEREMAIL));
	    entity.setAppOwnerEmail(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalAppOwnerEmail(entity.getAppOwnerEmail());

	    // Single References
	    //			entity.setDeviceTypeId(getLongFromResultSet(rs, COLUMN_DEVICETYPE_ID));
	    entity.setDeviceTypeId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalDeviceTypeId(entity.getDeviceTypeId());

	    // Load multi reference Ids
	    loadReferenceIds(entity);

	    obj.setModified(false);
	}
	catch (DatabaseException e)
	{
	    throw new DatabaseException("Cannot build database entity object from result set", e);
	}
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#createEntity(java.sql.ResultSet)
     */
    protected Entity createEntity(ResultSet rs) throws DatabaseException
    {
	TIApplicationEntity entity = null;
	try
	{
	    // get the ID of the entity we're to create, and check if that is already held in the session. Thereby allowing us to
	    // bypass the creation altogether and reuse the one in existence.			
	    Long _id = getLongFromResultSet(rs, COLUMN_ID);
	    entity = (TIApplicationEntity) getSession().getObjectFromSession(ENTITY_NAME, _id);
	    if (entity == null)
	    {        
		entity = new TIApplicationEntity(_id);
		buildEntity(rs, entity);
		getSession().addObjectToSession(entity, ENTITY_NAME, _id);
	    }
	}
	catch (DatabaseException e)
	{
	    throw new DatabaseException("Cannot create database entity object from result set", e);
	}
	return entity;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.AccessObject#getQuerySelectString()
     */
    protected String getQuerySelectString()
    {
	return SELECT_STMT;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#getQuerySelectIdString()
     */
    protected String getQuerySelectIdString()
    {
	return SELECT_ID_STMT;
    }

    //======================================================================
    /**
     * Load the IDs of the external references for the entity.
     *
     * @param obj The entity for which to load the IDs of its references
     * @throws DatabaseException the database exception
     */
    public void loadReferenceIds(Entity obj) throws DatabaseException
    {
	TIApplicationEntity entity = (TIApplicationEntity)obj;
    }

    //======================================================================
    /**
     * Load the external references for the entity.
     *
     * @param obj The entity for which to load its references
     * @throws DatabaseException the database exception
     */
    public void loadReferences(Entity obj) throws DatabaseException
    {
	if (obj.isReferencesLoaded())
	{
	    log.debug("IPRegDetailApplicationXrefDAO.loadReferences(): References for TIApplicationEntity [" + obj.getId() + "] already loaded");
	    return;
	}
	log.debug("IPRegDetailApplicationXrefDAO.loadReferences(): Loading references for TIApplicationEntity [" + obj.getId() + "].");
	obj.setReferencesLoaded(true);
	try
	{
	    TIApplicationEntity entity = (TIApplicationEntity)obj;

	    Long deviceTypeId = entity.getDeviceTypeId();
	    if (deviceTypeId != null)
	    {
		// Use lookup for optimized access
		entity.setDeviceType(GenericLookupLookup.getInstance().getById(getSession(), deviceTypeId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalDeviceType(entity.getDeviceType());
	    }

	}
	catch(Exception e)
	{
	    obj.setReferencesLoaded(false);
	    throw new DatabaseException("Failed to load references for TIApplicationEntity [" + obj.getId() + "].", e);
	}
    }

    //======================================================================
    /**
     * Load device type with id.
     *
     * @param id the id
     * @return the generic lookup entity
     * @throws DatabaseException the database exception
     */
    public GenericLookupEntity loadDeviceTypeWithId(Long id) throws DatabaseException
    {
	GenericLookupEntity entity = null;
	if (id != null)
	{
	    // Use lookup for optimized access
	    entity = GenericLookupLookup.getInstance().getById(getSession(), id);
	}
	return entity;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#updateReferences(java.sql.PreparedStatement, com.mentisys.model.Entity, int)
     */
    protected int updateReferences(PreparedStatement st, Entity obj, int position)
    throws DatabaseException, SQLException
    {
	TIApplicationEntity entity = (TIApplicationEntity) obj;

	setLongToStatement(st, position++, entity.getDeviceType() != null ? entity.getDeviceType().getId() : entity.getDeviceTypeId());

	return position;
    }

    // Single non-composition 'deviceType' helpers 'TIApplication' does not need helper

    // Reference DAO caching methods	
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A GenericLookupDAO object 
     */
    protected GenericLookupDAO getDeviceTypeDAO()
    {
	GenericLookupDAO dao = (GenericLookupDAO)getSession().getDAO("GenericLookup");  
	if(dao == null)
	{
	    dao = new GenericLookupDAO(getSession());  		
	    getSession().putDAO("GenericLookup", dao);
	}		
	return dao;
    }

    //=====================================================================
    // Query helpers: 
    //=====================================================================

    //=====================================================================
    /**
     * Find all entities where the property [ApplicationId] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByApplicationId(Long value) throws DatabaseException
    {
	return findByApplicationId(value, getSession());
    }

    /**
     * Find by application id.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByApplicationId(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIApplicationDAO.TABLE + " WHERE " + COLUMN_APPLICATIONID + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [ApplicationName] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByApplicationName(String value) throws DatabaseException
    {
	return findByApplicationName(value, getSession());
    }

    /**
     * Find by application name.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByApplicationName(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIApplicationDAO.TABLE + " WHERE " + COLUMN_APPLICATIONNAME + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [ApplicaitonDesc] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByApplicaitonDesc(String value) throws DatabaseException
    {
	return findByApplicaitonDesc(value, getSession());
    }

    /**
     * Find by applicaiton desc.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByApplicaitonDesc(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIApplicationDAO.TABLE + " WHERE " + COLUMN_APPLICAITONDESC + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [AppOwnerFullName] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByAppOwnerFullName(String value) throws DatabaseException
    {
	return findByAppOwnerFullName(value, getSession());
    }

    /**
     * Find by app owner full name.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByAppOwnerFullName(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIApplicationDAO.TABLE + " WHERE " + COLUMN_APPOWNERFULLNAME + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [AppOwnerGeid] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByAppOwnerGeid(String value) throws DatabaseException
    {
	return findByAppOwnerGeid(value, getSession());
    }

    /**
     * Find by app owner geid.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByAppOwnerGeid(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIApplicationDAO.TABLE + " WHERE " + COLUMN_APPOWNERGEID + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [IsDevice] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByIsDevice(String value) throws DatabaseException
    {
	return findByIsDevice(value, getSession());
    }

    /**
     * Find by is device.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByIsDevice(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIApplicationDAO.TABLE + " WHERE " + COLUMN_ISDEVICE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [DeviceModel] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByDeviceModel(String value) throws DatabaseException
    {
	return findByDeviceModel(value, getSession());
    }

    /**
     * Find by device model.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByDeviceModel(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIApplicationDAO.TABLE + " WHERE " + COLUMN_DEVICEMODEL + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [DeviceOtherText] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByDeviceOtherText(String value) throws DatabaseException
    {
	return findByDeviceOtherText(value, getSession());
    }

    /**
     * Find by device other text.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByDeviceOtherText(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIApplicationDAO.TABLE + " WHERE " + COLUMN_DEVICEOTHERTEXT + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [IsCsi] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByIsCsi(String value) throws DatabaseException
    {
	return findByIsCsi(value, getSession());
    }

    /**
     * Find by is csi.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByIsCsi(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIApplicationDAO.TABLE + " WHERE " + COLUMN_ISCSI + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [AppOwnerEmail] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByAppOwnerEmail(String value) throws DatabaseException
    {
	return findByAppOwnerEmail(value, getSession());
    }

    /**
     * Find by app owner email.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByAppOwnerEmail(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIApplicationDAO.TABLE + " WHERE " + COLUMN_APPOWNEREMAIL + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [DeviceType] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByDeviceType(Long value) throws DatabaseException
    {
	return findByDeviceType(value, getSession());
    }

    /**
     * Find by device type.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByDeviceType(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIApplicationDAO.TABLE + " WHERE " + COLUMN_DEVICETYPE_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find entities by property helper.
     *
     * @param sel_stmt the sel_stmt
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static protected List findEntitiesByPropertyHelper(String sel_stmt, DatabaseSession session) throws DatabaseException
    {
	List entities = null;
	Connection connection = null;
	Statement st = null;
	ResultSet rs = null;

	log.debug(sel_stmt);

	try
	{
	    connection = session.getConnection();
	    st = connection.createStatement();
	    rs = st.executeQuery(sel_stmt);

	    List found_entities = new ArrayList();		
	    while(rs.next())
	    {
		found_entities.add(Long.valueOf(rs.getLong(1)));			
	    }

	    if(found_entities.size() > 0)
	    {
		entities = found_entities;
	    }

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failure to find entities by DeviceType", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    if(connection != null)
	    {
		session.releaseConnection();
	    }
	}

	return entities;
    }


    //=====================================================================
    /**
     * Dummy exception tosser.
     *
     * @param flag the flag
     * @throws DatabaseException the database exception
     */
    protected void dummyExceptionTosser(boolean flag) throws DatabaseException
    {
	if(flag)
	{
	    throw new DatabaseException("This exception should never be thrown....", new Exception("Another dummy"));
	}
    }

    /**
     * Primary key exists.
     *
     * @param entity the entity
     * @param update the update
     * @param session the session
     * @return true, if successful
     * @throws DatabaseException the database exception
     */
    private boolean primaryKeyExists(TIApplicationEntity entity, boolean update, DatabaseSession session) 
    throws DatabaseException {

	boolean exists = false;

	return exists;
    }
}
