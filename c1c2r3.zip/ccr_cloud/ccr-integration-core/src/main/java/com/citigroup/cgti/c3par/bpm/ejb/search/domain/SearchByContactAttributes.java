package com.citigroup.cgti.c3par.bpm.ejb.search.domain;

import java.io.Serializable;


/**
 * The Class SearchByContactAttributes.
 */


/**
 * Created by nc43495
 */


public class SearchByContactAttributes  extends BaseSearchAttributes implements Serializable{

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -3828763137580583865L;
    
    /** Contact/soe id */
    private String contact;

    /** ContactRole */
    private Long contactRole;

    /** The Region */
    private Long region;
    
    /** The Sector */
    private Long sector;
    
    /** The CSI */
    private Long csiApplicationID;
   

	/** The firewall Device/Policy */
    private String fwDevice;
    
	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}
	
	public Long getContactRole() {
		return contactRole;
	}

	public void setContactRole(Long contactRole) {
		this.contactRole = contactRole;
	}

	public Long getRegion() {
		return region;
	}

	public void setRegion(Long region) {
		this.region = region;
	}

	public Long getSector() {
		return sector;
	}

	public void setSector(Long sector) {
		this.sector = sector;
	}

	public Long getCsiApplicationID() {
		return csiApplicationID;
	}

	public void setCsiApplicationID(Long csiApplicationID) {
		this.csiApplicationID = csiApplicationID;
	}

	public String getFwDevice() {
		return fwDevice;
	}

	public void setFwDevice(String fwDevice) {
		this.fwDevice = fwDevice;
	}

	public String getContactForQuery() {
		return validString(contact);
	}

	public Long getContactRoleForQuery() {
		return validLong(contactRole);
	}
	
	public Long getRegionForQuery() {
		return validLong(region);
	}
	
	public Long getCsiApplicationForQuery() {
		return validLong(csiApplicationID);
	}
	 
	public String getFwDeviceForQuery() {
			return validString(fwDevice);
	}

	public Long getSectorForQuery() {
		return validLong(sector);
	}	
	
}
