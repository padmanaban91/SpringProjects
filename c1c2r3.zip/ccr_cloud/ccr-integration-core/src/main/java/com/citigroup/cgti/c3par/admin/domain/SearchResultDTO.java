package com.citigroup.cgti.c3par.admin.domain;

public class SearchResultDTO {

    private Long ccrId;
    private String ccrName;
    private String isPrimary;
    private boolean isSelected;
    private String isNotify;
    private Long Id;

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }

    public Long getCcrId() {
        return ccrId;
    }

    public void setCcrId(Long ccrId) {
        this.ccrId = ccrId;
    }

    public String getCcrName() {
        return ccrName;
    }

    public void setCcrName(String ccrName) {
        this.ccrName = ccrName;
    }

    public String getIsPrimary() {
        return isPrimary;
    }

    public void setIsPrimary(String isPrimary) {
        this.isPrimary = isPrimary;
    }

    public String getIsNotify() {
        return isNotify;
    }

    public void setIsNotify(String isNotify) {
        this.isNotify = isNotify;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean isSelected) {
        this.isSelected = isSelected;
    }
}
