/**
 * 
 */
package com.citigroup.cgti.c3par.admin.service;

import java.util.List;
import java.util.Map;

import com.citigroup.cgti.c3par.admin.domain.BulkContactUpdateDTO;
import com.citigroup.cgti.c3par.admin.domain.SearchResultDTO;
import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.domain.Role;

/**
 * @author ka58098
 * 
 */
public interface BulkContactUpdateService {

    public BulkContactUpdateDTO getSearchDetails(BulkContactUpdateDTO bulkContactUpdateDTO);

    public List<Role> getRoleList();

    public Long getTIRequestID(Long processId);

    public void updateContact(List<Long> planningIdList, List<String> contactTypeList, List<Long> citiContactIdList, BulkContactUpdateDTO bulkContactUpdateDTO);

    public CitiContact getCitiContact(String ssoId);

    public String getContactNameForSsoId(String ssoId);

    void removeContact(BulkContactUpdateDTO bulkContactUpdateDTO);

    void updatePrimaryOrNotifyContact(Map<Long, String> planningIdList, BulkContactUpdateDTO bulkContactUpdateDTO);

    // public List<BulkContactUpdateDTO> getSearchDetails(String ssoId, Long
    // roleId);

}
