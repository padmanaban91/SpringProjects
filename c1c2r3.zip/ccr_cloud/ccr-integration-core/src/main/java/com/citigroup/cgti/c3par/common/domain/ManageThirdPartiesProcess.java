/**
 *
 */
package com.citigroup.cgti.c3par.common.domain;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.common.domain.soc.persist.ThirdPartyPersistable;
import com.citigroup.cgti.c3par.relationship.domain.Location;
import com.citigroup.cgti.c3par.relationship.domain.Relationship;
import com.citigroup.cgti.c3par.relationship.domain.ThirdParty;
import com.citigroup.cgti.c3par.relationship.domain.ThirdPartyContact;
import com.citigroup.cgti.c3par.relationship.domain.ThirdPartyLocationXref;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

/**
 * @author 
 * 
 */
public class ManageThirdPartiesProcess {
	
CCRBeanFactory ccrBeanFactory;
	
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}

	/** The log. */
	private static Logger log = Logger.getLogger(ManageThirdPartiesProcess.class);

	private List<ThirdParty> thirdParties;
	
    private List<ThirdPartyContact> 	tpContacts;
    
    private List<Location> 	tpLocations;
    
    private List<Relationship> 	tpRelationship;

	private ThirdParty thirdParty;
	
	private String filter;
	
	private Long selectedThirdParty;
	
	private String selectedId;
	
	private ThirdPartyContact tpContact;
	
	private Location tpLocation;
	
	private Map<Long,String> country;
	
	private Map<Long,String> region;
	
	private String regionId;
	
	private String countryId;
	
	private ThirdPartyLocationXref tpLocXref;

	 public String getRegionId() {
		return regionId;
	}

	public void setRegionId(String regionId) {
		this.regionId = regionId;
	}

	public String getCountryId() {
		return countryId;
	}

	public void setCountryId(String countryId) {
		this.countryId = countryId;
	}

	public Map<Long,String> getCountry() {
		return country;
	}

	public void setCountry(Map<Long,String> country) {
		this.country = country;
	}

	public Map<Long,String> getRegion() {
		return region;
	}

	public void setRegion(Map<Long,String> region) {
		this.region = region;
	}

	public List<ThirdParty> getThirdParties() {
		return thirdParties;
	}

	public void setThirdParties(List<ThirdParty> thirdParties) {
		this.thirdParties = thirdParties;
	}

	public String getFilter() {
		return filter;
	}

	public void setFilter(String filter) {
		this.filter = filter;
	}

	public ThirdParty getThirdParty() {
		return thirdParty;
	}

	public void setThirdParty(ThirdParty thirdParty) {
		this.thirdParty = thirdParty;
	}


	public Long getSelectedThirdParty() {
		return selectedThirdParty;
	}

	public void setSelectedThirdParty(Long selectedThirdParty) {
		this.selectedThirdParty = selectedThirdParty;
	}

	public List<ThirdPartyContact> getTpContacts() {
		return tpContacts;
	}

	public void setTpContacts(List<ThirdPartyContact> tpContacts) {
		this.tpContacts = tpContacts;
	}

	public List<Location> getTpLocations() {
		return tpLocations;
	}

	public void setTpLocations(List<Location> tpLocations) {
		this.tpLocations = tpLocations;
	}

	public List<Relationship> getTpRelationship() {
		return tpRelationship;
	}

	public void setTpRelationship(List<Relationship> tpRelationship) {
		this.tpRelationship = tpRelationship;
	}

	public String getSelectedId() {
		return selectedId;
	}

	public void setSelectedId(String selectedId) {
		this.selectedId = selectedId;
	}

	public ThirdPartyContact getTpContact() {
		return tpContact;
	}

	public void setTpContact(ThirdPartyContact tpContact) {
		this.tpContact = tpContact;
	}

	public Location getTpLocation() {
		return tpLocation;
	}

	public void setTpLocation(Location tpLocation) {
		this.tpLocation = tpLocation;
	}

	public ThirdPartyLocationXref getTpLocXref() {
		return tpLocXref;
	}

	public void setTpLocXref(ThirdPartyLocationXref tpLocXref) {
		this.tpLocXref = tpLocXref;
	}

	
	public List<ThirdParty> getThirdPartyList(String search) {
		return ccrBeanFactory.getThirdPartyPersistable().getThirdPartyList(search);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void deleteThirdParty(Long id) {
		ccrBeanFactory.getThirdPartyPersistable().deleteThirdParty(id);
	}

	public ThirdPartyPersistable getThirdPartyPersistable() {
		return ccrBeanFactory.getThirdPartyPersistable();
	}

	

	
	public List<ThirdPartyContact> getTpContactsForId(Long id) {
		return ccrBeanFactory.getThirdPartyPersistable().getTpContactsForId(id);
	}

	
	public List<Location> getTpLocationsForId(Long id) {
		return ccrBeanFactory.getThirdPartyPersistable().getTpLocationsForId(id);
	}
	
	
	public List<Relationship> getTpRelationshipForId(Long id) {
		return ccrBeanFactory.getThirdPartyPersistable().getTpRelationshipForId(id);
	}
	
	
	public ThirdPartyContact getThirdPartyForId(Long id) {
		return ccrBeanFactory.getThirdPartyPersistable().getThirdPartyForId(id);
	}
	
	
	public int getTpRelationshipForContact(long id) {
		return ccrBeanFactory.getThirdPartyPersistable().getTpRelationshipForContact(id);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void deleteContactById(Long id) {
		ccrBeanFactory.getThirdPartyPersistable().deleteContactById(id);		
	}
	
	
	public Location getThirdPartyLocation(Long id) {
		return ccrBeanFactory.getThirdPartyPersistable().getLocation(id);
	}
	
	
	public Map<Long, String> getListofCountries() {
		return ccrBeanFactory.getThirdPartyPersistable().getListofCountries();
	}
	
	
	public Map<Long,String> getListOfRegions() {
		return ccrBeanFactory.getThirdPartyPersistable().getListOfRegions();
	}
	
	
	public int getTpRelationshipForLocation(Long id) {
		return ccrBeanFactory.getThirdPartyPersistable().getTpRelationshipForLocation(id);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void deleteLocationById(Long id) {
		ccrBeanFactory.getThirdPartyPersistable().deleteLocationById(id);		
	}
}
