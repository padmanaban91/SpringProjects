package com.citigroup.cgti.c3par.communication.domain;

import java.io.Serializable;

/**
 * @author ac81662
 *
 */
public class ColumnsSortOrderSettings implements Serializable {

	private static final long serialVersionUID = 1L;
	private Long id;
	private EcmUserSetting ecmUserSetting;
	private Long ecmUserSettingId;
	private Long columnId;
	private EcmColumn ecmColumn;
	private String sortOrder;
	private Long ecmColumnIdOrder;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public EcmUserSetting getEcmUserSetting() {
		return ecmUserSetting;
	}
	public void setEcmUserSetting(EcmUserSetting ecmUserSetting) {
		this.ecmUserSetting = ecmUserSetting;
	}
	public EcmColumn getEcmColumn() {
		return ecmColumn;
	}
	public void setEcmColumn(EcmColumn ecmColumn) {
		this.ecmColumn = ecmColumn;
	}
	public String getSortOrder() {
		return sortOrder;
	}
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}
	public Long getEcmColumnIdOrder() {
		return ecmColumnIdOrder;
	}
	public void setEcmColumnIdOrder(Long ecmColumnIdOrder) {
		this.ecmColumnIdOrder = ecmColumnIdOrder;
	}
	public Long getColumnId() {
		return columnId;
	}
	public void setColumnId(Long columnId) {
		this.columnId = columnId;
	}
	public Long getEcmUserSettingId() {
		return ecmUserSettingId;
	}
	public void setEcmUserSettingId(Long ecmUserSettingId) {
		this.ecmUserSettingId = ecmUserSettingId;
	}
}
