package com.citigroup.cgti.c3par.connection.domain;

import java.io.Serializable;
import java.util.Date;

import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;


/**
 * The Class ConnectionPortXref.
 */
public class ConnectionPortXref extends PerformerPagerDO implements Serializable {

    /** The connection port mst. */
    private ConnectionPortMaster connectionPortMst;

    /** The default service. */
    private String defaultService;

    /** The service name. */
    private String serviceName;

    /** The other service text. */
    private String otherServiceText;

    /** The created_date. */
    private Date created_date;

    /** The updated_date. */
    private Date updated_date;

    /** The traffic type. */
    private String trafficType;

    /**
     * Instantiates a new connection port xref.
     */
    public ConnectionPortXref() {
	//---------------------
	setTableName(PerformerTypes.CONN_PORT_XREF_TABEL);
	setSequenceName(PerformerTypes.CONN_PORT_XREF_SEQ);
	//---------------------
	addToDBMapping("connectionPortMst","port_id",1);
	addToDBMapping("defaultService","default_service_flag",2);
	addToDBMapping("serviceName","service_name",3);
	addToDBMapping("otherServiceText","other_service_text",4);
	addToDBMapping("created_date","created_date",5);
	addToDBMapping("updated_date","updated_date",6);
	addToDBMapping("trafficType","TYPE_OF_TRAFFIC",7);
	//----------------------
	addToNonCompositionList("connectionPortMst");
	//----------------------
	addToParentsMap("com.citigroup.cgti.c3par.connection.domain.ConnectionIPPairXref" , "ip_pair_xref_id");
	//----------------------
    }

    /**
     * Gets the connection port mst.
     *
     * @return the connection port mst
     */
    public ConnectionPortMaster getConnectionPortMst() {
	return connectionPortMst;
    }

    /**
     * Sets the connection port mst.
     *
     * @param connectionPortMst the new connection port mst
     */
    public void setConnectionPortMst(ConnectionPortMaster connectionPortMst) {
	this.connectionPortMst = connectionPortMst;
    }



    /**
     * Gets the created_date.
     *
     * @return Returns the created_date.
     */
    public Date getCreated_date() {
	return created_date;
    }

    /**
     * Sets the created_date.
     *
     * @param created_date The created_date to set.
     */
    public void setCreated_date(Date created_date) {
	this.created_date = created_date;
    }

    /**
     * Gets the updated_date.
     *
     * @return Returns the updated_date.
     */
    public Date getUpdated_date() {
	return updated_date;
    }

    /**
     * Sets the updated_date.
     *
     * @param updated_date The updated_date to set.
     */
    public void setUpdated_date(Date updated_date) {
	this.updated_date = updated_date;
    }

    /**
     * Gets the default service.
     *
     * @return the default service
     */
    public String getDefaultService() {
	return defaultService;
    }

    /**
     * Sets the default service.
     *
     * @param defaultService the new default service
     */
    public void setDefaultService(String defaultService) {
	this.defaultService = defaultService;
    }

    /**
     * Gets the other service text.
     *
     * @return the other service text
     */
    public String getOtherServiceText() {
	return otherServiceText;
    }

    /**
     * Sets the other service text.
     *
     * @param otherServiceText the new other service text
     */
    public void setOtherServiceText(String otherServiceText) {
	this.otherServiceText = otherServiceText;
    }

    /**
     * Gets the service name.
     *
     * @return the service name
     */
    public String getServiceName() {
	return serviceName;
    }

    /**
     * Sets the service name.
     *
     * @param serviceName the new service name
     */
    public void setServiceName(String serviceName) {
	this.serviceName = serviceName;
    }

    /**
     * Gets the traffic type.
     *
     * @return the traffic type
     */
    public String getTrafficType() {
	return trafficType;
    }

    /**
     * Sets the traffic type.
     *
     * @param trafficType the new traffic type
     */
    public void setTrafficType(String trafficType) {
	this.trafficType = trafficType;
    }
}
