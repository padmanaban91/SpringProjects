package com.citigroup.cgti.c3par.bpm.ejb.vc;

import java.util.ArrayList;
import java.util.Map;

import com.citigroup.cgti.c3par.bpm.ejb.domain.ProcessRFCDTO;
import com.citigroup.cgti.c3par.bpm.ejb.domain.RFCRequestDTO;
import com.citigroup.cgti.c3par.fw.domain.ServiceNowMessageLog;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCRequest;





/**
 * The Interface IManageRFC.
 */
public  interface IManageRFC {
	
	/**
	 * Gets the rFC request list.
	 *
	 * @param processRFCDto the process rfc dto
	 * @return the rFC request list
	 */
	public ProcessRFCDTO getRFCRequestList(ProcessRFCDTO processRFCDto);
	
	/**
	 * Post rfc.
	 *
	 * @param rfcRequestDTO the rfc request dto
	 * @return the rFC request dto
	 */
	public RFCRequestDTO postRFC(RFCRequestDTO rfcRequestDTO);
	
	/**
	 * Check rfc data complete.
	 *
	 * @param rfcRequestDTO the rfc request dto
	 * @return the rFC request dto
	 */
	public RFCRequestDTO checkRFCDataComplete(RFCRequestDTO rfcRequestDTO);
	
	/**
	 * Register rfc.
	 *
	 * @param rfcRequestDTO the rfc request dto
	 * @return the rFC request dto
	 */
	public RFCRequestDTO registerRFC(RFCRequestDTO rfcRequestDTO);	
	
	/**
	 * Gets the people record.
	 *
	 * @param tiRequestId the ti request id
	 * @return the people record
	 */
	public String getPeopleRecord(Long tiRequestId);
    
    /**
     * Store generic rfc.
     *
     * @param tiRequestId the ti request id
     */
    public void storeGenericRFC(Long tiRequestId);
    public Map getSchedulerValues();
    public void insertSNActivity(Long tiRequestId);
    public void updateSNActivity(Long tiRequestId);
    
    public String getServiceNowCRXml(RFCRequestDTO rfcReqDTO, RFCRequest rfcRequest, ServiceNowMessageLog SNMsgLog, ArrayList contactDetails);

	/**
	 * @param processRFCDTO
	 * @return
	 */
	boolean isChangeRequestsCreated(ProcessRFCDTO processRFCDTO);

	/**
	 * @param tiRequestId
	 * @param processInstanceId
	 * @param rfcType
	 */
	public void updateProcessInstanceId(Long tiRequestId, Long processInstanceId,String rfcType);
}
