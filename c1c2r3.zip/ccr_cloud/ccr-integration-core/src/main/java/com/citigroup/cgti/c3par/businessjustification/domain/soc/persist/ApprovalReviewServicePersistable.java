/**
 * 
 */
package com.citigroup.cgti.c3par.businessjustification.domain.soc.persist;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.List;

import com.citigroup.cgti.c3par.businessjustification.domain.ApprovalReviewProcess;
import com.citigroup.cgti.c3par.persistance.Persistable;

public interface ApprovalReviewServicePersistable extends Persistable {

	public HashMap<String, String> fetchRequestInfo(String requestId,
			String action);

	public List<HashMap<String, String>> extractReviewComments(long requestId)
			throws Exception;

	public int getCount(String listType, Long ti_request_id, String role)
			throws Exception;

	public HashMap extractReviewInfo(long requestId) throws Exception;

	public HashMap extractReviewInfoForIP(long requestId) throws Exception;
	
	public List getAllDiscussions(String listType, Long ti_request_id,
			String role, int pageNum, int pageSize) throws RemoteException;

    public boolean saveNote(ApprovalReviewProcess approvalReviewProcess) throws Exception;

    public List<ApprovalReviewProcess> getNotes(Long tiProcessId) throws Exception;

    public boolean saveTag(ApprovalReviewProcess approvalReviewProcess) throws Exception;

    public List<ApprovalReviewProcess> getTags(Long tiProcessId) throws Exception;

}
