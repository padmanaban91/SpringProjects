package com.citigroup.cgti.c3par.admin.domain;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.common.domain.ResourceType;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

public class ManageResourceTypeProcess {
	
     CCRBeanFactory ccrBeanFactory;
	
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}

	private ResourceType resType = new ResourceType();

    private List<ResourceType> resourceTypeList = new ArrayList<ResourceType>();
    
    private String[] selectedID;
    
    
    public String[] getSelectedID() {
		return selectedID;
	}

	public void setSelectedID(String[] selectedID) {
		this.selectedID = selectedID;
	}

	
    
   
    public List<ResourceType> getResourceTypeList() {
		return resourceTypeList;
	}

	public void setResourceTypeList(List<ResourceType> resourceTypeList) {
		this.resourceTypeList = resourceTypeList;
	}

	public ResourceType getResType() {
		return resType;
	}

	public void setResType(ResourceType resType) {
		this.resType = resType;
	}

	
    public List<ResourceType> getResourceType(){
    	return ccrBeanFactory.getResourceTypePersistable().getResourceType();
	 }
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public boolean addResourceType(ResourceType resourceType,String userID){
		return ccrBeanFactory.getResourceTypePersistable().addResourceType(resourceType,userID);
	 }
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void updateResourceType(String id,String status,String userID){
		ccrBeanFactory.getResourceTypePersistable().updateResourceType(id,status,userID);
	 }

}
