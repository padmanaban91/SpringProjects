package com.citigroup.cgti.c3par.connection.domain;

import java.io.Serializable;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;


/**
 * The Class ConnectionFirewallXref.
 */
public class ConnectionFirewallXref extends PerformerPagerDO implements Serializable {

    /** The firewall. */
    private ConnectionFirewallMaster firewall= new ConnectionFirewallMaster();

    /** The circuit id. */
    private String circuitId= new String();

    /** The connection bandwidth. */
    private Long connectionBandwidth;

    /** The primary firewall. */
    private String primaryFirewall= new String();

    /** The acl variance. */
    private String aclVariance = new String();

    /** The router id. */
    private String routerId = new String();

    /** The location. */
    private String location = new String();

    /** The acl flag. */
    private String aclFlag="F";


    /**
     * Instantiates a new connection firewall xref.
     */
    public  ConnectionFirewallXref(){
	setTableName(PerformerTypes.CONNECTION_FIREWALL_DETAILS);
	setSequenceName(PerformerTypes.CON_FIREWALL_DETAILS_SEQ);
	addToDBMapping("firewall","firewall_id",1);
	addToDBMapping("circuitId","circuit_id",2);
	addToDBMapping("connectionBandwidth","bandwidth_id",3);

	addToDBMapping("primaryFirewall","primary_firewall",4);
	addToDBMapping("aclVariance","acl_variance",5);
	addToDBMapping("routerId","router_id",6);
	addToDBMapping("location","location",7);
	addToDBMapping("aclFlag","acl",8);




	addToNonCompositionList("connectionIPMaster");

	addToParentsMap(
		"com.citigroup.cgti.c3par.connection.domain.ConnectionProcess",
	"CONNECTION_REQUEST_ID");	
    }

    /**
     * Gets the acl variance.
     *
     * @return the acl variance
     */
    public String getAclVariance() {
	return aclVariance;
    }

    /**
     * Sets the acl variance.
     *
     * @param aclVariance the new acl variance
     */
    public void setAclVariance(String aclVariance) {
	this.aclVariance = aclVariance;
    }

    /**
     * Gets the circuit id.
     *
     * @return the circuit id
     */
    public String getCircuitId() {
	return circuitId;
    }

    /**
     * Sets the circuit id.
     *
     * @param circuitId the new circuit id
     */
    public void setCircuitId(String circuitId) {
	this.circuitId = circuitId;
    }

    /**
     * Gets the connection bandwidth.
     *
     * @return the connection bandwidth
     */
    public Long getConnectionBandwidth() {
	return connectionBandwidth;
    }

    /**
     * Sets the connection bandwidth.
     *
     * @param connectionBandwidth the new connection bandwidth
     */
    public void setConnectionBandwidth(Long connectionBandwidth) {
	this.connectionBandwidth = connectionBandwidth;

    }

    /**
     * Gets the firewall.
     *
     * @return the firewall
     */
    public ConnectionFirewallMaster getFirewall() {
	return firewall;
    }

    /**
     * Sets the firewall.
     *
     * @param firewall the new firewall
     */
    public void setFirewall(ConnectionFirewallMaster firewall) {
	this.firewall = firewall;
    }

    /**
     * Gets the location.
     *
     * @return the location
     */
    public String getLocation() {
	return location;
    }

    /**
     * Sets the location.
     *
     * @param location the new location
     */
    public void setLocation(String location) {
	this.location = location;
    }

    /**
     * Gets the router id.
     *
     * @return the router id
     */
    public String getRouterId() {
	return routerId;
    }

    /**
     * Sets the router id.
     *
     * @param routerId the new router id
     */
    public void setRouterId(String routerId) {
	this.routerId = routerId;
    }

    /**
     * Checks if is acl.
     *
     * @return true, if is acl
     */
    public boolean isAcl() {
	return aclFlag.equalsIgnoreCase("T");
    }

    /**
     * Sets the acl.
     *
     * @param aclFlag the new acl
     */
    public void setAcl(boolean aclFlag) {
	this.aclFlag = aclFlag ?"T" :"F";
    }

    /**
     * Checks if is primary firewall.
     *
     * @return true, if is primary firewall
     */
    public boolean isPrimaryFirewall() {
	return primaryFirewall.equalsIgnoreCase("T");
    }

    /**
     * Sets the primary firewall.
     *
     * @param isPrimaryFirewall the new primary firewall
     */
    public void setPrimaryFirewall(boolean isPrimaryFirewall) {
	this.primaryFirewall = isPrimaryFirewall?"T":"F";
    }

    /**
     * Gets the acl flag.
     *
     * @return the acl flag
     */
    public String getAclFlag() {
	return aclFlag;
    }

    /**
     * Sets the acl flag.
     *
     * @param aclFlag the new acl flag
     */
    public void setAclFlag(String aclFlag) {
	this.aclFlag = aclFlag;
    }

    /**
     * Gets the primary firewall.
     *
     * @return the primary firewall
     */
    public String getPrimaryFirewall() {
	return primaryFirewall;
    }

    /**
     * Sets the primary firewall.
     *
     * @param primaryFirewall the new primary firewall
     */
    public void setPrimaryFirewall(String primaryFirewall) {
	this.primaryFirewall = primaryFirewall;
    }




}
