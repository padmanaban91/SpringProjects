package com.citigroup.cgti.c3par.communication.domain;

import org.apache.commons.lang.builder.ToStringBuilder;

public class CmpDocumentContent {

	private Long id;
	private CmpDocumentMetaData cmpDocumentMetaData;
	private byte[] documentContent;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public CmpDocumentMetaData getCmpDocumentMetaData() {
		return cmpDocumentMetaData;
	}

	public void setCmpDocumentMetaData(CmpDocumentMetaData cmpDocumentMetaData) {
		this.cmpDocumentMetaData = cmpDocumentMetaData;
	}

	public byte[] getDocumentContent() {
		return documentContent;
	}

	public void setDocumentContent(byte[] documentContent) {
		this.documentContent = documentContent;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
