package com.citigroup.cgti.c3par.bpm.ejb.manageactivity;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.nsroot.eur.servicesolutions.cate.integration.ArrayOfPurchaseOptionDescription;
import net.nsroot.eur.servicesolutions.cate.integration.DataFieldUrl;
import net.nsroot.eur.servicesolutions.cate.integration.FulfilmentItem;
import net.nsroot.eur.servicesolutions.cate.integration.MessageTypeEnum;
import net.nsroot.eur.servicesolutions.cate.integration.PurchaseOptionDescription;
import net.nsroot.eur.servicesolutions.cate.integration.PurchaseOptionStatusEnum;
import net.nsroot.eur.servicesolutions.cate.integration.PurchaseOrder;
import net.nsroot.eur.servicesolutions.cate.integration.PurchaseOrderDocument;
import net.nsroot.eur.servicesolutions.cate.integration.Status;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.support.rowset.SqlRowSet;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.C3parTxSession;
import com.citigroup.cgti.c3par.bpm.ejb.domain.ActivityDataDTO;
import com.citigroup.cgti.c3par.ccrcmpmapping.service.CCRCMPMappingService;
import com.citigroup.cgti.c3par.communication.domain.ECMConstants;
import com.citigroup.cgti.c3par.configuation.DatabaseUtil;
import com.citigroup.cgti.c3par.configuation.QueryConstants;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.fw.service.ResolveITQueueSenderImpl;
import com.citigroup.cgti.c3par.oneapproval.OneApprovalPersistable;
import com.citigroup.cgti.c3par.soa.vc.util.OneApprovalConstants;


/**
 * The Class ManageActivityImpl.
 */
@SuppressWarnings( { "static-access"})
public class ManageActivityImpl implements IManageActivity {

    private static final String ANNUAL_CONNECTIVITY_VERIFICATION = "AnnualConnectivityVerification";
    private static final String VERIFY_SOW = "VerifySOW";
    private static final Logger LOGGER = Logger.getLogger(ManageActivityImpl.class);
    
    @Qualifier("jdbcTemplate_ccr")
    @Autowired
    private JdbcTemplate jdbcTemplate;

    /** The c3par session. */
    private C3parSession c3parSession;

    /** The c3par tx session. */
    private C3parTxSession c3parTxSession;
    
    @Autowired
    CCRCMPMappingService ccrCMPMappingService;

    /** The log. */
    
    
    private DatabaseUtil databaseUtil;
    
    private OneApprovalPersistable oneApprovalImpl;
    
    private String ccrUrl;
    
    public OneApprovalPersistable getOneApprovalImpl() {
        return oneApprovalImpl;
    }

    public void setOneApprovalImpl(OneApprovalPersistable oneApprovalImpl) {
        this.oneApprovalImpl = oneApprovalImpl;
    }
    

    public DatabaseUtil getDatabaseUtil() {
        return databaseUtil;
    }

    public void setDatabaseUtil(DatabaseUtil databaseUtil) {
        this.databaseUtil = databaseUtil;
    }

    /**
     * Sets the c3par session.
     *
     * @param session the new c3par session
     */
    public void setC3parSession(C3parSession session) {
        c3parSession = session;
    }

    /**
     * Sets the c3par tx session.
     *
     * @param txSession the new c3par tx session
     */
    public void setC3parTxSession(C3parTxSession txSession) {
        c3parTxSession = txSession;
    }
    
    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }
    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#logActivity(com.citigroup.cgti.c3par.bpm.ejb.domain.ActivityDataDTO, long, java.lang.String)
     */
    public long  logActivity(ActivityDataDTO activityDataDTO ,long tiRequestId,String bpmInstanceId)throws Exception {
        LOGGER.info("Ti Request Id:"+tiRequestId+"Bpm Instance Id:"+bpmInstanceId+"Activity Status:"+activityDataDTO.getActivityCode());
        
        
        long activityTrailId=-1;
    
        String processMode=ActivityDataDTO.IS_NEW;

        try {
            int tiTaskId = getTITaskId(activityDataDTO.getActivityCode());
            if(tiTaskId == 0){
                throw new Exception("Business Exception : Unknown Task Name "+activityDataDTO.getActivityCode() );
            }
            //con = c3parSession.getConnection();
            
            // storing start process activity in ti_activty_trail- activityphase(meaning datacollection/approval) would be  null,activity type(Approval/Provide Info)- will be null,Activity name will be
            // 'Start Process' and the activitystatus will be 'completed '
            if (activityDataDTO.getActivityCode().equals(ActivityData.ACTIVITY_START_PROCESS)||
                    activityDataDTO.getActivityCode().equals(ActivityData.ACTIVITY_ACTIVE)||
                    activityDataDTO.getActivityCode().equals(ActivityData.ACTIVITY_TERMINATED)||
                    activityDataDTO.getActivityCode().equals(ActivityData.ACTIVITY_ABORTED) ||
                    activityDataDTO.getActivityCode().equals(ActivityData.ACTIVITY_MANAGE_USER_CONTACTS_START_PROCESS)) {           
                StringBuilder instStartProcSQL = new StringBuilder();
                instStartProcSQL.append(" insert into c3par.ti_activity_trail (id,ti_request_id,activity_id,activity_status,user_role_id,user_id,activity_startdate,activity_enddate,activity_mode) values ");
                instStartProcSQL.append(" ( c3par.seq_ti_activity_trail.nextval,?,?,?,(select id from c3par.role where display_name=(select display_name from c3par.security_role where name=?)),(select id from c3par.c3par_users where sso_id like ?),SYSDATE,SYSDATE,?)");
                
                
//              pStmt = con.prepareStatement(instStartProcSQL.toString());
//              pStmt.setLong(1, tiRequestId);
//              pStmt.setInt(2, tiTaskId);
//              pStmt.setString(3, ActivityData.STATUS_COMPLETED);
//          
//              
//              if(activityDataDTO.getActivityCode().equals(ActivityData.ACTIVITY_ACTIVE)||
//                      activityDataDTO.getActivityCode().equals(ActivityData.ACTIVITY_TERMINATED)||activityDataDTO.getActivityCode().equals(ActivityData.ACTIVITY_ABORTED))
//                  pStmt.setString(3, ActivityData.STATUS_END);
//              
//              
//              pStmt.setString(4, activityDataDTO.getUserRole());
//              pStmt.setString(5, activityDataDTO.getUserID());
//              pStmt.setString(6, ActivityDataDTO.IS_NEW);
//              pStmt.executeUpdate();
                
                
                
                String thirdParameter = ActivityData.STATUS_COMPLETED;
                if(activityDataDTO.getActivityCode().equals(ActivityData.ACTIVITY_ACTIVE)||
                        activityDataDTO.getActivityCode().equals(ActivityData.ACTIVITY_TERMINATED)||activityDataDTO.getActivityCode().equals(ActivityData.ACTIVITY_ABORTED)){
                    thirdParameter = ActivityData.STATUS_END;
                }
                    
                Object[] parameters = { tiRequestId,tiTaskId,thirdParameter, activityDataDTO.getUserRole(), activityDataDTO.getUserID() ,ActivityDataDTO.IS_NEW};
                int[] types = { Types.BIGINT,Types.INTEGER, Types.VARCHAR,  Types.VARCHAR, Types.VARCHAR ,Types.VARCHAR};
                int rowsUpdated = jdbcTemplate.update(String.valueOf(instStartProcSQL), parameters, types);
                LOGGER.debug("jdbc template rowsUpdated::" + rowsUpdated);
                
                
                
                } else {
                //Only if their is an activity with status as completed or rejected the mode should be set to rework
                // otherwise override the mode to new
                    
                String mode = activityDataDTO.getActivityMode();
                String processActModeSQL=" select process_activity_mode from c3par.ti_process where id=(select process_id from c3par.ti_request where id=?)";
//
//              pStmt = con.prepareStatement(processActModeSQL);
//              pStmt.setLong(1, tiRequestId);
//              rs=pStmt.executeQuery();
//              if (rs != null && rs.next()) {
//                  processMode = rs.getString(1);
//              }
//
//              c3parSession.closeStatement( pStmt );
//              c3parSession.closeResultSet(rs);
                
                

                final Long tiReq = tiRequestId;
                processMode = jdbcTemplate.query(processActModeSQL, new PreparedStatementSetter() {
                                    @Override
                                    public void setValues(PreparedStatement preparedStatement) throws SQLException {
                                        preparedStatement.setLong(1, tiReq);
                                    }
                                }, new ResultSetExtractor<String>() {
                                    @Override
                                    public String extractData(ResultSet resultSet) throws SQLException, DataAccessException {
                                        //note that if resultset.next should be replaced with if and not while. 
                                        // if returns the first row ,while returns the last row. 
                                       if (resultSet.next()) {
                                            String processMode = resultSet.getString(1);
                                            return processMode;
                                        }else{
                                            return null;
                                        }
                                        
                                    }
                                });
                LOGGER.debug("Process Mode obtained from jdbcTemplatte = "+processMode+" :: For tiReq = "+tiReq);                
                 
                 
                 

                if(processMode!=null && !processMode.equalsIgnoreCase(ActivityDataDTO.IS_RECONSILE)){
                
                    
                    String reworkSQL=" select id from c3par.ti_activity_trail where activity_id=? and ti_request_id=? and (activity_status!=? or  activity_status!=?)";
                    
//                  pStmt = con.prepareStatement(reworkSQL);
//                  pStmt.setLong(1, tiTaskId);
//                  pStmt.setLong(2,tiRequestId);
//                  pStmt.setString(3, ActivityDataDTO.STATUS_UNLOCK);
//                  pStmt.setString(4, ActivityDataDTO.STATUS_EXTENDED);
//                  rs=pStmt.executeQuery();
//                  if (rs != null && rs.next()) {
//                      processMode=ActivityDataDTO.IS_REWORK;
//                  }else
//                      processMode=ActivityDataDTO.IS_NEW;
    
                    
                
                    
                    final int fnl_tiTaskId_query2 = tiTaskId;
                    final Long fnl_tiReqId_query2 = tiRequestId;
                    Integer returnedId = jdbcTemplate.query(reworkSQL, new PreparedStatementSetter() {
                                        @Override
                                        public void setValues(PreparedStatement preparedStatement) throws SQLException {
                                            
                                            preparedStatement.setInt(1, fnl_tiTaskId_query2);
                                            preparedStatement.setLong(2,fnl_tiReqId_query2);
                                            preparedStatement.setString(3, ActivityDataDTO.STATUS_UNLOCK);
                                            preparedStatement.setString(4, ActivityDataDTO.STATUS_EXTENDED);
                                        }
                                    }, new ResultSetExtractor<Integer>() {
                                        @Override
                                        public Integer extractData(ResultSet resultSet) throws SQLException, DataAccessException {
                                           if (resultSet.next()) {
                                                return resultSet.getInt(1);
                                                
                                            }else{
                                                return -1;
                                            }
                                            
                                        }
                                    });
                    
                    if (returnedId != null && returnedId>0) {
                        processMode=ActivityDataDTO.IS_REWORK;
                    }else
                        processMode=ActivityDataDTO.IS_NEW;
                    
                    LOGGER.debug("Process Mode obtained from jdbcTemplate = "+processMode+" :: For tiReq = "+tiReq);
                    
                }
                
                
                
                
                
                if(ActivityDataDTO.TYPE_PROVIDEINFO == activityDataDTO.getActivityType())
                    mode=ActivityDataDTO.IS_NEW;
                else
                    mode=processMode;
            
                //c3parSession.closeStatement( pStmt );  
                
                LOGGER.debug(" Process Mode set to while logging activity "+processMode);
                Date lockedTaskStartDate = null;
                                
                StringBuilder instActivitySQl = new StringBuilder(" insert into c3par.ti_activity_trail (id,ti_request_id,activity_stage,activity_id,activity_type");

                instActivitySQl.append(",activity_status,user_role_id,infouser_role_id,activity_mode,activity_startdate,bpm_instance_id,pi_requested_activity)");
                instActivitySQl.append(" values (c3par.seq_ti_activity_trail.nextval,?,?,?,?,?,(select id from c3par.role where display_name=(select display_name from c3par.security_role where name=?)),(select id from c3par.role where name=?),?,?,? " +
                                        " ,(select tat.id from c3par.ti_activity_trail tat,c3par.ti_task_type ttt where tat.ACTIVITY_ID=ttt.id and ttt.TASK_CODE=? and tat.ACTIVITY_STATUS= ? and tat.TI_REQUEST_ID=?))");

                

//              pStmt = con.prepareStatement(instActivitySQl.toString());
//              pStmt.setLong(1, tiRequestId);
//              pStmt.setString(2, activityDataDTO.getActivityStage());
//              pStmt.setInt(3, tiTaskId);
//              pStmt.setString(4, activityDataDTO.getActivityType());
//              pStmt.setString(5, ActivityDataDTO.STATUS_SCHEDULED);
//              pStmt.setString(6, activityDataDTO.getUserRole());
//              pStmt.setString(7, activityDataDTO.getInfoUserRole());
//              pStmt.setString(8, mode);
//              if(lockedTaskStartDate!=null){
//
//                  pStmt.setTimestamp(9, new java.sql.Timestamp(lockedTaskStartDate.getTime()));
//              }else
//                  pStmt.setTimestamp(9, new java.sql.Timestamp(new Date().getTime()));
//              pStmt.setString(10, bpmInstanceId);
//              if(activityDataDTO.getPrInfoActivityDataDTO()!=null){
//                  pStmt.setString(11,activityDataDTO.getPrInfoActivityDataDTO().getActivityCode());
//              pStmt.setString(12, ActivityDataDTO.STATUS_PROVIDEINFO);
//              }
//              else{
//              pStmt.setString(11,null);
//              pStmt.setString(12, null);
//              }
//
//              pStmt.setLong(13,tiRequestId);
                
                final ActivityDataDTO fnl_query3_activiDataDTO = activityDataDTO;
                final Long fnl_query3_tiRequestId = tiRequestId;
                
                final int fnl_query3_taskId = tiTaskId;
                final String fnl_query3_mode = mode;
                final Date fnl_query3_lockedTaskStartDate = lockedTaskStartDate;
                final String fnl_query3_bpmInstanceId = bpmInstanceId;
                Integer returnedId = jdbcTemplate.update(String.valueOf(instActivitySQl), new PreparedStatementSetter() {
                    @Override
                    public void setValues(PreparedStatement preparedStatement) throws SQLException {
                        
                        preparedStatement.setLong(1, fnl_query3_tiRequestId);
                        preparedStatement.setString(2, fnl_query3_activiDataDTO.getActivityStage());
                        preparedStatement.setInt(3, fnl_query3_taskId);
                        preparedStatement.setString(4, fnl_query3_activiDataDTO.getActivityType());
                        preparedStatement.setString(5, ActivityDataDTO.STATUS_SCHEDULED);
                        preparedStatement.setString(6, fnl_query3_activiDataDTO.getUserRole());
                        preparedStatement.setString(7, fnl_query3_activiDataDTO.getInfoUserRole());
                        preparedStatement.setString(8, fnl_query3_mode);
                        if( fnl_query3_lockedTaskStartDate!=null){

                            preparedStatement.setTimestamp(9, new java.sql.Timestamp( fnl_query3_lockedTaskStartDate.getTime()));
                        }else
                            preparedStatement.setTimestamp(9, new java.sql.Timestamp(new Date().getTime()));
                        preparedStatement.setString(10, fnl_query3_bpmInstanceId);
                        if(fnl_query3_activiDataDTO.getPrInfoActivityDataDTO()!=null){
                            preparedStatement.setString(11,fnl_query3_activiDataDTO.getPrInfoActivityDataDTO().getActivityCode());
                        preparedStatement.setString(12, ActivityDataDTO.STATUS_PROVIDEINFO);
                        }
                        else{
                            preparedStatement.setString(11,null);
                            preparedStatement.setString(12, null);
                        }

                        preparedStatement.setLong(13,fnl_query3_tiRequestId);

                    }
                }) ;
                LOGGER.debug("jdbc template rowsUpdated::" + returnedId);
                
                
//              pStmt.executeUpdate();
//              c3parSession.closeStatement( pStmt );
                 
                //85300 - Added for Pc Provide Info - ECM mail flow
                LOGGER.debug("Activity Type: " + activityDataDTO.getActivityType() + "Activity Code: " + activityDataDTO.getActivityCode());
                if(ECMConstants.PC_PROVIDE_INFO.equals(activityDataDTO.getActivityCode())) {
                    int pcProCom = getTITaskId(ECMConstants.PC_PROVIDE_INFO_ECM);
                    Object[] params = new Object[] {tiRequestId, null, pcProCom, activityDataDTO.getActivityType(), ActivityDataDTO.STATUS_STARTED, activityDataDTO.getUserRole(), 
                            activityDataDTO.getInfoUserRole(), mode, new java.sql.Timestamp(new Date().getTime()), null, null, null, tiRequestId};
                    int n = jdbcTemplate.update(String.valueOf(instActivitySQl),params);                   
                    LOGGER.debug("Rows updaetd : " + n);
                }
                //85300 - Code end
                
                //Added for Communication Module - DK64387
                if(processMode != null && activityDataDTO.getActivityType()!=null && activityDataDTO.getActivityCode() !=null &&
                        ((processMode.equals(ActivityDataDTO.IS_REWORK) && activityDataDTO.getActivityCode().equalsIgnoreCase("bus_jus"))
                        || (activityDataDTO.getActivityType().equalsIgnoreCase(ActivityDataDTO.TYPE_PROVIDEINFO) 
                        && activityDataDTO.getActivityCode().equalsIgnoreCase("pro_inf")))){
                    
                    
                    String status = getReworkStatus(tiRequestId, tiTaskId);                 
                                
                    if (!(ActivityData.STATUS_UNLOCK.equals(status) 
                            || ActivityData.STATUS_EXTENDED.equals(status))) {
                        ccrCMPMappingService.logECMActivityTrail(tiRequestId);
                        }
                    }
                //End of Communication Module - DK64387
                }
            
                 //update process status
                StringBuilder processUpdateSql = new StringBuilder();
                    processUpdateSql.append(" update ti_process SET process_activity_mode=? where id =(select process_id from ti_request where id=?)");
                    
                    
                    
                    LOGGER.debug(" Run with values tiRequestID = " + tiRequestId );

//                  pStmt = con.prepareStatement(processUpdateSql.toString());
//                  pStmt.setString(1, processMode);
//                  pStmt.setLong(2, tiRequestId);
//                  pStmt.executeUpdate();
                
                    
                    final String fnl_query4_processMode = processMode;
                    final Long fnl_query4_tiRequestId = tiRequestId;
                    Integer returnedId = jdbcTemplate.update(String.valueOf(processUpdateSql), new PreparedStatementSetter() {
                        @Override
                        public void setValues(PreparedStatement preparedStatement) throws SQLException {
                            
                            preparedStatement.setString(1, fnl_query4_processMode);
                            preparedStatement.setLong(2, fnl_query4_tiRequestId);
                           

                        }
                    }) ;
                    LOGGER.debug("jdbc template rowsUpdated::" + returnedId);
                    
                    
                    
                    String prInfoReqActDTO=null;
                    if(activityDataDTO.getPrInfoActivityDataDTO()!=null)
                        prInfoReqActDTO=activityDataDTO.getPrInfoActivityDataDTO().getActivityCode();
                    activityTrailId=getScheduledActivityTralId(tiRequestId,activityDataDTO.getActivityCode(), prInfoReqActDTO);
                    
                    
                    LOGGER.info("Activity code for checking isTemplateAborted:-"+activityDataDTO.getActivityCode());
                    
                    if(activityDataDTO.getActivityCode().equals(ActivityData.ACTIVITY_ABORTED))
                    {
                        Long processId = Long.valueOf(databaseUtil.getConnectionId(tiRequestId));
                        
                        LOGGER.info("Connection Id for checking isTemplateAborted:-"+processId);
                        
                        boolean isTemplateAborted = databaseUtil.isTemplateAborted(processId);
                        
                        LOGGER.info("isTemplateAborted status for checking isTemplateAborted:-"+isTemplateAborted);
                        
                        if(isTemplateAborted)
                        {
                            LOGGER.info("checking isTemplateAborted started:-"+new Date());
                            databaseUtil.revertTemplateRulesToImplementedVersion(processId);
                            LOGGER.info("checking isTemplateAborted Completed:-"+new Date());
                        }
                    }

        } catch (Exception e) {
            LOGGER.error("Exception in logActivity : "+e, e);
            throw new RemoteException(e.getMessage());
        } finally {
            LOGGER.info("activityTrailId : "+activityTrailId);
        }       
        
    return activityTrailId;
    }

 /* (non-Javadoc)
  * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#addActivity(com.citigroup.cgti.c3par.domain.ActivityData, long)
  */
 public long addActivity(ActivityData activityData, long tiRequestId) throws Exception {
     LOGGER.info("tiRequestId : "+tiRequestId);
        long rowsInserted = -1;
        
        try {
            validate(activityData, tiRequestId);
            int tiTaskId = getTITaskId(activityData.getActivityName());
            
            if(tiTaskId == 0){
                throw new Exception("Business Exception : Unknown Task Name "+activityData.getActivityName() );
            }
        

            // storing start process activity in ti_activty_trail-
            // activityphase(meaning datacollection/approval) would be
            // null,activity
            // type(Approval/Provide Info)- will be null,Activity name will be
            // 'Start Process' and the activitystatus will be 'completed '
            if (activityData.getActivityName().equals(ActivityData.ACTIVITY_START_PROCESS)||activityData.getActivityName().equals(ActivityData.ACTIVITY_ACTIVE)||activityData.getActivityName().equals(ActivityData.ACTIVITY_TERMINATED) ||activityData.getActivityName().equals(ActivityData.ACTIVITY_MANAGE_USER_CONTACTS_START_PROCESS)) {
                StringBuilder instStartProcSQL = new StringBuilder();

                instStartProcSQL
                        .append(" insert into c3par.ti_activity_trail (id,ti_request_id,activity_id,activity_status,user_role_id,user_id,activity_startdate,activity_enddate,activity_mode) values ");
                instStartProcSQL
                        .append(" ( c3par.seq_ti_activity_trail.nextval,?,?,?,(select id from c3par.role where name=?),(select id from c3par.c3par_users where sso_id like ?),SYSDATE,SYSDATE,?)");
                
//              pStmt = con.prepareStatement(instStartProcSQL.toString());
//              pStmt.setLong(1, tiRequestId);
//              pStmt.setInt(2, tiTaskId);
//              //pStmt.setString(3, ActivityData.STATUS_SCHEDULED);
//              pStmt.setString(3, ActivityData.STATUS_COMPLETED);
//              if(activityData.getActivityName().equals(ActivityData.ACTIVITY_ACTIVE)||activityData.getActivityName().equals(ActivityData.ACTIVITY_TERMINATED))
//                  pStmt.setString(3, ActivityData.STATUS_END);
//              pStmt.setString(4, activityData.getUserRole());
//              pStmt.setString(5, activityData.getUserID());
//              pStmt.setString(6, ActivityData.IS_NEW);
//
//              rowsInserted = pStmt.executeUpdate();
//              c3parSession.closeStatement( pStmt );
                
                
                


            final Long fnl_query1_tiRequestId = tiRequestId;
            final int fnl_query1_tiTaskId = tiTaskId;
            final ActivityData fnl_query1_activityDataDto = activityData;
                
                Integer returnedId = jdbcTemplate.update(String.valueOf(instStartProcSQL), new PreparedStatementSetter() {
                    
                    @Override
                    public void setValues(PreparedStatement preparedStatement) throws SQLException {
                        preparedStatement.setLong(1, fnl_query1_tiRequestId);
                    preparedStatement.setInt(2, fnl_query1_tiTaskId);
                    //pStmt.setString(3, ActivityData.STATUS_SCHEDULED);
                    preparedStatement.setString(3, ActivityData.STATUS_COMPLETED);
                    if(fnl_query1_activityDataDto.getActivityName().equals(ActivityData.ACTIVITY_ACTIVE)||fnl_query1_activityDataDto.getActivityName().equals(ActivityData.ACTIVITY_TERMINATED))
                        preparedStatement.setString(3, ActivityData.STATUS_END);
                    preparedStatement.setString(4, fnl_query1_activityDataDto.getUserRole());
                    preparedStatement.setString(5, fnl_query1_activityDataDto.getUserID());
                    preparedStatement.setString(6, fnl_query1_activityDataDto.IS_NEW);
                    }
                }) ;
                LOGGER.debug("jdbc template rowsUpdated::" + returnedId);
                
                
                
                
            } else {
                //Only if their is an activity with status as completed or rejected the mode should be set to rework
                // otherwise override the mode to new
                String mode = activityData.getActivityMode();

                Date lockedTaskStartDate=null;
                if(mode.equals(ActivityData.IS_REWORK)){
                  long activityId = getReworkActivity(tiRequestId,tiTaskId);
                  if(activityId == 0){
                      mode=ActivityData.IS_NEW;
                  }
                }
                if(activityData.getId()!=null){
                    lockedTaskStartDate=getStartDateForLockedTask(activityData.getId().longValue());
                }

                // to insert
                // requestid,activityphase,activityid,activitytype,activitystatus,userrole,infouserrole,activtymode
                StringBuilder instActivitySQl = new StringBuilder(
                        " insert into c3par.ti_activity_trail (id,ti_request_id,activity_stage,activity_id,activity_type");

                instActivitySQl
                        .append(",activity_status,user_role_id,infouser_role_id,activity_mode");
                                if(lockedTaskStartDate!=null)
                                    instActivitySQl.append(",activity_startdate");
                                instActivitySQl.append(") values (c3par.seq_ti_activity_trail.nextval,?,?,?,?,?,(select id from c3par.role where name=?),(select id from c3par.role where name=?),?");
                                if(lockedTaskStartDate!=null)
                                    instActivitySQl.append(",?");
                                    instActivitySQl.append(")");


                LOGGER.debug("insert activity sql = "+instActivitySQl.toString());

//              pStmt = con.prepareStatement(instActivitySQl.toString());
//              pStmt.setLong(1, tiRequestId);
//              pStmt.setString(2, activityData.getActivityStage());
//              pStmt.setInt(3, tiTaskId);
//              pStmt.setString(4, activityData.getActivityType());
//              if(ActivityData.STATUS_UNLOCK.equals(activityData.getActivityStatus())||ActivityData.STATUS_UNLOCK.equals(ActivityData.STATUS_EXTENDED))
//                  pStmt.setString(5, activityData.STATUS_SCHEDULED);
//              else
//                  pStmt.setString(5, activityData.getActivityStatus());
//              pStmt.setString(6, activityData.getUserRole());
//              pStmt.setString(7, activityData.getInfoUserRole());
//              pStmt.setString(8, mode);
//              if(lockedTaskStartDate!=null){
//                  pStmt.setTimestamp(9, new java.sql.Timestamp(lockedTaskStartDate.getTime()));
//              }
//
//              rowsInserted = pStmt.executeUpdate();
                
                
                
                final Long fnl_query2_tiRequestId = tiRequestId;
                final int fnl_query1_tiTaskId = tiTaskId;
                final ActivityData fnl_query2_activityDataDto = activityData;
                    final String fnl_query2_mode = mode;
                    final Date fnl_query2_lockedTaskStartDate=lockedTaskStartDate;
                    Integer numberOfRowsInserted = jdbcTemplate.update(String.valueOf(instActivitySQl), new PreparedStatementSetter() {
                        
                        @Override
                        public void setValues(PreparedStatement preparedStatement) throws SQLException {
                            preparedStatement.setLong(1, fnl_query2_tiRequestId);
                            preparedStatement.setString(2, fnl_query2_activityDataDto.getActivityStage());
                            preparedStatement.setInt(3, fnl_query1_tiTaskId);
                            preparedStatement.setString(4, fnl_query2_activityDataDto.getActivityType());
                                if(ActivityData.STATUS_UNLOCK.equals(fnl_query2_activityDataDto.getActivityStatus())||ActivityData.STATUS_UNLOCK.equals(ActivityData.STATUS_EXTENDED))
                                    preparedStatement.setString(5, fnl_query2_activityDataDto.STATUS_SCHEDULED);
                                else
                                    preparedStatement.setString(5, fnl_query2_activityDataDto.getActivityStatus());
                                preparedStatement.setString(6, fnl_query2_activityDataDto.getUserRole());
                                preparedStatement.setString(7, fnl_query2_activityDataDto.getInfoUserRole());
                                preparedStatement.setString(8, fnl_query2_mode);
                                if(fnl_query2_lockedTaskStartDate!=null){
                                    preparedStatement.setTimestamp(9, new java.sql.Timestamp(fnl_query2_lockedTaskStartDate.getTime()));
                                }}
                    }) ;
                    LOGGER.debug("jdbc template rowsUpdated::" + numberOfRowsInserted);
                    
                
                
                
                
                
                
                
                
                
            }
            if (activityData.getActivityName().equals(ActivityData.ACTIVITY_ACTIVE)||activityData.getActivityName().equals(ActivityData.ACTIVITY_TERMINATED) ) {                
                _notifyResolveIT(activityData.getActivityName(),tiRequestId);               
            }

        } catch (Exception e) {
            LOGGER.error("Exception in addActivity : "+e, e);
            throw new RemoteException(e.getMessage());
        } finally {
            
            if (rowsInserted > 0)
                LOGGER.info("Sucessfully inserted Activity "
                        + activityData.getActivityName() + " for Request Id "
                        + tiRequestId);
            else
                LOGGER.error("Could not Insert Activity "
                        + activityData.getActivityName() + " for Request Id "
                        + tiRequestId);
            
        }
        

        return rowsInserted;
    }

    /**
     * Gets the rework activity.
     *
     * @param tiRequestId the ti request id
     * @param tiTaskId the ti task id
     * @return the rework activity
     * @throws Exception the exception
     */
    private long getReworkActivity(final long tiRequestId,final int tiTaskId) throws Exception{
        LOGGER.info("tiRequestId :"+tiRequestId+" , tiTaskId : "+tiTaskId);
        
        Long activityId =0L;
        try{
            StringBuffer activitySQL = new StringBuffer();
            activitySQL
                    .append(" select max(tat.id) from c3par.ti_activity_trail tat " );
            activitySQL
                    .append(" where  tat.ti_request_id=? and  activity_id=? and (activity_status='COMPLETED' or activity_status='REJECTED')");
            activitySQL
                .append(" Group by ti_request_id");

//          con = c3parSession.getConnection();
//          
//          ps = con.prepareStatement(activitySQL.toString());
//          ps.setLong(1, tiRequestId);
//          ps.setInt(2, tiTaskId);
//          rs = ps.executeQuery();
//          
//          
//          if (rs != null && rs.next()) {
//              activityId = rs.getLong(1);
//          }
            
            
            
            activityId = jdbcTemplate.query(String.valueOf(activitySQL), new PreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement preparedStatement) throws SQLException {
                    preparedStatement.setLong(1, tiRequestId);
                    preparedStatement.setInt(2, tiTaskId);
                }
            }, new ResultSetExtractor<Long>() {
                @Override
                public Long extractData(ResultSet resultSet) throws SQLException, DataAccessException {
                    
                    if (resultSet.next()) {
                       return resultSet.getLong(1);
                    }else{
                        return 0L;
                    }
                    
                }
            });
            
            
            
        } finally {
            LOGGER.info("tiRequestId :"+tiRequestId+" , tiTaskId : "+tiTaskId+" : activityId = "+activityId);
            
        }
        return activityId;
    }
    
    /**
     * Gets the rework activity.
     *
     * @param tiRequestId the ti request id
     * @param tiTaskId the ti task id
     * @return the rework activity
     * @throws Exception the exception
     */
    private String getReworkStatus(final long tiRequestId,final int tiTaskId) throws Exception{
        LOGGER.info("tiRequestId :"+tiRequestId+" , tiTaskId : "+tiTaskId);
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs=null;
        String activityStatus="";
        try{
            StringBuffer activitySQL = new StringBuffer();
            activitySQL
                    .append("select activity_status from c3par.ti_activity_trail where id = (select max(tat.id) from c3par.ti_activity_trail tat  " );
            activitySQL
                    .append(" where  tat.ti_request_id=? and activity_id=? and activity_status!='SCHEDULED')");

//          con = c3parSession.getConnection();
//          
//          ps = con.prepareStatement(activitySQL.toString());
//          ps.setLong(1, tiRequestId);
//          ps.setInt(2, tiTaskId);
//          rs = ps.executeQuery();
//          if (rs != null && rs.next()) {
//              activityStatus = rs.getString(1);
//          }
//          
            
            
            
            
            activityStatus = jdbcTemplate.query(String.valueOf(activitySQL), new PreparedStatementSetter() {
                    @Override
                    public void setValues(PreparedStatement preparedStatement) throws SQLException {
                        preparedStatement.setLong(1, tiRequestId);
                        preparedStatement.setInt(2, tiTaskId);
                    }
                }, new ResultSetExtractor<String>() {
                    @Override
                    public String extractData(ResultSet resultSet) throws SQLException, DataAccessException {
                        
                        if (resultSet.next()) {
                           return resultSet.getString(1);
                        }else{
                            return "";
                        }
                        
                    }
                });
        } finally {
            try {
                if (rs != null)
                    rs.close();
                if (ps != null)
                    ps.close();
                if (con != null) {
                    c3parSession.releaseConnection();
                }
            } catch (Exception exp) {
                LOGGER.error("Failed to close connection : "+exp, exp);
            }
        }
        return activityStatus;
    }


    /**
     * Validate.
     *
     * @param activityData the activity data
     * @param tiRequestId the ti request id
     * @throws Exception the exception
     */
    private void validate(ActivityData activityData, long tiRequestId)
            throws Exception {
        LOGGER.info("tiRequestId :"+tiRequestId);
        StringBuffer errMsg = new StringBuffer();

        if (activityData == null)
            errMsg.append("ActivityData is Null");

        if (tiRequestId <= 0)
            errMsg.append("Invalid Request Id " + tiRequestId);
        if (activityData != null) {
            if (activityData.getActivityName() == null || !isString(activityData.getActivityName())) {
                errMsg.append("ActivityName is Empty");
            }
            // check for remaing activity data validations if activtyname is not
            // begin process
            if (activityData.getActivityName() != null
                    &&( !ActivityData.ACTIVITY_START_PROCESS
                            .equalsIgnoreCase(activityData.getActivityName())&& !ActivityData.ACTIVITY_ACTIVE
                            .equalsIgnoreCase(activityData.getActivityName()) && !ActivityData.ACTIVITY_TERMINATED
                            .equalsIgnoreCase(activityData.getActivityName()) && !ActivityData.ACTIVITY_ABORTED
                            .equalsIgnoreCase(activityData.getActivityName())) && !ActivityData.ACTIVITY_REJECTED
                            .equalsIgnoreCase(activityData.getActivityName()) && !ActivityData.ACTIVITY_ROLLEDBACK
                            .equalsIgnoreCase(activityData.getActivityName()) && !ActivityData.ACTIVITY_MANAGE_USER_CONTACTS
                            .equalsIgnoreCase(activityData.getActivityName()) && !ActivityData.ACTIVITY_MANAGE_USER_CONTACTS_START_PROCESS
                            .equalsIgnoreCase(activityData.getActivityName())) {
                if (!isString(activityData.getActivityStage())) {
                    errMsg.append("ActivityStage is Empty");
                }
                if (!isString(activityData.getActivityType())) {
                    errMsg.append(" ActivityType is Empty");
                }
                if (!isString(activityData.getActivityStatus())) {
                    errMsg.append(" ActivityStatus is Empty");
                }

                if (isString(activityData.getActivityType()) && ActivityData.TYPE_APPROVAL.equalsIgnoreCase(activityData
                        .getActivityType()) && !isString(activityData.getUserRole())) {
                        errMsg.append(" Approval Activties require UserRole to be set. Check data User Role "
                                        + activityData.getUserRole());
                }else if (isString(activityData.getActivityType()) && ActivityData.TYPE_PROVIDEINFO
                            .equalsIgnoreCase(activityData.getActivityType()) && !isString(activityData.getInfoUserRole())) {
                            errMsg
                                    .append(" Provide Info Activtiy requires InfouserRole to be set. Check data User Role "
                                            + activityData.getInfoUserRole());
                }
            } else {
                // For start pser process activity user role is required
                // startProcess = true;
                if (!isString(activityData.getUserRole()))
                    errMsg.append(" User Role is Required for Start Process");
            }
        }


        if (errMsg.length() > 0) {
            LOGGER.error(errMsg.toString());
            throw new Exception("Business Exception : "
                    + errMsg.toString());
        }
    }


/**
 * Gets the tI task id.
 *
 * @param activityName the activity name
 * @return the tI task id
 * @throws Exception the exception
 */
private int getTITaskId(final String activityName) throws Exception {
    LOGGER.info("ActivityName :"+activityName);
        Connection con = null;
        ResultSet rs = null;
        PreparedStatement pStmt = null;
        int activityId = 0;
        try {
            String taskSQL = "select id from c3par.ti_task_type where task_code= ?";
            
//          con = c3parSession.getConnection();
//          pStmt = con.prepareStatement(taskSQL.toString());
//          pStmt.setString(1, activityName);
//          rs = pStmt.executeQuery();
//          if (rs != null) {
//              while (rs.next())
//                  activityId = rs.getInt(1);
//          }
//
//          if (activityId == 0) {
//              throw new Exception(
//                      "No Activity Id associated with Activity Name "
//                              + activityName);
//          }
//          
            
            activityId = jdbcTemplate.query(taskSQL, new PreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement preparedStatement) throws SQLException {
                    preparedStatement.setString(1, activityName);
                }
            }, new ResultSetExtractor<Integer>() {
                @Override
                public Integer extractData(ResultSet resultSet) throws SQLException, DataAccessException {
                    
                    if (resultSet.next()) {
                       return resultSet.getInt(1);
                    }else{
                        return 0;
                    }
                    
                }
            });
            
            if (activityId == 0) {
                throw new Exception(
                        "No Activity Id associated with Activity Name "
                                + activityName);
            }
            
        } finally {
            try {
                if(rs != null)
                    rs.close();
                if (pStmt != null)
                    pStmt.close();
                if (con != null) {
                    c3parSession.releaseConnection();
                }
            } catch (Exception exp) {
                LOGGER.error("Failed to close connection : "+exp, exp);
            }
        }
        return activityId;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#scheduleActivity(long, java.lang.String)
     */
    public long scheduleActivity(final long activityID, final String bpmInstanceId) throws Exception {
        LOGGER.info("activityID :"+activityID);
        long rowsUpdated = -1;
        if (activityID <= 0) {
            LOGGER.error("Invalid Activity ID " + activityID);
            throw new RemoteException(
                    "Business Exception : Invalid Activity ID ");
        }
        Connection con = null;
        ResultSet rs=null;
        PreparedStatement pStmt = null;
        boolean startDateExisits=false;
        try {
            con = c3parSession.getConnection();
            String activityDetailsSQl=" select activity_startdate from c3par.ti_activity_trail where id=?";
//          pStmt = con.prepareStatement(activityDetailsSQl.toString());
//          pStmt.setLong(1, activityID);
//          rs = pStmt.executeQuery();
//          if(rs!=null){
//              while(rs.next()){
//                  if (rs.getDate(1)!=null)
//                  startDateExisits=true;
//              }
//          }
//          
            
            
            startDateExisits = jdbcTemplate.query(activityDetailsSQl, new PreparedStatementSetter() {
                @Override
                public void setValues(PreparedStatement preparedStatement) throws SQLException {
                    preparedStatement.setLong(1, activityID);
                }
            }, new ResultSetExtractor<Boolean>() {
                @Override
                public Boolean extractData(ResultSet resultSet) throws SQLException, DataAccessException {
                    
                    if (resultSet.next()) {
                       return true;
                    }else{
                        return false;
                    }
                    
                }
            });
            
            
            c3parSession.closeStatement( pStmt );


            StringBuilder schSQL = new StringBuilder("  update c3par.ti_activity_trail set activity_status=? ");
            if(!startDateExisits)
                schSQL.append(",activity_startdate=SYSDATE " );
            schSQL.append(",bpm_instance_id=? where id=? ");
//
//          pStmt = con.prepareStatement(schSQL.toString());
//          pStmt.setString(1, ActivityData.STATUS_SCHEDULED);
//          pStmt.setString(2, bpmInstanceId);
//          pStmt.setLong(3, activityID);
//          rowsUpdated = pStmt.executeUpdate();
            
            
            
               Integer returnedId = jdbcTemplate.update(String.valueOf(schSQL), new PreparedStatementSetter() {
                   
                   @Override
                   public void setValues(PreparedStatement preparedStatement) throws SQLException {
                       
                       preparedStatement.setString(1, ActivityData.STATUS_SCHEDULED);
                       preparedStatement.setString(2, bpmInstanceId);
                       preparedStatement.setLong(3, activityID);
                   }
               }) ;
               LOGGER.debug("jdbc template rowsUpdated::" + returnedId);
            
            
            notifyResolveIT(activityID, ActivityData.STATUS_SCHEDULED,ActivityData.STATUS_SCHEDULED,ActivityData.STATUS_SCHEDULED);
        } catch (Exception e) {
            LOGGER.error(e);
            throw new RemoteException(e.getMessage());
        } finally {
            c3parSession.closeResultSet(rs);
            c3parSession.closeStatement( pStmt );
            try {
                 
                if (con != null)
                    c3parSession.releaseConnection();
            } catch (Exception exp) {
                LOGGER.error("Failed to close connection : "+exp, exp);
            }
        }
        if (rowsUpdated > 0)
            LOGGER.info("Sucessfully updates status for Activity ID" + activityID);
        else
            LOGGER.error("Could not updates status for Activity ID" + activityID);
        return rowsUpdated;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#lockActivity(long, java.lang.String, boolean)
     */
    public long lockActivity(final long activityTrailId, final String lockedBy,final boolean isForceUnlock) throws Exception {
        LOGGER.info("activityTrailId :"+activityTrailId);
        long rowsUpdated = -1;

        if (activityTrailId <= 0 || !isString(lockedBy)) {
            LOGGER.error(" TIRequestId and lockedBy are required ");
            throw new RemoteException(
                    "Business Exception : TIRequestId ID and lockedBy are required ");
        }
        Connection con = null;
        ResultSet rs=null;
        
        PreparedStatement pStmt = null;
        try {
            con= c3parSession.getConnection();
            
            String lockSQL = new String(
                    " update c3par.ti_activity_trail set lockedby=(select id from c3par.c3par_users where lower(sso_id) like lower(?)) ,locked_date=SYSDATE where id=? and  ( lockedby !=(select id from c3par.c3par_users where lower(sso_id) like lower(?)) or lockedby is null) ");

                pStmt = con.prepareStatement(lockSQL.toString());
                pStmt.setString(1, lockedBy);
                pStmt.setLong(2, activityTrailId);
                pStmt.setString(3, lockedBy);
                rowsUpdated = pStmt.executeUpdate();
                
                
                
                 Integer returnedId = jdbcTemplate.update(lockSQL, new PreparedStatementSetter() {
                       
                       @Override
                       public void setValues(PreparedStatement preparedStatement) throws SQLException {
                           
                           preparedStatement.setString(1, lockedBy);
                           preparedStatement.setLong(2, activityTrailId);
                           preparedStatement.setString(3, lockedBy);
                       }
                   }) ;
                   LOGGER.debug("jdbc template rowsUpdated::" + returnedId);
                
                
                
                
                notifyResolveIT(activityTrailId, lockedBy,"LOCKED","Assigned");
        } catch (Exception e) {
            LOGGER.error("Exception in lockActivity : "+e, e);
            throw new RemoteException(e.getMessage());
        } finally {
            try {
                if (pStmt != null)
                    pStmt.close();
                if (con != null)
                    c3parSession.releaseConnection();
                if(rs!=null)
                    rs.close();
            } catch (Exception exp) {
                LOGGER.error("Failed to close connection : "+exp, exp);
            }
        }
        if (rowsUpdated > 0)
            LOGGER.info("Sucessfully set locked by details  for Activity ID"
                    + activityTrailId + "as locked by " + lockedBy);
        else
            LOGGER.error("Could not  set Locked by Details for Activity ID"
                    + activityTrailId + " as locked by " + lockedBy);
        return rowsUpdated;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#completeActivity(long, java.lang.String, java.lang.String)
     */
    public long completeActivity(final long activityTrailId, String completedBy, String status) throws Exception {
        LOGGER.info("Status:" + status + "CompletedBy:" + completedBy + "activityTrailId:" + activityTrailId);

        long rowsUpdated = -1;

        if (!isString(completedBy)) {
            completedBy = "system";
        }

        if (activityTrailId <= 0 || !isString(completedBy) || !isString(status)) {
            LOGGER.error(" Activity ID, Completed By and Status are required -ActivityTrail ID=" + activityTrailId
                    + ",Completed By=" + completedBy + ",Status=" + status);
            throw new RemoteException(
                    "Business Exception : Activity ID, Completed By and Status are required -ActivityTrail ID="
                            + activityTrailId + ",Completed By=" + completedBy + ",Status=" + status);
        }
        

        try {
        
            StringBuffer completeSQl = null;

            if (ActivityData.STATUS_PROVIDEINFO.equals(status)) {

                completeSQl = new StringBuffer(
                        "  update c3par.ti_activity_trail set activity_status=? , user_id=(select id from c3par.c3par_users where lower(sso_id)=lower('"
                                + completedBy + "')) where id=?");
            } else {
                completeSQl = new StringBuffer(
                        "  update c3par.ti_activity_trail set user_id=(select id from c3par.c3par_users where lower(sso_id)=lower('"
                                + completedBy + "'))");
                completeSQl
                        .append(" ,activity_enddate=SYSDATE ,activity_status=? where id=? and  ACTIVITY_ENDDATE is null ");
                // 85300 - Adding code to check PC Provide Info task is goin to complete
                if (ECMConstants.STATUS_COMPLETED.equals(status)) {
                    SqlRowSet rowSet = jdbcTemplate.queryForRowSet(QueryConstants.CHECK_PC_PRO_INFO_COMPLETING, activityTrailId);
                    if (rowSet.next()) {
                        Long tiRequestId = rowSet.getLong(1);
                        rowsUpdated = jdbcTemplate.update(QueryConstants.COMPLETE_PC_PRO_ECM_ACTIVITY, tiRequestId);
                        LOGGER.debug("Rows Updated: " + rowsUpdated);
                    }
                }
                //85300 - Code End
            }
         

           
            Object[] parameters = { status, activityTrailId };
            //please note, these are sql types - not java types. therefore String is Varchar and Long is Bigint. 
            //It is better to check the db columns and set them accordingly. 
            int[] types = { Types.VARCHAR, Types.BIGINT };
            rowsUpdated = jdbcTemplate.update(String.valueOf(completeSQl), parameters, types);
            LOGGER.debug("jdbc template rowsUpdated::" + rowsUpdated);

            notifyResolveIT(activityTrailId, completedBy, status, status);

            LOGGER.debug("NotifyResolveIT completed..");

            /* Added for Cancel One Approval By NE36745 - Starts */
            ResultSet rs = null;
            
            try {
                LOGGER.debug("OneApproval Cancel functionality started..");
                String activitySQL = "select tat.approval_system, tr.id, tr.process_id, tr.version_number, tat.bpm_instance_id, "
                        + " (select task_code from c3par.ti_task_type where id = tat.activity_id) as task from c3par.ti_activity_trail tat, ti_request tr where tat.ti_request_id = tr.id and tat.id = ?";

                ArrayList result = jdbcTemplate.query(activitySQL, new PreparedStatementSetter() {
                    @Override
                    public void setValues(PreparedStatement preparedStatement) throws SQLException {
                        preparedStatement.setLong(1, activityTrailId);
                    }
                }, new ResultSetExtractor<ArrayList>() {
                    @Override
                    public ArrayList extractData(ResultSet resultSet) throws SQLException, DataAccessException {
                        //This list can contain String or Long in different indices. Be careful when reading the output of this list. 
                        //Each row in this list contains a column from the above query. 6 columns from select query will get converted into a list of size 6.
                        //This has been done because non-final variables cannot be used inside the anonymous function.
                        ArrayList heterogenousList = new ArrayList();
                        if (resultSet.next()) {
                            heterogenousList.add(resultSet.getString(1));
                            heterogenousList.add(resultSet.getLong(2));
                            heterogenousList.add(resultSet.getLong(3));
                            heterogenousList.add(resultSet.getLong(4));
                            heterogenousList.add(resultSet.getString(5));
                            heterogenousList.add(resultSet.getString(6));
                            
                            return heterogenousList;
                        }
                        return null;
                    }
                });
                
                
                String approvalSystem = (String) result.get(0);
                Long tiRequestId = (Long) result.get(1);
                Long conId = (Long) result.get(2);
                Long version = (Long) result.get(3);
                String bpmInstanceId = (String) result.get(4);
                String task = (String) result.get(5);

                LOGGER.debug("OneApproval Cancel functionality : approvalSystem : " + approvalSystem + " tiRequestId : "
                        + tiRequestId + " conId : " + conId + " version : " + version + " bpmInstanceId : "
                        + bpmInstanceId + " task : " + task);

                if (approvalSystem != null
                        && !(approvalSystem.equalsIgnoreCase(OneApprovalConstants.APPROVAL_SYSTEM_OA) || approvalSystem
                                .equalsIgnoreCase(OneApprovalConstants.APPROVAL_SYSTEM_OA))
                        && task != null
                        && (task.equalsIgnoreCase(ActivityData.ACTIVITY_ISO_APP)
                                || task.equalsIgnoreCase(ActivityData.ACTIVITY_VERIFY_SOW)
                                || task.contains(ANNUAL_CONNECTIVITY_VERIFICATION) || task.contains(VERIFY_SOW))) {
                    if (task.equalsIgnoreCase(ActivityData.ACTIVITY_VERIFY_SOW)
                            || task.contains(ANNUAL_CONNECTIVITY_VERIFICATION) || task.contains(VERIFY_SOW)) {
                        oneApprovalImpl.createOneApproval(conId, tiRequestId, bpmInstanceId, version,
                                OneApprovalConstants.ACTIVITY_ACV, true, "");
                    } else {

                        oneApprovalImpl.createOneApproval(conId, tiRequestId, bpmInstanceId, version, null, true,"");
                    }
                } else if (task != null && task.equalsIgnoreCase(ActivityData.ACTIVITY_BUS_JUS)
                        && !ActivityData.STATUS_UNLOCK.equalsIgnoreCase(status)) {
                    String insertSQL = "insert into c3par.ti_activity_trail (id,ti_request_id,activity_id,activity_status, "
                            + " user_role_id,user_id,activity_startdate,activity_enddate,activity_mode) "
                            + " (select seq_ti_activity_trail.nextval,ti_request_id,(select id from c3par.ti_task_type where task_code = 'tec_arc'),?, "
                            + " user_role_id,user_id,activity_startdate,activity_enddate,activity_mode from ti_activity_trail where id = ?)";
                    /*
                     * pStmt = con.prepareStatement(insertSQL);
                     * 
                     * pStmt.setString(1, status); pStmt.setLong(2,
                     * activityTrailId); rowsUpdated = pStmt.executeUpdate();
                     */

                    // replacing preparedstatements with jdbctemplate based
                    // code.
                    Object[] parameters2 = { status, activityTrailId };
                    int[] types2 = { Types.VARCHAR, Types.BIGINT };
                    rowsUpdated = jdbcTemplate.update(String.valueOf(insertSQL), parameters2, types2);
                    LOGGER.debug("jdbc template rowsUpdated::" + rowsUpdated);

                    ccrCMPMappingService.completeECMActivityTrail(tiRequestId);
                } else if (task != null && task.equalsIgnoreCase(ActivityData.ACTIVITY_PC_PRO_INF)
                        && !ActivityData.STATUS_UNLOCK.equalsIgnoreCase(status)) {
                    ccrCMPMappingService.completeECMActivityTrail(tiRequestId);
                }

                // End of ECM -DK64387
                LOGGER.debug("OneApproval Cancel functionality ended..");

            } catch (Exception e) {
                LOGGER.error("Exception in completeActivity : " + e, e);
            } finally {
                LOGGER.debug("Entered the finally block ,check if exception got printed.");
                /*
                 * if(rs!=null) rs.close(); if(pStmt!=null) pStmt.close();
                 * if(pStmt1!=null) pStmt1.close(); if(pStmt2!=null)
                 * pStmt2.close();
                 * 
                 * if(con!=null){ c3parSession.releaseConnection(); }
                 */
            }

            /* Added for Cancel One Approval By NE36745 - Ends */

        } catch (Exception e) {
            LOGGER.error("Exception in completeActivity : " + e, e);
            throw new RemoteException(e.getMessage());
        } finally {
            LOGGER.debug("Entered the finally block#2 ,check if exception got printed.");
            /*
             * try { if (pStmt != null) pStmt.close(); if (con != null)
             * c3parSession.releaseConnection(); } catch (Exception exp) {
             * log.error("Failed to close connection : "+exp, exp); }
             */}
        if (rowsUpdated > 0)
            LOGGER.info(" Sucessfully set Activity status to " + status + " by user " + completedBy
                    + " for activityTrailId  " + activityTrailId);
        else
            LOGGER.error("Could not  setActivity status to " + status + " by user " + completedBy + " for activityTrailId"
                    + activityTrailId);

        return rowsUpdated;
    }
        
    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#
     * _notifyResolveIT(java.lang.String, long)
     */
    public void _notifyResolveIT(String activity, long tirequestId) {
        LOGGER.debug("activity : " + activity + " , tirequestId : " + tirequestId);
        int linkedCMPStatus = 1;
        Map<String, String> userDetails = null;
        String completedBy = "";
        String userId = "";
        Map<String, List<String>> cmpItemDetails = null;
        List<String> cmpDetails = null;
        List<String> ccrDetails = null;
        List<String> cmpOrderItemDetails = null;
        int count = 0;
        try {
            linkedCMPStatus = ccrCMPMappingService.checkCMPStatus(tirequestId);
            if (linkedCMPStatus > 0) {
                userDetails = ccrCMPMappingService.getCompletedUserDetails(tirequestId);
                if (userDetails != null) {
                    completedBy = userDetails.get("completedBy");
                    userId = userDetails.get("UserId");
                    if (completedBy != null && !completedBy.equals("") && userId != null && !userId.equals("")) {
                        cmpItemDetails = ccrCMPMappingService.getCMPCCRDetails(tirequestId);
                        cmpDetails = (List<String>) cmpItemDetails.get("cmpDetails");
                        ccrDetails = (List<String>) cmpItemDetails.get("ccrDetails");
                        cmpOrderItemDetails = (List<String>) cmpItemDetails.get("cmpOrderItemDetails");
                        for (String processId : ccrDetails) {
                            String cmp_id = (String) cmpDetails.get(count);
                            String cmpOrderItemid = (String) cmpOrderItemDetails.get(count);
                            String cmpXMLContent = ccrCMPMappingService.getCMPXMLContent(cmpOrderItemid);
                            String statusURL = null;
                            String statusText = null;
                            String statusLink = null;
                            statusURL = ccrUrl + "/loadEmailGenerationViewBusinessUser.act?cmpReqId=" + cmpOrderItemid
                                    + "&actCode=cmp_general_info&tiRequestId=" + tirequestId;
                            statusText = "CMP Details View URL";
                            statusLink = statusText + " : " + statusURL;
                            if (cmpXMLContent != null && !cmpXMLContent.equals("")) {
                                ResolveITQueueSenderImpl resolveITQueueSenderImpl = new ResolveITQueueSenderImpl();
                                PurchaseOrderDocument purchaseOrderDocument = null;
                                purchaseOrderDocument = PurchaseOrderDocument.Factory.parse(cmpXMLContent);
                                PurchaseOrder purchaseOrder = purchaseOrderDocument.getPurchaseOrder();
                                ArrayOfPurchaseOptionDescription arrayOfPurchaseOptionDescription = purchaseOrder
                                        .getPurchaseOptions();
                                PurchaseOptionDescription purchaseOptionDescription = arrayOfPurchaseOptionDescription
                                        .getPurchaseOptionDescriptionArray(0);
                                purchaseOptionDescription.setMessageType(MessageTypeEnum.UPDATE);
                                purchaseOptionDescription.setOrderTimeUtc(new GregorianCalendar());
                                FulfilmentItem fulfilmentItem = purchaseOptionDescription.getFulfilmentItem();
                                Status ccrStatus = fulfilmentItem.getStatus();
                                if ("Active".equalsIgnoreCase(activity)) {
                                    ccrStatus.setStatus(PurchaseOptionStatusEnum.COMPLETED);
                                } else {
                                    ccrStatus.setStatus(PurchaseOptionStatusEnum.CREATED);
                                }
                                if ("Active".equalsIgnoreCase(activity)) {
                                    activity = "Activated";
                                }
                                DataFieldUrl objDataFieldUrl = DataFieldUrl.Factory.newInstance();
                                objDataFieldUrl.setLink(statusURL);
                                objDataFieldUrl.setText(statusText);
                                ccrStatus.setUrl(objDataFieldUrl);
                                activity = (activity != null && !activity.equals("")) ? (activity.toUpperCase()) : "";
                                completedBy = (completedBy != null && !completedBy.equals("")) ? (completedBy
                                        .toUpperCase()) : "";
                                ccrStatus.setComments("CCR ID :" + processId + " IS " + activity + " BY " + completedBy
                                        + ". " + statusLink);
                                ccrStatus.setUpdatedByUserID(userId);
                                ccrStatus.setUpdatedDateTimeUtc(new GregorianCalendar());
                                String toPost = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>"
                                        + purchaseOrderDocument.xmlText();
                                LOGGER.debug("Notifying ResolveIt starts");
                                resolveITQueueSenderImpl.sendMesage(toPost);
                            }
                            int updateCMPStatusCnt = ccrCMPMappingService.updateCMPStatus(
                                    ActivityDataDTO.STATUS_COMPLETED, cmpOrderItemid);
                            LOGGER.debug("Number of rows updated =" + updateCMPStatusCnt);
                            // The following code updates any open cmp audit
                            // trail entry and marks it completed with an end
                            // timestamp.
                            // This is because the cmp is being marked completed
                            // in the above statement.
                            ccrCMPMappingService.completeECMActivtyTrail_By_TiReqId_CMP_OrdItemId(tirequestId,
                                    cmpOrderItemid);
                            count++;
                        }
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error("Exception occurred in _notifyResolveIT : " + e.toString());
            LOGGER.error(e.toString(), e);
        }
    }

    /**
     * @param activityTrailId
     * @param completedBy
     * @param activity
     * @param status
     */
    public void notifyResolveIT(long activityTrailId, String completedBy, String activity, String status) {
        LOGGER.debug("activityTrailId : " + activityTrailId + " , completedBy : " + completedBy + " , activity : "
                + activity + " , status : " + status);
        String userID = null;
        String task = null;
        Map<String, List<String>> cmpItemDetails = null;
        List<String> cmpDetails = null;
        List<String> ccrDetails = null;
        List<String> tiRequestDetails = null;
        List<String> ccrCMPXrefDetails = null;
        List<String> cmpOrderitemDetails = null;
        int count = 0;
        try {

            if (completedBy != null) {
                userID = ccrCMPMappingService.getGEIdforUser(completedBy);
            }

            if (userID != null) {
                task = ccrCMPMappingService.getTaskDescriptionForActivity(activityTrailId);
                cmpItemDetails = ccrCMPMappingService.getMappedCMPIdForCCRId(activityTrailId);
                cmpDetails = (List<String>) cmpItemDetails.get("cmpDetails");
                ccrDetails = (List<String>) cmpItemDetails.get("ccrDetails");
                tiRequestDetails = (List<String>) cmpItemDetails.get("tiRequestDetails");
                ccrCMPXrefDetails = (List<String>) cmpItemDetails.get("ccrCMPXrefDetails");
                cmpOrderitemDetails = (List<String>) cmpItemDetails.get("cmpOrderitemDetails");
                for (String processId : ccrDetails) {
                    String cmp_id = (String) cmpDetails.get(count);
                    String tiRequestId = (String) tiRequestDetails.get(count);
                    String ccrCMPMappingId = (String) ccrCMPXrefDetails.get(count);
                    String cmp_order_itemId = (String) cmpOrderitemDetails.get(count);
                    String cmpXMLContent = ccrCMPMappingService.getCMPXMLContent(cmp_order_itemId);
                    String statusURL = null;
                    String statusText = null;
                    String statusLink = null;
                    statusURL = ccrUrl + "/loadEmailGenerationViewBusinessUser.act?cmpReqId=" + cmp_order_itemId
                            + "&actCode=cmp_general_info&tiRequestId=" + tiRequestId;
                    statusText = "CMP Details View URL";
                    statusLink = statusText + " : " + statusURL;
                    if (cmpXMLContent != null && !cmpXMLContent.equals("")) {
                        PurchaseOrderDocument purchaseOrderDocument = null;
                        ResolveITQueueSenderImpl resolveITQueueSenderImpl = new ResolveITQueueSenderImpl();
                        purchaseOrderDocument = PurchaseOrderDocument.Factory.parse(cmpXMLContent);
                        PurchaseOrder purchaseOrder = purchaseOrderDocument.getPurchaseOrder();
                        ArrayOfPurchaseOptionDescription arrayOfPurchaseOptionDescription = purchaseOrder
                                .getPurchaseOptions();
                        PurchaseOptionDescription purchaseOptionDescription = arrayOfPurchaseOptionDescription
                                .getPurchaseOptionDescriptionArray(0);
                        purchaseOptionDescription.setMessageType(MessageTypeEnum.UPDATE);
                        purchaseOptionDescription.setOrderTimeUtc(new GregorianCalendar());
                        FulfilmentItem fulfilmentItem = purchaseOptionDescription.getFulfilmentItem();

                        Status ccrStatus = fulfilmentItem.getStatus();

                        task = (task != null && !task.equals("")) ? (task.toUpperCase()) : "";
                        completedBy = (completedBy != null && !completedBy.equals("")) ? (completedBy.toUpperCase())
                                : "";
                        status = (status != null && !status.equals("")) ? (status.toUpperCase()) : "";

                        if (ActivityData.STATUS_SCHEDULED.equalsIgnoreCase(activity)) {
                            ccrStatus.setComments(task + " : SCHEDULED, CCR ID :" + processId + " BY " + completedBy
                                    + ". " + statusLink);
                        } else if ("END".equalsIgnoreCase(activity)) {
                            ccrStatus.setComments(task + " : COMPLETED, CCR ID :" + processId + " BY " + completedBy
                                    + ". " + statusLink);
                        } else if ("LOCKED".equalsIgnoreCase(activity)) {
                            ccrStatus.setComments(task + " : INPROGRESS, CCR ID :" + processId + " BY " + completedBy
                                    + ". " + statusLink);
                        } else {
                            ccrStatus.setComments(task + " : " + status + ", CCR ID :" + processId + " BY "
                                    + completedBy + ". " + statusLink);
                        }
                        if ("END".equalsIgnoreCase(activity)) {
                            ccrStatus.setStatus(PurchaseOptionStatusEnum.COMPLETED);
                        } else {
                            if ("END".equalsIgnoreCase(activity)) {
                                ccrStatus.setStatus(PurchaseOptionStatusEnum.COMPLETED);
                            } else {
                                ccrStatus.setStatus(PurchaseOptionStatusEnum.CREATED);
                            }
                        }
                        DataFieldUrl objDataFieldUrl = DataFieldUrl.Factory.newInstance();
                        objDataFieldUrl.setLink(statusURL);
                        objDataFieldUrl.setText(statusText);
                        ccrStatus.setUrl(objDataFieldUrl);

                        ccrStatus.setUpdatedByUserID(userID);
                        ccrStatus.setUpdatedDateTimeUtc(new GregorianCalendar());

                        String toPost = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>" + purchaseOrderDocument.xmlText();
                        LOGGER.debug("Calling Notify ResolveIT ");
                        resolveITQueueSenderImpl.sendMesage(toPost);
                    }
                    if (activity.equalsIgnoreCase("aborted")) {
                        if (ccrCMPMappingId != null) {
                            long ccrCMPXrefLongValue = 0;
                            try {
                                ccrCMPXrefLongValue = Long.valueOf(ccrCMPMappingId);
                            } catch (Exception e) {
                                ccrCMPXrefLongValue = Long.valueOf(0);
                            }
                            ccrCMPMappingService.deleteCmpFromCCR(ccrCMPXrefLongValue);
                        }
                    }
                    count++;
                }
            }
        } catch (Exception e) {
            LOGGER.error("Exception occurred in notifyResolveIT : " + e.toString());
            LOGGER.error(e.toString(), e);
        }
    }
    
    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#completeExceptionActivity(long, java.lang.String, java.lang.String)
     */
    public long completeExceptionActivity(final long tiRequestId, String activityCode,String prInfoActivityCode) throws Exception {
        LOGGER.info("tiRequestId " + tiRequestId+" , activityCode " + activityCode+" , prInfoActivityCode " + prInfoActivityCode);
        long rowsUpdated = -1;
        if (tiRequestId >0){
            Connection con = null;
            ResultSet rs=null;

        PreparedStatement pStmt = null;
        try {
            con= c3parSession.getConnection();
            String scheduledTaskSQl = (" select tat.id,ttt.TASK_CODE from c3par.ti_activity_trail tat,c3par.ti_task_type ttt where tat.activity_status=? and tat.ACTIVITY_ID=ttt.ID and tat.ti_request_id=?");
            
            
//          pStmt = con.prepareStatement(scheduledTaskSQl);
//          pStmt.setString(1, ActivityDataDTO.STATUS_SCHEDULED);
//          pStmt.setLong(2, tiRequestId);
//          rs = pStmt.executeQuery();
//
//          if(rs!=null){
//              while(rs.next()){
//                  log.info(" Activity Id "+rs.getLong(1)+" with task_code "+rs.getString(2) +" is scheduled and will be updated to  Error status ");
//                  }
//          }
//          
//          c3parSession.closeStatement( pStmt );
         



            HashMap<Long,String> activityId = jdbcTemplate.query(scheduledTaskSQl, new PreparedStatementSetter() {
                        @Override
                        public void setValues(PreparedStatement preparedStatement) throws SQLException {
                            preparedStatement.setString(1, ActivityDataDTO.STATUS_SCHEDULED);
                            preparedStatement.setLong(2, tiRequestId);}
                    }, new ResultSetExtractor<HashMap<Long,String>>() {
                        @Override
                        public HashMap<Long,String> extractData(ResultSet resultSet) throws SQLException, DataAccessException {
                            HashMap<Long,String> returnMap = new HashMap<Long,String>();
                            if (resultSet.next()) {
                                returnMap.put(resultSet.getLong(1), resultSet.getString(2));
                                LOGGER.info(" Activity Id "+resultSet.getLong(1)+" with task_code "+resultSet.getString(2) +" is scheduled and will be updated to  Error status ");
                                
                            }else{
                                //do nothing
                            }
                            return returnMap;
                            
                        }
                    });

            
            
            
            
            
            
            StringBuilder updateErrorStatSQL=new StringBuilder(" update c3par.ti_activity_trail set activity_status=?,activity_enddate=SYSDATE ,user_id=(select id from c3par.c3par_users where lower(sso_id)=lower('system'))" );
            updateErrorStatSQL.append(" where ti_request_id=? and activity_status=? ");

//          pStmt = con.prepareStatement(updateErrorStatSQL.toString());
//
//          pStmt.setString(1, ActivityDataDTO.STATUS_ERROR);
//          pStmt.setLong(2, tiRequestId);
//          pStmt.setString(3, ActivityDataDTO.STATUS_SCHEDULED);
//
//          rowsUpdated = pStmt.executeUpdate();
            
            
            
            
            

            Integer returnedId = jdbcTemplate.update(String.valueOf(updateErrorStatSQL), new PreparedStatementSetter() {
                  
                  @Override
                  public void setValues(PreparedStatement preparedStatement) throws SQLException {
                      
                      preparedStatement.setString(1, ActivityDataDTO.STATUS_ERROR);
                      preparedStatement.setLong(2, tiRequestId);
                      preparedStatement.setString(3, ActivityDataDTO.STATUS_SCHEDULED);
                  }
              }) ;
              LOGGER.debug("jdbc template rowsUpdated::" + returnedId);

        } catch (Exception e) {
            LOGGER.error("Exception in completeExceptionActivity : "+e, e);
            throw new RemoteException(e.getMessage());
        } finally {
            c3parSession.closeStatement( pStmt );
            c3parSession.closeResultSet(rs);
            try {            
                if (con != null)
                    c3parSession.releaseConnection();
            } catch (Exception exp) {
                LOGGER.error("Failed to close connection : "+exp, exp);
            }
        }
        }
        if (rowsUpdated > 0)

            LOGGER.info(" Sucessfully Flagged Scheduled  Activity status to "+ActivityDataDTO.STATUS_ERROR + " For TiRequestId "+tiRequestId);
        else
            LOGGER.info(" Could not Flag Scheduled  Activity status to "+ActivityDataDTO.STATUS_ERROR + " For TiRequestId "+tiRequestId);

        return rowsUpdated;
    }




         /**
         * Sets the request deadline.
         *
         * @param date the new request deadline
         * @throws Exception the exception
         */
        public void setRequestDeadline(Date date) throws Exception{

     }
    

    /**
     * Gets the start date for locked task.
     *
     * @param activityId the activity id
     * @return the start date for locked task
     * @throws Exception the exception
     */
    private Date getStartDateForLockedTask(final long activityId) throws Exception{
        LOGGER.info("activityId " + activityId);
            

            Date startDate=null;
            try{
                String activitySQL="select activity_startdate from c3par.ti_activity_trail where activity_status='UNLOCKED'  and id=?";
//              con =c3parSession.getConnection();
//              pStmt = con.prepareStatement(activitySQL.toString());
//              pStmt.setLong(1,activityId);
//              rs = pStmt.executeQuery();
//              log.debug(" with  Conditions activityId = " +activityId );
//              if(rs!=null){
//                  while(rs.next()){
//                      startDate=rs.getTimestamp(1);
//
//                      break;
//                  }
//              }
                
                
                startDate = jdbcTemplate.query(String.valueOf(activitySQL), new PreparedStatementSetter() {
                    @Override
                    public void setValues(PreparedStatement preparedStatement) throws SQLException {
                        preparedStatement.setLong(1,activityId);
                    }
                }, new ResultSetExtractor<Date>() {
                    @Override
                    public Date extractData(ResultSet resultSet) throws SQLException, DataAccessException {
                        while (resultSet.next()) {
                            return resultSet.getDate(1);

                        }
                        return null;
                        
                    }
                });
                 
                
                
                
               }
                finally{
                    LOGGER.info("Activity Id "+activityId+"startDate : " + startDate);
                    
                }
            return startDate;


        }
    
    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#getProvideInfoActivity(long)
     */
    public String getProvideInfoActivity(final long tiRequestID) throws Exception{
        LOGGER.info("tiRequestID " + tiRequestID);
         

            String provideInfoRequestedCode=null;
            try{
                String provideInfoSQL=" select ttt.TASK_CODE from c3par.ti_activity_trail tat ,c3par.ti_task_type ttt where ti_request_id=? and activity_status like 'PROVIDEINFO' and tat.ACTIVITY_ID=ttt.id";
//              con =c3parSession.getConnection();
//              pStmt = con.prepareStatement(provideInfoSQL.toString());
//              pStmt.setLong(1,tiRequestID);
//
//              rs = pStmt.executeQuery();
//              
//              
//              if(rs!=null){
//                  while(rs.next()){
//                      provideInfoRequestedCode=rs.getString(1);
//                      break;
//                  }
//              }
//              log.info("provideInfoRequestedCode : " + provideInfoRequestedCode);
//              
                
                
                

                provideInfoRequestedCode = jdbcTemplate.query(String.valueOf(provideInfoSQL), new PreparedStatementSetter() {
                       @Override
                       public void setValues(PreparedStatement preparedStatement) throws SQLException {
                           preparedStatement.setLong(1,tiRequestID);
                       }
                   }, new ResultSetExtractor<String>() {
                       @Override
                       public String extractData(ResultSet resultSet) throws SQLException, DataAccessException {
                           while (resultSet.next()) {
                               return resultSet.getString(1);

                           }
                           return "";
                           
                       }
                   });
                    
                LOGGER.info("provideInfoRequestedCode : " + provideInfoRequestedCode);
               }
                finally{   LOGGER.info("provideInfoRequestedCode : " + provideInfoRequestedCode);
                }
            return provideInfoRequestedCode;
     }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#getCurrentActivityRole(long, java.lang.String)
     */
    public String getCurrentActivityRole(final long tiRequestID,final String prInfoRequestedActivityCode) throws Exception{
            LOGGER.info("tiRequestID " + tiRequestID+" , prInfoRequestedActivityCode : "+prInfoRequestedActivityCode);
            
            String role=null;
            try{
                StringBuffer currRoleSQL=new StringBuffer(" select rl.name from c3par.ti_activity_trail tat ,c3par.ti_request  tir,c3par.role rl,c3par.ti_activity_trail prreq");
                currRoleSQL.append(" where tir.id=tat.ti_request_id and tat.activity_status=? and tat.infouser_role_id=rl.id ");
                currRoleSQL.append(" and tat.pi_requested_activity=prreq.id and prreq.activity_id=(select id from c3par.ti_task_type where task_code=?) and tir.id=?");
//              con =c3parSession.getConnection();
//              pStmt = con.prepareStatement(currRoleSQL.toString());
//              pStmt.setString(1,ActivityData.STATUS_SCHEDULED);
//              pStmt.setString(2,prInfoRequestedActivityCode);
//              pStmt.setLong(3,tiRequestID);
//              rs = pStmt.executeQuery();
//              
//              log.debug(" Parameters : requestId = " +tiRequestID +" Status "+ActivityData.STATUS_SCHEDULED+" ,prinfoRequestedActivityCode"+prInfoRequestedActivityCode);
//              if(rs!=null){
//                  while(rs.next()){
//                      role=rs.getString(1);
//                      break;
//                  }
//              }
//              log.info("role : " + role);
                
                
                
                
                role = jdbcTemplate.query(String.valueOf(currRoleSQL), new PreparedStatementSetter() {
                       @Override
                       public void setValues(PreparedStatement preparedStatement) throws SQLException {
                           LOGGER.debug(" Parameters : requestId = " +tiRequestID +" Status "+ActivityData.STATUS_SCHEDULED+" ,prinfoRequestedActivityCode"+prInfoRequestedActivityCode);
                           preparedStatement.setString(1,ActivityData.STATUS_SCHEDULED);
                           preparedStatement.setString(2,prInfoRequestedActivityCode);
                           preparedStatement.setLong(3,tiRequestID);
                       }
                   }, new ResultSetExtractor<String>() {
                       @Override
                       public String extractData(ResultSet resultSet) throws SQLException, DataAccessException {
                           while (resultSet.next()) {
                               return resultSet.getString(1);

                           }
                           return "";
                           
                       }
                   });
                    
                    LOGGER.info("role : " + role);
                    
                    
               }
                finally{
                    
                    LOGGER.info("tiRequestID " + tiRequestID+" , prInfoRequestedActivityCode : "+prInfoRequestedActivityCode + " : role ="+role);
                }
            return role;
          }

     /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#isCurrentActivityScheduled(long, java.lang.String, java.lang.String)
     */
    public boolean isCurrentActivityScheduled(long tiRequestID,String activityCode, String prInfoRequestedActivityCode) throws Exception{
            boolean curActivityScheduled=false;
            if (getScheduledActivityTralId(tiRequestID,activityCode,prInfoRequestedActivityCode)>0)
            curActivityScheduled=true;
            return curActivityScheduled;
         }

     /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#getScheduledActivityTralId(long, java.lang.String, java.lang.String)
     */
    public long getScheduledActivityTralId(final long tiRequestID,final String activityCode,final String prInfoRequestedActivityCode) throws Exception{
        LOGGER.info("tiRequestID " + tiRequestID+" , activityCode : "+activityCode+" , prInfoRequestedActivityCode : "+prInfoRequestedActivityCode);
         Long activityTrailId=-1L;
         

            try{

                StringBuffer provideInfoSQL=new StringBuffer(" select tat.id from c3par.ti_activity_trail tat,c3par.ti_task_type ttt ");
                 if(isString(prInfoRequestedActivityCode))
                provideInfoSQL.append(" ,ti_activity_trail pitat,c3par.ti_task_type pittt ");
                provideInfoSQL.append(" where tat.ti_request_id=? and  tat.ACTIVITY_ID=ttt.id and ttt.TASK_CODE=? and tat.ACTIVITY_STATUS=?  ");
                if(isString(prInfoRequestedActivityCode))
                    provideInfoSQL.append("  and tat.PI_REQUESTED_ACTIVITY=pitat.id and pitat.ACTIVITY_ID=pittt.id and pittt.task_code = ? and pitat.ACTIVITY_STATUS=?  and tat.TI_REQUEST_ID=pitat.TI_REQUEST_ID ");
                
                
//              pStmt = con.prepareStatement(provideInfoSQL.toString());
//              pStmt.setLong(1,tiRequestID);
//              pStmt.setString(2,activityCode);
//              pStmt.setString(3,ActivityDataDTO.STATUS_SCHEDULED);
//              if(isString(prInfoRequestedActivityCode)){
//                  pStmt.setString(4,prInfoRequestedActivityCode);
//              pStmt.setString(5,ActivityDataDTO.STATUS_PROVIDEINFO);
//              }
//
//
//              rs = pStmt.executeQuery();
//              
//              if(rs!=null){
//                  while(rs.next()){
//                      activityTrailId=rs.getLong(1);
//                      break;
//                  }
//              }
//              log.info("activityTrailId : " + activityTrailId);
//              
                
                
                

                activityTrailId = jdbcTemplate.query(String.valueOf(provideInfoSQL), new PreparedStatementSetter() {
                   @Override
                   public void setValues(PreparedStatement preparedStatement) throws SQLException {
                       
                       preparedStatement.setLong(1,tiRequestID);
                       preparedStatement.setString(2,activityCode);
                       preparedStatement.setString(3,ActivityDataDTO.STATUS_SCHEDULED);
                         if(isString(prInfoRequestedActivityCode)){
                             preparedStatement.setString(4,prInfoRequestedActivityCode);
                             preparedStatement.setString(5,ActivityDataDTO.STATUS_PROVIDEINFO);
                         }
       
                       
                   }
               }, new ResultSetExtractor<Long>() {
                   @Override
                   public Long extractData(ResultSet resultSet) throws SQLException, DataAccessException {
                       while (resultSet.next()) {
                           return resultSet.getLong(1);

                       }
                       return -1L;
                       
                   }
               });
                
                
                
                
               }
                finally{
                    LOGGER.info("activityTrailId : " + activityTrailId);
                    
                }
            return activityTrailId;
     }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#getPrInfoRequestedActivityId(long, java.lang.String, java.lang.String)
     */
    public long getPrInfoRequestedActivityId(final long tiRequestID,final String activityCode, final String prInfoRequestedActivityCode) throws Exception{
        LOGGER.info("tiRequestID " + tiRequestID+" , activityCode : "+activityCode+" , prInfoRequestedActivityCode : "+prInfoRequestedActivityCode);
         Long activityTrailId=-1L;
        
            try{
                StringBuffer provideInfoSQL=new StringBuffer(" select tat.id from c3par.ti_activity_trail tat,c3par.ti_task_type ttt ");
                 if(isString(prInfoRequestedActivityCode))
                provideInfoSQL.append(" ,ti_activity_trail pitat,c3par.ti_task_type pittt ");
                provideInfoSQL.append(" where tat.ti_request_id=? and  tat.ACTIVITY_ID=ttt.id and ttt.TASK_CODE=? and tat.ACTIVITY_STATUS=?  ");
                if(isString(prInfoRequestedActivityCode))
                    provideInfoSQL.append("  and tat.PI_REQUESTED_ACTIVITY=pitat.id and pitat.ACTIVITY_ID=pittt.id and pittt.task_code = ? and pitat.ACTIVITY_STATUS=?  and tat.TI_REQUEST_ID=pitat.TI_REQUEST_ID ");
//              con =c3parSession.getConnection();
//              pStmt = con.prepareStatement(provideInfoSQL.toString());
//              pStmt.setLong(1,tiRequestID);
//              pStmt.setString(2,activityCode);
//              pStmt.setString(3,ActivityDataDTO.STATUS_PROVIDEINFO);
//              if(isString(prInfoRequestedActivityCode)){
//                  pStmt.setString(4,prInfoRequestedActivityCode);
//              pStmt.setString(5,ActivityDataDTO.STATUS_PROVIDEINFO);
//              }
//
//              rs = pStmt.executeQuery();
//              
//              if(rs!=null){
//                  while(rs.next()){
//                      activityTrailId=rs.getLong(1);
//                      break;
//                  }
//              }
                
                
                
                activityTrailId = jdbcTemplate.query(String.valueOf(provideInfoSQL), new PreparedStatementSetter() {
                    @Override
                    public void setValues(PreparedStatement preparedStatement) throws SQLException {
                        preparedStatement.setLong(1,tiRequestID);
                        preparedStatement.setString(2,activityCode);
                        preparedStatement.setString(3,ActivityDataDTO.STATUS_PROVIDEINFO);
                        if(isString(prInfoRequestedActivityCode)){
                            preparedStatement.setString(4,prInfoRequestedActivityCode);
                            preparedStatement.setString(5,ActivityDataDTO.STATUS_PROVIDEINFO);
                        }
                    }
                }, new ResultSetExtractor<Long>() {
                    @Override
                    public Long extractData(ResultSet resultSet) throws SQLException, DataAccessException {
                        if (resultSet.next()) {
                          return resultSet.getLong(1);
                        }else{
                            return -1L;
                        }
                        
                    }
                });
                
                
                
                
                
               }
                finally{
                    
                    LOGGER.info("tiRequestID " + tiRequestID+" , activityCode : "+activityCode+" , prInfoRequestedActivityCode : "+prInfoRequestedActivityCode+" : activityTrailId ="+activityTrailId);
                    
                }
            return activityTrailId;
        }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#getCurrentActivityStatus(long)
     */
    public String getCurrentActivityStatus(final long activityTrailId) throws Exception{
        LOGGER.info("activityTrailId : " + activityTrailId);
            
            String status=null;
            try{
                StringBuffer provideInfoSQL=new StringBuffer(" select activity_status from c3par.ti_activity_trail where id=?");

//              con =c3parSession.getConnection();
//              pStmt = con.prepareStatement(provideInfoSQL.toString());
//              pStmt.setLong(1,activityTrailId);
//
//              rs = pStmt.executeQuery();
//              
//              if(rs!=null){
//                  while(rs.next()){
//                      status=rs.getString(1);
//                      break;
//                  }
//              }
                
               
            
                
                 status = jdbcTemplate.query(String.valueOf(provideInfoSQL), new PreparedStatementSetter() {
                     @Override
                     public void setValues(PreparedStatement preparedStatement) throws SQLException {
                         preparedStatement.setLong(1,activityTrailId);
                     }
                 }, new ResultSetExtractor<String>() {
                     @Override
                     public String extractData(ResultSet resultSet) throws SQLException, DataAccessException {
                         if (resultSet.next()) {
                             return resultSet.getString(1);
                             
                         }else{
                             return "";
                         }
                         
                     }
                 });
            
            
            }
                finally{
                    LOGGER.debug("activityTrailId : " + activityTrailId+" :: Status is "+status);
                    
                }
            return status;
         }

     /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#updateBPMInstanceId(long, java.lang.String)
     */
    public void updateBPMInstanceId(final long activityTrailId,final String bpmInstanceId) throws Exception{
        LOGGER.info("activityTrailId " + activityTrailId+" , bpmInstanceId : "+bpmInstanceId);
            
            
                String updBPMInstanceSQL=" update c3par.ti_activity_trail set bpm_instance_id=? ,activity_status=? where id=?";
//              con =c3parSession.getConnection();
//              pStmt = con.prepareStatement(updBPMInstanceSQL.toString());
//              pStmt.setString(1,bpmInstanceId);
//              pStmt.setString(2,ActivityDataDTO.STATUS_SCHEDULED);
//              pStmt.setLong(3,activityTrailId);
//
//              pStmt.executeUpdate();
//              
                
                
                 Integer numberofRowsUpdated = jdbcTemplate.update(updBPMInstanceSQL, new PreparedStatementSetter() {
                        
                        @Override
                        public void setValues(PreparedStatement preparedStatement) throws SQLException {
                            preparedStatement.setString(1,bpmInstanceId);
                            preparedStatement.setString(2,ActivityDataDTO.STATUS_SCHEDULED);
                            preparedStatement.setLong(3,activityTrailId);
                        }
                    }) ;
                    LOGGER.debug("jdbc template rowsUpdated::" + numberofRowsUpdated);
                
    }
                
             

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageactivity.IManageActivity#isPrInfoRequestedActivity(long)
     */
    public boolean isPrInfoRequestedActivity(final long activityTrailId) throws Exception{
        LOGGER.info("activityTrailId " + activityTrailId);
         boolean isPrInfoReqActivity=false;
         

            try{

                StringBuffer provideInfoActivitySQL=new StringBuffer(" select pi_requested_activity from c3par.ti_activity_trail where pi_requested_activity =?");
//              con =c3parSession.getConnection();
//              pStmt = con.prepareStatement(provideInfoActivitySQL.toString());
//              pStmt.setLong(1,activityTrailId);
//              rs = pStmt.executeQuery();
//              
//              log.debug(" Parameters : activityTrailId = " +activityTrailId );
//                if(rs!=null){
//                    while(rs.next()){
//                        long actTrailId=rs.getLong(1);
//                        if(actTrailId>0)
//                        isPrInfoReqActivity=true;
//                        break;
//                    }
//                }
//              
                
                
                isPrInfoReqActivity = jdbcTemplate.query(String.valueOf(provideInfoActivitySQL), new PreparedStatementSetter() {
                   @Override
                   public void setValues(PreparedStatement preparedStatement) throws SQLException {
                       preparedStatement.setLong(1,activityTrailId);
                   }
               }, new ResultSetExtractor<Boolean>() {
                   @Override
                   public Boolean extractData(ResultSet resultSet) throws SQLException, DataAccessException {
                       if (resultSet.next()) {
                           return true;
                           
                       }else{
                           return false;
                       }
                       
                   }
               });
               
                
                

               }finally{ 
                   LOGGER.info("activityTrailId " + activityTrailId + " :: isPrInfoReqActivity " + isPrInfoReqActivity); }
            
            return isPrInfoReqActivity;
        }

    /**
     * Checks if is string.
     *
     * @param val the val
     * @return true, if is string
     */
    boolean isString(String val) {
        boolean isString = true;
        if (val == null)
            isString = false;
        if (val != null && val.length() == 0)
            isString = false;
        return isString;
    }
    
    /**
     * @return the ccrUrl
     */
    public String getCcrUrl() {
        return ccrUrl;
    }

    /**
     * @param ccrUrl the ccrUrl to set
     */
    public void setCcrUrl(String ccrUrl) {
        this.ccrUrl = ccrUrl;
    }
}