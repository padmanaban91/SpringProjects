package com.citigroup.cgti.c3par.common.domain;

import java.util.HashMap;
import java.util.List;

import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.domain.accessform.AccessFormXsl;
import com.citigroup.cgti.c3par.domain.accessform.PafAccessForm;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCRequest;

public interface AccessFormText {
	HashMap<String, String> getAttachments(Long tiRequestID, Long connectionRequestId, Long versionID, String isACV) throws Exception;
	
	String getProxyAccessFormText(Long tiRequestId, Long connectionRequestId, Long versionID);
	
	String getAppsenseAccessFormText(Long tiRequestId, Long connectionRequestId, Long versionID);
	
	String getFirewallAccessFormText(Long tiRequestId, Long connectionRequestId, Long versionID);	
	String getFirewallAccessFormText(Long tiRequestId, Long connectionRequestId, Long versionID, String isObjExpandable);
	
	String getIPRegistrationAccessFormText(Long tiRequestId, Long connectionRequestId, Long versionID);	
	String getIPRegistrationAccessFormText(Long tiRequestId, Long connectionRequestId, Long versionID, String isObjExpandable);
	
	String getSECACLAccessFormText(Long tiRequestId, Long connectionRequestId, Long versionID);
	
	String getFirewallAccessFormTextByRFC(RFCRequest rfcRequest);

	String getProxyAccessFormTextByRFC(RFCRequest rfcRequest);
	
	String getAllFirewallAccessFormText(Long tiRequestId, Long connectionRequestId, String expOption);
	String getAllFirewallAccessFormText(Long tiRequestId, Long connectionRequestId, String expOption, String isObjExpandable);
	
	String getAllIPRegistrationAccessFormText(Long tiRequestId, Long connectionRequestId, String expOption);
	String getAllIPRegistrationAccessFormText(Long tiRequestId, Long connectionRequestId, String expOption, String isObjExpandable);
	
	String getOrigBusJustification(Long connectionRequestId, Long versionID);
	String getCurrentBusJustfication(Long tiRequestId);
	
	String getAllProxyAccessFormText(Long tiRequestId, Long connectionRequestId);
	
	String getAllAppsenseAccessFormText(Long tiRequestId, Long connectionRequestId);
	
	String getAllACLAccessFormText(Long tiRequestId, Long connectionRequestId);

    public HashMap<String, String> getAllImplementedRule(Long tiRequestID, Long connectionRequestId, Long versionID,
            String isImpl);
    public AccessFormXsl getConnectionInfoForEnhancedExport(Long tiRequestId, Long connectionRequestId, Long versionID, String requestType,String isObjectExpandable) throws Exception;
    HashMap<String, byte[]> getFileAttachments(Long tiRequestID, Long connectionRequestId, Long versionID, String isACV) throws Exception;

	public List<TIRequest> getAllTiRequest(Long tiProcessId, String isIPReg, String expOption);
	AccessFormXsl getConnectionInfo(Long tiRequestId, Long connectionRequestId, Long versionID, String requestType) throws Exception;
	List<PafAccessForm> getPAFCombinationInfo(Long connectionID,Long tiRequestId, Long versionID, String isRFC,RFCRequest rfcRequest);
}
