package com.citigroup.cgti.c3par.comments.domain;

import java.io.Serializable;

import org.apache.log4j.Logger;

public class ExceptionProcess implements Serializable {

    private static Logger log = Logger.getLogger(ExceptionProcess.class);

    private String exceptionOption;

    private String connectionId;

    private String taskId;

    private String tiRequestId;

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getTiRequestId() {
        return tiRequestId;
    }

    public void setTiRequestId(String tiRequestId) {
        this.tiRequestId = tiRequestId;
    }

    private String errorMessage;

    public String getExceptionOption() {
        return exceptionOption;
    }

    public void setExceptionOption(String exceptionOption) {
        this.exceptionOption = exceptionOption;
    }

    public String getConnectionId() {
        return connectionId;
    }

    public void setConnectionId(String connectionId) {
        this.connectionId = connectionId;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

}
