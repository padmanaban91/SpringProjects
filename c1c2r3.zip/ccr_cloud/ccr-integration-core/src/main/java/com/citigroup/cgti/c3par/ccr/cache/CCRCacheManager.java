package com.citigroup.cgti.c3par.ccr.cache;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.communication.domain.ECMConstants;
import com.citigroup.cgti.c3par.configuation.CCRQueries;
import com.citigroup.cgti.c3par.configuation.QueryConstants;
import com.citigroup.cgti.c3par.util.StringUtil;
import com.citigroup.ets.ccr.CCR_Constants;

/**
 * CCRCacheManager provides the caching mechanism for fetching CMP Email
 * templates
 * 
 * @author mr89025
 * 
 */
@Repository
@Transactional
public class CCRCacheManager {

    private static final Logger LOGGER = Logger.getLogger(CCRCacheManager.class);

    public HashMap<String, Object> mailTemplates = null;
    public static Map<String, List<GenericLookup>> genericLookUpMap = null;
    
    @Autowired
    private CCRQueries ccrQueries;

    @Autowired
    private JdbcTemplate jdbcTemplate_ccr;

    public CCRQueries getCcrQueries() {
        return ccrQueries;
    }

    public void setCcrQueries(CCRQueries ccrQueries) {
        this.ccrQueries = ccrQueries;
    }

    public JdbcTemplate getJdbcTemplate_ccr() {
        return jdbcTemplate_ccr;
    }

    public void setJdbcTemplate_ccr(JdbcTemplate jdbcTemplate_ccr) {
        this.jdbcTemplate_ccr = jdbcTemplate_ccr;
    }

    @Transactional(readOnly = true)
    public void init() {
        try {
            mailTemplates = getEmailTemplateDetails();
            loadgenericLookUpMap();
        } catch (Exception e) {
            LOGGER.error("Exception occurred in init : " + e.toString());
            LOGGER.error(e.toString(), e);
        }
    }

    /*
     * To Fetch the Email templates based on the mapping
     */
    @Transactional(readOnly = true)
    public HashMap<String, Object> getEmailTemplateDetails() {
        String templateDetailsQuery = "";
        String templateListDetailsQuery = "";
        String directorMailTemplateQuery = "";
        String emerBuscritMailTemplateQuery = "";
        SqlRowSet result = null;
        List<GenericLookup> emailTemplateList = null;
        HashMap<String, Object> templateListDetails = null;
        String requestType = null;
        String taskName = null;
        String templateId = null;
        try {
            templateDetailsQuery = ccrQueries.getQueryByName(QueryConstants.GET_AVAILABLE_TEMPLATE_IDS);
            templateListDetailsQuery = ccrQueries.getQueryByName(QueryConstants.GET_TEMPLATE_LIST);
            emerBuscritMailTemplateQuery = ccrQueries.getQueryByName(QueryConstants.GET_EMER_EMAIL_TEMPLATE_LIST);
            directorMailTemplateQuery = ccrQueries.getQueryByName(QueryConstants.GET_DIRECTOR_MAIL_TEMPLATE_LIST);
            templateListDetails = new HashMap<String, Object>();
            result = jdbcTemplate_ccr.queryForRowSet(templateDetailsQuery);
            while (result.next()) {
                requestType = result.getString(1);
                taskName = result.getString(2);
                templateId = result.getString(3);
                if (!StringUtil.isNullorEmpty(requestType) && !StringUtil.isNullorEmpty(taskName)
                        && !StringUtil.isNullorEmpty(templateId)) {
                    emailTemplateList = getEmailTemplateListDetails_new(templateId, templateListDetailsQuery);
                    if (emailTemplateList != null && emailTemplateList.size() >= 0) {
                        templateListDetails.put("MAPPING_" + requestType + "_" + taskName, "Y");
                    } else {
                        templateListDetails.put("MAPPING_" + requestType + "_" + taskName, "N");
                    }
                    templateListDetails.put(requestType + "_" + taskName, emailTemplateList);
                }
            }
            emailTemplateList = getEmailTemplateListDetails_new("", emerBuscritMailTemplateQuery);
            if (emailTemplateList != null && emailTemplateList.size() >= 0) {
                templateListDetails.put(QueryConstants.EMER_BUSCRIT_MAIL_TEMPLATE, emailTemplateList);
            }
            emailTemplateList = getEmailTemplateListDetails_new("", directorMailTemplateQuery);
            if (emailTemplateList != null && emailTemplateList.size() >= 0) {
                templateListDetails.put(QueryConstants.DIRECTOR_MAIL_TEMPLATE, emailTemplateList);
            }
        } catch (Exception e) {
            LOGGER.error("Exception occurred in getEmailTemplateListForCurrentTask : " + e.toString());
            LOGGER.error(e.toString(), e);
        }
        return templateListDetails;
    }

    @Transactional(readOnly = true)
    public List<GenericLookup> getEmailTemplateListDetails_new(String template_id, String templateListDetailsQuery) {
        List<GenericLookup> emailTemplateList = null;
        try {
            emailTemplateList = new ArrayList<GenericLookup>();
            if (!StringUtil.isNullorEmpty(template_id)) {
                emailTemplateList = getJdbcTemplate_ccr().query(templateListDetailsQuery, new Object[] { template_id },
                        new BeanPropertyRowMapper<GenericLookup>(GenericLookup.class));
            } else {
                emailTemplateList = getJdbcTemplate_ccr().query(templateListDetailsQuery,
                        new BeanPropertyRowMapper<GenericLookup>(GenericLookup.class));
            }
        } catch (Exception e) {
            LOGGER.error("Exception occurred in getEmailTemplateListDetails : " + e.toString());
            LOGGER.error(e.toString(), e);
        }
        return emailTemplateList;
    }

    /**
     * getCache - gets the Cache
     * 
     * @return
     */
    public HashMap<String, Object> getCache() {
        return this.mailTemplates;
    }

    /**
     * reLoadCache - Reloads the Cache
     * 
     * @return
     */
    public HashMap<String, Object> reLoadCache() {
        try {
            this.init();
        } catch (Exception e) {
            LOGGER.error("Exception occurred in reLoadCache : " + e.toString());
            LOGGER.error(e.toString(), e);
        }
        return mailTemplates;
    }

    /**
     * displayEmailTemplateCache - Method to return the HashMap
     * 
     * @param option
     * @return
     */
    @SuppressWarnings("unchecked")
    public HashMap<String, Object> displayEmailTemplateCache(String emailTemplateKey) {
        HashMap<String, Object> emailTemplatesForTask = null;
        List<GenericLookup> emailTemplateList = null;
        try {
            emailTemplatesForTask = new HashMap<String, Object>();
            if (!StringUtil.isNullorEmpty(emailTemplateKey)) {
                emailTemplateList = new ArrayList<GenericLookup>(
                        (List<GenericLookup>) mailTemplates.get(emailTemplateKey));
                if (emailTemplateList != null && emailTemplateList.size() > 0) {
                    emailTemplatesForTask.put(emailTemplateKey, emailTemplateList);
                    return emailTemplatesForTask;
                }
            }
        } catch (Exception e) {
            LOGGER.error("Exception occurred in displayEmailTemplateCache : " + e.toString());
            LOGGER.error(e.toString(), e);
        }
        return mailTemplates;
    }

    @Transactional(readOnly = true)
    @SuppressWarnings("unchecked")
    public Map<String, List<GenericLookup>> loadgenericLookUpMap() {
        try {
            if (genericLookUpMap == null) {
                LOGGER.info("genericLookUpMap Method starts");
                genericLookUpMap = new LinkedHashMap<>();

                String genericLookUpQuery = "select id as id ,value1 as value1 ,value2 as value2 from GENERIC_LOOKUP where DEFINITION_ID in (select id  from GENERIC_LOOKUP_DEFS where name=:defnName)";

                List<GenericLookup> directorQuestions = getJdbcTemplate_ccr().query(genericLookUpQuery,
                        new Object[] { ECMConstants.GENERIC_MD_QUESTIONS },
                        new BeanPropertyRowMapper<GenericLookup>(GenericLookup.class));
                List<GenericLookup> urgencyList = getJdbcTemplate_ccr().query(genericLookUpQuery,
                        new Object[] { ECMConstants.GENERIC_LOOKUP_REQUEST_URGENCY },
                        new BeanPropertyRowMapper<GenericLookup>(GenericLookup.class));
                List<GenericLookup> sloDaysList = getJdbcTemplate_ccr().query(genericLookUpQuery,
                        new Object[] { ECMConstants.GENERIC_LOOKUP_SLO_DAYS },
                        new BeanPropertyRowMapper<GenericLookup>(GenericLookup.class));
                List<GenericLookup> cmpStatusList = getJdbcTemplate_ccr().query(genericLookUpQuery,
                        new Object[] { ECMConstants.CMP_STATUS },
                        new BeanPropertyRowMapper<GenericLookup>(GenericLookup.class));
                List<GenericLookup> ipPingPoolList = getJdbcTemplate_ccr().query(genericLookUpQuery,
                        new Object[] { CCR_Constants.IP_PING_POOL_SIZE },
                        new BeanPropertyRowMapper<GenericLookup>(GenericLookup.class));
                List<GenericLookup> ipPingCommandPrefixList = getJdbcTemplate_ccr().query(genericLookUpQuery,
                        new Object[] { CCR_Constants.IP_PING_COMMAND_PREFIX },
                        new BeanPropertyRowMapper<GenericLookup>(GenericLookup.class));
                List<GenericLookup> nsLookUpPoolList = getJdbcTemplate_ccr().query(genericLookUpQuery,
                        new Object[] { CCR_Constants.NS_LOOKUP_POOL_SIZE },
                        new BeanPropertyRowMapper<GenericLookup>(GenericLookup.class));
                List<GenericLookup> nsLookUpCommandPrefixList = getJdbcTemplate_ccr().query(genericLookUpQuery,
                        new Object[] { CCR_Constants.NS_LOOKUP_COMMAND_PREFIX },
                        new BeanPropertyRowMapper<GenericLookup>(GenericLookup.class));
                List<GenericLookup> changeCreationTimeDeadlineList = getJdbcTemplate_ccr().query(genericLookUpQuery,
                        new Object[] { CCR_Constants.TIME_DELAY_CHANGE_REQUEST_WAIT },
                        new BeanPropertyRowMapper<GenericLookup>(GenericLookup.class));

                genericLookUpMap.put("URGENCY", urgencyList);
                genericLookUpMap.put("SLODAYS", sloDaysList);
                genericLookUpMap.put("DIRECTORQUESTIONS", directorQuestions);
                genericLookUpMap.put(ECMConstants.CMP_STATUS, cmpStatusList);
                genericLookUpMap.put(CCR_Constants.IP_PING_POOL_SIZE, ipPingPoolList);
                genericLookUpMap.put(CCR_Constants.IP_PING_COMMAND_PREFIX, ipPingCommandPrefixList);
                genericLookUpMap.put(CCR_Constants.NS_LOOKUP_POOL_SIZE, nsLookUpPoolList);
                genericLookUpMap.put(CCR_Constants.NS_LOOKUP_COMMAND_PREFIX, nsLookUpCommandPrefixList);
                genericLookUpMap.put(CCR_Constants.TIME_DELAY_CHANGE_REQUEST_WAIT, changeCreationTimeDeadlineList);
                LOGGER.info("genericLookUpMap Method Ends genericLookUpMap");
            }
        } catch (Exception e) {
            LOGGER.error(e.toString(), e);
        }
        return genericLookUpMap;

    }
    
    public static Map<String, List<GenericLookup>> getGenericLookUpMap() {
        return genericLookUpMap;
    }

    public static void setGenericLookUpMap(Map<String, List<GenericLookup>> genericLookUpMap) {
        CCRCacheManager.genericLookUpMap = genericLookUpMap;
    }


}
