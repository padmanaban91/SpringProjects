/**
 * 
 */
package com.citigroup.cgti.c3par.admin.service.impl;

import java.util.Comparator;

import com.citigroup.cgti.c3par.admin.domain.BulkContactUpdateDTO;

/**
 * @author ka58098
 *
 */
public class ContactComparator implements Comparator<BulkContactUpdateDTO> {

	@Override
	public int compare(BulkContactUpdateDTO o1, BulkContactUpdateDTO o2) {
		return o2.getCcrId().compareTo(o1.getCcrId());
	}

}
