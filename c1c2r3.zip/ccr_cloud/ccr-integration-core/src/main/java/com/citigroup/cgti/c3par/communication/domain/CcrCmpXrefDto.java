package com.citigroup.cgti.c3par.communication.domain;

/**
 * @author ky38518
 * 
 */
public class CcrCmpXrefDto {
    private Long tiRequestId;
    private String ccrId;
    private Long ccrcmpXrefId;

    /**
     * @return the tiRequestId
     */
    public Long getTiRequestId() {
        return tiRequestId;
    }

    /**
     * @param tiRequestId
     *            the tiRequestId to set
     */
    public void setTiRequestId(Long tiRequestId) {
        this.tiRequestId = tiRequestId;
    }

    /**
     * @return the ccrId
     */
    public String getCcrId() {
        return ccrId;
    }

    /**
     * @param ccrId
     *            the ccrId to set
     */
    public void setCcrId(String ccrId) {
        this.ccrId = ccrId;
    }

    /**
     * @return the ccrcmpXrefId
     */
    public Long getCcrcmpXrefId() {
        return ccrcmpXrefId;
    }

    /**
     * @param ccrcmpXrefId
     *            the ccrcmpXrefId to set
     */
    public void setCcrcmpXrefId(Long ccrcmpXrefId) {
        this.ccrcmpXrefId = ccrcmpXrefId;
    }

}
