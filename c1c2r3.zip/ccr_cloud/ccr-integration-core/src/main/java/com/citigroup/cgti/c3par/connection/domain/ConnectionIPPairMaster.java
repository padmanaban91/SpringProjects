package com.citigroup.cgti.c3par.connection.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.citigroup.cgti.c3par.domain.Application;
import com.citigroup.cgti.c3par.performer.dao.*;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;



/**
 * The Class ConnectionIPPairMaster.
 */
public class ConnectionIPPairMaster extends PerformerPagerDO implements Serializable {

    /** The start point ip mst id. */
    private Long startPointIPMstId;       

    /** The end point ip mst id. */
    private Long endPointIPMstId;               

    /** The display text. */
    private String displayText;                             
    //	private Application  application ;                      
    /** The share falg. */
    private String shareFalg;                       

    /** The delete flag. */
    private String deleteFlag;

    /** The connection port mst list. */
    private List connectionPortMstList;

    /** The connection fw rule mst list. */
    private List connectionFWRuleMstList;

    /** The connection ipsec tunnel master. */
    private ConnectionIpsecTunnelMaster connectionIpsecTunnelMaster;

    /** The created_date. */
    private Date created_date;

    /** The updated_date. */
    private Date updated_date;

    /**
     * Instantiates a new connection ip pair master.
     */
    public ConnectionIPPairMaster() {
	//----------
	setTableName(PerformerTypes.CONN_IP_PAIR_MASTER_TABEL);
	setSequenceName(PerformerTypes.CONN_IP_PAIR_MASTER_SEQ);
	//----------
	addToDBMapping("startPointIPMstId","start_point_ip_id",1);
	addToDBMapping("endPointIPMstId","end_point_ip_id",2);
	addToDBMapping("displayText","display_text",3);
	addToDBMapping("shareFalg","share_flag",4);
	addToDBMapping("deleteFlag","delete_flag",5);
	//		addToDBMapping("application","application_id");
	addToDBMapping("connectionIpsecTunnelMaster","IPSEC_TUNNEL_ID",6);
	addToDBMapping("created_date","created_date",7);
	addToDBMapping("updated_date","updated_date",8);
	//-------------
	addToChildList("connectionPortMstList",new ConnectionPortMaster());
	addToChildList("connectionFWRuleMstList",new ConnectionFWRuleMaster());

	addToDefaultValueMap("shareFlag", "F");
	addToDefaultValueMap("deleteFlag", "F");
	//--------------
	setKey(1, "displayText");


    }
    /*public Application getApplication() {
		return application;
	}
	public void setApplication(Application application) {
		this.application = application;
	}*/
    /**
     * Gets the delete flag.
     *
     * @return the delete flag
     */
    public String getDeleteFlag() {
	return deleteFlag;
    }

    /**
     * Sets the delete flag.
     *
     * @param deleteFlag the new delete flag
     */
    public void setDeleteFlag(String deleteFlag) {
	this.deleteFlag = deleteFlag;
    }

    /**
     * Gets the display text.
     *
     * @return the display text
     */
    public String getDisplayText() {
	return displayText;
    }

    /**
     * Sets the display text.
     *
     * @param displayText the new display text
     */
    public void setDisplayText(String displayText) {
	this.displayText = displayText;
    }

    /**
     * Gets the end point ip mst id.
     *
     * @return the end point ip mst id
     */
    public Long getEndPointIPMstId() {
	return endPointIPMstId;
    }

    /**
     * Sets the end point ip mst id.
     *
     * @param endPointIPMstId the new end point ip mst id
     */
    public void setEndPointIPMstId(Long endPointIPMstId) {
	this.endPointIPMstId = endPointIPMstId;
    }

    /**
     * Gets the share falg.
     *
     * @return the share falg
     */
    public String getShareFalg() {
	return shareFalg;
    }

    /**
     * Sets the share falg.
     *
     * @param shareFalg the new share falg
     */
    public void setShareFalg(String shareFalg) {
	this.shareFalg = shareFalg;
    }

    /**
     * Gets the start point ip mst id.
     *
     * @return the start point ip mst id
     */
    public Long getStartPointIPMstId() {
	return startPointIPMstId;
    }

    /**
     * Sets the start point ip mst id.
     *
     * @param startPointIPMstId the new start point ip mst id
     */
    public void setStartPointIPMstId(Long startPointIPMstId) {
	this.startPointIPMstId = startPointIPMstId;
    }

    /**
     * Gets the connection port mst list.
     *
     * @return the connection port mst list
     */
    public List getConnectionPortMstList() {
	return connectionPortMstList;
    }

    /**
     * Sets the connection port mst list.
     *
     * @param connectionPortMstList the new connection port mst list
     */
    public void setConnectionPortMstList(List connectionPortMstList) {
	this.connectionPortMstList = connectionPortMstList;
    }            

    /**
     * Gets the connection fw rule mst list.
     *
     * @return Returns the connectionFWRuleMstList.
     */
    public List getConnectionFWRuleMstList() {
	return connectionFWRuleMstList;
    }

    /**
     * Sets the connection fw rule mst list.
     *
     * @param connectionFWRuleMstList The connectionFWRuleMstList to set.
     */
    public void setConnectionFWRuleMstList(List connectionFWRuleMstList) {
	this.connectionFWRuleMstList = connectionFWRuleMstList;
    }

    /**
     * Gets the connection ipsec tunnel master.
     *
     * @return Returns the connectionIpsecTunnelMaster.
     */
    public ConnectionIpsecTunnelMaster getConnectionIpsecTunnelMaster() {
	return connectionIpsecTunnelMaster;
    }

    /**
     * Sets the connection ipsec tunnel master.
     *
     * @param connectionIpsecTunnelMaster The connectionIpsecTunnelMaster to set.
     */
    public void setConnectionIpsecTunnelMaster(
	    ConnectionIpsecTunnelMaster connectionIpsecTunnelMaster) {
	this.connectionIpsecTunnelMaster = connectionIpsecTunnelMaster;
    }



    /**
     * Gets the created_date.
     *
     * @return Returns the created_date.
     */
    public Date getCreated_date() {
	return created_date;
    }

    /**
     * Sets the created_date.
     *
     * @param created_date The created_date to set.
     */
    public void setCreated_date(Date created_date) {
	this.created_date = created_date;
    }

    /**
     * Gets the updated_date.
     *
     * @return Returns the updated_date.
     */
    public Date getUpdated_date() {
	return updated_date;
    }

    /**
     * Sets the updated_date.
     *
     * @param updated_date The updated_date to set.
     */
    public void setUpdated_date(Date updated_date) {
	this.updated_date = updated_date;
    }
}
