
package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;
import java.sql.Date;

/**
 * The Class ConnectionRequest.
 *
 * @author pc79439
 */
@SuppressWarnings("unchecked")
public class Connection extends Base implements Serializable{

    private String discriminator;

    private Long lookupId;

    private com.citigroup.cgti.c3par.relationship.domain.Relationship relationship;

    private Long netconId;

    private String name;

    private String status;

    private String requestorId;

    private String rationale;
    
    private String benefit;
    
    private String plcode;

    private String requireNetworkAccess;

    private String cobredundancyReq;

    private Date requestDate;

    private Date readyDate;
    
    private String comments;

    private String semiannualentitlementReview;

    private String issconnectionCompliance;

    private String citipolicyAdherence;

    private String accesscitiGlobalNetwork;

    private String tptrainingAwarenessPrg;

    private String secreviewComments;

    private String sponsorreviewComments;

    private String activateconComments;

    private String approvedesignComments;

    private String integstatusComments;

    private Date procurementDate;
    
    private String procurementComments;

    private Long conreqId;

    private String sysadminComments;

    private String opanalystComments;

    private String istgComments;

    private Long informanId;

    private Date opanalystScheduleDate;

    private Date opanalystCompletedDate;

    private String exportLicenseCordinator;

    private String sponsorBusinessConsulted;

    private String sownumber;

    private String cmpid;

    private String exportLicenseCoordinatorNew;

    private String directAccessByThirdparty;
    
    private String capappGroupCode;

    private String conforcustclient;
    
    private String semiannualEntlReview;
    
    private String tptrainingAwarnessprg;
    
    private String connectivityEstimate;
    
    private String detailedInfo;

    
    
	public String getDiscriminator() {
		return discriminator;
	}

	public void setDiscriminator(String discriminator) {
		this.discriminator = discriminator;
	}

	public Long getLookupId() {
		return lookupId;
	}

	public void setLookupId(Long lookupId) {
		this.lookupId = lookupId;
	}

	public com.citigroup.cgti.c3par.relationship.domain.Relationship getRelationship() {
		return relationship;
	}

	public void setRelationship(
			com.citigroup.cgti.c3par.relationship.domain.Relationship relationship) {
		this.relationship = relationship;
	}

	public Long getNetconId() {
		return netconId;
	}

	public void setNetconId(Long netconId) {
		this.netconId = netconId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRequestorId() {
		return requestorId;
	}

	public void setRequestorId(String requestorId) {
		this.requestorId = requestorId;
	}

	public String getRationale() {
		return rationale;
	}

	public void setRationale(String rationale) {
		this.rationale = rationale;
	}

	public String getBenefit() {
		return benefit;
	}

	public void setBenefit(String benefit) {
		this.benefit = benefit;
	}

	public String getPlcode() {
		return plcode;
	}

	public void setPlcode(String plcode) {
		this.plcode = plcode;
	}

	public String getRequireNetworkAccess() {
		return requireNetworkAccess;
	}

	public void setRequireNetworkAccess(String requireNetworkAccess) {
		this.requireNetworkAccess = requireNetworkAccess;
	}

	public String getCobredundancyReq() {
		return cobredundancyReq;
	}

	public void setCobredundancyReq(String cobredundancyReq) {
		this.cobredundancyReq = cobredundancyReq;
	}

	public Date getRequestDate() {
		return requestDate;
	}

	public void setRequestDate(Date requestDate) {
		this.requestDate = requestDate;
	}

	public Date getReadyDate() {
		return readyDate;
	}

	public void setReadyDate(Date readyDate) {
		this.readyDate = readyDate;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getSemiannualentitlementReview() {
		return semiannualentitlementReview;
	}

	public void setSemiannualentitlementReview(String semiannualentitlementReview) {
		this.semiannualentitlementReview = semiannualentitlementReview;
	}

	public String getIssconnectionCompliance() {
		return issconnectionCompliance;
	}

	public void setIssconnectionCompliance(String issconnectionCompliance) {
		this.issconnectionCompliance = issconnectionCompliance;
	}

	public String getCitipolicyAdherence() {
		return citipolicyAdherence;
	}

	public void setCitipolicyAdherence(String citipolicyAdherence) {
		this.citipolicyAdherence = citipolicyAdherence;
	}

	public String getAccesscitiGlobalNetwork() {
		return accesscitiGlobalNetwork;
	}

	public void setAccesscitiGlobalNetwork(String accesscitiGlobalNetwork) {
		this.accesscitiGlobalNetwork = accesscitiGlobalNetwork;
	}

	public String getTptrainingAwarenessPrg() {
		return tptrainingAwarenessPrg;
	}

	public void setTptrainingAwarenessPrg(String tptrainingAwarenessPrg) {
		this.tptrainingAwarenessPrg = tptrainingAwarenessPrg;
	}

	public String getSecreviewComments() {
		return secreviewComments;
	}

	public void setSecreviewComments(String secreviewComments) {
		this.secreviewComments = secreviewComments;
	}

	public String getSponsorreviewComments() {
		return sponsorreviewComments;
	}

	public void setSponsorreviewComments(String sponsorreviewComments) {
		this.sponsorreviewComments = sponsorreviewComments;
	}

	public String getActivateconComments() {
		return activateconComments;
	}

	public void setActivateconComments(String activateconComments) {
		this.activateconComments = activateconComments;
	}

	public String getApprovedesignComments() {
		return approvedesignComments;
	}

	public void setApprovedesignComments(String approvedesignComments) {
		this.approvedesignComments = approvedesignComments;
	}

	public String getIntegstatusComments() {
		return integstatusComments;
	}

	public void setIntegstatusComments(String integstatusComments) {
		this.integstatusComments = integstatusComments;
	}

	public Date getProcurementDate() {
		return procurementDate;
	}

	public void setProcurementDate(Date procurementDate) {
		this.procurementDate = procurementDate;
	}

	public String getProcurementComments() {
		return procurementComments;
	}

	public void setProcurementComments(String procurementComments) {
		this.procurementComments = procurementComments;
	}

	public Long getConreqId() {
		return conreqId;
	}

	public void setConreqId(Long conreqId) {
		this.conreqId = conreqId;
	}

	public String getSysadminComments() {
		return sysadminComments;
	}

	public void setSysadminComments(String sysadminComments) {
		this.sysadminComments = sysadminComments;
	}

	public String getOpanalystComments() {
		return opanalystComments;
	}

	public void setOpanalystComments(String opanalystComments) {
		this.opanalystComments = opanalystComments;
	}

	public String getIstgComments() {
		return istgComments;
	}

	public void setIstgComments(String istgComments) {
		this.istgComments = istgComments;
	}

	public Long getInformanId() {
		return informanId;
	}

	public void setInformanId(Long informanId) {
		this.informanId = informanId;
	}

	public Date getOpanalystScheduleDate() {
		return opanalystScheduleDate;
	}

	public void setOpanalystScheduleDate(Date opanalystScheduleDate) {
		this.opanalystScheduleDate = opanalystScheduleDate;
	}

	public Date getOpanalystCompletedDate() {
		return opanalystCompletedDate;
	}

	public void setOpanalystCompletedDate(Date opanalystCompletedDate) {
		this.opanalystCompletedDate = opanalystCompletedDate;
	}

	public String getExportLicenseCordinator() {
		return exportLicenseCordinator;
	}

	public void setExportLicenseCordinator(String exportLicenseCordinator) {
		this.exportLicenseCordinator = exportLicenseCordinator;
	}

	public String getSponsorBusinessConsulted() {
		return sponsorBusinessConsulted;
	}

	public void setSponsorBusinessConsulted(String sponsorBusinessConsulted) {
		this.sponsorBusinessConsulted = sponsorBusinessConsulted;
	}

	public String getSownumber() {
		return sownumber;
	}

	public void setSownumber(String sownumber) {
		this.sownumber = sownumber;
	}

	public String getCmpid() {
		return cmpid;
	}

	public void setCmpid(String cmpid) {
		this.cmpid = cmpid;
	}

	public String getExportLicenseCoordinatorNew() {
		return exportLicenseCoordinatorNew;
	}

	public void setExportLicenseCoordinatorNew(String exportLicenseCoordinatorNew) {
		this.exportLicenseCoordinatorNew = exportLicenseCoordinatorNew;
	}

	public String getDirectAccessByThirdparty() {
		return directAccessByThirdparty;
	}

	public void setDirectAccessByThirdparty(String directAccessByThirdparty) {
		this.directAccessByThirdparty = directAccessByThirdparty;
	}

	public String getCapappGroupCode() {
		return capappGroupCode;
	}

	public void setCapappGroupCode(String capappGroupCode) {
		this.capappGroupCode = capappGroupCode;
	}

	public String getConforcustclient() {
		return conforcustclient;
	}

	public void setConforcustclient(String conforcustclient) {
		this.conforcustclient = conforcustclient;
	}

	public String getSemiannualEntlReview() {
		return semiannualEntlReview;
	}

	public void setSemiannualEntlReview(String semiannualEntlReview) {
		this.semiannualEntlReview = semiannualEntlReview;
	}

	public String getTptrainingAwarnessprg() {
		return tptrainingAwarnessprg;
	}

	public void setTptrainingAwarnessprg(String tptrainingAwarnessprg) {
		this.tptrainingAwarnessprg = tptrainingAwarnessprg;
	}

	public String getConnectivityEstimate() {
		return connectivityEstimate;
	}

	public void setConnectivityEstimate(String connectivityEstimate) {
		this.connectivityEstimate = connectivityEstimate;
	}

	public String getDetailedInfo() {
		return detailedInfo;
	}

	public void setDetailedInfo(String detailedInfo) {
		this.detailedInfo = detailedInfo;
	}

}