/**
 * 
 */
package com.citigroup.cgti.c3par.communication.domain;

import java.util.Date;

/**
 * @author ky38518
 * 
 */
public class CCRCMPMappingDTO {

    private String cmpOrderItemId;
    private String cmpApproverName;
    private String cmpApproverGEId;
    private Date cmpApprovedDate;

    /**
     * @return the cmpOrderItemId
     */
    public String getCmpOrderItemId() {
        return cmpOrderItemId;
    }

    /**
     * @param cmpOrderItemId
     *            the cmpOrderItemId to set
     */
    public void setCmpOrderItemId(String cmpOrderItemId) {
        this.cmpOrderItemId = cmpOrderItemId;
    }

    /**
     * @return the cmpApproverName
     */
    public String getCmpApproverName() {
        return cmpApproverName;
    }

    /**
     * @param cmpApproverName
     *            the cmpApproverName to set
     */
    public void setCmpApproverName(String cmpApproverName) {
        this.cmpApproverName = cmpApproverName;
    }

    /**
     * @return the cmpApproverGEId
     */
    public String getCmpApproverGEId() {
        return cmpApproverGEId;
    }

    /**
     * @param cmpApproverGEId
     *            the cmpApproverGEId to set
     */
    public void setCmpApproverGEId(String cmpApproverGEId) {
        this.cmpApproverGEId = cmpApproverGEId;
    }

    /**
     * @return the cmpApprovedDate
     */
    public Date getCmpApprovedDate() {
        return cmpApprovedDate;
    }

    /**
     * @param cmpApprovedDate
     *            the cmpApprovedDate to set
     */
    public void setCmpApprovedDate(Date cmpApprovedDate) {
        this.cmpApprovedDate = cmpApprovedDate;
    }

}
