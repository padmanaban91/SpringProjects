/**
 *
 */
package com.citigroup.cgti.c3par.common.domain;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;

import com.citigroup.cgti.c3par.common.domain.soc.persist.CommonServicePersistable;
import com.citigroup.cgti.c3par.domain.Base;

/**
 * @author nc43495
 * 
 */
public class ContactDetailsDTO extends Base{
	@Autowired
	private CommonServicePersistable commonServicePersistable;

	/** The log. */
	private static Logger log = Logger.getLogger(ContactDetailsDTO.class);
	
	private String name;
	
	private String ssoID;
	
	private String emailID;
	
	private String phoneNo;
	
	private String role;
	
	private String primaryContact;
	
	private String notifyContact;
	
	private String systemGenerated;

	private String firstName;
	
	private String lastName;
	
	private Long roleId;
	
	private String geid;

	private String isreject;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSsoID() {
		return ssoID;
	}

	public void setSsoID(String ssoID) {
		this.ssoID = ssoID;
	}

	public String getEmailID() {
		return emailID;
	}

	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getPrimaryContact() {
		return primaryContact;
	}

	public void setPrimaryContact(String primaryContact) {
		this.primaryContact = primaryContact;
	}

	public String getNotifyContact() {
		return notifyContact;
	}

	public void setNotifyContact(String notifyContact) {
		this.notifyContact = notifyContact;
	}

	public String getSystemGenerated() {
		return systemGenerated;
	}

	public void setSystemGenerated(String systemGenerated) {
		this.systemGenerated = systemGenerated;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public String getGeid() {
		return geid;
	}

	public void setGeid(String geid) {
		this.geid = geid;
	}

	public String getIsreject() {
		return isreject;
	}

	public void setIsreject(String isreject) {
		this.isreject = isreject;
	}

}
