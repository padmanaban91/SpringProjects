package com.citigroup.cgti.c3par.bpm.ejb.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


/**
 * The Class ProcessRFCDTO.
 */
public class ProcessRFCDTO implements Serializable{

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 905239232364211468L;
    //tiProcess properties	
    /** The id. */
    private Long id;

    /** The name. */
    private String name;
    //tiRequest properties	
    /** The ti request id. */
    private Long tiRequestId;

    /** The rfc request dto list. */
    private List<RFCRequestDTO> rfcRequestDTOList=new ArrayList();

    /** The process rfc status. */
    private String processRFCStatus;
    
    private String conType;

    /**
     * Gets the id.
     *
     * @return the id
     */
    public Long getId() {
	return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
	this.id = id;
    }

    /**
     * Gets the name.
     *
     * @return the name
     */
    public String getName() {
	return name;
    }

    /**
     * Sets the name.
     *
     * @param name the new name
     */
    public void setName(String name) {
	this.name = name;
    }

    /**
     * Gets the ti request id.
     *
     * @return the ti request id
     */
    public Long getTiRequestId() {
	return tiRequestId;
    }

    /**
     * Sets the ti request id.
     *
     * @param tiRequestId the new ti request id
     */
    public void setTiRequestId(Long tiRequestId) {
	this.tiRequestId = tiRequestId;
    }

    
    public List<RFCRequestDTO> getRfcRequestDTOList() {
		return rfcRequestDTOList;
	}

	public void setRfcRequestDTOList(List<RFCRequestDTO> rfcRequestDTOList) {
		this.rfcRequestDTOList = rfcRequestDTOList;
	}

	/**
     * Gets the process rfc status.
     *
     * @return the process rfc status
     */
    public String getProcessRFCStatus() {
	return processRFCStatus;
    }

    /**
     * Sets the process rfc status.
     *
     * @param processRFCStatus the new process rfc status
     */
    public void setProcessRFCStatus(String processRFCStatus) {
	this.processRFCStatus = processRFCStatus;
    }

	/**
	 * @return the conType
	 */
	public String getConType() {
		return conType;
	}

	/**
	 * @param conType the conType to set
	 */
	public void setConType(String conType) {
		this.conType = conType;
	}
    
    
}
