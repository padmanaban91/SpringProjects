package com.citigroup.cgti.c3par.businessjustification.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.domain.Role;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

public class SearchInRitsProcess {
	
CCRBeanFactory ccrBeanFactory;
	
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}

	private CitiContact citiContact;
	
	private String[] roleIds;
	
	private String ssoId;

    private List<CitiContact> citiContactList;
    
    private List<Role> roleList;
    
    private String priority;
    
    private String phase;
    
    private boolean acvScheduled = false;
    
    private Long tiRequestId = 0l;
    
    private JdbcTemplate gdwJDBCTemplate;
    
	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}
	
	public String getPhase() {
		return phase;
	}

	public void setPhase(String phase) {
		this.phase = phase;
	}

	public List<Role> getRoleList() {
		return roleList;
	}

	public void setRoleList(List<Role> roleList) {
		this.roleList = roleList;
	}

	public CitiContact getCitiContact() {
		return citiContact;
	}

	public void setCitiContact(CitiContact citiContact) {
		this.citiContact = citiContact;
	}

	public List<CitiContact> getCitiContactList() {
		return citiContactList;
	}

	public void setCitiContactList(List<CitiContact> citiContactList) {
		this.citiContactList = citiContactList;
	}
	
	public String[] getRoleIds() {
		return roleIds;
	}

	public void setRoleIds(String[] roleIds) {
		this.roleIds = roleIds;
	}

	public String getSsoId() {
		return ssoId;
	}

	public void setSsoId(String ssoId) {
		this.ssoId = ssoId;
	}

	public JdbcTemplate getGdwJDBCTemplate() {
		return gdwJDBCTemplate;
	}

	public void setGdwJDBCTemplate(JdbcTemplate gdwJDBCTemplate) {
		this.gdwJDBCTemplate = gdwJDBCTemplate;
	}

	
	public List<Role> getRoles() {
		return ccrBeanFactory.getBusjusServicePersistable().getRoles();	
	}
	
	
	public CitiContact getGDWDataBySSOId(String ssoId) {
		return ccrBeanFactory.getBusjusServicePersistable().getGDWDataBySSOId(ssoId);	
	}

    public boolean isAcvScheduled() {
        return acvScheduled;
    }

    public void setAcvScheduled(boolean acvScheduled) {
        this.acvScheduled = acvScheduled;
    }

    public Long getTiRequestId() {
        return tiRequestId;
    }

    public void setTiRequestId(Long tiRequestId) {
        this.tiRequestId = tiRequestId;
    }
    
}
