package com.citigroup.cgti.c3par.communication.domain;

import java.io.Serializable;
import java.util.Date;

/**
 * @author mr89025
 * 
 */
public class ICGTeamView implements Serializable {

    private static final long serialVersionUID = 16456545L;
    
    private Long agentUserId;
    
    private String agentID;

    private String agentName;
    
    private String firstname;

    private String lastname;

    private Long inQueue;

    private Long bau;

    private Long buscrit_emer;

    private Long assistance;

    private Long today;

    private Long thisWeek;
    
    private Long previousWeek;    

    private String isLocked;

    private String comments;
    
    private boolean selected;

    /**
     * @return the agentUserId
     */
    public Long getAgentUserId() {
        return agentUserId;
    }

    /**
     * @return the agentID
     */
    public String getAgentID() {
        return agentID;
    }

    /**
     * @return the agentName
     */
    public String getAgentName() {
        return agentName;
    }

    /**
     * @return the firstname
     */
    public String getFirstname() {
        return firstname;
    }

    /**
     * @return the lastname
     */
    public String getLastname() {
        return lastname;
    }

    /**
     * @return the inQueue
     */
    public Long getInQueue() {
        return inQueue;
    }

    /**
     * @return the bau
     */
    public Long getBau() {
        return bau;
    }

    /**
     * @return the buscrit_emer
     */
    public Long getBuscrit_emer() {
        return buscrit_emer;
    }

    /**
     * @return the assistance
     */
    public Long getAssistance() {
        return assistance;
    }

    /**
     * @return the today
     */
    public Long getToday() {
        return today;
    }

    /**
     * @return the thisWeek
     */
    public Long getThisWeek() {
        return thisWeek;
    }

    /**
     * @return the previousWeek
     */
    public Long getPreviousWeek() {
        return previousWeek;
    }

    /**
     * @return the isLocked
     */
    public String getIsLocked() {
        return isLocked;
    }

    /**
     * @return the comments
     */
    public String getComments() {
        return comments;
    }

    /**
     * @param agentUserId the agentUserId to set
     */
    public void setAgentUserId(Long agentUserId) {
        this.agentUserId = agentUserId;
    }

    /**
     * @param agentID the agentID to set
     */
    public void setAgentID(String agentID) {
        this.agentID = agentID;
    }

    /**
     * @param agentName the agentName to set
     */
    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }

    /**
     * @param firstname the firstname to set
     */
    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    /**
     * @param lastname the lastname to set
     */
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    /**
     * @param inQueue the inQueue to set
     */
    public void setInQueue(Long inQueue) {
        this.inQueue = inQueue;
    }

    /**
     * @param bau the bau to set
     */
    public void setBau(Long bau) {
        this.bau = bau;
    }

    /**
     * @param buscrit_emer the buscrit_emer to set
     */
    public void setBuscrit_emer(Long buscrit_emer) {
        this.buscrit_emer = buscrit_emer;
    }

    /**
     * @param assistance the assistance to set
     */
    public void setAssistance(Long assistance) {
        this.assistance = assistance;
    }

    /**
     * @param today the today to set
     */
    public void setToday(Long today) {
        this.today = today;
    }

    /**
     * @param thisWeek the thisWeek to set
     */
    public void setThisWeek(Long thisWeek) {
        this.thisWeek = thisWeek;
    }

    /**
     * @param previousWeek the previousWeek to set
     */
    public void setPreviousWeek(Long previousWeek) {
        this.previousWeek = previousWeek;
    }

    /**
     * @param isLocked the isLocked to set
     */
    public void setIsLocked(String isLocked) {
        this.isLocked = isLocked;
    }

    /**
     * @param comments the comments to set
     */
    public void setComments(String comments) {
        this.comments = comments;
    }

    /**
     * @return the selected
     */
    public boolean isSelected() {
        return selected;
    }

    /**
     * @param selected the selected to set
     */
    public void setSelected(boolean selected) {
        this.selected = selected;
    }   

}

