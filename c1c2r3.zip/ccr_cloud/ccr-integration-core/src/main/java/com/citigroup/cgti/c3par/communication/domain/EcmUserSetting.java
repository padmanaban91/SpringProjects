/**
 * 
 */
package com.citigroup.cgti.c3par.communication.domain;

/**
 * @author ka58098
 *
 */
public class EcmUserSetting extends EcmBaseEntity {
    /**
     * 
     */
    private static final long serialVersionUID = -4316223990971809852L;
    private Long id;
    private Long userId;
    private Long viewId;
    private Long resultsPerPage;
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public Long getUserId() {
        return userId;
    }
    public void setUserId(Long userId) {
        this.userId = userId;
    }
    public Long getViewId() {
        return viewId;
    }
    public void setViewId(Long viewId) {
        this.viewId = viewId;
    }
    public Long getResultsPerPage() {
        return resultsPerPage;
    }
    public void setResultsPerPage(Long resultsPerPage) {
        this.resultsPerPage = resultsPerPage;
    }
     
}
