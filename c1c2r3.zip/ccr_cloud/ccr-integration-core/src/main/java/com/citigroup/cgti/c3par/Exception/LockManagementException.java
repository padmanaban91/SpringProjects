/*
 * CONFIDENTIAL  AND PROPRIETARY
 * Copyright © 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is 
 * strictly prohibited.
 */
package com.citigroup.cgti.c3par.Exception;


/**
 * The Class LockManagementException.
 *
 * @author pkadam
 * 
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class LockManagementException extends Exception {

    /**
     * Instantiates a new lock management exception.
     *
     * @param msg the msg
     */
    public LockManagementException(String msg) {
	super(msg);
    }

    /**
     * Instantiates a new lock management exception.
     */
    public LockManagementException() {
	super();
    }

    /**
     * Instantiates a new lock management exception.
     *
     * @param e the e
     */
    public LockManagementException(Exception e) {
	super(e);
    }
}
