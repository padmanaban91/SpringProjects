package com.citigroup.ccr.gis;

import java.util.Date;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.citigroup.cgti.c3par.domain.TIRequest;

public class SpecialInstructions {

    private Long id;
    private TIRequest tiRequest;
    private String specialInstructions;
    private Date createdDate;
    private String createdBy;
    private String specialInstructionsBy;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public TIRequest getTiRequest() {
        return tiRequest;
    }

    public void setTiRequest(TIRequest tiRequest) {
        this.tiRequest = tiRequest;
    }

    public String getSpecialInstructions() {
        return specialInstructions;
    }

    public void setSpecialInstructions(String specialInstructions) {
        this.specialInstructions = specialInstructions;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }
    
    public String getSpecialInstructionsBy(){
        return specialInstructionsBy;
    }
    
    public void setSpecialInstructionsBy(String specialInstructionsBy){
        this.specialInstructionsBy = specialInstructionsBy;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

}
