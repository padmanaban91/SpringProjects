package com.citigroup.cgti.c3par.bpm.ejb.search.domain;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.bpm.ejb.domain.LookupDTO;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

@SuppressWarnings( { "unchecked", "unused" })

public class SearchMyConnectionsProcess {

//	private ClassPathXmlApplicationContext context;
	
CCRBeanFactory ccrBeanFactory;
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}
	
		/** The log. */
	private static Logger log = Logger.getLogger(SearchMyConnectionsProcess.class);

	private GeneralSearchAttributes generalSearchAttributes;
	
	public static final String LISTTYPE_ROLE="role";
	public static final String LISTTYPE_TASK="task";
	public static final String LISTTYPE_SECTOR="sector";
	public static final String LISTTYPE_REGION="region";

	private List processList;
	private List<LookupDTO>sectorList;
	private List<LookupDTO> rolesList;
	private List<LookupDTO> taskTypeList;
	private List<LookupDTO> regionList;

	private Integer pageSize;
	private String searchType;
	
	private boolean export;
	
	//properties used for ACV extension
	private List<GenericLookup> acvExtensionOptionsList;
    private String acvExtensionType;
    private int acvExtensionValue=0;
    private String acvExtendedDate;
	
	 //properties used for pagination
    private int rowCount;
    private int offset;
    private int limit;
    private int pageNo;
    private String field;
    private int totalPages;
	
	public GeneralSearchAttributes getGeneralSearchAttributes() {
		return generalSearchAttributes;
	}

	public void setGeneralSearchAttributes(
			GeneralSearchAttributes generalSearchAttributes) {
		this.generalSearchAttributes = generalSearchAttributes;
	}


	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public Integer getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(Integer totalPages) {
		this.totalPages = totalPages;
	}

	public String getSearchType() {
		return searchType;
	}

	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}
	
	public boolean isExport() {
		return export;
	}

	public void setExport(boolean export) {
		this.export = export;
	}

	public List<LookupDTO> getRolesList() throws Exception {
 		List<LookupDTO> list = ccrBeanFactory.getSearchProcess().getMyTaskContactPageDropdownList(generalSearchAttributes,LISTTYPE_ROLE);
		if (list == null) {
			list = new ArrayList<LookupDTO>();
		}
		return list;
	}

	public void setRolesList(List<LookupDTO> rolesList) {
		this.rolesList = rolesList;
	}
	
	public List<GenericLookup> getACVExtensionOptions(){
    	return ccrBeanFactory.getSubmitActivityPersistable().getACVExtensionOptions();
    }
	
	public List<GenericLookup> getAcvExtensionOptionsList() {
		return acvExtensionOptionsList;
	}

	public void setAcvExtensionOptionsList(
			List<GenericLookup> acvExtensionOptionsList) {
		this.acvExtensionOptionsList = acvExtensionOptionsList;
	}

	public String getAcvExtensionType() {
		return acvExtensionType;
	}

	public void setAcvExtensionType(String acvExtensionType) {
		this.acvExtensionType = acvExtensionType;
	}

	public int getAcvExtensionValue() {
		return acvExtensionValue;
	}

	public void setAcvExtensionValue(int acvExtensionValue) {
		this.acvExtensionValue = acvExtensionValue;
	}

	public String getAcvExtendedDate() {
		return acvExtendedDate;
	}

	public void setAcvExtendedDate(String acvExtendedDate) {
		this.acvExtendedDate = acvExtendedDate;
	}

	public List<LookupDTO> getTaskTypeList() throws Exception {
	 
		List<LookupDTO> list = ccrBeanFactory.getSearchProcess().getMyTaskContactPageDropdownList(generalSearchAttributes,LISTTYPE_TASK);
		if (list == null) {
			list = new ArrayList<LookupDTO>();
		}
		return list;
	}

	public void setTaskTypeList(List<LookupDTO> taskTypeList) {
		this.taskTypeList = taskTypeList;
	}

	
	public List<LookupDTO> getRegionList() throws Exception {
		List<LookupDTO> list = ccrBeanFactory.getSearchProcess().getMyTaskContactPageDropdownList(generalSearchAttributes,LISTTYPE_REGION);
		if (list == null) {
			list = new ArrayList<LookupDTO>();
		}
		return list;
	}

	public void setRegionList(List<LookupDTO> regionList) {
		this.regionList = regionList;
	}

	public List<LookupDTO> getSectorList() throws Exception {
		List<LookupDTO> list = ccrBeanFactory.getSearchProcess().getMyTaskContactPageDropdownList(generalSearchAttributes,LISTTYPE_SECTOR);
		if (list == null) {
			list = new ArrayList<LookupDTO>(); 
		}
		return list;
	}

	public void setSectorList(List<LookupDTO> sectorList) {
		this.sectorList = sectorList;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	/*public Integer getSearchRecordCount() throws Exception {
		int searchRecordCount = 0;
		if(getSearchType().equals("MY_TASK_CONTACTS")&& generalSearchAttributes.getRequesterSOEId() != null
				&& !generalSearchAttributes.getRequesterSOEId().equals("")){
			 
			 
			log.debug("Inside SearchProcess.getSearchRecordCount for Contacts:getSearchType():"+getSearchType()+"generalSearchAttributes.getRequesterSOEId()::"+
					generalSearchAttributes.getRequesterSOEId());
			 
			 
			searchRecordCount = searchProcess.getMyTaskContactRecordCount(generalSearchAttributes, 0, 0);
			 
			return searchRecordCount;
		}
		return null;
	}*/

	
//	public List loadProcessList() throws Exception {
//		return loadProcessList(0);
//	}
	
	
	/*public List loadProcessList(int recCnt) throws Exception {
		log.info("SearchProcess.getProcessList method started: ");
		log.debug("Inside the SearchProcess.getProcessList pagesize and pageno:"
				+ getPageSize() + ":" + getPageNo());
	if (getSearchType().equals("MY_TASK_CONTACTS")
				&& generalSearchAttributes.getRequesterSOEId() != null 
				&& !generalSearchAttributes.getRequesterSOEId().equals("")) {
			 	 
			processList = searchProcess.getMyContactTaskSearchResult(
					generalSearchAttributes, getPageSize(), getPageNo(),recCnt);
			log.debug("SearchProcess.getProcessList method ProcessList Size: "
					+ processList.size());
			log.debug("SearchProcess.getProcessList method started: ");
			 
			return processList;

		} else {
			return new ArrayList();
		}
	}*/
	
	public void setProcessList(List processList) {
		this.processList = processList;
	}

	public List getProcessList() {
		return this.processList; 
	}
	public List getAllRolesList() throws Exception {
		return ccrBeanFactory.getSearchProcess().getAllRolesList();
	}

	public int getRowCount() {
		return rowCount;
	}

	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}

	public int getOffset() {
		return offset;
	}

	public void setOffset(int offset) {
		this.offset = offset;
	}

	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public String getField() {
		return field;
	}

	public void setField(String field) {
		this.field = field;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}
	
	
	public List<Process> getMyConnections() throws Exception {
		return ccrBeanFactory.getSearchProcess().getMyConnections(this);
	}
	
 }
