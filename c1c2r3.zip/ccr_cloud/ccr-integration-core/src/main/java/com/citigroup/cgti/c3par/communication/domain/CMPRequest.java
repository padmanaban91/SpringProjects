package com.citigroup.cgti.c3par.communication.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.common.domain.TIActivityTrail;
import com.citigroup.cgti.c3par.common.domain.TIMailAudit;
import com.citigroup.cgti.c3par.communication.domain.soc.persist.CMPRequestPersistable;
import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.user.domain.C3parUser;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

@SuppressWarnings("serial")
public class CMPRequest extends Base implements Serializable {
    private static final long serialVersionUID = 1L;

     CCRBeanFactory ccrBeanFactory;
    {
        ApplicationContext appContext = CCRApplicationContextUtils.getApplicationContext();
        if (appContext != null && appContext.containsBean("cCRBeanFactory")) {
            ccrBeanFactory = (CCRBeanFactory) appContext.getBean("cCRBeanFactory");
        } else {
            System.out.println("appContext is null");
        }

    }

    public CMPRequestPersistable getCmpRequestPersistable() {
        return ccrBeanFactory.getCmpRequestPersistable();
    }

    private String orderId;
    private String orderItemId;
    private String status;
    private String step;
    private Date availableDate;
    private Date closedDate;
    private String orderByUser;
    private String orderBySoeID;
    private String orderForUser;
    private String orderForSoeID;
    private String assignedGroup;
    private C3parUser assignedUser;
    private String requestType;
    private String typeofConnectivityInvolved;
    private String id_2;
    private String requestUrgency;
    private String projectSector;
    private String region;
    private String businessjustification;
    private String terminationType;
    private String id_1;
    private Date updatedDate;
    private String businessGroup;
    private String affectedBusiness;
    private String thirdParty;
    private String supplierId;
    private String detailId;
    private String connectionName;
    private String relationshipId;
    private String ccrId;
    private String ccrIdWithVerNo;
    private Date updateAssignedUserDate;
    private String ecmSector;
    private String checkTiId;
    private String taskCodeColor;
    private String taskName;
    private String sloStatus;
    private String slo;
    private String requestTypeVal;
    private String chgId;
    private String chgDate;
    private String requestorName;
    private String dateAssigned;
    private String currentStatus;
    private String actCode;
    private boolean isWaitingForUserReply;
    private boolean isEcmInput;

    private List<CMPRequestContactXref> cmpRequestContactXrefs;
    private List<TIActivityTrail> tiactivityTrail;
    private List<TIMailAudit> timailAudit;
    private List<CMPRequestNotes> cmpRequestNotes;
    private List<CMPRequestAttachments> cmpRequestAttachments;

    private Date accessFormRemainderDate;
    private Long sloDays;
    private Long ecmTimer;

    private List<Map<String, String>> changeRequestDetails;
    private List<String> changeRequestIDDetails;
    private List<String> changeRequestDateDetails;
    private List<CmpAttachmentsDTO> cmpAttachmentsDtoList;
    private List<CcrCmpXrefDto> ccrCmpXrefDtoList;
    private String directorApprover;
    private Date directorApprovalDate;
    private String typeOfEntity;
    private String citiData;
    private String customerData;
    private String technicalDetails;
    private String gocCode;
    private String directAccess;
    private String[] reasonsDirectConArr;
    private String reasonsDirectCon;
    
    private String thirdPartyContactName;
    private String thirdPartyContactType;
    private String thirdPartyContactPhone;
    private String thirdPartyContactEmail;
    private String relationshipType;
    private String additionalInformationComment;
    
    private String mgrCompleteReason;
    private String isManagerCompleted;


    /**
     * @return the directorApprover
     */
    public String getDirectorApprover() {
        return directorApprover;
    }

    /**
     * @param directorApprover
     *            the directorApprover to set
     */
    public void setDirectorApprover(String directorApprover) {
        this.directorApprover = directorApprover;
    }

    /**
     * @return the directorApprovalDate
     */
    public Date getDirectorApprovalDate() {
        return directorApprovalDate;
    }

    /**
     * @param directorApprovalDate
     *            the directorApprovalDate to set
     */
    public void setDirectorApprovalDate(Date directorApprovalDate) {
        this.directorApprovalDate = directorApprovalDate;
    }

    /**
     * @return ccrCmpXrefDtoList
     */
    public List<CcrCmpXrefDto> getCcrCmpXrefDtoList() {
        return ccrCmpXrefDtoList;
    }

    /**
     * @param ccrCmpXrefDtoList
     */
    public void setCcrCmpXrefDtoList(List<CcrCmpXrefDto> ccrCmpXrefDtoList) {
        this.ccrCmpXrefDtoList = ccrCmpXrefDtoList;
    }

    public List<CmpAttachmentsDTO> getCmpAttachmentsDtoList() {
        return cmpAttachmentsDtoList;
    }

    public void setCmpAttachmentsDtoList(List<CmpAttachmentsDTO> cmpAttachmentsDtoList) {
        this.cmpAttachmentsDtoList = cmpAttachmentsDtoList;
    }

    public String getCurrentStatus() {
        return currentStatus;
    }

    public void setCurrentStatus(String currentStatus) {
        this.currentStatus = currentStatus;
    }

    public String getEcmSector() {
        return ecmSector;
    }

    public void setEcmSector(String ecmSector) {
        this.ecmSector = ecmSector;
    }

    public Date getUpdateAssignedUserDate() {
        return updateAssignedUserDate;
    }

    public void setUpdateAssignedUserDate(Date updateAssignedUserDate) {
        this.updateAssignedUserDate = updateAssignedUserDate;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getOrderItemId() {
        return orderItemId;
    }

    public void setOrderItemId(String orderItemId) {
        this.orderItemId = orderItemId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStep() {
        return step;
    }

    public void setStep(String step) {
        this.step = step;
    }

    public Date getAvailableDate() {
        return availableDate;
    }

    public void setAvailableDate(Date availableDate) {
        this.availableDate = availableDate;
    }

    public Date getClosedDate() {
        return closedDate;
    }

    public void setClosedDate(Date closedDate) {
        this.closedDate = closedDate;
    }

    public String getOrderByUser() {
        return orderByUser;
    }

    public void setOrderByUser(String orderByUser) {
        this.orderByUser = orderByUser;
    }

    public String getOrderBySoeID() {
        return orderBySoeID;
    }

    public void setOrderBySoeID(String orderBySoeID) {
        this.orderBySoeID = orderBySoeID;
    }

    public String getOrderForUser() {
        return orderForUser;
    }

    public void setOrderForUser(String orderForUser) {
        this.orderForUser = orderForUser;
    }

    public String getOrderForSoeID() {
        return orderForSoeID;
    }

    public void setOrderForSoeID(String orderForSoeID) {
        this.orderForSoeID = orderForSoeID;
    }

    public String getAssignedGroup() {
        return assignedGroup;
    }

    public void setAssignedGroup(String assignedGroup) {
        this.assignedGroup = assignedGroup;
    }

    public C3parUser getAssignedUser() {
        return assignedUser;
    }

    public void setAssignedUser(C3parUser assignedUser) {
        this.assignedUser = assignedUser;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public String getTypeofConnectivityInvolved() {
        return typeofConnectivityInvolved;
    }

    public void setTypeofConnectivityInvolved(String typeofConnectivityInvolved) {
        this.typeofConnectivityInvolved = typeofConnectivityInvolved;
    }

    public String getRequestUrgency() {
        return requestUrgency;
    }

    public void setRequestUrgency(String requestUrgency) {
        this.requestUrgency = requestUrgency;
    }

    public String getProjectSector() {
        return projectSector;
    }

    public void setProjectSector(String projectSector) {
        this.projectSector = projectSector;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getBusinessjustification() {
        return businessjustification;
    }

    public void setBusinessjustification(String businessjustification) {
        this.businessjustification = businessjustification;
    }

    public String getTerminationType() {
        return terminationType;
    }

    public void setTerminationType(String terminationType) {
        this.terminationType = terminationType;
    }

    public String getId_1() {
        return id_1;
    }

    public void setId_1(String id_1) {
        this.id_1 = id_1;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getBusinessGroup() {
        return businessGroup;
    }

    public void setBusinessGroup(String businessGroup) {
        this.businessGroup = businessGroup;
    }

    public String getAffectedBusiness() {
        return affectedBusiness;
    }

    public void setAffectedBusiness(String affectedBusiness) {
        this.affectedBusiness = affectedBusiness;
    }

    public String getThirdParty() {
        return thirdParty;
    }

    public void setThirdParty(String thirdParty) {
        this.thirdParty = thirdParty;
    }

    public String getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(String supplierId) {
        this.supplierId = supplierId;
    }

    public String getDetailId() {
        return detailId;
    }

    public void setDetailId(String detailId) {
        this.detailId = detailId;
    }

    public String getConnectionName() {
        return connectionName;
    }

    public void setConnectionName(String connectionName) {
        this.connectionName = connectionName;
    }

    public String getRelationshipId() {
        return relationshipId;
    }

    public void setRelationshipId(String relationshipId) {
        this.relationshipId = relationshipId;
    }

    public String getCcrId() {
        return ccrId;
    }

    public void setCcrId(String ccrId) {
        this.ccrId = ccrId;
    }
    
    public String getCcrIdWithVerNo() {
        return ccrIdWithVerNo;
    }

    public void setCcrIdWithVerNo(String ccrIdWithVerNo) {
        this.ccrIdWithVerNo = ccrIdWithVerNo;
    }

    public List<CMPRequestContactXref> getCmpRequestContactXrefs() {
        return cmpRequestContactXrefs;
    }

    public void setCmpRequestContactXrefs(List<CMPRequestContactXref> cmpRequestContactXrefs) {
        this.cmpRequestContactXrefs = cmpRequestContactXrefs;
    }

    public List<TIActivityTrail> getTiactivityTrail() {
        return tiactivityTrail;
    }

    public void setTiactivityTrail(List<TIActivityTrail> tiactivityTrail) {
        this.tiactivityTrail = tiactivityTrail;
    }

    public List<TIMailAudit> getTimailAudit() {
        return timailAudit;
    }

    public void setTimailAudit(List<TIMailAudit> timailAudit) {
        this.timailAudit = timailAudit;
    }

    public List<CMPRequestNotes> getCmpRequestNotes() {
        return cmpRequestNotes;
    }

    public void setCmpRequestNotes(List<CMPRequestNotes> cmpRequestNotes) {
        this.cmpRequestNotes = cmpRequestNotes;
    }

    public Date getAccessFormRemainderDate() {
        return accessFormRemainderDate;
    }

    public void setAccessFormRemainderDate(Date accessFormRemainderDate) {
        this.accessFormRemainderDate = accessFormRemainderDate;
    }

    public Long getEcmTimer() {
        return ecmTimer;
    }

    public void setEcmTimer(Long ecmTimer) {
        this.ecmTimer = ecmTimer;
    }

    public Long getSloDays() {
        return sloDays;
    }

    public void setSloDays(Long sloDays) {
        this.sloDays = sloDays;
    }

    public String getId_2() {
        return id_2;
    }

    public void setId_2(String id_2) {
        this.id_2 = id_2;
    }

    public String getCheckTiId() {
        return checkTiId;
    }

    public void setCheckTiId(String checkTiId) {
        this.checkTiId = checkTiId;
    }

    public String getTaskCodeColor() {
        return taskCodeColor;
    }

    public void setTaskCodeColor(String taskCodeColor) {
        this.taskCodeColor = taskCodeColor;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getSloStatus() {
        return sloStatus;
    }

    public void setSloStatus(String sloStatus) {
        this.sloStatus = sloStatus;
    }

    public String getSlo() {
        return slo;
    }

    public void setSlo(String slo) {
        this.slo = slo;
    }

    public String getRequestTypeVal() {
        return requestTypeVal;
    }

    public void setRequestTypeVal(String requestTypeVal) {
        this.requestTypeVal = requestTypeVal;
    }

    public String getChgId() {
        return chgId;
    }

    public void setChgId(String chgId) {
        this.chgId = chgId;
    }

    public String getChgDate() {
        return chgDate;
    }

    public void setChgDate(String chgDate) {
        this.chgDate = chgDate;
    }

    public String getRequestorName() {
        return requestorName;
    }

    public void setRequestorName(String requestorName) {
        this.requestorName = requestorName;
    }

    public String getDateAssigned() {
        return dateAssigned;
    }

    public void setDateAssigned(String dateAssigned) {
        this.dateAssigned = dateAssigned;
    }

    public List<CMPRequestAttachments> getCmpRequestAttachments() {
        return cmpRequestAttachments;
    }

    public void setCmpRequestAttachments(List<CMPRequestAttachments> cmpRequestAttachments) {
        this.cmpRequestAttachments = cmpRequestAttachments;
    }

    public List<Map<String, String>> getChangeRequestDetails() {
        return changeRequestDetails;
    }

    public void setChangeRequestDetails(List<Map<String, String>> changeRequestDetails) {
        this.changeRequestDetails = changeRequestDetails;
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public Long saveCmpRequestfield(String cmpRequestString) {
        return ccrBeanFactory.getCmpRequestPersistable().saveCmpRequestfield(cmpRequestString);
    }

    public void cmpActivityTrail(Long cmpId, String ssoId, String taskCode, String activityStatus) {
        ccrBeanFactory.getCmpRequestPersistable().cmpActivityTrail(cmpId, ssoId, taskCode, activityStatus,0l);
    }

    @Transactional(readOnly = true)
    public byte[] getCmpData(String cmpReqId) {
        return ccrBeanFactory.getCmpRequestPersistable().getCmpData(cmpReqId);
    }
    
    public int saveDirectorApprover(String orderItemId, String approverName, String approverGeid){
        return ccrBeanFactory.getCmpRequestPersistable().saveDirectorApprover(orderItemId, approverName, approverGeid);
    }
    
    @Transactional(readOnly=true)
    public List<CmpDocumentMetaData> getCMPDocumentDetail(String orderItemId){
    	return ccrBeanFactory.getCmpRequestPersistable().getDocumentDetail(orderItemId);
    }
    
    public List<String> getChangeRequestIDDetails() {
        return changeRequestIDDetails;
    }

    public void setChangeRequestIDDetails(List<String> changeRequestIDDetails) {
        this.changeRequestIDDetails = changeRequestIDDetails;
    }

    public List<String> getChangeRequestDateDetails() {
        return changeRequestDateDetails;
    }

    public void setChangeRequestDateDetails(List<String> changeRequestDateDetails) {
        this.changeRequestDateDetails = changeRequestDateDetails;
    }
    
    @Override
    public boolean equals(Object cmpRequestObject) {
        if (this == cmpRequestObject) {
            return true;            
        }
        if (cmpRequestObject == null) {
            return false;
        }
        if (getClass() != cmpRequestObject.getClass()) {
            return false;
        }
        CMPRequest cmpRequest = (CMPRequest) cmpRequestObject;
        return Objects.equals(orderItemId, cmpRequest.orderItemId)
                && Objects.equals(ccrIdWithVerNo, cmpRequest.ccrIdWithVerNo);
    }

    @Override
    public int hashCode()
    {
        int hashCode = 0;
        if(orderItemId != null && ccrIdWithVerNo != null){
            hashCode = orderItemId.hashCode() + ccrIdWithVerNo.hashCode();     
        }
        return hashCode;
    }

    /**
     * @return the typeOfEntity
     */
    public String getTypeOfEntity() {
        return typeOfEntity;
    }

    /**
     * @param typeOfEntity
     *            the typeOfEntity to set
     */
    public void setTypeOfEntity(String typeOfEntity) {
        this.typeOfEntity = typeOfEntity;
    }

    /**
     * @return the citiData
     */
    public String getCitiData() {
        return citiData;
    }

    /**
     * @param citiData
     *            the citiData to set
     */
    public void setCitiData(String citiData) {
        this.citiData = citiData;
    }

    /**
     * @return the customerData
     */
    public String getCustomerData() {
        return customerData;
    }

    /**
     * @param customerData
     *            the customerData to set
     */
    public void setCustomerData(String customerData) {
        this.customerData = customerData;
    }

    /**
     * @return the technicalDetails
     */
    public String getTechnicalDetails() {
        return technicalDetails;
    }

    /**
     * @param technicalDetails
     *            the technicalDetails to set
     */
    public void setTechnicalDetails(String technicalDetails) {
        this.technicalDetails = technicalDetails;
    }

    /**
     * @return the gocCode
     */
    public String getGocCode() {
        return gocCode;
    }

    /**
     * @param gocCode
     *            the gocCode to set
     */
    public void setGocCode(String gocCode) {
        this.gocCode = gocCode;
    }

    /**
     * @return the directAccess
     */
    public String getDirectAccess() {
        return directAccess;
    }

    /**
     * @param directAccess
     *            the directAccess to set
     */
    public void setDirectAccess(String directAccess) {
        this.directAccess = directAccess;
    }

	public String[] getReasonsDirectConArr() {
		return reasonsDirectConArr;
	}

	public void setReasonsDirectConArr(String[] reasonsDirectConArr) {
		this.reasonsDirectConArr = reasonsDirectConArr;
	}

	public String getReasonsDirectCon() {
		return reasonsDirectCon;
	}

	public void setReasonsDirectCon(String reasonsDirectCon) {
		this.reasonsDirectCon = reasonsDirectCon;
	}

    public String getThirdPartyContactName() {
        return thirdPartyContactName;
    }

    public void setThirdPartyContactName(String thirdPartyContactName) {
        this.thirdPartyContactName = thirdPartyContactName;
    }

    public String getThirdPartyContactType() {
        return thirdPartyContactType;
    }

    public void setThirdPartyContactType(String thirdPartyContactType) {
        this.thirdPartyContactType = thirdPartyContactType;
    }

    public String getThirdPartyContactPhone() {
        return thirdPartyContactPhone;
    }

    public void setThirdPartyContactPhone(String thirdPartyContactPhone) {
        this.thirdPartyContactPhone = thirdPartyContactPhone;
    }

    public String getThirdPartyContactEmail() {
        return thirdPartyContactEmail;
    }

    public void setThirdPartyContactEmail(String thirdPartyContactEmail) {
        this.thirdPartyContactEmail = thirdPartyContactEmail;
    }

	public String getRelationshipType() {
		return relationshipType;
	}

	public void setRelationshipType(String relationshipType) {
		this.relationshipType = relationshipType;
	}

	public String getAdditionalInformationComment() {
		return additionalInformationComment;
	}

	public void setAdditionalInformationComment(String additionalInformationComment) {
		this.additionalInformationComment = additionalInformationComment;
	}

    public String getActCode() {
        return actCode;
    }

    public void setActCode(String actCode) {
        this.actCode = actCode;
    }

    public boolean isWaitingForUserReply() {
        return isWaitingForUserReply;
    }

    public void setWaitingForUserReply(boolean isWaitingForUserReply) {
        this.isWaitingForUserReply = isWaitingForUserReply;
    }

    public boolean isEcmInput() {
        return isEcmInput;
    }

    public void setEcmInput(boolean isEcmInput) {
        this.isEcmInput = isEcmInput;
    }

    /**
     * @return the mgrCompleteReason
     */
    public String getMgrCompleteReason() {
        return mgrCompleteReason;
    }

    /**
     * @param mgrCompleteReason
     *            the mgrCompleteReason to set
     */
    public void setMgrCompleteReason(String mgrCompleteReason) {
        this.mgrCompleteReason = mgrCompleteReason;
    }

    /**
     * @return the isManagerCompleted
     */
    public String getIsManagerCompleted() {
        return isManagerCompleted;
    }

    /**
     * @param isManagerCompleted
     *            the isManagerCompleted to set
     */
    public void setIsManagerCompleted(String isManagerCompleted) {
        this.isManagerCompleted = isManagerCompleted;
    }
    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public void saveCmpChangeLogDetails(CmpChangeLogDetails cmpChangeLogDetails){
         ccrBeanFactory.getCmpRequestPersistable().saveCmpChangeLogDetails(cmpChangeLogDetails);
    }
    
    
}
