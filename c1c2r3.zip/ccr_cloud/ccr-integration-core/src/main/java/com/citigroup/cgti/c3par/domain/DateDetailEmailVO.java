package com.citigroup.cgti.c3par.domain;

import javax.xml.bind.annotation.XmlElement;

public class DateDetailEmailVO {
	
	private String activationDate;
	private String appsenseScheduledDate;
	private String proxyScheduledDate;
	private String gnccScheduledDate;
	private String ipregScheduledDate;
	private String opeScheduledDate;
	private String expirationDate;
	
	@XmlElement
	public String getActivationDate() {
		return activationDate;
	}
	public void setActivationDate(String activationDate) {
		this.activationDate = activationDate;
	}
	@XmlElement
	public String getAppsenseScheduledDate() {
		return appsenseScheduledDate;
	}
	public void setAppsenseScheduledDate(String appsenseScheduledDate) {
		this.appsenseScheduledDate = appsenseScheduledDate;
	}
	@XmlElement
	public String getProxyScheduledDate() {
		return proxyScheduledDate;
	}
	public void setProxyScheduledDate(String proxyScheduledDate) {
		this.proxyScheduledDate = proxyScheduledDate;
	}
	@XmlElement
	public String getGnccScheduledDate() {
		return gnccScheduledDate;
	}
	public void setGnccScheduledDate(String gnccScheduledDate) {
		this.gnccScheduledDate = gnccScheduledDate;
	}
	@XmlElement
	public String getIpregScheduledDate() {
		return ipregScheduledDate;
	}
	public void setIpregScheduledDate(String ipregScheduledDate) {
		this.ipregScheduledDate = ipregScheduledDate;
	}
	@XmlElement
	public String getOpeScheduledDate() {
		return opeScheduledDate;
	}
	public void setOpeScheduledDate(String opeScheduledDate) {
		this.opeScheduledDate = opeScheduledDate;
	}
	@XmlElement
	public String getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}
	
	
	
}
