package com.citigroup.cgti.c3par.admin.dao.service;

import java.util.List;

import com.citigroup.cgti.c3par.admin.domain.CCRTags;
import com.citigroup.cgti.c3par.admin.domain.ManageMoreInfoTagDTO;

/**
 * @author ac81662
 *
 */
public interface ManageTagsDao {

    public boolean addTag(ManageMoreInfoTagDTO manageMoreInfoTag) throws Exception;

    public List<ManageMoreInfoTagDTO> getTagsList() throws Exception;

    public void getEditTagDetails(ManageMoreInfoTagDTO manageMoreInfoTag) throws Exception;

    public boolean updateTag(ManageMoreInfoTagDTO manageMoreInfoTag) throws Exception;

    public Boolean deleteTag(Long tagID) throws Exception;

    public boolean checkDuplicateTag(ManageMoreInfoTagDTO manageMoreInfoTag) throws Exception;

    public List<CCRTags> getAllTags() throws Exception;

    public CCRTags getCCrTag(Long ccrId) throws Exception;

    public List<CCRTags> getAllTagsList() throws Exception;

}
