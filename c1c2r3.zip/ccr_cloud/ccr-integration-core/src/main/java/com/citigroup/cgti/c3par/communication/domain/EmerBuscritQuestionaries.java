package com.citigroup.cgti.c3par.communication.domain;

import java.io.Serializable;

public class EmerBuscritQuestionaries implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private Long id;
    private String orderItemId;
    private String question;
    private String answer;
    
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getOrderItemId() {
        return orderItemId;
    }
    public void setOrderItemId(String orderItemId) {
        this.orderItemId = orderItemId;
    }
    public String getQuestion() {
        return question;
    }
    public void setQuestion(String question) {
        this.question = question;
    }
    public String getAnswer() {
        return answer;
    }
    public void setAnswer(String answer) {
        this.answer = answer;
    }

}
