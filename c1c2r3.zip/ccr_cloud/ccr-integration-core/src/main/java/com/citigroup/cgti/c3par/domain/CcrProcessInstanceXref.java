package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;
import java.util.Date;

public class CcrProcessInstanceXref implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long id;
	private TIRequest tiRequest;
	private Long processInstanceId;
	private String rfcType;
	private Date createdDate;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public TIRequest getTiRequest() {
		return tiRequest;
	}

	public void setTiRequest(TIRequest tiRequest) {
		this.tiRequest = tiRequest;
	}

	public Long getProcessInstanceId() {
		return processInstanceId;
	}

	public void setProcessInstanceId(Long processInstanceId) {
		this.processInstanceId = processInstanceId;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	public String getRfcType() {
        return rfcType;
    }

    public void setRfcType(String rfcType) {
        this.rfcType = rfcType;
    }


}
