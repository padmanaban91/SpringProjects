package com.citigroup.cgti.c3par.communication.domain.service.impl;

import com.citigroup.cgti.c3par.communication.domain.service.EcmViewColumnDaoService;

public class EcmViewColumnDaoServiceImpl implements EcmViewColumnDaoService {

}
