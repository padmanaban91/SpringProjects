package com.citigroup.cgti.c3par.admin.service.impl;

import java.util.Comparator;

import com.citigroup.cgti.c3par.domain.Role;

public class RoleComparator implements Comparator<Role> {

    @Override
    public int compare(Role role1, Role role2) {
        return role1.getDisplayName().compareTo(role2.getDisplayName());
    }

}
