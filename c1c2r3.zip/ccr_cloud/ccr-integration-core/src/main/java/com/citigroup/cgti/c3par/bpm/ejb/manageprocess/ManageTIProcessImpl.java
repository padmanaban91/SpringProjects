package com.citigroup.cgti.c3par.bpm.ejb.manageprocess;

import static com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleConstants.TEMPLT_UING_CONN_MAIL_B4_TECH;
import static com.citigroup.cgti.c3par.util.C3parProperties.ISA_REGISTRY_EMAIL;
import static com.citigroup.cgti.c3par.util.C3parProperties.SENDEMAIL_TO_CSIAPPOWNER;
import static com.citigroup.cgti.c3par.webtier.helper.C3parStatusLookupNames.ACTIVE;
import static com.citigroup.cgti.c3par.webtier.helper.C3parStatusLookupNames.BUSINESS_JUSTIFICATION;
import static com.citigroup.cgti.c3par.webtier.helper.C3parStatusLookupNames.MANAGE_USER_CONTACTS;
import static com.citigroup.cgti.c3par.webtier.helper.C3parStatusLookupNames.TERMINATION_REVIEW;

import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ejb.EJBException;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.C3parTxSession;
import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.bpm.ejb.domain.ActivityDataDTO;
import com.citigroup.cgti.c3par.bpm.ejb.domain.RFCRequestDTO;
import com.citigroup.cgti.c3par.bpm.ejb.domain.TIProcessDTO;
import com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleImpl;
import com.citigroup.cgti.c3par.bpm.ejb.mailmodule.MailModuleUtil;
import com.citigroup.cgti.c3par.bpm.ejb.manageactivity.ManageActivityImpl;
import com.citigroup.cgti.c3par.ccrcmpmapping.service.CCRCMPMappingService;
import com.citigroup.cgti.c3par.configuation.CCRQueries;
import com.citigroup.cgti.c3par.configuation.DatabaseUtil;
import com.citigroup.cgti.c3par.configuation.QueryConstants;
import com.citigroup.cgti.c3par.connection.domain.logic.TechnicalArchitectureUtil;
import com.citigroup.cgti.c3par.dao.ConnectionCitiContactXrefExtDAO;
import com.citigroup.cgti.c3par.dao.ConnectionCitiReqContactXrefExtDAO;
import com.citigroup.cgti.c3par.dao.ConnectionDAO;
import com.citigroup.cgti.c3par.dao.ConnectionExtDAO;
import com.citigroup.cgti.c3par.dao.LocationDAO;
import com.citigroup.cgti.c3par.dao.MaintenanceDAO;
import com.citigroup.cgti.c3par.dao.NetworkConnectionDAO;
import com.citigroup.cgti.c3par.dao.PlanningDAO;
import com.citigroup.cgti.c3par.dao.TIProcessDAO;
import com.citigroup.cgti.c3par.dao.TIProcessTypeDAO;
import com.citigroup.cgti.c3par.dao.TerminationDAO;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.domain.InputMailVO;
import com.citigroup.cgti.c3par.domain.Region;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TargetContactEmail;
import com.citigroup.cgti.c3par.domain.logic.TIProcessService;
import com.citigroup.cgti.c3par.ip.dao.IPRegistrationDAO;
import com.citigroup.cgti.c3par.ip.domain.IPDestinationPorts;
import com.citigroup.cgti.c3par.ip.domain.IPDetail;
import com.citigroup.cgti.c3par.ip.model.IPRegistrationEntity;
import com.citigroup.cgti.c3par.model.CitiContactXrefEntity;
import com.citigroup.cgti.c3par.model.CitiContactXrefExtEntity;
import com.citigroup.cgti.c3par.model.CitiLocationEntity;
import com.citigroup.cgti.c3par.model.CitiReqContactXrefEntity;
import com.citigroup.cgti.c3par.model.CitiReqContactXrefExtEntity;
import com.citigroup.cgti.c3par.model.CommonLookupDataEntity;
import com.citigroup.cgti.c3par.model.ConnectionCitiContactXrefEntity;
import com.citigroup.cgti.c3par.model.ConnectionCitiContactXrefExtEntity;
import com.citigroup.cgti.c3par.model.ConnectionCitiReqContactXrefEntity;
import com.citigroup.cgti.c3par.model.ConnectionCitiReqContactXrefExtEntity;
import com.citigroup.cgti.c3par.model.ConnectionEntity;
import com.citigroup.cgti.c3par.model.ConnectionExtEntity;
import com.citigroup.cgti.c3par.model.ConnectionFacilitiesAffectedXrefEntity;
import com.citigroup.cgti.c3par.model.ConnectionProjectJustificationXrefEntity;
import com.citigroup.cgti.c3par.model.ConnectionResourceXrefEntity;
import com.citigroup.cgti.c3par.model.ConnectionTPContactXrefEntity;
import com.citigroup.cgti.c3par.model.ConnectionTPServiceXrefEntity;
import com.citigroup.cgti.c3par.model.FacilitiesAffectedXrefEntity;
import com.citigroup.cgti.c3par.model.FirewallDetailsEntity;
import com.citigroup.cgti.c3par.model.LocationEntity;
import com.citigroup.cgti.c3par.model.MaintenanceEntity;
import com.citigroup.cgti.c3par.model.MaterialBillEntity;
import com.citigroup.cgti.c3par.model.NetworkConnectionEntity;
import com.citigroup.cgti.c3par.model.PlanningEntity;
import com.citigroup.cgti.c3par.model.ProjectJustificationXrefEntity;
import com.citigroup.cgti.c3par.model.ResourceXrefEntity;
import com.citigroup.cgti.c3par.model.TIProcessEntity;
import com.citigroup.cgti.c3par.model.TPContactXrefEntity;
import com.citigroup.cgti.c3par.model.TPServiceXrefEntity;
import com.citigroup.cgti.c3par.model.TerminationEntity;
import com.citigroup.cgti.c3par.util.C3parStaticNames;
import com.citigroup.cgti.c3par.util.StringUtil;
import com.mentisys.dao.DatabaseException;
/**
 * The Class ManageTIProcessImpl.
 */
@SuppressWarnings({ "unchecked", "unused" })
public class ManageTIProcessImpl extends TIProcessService implements IManageTIProcess {
    private static final String TEMP_APPROVED_BY_CCR = "TEMP_APPROVED_BY_CCR";
    @Autowired
    private ManageActivityImpl manageActivityImpl;

    @Autowired
    private MailModuleImpl mailModuleImpl;

    @Autowired
    private MailModuleUtil mailModuleUtil;

    /** The c3par session. */
    private C3parSession c3parSession;

    private ManageTIProcessUtil manageTIProcessUtil;

    /** The c3par tx session. */
    private C3parTxSession c3parTxSession;

    /** The process type dao. */
    private TIProcessTypeDAO processTypeDao;

    /** The ti process dao. */
    private TIProcessDAO tiProcessDao;

    /** The ip registration dao. */
    private IPRegistrationDAO ipRegistrationDao;

    /** The log. */
    private Logger log = Logger.getLogger(this.getClass().getName());

    @Autowired
    private DatabaseUtil databaseUtil;

    @Autowired
    @Qualifier("jdbcTemplate_ccr")
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private CCRQueries ccrQueries;

    @Autowired
    CCRCMPMappingService ccrCMPMappingService;

    /**
     * @param jdbcTemplate
     *            the jdbcTemplate to set
     */
    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * @param manageActivityImpl
     *            the manageActivityImpl to set
     */
    public void setManageActivityImpl(ManageActivityImpl manageActivityImpl) {
        this.manageActivityImpl = manageActivityImpl;
    }

    /**
     * @param mailModuleImpl
     *            the mailModuleImpl to set
     */
    public void setMailModuleImpl(MailModuleImpl mailModuleImpl) {
        this.mailModuleImpl = mailModuleImpl;
    }

    /**
     * @param mailModuleUtil
     *            the mailModuleUtil to set
     */
    public void setMailModuleUtil(MailModuleUtil mailModuleUtil) {
        this.mailModuleUtil = mailModuleUtil;
    }

    /**
     * @param databaseUtil
     *            the databaseUtil to set
     */
    public void setDatabaseUtil(DatabaseUtil databaseUtil) {
        this.databaseUtil = databaseUtil;
    }

    /**
     * Sets the c3par session.
     * 
     * @param session
     *            the new c3par session
     */
    public void setC3parSession(C3parSession session) {
        c3parSession = session;
    }

    public void setManageTIProcessUtil(ManageTIProcessUtil manageTIProcessUtil) {
        this.manageTIProcessUtil = manageTIProcessUtil;
    }

    /**
     * Sets the c3par tx session.
     * 
     * @param txSession
     *            the new c3par tx session
     */
    public void setC3parTxSession(C3parTxSession txSession) {
        c3parTxSession = txSession;
    }

    /**
     * Sets the ip registration dao.
     * 
     * @param ipRegistrationDao
     *            the new ip registration dao
     */
    public void setIpRegistrationDao(IPRegistrationDAO ipRegistrationDao) {
        this.ipRegistrationDao = ipRegistrationDao;
    }

    // gets Connection and IP registration information used in viewing the
    // details screen of a SCHEDEDULED activity and also gets the business
    // params which derives the workflows
    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * getProcessData(long, java.lang.String, java.lang.String)
     */
    public TIProcess getProcessData(long requestID, String activityCode, String prInfoRequestedActivityCode)
            throws Exception {

        return manageTIProcessUtil.getProcessData(requestID, activityCode, prInfoRequestedActivityCode, null);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * getProcessData(long)
     */
    public TIProcess getProcessData(long requestID) throws Exception {
        return getProcessData(requestID, null, null);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * updateProcessMode(long, java.lang.String)
     */

    public long updateProcessMode(long tiRequestId, String mode) throws Exception {
        int rowsUpdated = 0;
        try {
            log.info("updateProcessMode Starts::tiRequestId="+tiRequestId+"::process_activity_mode="+mode);
            StringBuilder processUpdateSql = new StringBuilder();
            processUpdateSql.append(" update ti_process ");
            processUpdateSql.append(" SET process_activity_mode = ?");
            processUpdateSql.append(" where id in ( select process_id from ti_request where id =?)");

            Object[] params = { mode, tiRequestId };
            rowsUpdated = jdbcTemplate.update(processUpdateSql.toString(), params);
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }
        return rowsUpdated;
    }
    // insert processname,relationshipid,requester ssoid
    // ,processType(IP,Connectione use
    // TIProcessService.IPREGISTRATION,TIProcessService.CONNECTION)) and
    // tirequesttype (Create,maintain ,terminate use
    // TIProcessService.(TIReqType_Create,TIReqType_Maintain,TIReqType_Terminate
    // )return ti requestid
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#insertProcess
     * (com.citigroup.cgti.c3par.bpm.ejb.domain.TIProcessDTO)
     */
    public long insertProcess(TIProcessDTO tiProcessDTO) throws Exception {
        Long time = System.currentTimeMillis();
        log.debug("Entering.. " + tiProcessDTO + " time : " + time);
        if (tiProcessDTO == null) {
            throw new RemoteException("ProcessDTO is Null");
        }
        TIProcess tiProcess = new TIProcess();
        try {
            tiProcess.setName(tiProcessDTO.getName());
            tiProcess.getRelationship().setId(tiProcessDTO.getRelationshipId());
            tiProcess.getBusinessCase().getProcessType().setName(tiProcessDTO.getProcessType());
            tiProcess.getRequestor().setSoeID(tiProcessDTO.getRequestorSOEId());
            tiProcess.getTiRequest().getPriority().setValue1(tiProcessDTO.getPriority());
            insertProcess(tiProcess);
            log.debug("Exiting.. " + tiProcessDTO + " time taken : " + (System.currentTimeMillis() - time));
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw new EJBException(e.getMessage());
        }
        return tiProcess.getTiRequest().getId().longValue();
    }

    /*
     * This method inserts Relationship details(Region,Sector,Business Unit)
     * into TiProcess
     * 
     * (non-Javadoc)
     * 
     * @see
     * com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#insertProcess
     * (com.citigroup.cgti.c3par.domain.TIProcess)
     */
    public long insertProcess(TIProcess tiProcess) throws Exception {
        log.debug("Entering..");
        Connection con = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;

        StringBuilder errMsg = new StringBuilder();
        if (tiProcess == null) {
            errMsg.append("Process is Null");
        }
        if (tiProcess != null) {
            if (tiProcess.getName() == null) {
                errMsg.append("  Process Name is Empty");
            }
            if (tiProcess.getRelationship() != null && tiProcess.getRelationship().getId() == null) {
                errMsg.append("  RelationshipId is Empty");
            }
            if (tiProcess.getBusinessCase() != null && tiProcess.getBusinessCase().getProcessType() != null
                    && tiProcess.getBusinessCase().getProcessType().getName() == null) {
                errMsg.append("  Process Type is Empty");
            }
            if (tiProcess.getRequestor() != null && tiProcess.getRequestor().getSoeID() == null) {
                errMsg.append("  Requester ssoid is empty  ");
            }
        }
        if (errMsg.length() > 0) {
            log.error(errMsg.toString());
            throw new RemoteException("Business Exception : " + errMsg.toString());
        }
        log.debug("Insert Process - " + tiProcess.getName());

        try {
            List list = processTypeDao.findByProcessType(tiProcess.getBusinessCase().getProcessType().getName());
            if (list != null && list.size() > 0) {
                tiProcess.getBusinessCase().getProcessType().setId((Long) list.get(0));
            } else {
                throw new RemoteException("Unknown TI Process with name "
                        + tiProcess.getBusinessCase().getProcessType().getName());
            }

            // Modified query according to new table change
            // (REL_CITI_HIERARCHY_XREF)

            StringBuilder entSQL = new StringBuilder();
            entSQL.append("SELECT REG.ID,");
            entSQL.append("SEC.ID,");
            entSQL.append("BU.ID ");
            entSQL.append("FROM C3PAR.RELATIONSHIP REL  ");
            entSQL.append("JOIN C3PAR.REL_CITI_HIERARCHY_XREF RXREF ON RXREF.RELATIONSHIP_ID = REL.ID ");
            entSQL.append("JOIN  C3PAR.CITI_HIERARCHY_MASTER CITIHIERARCHYMASTER ON  CITIHIERARCHYMASTER.ID = RXREF.CITI_HIERARCHY_MASTER_ID ");
            entSQL.append("JOIN C3PAR.REGION REG ON CITIHIERARCHYMASTER.REGION_ID =REG.ID ");
            entSQL.append("JOIN C3PAR.SECTOR SEC ON CITIHIERARCHYMASTER.SECTOR_ID = SEC.ID ");
            entSQL.append("JOIN C3PAR.BUSINESS_UNIT BU ON CITIHIERARCHYMASTER.BU_ID = BU.ID  ");
            entSQL.append("WHERE REL.ID=? ");

            con = c3parSession.getConnection();
            pStmt = con.prepareStatement(entSQL.toString());
            pStmt.setLong(1, tiProcess.getRelationship().getId().longValue());
            rs = pStmt.executeQuery();
            log.debug("ManageTiProcessImpl Table change:" + entSQL.toString());

            while (rs.next()) {
                Region reg = new Region();
                reg.setId(Long.valueOf(rs.getLong(1)));
                tiProcess.getBusinessCase().getRegionList().add(reg);
                tiProcess.getBusinessCase().getSector().setId(Long.valueOf(rs.getLong(2)));
                tiProcess.getBusinessCase().getBusinessUnit().setId(Long.valueOf(rs.getLong(3)));

            }
            c3parSession.closeStatement(pStmt);

            TIProcessEntity tiProcessEntity = createTIProcessEntity(tiProcess);

            tiProcessDao.insert(tiProcessEntity, false);
            tiProcess.setId(tiProcessEntity.getId());
            // log.info(" ** Process ID Before the exception **
            // "+tiProcess.getId());
            // tiProcess=null;
            if (tiProcess.getId() == null)
                throw new Exception(" Could not successfully create TIProcess for process name " + tiProcess.getName());

            // create tirequest and start activity
            tiProcess.getTiRequest().setVersionNumber(1);
            createRequest(tiProcess);

            if (TIProcess.CONNECTION.equalsIgnoreCase(tiProcess.getBusinessCase().getProcessType().getName())) {
                /*
                 * PlanningEntity planningEntity=new PlanningEntity();
                 * planningEntity.setId(tiProcess.getId());
                 * planningEntity.setConnectionName(tiProcess.getName());
                 * planningEntity
                 * .setRelationshipId(tiProcess.getRelationship().getId());
                 * planningEntity
                 * .setRequesterId(tiProcess.getRequestor().getSoeID());
                 * planningDao.update(planningEntity,false);
                 */
                StringBuilder instConSQL = new StringBuilder(
                        "insert into c3par.con_req (id,discriminator,connection_name,status,relationship_id,requester_id,source_resource_type,target_resource_type,bulk_request) values(?,?,?,?,?,?");
                instConSQL
                        .append(",(select requester_resource_type_id from c3par.relationship where id=?),(select target_resource_type_id from c3par.relationship where id=?),?)");

                pStmt = con.prepareStatement(instConSQL.toString());
                pStmt.setLong(1, tiProcess.getId().longValue());
                pStmt.setString(2, "PLANNING");
                pStmt.setString(3, tiProcess.getName());
                pStmt.setString(4, "Incomplete");
                pStmt.setLong(5, tiProcess.getRelationship().getId().longValue());
                pStmt.setString(6, tiProcess.getRequestor().getSoeID());
                pStmt.setLong(7, tiProcess.getRelationship().getId().longValue());
                pStmt.setLong(8, tiProcess.getRelationship().getId().longValue());
                pStmt.setString(9, "N");
                int conRowsInserted = pStmt.executeUpdate();
                if (conRowsInserted > 0)
                    log.debug("Sucessfully inserted Connection  " + tiProcess.getName() + " with id "
                            + tiProcess.getId());
                else
                    log.error(" Could not Insert Connection  " + tiProcess.getName() + " with id " + tiProcess.getId());

                c3parSession.closeStatement(pStmt);

                String instPlanSQL = " insert into c3par.planning (id) values (?)";
                pStmt = con.prepareStatement(instPlanSQL);
                pStmt.setLong(1, tiProcess.getId().longValue());
                int planRowsInserted = pStmt.executeUpdate();
                if (planRowsInserted > 0)
                    log.info("Sucessfully inserted Planning Data for Connection  " + tiProcess.getName() + " with id "
                            + tiProcess.getId());
                else
                    log.error("Could not Insert Planning Data for " + tiProcess.getName() + " with id "
                            + tiProcess.getId());

                // (1567,'PLANNING','delete','Incomplete',4051,'ep97079',(select
                // requester_resource_type_id from c3par.relationship where
                // id=4051),
                String instSQL = "insert into c3par.ti_request_planning_xref  values (?,?)";
                pStmt = con.prepareStatement(instSQL);
                pStmt.setLong(1, tiProcess.getTiRequest().getId().longValue());
                pStmt.setLong(2, tiProcess.getId().longValue());

                log.debug(" with  values TIRequestID = " + tiProcess.getTiRequest().getId().longValue()
                        + " and Planning =" + tiProcess.getId().longValue());
                pStmt.executeUpdate();

                // INSERT GENERIC RFC
                long tiRequestID = tiProcess.getTiRequest().getId().longValue();
                insertGenericRFC(tiRequestID, RFCRequestDTO.RFC_REQ_TYPE_GENERIC);

            } else if (TIProcess.IPREGISTRATION
                    .equalsIgnoreCase(tiProcess.getBusinessCase().getProcessType().getName())) {
                IPRegistrationEntity ipRegEntity = new IPRegistrationEntity();
                ipRegEntity.setProcessId(tiProcess.getId());
                ipRegistrationDao.insert(ipRegEntity);
                // ipRegEntity.

            }

        } catch (Exception e) {
            log.error(e, e);
            throw new EJBException(e.getMessage());
        } finally {
            c3parSession.closeResultSet(rs);
            c3parSession.closeStatement(pStmt);
            c3parSession.releaseConnection();
        }

        // log.info("return request id"+ tiProcess.getTiRequest().getId());
        return tiProcess.getTiRequest().getId().longValue();

        // return tiProcess.getTiRequest().getId();
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#lockComments
     * (long)
     */

    public void lockComments(long ti_request_id) throws Exception {
        try {

            StringBuilder updateSQL = new StringBuilder(
                    "update c3par.TI_REQUEST_COMMENTS set locked = 'Y' where ti_request_id = ?");
            Object[] params = { ti_request_id };
            int totalReocrdsUpdated = jdbcTemplate.update(updateSQL.toString(), params);
            log.info("locked flag update to Y::ti_request_id=" + ti_request_id + "::totalReocrdsUpdated="
                    + totalReocrdsUpdated);
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * getApprovalControlFlags(long)
     */

    public Map getApprovalControlFlags(long tiRequestId) throws Exception {

        String aclVariance = "N";
        String broadAccess = "N";
        String highRisk = "N";
        String fwRegId = null;
        String fwRegion = null;
        String seFlag = null;
        String fwType = null;
        String tpaFlag = "N";
        String ofacFlag = "N";

        long procId = -1;
        String processType = null;

        Map flagsMap = new HashMap();
        flagsMap.put(TIProcessDTO.ACL_FLAG, Boolean.FALSE);
        flagsMap.put(TIProcessDTO.BROAD_ACCESS_FLAG, Boolean.FALSE);
        flagsMap.put(TIProcessDTO.HIGH_RISK_FLAG, Boolean.FALSE);
        flagsMap.put(TIProcessDTO.SEC_ENGG_FLAG, Boolean.FALSE);
        flagsMap.put(TIProcessDTO.TPA_RISK_FLAG, Boolean.FALSE);
        flagsMap.put(TIProcessDTO.OFAC_RISK_FLAG, Boolean.FALSE);
        flagsMap.put(TIProcessDTO.DENY_FLAG, Boolean.FALSE);

        StringBuilder errMsg = new StringBuilder();
        if (tiRequestId <= 0) {
            errMsg.append("Provide TIRequest ID " + tiRequestId);
        }

        chkBusException(errMsg);

        try {

            StringBuilder procTypeSQL = new StringBuilder(
                    " select tiProc.id,tiProcType.PROCESS_TYPE from c3par.ti_process tiProc,c3par.ti_process_type tiProcType ");
            procTypeSQL
                    .append(" where tiProc.id=(select process_id from c3par.ti_request where id=?) and tiProc.PROCESS_TYPE_ID=tiProcType.ID ");

            SqlRowSet rowSet = jdbcTemplate.queryForRowSet(procTypeSQL.toString(), new Object[] { tiRequestId });
            log.debug("Row Set " + rowSet);
            while (rowSet.next()) {
                procId = rowSet.getLong(1);
                processType = rowSet.getString(2);
            }
            if (procId <= 0) {
                errMsg.append("Invalid TiProccesId " + procId + " for TIRequest ID " + tiRequestId);
            }
            if (processType == null) {
                errMsg.append("No Process Type assigned to TiRequestID " + tiRequestId);
            }

            chkBusException(errMsg);

            StringBuilder highRiskBUSQL = new StringBuilder();
            highRiskBUSQL
                    .append("select id from c3par.business_unit where id in ( select distinct bu_id from c3par.relationship rel ,c3par.ti_process tip,rel_citi_hierarchy_xref rc, ");
            highRiskBUSQL
                    .append("citi_hierarchy_master ch where tip.RELATIONSHIP_ID=rel.id and tip.id= ? and rel.id=rc.relationship_id ");
            highRiskBUSQL
                    .append("and rc.citi_hierarchy_master_id=ch.id) and is_active='Y' and trim(upper(business_name))= ? ");
            // Added to check MAD business Unit as high risk when there is
            // firewall entry for the current version - Uma - Oct 1,2011
            long firewallCount = getcurrentVersionCombCount(tiRequestId);
            log.debug("High Risk Flag for MAD :: tiRequestId " + tiRequestId + "  firewallCount " + firewallCount);

            rowSet = jdbcTemplate.queryForRowSet(highRiskBUSQL.toString(), new Object[] { procId, "MA&D" });
            log.debug("Row Set " + rowSet);
            if (rowSet.next()) {
                if (firewallCount > 0)
                    highRisk = "Y";
            }

            log.debug("High Risk Flag for MAD Approval  is " + highRisk);
            if (highRisk.equals("N")) {

                String processActModeSQL = " select process_activity_mode from c3par.ti_process where id=?";

                rowSet = jdbcTemplate.queryForRowSet(processActModeSQL, new Object[] { procId });
                log.debug("Row Set " + rowSet);
                if (rowSet.next()) {
                    String processMode = rowSet.getString(1);
                    if (ActivityDataDTO.IS_RECONSILE.equalsIgnoreCase(processMode))
                        highRisk = "Y";
                }
            }

            // For Connection get ACL,BroadAccess ,HighRisk,seReviewFlag-- Acl
            // and SeReview Flag are specific to Connection
            if (TIProcess.CONNECTION.equalsIgnoreCase(processType)) {
                String aclSQL = "select count(1) from acl_variance where ti_request_id = ? having count(1) > 0";

                rowSet = jdbcTemplate.queryForRowSet(aclSQL, new Object[] { tiRequestId });
                log.debug("Row Set " + rowSet);
                while (rowSet.next()) {
                    aclVariance = "Y";
                }

                if (aclVariance != null) {
                    if (aclVariance.equalsIgnoreCase("Y"))
                        flagsMap.put(TIProcess.ACL_FLAG, Boolean.TRUE);
                }

                // Allow/Deny Flag

                flagsMap.put(TIProcess.DENY_FLAG, isDenied(tiRequestId));

                // BroadAccess

                broadAccess = getBroadAccessFlag(tiRequestId);

                // highRisk
                if (highRisk.equals("N")) {

                    String fwRuleDocSQL = "select con.bulk_request from con_req con,ti_request_planning_xref xref"
                            + " where con.id=xref.planning_id and xref.ti_request_id = ?";
                    // " select id from c3par.ti_doc_meta_data where doc_type='Firewall Rules' and connection_id=?";

                    rowSet = jdbcTemplate.queryForRowSet(fwRuleDocSQL.toString(), new Object[] { tiRequestId });
                    log.debug("Row Set " + rowSet);
                    while (rowSet.next()) {
                        if (rowSet.getString(1) != null)
                            highRisk = rowSet.getString(1);
                        break;
                    }
                }

                if (highRisk.equals("N")) {
                    StringBuilder riskConSQL = new StringBuilder(
                            "select q.id from con_fw_rule_questionnaire q, con_fw_rule r ");
                    riskConSQL
                            .append(" where q.updated_ti_request_id=r.updated_ti_request_id and q.deleted_ti_request_id is null and r.deleted_ti_request_id is null");
                    riskConSQL
                            .append(" and q.fw_rule_id is not null and q.fw_rule_id = r.id and r.updated_ti_request_id=? ");
                    riskConSQL
                            .append(" and (q.status='Incomplete' or q.status='Completed' or q.status='Reviewed' or q.status='RiskCheckBypassed')");
                    riskConSQL.append(" union");
                    riskConSQL.append(" select q.id from ti_req_questionnaire q, ti_request t");
                    riskConSQL.append(" where q.ti_request_id=t.id and q.deleted_ti_request_id is null and t.id=? ");
                    riskConSQL
                            .append(" and (q.status='Incomplete' or q.status='Completed' or q.status='Reviewed' or q.status='RiskCheckBypassed')");

                    rowSet = jdbcTemplate.queryForRowSet(riskConSQL.toString(),
                            new Object[] { tiRequestId, tiRequestId });
                    log.debug("Row Set " + rowSet);
                    while (rowSet.next()) {
                        highRisk = "Y";
                        break;
                    }
                }

                // High Risk for Appsence in case Firewallchanges did not fit
                // risk logic
                if (highRisk.equals("N")) {
                    // StringBuilder appRiskSQL=new
                    // StringBuilder(" select distinct ti_request_id from c3par.APS_APPSENSE_POLICY where ti_request_id=? and aps_port_master_id is not null ");
                    StringBuilder appRiskSQL = new StringBuilder(
                            " select ti_request_id from c3par.aps_impl_history where comb_type_id=1 and CROSS_ENV_ACCESS='Y' and faf_type in(1,2,3) and ti_request_id=? ");
                    // Added for Defect 10036 - High Risk Port Parameter no
                    // displaying
                    appRiskSQL
                            .append(" union select ti_request_id from c3par.aps_impl_history where comb_type_id=1 and aps_port_master_id is not null and faf_type in(1,2,3) and ti_request_id=? ");

                    rowSet = jdbcTemplate.queryForRowSet(appRiskSQL.toString(),
                            new Object[] { tiRequestId, tiRequestId });
                    log.debug("Row Set " + rowSet);
                    while (rowSet.next()) {
                        highRisk = "Y";
                        break;
                    }

                }
                // //High Risk for Proxy in case Firewallchanges,Appsence did
                // not fit risk logic
                if (highRisk.equals("N")) {

                    StringBuilder prxRiskSQL = new StringBuilder();
                    prxRiskSQL.append("SELECT pph.TI_REQUEST_ID ");
                    prxRiskSQL.append("FROM c3par.prx_paf_history pph,");
                    prxRiskSQL.append("c3par.prx_instance_master pim,");
                    prxRiskSQL.append("con_req con,");
                    prxRiskSQL.append("ti_request tr,");
                    prxRiskSQL.append("relationship rel,");
                    prxRiskSQL.append("REL_CITI_HIERARCHY_XREF relxref, ");
                    prxRiskSQL.append("citi_hierarchy_master cm, ");
                    prxRiskSQL.append("business_unit bu, ");
                    prxRiskSQL.append("ti_request_planning_xref trpx ");
                    prxRiskSQL.append("WHERE pph.COMB_TYPE_ID   =1 ");
                    prxRiskSQL.append("AND pph.PROXY_INST_MST_ID=pim.ID ");
                    prxRiskSQL.append("AND con.id               = trpx.planning_id ");
                    prxRiskSQL.append("AND trpx.ti_request_id   = tr.id ");
                    prxRiskSQL.append("AND con.RELATIONSHIP_ID  = rel.id ");
                    prxRiskSQL.append("and relxref.RELATIONSHIP_ID = rel.id ");
                    prxRiskSQL.append("and relxref.CITI_HIERARCHY_MASTER_ID = cm.id ");
                    prxRiskSQL.append("and cm.BU_ID = bu.ID ");
                    prxRiskSQL.append("AND tr.id                = pph.TI_REQUEST_ID  ");
                    prxRiskSQL.append("AND (pim.RECORD_TYPE IN ('SOCKS','PLUG') ");
                    prxRiskSQL
                            .append("OR (pim.internet_access='Y' AND upper(bu.business_name)=upper('MA'||'&'||'D'))) AND pph.TI_REQUEST_ID=? ");

                    rowSet = jdbcTemplate.queryForRowSet(prxRiskSQL.toString(), new Object[] { tiRequestId });
                    log.debug("tiRequestId : "+tiRequestId+" Row Set " + rowSet);
                    while (rowSet.next()) {
                        highRisk = "Y";
                        break;
                    }
                    log.debug("The proxy high risk flag for this ti_request id is"+ highRisk);
                }
                // Firewall Region
                StringBuilder fwSQL = new StringBuilder(
                        " select b.id,b.mgt_region,c.se_reviewflag,a.FW_TYPE from c3par.con_fw_policy_master a ,c3par.con_fw_mgmt_region b,c3par.con_fw_location c where ");
                fwSQL.append(" a.FW_MGMT_REGION_ID=b.id and  a.FW_LOCATION_ID=c.id(+) and a.id in ( select firewall_policy_id from c3par.con_fw_policy_xref where connection_request_id=? )");
                rowSet = jdbcTemplate.queryForRowSet(fwSQL.toString(), new Object[] { procId });
                log.debug("Row Set " + rowSet);
                while (rowSet.next()) {
                    fwRegId = rowSet.getString(1);
                    fwRegion = rowSet.getString(2);
                    seFlag = rowSet.getString(3);
                    fwType = rowSet.getString(4);
                    break;
                }
                // Added for SE Approval Remodel - Task 3927
                String supRole = getSupplementReviewRoles(tiRequestId);

                if (supRole != null && supRole.indexOf("ECM") != -1) {
                    flagsMap.put(TIProcess.SEC_ENGG_FLAG, Boolean.TRUE);
                }

                tpaFlag = getTPAFlagforIP(tiRequestId);
                if ("N".equals(tpaFlag)) {
                    log.info("TPAFlag is no and hence calling OFAC Details..");
                    ofacFlag = getOFACFlagforIP(tiRequestId);
                }

            }
            // Broad Access will be Done Later --TO DO
            if (TIProcess.IPREGISTRATION.equalsIgnoreCase(processType)) {
                if (highRisk.equals("N")) {
                    StringBuilder riskSQL = new StringBuilder(" select risk.id  from c3par.ip_registration ipreg, ");
                    riskSQL.append(" c3par.ip_reg_detail ipregdet,c3par.ipregdestinationports destport,c3par.riskport_ostia risk ");
                    riskSQL.append(" where ipreg.PROCESS_ID = ?  and  ipreg.id=ipregdet.IP_REGISTRATION_ID and ");
                    riskSQL.append(" ipregdet.ID=destport.IP_REGDETAIL_ID and destport.ID=risk.IP_REG_DESTINATION_PORTS_ID ");
                    rowSet = jdbcTemplate.queryForRowSet(riskSQL.toString(), new Object[] { procId });
                    log.debug("Row Set " + rowSet);
                    while (rowSet.next()) {
                        highRisk = "Y";
                        break;
                    }
                }

            }

            // Update HighRIsk and Acl flag in Tiprocess table
            String updateProcSQL = " update c3par.ti_process set is_high_risk=?,is_broad_access=? where id=? ";
            int rowUpdated = jdbcTemplate.update(updateProcSQL.toString(), new Object[] { highRisk, broadAccess, procId });
            log.debug("Rows updated: " + rowUpdated);

            // update con_rq table with acl and fwmgt id
            String updateConnSQL = " update c3par.con_Req  set is_acl_variance=?,fw_type=?,fw_mgmt_region_id=? where id=?";
            rowUpdated = jdbcTemplate.update(updateConnSQL.toString(), new Object[] { aclVariance, fwType, fwRegId, procId });
            log.debug("Rows updated: " + rowUpdated);
            // setting common flags for IPregistration and Connection

            if (broadAccess != null && broadAccess.equalsIgnoreCase("Y"))
                flagsMap.put(TIProcess.BROAD_ACCESS_FLAG, Boolean.TRUE);
            if (highRisk != null && highRisk.equalsIgnoreCase("Y"))
                flagsMap.put(TIProcess.HIGH_RISK_FLAG, Boolean.TRUE);
            if (tpaFlag != null && tpaFlag.equalsIgnoreCase("Y"))
                flagsMap.put(TIProcess.TPA_FLAG, Boolean.TRUE);
            if ("Y".equals(ofacFlag)) {
                flagsMap.put(TIProcess.OFAC_FLAG, Boolean.TRUE);
            }
            // updateRiskFlags(broadAccess,highRisk,tpaFlag,tiRequestId,getImplementationControlFlags(tiRequestId));
            log.debug(" Flags Set for " + processType + " Process Id " + procId + " are : " + flagsMap);
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }

        return flagsMap;
    }
  
    /**
     * @param tiRequestId
     * @param con
     * @return
     * @throws SQLException
     */

    private boolean isDenied(long tiRequestId) throws SQLException {
        boolean isDenied = Boolean.FALSE;
        String confwruleSQL = "select count(ID) from con_fw_rule where RULE_TYPE ='D' and TI_REQUEST_ID=? having count(ID) > 0";
        SqlRowSet rowSet = jdbcTemplate.queryForRowSet(confwruleSQL, new Object[] { tiRequestId });
        while (rowSet.next()) {
            isDenied = Boolean.TRUE;
        }
        log.info("tiRequestId::" + tiRequestId + "::isDeniedFlag=" + isDenied);
        return isDenied;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * getImplementationControlFlags(long)
     */

    public Map getImplementationControlFlags(long tiRequestId) throws Exception {
        log.debug("Entering getImplementationControlFlags for tiRequestId " + tiRequestId);

        boolean isAppsense = false;
        boolean isProxy = false;
        boolean isFWImplementation = false;
        boolean isACL = false;
        boolean isTPA = false;
        boolean isFireflow = false;
        boolean isFireflowNotify = false;
        boolean isECM = false;
        boolean isIPReg = false;

        Map flagsMap = new HashMap();
        StringBuilder errMsg = new StringBuilder();
        if (tiRequestId <= 0) {
            errMsg.append("Provide TIRequest ID " + tiRequestId);
        }

        chkBusException(errMsg);

        try {
            Map processMap = tiProcessSQL.getProcessForTIRequest(tiRequestId);
            String processType = (String) processMap.get("PROCESSTYPE");
            if (TIProcessDTO.IPREGISTRATION.equalsIgnoreCase(processType))
                isFWImplementation = true;
            else {
                StringBuilder bulkUploadSQL = new StringBuilder(
                        " select a.id  from c3par.con_req a,c3par.planning b,c3par.ti_request_planning_xref ");
                bulkUploadSQL
                        .append(" trpx where a.id=b.id and a.ID=trpx.PLANNING_ID and trpx.TI_REQUEST_ID=? and a.BULK_REQUEST='Y' ");
                SqlRowSet rowSet = jdbcTemplate.queryForRowSet(bulkUploadSQL.toString(), new Object[] { tiRequestId });
                log.debug("Row set : rowSet : "+rowSet);
                while (rowSet.next()) {
                    isFWImplementation = true;
                    break;
                }
                if (!isFWImplementation) {
                    StringBuilder fwImpSQL = new StringBuilder(
                            "select * from faf_fireflow_ticket where ti_request_id=? and (ip_reg is null or ip_reg <> 'Y') and upper(ltrim(rtrim(status))) not in(upper('rejected'),'DELETED')");
                    SqlRowSet rowSet1 = jdbcTemplate.queryForRowSet(fwImpSQL.toString(), new Object[] { tiRequestId });
                    log.debug("Row set : rowSet1 : "+rowSet1);
                    while (rowSet1.next()) {
                        isFWImplementation = true;
                        log.debug("ManaeTIProcessImple.isFWImplementation.Inside loop.isFWImplementation::"
                                + isFWImplementation);
                        break;
                    }
                }
                StringBuilder appsenseSQL = new StringBuilder(
                        " select  distinct(ti_request_id) from c3par.aps_impl_history where comb_type_id!=0 and  ti_request_id=? ");
                try {
                    SqlRowSet appRS = jdbcTemplate.queryForRowSet(appsenseSQL.toString(), new Object[] { tiRequestId });
                    log.debug("Row set : appRS : "+appRS);
                    while (appRS.next()) {
                        isAppsense = true;
                        log.debug("ManaeTIProcessImple.isAppsense.Inside loop.isAppsense::" + isAppsense);
                    }
                } catch (Exception appException) {
                    log.error(appException.toString(), appException);
                }

                try {
                    StringBuilder proxySQL = new StringBuilder(
                            " select  distinct(ti_request_id) from c3par.prx_paf_history where comb_type_id!=0 and  ti_request_id=?");
                    SqlRowSet prxRS = jdbcTemplate.queryForRowSet(proxySQL.toString(), new Object[] { tiRequestId });
                    log.debug("Row set : prxRS : "+prxRS);
                    while (prxRS.next()) {
                        isProxy = true;
                        log.debug("ManaeTIProcessImple.prxRS.Inside loop.isProxy::" + isProxy);
                        break;
                    }
                } catch (Exception appException) {
                    log.error(appException.toString(), appException);
                }
                StringBuilder aclSQL = new StringBuilder(
                        " select count(1) from acl_variance where ti_request_id = ? having count(1) > 0 ");
                try {
                    SqlRowSet aclRS = jdbcTemplate.queryForRowSet(aclSQL.toString(), new Object[] { tiRequestId });
                    log.debug("Row set : aclRS : "+aclRS);
                    while (aclRS.next()) {
                        isACL = true;
                        log.debug("ManaeTIProcessImple.isACL.Inside loop.isACL::" + isACL);
                    }
                } catch (Exception aclException) {
                    log.error(aclException.toString(), aclException);
                }

                StringBuilder ecmSQL = new StringBuilder(
                        " select count(1) from ti_request,security_role,c3par_user_role_xref where ti_request.user_id=c3par_user_role_xref.user_id "
                                + "and security_role.id= c3par_user_role_xref.role_id and ti_request.id=? and display_name='ECM' having COUNT(1)>0 "
                                + "union "
                                + "select count(1) from ti_activity_trail tat, c3par_user_role_xref curx,security_role sr "
                                + "where tat.id in(select max(taat.id) from ti_activity_trail taat,ti_task_type tttt where taat.ti_request_id=? and "
                                + "tttt.task in('Business Justification','Technical Architecture') and taat.activity_id = tttt.id group by taat.id) and "
                                + "curx.role_id= sr.id  and curx.user_id= tat.user_id and tat.ti_request_id=? and sr.display_name='ECM' having COUNT(1)>0");
                try {
                    SqlRowSet ecmRS = jdbcTemplate.queryForRowSet(ecmSQL.toString(), new Object[] { tiRequestId, tiRequestId, tiRequestId });
                    log.debug("Row set : ecmRS : "+ecmRS);
                    while (ecmRS.next()) {
                        isECM = true;
                        break;
                    }

                } catch (Exception ecmException) {
                    log.error(ecmException.toString(), ecmException);
                }

                StringBuilder tpaSQL = new StringBuilder(
                        " select count(1) from c3par.TI_REQUEST_RISK_FLAGS where ti_request_id = ? and is_tpa='Y' having count(1) > 0");
                try {
                    SqlRowSet tPRiskRS = jdbcTemplate.queryForRowSet(tpaSQL.toString(), new Object[] { tiRequestId });
                    log.debug("Row set : tPRiskRS : "+tPRiskRS);
                    while (tPRiskRS.next()) {
                        isTPA = true;
                    }
                } catch (Exception exception) {
                    log.error(exception.toString(), exception);
                }

                StringBuilder fireFlowSQL = new StringBuilder(
                        "SELECT VALUE2 FROM GENERIC_LOOKUP WHERE VALUE1='FIRE_FLOW_INTERFACE'");
                try {
                    SqlRowSet fireFlowRS = jdbcTemplate.queryForRowSet(fireFlowSQL.toString());
                    log.debug("Row set : fireFlowRS : "+fireFlowRS);
                    while (fireFlowRS.next()) {
                        String fireFlowFlag = (String) fireFlowRS.getString(1);
                        if (fireFlowFlag.equalsIgnoreCase("Y"))
                            isFireflow = true;
                    }
                } catch (Exception ffException) {
                    log.error(ffException.toString(), ffException);
                }

                StringBuilder fireFlowNotifySQL = new StringBuilder(
                        "SELECT VALUE2 FROM GENERIC_LOOKUP WHERE VALUE1='FIREFLOW_NOTIFICATION'");
                try {
                    SqlRowSet fireFlowNotifyRS = jdbcTemplate.queryForRowSet(fireFlowNotifySQL.toString());
                    log.debug("Row set : fireFlowNotifyRS : "+fireFlowNotifyRS);
                    while (fireFlowNotifyRS.next()) {
                        String fireFlowNotifyFlag = (String) fireFlowNotifyRS.getString(1);
                        if (fireFlowNotifyFlag.equalsIgnoreCase("Y"))
                            isFireflowNotify = true;
                    }
                } catch (Exception ffNotifyException) {
                    log.error(ffNotifyException.toString(), ffNotifyException);
                }

                StringBuilder isIPRegSQL = new StringBuilder(
                        "select ti_request_id from faf_fireflow_ticket where ti_request_id=? and ip_reg = 'Y' and upper(ltrim(rtrim(status))) not in(upper('rejected'),'DELETED')");
                try {
                    SqlRowSet isIPRegRS = jdbcTemplate.queryForRowSet(isIPRegSQL.toString(), new Object[] { tiRequestId });
                    log.debug("Row set : isIPRegRS : "+isIPRegRS);
                    while (isIPRegRS.next()) {
                        isIPReg = true;
                    }
                } catch (Exception exception) {
                    log.error(exception.toString(), exception);
                }
            }
            flagsMap.put(TIProcessDTO.APPSENSE_REQD_FLAG, Boolean.valueOf(isAppsense));
            flagsMap.put(TIProcessDTO.PROXY_REQD_FLAG, Boolean.valueOf(isProxy));
            flagsMap.put(TIProcessDTO.FW_IMPLEMENTATION_REQD_FLAG, Boolean.valueOf(isFWImplementation));
            flagsMap.put(TIProcessDTO.GNCC_REQD_FLAG, Boolean.valueOf(isACL));
            flagsMap.put(TIProcessDTO.TPA_RISK_FLAG, Boolean.valueOf(isTPA));
            flagsMap.put(TIProcessDTO.FIREFLOW_CONTROL_FLAG, Boolean.valueOf(isFireflow));
            flagsMap.put(TIProcessDTO.FIREFLOW_NOTIFY_FLAG, Boolean.valueOf(isFireflowNotify));
            flagsMap.put(TIProcessDTO.ECM_FLAG, Boolean.valueOf(isECM));
            flagsMap.put(TIProcessDTO.IPREG_FLAG, Boolean.valueOf(isIPReg));

            log.debug("IPReg flag" + isIPReg + "Appsense Req Flag : " + isAppsense + " Proxy Req Flag : " + isProxy
                    + " FWImplementationFlag : " + isFWImplementation + " ACL Req Flag : " + isACL + "TPA Risk Flag:: "
                    + isTPA + "Fireflow Flag:: " + isFireflow + "Fireflow Notify Flag:: " + isFireflowNotify
                    + "for TIRequestId :" + tiRequestId);
            updateRiskFlags(getApprovalControlFlags(tiRequestId), isFWImplementation, isProxy, isAppsense, isACL,
                    isECM, isIPReg, tiRequestId);
        } catch (Exception e) {
            log.error(e, e);
            throw e;
        }
        log.debug("Exiting getImplementationControlFlags for tiRequestId " + tiRequestId);
        return flagsMap;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * isDataEntryComplete(long)
     */

    public boolean isDataEntryComplete(long tiRequestId) throws Exception {
        if (tiRequestId <= 0) {
            log.error(" TIRequest ID " + tiRequestId + " is invalid .Provide a valid Request ID ");
            throw new Exception("Business Exception : TIRequest ID " + tiRequestId
                    + " is invalid .Provide a valid Request ID ");
        }

        String relStatus = null;
        String procType = null;
        String relationshipID = null;

        boolean ostiaComplete = false;
        StringBuilder errMsg = new StringBuilder();
        long procID = -1;
        try {
            StringBuilder relSQL = new StringBuilder(
                    " select ti_process.id,status,ti_process_type.PROCESS_TYPE,relationship.id  from c3par.relationship ,c3par.ti_request,c3par.ti_process,c3par.ti_process_type ");
            relSQL.append(" where ti_request.PROCESS_ID = ti_process.id and ti_process.RELATIONSHIP_ID=relationship.id and ti_process.PROCESS_TYPE_ID=ti_process_type.id and ti_request.id=?");

            SqlRowSet rowSet = jdbcTemplate.queryForRowSet(relSQL.toString(), new Object[] { tiRequestId });
            while (rowSet.next()) {
                procID = rowSet.getLong(1);
                relStatus = rowSet.getString(2);
                procType = rowSet.getString(3);
                relationshipID = rowSet.getString(4);
            }
            if (procID <= 0) {
                log.error(" Invalid Process Id " + procID + " for TIRequestId " + tiRequestId);
                throw new ApplicationException(" Invalid Process Id " + procID + " for TIRequestId " + tiRequestId);
            }
            if (procType == null) {
                log.error(" No Process is Defined for  Process Id " + procID + " and TIRequestId " + tiRequestId);
                throw new ApplicationException(" No Process is Defined for  Process Id " + procID + " and TIRequestId "
                        + tiRequestId);
            }

            if (TIProcess.IPREGISTRATION.equalsIgnoreCase(procType))
                ostiaComplete = isIPOstiaTabComplete(Long.valueOf(procID));
            else
                ostiaComplete = isOstiaCompleted(tiRequestId);

        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }

        if ((relStatus != null && relStatus.equalsIgnoreCase("CERTIFIED")) && ostiaComplete)
            return true;
        else
            return false;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * getCheckCompletionFlags(long)
     */

    public Map getCheckCompletionFlags(long tiRequestId) throws Exception {
        if (tiRequestId <= 0) {
            log.error(" TIRequest ID " + tiRequestId + " is invalid .Provide a valid Request ID ");
            throw new Exception("Business Exception : TIRequest ID " + tiRequestId
                    + " is invalid .Provide a valid Request ID ");
        }

        String relStatus = null;
        String procType = null;
        String relationshipID = null;

        boolean ostiaComplete = false;
        boolean relationshipComplete = false;
        long procID = -1;
        Map completionFlags = new HashMap();
        try {
            StringBuilder relSQL = new StringBuilder(
                    " select ti_process.id,status,ti_process_type.PROCESS_TYPE,relationship.id  from c3par.relationship ,c3par.ti_request,c3par.ti_process,c3par.ti_process_type ");
            relSQL.append(" where ti_request.PROCESS_ID = ti_process.id and ti_process.RELATIONSHIP_ID=relationship.id and ti_process.PROCESS_TYPE_ID=ti_process_type.id and ti_request.id=?");

            SqlRowSet rowSet = jdbcTemplate.queryForRowSet(relSQL.toString(), new Object[] { tiRequestId });
            while (rowSet.next()) {
                procID = rowSet.getLong(1);
                relStatus = rowSet.getString(2);
                procType = rowSet.getString(3);
                relationshipID = rowSet.getString(4);
            }
            if (procID <= 0) {
                log.error(" Invalid Process Id " + procID + " for TIRequestId " + tiRequestId);
                throw new ApplicationException(" Invalid Process Id " + procID + " for TIRequestId " + tiRequestId);
            }
            if (procType == null) {
                log.error(" No Process is Defined for  Process Id " + procID + " and TIRequestId " + tiRequestId);
                throw new ApplicationException(" No Process is Defined for  Process Id " + procID + " and TIRequestId "
                        + tiRequestId);
            }
            if (TIProcess.IPREGISTRATION.equalsIgnoreCase(procType))
                ostiaComplete = isIPOstiaTabComplete(Long.valueOf(procID));
            else {
                ostiaComplete = isOstiaCompleted(tiRequestId);
            }
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }
        // TODO Auto-generated method stub
        if ((relStatus != null && relStatus.equalsIgnoreCase("CERTIFIED")))
            relationshipComplete = true;
        completionFlags.put(TIProcessDTO.OSTIA_COMPLETE_FLAG, Boolean.valueOf(ostiaComplete));
        completionFlags.put(TIProcessDTO.RELATIONSHIP_COMPLETE_FLAG, Boolean.valueOf(relationshipComplete));
        log.info("TiRequestId::" + tiRequestId + "::completionFlags" + completionFlags);

        return completionFlags;
    }

    /**
     * Checks if is ostia questions tab complete.
     * 
     * @param con_req_id
     *            the con_req_id
     * @return true, if is ostia questions tab complete
     * @throws Exception
     *             the exception
     */

    public boolean isOstiaQuestionsTabComplete(Long con_req_id) throws Exception {
        log.debug("CHECKING IF OSTIA TAB IS COMPLETE FOR CON_REQ " + con_req_id);

        String sql = "SELECT 1 FROM con_ip_pair_xref a, con_port_xref b, con_riskport_ostia c, con_ostia_group d WHERE a.id = b.ip_pair_xref_id AND b.port_id = c.port_id AND a.connection_request_id = ? AND d.id(+) = c.GROUP_ID AND (d.status IS NULL OR d.status ='Incomplete')";
        boolean rtrn = false;
        try {
            SqlRowSet rowSet = jdbcTemplate.queryForRowSet(sql, new Object[] { con_req_id.toString() });
            if (rowSet.next()) {
                return rtrn;
            }
            rtrn = true;
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }

        return rtrn;
    }

    /**
     * Checks if is iP ostia tab complete.
     * 
     * @param ipProcessID
     *            the ip process id
     * @return true, if is iP ostia tab complete
     */

    public boolean isIPOstiaTabComplete(Long ipProcessID) {
        boolean isOstiaTabComplete = false;
        try {
            if (!chkIsZero(ipProcessID)) {
                StringBuilder sql = new StringBuilder(
                        "select 1 from ( select count(*) tot from ip_reg_detail,ip_registration,IPREGDESTINATIONPORTS irp,riskport_ostia ro where ip_registration_id=ip_registration.ID ");
                sql.append(" and irp.IP_REGDETAIL_ID=ip_reg_detail.ID and ro.IP_REG_DESTINATION_PORTS_ID=irp.ID and ip_registration.PROCESS_ID="
                        + ipProcessID);
                sql.append(" ) where tot= ");
                sql.append(" (select count(ro.status) from ip_reg_detail,ip_registration,IPREGDESTINATIONPORTS irp,riskport_ostia ro where ip_registration_id=ip_registration.ID and irp.IP_REGDETAIL_ID=ip_reg_detail.ID and ro.IP_REG_DESTINATION_PORTS_ID=irp.ID and ip_registration.PROCESS_ID=");
                sql.append(ipProcessID);
                sql.append(" and ro.STATUS='COMPLETE') ");
                Long count = runQueryReturnID(sql.toString());
                if (count != null) {
                    if (count.longValue() <= 0)
                        isOstiaTabComplete = false;
                    else {
                        isOstiaTabComplete = true;
                    }
                }
            }
        } catch (Exception e) {
            log.error(e.toString(), e);
        }
        log.info("ProcessId::" + ipProcessID + "::isOstiaTabComplete" + isOstiaTabComplete);
        return isOstiaTabComplete;
    }

    /**
     * Run query return id.
     * 
     * @param sql
     *            the sql
     * @return the long
     * @throws Exception
     *             the exception
     */

    public Long runQueryReturnID(String sql) throws Exception {
        Long id = null;
        try {
            SqlRowSet rowSet = jdbcTemplate.queryForRowSet(sql);
            while (rowSet.next()) {
                id = Long.valueOf(rowSet.getLong(1));
            }
        } catch (Exception e) {
            log.error(e.toString(), e);
        }
        return id;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * updateProcessStatus(long, long)
     */

    public long updateProcessStatus(long tiRequestId, long activityID) throws Exception {
        int rowsUpdated = 0;
        try {
            StringBuilder processUpdateSql = new StringBuilder();
            processUpdateSql
                    .append(" update ti_process  SET process_status_id= ?  where id =(select process_id from ti_request where id=?) ");
            processUpdateSql.append("  ");

            log.debug(" Run with values tiRequestID = " + tiRequestId + " activityID = " + activityID);
            rowsUpdated = jdbcTemplate.update(processUpdateSql.toString(), new Object[] { activityID, tiRequestId });
           
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }
        return rowsUpdated;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * updateScheduleDate(long, java.lang.String, java.util.Date)
     */

    public void updateScheduleDate(long tiRequestId, String activityCode, Date scheduleDate) throws Exception {
        if (tiRequestId <= 0)
            throw new Exception(" Argument TiRequestId  " + tiRequestId + " passed is invalid ");

        long scheduleTime = 0;
        if (scheduleDate == null)
            throw new Exception(" Argument scheduleDate  " + scheduleDate + " passed is null ");
        scheduleTime = scheduleDate.getTime();
        if (scheduleTime <= 0)
            throw new Exception(" Argument scheduleDate  " + scheduleDate + " passed is invalid ");

        try {
            String updateScheduleSQL = null;
            updateScheduleSQL = "update c3par.ti_request set tpwapp_review_date=? where id=?";
            if (ActivityDataDTO.ACTIVITY_OPE_IMP.equalsIgnoreCase(ActivityDataDTO.ACTIVITY_OPE_IMP))
                updateScheduleSQL = "update c3par.ti_request set tpwapp_review_date=? where id=?";
            log.debug(" Run with values tiRequestID = " + tiRequestId + " scheduleDate = " + scheduleDate);
            int rowsUpdated = jdbcTemplate.update(updateScheduleSQL, new Object[] {
                    new java.sql.Timestamp(scheduleTime), tiRequestId });
            
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }
    }
    /*
      * (non-Javadoc)
      * 
      * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
      * updateProcess(com.citigroup.cgti.c3par.domain.TIProcess)
      */

    public long updateProcess(TIProcess tiProcess) throws Exception {

        // if(isActive){
        Connection con = null;
        PreparedStatement ps = null;
        try {

            updateTIProcess(tiProcess, TIProcessService.TIReqType_Maintain);

            if (TIProcess.CONNECTION.equalsIgnoreCase(tiProcess.getBusinessCase().getProcessType().getName())) {
                // get connectionId for the given connection Request
                Long connID = tiProcessSQL.getConnectionID(tiProcess.getId());
                if (connID == null)
                    throw new Exception(" Connection ID is null for and Active Connection Request ID "
                            + tiProcess.getId());

                // insert into Maintenance and Planning tables
                MaintenanceEntity maint = new MaintenanceEntity();
                maint.setConnectionId(connID);
                maint.setUpdateType("circuit");
                maint.setStatus(BUSINESS_JUSTIFICATION);

                /*
                 * ConnectionEntity connection =
                 * ConnectionDAO.createInstance(c3parSession
                 * ).get(maint.getConnectionId()); PlanningEntity planning =
                 * transfromConnection2Planning(connection, c3parSession);
                 */
                ConnectionExtEntity connection = ConnectionExtDAO.createInstance(c3parSession).get(
                        (maint.getConnectionId()));
                PlanningEntity planning = transfromConnection2Planning(connection, c3parSession);

                planning.setConnForCustORClient(connection.getConnForCustORClient());
                planning.setCabApprGrpCode(connection.getCabApprGrpCode());
                planning.setDirectAccessByThirdPrt(connection.getDirectAccessByThirdPrt());
                planning.setReasonForVirtuConn(connection.getReasonForVirtuConn());
                planning.setSemiAnnualEntitlReview(connection.getSemiAnnualEntitlReview());
                planning.setTpTrainingAwarnessPrg(connection.getTpTrainingAwarnessPrg());
                planning.setExportLicenseCordinatorNew(connection.getExportLicenseCordinatorNew());
                planning.setConnEstimate(connection.getConnEstimate());
                planning.setDetInformation(connection.getDetInformation());
                /*
                 * While copying details form connection table to con_req,dont
                 * copy the rational field value because if will be differ for
                 * each cycle
                 */
                planning.setRationale(null);

                /*
                 * //Added two new fields - SOW, CMPID - for Task 9329
                 */

                planning.setPlannedActivateDate(tiProcess.getTiRequest().getPlannedCompletionDate());
                planning.setRequesterId(tiProcess.getRequestor().getSoeID());
                savePlanningEntity(planning, c3parSession);
                maint.setPlanning(planning);
                MaintenanceDAO.createInstance(c3parSession).update(maint);
                log.info(" Created Connections Maintenance Id " + maint.getId() + ", planning id " + planning.getId()
                        + " for TIProcess Id " + tiProcess.getId());
                if (maint.getId() == null)
                    throw new Exception(" Could not successfully Create Maintenance Id for TIProcess ID "
                            + tiProcess.getId());
                if (planning.getId() == null)
                    throw new Exception(" Could not successfully Create Planning Id for TIProcess ID "
                            + tiProcess.getId());

                // insert into ti_request_planning_xref

                String instSQL = "insert into c3par.ti_request_planning_xref  values (?,?)";
                con = c3parSession.getConnection();
                ps = con.prepareStatement(instSQL);
                ps.setLong(1, tiProcess.getTiRequest().getId().longValue());
                ps.setLong(2, planning.getId().longValue());

                log.debug(" with  values TIRequestID = " + tiProcess.getTiRequest().getId().longValue()
                        + " and Planning =" + planning.getId());
                ps.executeUpdate();
                long tiReqId = tiProcess.getTiRequest().getId().longValue();
                updateDataInfoBulkRequest(tiReqId);
                copyTechArchData(tiProcess.getId().longValue(), tiProcess.getTiRequest().getId().longValue(),
                        TIProcessService.TIReqType_Maintain);
                log.debug("Before copying Uploaded Documents");
                copyUploadedDocuments(tiProcess.getId().longValue(), tiProcess.getTiRequest().getId().longValue());
                log.debug("After copying Uploaded Documents");
            }
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw new EJBException(e.getMessage());
        } finally {
            c3parSession.closeStatement(ps);
            c3parSession.releaseConnection();
        }

        return tiProcess.getTiRequest().getId().longValue();

    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#updateProcess
     * (com.citigroup.cgti.c3par.bpm.ejb.domain.TIProcessDTO)
     */

    public long updateProcess(TIProcessDTO processDTO) throws Exception {

        log.debug("ManageTIProcessImpl.updateProcess().started");
        Connection con = null;
        PreparedStatement ps = null;
        TIProcess tiProcess = new TIProcess();
        if (processDTO == null) {
            throw new Exception("Business Exception :  ProcessDTO is null");
        }
        tiProcess.setId(processDTO.getId());
        tiProcess.getRequestor().setSoeID(processDTO.getRequestorSOEId());
        try {
            updateTIProcess(tiProcess, TIProcessService.TIReqType_Maintain);
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw new Exception(e.getMessage());
        }
        try {
            if (TIProcess.CONNECTION.equalsIgnoreCase(tiProcess.getBusinessCase().getProcessType().getName())) {
                // get connectionId for the given connection Request
                Long connID = tiProcessSQL.getConnectionID(tiProcess.getId());
                if (connID == null)
                    throw new Exception(" Connection ID is null for and Active Connection Request ID "
                            + tiProcess.getId());

                // insert into Maintenance and Planning tables
                MaintenanceEntity maint = new MaintenanceEntity();
                maint.setConnectionId(connID);
                maint.setUpdateType("circuit");
                maint.setStatus(BUSINESS_JUSTIFICATION);

                /*
                 * ConnectionEntity connection =
                 * ConnectionDAO.createInstance(c3parSession
                 * ).get(maint.getConnectionId());
                 */
                ConnectionExtEntity connection = ConnectionExtDAO.createInstance(c3parSession).get(
                        (maint.getConnectionId()));
                PlanningEntity planning = transfromConnection2Planning(connection, c3parSession);

                planning.setConnForCustORClient(connection.getConnForCustORClient());
                planning.setCabApprGrpCode(connection.getCabApprGrpCode());
                planning.setDirectAccessByThirdPrt(connection.getDirectAccessByThirdPrt());
                planning.setReasonForVirtuConn(connection.getReasonForVirtuConn());
                planning.setSemiAnnualEntitlReview(connection.getSemiAnnualEntitlReview());
                planning.setTpTrainingAwarnessPrg(connection.getTpTrainingAwarnessPrg());
                planning.setExportLicenseCordinatorNew(connection.getExportLicenseCordinatorNew());
                planning.setConnEstimate(connection.getConnEstimate());
                planning.setDetInformation(connection.getDetInformation());

                /*
                 * //Added two new fields - SOW, CMPID - for Task 9329
                 * ConnectionExtDAO connectionExtDAO = new ConnectionExtDAO(new
                 * C3parSession()); ConnectionExtEntity connectionExtEntity=
                 * connectionExtDAO
                 * .getConnectionExtEntity(maint.getConnectionId());
                 * planning.setSOW(connectionExtEntity.getSOW());
                 * planning.setCmpId(connectionExtEntity.getCmpId());
                 */

                planning.setPlannedActivateDate(tiProcess.getTiRequest().getPlannedCompletionDate());
                planning.setRequesterId(tiProcess.getRequestor().getSoeID());
                // ///////////////////////////
                /*
                 * While copying details form connection table to con_req,dont
                 * copy the rational field value because if will be differ for
                 * each cycle
                 */
                planning.setRationale(null);
                // ///////////////////
                savePlanningEntity(planning, c3parSession);
                maint.setPlanning(planning);
                MaintenanceDAO.createInstance(c3parSession).update(maint);
                log.debug(" Created Connections Maintenance Id " + maint.getId() + ", planning id " + planning.getId()
                        + " for TIProcess Id " + tiProcess.getId());
                if (maint.getId() == null)
                    throw new Exception(" Could not successfully Create Maintenance Id for TIProcess ID "
                            + tiProcess.getId());
                if (planning.getId() == null)
                    throw new Exception(" Could not successfully Create Planning Id for TIProcess ID "
                            + tiProcess.getId());

                // insert into ti_request_planning_xref

                String instSQL = "insert into c3par.ti_request_planning_xref  values (?,?)";
                con = c3parSession.getConnection();
                ps = con.prepareStatement(instSQL);
                ps.setLong(1, tiProcess.getTiRequest().getId().longValue());
                ps.setLong(2, planning.getId().longValue());

                log.debug(" with  values TIRequestID = " + tiProcess.getTiRequest().getId().longValue()
                        + " and Planning =" + planning.getId());
                ps.executeUpdate();
                long tiReqId = tiProcess.getTiRequest().getId().longValue();
                updateDataInfoBulkRequest(tiReqId);
                copyTechArchData(tiProcess.getId().longValue(), tiProcess.getTiRequest().getId().longValue(),
                        TIProcessService.TIReqType_Maintain);
                // updateConFWRule(tiProcess.getId().longValue(),tiReqId);
                copyRFCData(tiProcess.getId().longValue(), tiProcess.getTiRequest().getId().longValue());
                // updateFAFFWRule(tiProcess.getId().longValue());
                log.debug("Before copying Uploaded Documents");
                copyUploadedDocuments(tiProcess.getId().longValue(), tiProcess.getTiRequest().getId().longValue());
                log.debug("After copying Uploaded Documents");

                // This code may clean up con_fw_rule and re-add all the rules,
                // delete if this is redundant
                boolean isaborted = isAborted(tiProcess.getId().longValue(), tiProcess.getTiRequest().getId()
                        .longValue(), 2);
                log.debug("In ManageTIProcessImpl: abortToActiveFWRuleCopy, PREVIOUS CYCLE isaborted => " + isaborted);
                if (isaborted) {
                    String result = abortToActiveFWRuleCopy(tiProcess.getId().longValue(), tiProcess.getTiRequest()
                            .getId().longValue());
                    log.debug("In ManageTIProcessImpl: abortToActiveFWRuleCopy is completed Result is:" + result);
                }

            }
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw new EJBException(e.getMessage());
        } finally {
            c3parSession.closeStatement(ps);
            c3parSession.releaseConnection();
        }

        log.debug("ManageTIProcessImpl.updateProcess().started");
        return tiProcess.getTiRequest().getId().longValue();

    }

    /**
     * @param tiProcessId
     * @param tiRequestId
     * @throws RemoteException
     */

    private void updateConFWRule(long tiProcessId, long tiRequestId) throws Exception {
        log.debug("Entering updateConFWRule for tiRequestId " + tiRequestId);
        try {
            String updateConFWRuleSQL = "update c3par.con_fw_rule set ti_request_id=? where ti_request_id in "
                    + "(select id from ti_request where process_id=?) ";
            int rowsUpdated = jdbcTemplate.update(updateConFWRuleSQL, new Object[] { tiRequestId, tiProcessId });
          

        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }
        log.debug("Exiting updateConFWRule for tiRequestId " + tiRequestId);

    }

    /**
     * @param tiProcessId
     * @throws RemoteException
     */

    private void updateFAFFWRule(long tiProcessId) throws Exception {
        log.debug("Entering updateFAFFWRule for process_id " + tiProcessId);
        try {
            String updateFAFFWRuleSQL = "update c3par.faf_fw_rule set is_new='N' where ti_request_id in "
                    + "(select id from ti_request where process_id=?) ";
            int rowsUpdated = jdbcTemplate.update(updateFAFFWRuleSQL, new Object[] { tiProcessId });
           
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }
        log.debug("Exiting updateFAFFWRule for process_id " + tiProcessId);

    }
   
    /**
     * Update ti process.
     * 
     * @param tiProcess
     *            the ti process
     * @param processCycle
     *            the process cycle
     * @throws Exception
     *             the exception
     */
    public void updateTIProcess(TIProcess tiProcess, String processCycle) throws Exception {
        StringBuilder errMsg = new StringBuilder();
        if (tiProcess != null && chkIsZero(tiProcess.getId()))
            errMsg.append(" Searched Process Id is - " + tiProcess.getId() + ".Please Enter a valid Id ");
        if (!isString(tiProcess.getRequestor().getSoeID()))
            errMsg.append("   Requester ssoid is empty  ");
        if (errMsg.length() > 0) {
            log.error(errMsg.toString());
            throw new Exception("Business Exception : " + errMsg.toString());
        }

        boolean isActive = tiProcessSQL.isProcessActive(tiProcess.getId().longValue());
        if (!isActive) {
            log.error(" Cannot update  TIProcess ID " + tiProcess.getId() + " since its not Active ");
            throw new Exception("Business Exception : Cannot update  TIProcess ID " + tiProcess.getId()
                    + " since its not Active ");
        }
        String entName = null;

        if (!TIProcessDTO.SYSTEM_USER.equalsIgnoreCase(tiProcess.getRequestor().getSoeID()))
            entName = tiProcessSQL.chkUpdatePreviliges(tiProcess.getRequestor().getSoeID(), tiProcess.getId()
                    .longValue());
        String processType = tiProcessSQL.getProcessType(tiProcess.getId().longValue());
        if (processType == null) {
            log.error(" Process Type is undefined for  " + tiProcess.getId());
            throw new Exception(" Process Type is undefined for TIProcess " + tiProcess.getId());
        }
        tiProcess.getBusinessCase().getProcessType().setName(processType);

        // String fafGenerated=null;
        if (isActive) {
            if (isString(entName)) {
                log.error(" Require Project Coordinator role and entitlement to  " + entName
                        + " to Update/Terminate the Process");
                throw new Exception("Business Exception :  Require Project Coordinator role and entitlement to  "
                        + entName + " to Update/Terminate the Process ID "+tiProcess.getId());
            }

            if (TIProcess.CONNECTION.equalsIgnoreCase(processType)) {

                boolean isResourceMissing = tiProcessSQL.isResourceTypeMissing(tiProcess.getId().longValue());
                if (isResourceMissing) {
                    log.error(" Cannot update  TIProcess ID " + tiProcess.getId()
                            + " since Resource type is missing.Please check EndPointA/EndpointB Resource Type ");
                    throw new Exception("Business Exception : Cannot update  TIProcess ID " + tiProcess.getId()
                            + " since Resource type is missing.Please check EndPointA/EndPointB Resource Type ");
                }

                // log.info("Faf Flag for id "+tiProcess.getId() +
                // fafGenerated);

            }

        }
        if (isActive && !isString(entName)) {

            PreparedStatement ps = null;
            try {

                int versionNum = tiProcessSQL.getProcessVersion(tiProcess.getId().longValue());

                if (chkIsZero(Long.valueOf(versionNum)))
                    throw new Exception(" Business Exception : Invalid Version Number for ti Process Id "
                            + tiProcess.getId());

                tiProcess.getTiRequest().setVersionNumber(versionNum + 1);
                tiProcess.getTiRequest().getTiRequestType().setName(processCycle);

                // insert new TIRequest
                tiProcess.getTiRequest().setId(null);
                // Create TIequest and Start Activity
                createRequest(tiProcess);
                long tiRequestID = tiProcess.getTiRequest().getId().longValue();
                insertGenericRFC(tiRequestID, RFCRequestDTO.RFC_REQ_TYPE_GENERIC);
                databaseUtil.copyContactsToXrefs(tiProcess.getId().longValue());
            } catch (Exception e) {
                log.error(e.toString(), e);
                throw new Exception(e.getMessage());
            }

            finally {
                c3parSession.closeStatement(ps);
            }
        }

    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * terminateProcess(com.citigroup.cgti.c3par.domain.TIProcess)
     */
    public long terminateProcess(TIProcess tiProcess) throws Exception {
        Connection con = null;
        PreparedStatement ps = null;
        try {

            updateTIProcess(tiProcess, TIProcessService.TIReqType_Terminate);

            if (TIProcess.CONNECTION.equalsIgnoreCase(tiProcess.getBusinessCase().getProcessType().getName())) {
                // get connectionId for the given connection Request
                Long connID = tiProcessSQL.getConnectionID(tiProcess.getId());
                if (connID == null)
                    throw new Exception(" Connection ID is null for and Active Connection Request ID "
                            + tiProcess.getId());
                TerminationEntity term_entity = new TerminationEntity();
                term_entity.setStatus(TERMINATION_REVIEW);
                term_entity.setRequesterId(tiProcess.getRequestor().getSoeID());
                term_entity.setConnectionId(connID);
                // term_entity.setRequestComment(action_form.getProjectDescription());
                TerminationDAO term_dao = new TerminationDAO(c3parSession);
                term_dao.update(term_entity);

                log.info(" Created Connections Termination Id " + term_entity.getId() + " for TIProcess Id "
                        + tiProcess.getId());
                if (term_entity.getId() == null)
                    throw new Exception(" Could not successfully Create Termination Id for TIProcess ID "
                            + tiProcess.getId());
                /*
                 * ConnectionEntity connection =
                 * ConnectionDAO.createInstance(c3parSession).get(connID);
                 * PlanningEntity planning =
                 * transfromConnection2Planning(connection, c3parSession);
                 */

                ConnectionExtEntity connection = ConnectionExtDAO.createInstance(c3parSession).get(connID);
                PlanningEntity planning = transfromConnection2Planning(connection, c3parSession);

                planning.setConnForCustORClient(connection.getConnForCustORClient());
                planning.setCabApprGrpCode(connection.getCabApprGrpCode());
                planning.setDirectAccessByThirdPrt(connection.getDirectAccessByThirdPrt());
                planning.setReasonForVirtuConn(connection.getReasonForVirtuConn());
                planning.setSemiAnnualEntitlReview(connection.getSemiAnnualEntitlReview());
                planning.setTpTrainingAwarnessPrg(connection.getTpTrainingAwarnessPrg());
                planning.setExportLicenseCordinatorNew(connection.getExportLicenseCordinatorNew());
                planning.setConnEstimate(connection.getConnEstimate());
                planning.setDetInformation(connection.getDetInformation());

                /*
                 * //Added two new fields - SOW, CMPID - for Task 9329
                 * ConnectionExtDAO connectionExtDAO = new ConnectionExtDAO(new
                 * C3parSession()); ConnectionExtEntity connectionExtEntity=
                 * connectionExtDAO.getConnectionExtEntity(connID);
                 * planning.setSOW(connectionExtEntity.getSOW());
                 * planning.setCmpId(connectionExtEntity.getCmpId());
                 */

                /*
                 * While copying details form connection table to con_req,dont
                 * copy the rational field value because if will be differ for
                 * each cycle
                 */
                planning.setRationale(null);

                planning.setPlannedActivateDate(tiProcess.getTiRequest().getPlannedCompletionDate());
                planning.setRequesterId(tiProcess.getRequestor().getSoeID());
                savePlanningEntity(planning, c3parSession);
                PlanningDAO.createInstance(c3parSession).update(planning);
                if (planning.getId() == null)
                    throw new Exception(" Could not successfully Create Planning Id for TIProcess ID "
                            + tiProcess.getId());
                log.info("  Created Connections Termination Id " + term_entity.getId() + ", planning id "
                        + planning.getId() + " for TIProcess Id " + tiProcess.getId());
                // insert into ti_request_planning_xref

                String instSQL = "insert into c3par.ti_request_planning_xref  values (?,?)";
                con = c3parSession.getConnection();
                ps = con.prepareStatement(instSQL);
                ps.setLong(1, tiProcess.getTiRequest().getId().longValue());
                ps.setLong(2, planning.getId().longValue());

                log.debug(" with  values TIRequestID = " + tiProcess.getTiRequest().getId().longValue()
                        + " and Planning =" + planning.getId());
                ps.executeUpdate();
                // Insert Generic RFC
                long tiRequestID = tiProcess.getTiRequest().getId().longValue();
                insertGenericRFC(tiRequestID, RFCRequestDTO.RFC_REQ_TYPE_GENERIC);
            }
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw new EJBException(e.getMessage());
        } finally {
            c3parSession.closeStatement(ps);
            c3parSession.releaseConnection();
        }
        return tiProcess.getTiRequest().getId().longValue();

    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * terminateProcess(com.citigroup.cgti.c3par.bpm.ejb.domain.TIProcessDTO)
     */
    public long terminateProcess(TIProcessDTO processDTO) throws Exception {
        Connection con = null;
        PreparedStatement ps = null;
        TIProcess tiProcess = new TIProcess();
        if (processDTO == null) {
            throw new Exception("Business Exception :  ProcessDTO is null");
        }
        tiProcess.setId(processDTO.getId());
        tiProcess.getRequestor().setSoeID(processDTO.getRequestorSOEId());

        try {

            updateTIProcess(tiProcess, TIProcessService.TIReqType_Terminate);

            if (TIProcess.CONNECTION.equalsIgnoreCase(tiProcess.getBusinessCase().getProcessType().getName())) {
                // get connectionId for the given connection Request
                Long connID = tiProcessSQL.getConnectionID(tiProcess.getId());
                if (connID == null)
                    throw new Exception(" Connection ID is null for and Active Connection Request ID "
                            + tiProcess.getId());
                TerminationEntity term_entity = new TerminationEntity();
                term_entity.setStatus(TERMINATION_REVIEW);
                term_entity.setRequesterId(tiProcess.getRequestor().getSoeID());
                term_entity.setConnectionId(connID);
                // term_entity.setRequestComment(action_form.getProjectDescription());
                TerminationDAO term_dao = new TerminationDAO(c3parSession);
                term_dao.update(term_entity);

                log.info(" Created Connections Termination Id " + term_entity.getId() + " for TIProcess Id "
                        + tiProcess.getId());
                if (term_entity.getId() == null)
                    throw new Exception(" Could not successfully Create Termination Id for TIProcess ID "
                            + tiProcess.getId());
                /*
                 * ConnectionEntity connection =
                 * ConnectionDAO.createInstance(c3parSession).get(connID);
                 */
                ConnectionExtEntity connection = ConnectionExtDAO.createInstance(c3parSession).get(connID);
                PlanningEntity planning = transfromConnection2Planning(connection, c3parSession);

                planning.setConnForCustORClient(connection.getConnForCustORClient());
                planning.setCabApprGrpCode(connection.getCabApprGrpCode());
                planning.setDirectAccessByThirdPrt(connection.getDirectAccessByThirdPrt());
                planning.setReasonForVirtuConn(connection.getReasonForVirtuConn());
                planning.setSemiAnnualEntitlReview(connection.getSemiAnnualEntitlReview());
                planning.setTpTrainingAwarnessPrg(connection.getTpTrainingAwarnessPrg());
                planning.setExportLicenseCordinatorNew(connection.getExportLicenseCordinatorNew());
                planning.setConnEstimate(connection.getConnEstimate());
                planning.setDetInformation(connection.getDetInformation());

                // Added two new fields - SOW, CMPID - for Task 9329
                /*
                 * ConnectionExtDAO connectionExtDAO = new ConnectionExtDAO(new
                 * C3parSession()); ConnectionExtEntity connectionExtEntity=
                 * connectionExtDAO.getConnectionExtEntity(connID);
                 * planning.setSOW(connectionExtEntity.getSOW());
                 * planning.setCmpId(connectionExtEntity.getCmpId());
                 */

                // ///////////////////////////
                /*
                 * While copying details form connection table to con_req,dont
                 * copy the rational field value because if will be differ for
                 * each cycle
                 */
                planning.setRationale(null);
                // ///////////////////

                planning.setPlannedActivateDate(tiProcess.getTiRequest().getPlannedCompletionDate());
                planning.setRequesterId(tiProcess.getRequestor().getSoeID());
                savePlanningEntity(planning, c3parSession);
                PlanningDAO.createInstance(c3parSession).update(planning);
                if (planning.getId() == null)
                    throw new Exception(" Could not successfully Create Planning Id for TIProcess ID "
                            + tiProcess.getId());
                log.info("  Created Connections Termination Id " + term_entity.getId() + ", planning id "
                        + planning.getId() + " for TIProcess Id " + tiProcess.getId());
                // insert into ti_request_planning_xref

                String instSQL = "insert into c3par.ti_request_planning_xref  values (?,?)";
                con = c3parSession.getConnection();
                ps = con.prepareStatement(instSQL);
                ps.setLong(1, tiProcess.getTiRequest().getId().longValue());
                ps.setLong(2, planning.getId().longValue());

                log.debug(" with  values TIRequestID = " + tiProcess.getTiRequest().getId().longValue()
                        + " and Planning =" + planning.getId());
                ps.executeUpdate();

                TechnicalArchitectureUtil taUtil = new TechnicalArchitectureUtil();
                boolean isaborted = isAborted(tiProcess.getId().longValue(), tiProcess.getTiRequest().getId()
                        .longValue(), 2);
                log.debug("In ManageTIProcessImpl: abortToActiveFWRuleCopy,  isaborted => " + isaborted);
                if (isaborted) {
                    String result = abortToActiveFWRuleCopy(tiProcess.getId().longValue(), tiProcess.getTiRequest()
                            .getId().longValue());
                    log.debug("In ManageTIProcessImpl: abortToActiveFWRuleCopy is completed Result is: " + result);
                }
                copyTechArchData(tiProcess.getId(), tiProcess.getTiRequest().getId(),
                        TIProcessService.TIReqType_Terminate);
                taUtil.copyACLVarianceData(tiProcess.getId(), tiProcess.getTiRequest().getId());
                copyUploadedDocuments(tiProcess.getId().longValue(), tiProcess.getTiRequest().getId().longValue());

                // if proxy exists then update proxy generate and rfc change
                // flag
                updateProxyFlags(tiProcess.getId(), tiProcess.getTiRequest().getId());
            }
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw new EJBException(e.getMessage());
        } finally {
            c3parSession.closeStatement(ps);
            c3parSession.releaseConnection();
        }
        return tiProcess.getTiRequest().getId().longValue();

    }

    /**
     * Save planning entity.
     * 
     * @param planningEntity
     *            the planning entity
     * @param c3parSession
     *            the c3par session
     * @throws Exception
     *             the exception
     */
    public void savePlanningEntity(PlanningEntity planningEntity, C3parSession c3parSession) throws Exception {
        insertOrUpdateLocation(planningEntity, c3parSession);
        insertOrUpdateNetwork(planningEntity, c3parSession);
        PlanningDAO planningDAO = new PlanningDAO(c3parSession);
        planningDAO.update(planningEntity);

    }

    /**
     * Insert or update network.
     * 
     * @param planningEntity
     *            the planning entity
     * @param c3parSession
     *            the c3par session
     * @throws DatabaseException
     *             the database exception
     */
    private static void insertOrUpdateNetwork(PlanningEntity planningEntity, C3parSession c3parSession)
            throws DatabaseException {
        if (planningEntity.getNetCon() != null) {
            NetworkConnectionEntity networkConnectionEntity = planningEntity.getNetCon();
            NetworkConnectionDAO dao = new NetworkConnectionDAO(c3parSession);
            dao.update(networkConnectionEntity);
        }
    }

    /**
     * Insert or update location.
     * 
     * @param planningEntity
     *            the planning entity
     * @param c3parSession
     *            the c3par session
     * @throws DatabaseException
     *             the database exception
     */
    private static void insertOrUpdateLocation(PlanningEntity planningEntity, C3parSession c3parSession)
            throws DatabaseException {
        if (planningEntity.getNetCon() != null) {
            NetworkConnectionEntity networkConnectionEntity = planningEntity.getNetCon();
            LocationEntity locationEntity = networkConnectionEntity.getTpLocation();
            if (locationEntity != null) {
                LocationDAO dao = new LocationDAO(c3parSession);
                dao.update(locationEntity);
                networkConnectionEntity.setTpLocation(locationEntity);
            }
        }
    }

    // creates tirequestid,activityid,and updated tiprocess status id and
    // version number
    /**
     * Creates the request.
     * 
     * @param tiProcess
     *            the ti process
     * @throws Exception
     *             the exception
     */

    public void createRequest(TIProcess tiProcess) throws Exception {
        createTIRequest(tiProcess);
        // insert startProcess Activity

        if (tiProcess.getTiRequest().getId().longValue() <= 0)
            throw new Exception(" Could not create TIRequest for TIProcess Id " + tiProcess.getId());

        ActivityData activityData = new ActivityData();
        activityData.setUserID(tiProcess.getRequestor().getSoeID());
        activityData.setActivityName(ActivityData.ACTIVITY_START_PROCESS);
        activityData.setUserRole(ActivityData.ROLE_PC);
        manageActivityImpl.addActivity(activityData, tiProcess.getTiRequest().getId().longValue());

        // get inserted activity id
        // update ProcessStatus and version number

        try {
            // set activityid in tiProcess

            // Update c3par.ti_process_status status id

            String updateSQL = " update c3par.ti_process set version_number=?,process_activity_mode=? where id=? ";

            log.debug(" with  Conditions version Number = " + tiProcess.getTiRequest().getVersionNumber()
                    + "  and TIProcessId =" + tiProcess.getId());
            int rowsUpdated = jdbcTemplate.update(updateSQL, new Object[] {
                    tiProcess.getTiRequest().getVersionNumber(), ActivityData.IS_NEW, tiProcess.getId().longValue() });
         

            String relationshipType = "";
            String relationshipTypeQuery = "SELECT RL.RELATIONSHIP_TYPE FROM TI_PROCESS PR,RELATIONSHIP RL WHERE PR.ID = ? AND PR.RELATIONSHIP_ID = RL.ID  ";
            if (tiProcess.getTiRequest() != null && tiProcess.getTiRequest().getId() != null) {
                SqlRowSet rs = jdbcTemplate.queryForRowSet(relationshipTypeQuery, new Object[] { tiProcess.getId() });
                if (rs.next()) {
                    relationshipType = rs.getString(1);
                }
            }
            log.debug("ManageTIProcessImpl.CreateProcess:reslationshiptype:" + relationshipType + "tirequest:"
                    + tiProcess.getTiRequest());
            if (relationshipType != null && !relationshipType.isEmpty() && tiProcess.getTiRequest() != null) {
                String updateFireFlowFlag = " UPDATE C3PAR.TI_REQUEST SET FIREFLOW_FLAG = 'N' WHERE ID = ? ";
                
                if (relationshipType.equalsIgnoreCase(C3parStaticNames.TEMPLATE_OBJ)
                        || relationshipType.equalsIgnoreCase(C3parStaticNames.IP_TEMPLATE)
                        || relationshipType.equalsIgnoreCase(C3parStaticNames.PORT_TEMPLATE)) {
                    int rowsUpdated1 = jdbcTemplate.update(updateFireFlowFlag, new Object[] { tiProcess.getTiRequest()
                            .getId() });
                    log.debug("ManageTIProcessImpl.CreateProcess:reslationshiptype:" + relationshipType
                            + "tiRequestid:" + tiProcess.getTiRequest().getId() + "::rowsUpdated1=" + rowsUpdated1);
                }
            }

        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.citigroup.cgti.c3par.domain.logic.TIProcessService#setProcessTypeDao
     * (com.citigroup.cgti.c3par.dao.TIProcessTypeDAO)
     */
    public void setProcessTypeDao(TIProcessTypeDAO processTypeDao) {
        this.processTypeDao = processTypeDao;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.citigroup.cgti.c3par.domain.logic.TIProcessService#setTiProcessDao
     * (com.citigroup.cgti.c3par.dao.TIProcessDAO)
     */
    public void setTiProcessDao(TIProcessDAO tiProcessDao) {
        this.tiProcessDao = tiProcessDao;
    }

    /**
     * Checks if is string.
     * 
     * @param val
     *            the val
     * @return true, if is string
     */
    boolean isString(String val) {
        boolean isString = true;
        if (val == null)
            isString = false;
        if (val != null && val.length() == 0)
            isString = false;
        return isString;
    }

    /**
     * Chk bus exception.
     * 
     * @param errMsg
     *            the err msg
     * @throws Exception
     *             the exception
     */
    void chkBusException(StringBuilder errMsg) throws Exception {
        if (errMsg.length() > 0) {
            log.error(errMsg.toString());
            throw new Exception("Business Exception : " + errMsg.toString());
        }

    }

    /**
     * Transfrom connection2 planning.
     * 
     * @param connection
     *            the connection
     * @param db_session
     *            the db_session
     * @return the planning entity
     * @throws DatabaseException
     *             the database exception
     */
    public PlanningEntity transfromConnection2Planning(ConnectionEntity connection, C3parSession db_session)
            throws DatabaseException {
        // C3parSession db_session = new C3parSession();
        PlanningEntity planning = new PlanningEntity();

        planning.setConnectionName(connection.getName());
        planning.setStatus(connection.getStatus());
        // planning.setRequesterId(connection.getRequesterId());
        planning.setRationale(connection.getRationale());
        planning.setBenefit(connection.getBenefit());
        planning.setPlcode(connection.getPlcode());
        planning.setRequireNetworkAccess(connection.getRequireNetworkAccess());
        planning.setEstimatedRevenueGenerated(connection.getEstimatedRevenueGenerated());
        planning.setEstimatedCostSaving(connection.getEstimatedCostSaving());
        planning.setCobRedundancyRequired(connection.getCobRedundancyRequired());
        planning.setSemiAnnualEntitlementReview(connection.getSemiAnnualEntitlementReview());
        planning.setIssConnectionCompliance(connection.getIssConnectionCompliance());
        planning.setCitiPolicyAdherence(connection.getCitiPolicyAdherence());
        planning.setAccessCitiGlobalNetwork(connection.getAccessCitiGlobalNetwork());
        planning.setTpTrainingAwarnessProgram(connection.getTpTrainingAwarnessProgram());
        planning.setSponsorBusinessConsulted(connection.getSponsorBusinessConsulted());
        planning.setExportLicenseCordinator(connection.getExportLicenseCordinator());
        planning.setSecurityReviewComment(connection.getSecurityReviewComments());
        planning.setSponsorReviewComments(connection.getSponsorReviewComments());
        planning.setActivateConnectionComment(connection.getActivateConComments());
        planning.setApproveDetailDesignComment(connection.getApproveDesignComments());
        planning.setSystemAdminComments(connection.getSystemAdminComments());
        planning.setIntegrationStatusComments(connection.getIntegrationStatusComments());
        planning.setProcurementDate(connection.getProcurementDate());
        planning.setProcurementComments(connection.getProcurementComments());
        planning.setPlannedActivateDate(connection.getRequestDate());
        planning.setConnEstimate(connection.getConnEstimate());
        planning.setDetInformation(connection.getDetInformation());

        planning.setRelationship(connection.getRelationship());

        planning.setProcurementOptional(Boolean.TRUE);

        CommonLookupDataEntity con_lookup = connection.getLookup();
        if (con_lookup != null) {
            CommonLookupDataEntity lookup = new CommonLookupDataEntity();
            lookup.setClassificationId(con_lookup.getClassificationId());
            lookup.setConnectionTypeId(con_lookup.getConnectionTypeId());
            lookup.setCustomerDataId(con_lookup.getCustomerDataId());
            lookup.setExpDataFeqId(con_lookup.getExpDataFeqId());
            lookup.setCitigroupDataId(con_lookup.getCitigroupDataId());
            lookup.setExpDataInfoSizeId(con_lookup.getExpDataInfoSizeId());
            lookup.setCriticalityId(con_lookup.getCriticalityId());
            planning.setLookup(lookup);
        }
        // duplicate network connection
        NetworkConnectionEntity con_net_con = connection.getNetCon();
        if (con_net_con != null) {
            NetworkConnectionEntity net_con = new NetworkConnectionEntity();

            net_con.setSplitTunneling(con_net_con.getSplitTunneling());
            net_con.setSplitTunnelingReason(con_net_con.getSplitTunnelingReason());
            net_con.setVirusContainmentStrategy(con_net_con.getVirusContainmentStrategy());
            net_con.setAccessContainmentStrategy(con_net_con.getAccessContainmentStrategy());

            // net_con.setTpLocationId(con_net_con.getTpLocationId());

            CitiLocationEntity con_loc = con_net_con.getCitiLocation();
            CitiLocationEntity loc = new CitiLocationEntity();
            if (con_loc != null) {
                loc.setAddress1(con_loc.getAddress1());
                loc.setAddress2(con_loc.getAddress2());
                loc.setCity(con_loc.getCity());
                loc.setCounty(con_loc.getCounty());
                loc.setRegion(con_loc.getRegion());
                loc.setCountry(con_loc.getCountry());
                loc.setRemsId(con_loc.getRemsId());
                loc.setPrimaryId(con_loc.getPrimaryId());
                net_con.setCitiLocation(loc);

            }

            planning.setNetCon(net_con);
        }

        // Firewall change by Gerald
        // ****************************
        if (connection.getFirewalls() != null) {
            Iterator firewall_iter = connection.getFirewalls().iterator();
            while (firewall_iter.hasNext()) {
                FirewallDetailsEntity firewall = new FirewallDetailsEntity();
                FirewallDetailsEntity con_firewall = (FirewallDetailsEntity) firewall_iter.next();

                firewall.setPrimaryFirewallName(con_firewall.getPrimaryFirewallName());
                firewall.setPrimaryPhyConAddress(con_firewall.getPrimaryPhyConAddress());
                firewall.setPrimaryCircuitId(con_firewall.getPrimaryCircuitId());
                firewall.setPrimaryBandwidth(con_firewall.getPrimaryBandwidth());
                firewall.setSecondaryFirewallName(con_firewall.getSecondaryFirewallName());
                firewall.setSecondaryPhyConAddress(con_firewall.getSecondaryPhyConAddress());
                firewall.setSecondaryCircuitId(con_firewall.getSecondaryCircuitId());
                firewall.setSecondaryBandwidth(con_firewall.getSecondaryBandwidth());
                planning.addToFirewalls(firewall);
            }
        }
        // ****************************
        if (connection.getProjectJustifications() != null) {
            Iterator just_iter = connection.getProjectJustifications().iterator();
            while (just_iter.hasNext()) {
                ProjectJustificationXrefEntity xref = new ProjectJustificationXrefEntity();
                ConnectionProjectJustificationXrefEntity con_xref = (ConnectionProjectJustificationXrefEntity) just_iter
                        .next();
                xref.setRequest(planning);
                xref.setProjectJustification(con_xref.getProjectJustification());
                planning.addToProjectJustifications(xref);
            }

            // planning.setFacilitiesAffected(connection.getFacilitiesAffected());
        }
        if (connection.getFacilitiesAffected() != null) {
            Iterator facil_iter = connection.getFacilitiesAffected().iterator();

            while (facil_iter.hasNext()) {
                FacilitiesAffectedXrefEntity xref = new FacilitiesAffectedXrefEntity();
                ConnectionFacilitiesAffectedXrefEntity con_xref = (ConnectionFacilitiesAffectedXrefEntity) facil_iter
                        .next();
                xref.setRequest(planning);
                xref.setFacilitiesAffected(con_xref.getFacilitiesAffected());
                planning.addToFacilitiesAffected(xref);
            }
        }

        // Modified for 9866 - Copying Changes in Contacts to next Cycle
        ConnectionCitiContactXrefExtDAO dao = new ConnectionCitiContactXrefExtDAO(new C3parSession());
        HashMap<Long, ConnectionCitiContactXrefExtEntity> citiContacts = dao.getNotifyList(
                connection.getOriginalCitiContactsIds(), true);

        // planning.setCitiContacts(connection.getCitiContacts());
        if (connection.getCitiContacts() != null) {
            Iterator citi_iter = connection.getCitiContacts().iterator();
            while (citi_iter.hasNext()) {
                CitiContactXrefExtEntity xref = new CitiContactXrefExtEntity();
                ConnectionCitiContactXrefEntity con_xref = (ConnectionCitiContactXrefEntity) citi_iter.next();
                xref.setRequest(planning);
                xref.setCitiContact(con_xref.getCitiContact());
                xref.setRole(con_xref.getRole());
                xref.setPrimaryContact(con_xref.getPrimaryContact());
                if (citiContacts != null && con_xref.getId() != null) {
                    ConnectionCitiContactXrefExtEntity citiContactXrefExtEntity = citiContacts.get(con_xref.getId());
                    if (citiContactXrefExtEntity != null) {
                        xref.setNotifyContact(citiContactXrefExtEntity.getNotifyContact());
                    }
                }
                planning.addToCitiContacts(xref);
            }
        }

        ConnectionCitiReqContactXrefExtDAO reqDao = new ConnectionCitiReqContactXrefExtDAO(new C3parSession());
        HashMap<Long, ConnectionCitiReqContactXrefExtEntity> citiReqContacts = reqDao.getNotifyList(
                connection.getOriginalCitiReqContactsIds(), true);

        if (connection.getCitiReqContacts() != null) {
            Iterator citiReq_iter = connection.getCitiReqContacts().iterator();
            while (citiReq_iter.hasNext()) {
                CitiReqContactXrefExtEntity xref = new CitiReqContactXrefExtEntity();
                ConnectionCitiReqContactXrefEntity con_xref = (ConnectionCitiReqContactXrefEntity) citiReq_iter.next();
                xref.setRequest(planning);
                xref.setCitiContact(con_xref.getCitiContact());
                xref.setRole(con_xref.getRole());
                xref.setPrimaryContact(con_xref.getPrimaryContact());
                if (citiReqContacts != null && con_xref.getId() != null) {
                    ConnectionCitiReqContactXrefExtEntity citiContactXrefExtEntity = citiReqContacts.get(con_xref
                            .getId());
                    if (citiContactXrefExtEntity != null) {
                        xref.setNotifyContact(citiContactXrefExtEntity.getNotifyContact());
                    }
                }
                planning.addToCitiReqContacts(xref);
            }
        }
        // planning.setTpContacts(connection.getTpContacts());
        if (connection.getTpContacts() != null) {
            Iterator tp_iter = connection.getTpContacts().iterator();
            while (tp_iter.hasNext()) {
                TPContactXrefEntity xref = new TPContactXrefEntity();
                ConnectionTPContactXrefEntity con_xref = (ConnectionTPContactXrefEntity) tp_iter.next();
                xref.setRequest(planning);
                xref.setTpContact(con_xref.getTpContact());
                xref.setRole(con_xref.getRole());
                planning.addToTpContacts(xref);
            }
        }
        // planning.setResources(connection.getResources());
        if (connection.getResources() != null) {
            Iterator res_iter = connection.getResources().iterator();
            while (res_iter.hasNext()) {
                ResourceXrefEntity xref = new ResourceXrefEntity();
                ConnectionResourceXrefEntity con_xref = (ConnectionResourceXrefEntity) res_iter.next();
                xref.setRequest(planning);
                xref.setResource(con_xref.getResource());
                planning.addToResources(xref);
            }
        }

        // planning.setServices(connection.getServices());
        if (connection.getServices() != null) {
            Iterator serv_iter = connection.getServices().iterator();
            while (serv_iter.hasNext()) {
                TPServiceXrefEntity xref = new TPServiceXrefEntity();
                ConnectionTPServiceXrefEntity con_xref = (ConnectionTPServiceXrefEntity) serv_iter.next();
                xref.setRequest(planning);
                xref.setService(con_xref.getService());
                planning.addToServices(xref);
            }
        }
        // planning.setMaterialBill(connection.getMaterialBills());
        if (connection.getMaterialBills() != null) {
            Iterator material_iter = connection.getMaterialBills().iterator();
            while (material_iter.hasNext()) {
                MaterialBillEntity bill = new MaterialBillEntity();
                MaterialBillEntity con_bill = (MaterialBillEntity) material_iter.next();

                bill.setItem(con_bill.getItem());
                bill.setOneTimeCost(con_bill.getOneTimeCost());
                bill.setMonthlyCost(con_bill.getMonthlyCost());
                bill.setSerialNumber(con_bill.getSerialNumber());

                planning.addToMaterialBill(bill);
            }
        }
        planning.setOperationalAnalystComments(connection.getOperationalAnalystComments());
        planning.setIstgComments(connection.getIstgComments());
        planning.setInfomanId(connection.getInfomanId());
        planning.setOpAnalystScheduleDate(connection.getOpAnalystScheduleDate());
        planning.setOpAnalystCompletedDate(connection.getOpAnalystCompletedDate());
        return planning;
    }

    // activityCode cannot be null activityStatus can be null
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#endProcess
     * (long, java.lang.String, java.lang.String)
     */
    public void endProcess(long tiRequestID, String activityCode, String activityStatus) throws Exception {
        StringBuilder errMsg = new StringBuilder();
        String procStatus = null;
        String tempApprovalFlag = "N";
        String tempExpiryGenFlag = "N";
        log.debug("End Process activityStatus:activityCode  " + activityStatus + ":" + activityCode + ",tiRequestID=>"
                + tiRequestID);
        if (chkIsZero(Long.valueOf(tiRequestID)))
            errMsg.append(" Invalid Request Id " + tiRequestID);

        if (errMsg.length() > 0) {
            log.error(errMsg.toString());
            throw new Exception("Business Exception : " + errMsg.toString());
        }
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            Map processMap = tiProcessSQL.getProcessForTIRequest(tiRequestID);
            Long procID = (Long) processMap.get("ID");
            String processType = (String) processMap.get("PROCESSTYPE");
            String requestType = (String) processMap.get("REQUESTTYPE");
            Long tempAppDate = (Long) processMap.get("TEMPAPPDATE");
            log.debug("Temp Approval Date: " + tempAppDate);
            Date activationExpDate = null;
            if (tempAppDate != null && tempAppDate.longValue() > 0) {
                activationExpDate = new Date(tempAppDate.longValue());
                tempApprovalFlag = "Y";
            } else {
                Calendar c1 = Calendar.getInstance();
                c1.setTime(new Date());
                c1.add(Calendar.DATE, 365);
                activationExpDate = c1.getTime();
            }
            boolean createInventory = true;
            if (activityCode != null && activityCode.equals(ActivityDataDTO.ACTIVITY_ABORTED))
                createInventory = false;
            log.debug(" End Process Current ProcessActivty  Details  : Process ID= " + procID + " ,processType="
                    + processType);
            if (procID == null || processType == null)
                throw new Exception(" Check processs details for TIRequest ID : Process ID= " + procID
                        + " ,processType=" + processType);

            // update the status of tiprocess table to Active

            // adding an activity to ti_Activity_trail
            /*
             * ClassPathXmlApplicationContext context = new
             * ClassPathXmlApplicationContext( new String[] { "ejbContext.xml",
             * "dataAccessContext.xml" }); ManageActivityImpl manageActivityImpl
             * = (IManageActivity) context .getBean("manageActivityImpl");
             */

            ActivityData activityData = new ActivityData();
            activityData.setActivityName(activityCode);
            activityData.setUserRole(ActivityData.ROLE_PC);
            activityData.setActivityStatus(ActivityData.STATUS_END);

            manageActivityImpl.addActivity(activityData, tiRequestID);
            con = c3parSession.getConnection();

            if (createInventory && !TIProcessDTO.ACV.equalsIgnoreCase(requestType)) {
                StringBuilder updateProcSQL = new StringBuilder("update c3par.ti_process set  temp_Approval_flag='"
                        + tempApprovalFlag + "'");

                updateProcSQL.append(" , temp_expiry_gen_flag = '" + tempExpiryGenFlag + "'");

                if (!ActivityDataDTO.STATUS_ABORTED.equalsIgnoreCase(activityStatus)) {
                    updateProcSQL.append(" , ACTIVATION_EXP_DATE=? ");
                }

                updateProcSQL.append(" where id=? ");
                ps = con.prepareStatement(updateProcSQL.toString());
                if (!ActivityDataDTO.STATUS_ABORTED.equalsIgnoreCase(activityStatus)) {
                    ps.setDate(1, new java.sql.Date(activationExpDate.getTime()));
                    ps.setLong(2, procID.longValue());
                } else
                    ps.setLong(1, procID.longValue());
                log.debug(" with  values TIProcessID = " + procID + " and ActivityId =" + procStatus);
                ps.executeUpdate();
                c3parSession.closeStatement(ps);
            }

            StringBuilder updateReqSQL = new StringBuilder(" update c3par.ti_request set COMPLETION_DATE=SYSDATE ");

            if (ActivityDataDTO.STATUS_ABORTED.equalsIgnoreCase(activityStatus))
                updateReqSQL.append(" , is_deleted='Y' ");
            updateReqSQL.append(" where id=? ");
            ps = con.prepareStatement(updateReqSQL.toString());
            /*
             * java.util.Date currDate=new java.util.Date(); ps.setDate(1,new
             * Date(currDate.getTime()));
             */
            ps.setLong(1, tiRequestID);

            log.debug("TIRequestID = " + tiRequestID);
            ps.executeUpdate();
            c3parSession.closeStatement(ps);
            // Insert Connection Record only if process type is connection and
            // is in create cycle

            if (createInventory && TIProcess.CONNECTION.equalsIgnoreCase(processType)) {
                Long currentRequestId = procID;
                long connID = -1;
                // ConnectionDAO connectionDAO = new
                // ConnectionDAO(c3parSession);
                ConnectionExtDAO connectionExtDAO = new ConnectionExtDAO(c3parSession);
                ConnectionExtEntity connectionExtEntity = null;

                PlanningDAO dao = new PlanningDAO(c3parSession);
                if ((TIProcessService.TIReqType_Create.equalsIgnoreCase(requestType))) {
                    connectionExtEntity = new ConnectionExtEntity();
                } else {
                    StringBuilder planningSQL = new StringBuilder();
                    planningSQL
                            .append(" select 'Planning', tireqplan.planning_id from c3par.ti_request tireq  ,c3par.ti_request_planning_xref tireqplan where tireq.id= tireqplan.ti_request_id and tireq.id= ? ");
                    planningSQL.append(" union ");
                    planningSQL.append(" select 'Connection',id from c3par.connection where connection_request_id=? ");
                    ps = con.prepareStatement(planningSQL.toString());
                    ps.setLong(1, tiRequestID);
                    ps.setLong(2, procID.longValue());

                    log.debug(" with  values TIProcessID = " + procID + " and TIRequestID =" + tiRequestID);
                    rs = ps.executeQuery();
                    Long planningID = null;
                    while (rs.next()) {
                        String connPhase = rs.getString(1);
                        if ("Planning".equals(connPhase))
                            currentRequestId = Long.valueOf(rs.getLong(2));
                        else if ("Connection".equals(connPhase))
                            connID = rs.getLong(2);
                    }

                    if (chkIsZero(planningID))
                        log.error(" No Planning ID is associated with Request ID " + tiRequestID
                                + " Continuing with the original Planning ID " + currentRequestId);
                    else {
                        currentRequestId = planningID;
                    }
                    if (chkIsZero(Long.valueOf(connID))) {
                        log.error(" No Connection ID id associated for a Maintenance Process ID " + procID);
                        connectionExtEntity = new ConnectionExtEntity();
                    } else {
                        connectionExtEntity = (ConnectionExtEntity) connectionExtDAO.get(Long.valueOf(connID));
                    }

                    // connectionEntity=connectionDAO.get();
                }
                log.info(" Updating   Planning ID " + currentRequestId + ",Connection ID " + connID
                        + " Details for TIProcessId " + procID);
                PlanningEntity planningEntity = (PlanningEntity) dao.get(currentRequestId);
                // Insert to inventory
                transformToInventory(planningEntity, connectionExtEntity);
                connectionExtEntity.setConnectionRequestId(procID);
                connectionExtEntity.setConnForCustORClient(planningEntity.getConnForCustORClient());
                connectionExtEntity.setCabApprGrpCode(planningEntity.getCabApprGrpCode());
                connectionExtEntity.setDirectAccessByThirdPrt(planningEntity.getDirectAccessByThirdPrt());
                connectionExtEntity.setReasonForVirtuConn(planningEntity.getReasonForVirtuConn());
                connectionExtEntity.setSemiAnnualEntitlReview(planningEntity.getSemiAnnualEntitlReview());
                connectionExtEntity.setTpTrainingAwarnessPrg(planningEntity.getTpTrainingAwarnessPrg());
                connectionExtEntity.setExportLicenseCordinatorNew(planningEntity.getExportLicenseCordinatorNew());
                connectionExtEntity.setConnEstimate(planningEntity.getConnEstimate());
                connectionExtEntity.setDetInformation(planningEntity.getDetInformation());

                Long primaryKey = connectionExtDAO.update(connectionExtEntity);
                // Added two new fields - SOW, CMPID - for Task 9329
                log.debug(" Updating   Planning ID " + currentRequestId + ",Connection ID " + connID
                        + " Details for TIProcessId " + procID);
                /*
                 * ConnectionExtDAO connectionExtDAO = new ConnectionExtDAO(new
                 * C3parSession()); ConnectionExtEntity connectionExtEntity =
                 * new ConnectionExtEntity();
                 * connectionExtEntity.setSOW(planningEntity.getSOW());
                 * connectionExtEntity.setCmpId(planningEntity.getCmpId());
                 * connectionExtEntity.setPrimaryKey(primaryKey);
                 * log.info(" Primary Key "
                 * +connectionExtEntity.getPrimaryKey());
                 * connectionExtDAO.update(connectionExtEntity);
                 */

            }
            /*
             * if(TIProcess.CONNECTION.equalsIgnoreCase(processType)){
             * if(ActivityDataDTO
             * .STATUS_ABORTED.equalsIgnoreCase(activityStatus)){
             * abortTechArchData( procID.longValue(), tiRequestID);
             * releaseCMP(tiRequestID); } }
             */
            if (TIProcess.CONNECTION.equalsIgnoreCase(processType)) {
                if (ActivityDataDTO.STATUS_ABORTED.equalsIgnoreCase(activityStatus)) {
                    abortTechArchData(procID.longValue(), tiRequestID);
                    ccrCMPMappingService.clearMappedCMPIds(tiRequestID);
                }
                log.debug("End Process @ bidirectional activityStatus:activityCode  " + activityStatus + ":"
                        + activityCode);
                if (ActivityDataDTO.ACTIVITY_ACTIVE.equalsIgnoreCase(activityCode)
                        || ActivityDataDTO.ACTIVITY_TERMINATED.equalsIgnoreCase(activityCode)) {
                    StringBuilder sb1 = new StringBuilder();
                    PreparedStatement pStmt = null;
                    sb1.append("update CON_FW_RULE cfr set bidirectional = 'ON' ");
                    sb1.append("where cfr.bidirectional = 'ONINPROGRESS' and cfr.ti_request_id = ?");
                    pStmt = con.prepareStatement(sb1.toString());
                    pStmt.setLong(1, tiRequestID);
                    pStmt.executeUpdate();

                    StringBuilder sb2 = new StringBuilder();
                    sb2.append("update CON_FW_RULE cfr set bidirectional = 'OFF' ");
                    sb2.append("where cfr.bidirectional = 'OFFINPROGRESS' and cfr.ti_request_id = ?");
                    pStmt = con.prepareStatement(sb2.toString());
                    pStmt.setLong(1, tiRequestID);
                    pStmt.executeUpdate();
                    c3parSession.closeStatement(pStmt);
                    log.debug("In ManageTIProcessImpl: endProcess mothed: Bidirectional status updated Successfully ");
                }
                // log.debug(
                // "******************** copyHistoryFwRuleData, procID.longValue()=>"+procID.longValue()+",tiRequestID=>"+tiRequestID);
                if (ActivityDataDTO.ACTIVITY_ACTIVE.equalsIgnoreCase(activityCode)
                        || ActivityDataDTO.ACTIVITY_TERMINATED.equalsIgnoreCase(activityCode)) {
                    // String result=copyFwRuleData(procID.longValue(),
                    // tiRequestID,requestType,"ENDPROCESS");
                    boolean isaborted = isAborted(procID.longValue(), tiRequestID, 1);
                    log.debug("Before copyHistoryFwRuleData, procID.longValue()=>" + procID.longValue()
                            + ",tiRequestID=>" + tiRequestID + ",isaborted=>" + isaborted);
                    if (!isaborted) {// If current cycle is aborted then no need
                                     // to copy FWRules to history
                        String result = copyHistoryFwRuleData(procID.longValue(), tiRequestID);
                        log.debug("In ManageTIProcessImpl: copy CON FW RULE TO HISTORY TABLE is completed Result is:"
                                + result);
                    }
                    // log.debug( "Before abortToActiveFWRuleCopy");
                    // abortToActiveFWRuleCopy(tiProcess.getId().longValue(),tiProcess.getTiRequest().getId().longValue());
                    // log.debug(
                    // "After abortToActiveFWRuleCopy ............... Before copying Uploaded Documents");
                }

            }
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw new Exception(e.getMessage());
        } finally {
            c3parSession.closeResultSet(rs);
            c3parSession.closeStatement(ps);
            c3parSession.releaseConnection();
        }
    }

  /*  *//**
     * @param processId
     * @param tiRequestId
     * @param requestType
     * @param controlFlag
     * @return
     * @throws Exception
     *//*
    private String copyFwRuleData(Long processId, Long tiRequestId, String requestType, String controlFlag)
            throws Exception {
        String result = null;
        try {

            SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("COPY_FW_RULE");

            Map<String, Object> inParamMap = new HashMap<String, Object>();
            inParamMap.put("P_TI_REQUEST_ID", tiRequestId.longValue());
            inParamMap.put("P_PROCESS_ID", processId.longValue());
            inParamMap.put("P_REQUEST_TYPE", requestType);
            inParamMap.put("P_CONTROL_TYPE", controlFlag);
            SqlParameterSource in = new MapSqlParameterSource(inParamMap);

            Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
            if (simpleJdbcCallResult.get("P_RESULT") != null) {
                result = (String) simpleJdbcCallResult.get("P_RESULT");
            }

        } catch (Exception ex) {
            log.error(ex.toString(), ex);
        }
        return result;
    }*/

    /**
     * @param processId
     * @param tiRequestId
     * @return
     * @throws Exception
     */
    private String copyHistoryFwRuleData(Long processId, Long tiRequestId) throws Exception {
        String result = null;
        try {
            log.debug(" CopyHistoryFwRuleData  Starts : TIRequestID = " + tiRequestId);

            SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
                    .withProcedureName("COPY_HISTORY_CON_FW_RULE");

            Map<String, Object> inParamMap = new HashMap<String, Object>();
            inParamMap.put("P_TI_REQUEST_ID", tiRequestId.longValue());

            SqlParameterSource in = new MapSqlParameterSource(inParamMap);

            Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
            if (simpleJdbcCallResult.get("P_RESULT") != null) {
                result = (String) simpleJdbcCallResult.get("P_RESULT");
            }

            log.debug(" CopyHistoryFwRuleData : result = " + result);
        } catch (Exception ex) {
            log.error(ex.toString(), ex);
        }

        return result;
    }

    /**
     * Transform to inventory.
     * 
     * @param planningEntity
     *            the planning entity
     * @param connectionEntity
     *            the connection entity
     * @return the connection entity
     */
    public ConnectionEntity transformToInventory(PlanningEntity planningEntity, ConnectionEntity connectionEntity) {
        fillConnection(planningEntity, connectionEntity);
        connectionEntity.setReadyDate(new java.util.Date());
        return connectionEntity;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * getProcessesForAutopush()
     */

    public List getProcessesForAutopush() throws Exception {

        String sql = "select distinct tat.TI_REQUEST_ID from ti_process tp,ti_activity_trail tat,ti_request tr where tp.autopush = 'Y' and tr.process_id=tp.id and tr.version_number=tp.version_number and tr.id=tat.ti_request_id and tat.activity_status = 'SCHEDULED'";
        List ids = new ArrayList();
        try {
            SqlRowSet rowSet = jdbcTemplate.queryForRowSet(sql);
            while (rowSet.next()) {
                ids.add(rowSet.getString(1));
            }
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }
        return ids;
    }


    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * getRequestsForNotification()
     */

    public List getRequestsForNotification() throws Exception {

        String sql = "select nextkey from key_generator where entity = 'FAFCompleted'";
        List ids = new ArrayList();
        try {
            SqlRowSet rowSet = jdbcTemplate.queryForRowSet(sql);
            while (rowSet.next()) {
                ids.add(rowSet.getString(1));
            }
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }

        return ids;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * setRequestDeadline(long, java.util.Date)
     */

    public void setRequestDeadline(long tiRequestId, Date reqDeadline) throws Exception {
        StringBuilder errMsg = new StringBuilder();

        if (tiRequestId <= 0)
            errMsg.append("Invalid Request Id " + tiRequestId);
        if (reqDeadline == null)
            errMsg.append("Invalid RequestDeadline " + reqDeadline);
        if (errMsg.length() > 0) {
            log.error(errMsg.toString());
            throw new Exception("Business Exception : " + errMsg.toString());
        }

        try {
            StringBuilder processUpdateSql = new StringBuilder();
            processUpdateSql.append(" update ti_request  SET request_deadline= ?  where id = ? ");
            log.debug(" Run with values tiRequestID = " + tiRequestId + " and RequestDeadline = " + reqDeadline);
            int rowsUpdated = jdbcTemplate.update(processUpdateSql.toString(), new Object[] {
                    new java.sql.Timestamp(reqDeadline.getTime()), tiRequestId });
            
        } catch (Exception e) {
            log.error(e, e);
            throw e;
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * setActivationDeadline(long, java.util.Date)
     */
    public void setActivationDeadline(long tiRequestId, Date reqDeadline) throws Exception {
        Connection con = null;
        PreparedStatement ps = null;
        StringBuilder errMsg = new StringBuilder();

        if (tiRequestId <= 0)
            errMsg.append("Invalid Request Id " + tiRequestId);
        if (reqDeadline == null)
            errMsg.append("Invalid ActivationDeadline " + reqDeadline);
        if (errMsg.length() > 0) {
            log.error(errMsg.toString());
            throw new Exception("Business Exception : " + errMsg.toString());
        }

        try {
            StringBuilder processUpdateSql = new StringBuilder();
            processUpdateSql
                    .append(" update ti_process  SET activation_exp_date= ?  where id = (select process_id from c3par.ti_request where id= ?) ");

            con = c3parSession.getConnection();
            log.debug(" Run with values tiRequestID = " + tiRequestId + " and ActivationDeadline = " + reqDeadline);
            ps = con.prepareStatement(processUpdateSql.toString());
            // ps.setDate(1, new java.sql.Date(reqDeadline.getTime()));
            ps.setTimestamp(1, new java.sql.Timestamp(reqDeadline.getTime()));
            ps.setLong(2, tiRequestId);
            ps.executeUpdate();
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw new RemoteException(e.getMessage());
        } finally {
            c3parSession.closeStatement(ps);
            c3parSession.releaseConnection();
        }

    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * getExtendedTime(java.lang.String)
     */
    public List getExtendedTime(String value) throws Exception {
        List extendTimeList = new ArrayList();
        try {
            StringBuilder extendSQL = new StringBuilder();
            extendSQL.append("select value2 from c3par.generic_lookup where value1 like '" + value + "%'");
            SqlRowSet rowSet = jdbcTemplate.queryForRowSet(extendSQL.toString());
            while (rowSet.next()) {
                extendTimeList.add(Integer.valueOf(rowSet.getString(1)));
            }
            log.info("extendTimeList::" + extendTimeList);
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }
        return extendTimeList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * getExpirationActions(java.lang.String)
     */
    public List getExpirationActions(String activityCode) throws Exception {
        List actions = new ArrayList();
        try {
            StringBuilder expActionSQL = new StringBuilder(
                    " select value1 from c3par.generic_lookup where definition_id in (select id from c3par.generic_lookup_defs where name='"
                            + activityCode + "')");
            SqlRowSet rowSet = jdbcTemplate.queryForRowSet(expActionSQL.toString());
            while (rowSet.next()) {
                actions.add(rowSet.getString(1));
            }
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }
        return actions;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * updateAutopushStatus(long, java.lang.String)
     */

    public long updateAutopushStatus(long tiRequestId, String autopushStatus) throws Exception {
        int rowsUpdated = 0;
        try {
            StringBuilder processUpdateSql = new StringBuilder();
            processUpdateSql
                    .append(" update ti_process set autopush = ? where id = (select tp.id from ti_Process tp,ti_request tr where tr.process_id = tp.id and tr.id = ?) ");

            log.debug(" Run with values tiRequestID = " + tiRequestId + " autopushStatus = " + autopushStatus);
            rowsUpdated = jdbcTemplate
                    .update(processUpdateSql.toString(), new Object[] { autopushStatus, tiRequestId });
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }
        return rowsUpdated;
    }

    /**
     * Fill connection.
     * 
     * @param planningEntity
     *            the planning entity
     * @param connectionEntity
     *            the connection entity
     */
    public static void fillConnection(PlanningEntity planningEntity, ConnectionEntity connectionEntity) {

        // All lookups
        connectionEntity.setLookup(planningEntity.getLookup());

        // Map business case
        connectionEntity.setRationale(planningEntity.getRationale());
        connectionEntity.setBenefit(planningEntity.getBenefit());
        connectionEntity.setSemiAnnualEntitlementReview(planningEntity.getSemiAnnualEntitlementReview());
        connectionEntity.setTpTrainingAwarnessProgram(planningEntity.getTpTrainingAwarnessProgram());
        connectionEntity.setCitiPolicyAdherence(planningEntity.getCitiPolicyAdherence());
        connectionEntity.setAccessCitiGlobalNetwork(planningEntity.getAccessCitiGlobalNetwork());
        connectionEntity.setPlcode(planningEntity.getPlcode());
        connectionEntity.setEstimatedRevenueGenerated(planningEntity.getEstimatedRevenueGenerated());
        connectionEntity.setEstimatedCostSaving(planningEntity.getEstimatedCostSaving());
        connectionEntity.setSponsorBusinessConsulted(planningEntity.getSponsorBusinessConsulted());
        connectionEntity.setExportLicenseCordinator(planningEntity.getExportLicenseCordinator());

        connectionEntity.clearProjectJustifications();
        Iterator it = planningEntity.getProjectJustifications().iterator();
        while (it.hasNext()) {
            ProjectJustificationXrefEntity xrefEntity = (ProjectJustificationXrefEntity) it.next();
            ConnectionProjectJustificationXrefEntity cxrefEntity = new ConnectionProjectJustificationXrefEntity();
            cxrefEntity.setConnection(connectionEntity);
            cxrefEntity.setProjectJustification(xrefEntity.getProjectJustification());
            connectionEntity.getProjectJustifications().add(cxrefEntity);
        }

        connectionEntity.clearFacilitiesAffected();
        it = planningEntity.getFacilitiesAffected().iterator();
        while (it.hasNext()) {
            FacilitiesAffectedXrefEntity xrefEntity = (FacilitiesAffectedXrefEntity) it.next();
            ConnectionFacilitiesAffectedXrefEntity cxrefEntity = new ConnectionFacilitiesAffectedXrefEntity();
            cxrefEntity.setConnection(connectionEntity);
            cxrefEntity.setFacilitiesAffected(xrefEntity.getFacilitiesAffected());
            connectionEntity.getFacilitiesAffected().add(cxrefEntity);
        }
        connectionEntity.setCobRedundancyRequired(planningEntity.getCobRedundancyRequired());

        // Connection basic information
        connectionEntity.setName(planningEntity.getConnectionName());
        connectionEntity.setNetCon(planningEntity.getNetCon());
        connectionEntity.setRequestDate(planningEntity.getPlannedActivateDate());

        connectionEntity.clearServices();
        it = planningEntity.getServices().iterator();
        while (it.hasNext()) {
            TPServiceXrefEntity xrefEntity = (TPServiceXrefEntity) it.next();
            ConnectionTPServiceXrefEntity cxrefEntity = new ConnectionTPServiceXrefEntity();
            cxrefEntity.setConnection(connectionEntity);
            cxrefEntity.setService(xrefEntity.getService());
            connectionEntity.getServices().add(cxrefEntity);
        }

        // Citigroup contacts
        // Modified for 9866 - Copying Changes in Contacts to next Cycle
        HashMap<Long, CitiContactXrefExtEntity> citiExtContacts = planningEntity.getCitiExtContacts();

        connectionEntity.clearCitiContacts();
        if (planningEntity.getCitiContacts() != null) {
            it = planningEntity.getCitiContacts().iterator();
            while (it.hasNext()) {
                CitiContactXrefEntity xrefEntity = (CitiContactXrefEntity) it.next();
                ConnectionCitiContactXrefExtEntity cxrefEntity = new ConnectionCitiContactXrefExtEntity();
                cxrefEntity.setConnection(connectionEntity);
                cxrefEntity.setRole(xrefEntity.getRole());
                cxrefEntity.setCitiContact(xrefEntity.getCitiContact());
                cxrefEntity.setPrimaryContact(xrefEntity.getPrimaryContact());
                if (citiExtContacts != null && xrefEntity.getId() != null) {
                    CitiContactXrefExtEntity xrefExtEntity = citiExtContacts.get(xrefEntity.getId());
                    if (xrefExtEntity != null) {
                        cxrefEntity.setNotifyContact(xrefExtEntity.getNotifyContact());
                    }
                }
                connectionEntity.getCitiContacts().add(cxrefEntity);
            }
        }
        HashMap<Long, CitiReqContactXrefExtEntity> citiReqExtContacts = planningEntity.getCitiReqExtContacts();

        connectionEntity.clearCitiReqContacts();
        if (planningEntity.getCitiReqContacts() != null) {
            it = planningEntity.getCitiReqContacts().iterator();
            while (it.hasNext()) {
                CitiReqContactXrefEntity xrefEntity = (CitiReqContactXrefEntity) it.next();
                ConnectionCitiReqContactXrefExtEntity cxrefEntity = new ConnectionCitiReqContactXrefExtEntity();
                cxrefEntity.setConnection(connectionEntity);
                cxrefEntity.setRole(xrefEntity.getRole());
                cxrefEntity.setCitiContact(xrefEntity.getCitiContact());
                cxrefEntity.setPrimaryContact(xrefEntity.getPrimaryContact());
                if (citiReqExtContacts != null && xrefEntity.getId() != null) {
                    CitiReqContactXrefExtEntity xrefExtEntity = citiReqExtContacts.get(xrefEntity.getId());
                    if (xrefExtEntity != null) {
                        cxrefEntity.setNotifyContact(xrefExtEntity.getNotifyContact());
                    }
                }
                connectionEntity.getCitiReqContacts().add(cxrefEntity);
            }

        }

        // Third party contacts
        connectionEntity.clearTpContacts();
        if (planningEntity.getTpContacts() != null) {
            it = planningEntity.getTpContacts().iterator();
            while (it.hasNext()) {
                TPContactXrefEntity xrefEntity = (TPContactXrefEntity) it.next();
                ConnectionTPContactXrefEntity cxrefEntity = new ConnectionTPContactXrefEntity();
                cxrefEntity.setConnection(connectionEntity);
                cxrefEntity.setRole(xrefEntity.getRole());
                cxrefEntity.setTpContact(xrefEntity.getTpContact());
                connectionEntity.getTpContacts().add(cxrefEntity);
            }
        }

        // Resource
        /*
         * 
         * // Firewall connectionEntity.clearFirewalls();
         * connectionEntity.getFirewalls
         * ().addAll(planningEntity.getFirewalls());
         */

        // security review comments
        connectionEntity.setSecurityReviewComments(planningEntity.getSecurityReviewComment());
        connectionEntity.setIssConnectionCompliance(planningEntity.getIssConnectionCompliance());

        // Sponsor review comments
        connectionEntity.setSponsorReviewComments(planningEntity.getSponsorReviewComments());

        // Approve detailed design comment
        connectionEntity.setApproveDesignComments(planningEntity.getApproveDetailDesignComment());

        // Procurement & Network
        connectionEntity.setProcurementDate(planningEntity.getProcurementDate());
        connectionEntity.setProcurementComments(planningEntity.getProcurementComments());
        connectionEntity.setIntegrationStatusComments(planningEntity.getIntegrationStatusComments());

        // SystemAdmin comments
        connectionEntity.setSystemAdminComments(planningEntity.getSystemAdminComments());

        // Activate comments
        connectionEntity.setActivateConComments(planningEntity.getActivateConnectionComment());

        // Others
        connectionEntity.setRelationship(planningEntity.getRelationship());
        connectionEntity.setStatus(ACTIVE);
        connectionEntity.setRequesterId(planningEntity.getRequesterId());

        connectionEntity.setOperationalAnalystComments(planningEntity.getOperationalAnalystComments());
        connectionEntity.setIstgComments(planningEntity.getIstgComments());
        connectionEntity.setInfomanId(planningEntity.getInfomanId());
        connectionEntity.setOpAnalystScheduleDate(planningEntity.getOpAnalystScheduleDate());
        connectionEntity.setOpAnalystCompletedDate(planningEntity.getOpAnalystCompletedDate());

    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * sendEmailToAppOwners(long)
     */
    public void sendEmailToAppOwners(long tiRequestId) throws Exception {

    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * sendEmailToAppOwners(long, boolean, boolean, boolean)
     */
    public void sendEmailToAppOwners(long tiRequestId, boolean firewallFlag, boolean proxyFlag, boolean appSenseFlag)
            throws Exception {

        log.debug("ManageTIProcessImpl.sendEmailToAppOwners::starts");
        TIProcess tiProcess = null;
        InputMailVO inputMailVO = null;
        StringBuilder errMsg = new StringBuilder();
        Map<String, String> templateDtls = new HashMap<String, String>();
        if (chkIsZero(Long.valueOf(tiRequestId)))
            errMsg.append(" Invalid Request Id " + tiRequestId);

        if (errMsg.length() > 0) {
            log.error(errMsg.toString());
            throw new Exception("Business Exception : " + errMsg.toString());
        }

        try {
            tiProcess = getProcessData(tiRequestId);
            if (tiProcess != null) {
                log.debug("ManageTIProcessImpl.sendEmailToAppOwners::tiProcess is not null:");
                inputMailVO = new InputMailVO();
                inputMailVO.setTiProcess(tiProcess);
                inputMailVO.setConnectionId((tiProcess.getId()).longValue() + "");
                if (tiProcess.getTiRequest() != null)
                    inputMailVO.setTirequestID(tiProcess.getTiRequest().getId().longValue());
                String owner = mailModuleUtil.getTemplateConnOwners(inputMailVO);
                log.info("ManageTIProcessImpl.sendEmailToAppOwners::owner: " + owner);
                if (owner != null && !owner.isEmpty()) {
                    templateDtls = mailModuleUtil.getTmpltConIdsAndNamesForUsedConn(tiRequestId);
                    tiProcess.setTemplateConIds(templateDtls.get("TMP_CONN_IDS"));
                    tiProcess.setTemplateConNames(templateDtls.get("TMP_CONN_NAMES"));
                    tiProcess.setTemplateOwners(templateDtls.get("TMP_CONN_OWNERS"));
                    // send mail to TemplateUsage connection contacts
                    mailModuleImpl.sendMail(
                            mailModuleImpl.parseTemplateNew(TEMPLT_UING_CONN_MAIL_B4_TECH, inputMailVO, true),
                            mailModuleUtil.testModeFlag(tiProcess.getId(), mailModuleImpl.getTestMode()));

                }
            }
            Map processMap = tiProcessSQL.getProcessForTIRequest(tiRequestId);
            Long procID = (Long) processMap.get("ID");
            String processType = (String) processMap.get("PROCESSTYPE");
            if (TIProcess.CONNECTION.equalsIgnoreCase(processType)) {
                if (firewallFlag == true) {
                    connAppOwnersEmail(procID, tiRequestId, "firewall");
                }
                if (proxyFlag == true) {
                    connAppOwnersEmail(procID, tiRequestId, "proxy");
                }
                if (appSenseFlag == true) {
                    connAppOwnersEmail(procID, tiRequestId, "appSense");
                }
            } else if (TIProcess.IPREGISTRATION.equalsIgnoreCase(processType)) {
                ipRegAppOwnersEmail(procID);
            }
        } catch (Exception e) {
            throw e;
        }
        log.debug("ManageTIProcessImpl.sendEmailToAppOwners::ends");

    }


    /**
     * Ip reg app owners email.
     * 
     * @param tiProcessID
     *            the ti process id
     * @throws Exception
     *             the exception
     */

    public void ipRegAppOwnersEmail(Long tiProcessID) throws Exception {
        String sendEmail = SENDEMAIL_TO_CSIAPPOWNER;
        try {
            if (tiProcessID != null) {
                StringBuilder sql = new StringBuilder(
                        " select tp.PROCESS_NAME,bu.BUSINESS_NAME ,role.name ,citi.FIRST_NAME,citi.LAST_NAME,citi.EMAIL,app.APPLICATION_ID,app.APPLICATION_NAME,app.APP_OWNER_EMAIL,iprd.SOURCE_START_IP,iprd.DESTINATION_IP,iprd.DESTINATION_END_IP,iprd.SOURCE_ACL ,ipport.START_PORT,ipport.END_PORT,iprd.id,ipport.id ,usr.FIRST_NAME,usr.last_name,app.app_mgr_email ");
                sql.append(" from ti_process tp,business_unit bu,ent_inst ei,ent_data ed,ti_application app,ip_registration ipr,ip_reg_detail iprd,IPREGDETAIL_APPLICATION_XREF ipax,IPREGDESTINATIONPORTS ipport,c3par_process_role_xref cprx,citi_contact citi,role,c3par.ti_request tireq,c3par.c3par_users usr ");
                sql.append(" where tp.ID = " + tiProcessID);
                sql.append(" and tp.ID=ipr.PROCESS_ID and ipr.ID=iprd.IP_REGISTRATION_ID and iprd.ID=ipax.IP_REG_DETAIL_ID and ipax.APPLICATION_ID=app.id  and app.IS_CSI='Y' and app.IS_DEVICE='N'and iprd.ID=ipport.IP_REGDETAIL_ID and tp.ENTITLEMENT_INSTANCE_ID=ei.ID and ei.ID=ed.ENTITLEMENT_INSTANCE_ID");
                sql.append(" and ed.ENTITLEMENT_NODE_ID=(select id from ent_node where ent_node.ENTITY_NAME='BusinessUnit') and ed.DATA=bu.id and tp.id=cprx.PROCESS_ID and cprx.ROLE_ID=ROLE.ID and cprx.IS_ACTIVE='Y' and cprx.CITI_CONTACT_ID=citi.ID and tireq.PROCESS_ID=tp.id and tireq.USER_ID=usr.ID order by application_name ");
                Set<String> emailAddr = new HashSet<String>();
                Set<String> contacts = new HashSet<String>();
                String processName = null;
                String buName = null;
                Map appMap = new HashMap();

                SqlRowSet rs = jdbcTemplate.queryForRowSet(sql.toString());
                String projectCoordinator = null;
                while (rs.next()) {
                    processName = rs.getString(1);
                    buName = rs.getString(2);
                    contacts.add(rs.getString(3) + "~" + rs.getString(4) + "~" + rs.getString(5));
                    if (rs.getString(6) != null)
                        emailAddr.add(rs.getString(6));
                    String appID = rs.getString(7);
                    String appName = rs.getString(8);
                    String appIDName = appID + "~" + appName;
                    if (rs.getString(9) != null)
                        emailAddr.add(rs.getString(9));
                    String srcIP = rs.getString(10);
                    String dstIP = rs.getString(11);
                    String dstEndIP = rs.getString(12);

                    String acl = rs.getString(13);
                    String startPort = rs.getString(14);
                    String endPort = rs.getString(15);
                    Long ipDetID = Long.valueOf(rs.getLong(16));
                    Long portID = Long.valueOf(rs.getLong(17));
                    projectCoordinator = rs.getString(18) + rs.getString(19);

                    if (rs.getString(20) != null)
                        emailAddr.add(rs.getString(20));

                    // Application map(key is appliactionid and application
                    // name) has map of ips(srcip,destip,dstendip is the key)
                    // and each ip will have list of ipdetail objects
                    if (appMap != null && appMap.containsKey(appIDName)) {
                        Map ipMap = (Map) appMap.get(appIDName);
                        if (ipMap != null && ipMap.containsKey(ipDetID)) {
                            IPDetail ipDetail = (IPDetail) ipMap.get(ipDetID);
                            if (!chkPortDetailExists(ipDetail, portID))
                                addPortDetails(ipDetail, startPort, endPort, portID);
                        } else {
                            IPDetail ipDetail = new IPDetail();
                            ipMap.put(ipDetID, ipDetail);
                            addIPDetails(ipDetail, srcIP, dstIP, dstEndIP, acl, startPort, endPort, ipDetID, portID);
                        }
                    } else {
                        Map ipMap = new HashMap();
                        IPDetail ipDetail = new IPDetail();
                        ipMap.put(ipDetID, ipDetail);
                        appMap.put(appIDName, ipMap);
                        addIPDetails(ipDetail, srcIP, dstIP, dstEndIP, acl, startPort, endPort, ipDetID, portID);

                    }
                }
                SimpleMailMessage msg = new SimpleMailMessage(this.templateMessage);
                if (appMap != null && appMap.size() > 0 && emailAddr != null && emailAddr.size() > 0) {

                    String biso = null;
                    String[] emailAddress = (String[]) emailAddr.toArray(new String[emailAddr.size()]);
                    for (int j = 0; j < emailAddress.length; j++)
                        log.debug(" email Address " + j + emailAddress[j]);
                    if (contacts != null && contacts.size() > 0) {
                        String[] conts = (String[]) contacts.toArray(new String[contacts.size()]);
                        for (String contact : conts) {
                            String splitContact[] = contact.split("~");
                            if ((splitContact[0]) != null) {
                                if (splitContact[0].equalsIgnoreCase("BISO"))
                                    biso = splitContact[1] + splitContact[2];
                            }
                        }
                    }
                    boolean msgExists = false;
                    StringBuilder msgTxt = new StringBuilder();
                    msg.setSubject("Approval Requested: IP Registration Request: " + tiProcessID + " - " + processName);
                    msg.setSentDate(new Date());
                    msg.setTo(emailAddress);

                    msgTxt.append("Hello Application Manager or Business Owner \n");
                    msgTxt.append("\n");
                    msgTxt.append("This email NOTIFICATION, which satisfies an Audit Requirement, is to alert you that a request to access an application for which you are listed as Application Manager or Business Owner has been submitted via Citi Connectivity Registry (CCR).  The specifics of the requests are below.  The access requested in this case is via an IP Registration. \n\n");
                    msgTxt.append("You need to be aware that this access might include non-Citi personnel (3rd parties) accessing your application from a Non-Citi location, HOWEVER, NO SPECIFIC ACTION IS REQUIRED ON YOUR PART. \n \n");
                    msgTxt.append("If you need additional details about this request, please contact the CCR Service Desk via e-mail at *IS GLOBAL CCR.\n \n");
                    msgTxt.append("IF YOU FEEL YOU HAVE RECEIVED THIS NOTIFICATION IN ERROR, please have the CSI entry for the application listed below updated.  THE CCR SERVICE DESK CANNOT ASSIST YOU WITH THIS TASK.  Each time a request to access this application is processed the record in CSI will be checked.  As long as you are listed as Application Manager or Business Owner in CSI you will continue to get these alerts. \n\nThe details of the request are listed below: \n");
                    msgTxt.append("\n");
                    msgTxt.append("IP Registration Request Name: " + processName);
                    msgTxt.append("\n");
                    msgTxt.append("IP Registration Request ID: " + tiProcessID);
                    msgTxt.append("\n");
                    msgTxt.append("Requesting Business Unit: " + buName);
                    msgTxt.append("\n");
                    msgTxt.append("Project Coordinator: " + projectCoordinator);
                    msgTxt.append("\n");
                    msgTxt.append("Biso: " + biso);
                    msgTxt.append("\n");

                    Set appKeys = appMap.keySet();
                    if (appKeys != null && appKeys.size() > 0) {
                        Iterator appKeyItr = appKeys.iterator();
                        while (appKeyItr.hasNext()) {
                            String appKey = (String) appKeyItr.next();
                            String[] appKeySplit = appKey.split("~");
                            String appID = null;
                            String appName = null;
                            if (appKeySplit != null) {
                                for (int i = 0; i < appKeySplit.length; i++) {
                                    if (i == 0)
                                        appID = appKeySplit[0];
                                    else
                                        appName = appKeySplit[i];
                                }
                            }
                            msgTxt.append("\nApplication Name: " + appName + "\n");
                            msgTxt.append("CSI ID: " + appID + "\n");
                            HashMap ipMap = (HashMap) appMap.get(appKey);
                            if (ipMap != null && ipMap.size() > 0) {
                                msgExists = true;
                                Set ipKeySet = ipMap.keySet();
                                Iterator ipKeyItr = ipKeySet.iterator();
                                while (ipKeyItr.hasNext()) {
                                    Long ipDetailID = (Long) ipKeyItr.next();
                                    IPDetail ipDetail = (IPDetail) ipMap.get(ipDetailID);
                                    msgTxt.append("Destination  IP: "
                                            + ipDetail.getDestinationIP()
                                            + (ipDetail.getDestinationEndIP() == null ? "" : " - "
                                                    + ipDetail.getDestinationEndIP()) + "\n");
                                    List dstPorts = ipDetail.getIPDestinationPorts();
                                    if (dstPorts != null && dstPorts.size() > 0) {
                                        Iterator dstPortItr = dstPorts.iterator();
                                        int count = 1;
                                        StringBuilder portString = new StringBuilder();
                                        while (dstPortItr.hasNext()) {
                                            IPDestinationPorts port = (IPDestinationPorts) dstPortItr.next();
                                            if (port.getStartPort() != null) {
                                                portString.append(port.getStartPort()
                                                        + (port.getEndPort() == null ? "" : "-" + port.getEndPort()));
                                                if (count < dstPorts.size() - 1)
                                                    portString.append(",");
                                                count++;
                                            }
                                        }
                                        msgTxt.append("Port: " + portString.toString() + "\n");
                                    }
                                    msgTxt.append("Acl: " + ipDetail.getAcl() + "\n");
                                }
                            }
                        }
                    }
                    msgTxt.append(" \nIf you accept this request, please take no action. " + "\n");
                    msgTxt.append("\n");
                    msgTxt.append("Thank you, \n");
                    msgTxt.append("CCR");
                    msg.setText(msgTxt.toString());
                    if (sendEmail != null && sendEmail.equalsIgnoreCase("FALSE"))
                        msg.setTo(ISA_REGISTRY_EMAIL);
                    if (msg != null) {
                        if (msg.getTo() != null) {
                            log.debug("MESSAGE TO " + msg.getTo().toString());
                        }
                        log.debug("MESSAGE SUBJECT " + msg.getSubject() + " MESSAGE TXT " + msg.getText());
                    }

                    if (msgExists) {
                        try {
                            log.debug("sending email to appowners and app managers for process id " + tiProcessID);
                            this.mailSender.send(msg);
                        } catch (MailException ex) {
                            log.error(ex.toString(), ex);
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }
    }

    /**
     * Adds the port details.
     * 
     * @param ipDetail
     *            the ip detail
     * @param startPort
     *            the start port
     * @param endPort
     *            the end port
     * @param portID
     *            the port id
     */
    void addPortDetails(IPDetail ipDetail, String startPort, String endPort, Long portID) {

        IPDestinationPorts ipDestPort = new IPDestinationPorts();
        ipDestPort.setId(portID);
        ipDestPort.setStartPort(startPort);
        ipDestPort.setEndPort(endPort);
        ipDetail.getIPDestinationPorts().add(ipDestPort);
    }

    /**
     * Adds the ip details.
     * 
     * @param ipDetail
     *            the ip detail
     * @param srcIP
     *            the src ip
     * @param dstIP
     *            the dst ip
     * @param dstEndIP
     *            the dst end ip
     * @param acl
     *            the acl
     * @param startPort
     *            the start port
     * @param endPort
     *            the end port
     * @param ipDetID
     *            the ip det id
     * @param portID
     *            the port id
     */
    void addIPDetails(IPDetail ipDetail, String srcIP, String dstIP, String dstEndIP, String acl, String startPort,
            String endPort, Long ipDetID, Long portID) {

        ipDetail.setId(ipDetID);
        ipDetail.setSourceStartIP(srcIP);
        ipDetail.setDestinationIP(dstIP);
        ipDetail.setDestinationEndIP(dstEndIP);
        /*
         * Application app=new Application(); app.setApplicationID(appID);
         * app.setApplicationID(appID);
         */
        ipDetail.setAcl(acl);
        IPDestinationPorts ipPort = new IPDestinationPorts();
        ipPort.setId(portID);
        ipPort.setStartPort(startPort);
        ipPort.setEndPort(endPort);
        ipDetail.getIPDestinationPorts().add(ipPort);
    }

    /**
     * Conn app owners email.
     * 
     * @param connID
     *            the conn id
     * @param implementors
     *            the implementors
     * @throws Exception
     *             the exception
     */

    public void connAppOwnersEmail(Long connID, Long tiRequestId, String implementors) throws Exception {
        log.debug("connID : " + connID + " implementors : " + implementors);
        StringBuilder sql = null;
        String sendEmail = SENDEMAIL_TO_CSIAPPOWNER;
        String change_Text = "";

        TargetContactEmail mailList = new TargetContactEmail();
        try {
            if (connID != null) {

                String distEmailSQL = "select value2 from c3par.generic_lookup where value1='";
                String opsDistEmailSQL = "";
                if (implementors.equalsIgnoreCase("firewall")) {
                    change_Text = "a Firewall Change.";
                    sql = firewallQuery(connID);
                    opsDistEmailSQL = distEmailSQL + "OPS Email Distribution'";
                }
                if (implementors.equalsIgnoreCase("appSense")) {
                    change_Text = "The Third Party Architecture (TPA).";
                    sql = appSenseQuery(connID);
                    opsDistEmailSQL = distEmailSQL + "AppSense Email Distribution'";
                }
                if (implementors.equalsIgnoreCase("proxy")) {
                    change_Text = "a Proxy Change.";
                    sql = proxyQuery(connID);
                    opsDistEmailSQL = distEmailSQL + "Proxy Email Distribution'";
                }
                String opsDistEmail = null;

                Set<String> emailAddr = new HashSet<String>();
                // emailAddr.add("dl.CITS.C3par.Development@imcnam.ssmb.com");
                String connectionName = null;
                String firstName = null;
                String lastName = null;
                String ssoID = null;
                String bu = null;
                String reg = null;
                String sec = null;
                // StringBuilder appInfo = new StringBuilder();
                TargetContactEmail.AppInfo apInfo = null;
                Set<TargetContactEmail.AppInfo> appInfoSet = new HashSet<TargetContactEmail.AppInfo>();
                SqlRowSet rs = jdbcTemplate.queryForRowSet(opsDistEmailSQL);
                while (rs.next()) {
                    opsDistEmail = rs.getString(1);
                }

                rs = jdbcTemplate.queryForRowSet(sql.toString());
                while (rs.next()) {
                    connectionName = rs.getString(1);
                    firstName = rs.getString(2);
                    lastName = rs.getString(3);
                    ssoID = rs.getString(4);
                    reg = rs.getString(5);
                    sec = rs.getString(6);
                    bu = rs.getString(7);
                    StringBuilder appInfo = new StringBuilder();
                    apInfo = new TargetContactEmail.AppInfo();
                    appInfo.append(rs.getString(8));
                    appInfo.append(" - " + rs.getString(9));
                    appInfo.append(" - " + rs.getString(10));
                    if (rs.getString(11) != null)
                        emailAddr.add(rs.getString(11));
                    appInfo.append(" - " + rs.getString(12));

                    if (rs.getString(13) != null)
                        emailAddr.add(rs.getString(13));
                    appInfo.append(" - " + rs.getString(14));
                    apInfo.setType(appInfo.toString());
                    appInfoSet.add(apInfo);
                    log.debug("msg : " + appInfoSet.toString());
                }

                SimpleMailMessage msg = new SimpleMailMessage(this.templateMessage);
                if (emailAddr != null && emailAddr.size() > 0) {
                    StringBuilder emailAddList = new StringBuilder();
                    for (String emailAdd : emailAddr) {
                        emailAddList.append(emailAdd + ";");
                    }
                    mailList.setCcr_id(connID);
                    mailList.setTiRequestID(tiRequestId);
                    mailList.setCmpRequestId(ccrCMPMappingService.getCmpIdForTiRequestId(tiRequestId));
                    mailList.setConnName(connectionName);
                    mailList.setRegion(reg);
                    mailList.setSector(sec);
                    mailList.setBusUnit(bu);
                    mailList.setProjectCoor(firstName + " " + lastName + "(" + ssoID + ")");
                    mailList.setDistributionList(opsDistEmail);
                    mailList.setChange_Text(change_Text);
                    mailList.setToAddresses(emailAddList.toString());
                    mailList.setAppInfo(appInfoSet.toArray(new TargetContactEmail.AppInfo[appInfoSet.size()]));
                    log.debug("TargtContactEmail added : " + mailList);

                    if (sendEmail != null && sendEmail.equalsIgnoreCase("FALSE")) {
                        msg.setTo(ISA_REGISTRY_EMAIL);
                    }
                    try {
                        log.debug("sending email to appowners and mangers for process id " + connID);
                        mailModuleImpl.sendApplicationOwnerMail(mailList);
                    } catch (MailException ex) {
                        log.error(ex.toString(), ex);
                    }
                }
            }
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }
    }

    /**
     * Proxy query.
     * 
     * @param connID
     *            the conn id
     * @return the string buffer
     */
    private StringBuilder proxyQuery(final Long connID) {
        StringBuilder sql = new StringBuilder();

        sql.append("SELECT DISTINCT CON.CONNECTION_NAME, ");
        sql.append(" USR.FIRST_NAME,  ");
        sql.append(" USR.LAST_NAME,  ");
        sql.append(" CON.REQUESTER_ID,  ");
        sql.append(" REG.NAME,  ");
        sql.append(" SEC.NAME,  ");
        sql.append(" BU.BUSINESS_NAME,  ");
        sql.append(" APP.APPLICATION_ID,  ");
        sql.append(" APP.APPLICATION_NAME,  ");
        sql.append(" APP.APP_OWNER_FULL_NAME,  ");
        sql.append(" APP.APP_OWNER_EMAIL,  ");
        sql.append(" APP.APP_MGR_FULL_NAME,  ");
        sql.append(" APP.APP_MGR_EMAIL,  ");
        sql.append(" CASE WHEN COMB_TYPE_ID=1 THEN 'ADD' ELSE 'DELETE' END ");
        sql.append(" FROM C3PAR.CON_REQ CON,  ");
        sql.append(" C3PAR.RELATIONSHIP REL,  ");
        sql.append("C3PAR.REL_CITI_HIERARCHY_XREF RELXREF, ");
        sql.append("C3PAR.CITI_HIERARCHY_MASTER CITIMASTER, ");
        sql.append(" C3PAR.TI_APPLICATION APP,  ");
        sql.append(" C3PAR.REGION REG,  ");
        sql.append(" C3PAR.SECTOR SEC,  ");
        sql.append(" C3PAR.BUSINESS_UNIT BU,  ");
        sql.append(" C3PAR.C3PAR_USERS USR,  ");
        sql.append(" C3PAR.PRX_PROXY_FILTER PRX, ");
        sql.append(" PRX_PAF_HISTORY PPH  ");
        sql.append(" WHERE CON.RELATIONSHIP_ID = REL.ID  ");
        sql.append("AND RELXREF.RELATIONSHIP_ID = REL.ID ");
        sql.append("AND CITIMASTER.ID = RELXREF.CITI_HIERARCHY_MASTER_ID ");
        sql.append("AND CITIMASTER.REGION_ID = REG.ID  ");
        sql.append("AND CITIMASTER.SECTOR_ID = SEC.ID ");
        sql.append("AND CITIMASTER.BU_ID = BU.ID ");
        sql.append(" AND CON.ID = PRX.PROCESS_ID  ");
        sql.append(" AND APP.IS_CSI = 'Y'  ");
        sql.append(" AND APP.IS_DEVICE = 'N'  ");
        sql.append(" AND CON.REQUESTER_ID = USR.SSO_ID  ");
        sql.append(" AND PPH.PROCESS_ID = " + connID);
        sql.append(" AND PPH.PROCESS_ID = PRX.PROCESS_ID  ");
        sql.append(" AND PPH.TI_REQUEST_ID = PRX.TI_REQUEST_ID  ");
        sql.append(" AND PPH.APP_ID = APP.ID ");
        return sql;
    }

    /**
     * App sense query.
     * 
     * @param connID
     *            the conn id
     * @return the string buffer
     */
    private StringBuilder appSenseQuery(final Long connID) {
        StringBuilder sql = new StringBuilder();

        sql.append("SELECT DISTINCT con.CONNECTION_NAME,  ");
        sql.append("usr.FIRST_NAME, ");
        sql.append("usr.LAST_NAME, ");
        sql.append("con.REQUESTER_ID, ");
        sql.append("reg.NAME, ");
        sql.append("sec.NAME, ");
        sql.append("bu.BUSINESS_NAME, ");
        sql.append("app.APPLICATION_ID, ");
        sql.append("app.APPLICATION_NAME, ");
        sql.append("app.APP_OWNER_FULL_NAME, ");
        sql.append("app.APP_OWNER_EMAIL, ");
        sql.append("app.APP_MGR_FULL_NAME, ");
        sql.append("app.APP_MGR_EMAIL, ");
        sql.append("case when comb_type_id=1 then 'ADD' else 'DELETE' end  ");
        sql.append("FROM c3par.con_req con, ");
        sql.append("c3par.relationship rel, ");
        sql.append("c3par.REL_CITI_HIERARCHY_XREF relXref,");
        sql.append("c3par.CITI_HIERARCHY_MASTER CITIMASTER,");
        sql.append("c3par.ti_application app,");
        sql.append("c3par.region reg, ");
        sql.append("c3par.sector sec, ");
        sql.append("c3par.business_unit bu, ");
        sql.append("C3PAR.C3PAR_USERS usr, ");
        sql.append("c3par.aps_appsense_policy aps, ");
        sql.append("aps_impl_history aih  ");
        sql.append("WHERE con.relationship_id = rel.id  ");
        sql.append("and RELXREF.RELATIONSHIP_ID = rel.id ");
        sql.append("and CITIMASTER.ID = relXref.CITI_HIERARCHY_MASTER_ID ");
        sql.append("and CITIMASTER.REGION_ID = reg.id  ");
        sql.append("and CITIMASTER.SECTOR_ID = sec.id ");
        sql.append("and CITIMASTER.BU_ID = bu.id ");
        sql.append("AND con.ID = aps.process_id  ");
        sql.append("AND app.IS_CSI = 'Y'  ");
        sql.append("AND app.IS_DEVICE = 'N'  ");
        sql.append("AND CON.REQUESTER_ID = usr.SSO_ID  ");
        sql.append("AND aih.process_id = " + connID);
        sql.append(" AND aih.process_id = aps.process_id  ");
        sql.append("AND aih.ti_request_id = aps.ti_request_id  ");
        sql.append("AND aih.application_id = app.id ");

        return sql;
    }

    /**
     * Firewall query.
     * 
     * @param connID
     *            the conn id
     * @return the string buffer
     */
    private StringBuilder firewallQuery(final Long connID) {

        StringBuilder sql = new StringBuilder();
        sql.append("SELECT DISTINCT CON.CONNECTION_NAME, ");
        sql.append("USR.FIRST_NAME, ");
        sql.append("USR.LAST_NAME,");
        sql.append("CON.REQUESTER_ID,");
        sql.append("REG.NAME,");
        sql.append("SEC.NAME,");
        sql.append("BU.BUSINESS_NAME,");
        sql.append("APP.APPLICATION_ID,");
        sql.append("APP.APPLICATION_NAME,");
        sql.append("APP.APP_OWNER_FULL_NAME,");
        sql.append("APP.APP_OWNER_EMAIL,");
        sql.append("APP.APP_MGR_FULL_NAME,");
        sql.append("APP.APP_MGR_EMAIL,");
        sql.append("CASE WHEN CFRA.DELETED_TI_REQUEST_ID IS NOT NULL THEN 'DELETE' ELSE 'ADD' END ");
        sql.append("FROM C3PAR.CON_REQ CON,");
        sql.append("C3PAR.RELATIONSHIP REL,");
        sql.append("C3PAR.REL_CITI_HIERARCHY_XREF RELXREF,");
        sql.append("C3PAR.CITI_HIERARCHY_MASTER CITIMASTER,");
        sql.append("C3PAR.TI_APPLICATION APP,");
        sql.append("C3PAR.REGION REG,");
        sql.append("C3PAR.SECTOR SEC,");
        sql.append("C3PAR.BUSINESS_UNIT BU,");
        sql.append("C3PAR.C3PAR_USERS USR,");
        sql.append("C3PAR.CON_FW_RULE CFR, CON_FW_RULE_APPLICATION CFRA ");
        sql.append("WHERE CON.RELATIONSHIP_ID = REL.ID ");
        sql.append("AND RELXREF.RELATIONSHIP_ID = REL.ID ");
        sql.append("AND CITIMASTER.ID = RELXREF.CITI_HIERARCHY_MASTER_ID ");
        sql.append("AND CITIMASTER.REGION_ID = REG.ID ");
        sql.append("AND CITIMASTER.SECTOR_ID = SEC.ID ");
        sql.append("AND CITIMASTER.BU_ID = BU.ID ");
        sql.append("AND CON.ID = " + connID);
        sql.append(" AND CFRA.APPLICATION_ID = APP.ID ");
        sql.append("AND APP.IS_CSI = 'Y' ");
        sql.append("AND CON.REQUESTER_ID = USR.SSO_ID ");
        sql.append("AND CFR.ID = CFRA.RULE_ID ");
        sql.append("AND (CFR.UPDATED_TI_REQUEST_ID IN (SELECT MAX(ID) FROM TI_REQUEST WHERE PROCESS_ID=" + connID
                + ") ");
        sql.append(" OR CFR.DELETED_TI_REQUEST_ID IN (SELECT MAX(ID) FROM TI_REQUEST WHERE PROCESS_ID=" + connID
                + ")) ");
        return sql;
    }

    /**
     * Chk port detail exists.
     * 
     * @param ipDetail
     *            the ip detail
     * @param currPortID
     *            the curr port id
     * @return true, if successful
     */
    private boolean chkPortDetailExists(IPDetail ipDetail, Long currPortID) {
        boolean exists = false;
        List dstPort = ipDetail.getIPDestinationPorts();
        if (dstPort != null && dstPort.size() > 0) {
            Iterator portItr = dstPort.iterator();
            while (portItr.hasNext()) {
                IPDestinationPorts port = (IPDestinationPorts) portItr.next();
                if (port != null && !chkIsZero(port.getId()) && !chkIsZero(currPortID)
                        && port.getId().equals(currPortID)) {
                    exists = true;
                    break;
                }
            }
        }
        return exists;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#getProcessDTO
     * (long, java.lang.String, java.lang.String)
     */
    public TIProcessDTO getProcessDTO(long requestID, String activityCode, String prInfoRequestedActivityCode)
            throws Exception {
        return manageTIProcessUtil.getProcessDTO(requestID, activityCode, prInfoRequestedActivityCode);
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#getProcessDTO
     * (long)
     */
    public TIProcessDTO getProcessDTO(long requestID) throws Exception {
        return getProcessDTO(requestID, null, null);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * isMADBusinessUnit(long)
     */
    public boolean isMADBusinessUnit(long tiRequestId) throws Exception {
        boolean isMAD = false;
        try {
            StringBuilder buSQL = new StringBuilder();
            buSQL.append("SELECT bu.id ");
            buSQL.append("FROM c3par.ti_process tip , ");
            buSQL.append("c3par.relationship rel, ");
            buSQL.append("REL_CITI_HIERARCHY_XREF rxref, ");
            buSQL.append("CITI_HIERARCHY_MASTER cm, ");
            buSQL.append("c3par.business_unit bu ");
            buSQL.append("WHERE tip.RELATIONSHIP_ID=rel.id ");
            buSQL.append("and rxref.RELATIONSHIP_ID = rel.id ");
            buSQL.append("and rxref.CITI_HIERARCHY_MASTER_ID = cm.ID ");
            buSQL.append("and cm.BU_ID = bu.ID ");
            buSQL.append("AND tip.id               =  ");
            buSQL.append("(SELECT process_id FROM c3par.ti_request WHERE id=? ");
            buSQL.append(" ) ");
            buSQL.append("AND trim(upper(bu.business_name))= ?  ");

            SqlRowSet rowSet = jdbcTemplate.queryForRowSet(buSQL.toString(), new Object[] { tiRequestId, "MA&D" });
            while (rowSet.next()) {
                // log.debug(rs.getString(1));
                isMAD = true;
            }
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }
        log.info("tiRequestId:"+tiRequestId+"isMADFlag:"+isMAD);
        return isMAD;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#isBulkRequest
     * (long)
     */
    public boolean isBulkRequest(long tiRequestId) throws Exception {
        log.debug("Entering with tiRequestId : " + tiRequestId);
        boolean isBulkRequest = false;
        try {
            StringBuilder bulkUploadSQL = new StringBuilder(
                    " select a.id  from c3par.con_req a,c3par.planning b,c3par.ti_request_planning_xref");
            bulkUploadSQL
                    .append(" trpx where a.id=b.id and a.ID=trpx.PLANNING_ID and trpx.TI_REQUEST_ID=? and a.BULK_REQUEST='Y' ");
            SqlRowSet rowSet = jdbcTemplate.queryForRowSet(bulkUploadSQL.toString(), new Object[] { tiRequestId });
            while (rowSet.next()) {
                isBulkRequest = true;
            }
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }
        return isBulkRequest;

    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * getSupplementReviewRoles(long)
     */
    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * getSupplementReviewRoles(long)
     */

    public String getSupplementReviewRoles(long tiRequestId) throws Exception {
        log.debug("Entering  getSupplementReviewRoles for tiRequestId " + tiRequestId);
        StringBuilder suppReviewRoles = new StringBuilder();
        try {
            StringBuilder suppReviewSQL = new StringBuilder(
                    " select rl.NAME from c3par.TI_REQ_SUPPLEMENT_REVIEW sr ,c3par.role rl ");
            suppReviewSQL.append(" where sr.REVIEWER_ROLE=rl.ID and ti_request_id=?");

            SqlRowSet rowSet = jdbcTemplate.queryForRowSet(suppReviewSQL.toString(), new Object[] { tiRequestId });
            while (rowSet.next()) {
                suppReviewRoles.append("~" + rowSet.getString(1));
            }
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }
        log.debug("Exiting   getSupplementReviewRoles  with suppReviewRoles " + suppReviewRoles.toString());
        return suppReviewRoles.toString();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * isDeferredReview(long)
     */

    public boolean isDeferredReview(long tiRequestId) throws Exception {
        log.debug("isDeferredReview Method Starts::tiRequestId : " + tiRequestId);
        try {
            StringBuilder defferedReviewSQL = new StringBuilder(
                    " select id  from c3par.ti_activity_trail  where ti_request_id =? and id in (select max(id) from c3par.ti_activity_trail where activity_id in (");
            defferedReviewSQL.append(" select id from c3par.ti_task_type  where task_code in (?,?,?)) ");
            defferedReviewSQL.append(" and ti_request_id=? group by  ti_request_id,activity_id) and activity_status=?");
            SqlRowSet rowSet = jdbcTemplate.queryForRowSet(defferedReviewSQL.toString(), new Object[] { tiRequestId,
                    ActivityDataDTO.Activity_MAD_APP, ActivityDataDTO.Activity_OTRM_APP,
                    ActivityDataDTO.ACTIVITY_TPW_APP, tiRequestId, ActivityDataDTO.STATUS_DEFERRED });
            while (rowSet.next()) {
                return true;
            }
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }
        return false;

    }
    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * abortTechArchData(long, long)
     */
    public void abortTechArchData(long processId, long tiRequestId) throws Exception {
        log.info("abortTechArchData for tiRequestId-" + tiRequestId + "Connection Id for checking isTemplateAborted:-"
                + processId + " databaseUtil object:-" + databaseUtil);
        TechnicalArchitectureUtil taUtil = new TechnicalArchitectureUtil();
        taUtil.abortTechArchData(Long.valueOf(processId), Long.valueOf(tiRequestId));

        if (databaseUtil != null) {
            boolean isTemplateAborted = databaseUtil.isTemplateAborted(processId);

            log.info("isTemplateAborted status for checking isTemplateAborted:-" + isTemplateAborted);

            if (isTemplateAborted) {
                log.info("checking isTemplateAborted started:-" + new Date());
                databaseUtil.revertTemplateRulesToImplementedVersion(processId);
                log.info("checking isTemplateAborted Completed:-" + new Date());
            }
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * copyTechArchData(long, long)
     */
    public String copyTechArchData(long processId, long tiRequestId) throws Exception {
        log.info("copyTechArchData :: for tiRequestId-" + tiRequestId);
        String result = null;
        TechnicalArchitectureUtil taUtil = new TechnicalArchitectureUtil();
        result = taUtil.copyTAMaintenanceData(Long.valueOf(processId), Long.valueOf(tiRequestId),
                TIProcessService.TIReqType_Maintain);
        log.info("Result of copyTAMaintainnenceData is::" + result + ":: for tiRequestId-" + tiRequestId);

        return result;
    }

    /**
     * @param processId
     * @param tiRequestId
     * @param requestType
     * @return
     * @throws Exception
     */
    public String copyTechArchData(long processId, long tiRequestId, String requestType) throws Exception {
        String result = null;
        TechnicalArchitectureUtil taUtil = new TechnicalArchitectureUtil();
        result = taUtil.copyTAMaintenanceData(Long.valueOf(processId), Long.valueOf(tiRequestId), requestType);
        log.info("Result of copyTAMaintainnenceData is::" + result + ":: for tiRequestId-" + tiRequestId);

        return result;
    }

    /**
     * @param processId
     * @param tiRequestId
     * @return
     * @throws Exception
     */
    public String copyUploadedDocuments(long processId, long tiRequestId) throws Exception {
        log.info("ManageTIProcessImpl.copyUploadedDocuments :: Starts for  for tiRequestId -" + tiRequestId);
        String result = null;
        TechnicalArchitectureUtil taUtil = new TechnicalArchitectureUtil();
        result = taUtil.copyUploadedDocuments(Long.valueOf(processId), Long.valueOf(tiRequestId));
        log.info("Result of copyUploadedDocuments is::" + result + ":: for tiRequestId-" + tiRequestId);
        return result;
    }

    /**
     * Copy rfc data.
     * 
     * @param processId
     *            the process id
     * @param tiRequestId
     *            the ti request id
     * @throws Exception
     *             the exception
     */
    public void copyRFCData(long processId, long tiRequestId) throws Exception {
        String result = null;
        try {

            SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("COPY_AFFECTEDBUSINESS");

            Map<String, Object> inParamMap = new HashMap<String, Object>();
            inParamMap.put("processId", processId);
            inParamMap.put("tiRequestId", tiRequestId);

            SqlParameterSource in = new MapSqlParameterSource(inParamMap);

            Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
            if (simpleJdbcCallResult.get("status") != null) {
                result = (String) simpleJdbcCallResult.get("status");
            }

            log.info("Result of copyRFCData is::" + result + ":: for tiRequestId-" + tiRequestId);
        } catch (Exception ex) {
            log.error(ex.toString(), ex);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * getAnnualVerificationFlagValue(long)
     */
    public String getAnnualVerificationFlagValue(long tiRequestId) throws Exception {
        log.debug(" getAnnualVerificationFlagValue Method Starts:TiRequestId: " + tiRequestId);
        String annualVerificationFlag = "";
        String sql = " select ANNUAL_VERIFICATION_FLAG from ti_request where id = ?";
        List ids = new ArrayList();
        try {
            SqlRowSet rowSet = jdbcTemplate.queryForRowSet(sql, new Object[] { tiRequestId });
            while (rowSet.next()) {
                annualVerificationFlag = rowSet.getString(1);
                log.debug("For Ti_RequestId= " + tiRequestId + " == annualVerificationFlag::" + annualVerificationFlag);
            }
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }
        return annualVerificationFlag;

    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * verifySOWUpdate(long, java.lang.String, java.lang.String)
     */
    public boolean verifySOWUpdate(long tiRequestId, String verificationFlag, String SOW) throws Exception {
        log.info("verifySOWUpdate Method Starts::tiRequestId=" + tiRequestId + "::verificationFlag=" + verificationFlag
                + "::SOW" + SOW);
        int rowsUpdated = 0;
        try {
            String schSQL = "";
            schSQL = new String("update c3par.ti_request set " + "ANNUAL_VERIFICATION_FLAG =?, " + "SOW_NUMBER  =? "
                    + "where id = ?");
            rowsUpdated = jdbcTemplate.update(schSQL, new Object[] { verificationFlag, SOW, tiRequestId });
       
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#createACV
     * (com.citigroup.cgti.c3par.bpm.ejb.domain.TIProcessDTO)
     */
    public long createACV(TIProcessDTO processDTO) throws Exception {
        TIProcess tiProcess = new TIProcess();
        tiProcess.setId(processDTO.getId());

        // tiProcess.getRequestor().setSoeID(processDTO.getRequestorSOEId());
        StringBuilder errMsg = new StringBuilder();
        if (tiProcess != null && chkIsZero(tiProcess.getId()))
            errMsg.append(" Searched Process Id is - " + tiProcess.getId() + ".Please Enter a valid Id ");
        /*
         * if(!isString(tiProcess.getRequestor().getSoeID()))
         * errMsg.append("   Requester ssoid is empty  ");
         */
        if (errMsg.length() > 0) {
            log.error(errMsg.toString());
            throw new Exception("Business Exception : " + errMsg.toString());
        }

        boolean isActive = tiProcessSQL.isProcessActive(tiProcess.getId().longValue());
        if (!isActive) {
            log.error(" Cannot start ACV phase  TIProcess ID " + tiProcess.getId() + " since its not Active ");
            throw new Exception("Business Exception : Cannot start ACV phase  TIProcess ID " + tiProcess.getId()
                    + " since its not Active ");
        }
        // String
        // entName=tiProcessSQL.chkUpdatePreviliges(tiProcess.getRequestor().getSoeID(),
        // tiProcess.getId().longValue());
        String processType = tiProcessSQL.getProcessType(tiProcess.getId().longValue());
        if (processType == null) {
            log.error(" Process Type is undefined for  " + tiProcess.getId());
            throw new Exception(" Process Type is undefined for TIProcess " + tiProcess.getId());
        }
        tiProcess.getBusinessCase().getProcessType().setName(processType);

        if (isActive) {

            try {
                int versionNum = tiProcessSQL.getProcessVersion(tiProcess.getId().longValue());

                if (chkIsZero(Long.valueOf(versionNum)))
                    throw new Exception(" Business Exception : Invalid Version Number for ti Process Id "
                            + tiProcess.getId());

                tiProcess.getTiRequest().setVersionNumber(versionNum + 1);
                tiProcess.getTiRequest().getTiRequestType().setName("ACV");
                tiProcess.getRequestor().setSoeID(TIProcessDTO.SYSTEM_USER);

                tiProcess.getTiRequest().setId(null);
                createRequest(tiProcess);

                long requestId = getCurrentTiRequest(tiProcess.getId().longValue());
                tiProcess.getTiRequest().setId(Long.valueOf(requestId));

                String instSQL = "insert into c3par.ti_request_planning_xref  values (?,(select planning_id from c3par.ti_request_planning_xref where ti_request_id in (select max(id) from c3par.ti_request where process_id=? and ti_request.IS_DELETED !='Y' and ti_request_type_id not in (select id from ti_request_type where request_type in ('ACV','ManageContacts','Temp Approval Expiration')) )))";

               
                int rowsUpdated = jdbcTemplate.update(instSQL, new Object[] {
                        tiProcess.getTiRequest().getId().longValue(), tiProcess.getId().longValue() });
                log.debug(" with  values TIRequestID = " + tiProcess.getTiRequest().getId().longValue()
                        + " and tiProcess " + " =" + tiProcess.getId().longValue() + "::No Of Rows Updated"
                        + rowsUpdated);
              

            } catch (Exception e) {
                log.error(e.toString(), e);
                throw new Exception(e.getMessage());
            }
        }
        return tiProcess.getTiRequest().getId().longValue();
    }
    
    /*
     * (non-Javadoc)
     * 
     * @see
     * com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#createACV
     * (com.citigroup.cgti.c3par.bpm.ejb.domain.TIProcessDTO)
     */
    public long createACV(TIProcessDTO processDTO, String requestType) throws Exception {
        log.debug("requestType :" + requestType);
        TIProcess tiProcess = new TIProcess();
        String tempApprovedBy = null;
        tiProcess.setId(processDTO.getId());

        // tiProcess.getRequestor().setSoeID(processDTO.getRequestorSOEId());
        StringBuilder errMsg = new StringBuilder();
        if (tiProcess != null && chkIsZero(tiProcess.getId()))
            errMsg.append(" Searched Process Id is - " + tiProcess.getId() + ".Please Enter a valid Id ");
        /*
         * if(!isString(tiProcess.getRequestor().getSoeID()))
         * errMsg.append("   Requester ssoid is empty  ");
         */
        if (errMsg.length() > 0) {
            log.error(errMsg.toString());
            throw new Exception("Business Exception : " + errMsg.toString());
        }

        boolean isActive = tiProcessSQL.isProcessActive(tiProcess.getId().longValue());
        if (!isActive) {
            log.error(" Cannot start ACV phase  TIProcess ID " + tiProcess.getId() + " since its not Active ");
            throw new Exception("Business Exception : Cannot start ACV phase  TIProcess ID " + tiProcess.getId()
                    + " since its not Active ");
        }
        // String
        // entName=tiProcessSQL.chkUpdatePreviliges(tiProcess.getRequestor().getSoeID(),
        // tiProcess.getId().longValue());
        String processType = tiProcessSQL.getProcessType(tiProcess.getId().longValue());
        if (processType == null) {
            log.error(" Process Type is undefined for  " + tiProcess.getId());
            throw new Exception(" Process Type is undefined for TIProcess " + tiProcess.getId());
        }
        tiProcess.getBusinessCase().getProcessType().setName(processType);

        if (isActive) {

            try {
                int versionNum = tiProcessSQL.getProcessVersion(tiProcess.getId().longValue());

                if (chkIsZero(Long.valueOf(versionNum)))
                    throw new Exception(" Business Exception : Invalid Version Number for ti Process Id "
                            + tiProcess.getId());

                tiProcess.getTiRequest().setVersionNumber(versionNum + 1);

                if (requestType != null && requestType.equalsIgnoreCase("TEMP_APP")) {
                    tiProcess.getTiRequest().getTiRequestType().setName(TIReqType_Temp_Approval_Expiration);
                    tempApprovedBy = updateTempApprovedByForCcr(tiProcess.getId(), versionNum);
                } else {
                    tiProcess.getTiRequest().getTiRequestType().setName("ACV");
                }
                tiProcess.getRequestor().setSoeID(TIProcessDTO.SYSTEM_USER);

                tiProcess.getTiRequest().setId(null);
                createRequest(tiProcess);

                long requestId = getCurrentTiRequest(tiProcess.getId().longValue());
                tiProcess.getTiRequest().setId(Long.valueOf(requestId));
                if (tempApprovedBy != null) {
                    String updatetempApprovedByQuery = "update TI_REQUEST  set TEMP_APPROVED_BY_ROLE=?  where id=?";
                    jdbcTemplate.update(updatetempApprovedByQuery, new Object[] { tempApprovedBy, requestId });
                }
                String instSQL = "insert into c3par.ti_request_planning_xref  values (?,(select planning_id from c3par.ti_request_planning_xref where ti_request_id in (select max(id) from c3par.ti_request where process_id=? and ti_request.IS_DELETED !='Y' and ti_request_type_id not in (select id from ti_request_type where request_type in ('ACV','ManageContacts','Temp Approval Expiration')) )))";
                jdbcTemplate.update(instSQL, new Object[] { tiProcess.getTiRequest().getId().longValue(),
                        tiProcess.getId().longValue() });

                log.debug(" with  values TIRequestID = " + tiProcess.getTiRequest().getId().longValue()
                        + " and tiProcess " + " =" + tiProcess.getId().longValue());

            } catch (Exception e) {
                log.error(e.toString(), e);
                throw new Exception(e.getMessage());
            }
        }
        return tiProcess.getTiRequest().getId().longValue();
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * extendExpiration(long)
     */

    public boolean extendExpiration(long processId) throws Exception {
        try {
            log.info("extendExpiration Method Starts::processId" + processId);
            String updateSQL = " update c3par.TI_PROCESS set ACTIVATION_EXP_DATE = sysdate+365 where id = ?  ";
            int rowsUpdated = jdbcTemplate.update(updateSQL, new Object[] { processId });
            
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }
        return true;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * extendExpiration(long)
     */

    public boolean extendExpiration(long processId, int extensionValue, String extendedDate) throws Exception {
        String updateSQL = "";
        int rowsUpdated = 0;
        try {
            log.debug("extendExpiration Mehtod Starts::processId : " + processId + ", extensionValue : " + extensionValue + " , extendedDate : "
                    + extendedDate);
            if (extensionValue != 0) {
                updateSQL = " update c3par.TI_PROCESS set ACTIVATION_EXP_DATE = sysdate+? where id = ?  ";
                rowsUpdated = jdbcTemplate.update(updateSQL, new Object[] { extensionValue, processId });
            } else {
                updateSQL = " update c3par.TI_PROCESS set ACTIVATION_EXP_DATE = to_date(?,'mm-dd-yyyy') where id = ?  ";
                rowsUpdated = jdbcTemplate.update(updateSQL, new Object[] { extendedDate, processId });
            }
          
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }
        return true;
    }

    /**
     * Gets the current ti request.
     * 
     * @param tiProcessId
     *            the ti process id
     * @return the current ti request
     * @throws Exception
     *             the exception
     */
    public long getCurrentTiRequest(long tiProcessId) throws Exception {
        log.debug("getCurrentTiRequest Method Starts::ProcessId: " + tiProcessId);
        String sql = "select max(id) from ti_request where  process_id=" + tiProcessId;
        long ids = 0;
        try {
            SqlRowSet rowSet = jdbcTemplate.queryForRowSet(sql);
            while (rowSet.next()) {
                ids = rowSet.getLong(1);
                log.debug("TI Request ID -::" + ids);
            }
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw new Exception(e.toString());
        }
        return ids;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * isManagerApprovalRequired(long)
     */
    public boolean isManagerApprovalRequired(long tiRequestId) throws Exception {
       
        boolean isMgrApproval = false;
        try {
            StringBuilder mgrApprovalSQL = new StringBuilder(
                    "select * from ti_req_supplement_review where ti_request_id=? and reviewer_role = (SELECT ID FROM ROLE WHERE NAME='Manager')");
            SqlRowSet rowSet = jdbcTemplate.queryForRowSet(mgrApprovalSQL.toString(), new Object[] { tiRequestId });
            while (rowSet.next()) {
                // log.info(rs.getString(1));
                isMgrApproval = true;
            }
            // To check the TA was submitted by platform team members, in that
            // case it should go to BMA
            if (!isMgrApproval) {
                String isPlatformTeamMember = "select gl.value2 from ti_activity_trail tat, c3par_users cu, generic_lookup gl "
                        + " where tat.activity_id in (select id from ti_task_type where task_code='tec_arc')"
                        + " and tat.activity_status='COMPLETED' and tat.ti_request_id = ?"
                        + " and gl.definition_id in (select id from generic_lookup_defs where name = 'PLATFORM_TEAM')"
                        + " and tat.user_id = cu.id and upper(gl.value1) = upper(cu.sso_id) order by tat.id desc";
                SqlRowSet rowSet1 = jdbcTemplate.queryForRowSet(isPlatformTeamMember, new Object[] { tiRequestId });
                while (rowSet1.next()) {

                    isMgrApproval = true;

                }
            }
            log.debug("isManagerApprovalRequired End  tiRequestId : " + tiRequestId + "::isManagerApprovalRequired"
                    + isMgrApproval);
           
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }
        return isMgrApproval;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * isRequestRolledBack(long)
     */

    public boolean isRequestRolledBack(long tiRequestId) throws Exception {
        log.debug("Entering with tiRequestId : " + tiRequestId);
        boolean isReqRolledback = false;
        try {
            StringBuilder rolledBackApprovalSQL = new StringBuilder(
                    "select id from c3par.ti_activity_trail where ti_request_id=? and activity_status = ?");
            SqlRowSet rowSet = jdbcTemplate.queryForRowSet(rolledBackApprovalSQL.toString(), new Object[] {
                    tiRequestId, ActivityDataDTO.STATUS_ROLLEDBACK });
            while (rowSet.next()) {
                isReqRolledback = true;
            }
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }
        log.info("ISRequestRolledback status " + isReqRolledback + " For TIRequestId " + tiRequestId);
        return isReqRolledback;

    }

    /**
     * Update data info bulk request.
     * 
     * @param tiRequestId
     *            the ti request id
     * @throws Exception
     *             the exception
     */
    public void updateDataInfoBulkRequest(long tiRequestId) throws Exception {
        log.debug("Entering setDataInfoBulkRequest for tiRequestId " + tiRequestId);
        StringBuilder errMsg = new StringBuilder();
        if (tiRequestId <= 0) {
            errMsg.append("Provide TIRequest ID " + tiRequestId);
        }
        chkBusException(errMsg);

        try {
            String bulkReqSQL = "update c3par.con_req set bulk_request='N' where id= "
                    + "(select xref.planning_id from ti_request_planning_xref xref where ti_request_id=?) ";

            int rowUpdated = jdbcTemplate.update(bulkReqSQL, new Object[] { tiRequestId });
            log.debug("Exiting setDataInfoBulkRequest for tiRequestId " + tiRequestId + "::rowUpdated" + rowUpdated);
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }
       
    }

    /**
     * Insert generic rfc.
     * 
     * @param tiRequestID
     *            the ti request id
     * @param rfcType
     *            the rfc type
     */

    private void insertGenericRFC(long tiRequestID, String rfcType) {
        log.debug("insertGenericRFC Method Starts:: tiRequestId : " + tiRequestID + " rfcType : " + rfcType);
        String rfcSQl = "insert into c3par.rfc_request (id,ti_request_id,CREATED_DATE,rfc_type) values (seq_rfc_REQUEST.NEXTVAL,?,SYSDATE,?)";
        try {
            jdbcTemplate.update(rfcSQl, new Object[] { tiRequestID, rfcType });
        } catch (Exception e) {
            log.error(e.toString(), e);
        }
    }

    /**
     * Checks if is affected business data exists.
     * 
     * @param tiRequestId
     *            the ti request id
     * @return true, if is affected business data exists
     */

    private boolean isAffectedBusinessDataExists(long tiRequestId) {

        StringBuilder sql = new StringBuilder();
        try {
            sql.append("SELECT RDA.ANSWER FROM RFC_DETAIL_ANSWERS RDA, ");
            sql.append(" RFC_DETAIL RD, RFC_LOOKUP RL,RFC_REQUEST RR, TI_REQUEST TR ");
            sql.append(" WHERE TR.ID = RR.TI_REQUEST_ID AND ");
            sql.append(" RR.ID = RD.RFC_REQUEST_ID AND ");
            sql.append(" RD.ID = RDA.RFC_DETAIL_ID AND ");
            sql.append(" RL.ID = RD.RFC_LOOKUP_ID ");
            sql.append(" AND RL.PARAMNAME = 'AFFECTED_BUSINESS' AND TR.ID = ?");

            SqlRowSet rowSet = jdbcTemplate.queryForRowSet(sql.toString(), new Object[] { tiRequestId });
            if (rowSet.next()) {
                return true;
            } else
                return false;
        } catch (Exception ex) {
            log.error(ex.toString(), ex);
        }
        return false;
    }

    /**
     * Gets the current version comb count.
     * 
     * @param tiRequestId
     *            the ti request id
     * @return the current version comb count
     */

    public long getcurrentVersionCombCount(long tiRequestId) {
        log.debug("getcurrentVersionCombCount Starts:: tiRequestId : " + tiRequestId);
        long combCount = 0;
        if (tiRequestId > 0) {
            try {
                String sql = " select count(id) from faf_fireflow_ticket where ti_request_id=? and (ip_reg is null or ip_reg <> 'Y') and upper(ltrim(rtrim(status))) not in(upper('rejected'),'DELETED')";
                SqlRowSet rowSet = jdbcTemplate.queryForRowSet(sql, new Object[] { tiRequestId });
                if (rowSet.next()) {
                    combCount = rowSet.getLong(1);
                }
            } catch (Exception ex) {
                log.error(ex.toString(), ex);
                return 0;
            }
        }
        
        return combCount;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * manageUserContactsProcess
     * (com.citigroup.cgti.c3par.bpm.ejb.domain.TIProcessDTO)
     */
    public long manageUserContactsProcess(TIProcessDTO processDTO) throws Exception {

        Connection con = null;
        PreparedStatement ps = null;
        TIProcess tiProcess = new TIProcess();
        if (processDTO == null) {
            throw new Exception("Business Exception :  ProcessDTO is null");
        }
        tiProcess.setId(processDTO.getId());
        tiProcess.getRequestor().setSoeID(processDTO.getRequestorSOEId());
        try {
            // updateTIProcess(tiProcess,TIProcessService.TIReqType_ManageUserContacts);

            updateManageContactsTIProcess(tiProcess, TIProcessService.TIReqType_ManageUserContacts);

            if (TIProcess.CONNECTION.equalsIgnoreCase(tiProcess.getBusinessCase().getProcessType().getName())) {
                Long connID = tiProcessSQL.getConnectionID(tiProcess.getId());
                if (connID == null)
                    throw new Exception(" Connection ID is null for and Active Connection Request ID "
                            + tiProcess.getId());

                MaintenanceEntity maint = new MaintenanceEntity();
                maint.setConnectionId(connID);
                maint.setUpdateType("circuit");
                maint.setStatus(MANAGE_USER_CONTACTS);

                ConnectionEntity connection = ConnectionDAO.createInstance(c3parSession).get(maint.getConnectionId());
                PlanningEntity planning = transfromConnection2Planning(connection, c3parSession);

                planning.setPlannedActivateDate(tiProcess.getTiRequest().getPlannedCompletionDate());
                planning.setRequesterId(tiProcess.getRequestor().getSoeID());
                savePlanningEntity(planning, c3parSession);
                maint.setPlanning(planning);
                MaintenanceDAO.createInstance(c3parSession).update(maint);
                log.info(" Created Connections Maintenance Id " + maint.getId() + ", planning id " + planning.getId()
                        + " for TIProcess Id " + tiProcess.getId());
                if (maint.getId() == null) {
                    throw new Exception(" Could not successfully Create Maintenance Id for TIProcess ID "
                            + tiProcess.getId());
                }
                if (planning.getId() == null) {
                    throw new Exception(" Could not successfully Create Planning Id for TIProcess ID "
                            + tiProcess.getId());
                }
                String instSQL = "insert into c3par.ti_request_planning_xref  values (?,?)";
                con = c3parSession.getConnection();
                ps = con.prepareStatement(instSQL);
                ps.setLong(1, tiProcess.getTiRequest().getId().longValue());
                ps.setLong(2, planning.getId().longValue());

                log.debug(" with  values TIRequestID = " + tiProcess.getTiRequest().getId().longValue()
                        + " and Planning =" + planning.getId());
                ps.executeUpdate();
                long tiReqId = tiProcess.getTiRequest().getId().longValue();
            }
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw new EJBException(e.getMessage());
        } finally {
            c3parSession.closeStatement(ps);
            c3parSession.releaseConnection();
        }
        return tiProcess.getTiRequest().getId().longValue();
    }


    /**
     * Update manage contacts ti process.
     * 
     * @param tiProcess
     *            the ti process
     * @param processCycle
     *            the process cycle
     * @throws Exception
     *             the exception
     */
    public void updateManageContactsTIProcess(TIProcess tiProcess, String processCycle) throws Exception {
        StringBuilder errMsg = new StringBuilder();
        if (tiProcess != null && chkIsZero(tiProcess.getId()))
            errMsg.append(" Searched Process Id is - " + tiProcess.getId() + ".Please Enter a valid Id ");
        if (!isString(tiProcess.getRequestor().getSoeID()))
            errMsg.append("   Requester ssoid is empty  ");
        if (errMsg.length() > 0) {
            log.error(errMsg.toString());
            throw new Exception("Business Exception : " + errMsg.toString());
        }

        boolean isActive = tiProcessSQL.isProcessActive(tiProcess.getId().longValue());
        if (!isActive) {
            log.error(" Cannot update  TIProcess ID " + tiProcess.getId() + " since its not Active ");
            throw new Exception("Business Exception : Cannot update  TIProcess ID " + tiProcess.getId()
                    + " since its not Active ");
        }
        String entName = null;

        if (!TIProcessDTO.SYSTEM_USER.equalsIgnoreCase(tiProcess.getRequestor().getSoeID()))
            entName = tiProcessSQL.chkPreviligesUpdateContacts(tiProcess.getRequestor().getSoeID(), tiProcess.getId()
                    .longValue());
        String processType = tiProcessSQL.getProcessType(tiProcess.getId().longValue());
        if (processType == null) {
            log.error(" Process Type is undefined for  " + tiProcess.getId());
            throw new Exception(" Process Type is undefined for TIProcess " + tiProcess.getId());
        }
        tiProcess.getBusinessCase().getProcessType().setName(processType);

        // String fafGenerated=null;
        if (isActive) {
            if (isString(entName)) {
                log.error(" Require Business User role and entitlement to  " + entName + " to Update the Process");
                throw new Exception("Business Exception :  Require Business User role and entitlement to  " + entName
                        + " to Update the process");
            }

            if (TIProcess.CONNECTION.equalsIgnoreCase(processType)) {
                boolean isResourceMissing = tiProcessSQL.isResourceTypeMissing(tiProcess.getId().longValue());
                if (isResourceMissing) {
                    log.error(" Cannot update  TIProcess ID " + tiProcess.getId()
                            + " since Resource type is missing.Please check EndPointA/EndpointB Resource Type ");
                    throw new Exception("Business Exception : Cannot update  TIProcess ID " + tiProcess.getId()
                            + " since Resource type is missing.Please check EndPointA/EndPointB Resource Type ");
                }
            }
        }
        if (isActive && !isString(entName)) {
            PreparedStatement ps = null;
            try {
                int versionNum = tiProcessSQL.getProcessVersion(tiProcess.getId().longValue());
                if (chkIsZero(Long.valueOf(versionNum))) {
                    throw new Exception(" Business Exception : Invalid Version Number for ti Process Id "
                            + tiProcess.getId());
                }
                tiProcess.getTiRequest().setVersionNumber(versionNum + 1);
                tiProcess.getTiRequest().getTiRequestType().setName(processCycle);

                tiProcess.getTiRequest().setId(null);
                createManageContactsRequest(tiProcess);
                long tiRequestID = tiProcess.getTiRequest().getId().longValue();
            } catch (Exception e) {
                log.error(e.toString(), e);
                throw new Exception(e.getMessage());
            } finally {
                c3parSession.closeStatement(ps);
            }
        }
    }


    /**
     * Creates the manage contacts request.
     * 
     * @param tiProcess
     *            the ti process
     * @throws Exception
     *             the exception
     */
    public void createManageContactsRequest(TIProcess tiProcess) throws Exception {
        createTIRequest(tiProcess);

        if (tiProcess.getTiRequest().getId().longValue() <= 0) {
            throw new Exception(" Could not create TIRequest for TIProcess Id " + tiProcess.getId());
        }

        ActivityData activityData = new ActivityData();
        activityData.setUserID(tiProcess.getRequestor().getSoeID());
        activityData.setActivityName(ActivityData.ACTIVITY_MANAGE_USER_CONTACTS_START_PROCESS);
        activityData.setUserRole(ActivityData.ROLE_BUSINESS_USER);
        manageActivityImpl.addActivity(activityData, tiProcess.getTiRequest().getId().longValue());

        try {
            String updateSQL = " update c3par.ti_process set version_number=?,process_activity_mode=? where id=? ";
            log.debug(" with  Conditions version Number = " + tiProcess.getTiRequest().getVersionNumber()
                    + "  and TIProcessId =" + tiProcess.getId());
            int rowsUpdated = jdbcTemplate.update(updateSQL, new Object[] {
                    tiProcess.getTiRequest().getVersionNumber(), ActivityData.IS_NEW, tiProcess.getId().longValue() });
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }
    }

    /**
     * @param tiRequestId
     * @return
     */

    public String getBroadAccessFlag(Long tiRequestId) {
        String broadAccess = "N";
        long ipCount = 0;

        try {
            StringBuilder broadAcessAnySQL = new StringBuilder(
                    " select count(ip.id) from c3par.con_ip_master ip,con_fw_rule rul, con_fw_rule_destination_ip dip ");
            broadAcessAnySQL.append(" where rul.ti_request_id = ? and rul.deleted_ti_request_id is null "
                    + " and dip.rule_id = rul.id and dip.deleted_ti_request_id is null "
                    + " and dip.ip_id = ip.id and ip.ip_address LIKE '0.0.0.%' ");
            broadAcessAnySQL.append(" UNION ");
            broadAcessAnySQL
                    .append(" select count(ip.id) from c3par.con_ip_master ip,con_fw_rule rul, con_fw_rule_source_ip sip ");
            broadAcessAnySQL.append(" where rul.ti_request_id = ? and rul.deleted_ti_request_id is null "
                    + " and sip.rule_id = rul.id and sip.deleted_ti_request_id is null "
                    + " and sip.ip_id = ip.id and ip.ip_address LIKE '0.0.0.%' ");

            SqlRowSet rowSet = jdbcTemplate.queryForRowSet(broadAcessAnySQL.toString(), new Object[] { tiRequestId,
                    tiRequestId });
            while (rowSet.next()) {
                ipCount += rowSet.getLong(1);
            }
            if (ipCount > 0) {
                broadAccess = "Y";
            }
            // get the count of ips only if there are no any ips
            if ("N".equals(broadAccess)) {
                StringBuilder broadAccSQl = new StringBuilder(
                        " select count(ip.id) from c3par.con_ip_master ip,con_fw_rule rul, con_fw_rule_destination_ip dip ");
                broadAccSQl.append(" where rul.ti_request_id = ? and dip.rule_id = rul.id and dip.ip_id = ip.id ");
                broadAccSQl
                        .append(" and rul.src_nwzone_id not in (select id from c3par.resourcetype where name like '3rd Party/CEP') and ip.no_of_host is null ");
                broadAccSQl.append(" union ");
                broadAccSQl
                        .append(" select count(ip.id) from c3par.con_ip_master ip,con_fw_rule rul, con_fw_rule_source_ip sip ");
                broadAccSQl.append(" where rul.ti_request_id = ? and sip.rule_id = rul.id and sip.ip_id = ip.id ");
                broadAccSQl
                        .append(" and rul.dst_nwzone_id not in (select id from c3par.resourcetype where name like '3rd Party/CEP') and ip.no_of_host is null ");
                broadAccSQl.append(" union ");
                broadAccSQl
                        .append(" select  sum(ip.no_of_host) b from c3par.con_ip_master ip,con_fw_rule rul, con_fw_rule_source_ip sip ");
                broadAccSQl.append(" where rul.ti_request_id = ? and sip.rule_id = rul.id and sip.ip_id = ip.id ");
                broadAccSQl
                        .append(" and rul.src_nwzone_id not in (select id from c3par.resourcetype where name like '3rd Party/CEP') and ip.no_of_host is not null ");
                broadAccSQl.append(" union ");
                broadAccSQl
                        .append(" select sum(ip.no_of_host) b from c3par.con_ip_master ip,con_fw_rule rul, con_fw_rule_destination_ip dip ");
                broadAccSQl.append(" where rul.ti_request_id = ? and dip.rule_id = rul.id and dip.ip_id = ip.id ");
                broadAccSQl
                        .append(" and rul.dst_nwzone_id not in (select id from c3par.resourcetype where name like '3rd Party/CEP') and ip.no_of_host is not null");

                SqlRowSet rowSet1 = jdbcTemplate.queryForRowSet(broadAccSQl.toString(), new Object[] { tiRequestId,
                        tiRequestId, tiRequestId, tiRequestId });
                ipCount = 0;
                while (rowSet1.next()) {
                    ipCount += rowSet1.getLong(1);
                }
                if (ipCount >= TIProcess.BROAD_ACCESS_IP_COUNT)
                    broadAccess = "Y";
            }
            log.info("broadAccess Flag For tiRequestId::" + tiRequestId + "::" + broadAccess);
        } catch (Exception e) {
            log.error(e.toString(), e);
        }
        return broadAccess;
    }

    /**
     * @param tiReqId
     * @return
     */

    public String getTPAFlagforIP(Long tiReqId) {
        log.info("Entering : tiReqId : " + tiReqId);
        String tpaFlag = "N";
        StringBuilder isTPA = new StringBuilder();
        isTPA.append(" select 1 from con_fw_rule rul, con_fw_rule_source_ip sip, ");
        isTPA.append(" con_ip_master ip ");
        isTPA.append(" where ");
        isTPA.append(" rul.id = sip.rule_id and ");
        isTPA.append(" sip.ip_id = ip.id and ip.is_tpa='Y' ");
        isTPA.append(" and rul.updated_ti_request_id= ?");
        isTPA.append(" union ");
        isTPA.append(" select 1 from con_fw_rule rul, con_fw_rule_destination_ip sip, ");
        isTPA.append(" con_ip_master ip ");
        isTPA.append(" where  ");
        isTPA.append(" rul.id = sip.rule_id and ");
        isTPA.append(" sip.ip_id = ip.id and ip.is_tpa='Y' ");
        isTPA.append(" and rul.updated_ti_request_id= ?");
        try {
            SqlRowSet rowSet = jdbcTemplate.queryForRowSet(isTPA.toString(), new Object[] { tiReqId, tiReqId });
            while (rowSet.next()) {
                tpaFlag = "Y";
                break;
            }
        } catch (Exception e) {
            log.error(e.toString(), e);
        }
        log.info("Exiting : tpaFlag : " + tpaFlag + " for tiReqId : " + tiReqId);
        return tpaFlag;

    }

    /**
     * @param tiReqId
     * @return
     */

    public String getOFACFlagforIP(Long tiReqId) {
        log.info("Entering : tiReqId : " + tiReqId);
        String ofacFlag = "N";
        StringBuilder isOFAC = new StringBuilder();
        isOFAC.append(" select 1 from con_fw_rule rul, con_fw_rule_source_ip sip, ");
        isOFAC.append(" con_ip_master ip ");
        isOFAC.append(" where ");
        isOFAC.append(" rul.id = sip.rule_id and ");
        isOFAC.append(" sip.ip_id = ip.id and ip.is_ofac='Y' ");
        isOFAC.append(" and rul.ti_request_id= ?");
        isOFAC.append(" union ");
        isOFAC.append(" select 1 from con_fw_rule rul, con_fw_rule_destination_ip sip, ");
        isOFAC.append(" con_ip_master ip ");
        isOFAC.append(" where  ");
        isOFAC.append(" rul.id = sip.rule_id and ");
        isOFAC.append(" sip.ip_id = ip.id and ip.is_ofac='Y' ");
        isOFAC.append(" and rul.ti_request_id= ?");

        try {
            SqlRowSet rowSet = jdbcTemplate.queryForRowSet(isOFAC.toString(), new Object[] { tiReqId, tiReqId });
            while (rowSet.next()) {
                ofacFlag = "Y";
                break;
            }
        } catch (Exception e) {
            log.error(e.toString(), e);
        }
        log.info("Exiting : ofacFlag : " + ofacFlag + " for tiReqId : " + tiReqId);
        return ofacFlag;

    }

    /**
     * @param ruleId
     * @return
     */
    public String getTPAFlagforRule(Long ruleId) {
        log.info("Entering : Rule Id  : " + ruleId);
        String tpaFlag = "N";
        StringBuilder isTPA = new StringBuilder();

        isTPA.append(" select 1 from con_fw_rule rul, con_fw_rule_source_ip sip, ");
        isTPA.append(" con_ip_master ip ");
        isTPA.append(" where ");
        isTPA.append(" rul.id = sip.rule_id and ");
        isTPA.append(" sip.ip_id = ip.id and ip.is_tpa='Y' ");
        isTPA.append(" and rul.id = ? ");
        isTPA.append(" union ");
        isTPA.append(" select 1 from con_fw_rule rul, con_fw_rule_destination_ip sip, ");
        isTPA.append(" con_ip_master ip ");
        isTPA.append(" where  ");
        isTPA.append(" rul.id = sip.rule_id and ");
        isTPA.append(" sip.ip_id = ip.id and ip.is_tpa='Y' ");
        isTPA.append(" and rul.id = ? ");

        try {
            SqlRowSet rowSet = jdbcTemplate.queryForRowSet(isTPA.toString(), new Object[] { ruleId, ruleId });
            while (rowSet.next()) {
                tpaFlag = "Y";
                break;
            }
        } catch (Exception e) {
            log.error(e.toString(), e);
        }
        log.info("Existing  : TPA Flag  For RUle : " + tpaFlag + ":RuleId " + ruleId);
        return tpaFlag;

    }

    /**
     * @param ruleId
     * @return
     */

    public String getOFACFlagforRule(Long ruleId) {
        log.info("Entering : Rule Id  : " + ruleId);
        String ofacFlag = "N";
        StringBuilder ofacByRuleQuery = new StringBuilder();

        ofacByRuleQuery.append(" select 1 from con_fw_rule rul, con_fw_rule_source_ip sip, ");
        ofacByRuleQuery.append(" con_ip_master ip ");
        ofacByRuleQuery.append(" where ");
        ofacByRuleQuery.append(" rul.id = sip.rule_id and ");
        ofacByRuleQuery.append(" sip.ip_id = ip.id and ip.is_ofac='Y' ");
        ofacByRuleQuery.append(" and rul.id = ? and sip.deleted_ti_request_id is null ");
        ofacByRuleQuery.append(" union ");
        ofacByRuleQuery.append(" select 1 from con_fw_rule rul, con_fw_rule_destination_ip sip, ");
        ofacByRuleQuery.append(" con_ip_master ip ");
        ofacByRuleQuery.append(" where  ");
        ofacByRuleQuery.append(" rul.id = sip.rule_id and ");
        ofacByRuleQuery.append(" sip.ip_id = ip.id and ip.is_ofac='Y' ");
        ofacByRuleQuery.append(" and rul.id = ? and sip.deleted_ti_request_id is null");

        try {
            SqlRowSet rowSet = jdbcTemplate.queryForRowSet(ofacByRuleQuery.toString(), new Object[] { ruleId, ruleId });
            while (rowSet.next()) {
                ofacFlag = "Y";
                break;
            }
        } catch (Exception e) {
            log.error(e.toString(), e);
        }
        log.info("Existing  : OFAC Flag  : " + ofacFlag + ":RuleId" + ruleId);
        return ofacFlag;

    }

    /**
     * @param cntrlFlags
     * @param is_faf
     * @param is_proxy
     * @param is_Appsense
     * @param is_acl_variance
     * @param is_ecm
     * @param is_IPReg
     * @param tiRequestId
     */
    public void updateRiskFlags(Map<String, Boolean> cntrlFlags, boolean is_faf, boolean is_proxy, boolean is_Appsense,
            boolean is_acl_variance, boolean is_ecm, boolean is_IPReg, Long tiRequestId) {
        log.info("Entering updateRiskFlags1 with ti_request_id ::" + tiRequestId
                +" Control Flags: is_faf: " + is_faf + ",is_proxy: " + is_proxy + ",is_Appsense: " 
                + is_Appsense+ ",is_acl_variance: " + is_acl_variance + ", is_ecm: " + is_ecm
                +"cntrlFlags Map:" + cntrlFlags);
        String broadAccess = cntrlFlags.get(TIProcess.BROAD_ACCESS_FLAG) == true ? "Y" : "N";
        String highRisk = cntrlFlags.get(TIProcess.HIGH_RISK_FLAG) == true ? "Y" : "N";
        String tpaFlag = cntrlFlags.get(TIProcess.TPA_FLAG) == true ? "Y" : "N";
        // adeed for ofac change Start
        String ofacFlag = cntrlFlags.get(TIProcess.OFAC_FLAG) == true ? "Y" : "N";

        // end
        Map<String, Boolean> otherFlags = new HashMap<String, Boolean>();
        otherFlags.put(TIProcessDTO.FIREFLOW_CONTROL_FLAG, is_faf);
        otherFlags.put(TIProcessDTO.PROXY_REQD_FLAG, is_proxy);
        otherFlags.put(TIProcessDTO.APPSENSE_REQD_FLAG, is_Appsense);
        otherFlags.put(TIProcessDTO.GNCC_REQD_FLAG, is_acl_variance);
        otherFlags.put(TIProcessDTO.ECM_FLAG, is_ecm);
        otherFlags.put(TIProcessDTO.IPREG_FLAG, is_IPReg);
        log.debug("High risk flag is "+highRisk);
        updateRiskFlags(broadAccess, highRisk, tpaFlag, ofacFlag, tiRequestId, otherFlags);
        log.info("Exiting updateRiskFlags1 with ti_request_id ::" + tiRequestId);
    }


    /**
     * @param broadAccess
     * @param highRisk
     * @param tpaFlag
     * @param ofacFlag
     * @param tiRequestId
     * @param cntrlFlags
     */

    public void updateRiskFlags(String broadAccess, String highRisk, String tpaFlag, String ofacFlag, Long tiRequestId,
            Map<String, Boolean> cntrlFlags) {

        log.info("Entering updateRiskFlags2 with ti_request_id ::" + tiRequestId);

        StringBuilder insertFlags = new StringBuilder();
        insertFlags
                .append("insert into ti_request_risk_flags(id,ti_request_id,is_tpa,is_highrisk,is_broadaccess,is_faf,is_proxy,is_Appsense,is_acl_variance,is_ecm,IP_REGISTRATION,is_ofac,created_date) ");
        insertFlags
                .append("select seq_ti_request_risk_flags.nextval,?,?,?,?,?,?,?,?,?,?,?,sysdate from dual where not exists ");
        insertFlags.append("(select 1 from ti_request_risk_flags where ti_request_id=?) ");

        StringBuilder updateFlags = new StringBuilder();
        updateFlags
                .append("update ti_request_risk_flags set is_tpa = ?,is_highrisk = ?,is_broadaccess = ?,is_faf = ?,is_proxy = ?, is_Appsense = ?, is_acl_variance = ?, is_ecm = ? ,IP_REGISTRATION = ?, updated_date=sysdate,is_ofac = ?   where ti_request_id=? ");

        try {
            boolean is_faf = cntrlFlags.get(TIProcessDTO.FIREFLOW_CONTROL_FLAG);
            boolean is_proxy = cntrlFlags.get(TIProcessDTO.PROXY_REQD_FLAG);
            boolean is_Appsense = cntrlFlags.get(TIProcessDTO.APPSENSE_REQD_FLAG);
            boolean is_acl_variance = cntrlFlags.get(TIProcessDTO.GNCC_REQD_FLAG);
            boolean is_ecm = cntrlFlags.get(TIProcessDTO.ECM_FLAG);
            boolean is_ipreg = cntrlFlags.get(TIProcessDTO.IPREG_FLAG);

            int i = jdbcTemplate.update(insertFlags.toString(), new Object[] { tiRequestId, tpaFlag, highRisk,
                    broadAccess, is_faf == true ? "Y" : "N", is_proxy == true ? "Y" : "N",
                    is_Appsense == true ? "Y" : "N", is_acl_variance == true ? "Y" : "N", is_ecm == true ? "Y" : "N",
                    is_ipreg == true ? "Y" : "N", ofacFlag, tiRequestId });
            if (i <= 0) {
                int j = jdbcTemplate.update(updateFlags.toString(), new Object[] { tpaFlag, highRisk, broadAccess,
                        is_faf == true ? "Y" : "N", is_proxy == true ? "Y" : "N", is_Appsense == true ? "Y" : "N",
                        is_acl_variance == true ? "Y" : "N", is_ecm == true ? "Y" : "N", is_ipreg == true ? "Y" : "N",
                        ofacFlag, tiRequestId });
                log.debug("Rows updated: " + j);
            }

        } catch (Exception e) {
            log.error(e.toString(), e);
        }
      
    }

    /**
     * @param tiReqId
     * @return
     */

    public boolean isOstiaCompleted(Long tiReqId) {

      
        boolean message = true;
        try {
            String sql = "select q.id from con_fw_rule_questionnaire q, ti_request t ,con_fw_rule cfr "
                    + "where q.updated_ti_request_id=t.id and cfr.id=q.fw_rule_id and cfr.updated_ti_request_id=t.id and q.deleted_ti_request_id is null and q.fw_rule_id is not null and t.id=? and q.status='Incomplete'";
            SqlRowSet rowSet = jdbcTemplate.queryForRowSet(sql, new Object[] { tiReqId });
            if (rowSet != null && rowSet.next()) {
                message = false;
            }
            log.info("Util.isOstiaCompleted() ::tiRequestId " + tiReqId + "::message" + message);
            
        } catch (Exception e) {
            log.error(e.toString(), e);
        }
        log.info("Util.isOstiaCompleted ends " + message);
        return message;
    }

    /**
     * @param processId
     * @param tiReqId
     * @param abortedType
     * @return
     */

    public boolean isAborted(Long processId, Long tiReqId, int abortedType) {
        /*
         * AbortedType 1 - Check whether the connection Aborted in the Current
         * Cycle 2 - Check whether the connection Aborted in the Previous Cycle
         */
        log.info("ManageTIProcessImpl.isAborted() starts ,processId=>" + processId + ",tiReqId=>" + tiReqId
                + ",abortedType=>" + abortedType);
        boolean message = false;
        SqlRowSet rowSet = null;
        try {
            if (abortedType == 1) {
                String sql = "select 1 from ti_activity_trail where activity_status = 'ABORTED'"
                        + "and ti_request_id = (select max(ID) from ti_request where process_id = ?)";
                rowSet = jdbcTemplate.queryForRowSet(sql, new Object[] { processId });
            } else {
                String sql = "select 1 from ti_activity_trail where activity_status = 'ABORTED'"
                        + "and ti_request_id = (select max(ID) from ti_request where process_id = ? and ID < ? AND TI_REQUEST_TYPE_ID in (1,2) )";
                rowSet = jdbcTemplate.queryForRowSet(sql, new Object[] { processId, tiReqId });
            }
            if (rowSet != null && rowSet.next()) {
                message = true;
            }
        } catch (Exception e) {
            log.error(e.toString(), e);
        }
        log.info("ManageTIProcessImpl.isAborted() ends " + message);
        return message;
    }

    /**
     * @param processId
     * @param tiRequestId
     * @return
     * @throws Exception
     */
    public String abortToActiveFWRuleCopy(Long processId, Long tiRequestId) throws Exception {
        log.debug("abortToActiveFWRuleCopy Starts::processId=>" + processId.longValue() + ",tiRequestId=>"
                + tiRequestId.longValue());
        String result = null;
        try {

            SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("COPY_FWRULE_FOR_ABORT");

            Map<String, Object> inParamMap = new HashMap<String, Object>();
            inParamMap.put("P_TI_PROCESS_ID", processId.longValue());
            inParamMap.put("P_TI_REQUEST_ID", tiRequestId.longValue());

            SqlParameterSource in = new MapSqlParameterSource(inParamMap);

            Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
            if (simpleJdbcCallResult.get("P_RESULT") != null) {
                result = (String) simpleJdbcCallResult.get("P_RESULT");
            }

            log.debug("abortToActiveFWRuleCopy::result => " + result);
        } catch (Exception ex) {
            log.error(ex.toString(), ex);
        }
        return result;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * getTiRequestAuditVersion(long)
     */
    @Override
    public String getTiRequestAuditVersion(long tiReqId) throws Exception {
        log.info("ManageTIProcessImpl.getTiRequestAuditVersion() starts ,tiReqId=>" + tiReqId);
        String version_no = "";
        try {
            String sql = "select max(version_no) from ti_activity_trail where ti_request_id = ?";
            SqlRowSet rowSet = jdbcTemplate.queryForRowSet(sql, new Object[] { tiReqId });
            if (rowSet != null && rowSet.next()) {
                version_no = String.valueOf(rowSet.getInt(1));
            }
        } catch (Exception e) {
            log.error(e.toString(), e);
        }
        log.info("ManageTIProcessImpl.getTiRequestAuditVersion() ends " + version_no);
        return version_no;
    }

    /**
     * @param processId
     * @param tiReqId
     */
    public void updateProxyFlags(Long processId, Long tiReqId) {

        C3parSession c3parSession = new C3parSession();
        log.info("ManageTIProcessImpl.updateProxyFlags() starts ,processId=>" + processId + ",tiReqId=>" + tiReqId);

        PreparedStatement pstmt = null;
        Connection connection = null;
        try {

            String sql = "update ti_request set proxy_rfc_generate_flag = 'N',paf_generate_flag = 'N' where id = ? "
                    + " and exists (select 1 from prx_proxy_filter where process_id = ?)";
            connection = c3parSession.getConnection();
            pstmt = connection.prepareStatement(sql);
            pstmt.setLong(1, tiReqId);
            pstmt.setLong(2, processId);

            pstmt.executeUpdate();
        } catch (Exception e) {
            log.error(e.toString(), e);
        } finally {
            c3parSession.closeStatement(pstmt);
            c3parSession.releaseConnection();
        }
        log.info("ManageTIProcessImpl.isAborted() ends ");
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#
     * getHoldingPeriod(long)
     */

    public Date getHoldingPeriod(long tiRequestId) throws Exception {
        Date holdingPeriod = null;
        String sql = " select LOGGING_UNTIL from ti_request where id = ?";
        List ids = new ArrayList();
        try {
            SqlRowSet rowSet = jdbcTemplate.queryForRowSet(sql, new Object[] { tiRequestId });

            while (rowSet.next()) {
                holdingPeriod = rowSet.getDate(1);
                log.debug("For Ti_RequestId= " + tiRequestId + " == holdingPeriod::" + holdingPeriod);
            }
        } catch (Exception e) {
            log.error(e.toString(), e);
        }
        return holdingPeriod;
    }

    /**
     * @param tiProcessId
     * @return long
     */
    public long getTiRequestIdForACV(long tiProcessId) {
        log.info("tiProcessId : " + tiProcessId);
        long tiRequestId = 0;
        String tiRequesdIdForIntACVQuery = null;
        if (tiProcessId > 0) {
            try {
                tiRequesdIdForIntACVQuery = ccrQueries.getQueryByName(QueryConstants.TIREQUESTID_FOR_INTERNAL_ACV);
                SqlRowSet rs = jdbcTemplate.queryForRowSet(tiRequesdIdForIntACVQuery, new Object[] { tiProcessId });
                if (rs.next()) {
                    tiRequestId = rs.getLong(1);
                }
                log.info("tiRequestId :" + tiRequestId);

            } catch (Exception ex) {
                log.error("Exception in getTiRequestIdForACV : " + ex.toString());
                log.error(ex.toString(), ex);
            }
        }
        return tiRequestId;
    }

    /**
     * @param tiProcessId
     * @param tiAuditTrialId
     * @param ssoId
     * @return
     */
    public Map<String, String> getTaskIdForACV(long tiProcessId, long tiAuditTrialId, String ssoId) {
        log.info("tiProcessId :" + tiProcessId + " : tiAuditTrialId : " + tiAuditTrialId + " ssoId : " + ssoId);
        String taskId = "0";
        String activity_status = null;
        Map<String, String> taskIdDetails = null;
        try {
            if (tiProcessId > 0) {
                StringBuilder taskIdForACVSQL = new StringBuilder();
                taskIdDetails = new HashMap<String, String>();
                taskIdForACVSQL
                        .append(" SELECT A.TASK_ID, UPPER(A.ACTIVITY_STATUS) ACTIVITY_STATUS,DECODE(A.TASK_ROLE,'C3PARSYSTEMADMIN','1','Design_Engineer','2','Project_Coordinator','3','Business User','4','BISO','5','1') TASK_ROLE_PRIORITY  ");
                taskIdForACVSQL
                        .append(" FROM CCR_TASK_REF A, SECURITY_ROLE B, C3PAR_USER_ROLE_XREF C, C3PAR_USERS D WHERE A.CONNECTION_ID=?   ");
                taskIdForACVSQL.append(" AND A.TI_AUDITTRAIL_ID=? AND A.PHASE='ACV' ");
                taskIdForACVSQL.append(" AND A.TASK_ROLE = B.NAME  ");
                taskIdForACVSQL
                        .append(" AND A.TASK_ROLE IN ('C3PARSYSTEMADMIN','Design_Engineer','Project_Coordinator','Business User','BISO')  ");
                taskIdForACVSQL.append(" AND B.ID = C.ROLE_ID AND C.USER_ID = D.ID AND UPPER(D.SSO_ID)=UPPER(?) AND UPPER(ACTIVITY_STATUS) <> 'COMPLETED' ");
                taskIdForACVSQL.append(" ORDER BY TASK_ROLE_PRIORITY  ");

                SqlRowSet rs = jdbcTemplate.queryForRowSet(taskIdForACVSQL.toString(), new Object[] { tiProcessId,
                        tiAuditTrialId, ssoId });
                if (rs.next()) {
                    taskId = rs.getString(1);
                    activity_status = rs.getString(2);
                    taskIdDetails.put("taskId", taskId);
                    taskIdDetails.put("activity_status", activity_status);
                }
                log.info(" taskId : " + taskId + " activity_status : " + activity_status);
            }
        } catch (Exception ex) {
            log.error("Exception in getTaskIdForACV : " + ex.toString());
            log.error(ex.toString(), ex);
        }
        return taskIdDetails;
    }

    /**
     * @param tiProcessId
     * @return
     */
    public String getRelationshipType(long tiProcessId) {
        String relationshipType = "CITI_CON";
        final String relationshipTypeForACVSQL = " SELECT B.RELATIONSHIP_TYPE RELATIONSHIP_TYPE FROM CON_REQ A,RELATIONSHIP B WHERE A.RELATIONSHIP_ID=B.ID AND A.ID =? ";
        try {
            log.info("tiProcessId :" + tiProcessId);
            if (tiProcessId > 0) {
                SqlRowSet rs = jdbcTemplate.queryForRowSet(relationshipTypeForACVSQL, new Object[] { tiProcessId });
                if (rs.next()) {
                    relationshipType = rs.getString(1);
                }
            }
            log.info("relationshipType :" + relationshipType);
        } catch (Exception e) {
            log.error("Exception in getting Relationship Type for ACV : " + e.toString());
            log.error(e.toString(), e);
        }
        return relationshipType;
    }

    /**
     * @param tiProcessId
     * @param tiRequestId
     * @return
     */
    public Date getRequestDeadLineForACV(long tiProcessId, long tiRequestId) {
        log.info("tiProcessId :" + tiProcessId + "tiRequestId :" + tiRequestId);
        Date requestDeadLine = new Date();
        final String requestDeadLineForACVSQL = " SELECT REQUEST_DEADLINE FROM TI_REQUEST WHERE PROCESS_ID=? AND ID=? ";
        try {
            if (tiProcessId > 0) {
                SqlRowSet rs = jdbcTemplate.queryForRowSet(requestDeadLineForACVSQL, new Object[] { tiProcessId,
                        tiRequestId });
                if (rs.next()) {
                    requestDeadLine = rs.getTimestamp(1);
                } else {
                    Calendar myCal = Calendar.getInstance();
                    myCal.setTime(requestDeadLine);
                    myCal.add(Calendar.MONTH, +1);
                    requestDeadLine = myCal.getTime();
                }
            }
            log.info("tiRequestId :" + tiRequestId);
        } catch (Exception e) {
            log.error("Exception in getting Request DeadLine for ACV : " + e.toString());
            log.error(e.toString(), e);
        }
        return requestDeadLine;
    }

    /**
     * @param tiProcessId
     * @return
     */
    public String getProcessActivityMode(long tiProcessId) {
        log.info("tiProcessId :" + tiProcessId);
        String processActivityMode = "NEW";
        final String processActivityModeForACVSQL = " SELECT PROCESS_ACTIVITY_MODE FROM TI_PROCESS WHERE ID=? ";
        try {
            if (tiProcessId > 0) {
                SqlRowSet rs = jdbcTemplate.queryForRowSet(processActivityModeForACVSQL, new Object[] { tiProcessId });
                if (rs.next()) {
                    processActivityMode = rs.getString(1);
                }
            }
            log.info("processActivityMode :" + processActivityMode);
        } catch (Exception e) {
            log.error("Exception in getting Process Activity Mode for ACV : " + e.toString());
            log.error(e.toString(), e);
        }
        return processActivityMode;
    }

    /**
     * @param tiProcessId
     * @return
     */
    public String getProcessType(long tiProcessId) {
        log.info("tiProcessId :" + tiProcessId);
        String processType = "Connection";
        final String processTypeForACVSQL = " SELECT PROCESS_TYPE FROM TI_PROCESS_TYPE WHERE ID IN (SELECT PROCESS_TYPE_ID FROM TI_PROCESS WHERE ID=?) ";
        try {
            if (tiProcessId > 0) {
                SqlRowSet rs = jdbcTemplate.queryForRowSet(processTypeForACVSQL, new Object[] { tiProcessId });
                if (rs.next()) {
                    processType = rs.getString(1);
                }
            }
            log.info("processType :" + processType);
        } catch (Exception e) {
            log.error("Exception in getting Process Type for ACV : " + e.toString());
            log.error(e.toString(), e);
        }
        return processType;
    }

    /**
     * @param tiRequestId
     * @param byPassSNOWFlag
     */
    public void updateByPassSNOWFlag(long tiRequestId, String byPassSNOWFlag) {
        log.info("tiRequestId : " + tiRequestId + " and byPassSNOWFlag as : " + byPassSNOWFlag);
        int updateCount = 0;
        final String updateByPassSNOWSQL = " UPDATE TI_REQUEST SET SNOW_BYPASS_FLAG=? WHERE ID=? ";
        try {
            updateCount = jdbcTemplate.update(updateByPassSNOWSQL, new Object[] { byPassSNOWFlag, tiRequestId });
            log.info("updateCount :" + updateCount);
        } catch (Exception e) {
            log.error("Exception while updating ByPass SNOW flag : " + e.toString());
            log.error(e.toString(), e);
        }
    }

    /**
     * @param tiRequestId
     * @return
     */
    public String getByPassSnowFlag(long tiRequestId) {
        log.info("tiRequestId :" + tiRequestId);
        String snowByPassFlag = "";
        final String ByPassSnowFlagSQL = " SELECT NVL(SNOW_BYPASS_FLAG,'') FROM TI_REQUEST WHERE ID=? ";
        try {
            if (tiRequestId > 0) {
                SqlRowSet rs = jdbcTemplate.queryForRowSet(ByPassSnowFlagSQL, new Object[] { tiRequestId });
                if (rs.next()) {
                    snowByPassFlag = rs.getString(1);
                }
            }
            log.info("snowByPassFlag :" + snowByPassFlag);
        } catch (Exception e) {
            log.error("Exception in getting ByPass Servicenow Flag : " + e.toString());
            log.error(e.toString(), e);
        }
        return snowByPassFlag;
    }

    /**
     * @param tiProcessId
     * @param tiRequestId
     * @return List<String>
     * @throws Exception
     */
    public List<String> getTaskandAuditIdForACV(long tiProcessId, long tiRequestId) throws Exception {
        log.info("tiProcessId : " + tiProcessId + ", tiRequestId : " + tiRequestId);
        List<String> result = new ArrayList<String>();
        String taskandauditIdForACVQuery = null;
        try {
            if (tiProcessId > 0) {
                taskandauditIdForACVQuery = ccrQueries.getQueryByName(QueryConstants.TASKID_FOR_INTERNAL_ACV);
                SqlRowSet rs = jdbcTemplate.queryForRowSet(taskandauditIdForACVQuery, new Object[] { tiRequestId,
                        tiProcessId });

                if (rs.next()) {
                    result.add(rs.getString(1));
                    result.add(rs.getString(2));
                    log.debug("taskId :" + result.get(0) + " and auditId :" + result.get(1));
                }
            }
        } catch (Exception ex) {
            log.error("Exception Occured in getTaskandAuditIdForACV :" + ex.toString(), ex);
            log.error(ex.toString(), ex);
        }
        return result;
    }

    /**
     * @param tiRequestId
     * @param strtaskId
     */
    public void updateBPMInstanceId(long tiRequestId, String strtaskId) {
        log.info("tiRequestId : " + tiRequestId + " and taskId : " + strtaskId);
        int updateCount = 0;
        long taskId = 0;
        final String updateBPMInstanceIdSQL = " UPDATE TI_ACTIVITY_TRAIL SET BPM_INSTANCE_ID=?  WHERE ACTIVITY_STATUS='SCHEDULED' AND TI_REQUEST_ID=? ";
        try {
            if (strtaskId != null) {
                try {
                    taskId = Long.valueOf(strtaskId);
                } catch (Exception e) {
                    taskId = Long.valueOf(0);
                }
            }
            updateCount = jdbcTemplate.update(updateBPMInstanceIdSQL, new Object[] { taskId, tiRequestId });
            log.info("updateCount :" + updateCount);
        } catch (Exception e) {
            log.error("Exception while updating BPM Instance Id : " + e.toString());
            log.error(e.toString(), e);
        }
    }

    /**
     * @param tiRequestId
     * @param ssoId
     * @return
     */
    public Map<String, String> getTaskIdDetailsForACVInGlblSrch(long tiRequestId, String ssoId) {
        log.info("tiRequestId :" + tiRequestId + " : ssoId :" + ssoId);
        String taskId = "0";
        Map<String, String> taskIdDetails = null;
        try {
            if (tiRequestId > 0) {
                StringBuilder taskIdForACVSQL = new StringBuilder();
                taskIdDetails = new HashMap<String, String>();
                taskIdForACVSQL
                        .append(" SELECT A.TASK_ID,A.TASK_ROLE,TI_AUDITTRAIL_ID,DECODE(A.TASK_ROLE,'C3PARSYSTEMADMIN','1','Design_Engineer','2','Project_Coordinator','3', ");
                taskIdForACVSQL
                        .append(" 'Business User','4','BISO','5','1') TASK_ROLE_PRIORITY FROM CCR_TASK_REF A,   ");
                taskIdForACVSQL
                        .append(" SECURITY_ROLE B, C3PAR_USER_ROLE_XREF C, C3PAR_USERS D WHERE A.TASK_ROLE = B.NAME   ");
                taskIdForACVSQL
                        .append(" AND A.TASK_ROLE IN ('C3PARSYSTEMADMIN','Design_Engineer','Project_Coordinator','Business User','BISO')    ");
                taskIdForACVSQL.append(" AND B.ID = C.ROLE_ID AND C.USER_ID = D.ID AND UPPER(D.SSO_ID) = UPPER(?)   ");
                taskIdForACVSQL.append(" AND A.TI_REQUEST_ID=? AND CON_TYPE='ACV' AND UPPER(ACTIVITY_STATUS) <> 'COMPLETED' ");
                taskIdForACVSQL.append(" ORDER BY TASK_ROLE_PRIORITY  ");

                SqlRowSet rs = jdbcTemplate.queryForRowSet(taskIdForACVSQL.toString(), new Object[] { ssoId,
                        tiRequestId });
                if (rs.next()) {
                    taskId = rs.getString(1);
                    taskIdDetails.put("taskId", taskId);
                }
                log.info("taskId :" + taskId);
            }
        } catch (Exception ex) {
            log.error("Exception Occured in getTaskIdDetailsForACVInGlblSrch :" + ex.toString());
            log.error(ex.toString(), ex);
        }
        return taskIdDetails;
    }

    /**
     * @param tiProcessId
     * @param tiRequestId
     * @return
     */
    public Date getRequestDeadLine(Long tiProcessId, Long tiRequestId) {
        log.info("tiProcessId :" + tiProcessId + "tiRequestId :" + tiRequestId);
        Date requestDeadLine = new Date();
        final String requestDeadLineForSQL = " SELECT REQUEST_DEADLINE FROM TI_REQUEST WHERE PROCESS_ID=? AND ID=? ";
        try {
            if (tiProcessId > 0) {
                SqlRowSet rs = jdbcTemplate.queryForRowSet(requestDeadLineForSQL, new Object[] { tiProcessId,
                        tiRequestId });
                if (rs.next()) {
                    requestDeadLine = rs.getTimestamp(1);
                }
            }
            log.info("requestDeadLine :" + requestDeadLine);
        } catch (Exception e) {
            log.error("Exception in getting Request DeadLine : " + e.toString());
            log.error(e.toString(), e);
        }
        return requestDeadLine;
    }

    /**
     * @return ACVDeadLineDays
     * @throws Exception
     */
    public double getACVDeadLineDays() throws Exception {
        double ACVDeadLineDays = 30;
        String strACVDeadLineDays = "0";
        String ACVDeadLineDaysQuery = "";
        try {
            ACVDeadLineDaysQuery = ccrQueries.getQueryByName(QueryConstants.ACV_REQUEST_DEADLINE_DAYS);
            SqlRowSet rs = jdbcTemplate.queryForRowSet(ACVDeadLineDaysQuery);
            if (rs.next()) {
                strACVDeadLineDays = rs.getString(1);
                if (strACVDeadLineDays != null) {
                    ACVDeadLineDays = Double.parseDouble(strACVDeadLineDays);
                }
            }
            log.info("ACVDeadLineDays :" + ACVDeadLineDays);
        } catch (Exception e) {
            log.error("Exception in getting getACVDeadLineDays : " + e.toString());
            log.error(e.toString(), e);
        }
        return ACVDeadLineDays;
    }

    /**
     * @return List<String>
     * @throws Exception
     */
    public List<String> getInternalScheduledACVIds() throws Exception {
        String scheduledInternalACVQuery = null;
        List<String> scheduledInternalACVList = null;
        try {
            scheduledInternalACVList = new ArrayList<String>();
            scheduledInternalACVQuery = ccrQueries.getQueryByName(QueryConstants.INTERNAL_SCHEDULED_ACV_IDS);
            SqlRowSet rs = jdbcTemplate.queryForRowSet(scheduledInternalACVQuery);
            while (rs.next()) {
                scheduledInternalACVList.add(rs.getString(1));
            }
        } catch (Exception e) {
            log.error("Exception in getting getInternalScheduledACVIds : " + e.toString());
            log.error(e.toString(), e);
        }
        return scheduledInternalACVList;
    }

    /**
     * @return List<String>
     * @throws Exception
     */
    public List<String> getProcessesForApprovalExpiration() throws Exception {
        String processIdsForTempAppExpQuery = null;
        List<String> tempAppExpList = null;
        try {
            tempAppExpList = new ArrayList<String>();
            processIdsForTempAppExpQuery = ccrQueries.getQueryByName(QueryConstants.TEMP_APPROVAL_IDS);
            SqlRowSet rs = jdbcTemplate.queryForRowSet(processIdsForTempAppExpQuery);
            while (rs.next()) {
                tempAppExpList.add(rs.getString(1));
            }
        } catch (Exception e) {
            log.error("Exception in getting getInternalScheduledACVIds : " + e.toString());
            log.error(e.toString(), e);
        }
        return tempAppExpList;
    }

    /**
     * @return List<String>
     * @throws Exception
     */
    public List<String> getProcessesForACV() throws Exception {
        String initiateACVQuery = null;
        List<String> initiateACVList = null;
        try {
            initiateACVList = new ArrayList<String>();
            initiateACVQuery = ccrQueries.getQueryByName(QueryConstants.PROCESS_IDS_FOR_ACV);
            SqlRowSet rs = jdbcTemplate.queryForRowSet(initiateACVQuery);
            while (rs.next()) {
                initiateACVList.add(rs.getString(1));
            }
        } catch (Exception e) {
            log.error("Exception in getting getProcessesForACV : " + e.toString());
            log.error(e.toString(), e);
        }
        return initiateACVList;
    }

    /**
     * @return boolean
     * @throws Exception
     */
    public boolean processInternalACV() throws Exception {
        boolean processInternalACV = false;
        String processInternalACVSQL = null;
        try {
            processInternalACVSQL = ccrQueries.getQueryByName(QueryConstants.PROCESS_INTERNAL_ACV);
            SqlRowSet rs = jdbcTemplate.queryForRowSet(processInternalACVSQL);
            if (rs.next()) {
                if (rs.getString(1).equalsIgnoreCase("Y")) {
                    processInternalACV = true;
                }
            }
            log.info("processInternalACV : " + processInternalACV);
        } catch (Exception e) {
            log.error("Exception occurred in  processInternalACV ::" + e.toString());
            log.error(e.toString(), e);
        }
        return processInternalACV;
    }
    
    /**
     * @param tiRequestId
     * @return
     */
    public String getBPMInstanceIdforExpiration(long tiRequestId, String activityCode, String ssoId) {
        log.info("tiRequestId :" + tiRequestId+" , activityCode :" + activityCode+" , ssoId :" + ssoId);
        String taskId = "0";
        String bpmInstanceIdQuery = "";
        Object[] params = new Object [2];
        try {
            if (tiRequestId > 0) {
                if (activityCode != null && !"".equalsIgnoreCase(activityCode)
                        && ActivityDataDTO.ACTIVITY_INC_EXP.equalsIgnoreCase(activityCode)) {
                    bpmInstanceIdQuery = ccrQueries.getQueryByName(QueryConstants.TASKID_FOR_INCEXP);
                    params[0] = ssoId;
                    params[1] = tiRequestId;
                } else if (activityCode != null
                        && !"".equalsIgnoreCase(activityCode)
                        && (ActivityDataDTO.ACTIVITY_TMP_EXP.equalsIgnoreCase(activityCode) || ActivityDataDTO.ACTIVITY_REC_EXP
                                .equalsIgnoreCase(activityCode))) {
                    bpmInstanceIdQuery = ccrQueries.getQueryByName(QueryConstants.TASKID_FOR_RECEXP_OR_TMPEXP);
                    params[0] = tiRequestId;
                    params[1] = activityCode;
                }
                SqlRowSet rs = jdbcTemplate.queryForRowSet(bpmInstanceIdQuery, params);
                if (rs.next()) {
                    taskId = rs.getString(1);
                }
            }
            log.info("taskId :" + taskId);
        } catch (Exception e) {
            log.error("Exception in getBPMInstanceIdforExpiration : " + e.toString());
            log.error(e.toString(), e);
        }
        return taskId;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess#isAllProductsImplemented(java.lang.Long)
     */
    public boolean isAllProductsImplemented(Long tiRequestId) {

        String checkIfAllProductsImplementedQuery = null;
        String howManyProductsRejectedInImpl = null;
        boolean everythingImplemented = true;
        try {

            Map implementationMap = getImplementationControlFlags(tiRequestId);
            Boolean isFirewall = (Boolean) implementationMap.get(TIProcessDTO.FW_IMPLEMENTATION_REQD_FLAG);
            Boolean isProxy = (Boolean) implementationMap.get(TIProcessDTO.PROXY_REQD_FLAG);
            Boolean isIPReg = (Boolean) implementationMap.get(TIProcessDTO.IPREG_IMPLEMENTATION_REQD_FLAG);
            Boolean isSecACL = (Boolean) implementationMap.get(TIProcessDTO.GNCC_REQD_FLAG);
            Boolean isAppSense = (Boolean) implementationMap.get(TIProcessDTO.APPSENSE_REQD_FLAG);

            int checkIfRejected = 0;
            if (null!= isFirewall && isFirewall)
                checkIfRejected++;
            if (null!= isProxy && isProxy)
                checkIfRejected++;
            if (null!= isIPReg && isIPReg)
                checkIfRejected++;
            if (null!= isSecACL && isSecACL)
                checkIfRejected++;
            if (null!=isAppSense && isAppSense)
                checkIfRejected++;
            log.info("checkIfRejected ::" + checkIfRejected);

            checkIfAllProductsImplementedQuery = ccrQueries
                    .getQueryByName(QueryConstants.HOW_MANY_PRODUCTS_REJECTED_IN_IMPL);
            SqlRowSet rs = jdbcTemplate
                    .queryForRowSet(checkIfAllProductsImplementedQuery, new Object[] { tiRequestId });
            int numberOfProdRejectedInImpl = 0;
            while (rs.next()) {
                numberOfProdRejectedInImpl++;
                log.info("Number of Product rejections  " + rs.getInt(1) + rs.getInt(2));
            }

            checkIfAllProductsImplementedQuery = ccrQueries.getQueryByName(QueryConstants.ALL_PRODUCTS_IMPLEMENTED);
            rs = jdbcTemplate.queryForRowSet(checkIfAllProductsImplementedQuery, new Object[] { tiRequestId });

            if (rs.next()) {
                log.info("rs.getString(1)" + rs.getString(1) + " rs.getString(2)" + rs.getString(2) + "rs.getString(3)"
                        + rs.getString(3) + "rs.getString(4)" + rs.getString(4) + "rs.getString(5)" + rs.getString(5));
                if (null != isFirewall && isFirewall && StringUtil.isNullorEmpty(rs.getString(1))) {
                    everythingImplemented = false;
                    checkIfRejected--;
                }

                if (null != isProxy && isProxy && StringUtil.isNullorEmpty(rs.getString(2))) {
                    everythingImplemented = false;
                    checkIfRejected--;
                }

                if (null != isIPReg && isIPReg && StringUtil.isNullorEmpty(rs.getString(3))) {
                    everythingImplemented = false;
                    checkIfRejected--;
                }

                if (null != isSecACL && isSecACL && StringUtil.isNullorEmpty(rs.getString(4))) {
                    everythingImplemented = false;
                    checkIfRejected--;
                }

                if (null != isAppSense && isAppSense && StringUtil.isNullorEmpty(rs.getString(5))) {
                    everythingImplemented = false;
                    checkIfRejected--;
                }

                
                if (!everythingImplemented) {
                    //its possible that some product was rejected and then re done.
                    if (numberOfProdRejectedInImpl >= checkIfRejected) {
                        everythingImplemented = true;
                    }
                }
            }
            log.info("numberOfProdRejectedInImpl::"+numberOfProdRejectedInImpl+"checkIfRejected::"+checkIfRejected+"everythingImplemented::" + everythingImplemented);
        } catch (Exception e) {
            log.error("Exception occurred in  processInternalACV ::" + e.toString());
            log.error(e.toString(), e);
        }
        return everythingImplemented;
    }
    
    /**
     * @param tiProcessId
     * @param tiAuditTrialId
     * @param ssoId
     * @return
     */
    public boolean validateUserIdForACV(String ssoId) {
        log.info("ssoId : " + ssoId);
        String userIdValidationQuery = "";
        boolean validUser = false;
        SqlRowSet rs = null;
        try {
            userIdValidationQuery = ccrQueries.getQueryByName(QueryConstants.VALIDATE_USERID_FOR_ACV);
            Object[] params = { ssoId };
            rs = jdbcTemplate.queryForRowSet(userIdValidationQuery, params);
            if (rs.next()) {
                if (rs.getInt(1) > 0) {
                    validUser = true;
                }
            }
        } catch (Exception ex) {
            log.error("Exception in validateUserIdForACV : " + ex.toString());
            log.error(ex.toString(), ex);
        }
        return validUser;
    }
    
    /**
     * @param tiRequestId
     * @return
     */
    public String getCcrIdWithVer(String tiRequestId) throws Exception {
        String ccrIdWithVer = "";
        try {
            List<Long> processIdList = new ArrayList<Long>();
            List<Long> versionNumberList = new ArrayList<Long>();
            String processIdQuery = "select process_id from ti_request where id=?";
            String versionNumberQuery = "select version_number from ti_request where id=?";
            SqlRowSet rs = jdbcTemplate.queryForRowSet(processIdQuery, new Object[] { Long.parseLong(tiRequestId) });
            while (rs.next()) {
                processIdList.add(rs.getLong(1));
            }
            rs = jdbcTemplate.queryForRowSet(versionNumberQuery, new Object[] { Long.parseLong(tiRequestId) });
            while (rs.next()) {
                versionNumberList.add(rs.getLong(1));
            }
            if(processIdList != null && processIdList.size() > 0 && versionNumberList != null && versionNumberList.size() > 0) {
                ccrIdWithVer = processIdList.get(0).toString() + "." + versionNumberList.get(0).toString(); 
            }
        } catch (Exception e) {
            log.error("Exception occurred in  getCcrIdWithVer ::" + e.toString());
            log.error(e.toString(), e);
            throw new ApplicationException("Exception has occurred :: getCcrIdWithVer() ", e);
        }
        return ccrIdWithVer;
    }
    
    /**
     * @param completedOnbehalfUser
     * @param tiRequestId
     * @return String
     * @throws Exception
     */
    public String getTaskIdForCompletedOnBehalf(String completedOnbehalfUser, long tiRequestId) throws Exception {
        log.info("completedOnbehalfUser : " + completedOnbehalfUser + ", tiRequestId : " + tiRequestId);
        String taskId = "0";
        String taskIdForOnBehalfUserQuery = null;
        try {
            if (tiRequestId > 0) {
                taskIdForOnBehalfUserQuery = ccrQueries.getQueryByName(QueryConstants.GET_TASKID_OF_ONBEHALFOFUSER);
                SqlRowSet rs = jdbcTemplate.queryForRowSet(taskIdForOnBehalfUserQuery, new Object[] { tiRequestId,
                        completedOnbehalfUser });

                if (rs.next()) {
                    taskId = rs.getString(1);
                }
                log.info("taskId :" + taskId);
            }
        } catch (Exception ex) {
            log.error("Exception Occured in getTaskIdForCompletedOnBehalf :" + ex.toString(), ex);
            log.error(ex.toString(), ex);
        }
        return taskId;
    }


    @Override
    public String getCurrentPhaseName(Long tiRequestId) {
        log.info("TiRequestId: " + tiRequestId);
        String phase = null;
        try {
            String currentPhaseQuery = ccrQueries.getQueryByName(QueryConstants.GET_CURRENT_PHASE);
            SqlRowSet rs = jdbcTemplate.queryForRowSet(currentPhaseQuery, tiRequestId);
            if (rs.next()) {
                phase = rs.getString(1);
            }
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }
        log.debug("Current Phase: " + phase);
        return phase;
}

    @Override
    public Boolean containsDeleteRules(Long tiRequestId) {
        log.info("TiRequestId: " + tiRequestId);
        Boolean isDelete = false;
        SqlRowSet rs;
        try {
            String checkIsDeletedQuery = ccrQueries.getQueryByName(QueryConstants.CHECK_IS_DELETE);
            rs = jdbcTemplate.queryForRowSet(checkIsDeletedQuery.replace(":tiRequestId",tiRequestId.toString()));
            if(rs.next()) {
                isDelete = true;
            }
            
            
        } catch (Exception e) {
            log.error(e.toString(), e);
            throw e;
        }
        log.debug("isDelete: " + isDelete);
        return isDelete;
    }
    
    /**
     * @param tiRequestId
     * @return Boolean isACVCompleted
     * @throws Exception
     */
    public Boolean isACVCompleted(Long tiRequestId) {
        log.info("tiRequestId: " + tiRequestId);
        Boolean isACVCompleted = true;
        SqlRowSet rs;
        String checkIsACVCompletedQuery = null;
        try {
            checkIsACVCompletedQuery = ccrQueries.getQueryByName(QueryConstants.GET_ACV_PENDING_TASK_COUNT);
            rs = jdbcTemplate.queryForRowSet(checkIsACVCompletedQuery, new Object[] { tiRequestId });
            if (rs.next() && rs.getInt(1) > 0) {
                isACVCompleted = false;
            }
        } catch (Exception e) {
            log.error("Exception Occured in getTaskIdForCompletedOnBehalf :" + e.toString(), e);
            log.error(e.toString(), e);
        }
        log.debug("isACVCompleted: " + isACVCompleted);
        return isACVCompleted;
    }

    /**
     * @param tiRequestId
     * @return ACVDeadLineDays
     * @throws Exception
     */
    public int getACVLogExpDeadLineDays(Long tiRequestId) throws Exception {
        log.info("tiRequestId: " + tiRequestId);
        int ACVLogExpDeadLineDays = 0;
        String ACVLogExpDeadLineDaysQuery = "";
        try {
            ACVLogExpDeadLineDaysQuery = ccrQueries.getQueryByName(QueryConstants.ACV_LOG_EXP_DEADLINE_DAYS);
            SqlRowSet rs = jdbcTemplate.queryForRowSet(ACVLogExpDeadLineDaysQuery, new Object[] { tiRequestId });
            if (rs.next()) {
                ACVLogExpDeadLineDays = rs.getInt(1);
            }
            log.info("ACVLogExpDeadLineDays :" + ACVLogExpDeadLineDays);
        } catch (Exception e) {
            log.error("Exception Occured in getACVLogExpDeadLineDays : " + e.toString());
            log.error(e.toString(), e);
        }
        return ACVLogExpDeadLineDays;
    }

    /**
     * @param tiRequestId
     * @return Boolean isACVLoggingScheduled
     * @throws Exception
     */
    public Boolean isACVLoggingScheduled(Long tiRequestId) throws Exception {
        log.info("tiRequestId: " + tiRequestId);
        Boolean isACVLoggingScheduled = false;
        SqlRowSet rs;
        String checkIsACVLogScheduledQuery = null;
        try {
            checkIsACVLogScheduledQuery = ccrQueries.getQueryByName(QueryConstants.GET_ACV_LOG_SCHEDULED_TASK_COUNT);
            rs = jdbcTemplate.queryForRowSet(checkIsACVLogScheduledQuery, new Object[] { tiRequestId });
            if (rs.next() && rs.getInt(1) > 0) {
                isACVLoggingScheduled = true;
            }
        } catch (Exception e) {
            log.error("Exception Occured in isACVLoggingScheduled :" + e.toString(), e);
            log.error(e.toString(), e);
        }
        log.debug("isACVLoggingScheduled: " + isACVLoggingScheduled);
        return isACVLoggingScheduled;
    }

    /**
     * @param tiRequestId
     * @return List<String>
     * @throws Exception
     */
    public List<String> getTaskIdForACLogActivity(long tiRequestId) throws Exception {
        log.info(" tiRequestId : " + tiRequestId);
        List<String> result = new ArrayList<String>();
        String tasktIdForACVLogQuery = null;
        try {
            if (tiRequestId > 0) {
                tasktIdForACVLogQuery = ccrQueries.getQueryByName(QueryConstants.GET_TASKID_FOR_ACV_LOG_ACTIVITY);
                SqlRowSet rs = jdbcTemplate.queryForRowSet(tasktIdForACVLogQuery, new Object[] { tiRequestId });
                if (rs.next()) {
                    result.add(rs.getString(1));
                    result.add(rs.getString(2));
                }
                log.info("taskId :" + result.get(0) + " and auditId :" + result.get(1));
            }
        } catch (Exception ex) {
            log.error("Exception Occured in getTaskIdForACLogActivity :" + ex.toString(), ex);
            log.error(ex.toString(), ex);
        }
        return result;
    }

    /**
     * @param activityCode
     * @return List<String>
     */
    public List<String> getScheduledProcessIds(String activityCode) {
        log.debug("activityCode :" + activityCode);
        String processIdsQuery = null;
        List<String> processIdList = null;
        try {
            processIdList = new ArrayList<String>();
            processIdsQuery = ccrQueries.getQueryByName(QueryConstants.GET_SCHEDULED_PROCESS_IDS);
            SqlRowSet rs = jdbcTemplate.queryForRowSet(processIdsQuery, new Object[] { activityCode });
            while (rs.next()) {
                processIdList.add(rs.getString(1));
            }
        } catch (Exception e) {
            log.error("Exception in getting getScheduledProcessIds : " + e.toString());
            log.error(e.toString(), e);
        }
        return processIdList;
    }
    
    /**
     * @param tiRequestId
     * @return Boolean isACVLoggingScheduled
     * @throws Exception
     */
    public Boolean isACVScheduled(Long tiRequestId) throws Exception {
        log.info("tiRequestId: " + tiRequestId);
        Boolean isACVScheduled = false;
        SqlRowSet rs;
        String checkIsACVScheduledQuery = null;
        try {
            checkIsACVScheduledQuery = ccrQueries.getQueryByName(QueryConstants.GET_ACV_SCHEDULED_TASK_COUNT);
            rs = jdbcTemplate.queryForRowSet(checkIsACVScheduledQuery, new Object[] { tiRequestId });
            if (rs.next() && rs.getInt(1) > 0) {
                isACVScheduled = true;
            }
        } catch (Exception e) {
            log.error("Exception Occured in isACVScheduled :" + e.toString(), e);
            log.error(e.toString(), e);
        }
        log.debug("isACVScheduled: " + isACVScheduled);
        return isACVScheduled;
    }
    
    /**
     * @param tiRequestId
     * @return Boolean isTempApproved
     * @throws Exception
     */
    public Boolean isTempApprovedInPreviousPhase(Long tiRequestId) throws Exception {
        log.info("tiRequestId: " + tiRequestId);
        Boolean isTempApproved = false;
        SqlRowSet rs;
        String checkIsTempApprovedQuery = null;
        try {
            checkIsTempApprovedQuery = ccrQueries.getQueryByName(QueryConstants.GET_COUNT_OF_TEMP_APP_IN_PREV_PHASE);
            rs = jdbcTemplate.queryForRowSet(checkIsTempApprovedQuery, new Object[] { tiRequestId, tiRequestId,
                    tiRequestId, tiRequestId, tiRequestId });
            if (rs.next() && rs.getInt(1) > 0) {
                isTempApproved = true;
            }
        } catch (Exception e) {
            log.error("Exception Occured in isTempApproved :" + e.toString(), e);
            log.error(e.toString(), e);
        }
        log.debug("isTempApproved: " + isTempApproved);
        return isTempApproved;
    }
    
    /**
     * @param tiRequestId
     * @return String previousTaskCode
     * @throws Exception
     */
    public String getPreviousTaskCode(Long tiRequestId) {
        log.info("TiRequestId: " + tiRequestId);
        String taskCode = null;
        String taskCodeFetchQuery = null;
        SqlRowSet rs = null;
        try {
            taskCodeFetchQuery = ccrQueries.getQueryByName(QueryConstants.GET_TASK_CODE_OF_PREVIOUS_ACTIVITY);
            rs = jdbcTemplate.queryForRowSet(taskCodeFetchQuery, tiRequestId, tiRequestId);
            if (rs.next()) {
                taskCode = rs.getString(1);
            }
        } catch (Exception e) {
            log.error("Exception Occured in getPreviousTaskCode :" + e.toString(), e);
            log.error(e.toString(), e);
        }
        log.debug("Previous TaskCode: " + taskCode);
        return taskCode;
    }
    
    /**
     * @param tiRequestId
     * @param gisMandateFlag
     */
    public void updateGISMandateFlag(long tiRequestId, String gisMandateFlag) {
        log.debug("tiRequestId : " + tiRequestId + ", gisMandateFlag : " + gisMandateFlag);
        int updateCount = 0;
        final String updateByPassSNOWSQL = " UPDATE TI_REQUEST SET GIS_MANDATE_FLAG=? WHERE ID=? ";
        try {
            updateCount = jdbcTemplate.update(updateByPassSNOWSQL, new Object[] { gisMandateFlag, tiRequestId });
            log.debug("updateCount :" + updateCount);
        } catch (Exception e) {
            log.error("Exception while updating GIS Mandate flag : " + e.toString());
            log.error(e.toString(), e);
        }
    }

    /**
     * @param tiRequestId
     * @return gisMandateFlag
     */
    public String getGISMandateFlag(long tiRequestId) {
        log.info("tiRequestId :" + tiRequestId);
        String gisMandateFlag = "";
        final String ByPassSnowFlagSQL = " SELECT NVL(GIS_MANDATE_FLAG,'') FROM TI_REQUEST WHERE ID=? ";
        try {
            if (tiRequestId > 0) {
                SqlRowSet rs = jdbcTemplate.queryForRowSet(ByPassSnowFlagSQL, new Object[] { tiRequestId });
                if (rs.next()) {
                    gisMandateFlag = rs.getString(1);
                }
            }
            log.info("gisMandateFlag :" + gisMandateFlag);
        } catch (Exception e) {
            log.error("Exception in getting GIS Mandate flag : " + e.toString());
            log.error(e.toString(), e);
        }
        return gisMandateFlag;
    }

    /**
     * @param tiRequestId
     * @return Boolean isGISMandated
     * @throws Exception
     */
    public Boolean isGISMandatedInPreviousPhase(Long tiRequestId) {
        log.info("tiRequestId: " + tiRequestId);
        Boolean isGISMandated = false;
        SqlRowSet rs;
        String checkIsGISMandatedQuery = null;
        try {
            checkIsGISMandatedQuery = ccrQueries.getQueryByName(QueryConstants.GET_COUNT_OF_GIS_MANDATED_IN_PREV_PHASE);
            rs = jdbcTemplate.queryForRowSet(checkIsGISMandatedQuery, new Object[] { tiRequestId, tiRequestId,
                    tiRequestId, tiRequestId, tiRequestId });
            if (rs.next() && rs.getInt(1) > 0) {
                isGISMandated = true;
            }
        } catch (Exception e) {
            log.error("Exception Occured in isGISMandatedInPreviousPhase :" + e.toString(), e);
            log.error(e.toString(), e);
        }
        log.debug("isGISMandated: " + isGISMandated);
        return isGISMandated;
    }
    
    /**
     * @return List<Long>
     * @throws Exception
     */
    public List<Long> getTirequestIdsOfACV() throws Exception {
        String tiRequestIdsOfACVQuery = null;
        List<Long> tiRequestIdsList = null;
        try {
            tiRequestIdsList = new ArrayList<Long>();
            tiRequestIdsOfACVQuery = ccrQueries.getQueryByName(QueryConstants.TI_REQUEST_IDS_OF_ACV);
            SqlRowSet rs = jdbcTemplate.queryForRowSet(tiRequestIdsOfACVQuery);
            while (rs.next()) {
                tiRequestIdsList.add(rs.getLong(1));
            }
        } catch (Exception e) {
            log.error("Exception in getTirequestIdsOfACV :" + e);
            log.error(e.toString(), e);
        }
        return tiRequestIdsList;
    }
    
    /**
     * method to get the request validation deadline
     * 
     * @return reqValDeadLineDays
     * @throws Exception
     */
    public double getReqValDeadLine() {
        double reqValDeadLineDays = 30;
        String strReqValDeadLineDays = "0";
        String reqValDeadLineDaysQuery = "";
        try {
            reqValDeadLineDaysQuery = ccrQueries.getQueryByName(QueryConstants.GET_REQUEST_VALIDATION_DEADLINE);
            SqlRowSet rs = jdbcTemplate.queryForRowSet(reqValDeadLineDaysQuery);
            if (rs.next()) {
                strReqValDeadLineDays = rs.getString(1);
                if (strReqValDeadLineDays != null) {
                    reqValDeadLineDays = Double.parseDouble(strReqValDeadLineDays);
                }
            }
            log.info("reqValDeadLineDays :" + reqValDeadLineDays);
        } catch (Exception e) {
            log.error("Exception in getReqValDeadLine : " + e);
            log.error(e.toString(), e);
        }
        return reqValDeadLineDays;
    }

    /**
     * methodd to check if the request validation is completed or not
     * 
     * @param tiRequestId
     * @return Boolean isRequestValidationCompleted
     * @throws Exception
     */
    public Boolean isRequestValidationCompleted(Long tiRequestId) {
        log.info("tiRequestId: " + tiRequestId);
        Boolean isReqValCompleted = true;
        SqlRowSet rs;
        String checkisReqValCompletedQuery = null;
        try {
            checkisReqValCompletedQuery = ccrQueries.getQueryByName(QueryConstants.GET_REQ_VAL_PENDING_TASK_COUNT);
            rs = jdbcTemplate.queryForRowSet(checkisReqValCompletedQuery, new Object[] { tiRequestId });
            if (rs.next() && rs.getInt(1) > 0) {
                isReqValCompleted = false;
            }
        } catch (Exception e) {
            log.error("Exception Occured in isRequestValidationCompleted :" + e.toString(), e);
            log.error(e.toString(), e);
        }
        log.debug("isReqValCompleted: " + isReqValCompleted);
        return isReqValCompleted;
    }

    /**
     * method to fetch the task Id for request validation activity
     * 
     * @param tiRequestId
     * @return reqValTaskId
     * @throws Exception
     */
    public Long getTaskIdForRequestValidation(long tiRequestId) {
        log.info("tiRequestId : " + tiRequestId);
        SqlRowSet rs = null;
        Long reqValTaskId = 0l;
        String taskIdForRequestValidationQuery = null;
        try {
            if (tiRequestId > 0) {
                taskIdForRequestValidationQuery = ccrQueries
                        .getQueryByName(QueryConstants.TASKID_FOR_REQUEST_VALIDATION);
                rs = jdbcTemplate.queryForRowSet(taskIdForRequestValidationQuery, new Object[] { tiRequestId });
                if (rs.next()) {
                    reqValTaskId = rs.getLong(1);
                }
                log.debug("reqValTaskId :" + reqValTaskId);
            }
        } catch (Exception ex) {
            log.error("Exception Occured in getTaskIdForRequestValidation :" + ex.toString(), ex);
            log.error(ex.toString(), ex);
        }
        return reqValTaskId;
    }

    /**
     * @param tiRequestId
     * @param reconADRFlag
     */
    public void updateReconADRFlag(long tiRequestId, String reconADRFlag) {
        log.info("tiRequestId : " + tiRequestId + " and reconADRFlag as : " + reconADRFlag);
        int updateCount = 0;
        final String updatereconADRFlagSQL = " UPDATE TI_REQUEST SET RECON_ADR_FLAG=? WHERE ID=? ";
        try {
            updateCount = jdbcTemplate.update(updatereconADRFlagSQL, new Object[] { reconADRFlag, tiRequestId });
            log.info("updateCount :" + updateCount);
        } catch (Exception e) {
            log.error("Exception while updating reconADRFlag : " + e.toString());
            log.error(e.toString(), e);
        }
    }

    /**
     * @param tiRequestId
     * @return
     */
    public String getReconADRFlag(long tiRequestId) {
        log.info("tiRequestId :" + tiRequestId);
        String reconADRFlag = "";
        final String reconADRFlagSQL = " SELECT NVL(RECON_ADR_FLAG,'') FROM TI_REQUEST WHERE ID=? ";
        try {
            if (tiRequestId > 0) {
                SqlRowSet rs = jdbcTemplate.queryForRowSet(reconADRFlagSQL, new Object[] { tiRequestId });
                if (rs.next()) {
                    reconADRFlag = rs.getString(1);
                }
            }
            log.info("snowByPassFlag :" + reconADRFlag);
        } catch (Exception e) {
            log.error("Exception in getting reconADRFlag : " + e.toString());
            log.error(e.toString(), e);
        }
        return reconADRFlag;
    }
    
    /**
     * method to fetch the activityCode before RISO Approval
     * 
     * @param tiRequestId
     * @return activityCode
     * @throws Exception
     */
    public String getPreviousActivityCode(long tiRequestId) {
        log.info("tiRequestId : " + tiRequestId);
        SqlRowSet rs = null;
        String activityCode = "";
        String activityCodeQuery = null;
        try {
            if (tiRequestId > 0) {
                activityCodeQuery = ccrQueries
                        .getQueryByName(QueryConstants.GET_PREVIOUS_ACTIVITY);
                rs = jdbcTemplate.queryForRowSet(activityCodeQuery, new Object[] { tiRequestId });
                if (rs.next()) {
                    activityCode = rs.getString(1);
                }
                log.debug("activityCode :" + activityCode);
            }
        } catch (Exception ex) {
            log.error("Exception Occured in getPreviousActivityCode :" + ex.toString(), ex);
            log.error(ex.toString(), ex);
        }
        return activityCode;
    }

    /**
     * @param processId
     * @param versionNo
     * @return
     */
    private String updateTempApprovedByForCcr(long processId, int versionNo) {
        String updateTempApprovedByForCcrQuery = ccrQueries.getQueryByName(TEMP_APPROVED_BY_CCR);
        String tempApprovedBy = null;
        SqlRowSet rs = jdbcTemplate.queryForRowSet(updateTempApprovedByForCcrQuery,
                new Object[] { processId, versionNo });
        if (rs.next()) {
            tempApprovedBy = rs.getString(1);
        }
        return tempApprovedBy;
    }
    
    /**
     * @return List<Long>
     * @throws Exception
     */
    public List<Long> getValidTirequestIdOfCCRId(Long ccrId) throws Exception {
        String tiRequestIdsOfACVQuery = null;
        List<Long> tiRequestIdsList = null;
        try {
            tiRequestIdsList = new ArrayList<Long>();
            tiRequestIdsOfACVQuery = ccrQueries.getQueryByName(QueryConstants.GET_VALID_TI_REQUEST_IDS_OF_CCRID);
            SqlRowSet rs = jdbcTemplate.queryForRowSet(tiRequestIdsOfACVQuery, new Object[] { ccrId });
            while (rs.next()) {
                tiRequestIdsList.add(rs.getLong(1));
            }
        } catch (Exception e) {
            log.error("Exception in getValidTirequestIdOfCCRId :" + e);
            log.error(e.toString(), e);
        }
        return tiRequestIdsList;
    }
}
