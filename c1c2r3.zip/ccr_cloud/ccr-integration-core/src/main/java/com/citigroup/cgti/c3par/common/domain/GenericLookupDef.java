package com.citigroup.cgti.c3par.common.domain;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import com.citigroup.cgti.c3par.domain.Base;


/**
 * The Class GenericLookupDef.
 */
public class GenericLookupDef extends Base implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** The name. */
    private String name;

    /** The label1. */
    private String label1;

    /** The label2. */
    private String label2;
    
    private Set<GenericLookup> genericLookup = 
			new HashSet<GenericLookup>(0);


    /**
     * Gets the label1.
     *
     * @return the label1
     */
    public String getLabel1() {
	return label1;
    }

    /**
     * Sets the label1.
     *
     * @param label1 the new label1
     */
    public void setLabel1(String label1) {
	this.label1 = label1;
    }

    /**
     * Gets the label2.
     *
     * @return the label2
     */
    public String getLabel2() {
	return label2;
    }

    /**
     * Sets the label2.
     *
     * @param label2 the new label2
     */
    public void setLabel2(String label2) {
	this.label2 = label2;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.domain.Name#getName()
     */
    public String getName() {
	return name;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.domain.Name#setName(java.lang.String)
     */
    public void setName(String name) {
	this.name = name;
    }

	public Set<GenericLookup> getGenericLookup() {
		return genericLookup;
	}

	public void setGenericLookup(Set<GenericLookup> genericLookup) {
		this.genericLookup = genericLookup;
	}

	 
    
    
}
