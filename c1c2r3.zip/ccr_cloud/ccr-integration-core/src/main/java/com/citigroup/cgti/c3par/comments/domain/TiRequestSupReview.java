package com.citigroup.cgti.c3par.comments.domain;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.Role;
import com.citigroup.cgti.c3par.domain.TIRequest;

/*
 * @nc43495
 */
public class TiRequestSupReview extends Base{
	
	private static final long serialVersionUID = 1L;

	private TIRequest tiRequest;
	
	private Role requestorRole;
	
	private Role reviewerRole;

	public TIRequest getTiRequest() {
		return tiRequest;
	}

	public void setTiRequest(TIRequest tiRequest) {
		this.tiRequest = tiRequest;
	}

	public Role getRequestorRole() {
		return requestorRole;
	}

	public void setRequestorRole(Role requestorRole) {
		this.requestorRole = requestorRole;
	}

	public Role getReviewerRole() {
		return reviewerRole;
	}

	public void setReviewerRole(Role reviewerRole) {
		this.reviewerRole = reviewerRole;
	}
	
	
	
	

}
