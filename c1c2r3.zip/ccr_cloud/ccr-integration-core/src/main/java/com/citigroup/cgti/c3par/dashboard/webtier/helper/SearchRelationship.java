package com.citigroup.cgti.c3par.dashboard.webtier.helper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.ScenarioNames;
import com.citigroup.cgti.c3par.dao.BusinessUnitDAO;
import com.citigroup.cgti.c3par.dao.C3parUsersDAO;
import com.citigroup.cgti.c3par.dao.CitiHierMasterDAO;
import com.citigroup.cgti.c3par.dao.CommonLookupDataDAO;
import com.citigroup.cgti.c3par.dao.RelCitiHierXrefDAO;
import com.citigroup.cgti.c3par.dao.RelationshipDAO;
import com.citigroup.cgti.c3par.dao.ThirdPartyDAO;
import com.citigroup.cgti.c3par.dao.UserCitiHierXrefDAO;
import com.citigroup.cgti.c3par.model.EntitlementInstanceEntity;
import com.citigroup.cgti.c3par.model.RelationshipEntity;
import com.citigroup.cgti.c3par.util.C3parStaticNames;
import com.citigroup.cgti.c3par.webtier.helper.FieldValidator;
import com.mentisys.dao.AccessObject;
import com.mentisys.dao.DatabaseException;
import com.mentisys.dao.DatabaseSession;
import com.mentisys.dao.query.Condition;
import com.mentisys.dao.query.Expression;
import com.mentisys.dao.query.JoinExpression;
import com.mentisys.dao.query.LogicalExpression;
import com.mentisys.dao.query.LogicalOperator;
import com.mentisys.dao.query.Operator;
import com.mentisys.dao.query.OperatorExpression;
import com.mentisys.dao.query.QueryException;
import com.mentisys.dao.query.SubExpression;


/**
 * The Class SearchRelationship.
 */
public class SearchRelationship extends AccessObject {
    // private Long userId;

    // private boolean isAdmin;

    /** The attrs. */
    private RelationshipSearchAttributes attrs;

    /** The log. */
    private static Logger log = Logger.getLogger(SearchRelationship.class);

    /**
     * Instantiates a new search relationship.
     *
     * @param session the session
     * @param searchFilters the search filters
     */
    public SearchRelationship(DatabaseSession session,
	    RelationshipSearchAttributes searchFilters) {
	super(session);
	this.attrs = searchFilters;
    }

    /**
     * Instantiates a new search relationship.
     *
     * @param session the session
     */
    public SearchRelationship(DatabaseSession session) {
	super(session);
    }

    /* (non-Javadoc)
     * @see com.mentisys.dao.AccessObject#loadModelReferences(java.lang.Object)
     */
    protected void loadModelReferences(Object obj) throws DatabaseException {
    }

    /* (non-Javadoc)
     * @see com.mentisys.dao.AccessObject#createModel(java.sql.ResultSet)
     */
    protected Object createModel(ResultSet rs) throws DatabaseException {
	RelationshipDAO dao = new RelationshipDAO(getSession());
	RelationshipEntity relEntity = new RelationshipEntity();
	relEntity.setReferencesLoaded(false);
	relEntity.setId(getLongFromResultSet(rs, RelationshipDAO.COLUMN_ID));

	relEntity.setPrimaryKey(relEntity.getId());
	relEntity.setName(getStringFromResultSet(rs,
		RelationshipDAO.COLUMN_NAME));
	log.info("Relationship id " + relEntity.getId() + " Name "
		+ relEntity.getName());
	relEntity.setPurpose(getStringFromResultSet(rs,
		RelationshipDAO.COLUMN_PURPOSE));
	relEntity.setStatus(getStringFromResultSet(rs,
		RelationshipDAO.COLUMN_STATUS));
	relEntity.setConnectivityExists(getStringFromResultSet(rs,
		RelationshipDAO.COLUMN_CONNECTIVITYEXISTS));
	relEntity.setAccessCitiData(getStringFromResultSet(rs,
		RelationshipDAO.COLUMN_ACCESSCITIDATA));
	relEntity.setAccessCustomerData(getStringFromResultSet(rs,
		RelationshipDAO.COLUMN_ACCESSCUSTOMERDATA));
	relEntity.setIsOutsourceProvider(getStringFromResultSet(rs,
		RelationshipDAO.COLUMN_ISOUTSOURCEPROVIDER));
	relEntity.setOspServiceName(getStringFromResultSet(rs,
		RelationshipDAO.COLUMN_OSPSERVICENAME));
	relEntity.setRequesterId(getStringFromResultSet(rs,
		RelationshipDAO.COLUMN_REQUESTERID));
	/*relEntity.setBusinessUnitId(getLongFromResultSet(rs,
		RelationshipDAO.COLUMN_BUSINESSUNIT_ID));*/
	relEntity.setThirdPartyId(getLongFromResultSet(rs,
		RelationshipDAO.COLUMN_THIRDPARTY_ID));
	/*relEntity.setEntInstanceId(getLongFromResultSet(rs,
		RelationshipDAO.COLUMN_ENTINSTANCEID));*/
	relEntity.setRelationshipType(getStringFromResultSet(rs,
		RelationshipDAO.COLUMN_RELATIONSHIPTYPE));
	relEntity.setLookup(dao.loadLookupWithId(getLongFromResultSet(rs,
		RelationshipDAO.COLUMN_LOOKUP_ID)));
	relEntity.setRequesterResourceTypeId(getLongFromResultSet(rs,
		RelationshipDAO.COLUMN_REQUESTERRESOURCETYPE_ID));
	relEntity.setTargetResourceTypeId(getLongFromResultSet(rs,
		RelationshipDAO.COLUMN_TARGETRESOURCETYPE_ID));

	/*
	 * ThirdPartyDAO tpDao = new ThirdPartyDAO(getSession());
	 * relEntity.setThirdParty(tpDao.get(relEntity.getThirdPartyId()));
	 * 
	 * BusinessUnitDAO buDao = new BusinessUnitDAO(getSession());
	 * relEntity.setBusinessUnit(buDao.get(relEntity.getBusinessUnitId()));
	 * 
	 * ResourceTypeDAO resourceTypeDAO = new ResourceTypeDAO(getSession());
	 * relEntity.setRequesterResourceType(resourceTypeDAO.get(relEntity
	 * .getRequesterResourceTypeId()));
	 * 
	 * relEntity.setTargetResourceType(resourceTypeDAO.get(relEntity
	 * .getTargetResourceTypeId()));
	 */

	return relEntity;
    }

    /* (non-Javadoc)
     * @see com.mentisys.dao.AccessObject#getQuerySelectString()
     */
    protected String getQuerySelectString() {
	String stmt = null;
	String relationshipType = attrs.getRelationshipType();

	stmt = "SELECT DISTINCT  "
	    + getQualifiedColumnName(RelationshipDAO.TABLE,
		    RelationshipDAO.COLUMN_ID, true)
		    + getQualifiedColumnName(RelationshipDAO.TABLE,
			    RelationshipDAO.COLUMN_NAME, true)
			    + getQualifiedColumnName(RelationshipDAO.TABLE,
				    RelationshipDAO.COLUMN_PURPOSE, true)
				    + getQualifiedColumnName(RelationshipDAO.TABLE,
					    RelationshipDAO.COLUMN_STATUS, true)
					    + getQualifiedColumnName(RelationshipDAO.TABLE,
						    RelationshipDAO.COLUMN_RELATIONSHIPTYPE, true)
						    + getQualifiedColumnName(RelationshipDAO.TABLE,
							    RelationshipDAO.COLUMN_CONNECTIVITYEXISTS, true)
							    + getQualifiedColumnName(RelationshipDAO.TABLE,
								    RelationshipDAO.COLUMN_ACCESSCITIDATA, true)
								    + getQualifiedColumnName(RelationshipDAO.TABLE,
									    RelationshipDAO.COLUMN_ISOUTSOURCEPROVIDER, true)
									    + getQualifiedColumnName(RelationshipDAO.TABLE,
										    RelationshipDAO.COLUMN_ACCESSCUSTOMERDATA, true)
										    + getQualifiedColumnName(RelationshipDAO.TABLE,
											    RelationshipDAO.COLUMN_OSPSERVICENAME, true) 
											    + getQualifiedColumnName(RelationshipDAO.TABLE,
												    RelationshipDAO.COLUMN_REQUESTERID, true)
													    + getQualifiedColumnName(RelationshipDAO.TABLE,
														    RelationshipDAO.COLUMN_THIRDPARTY_ID, true)
															    + getQualifiedColumnName(RelationshipDAO.TABLE,
																    RelationshipDAO.COLUMN_LOOKUP_ID, true)
																    + getQualifiedColumnName(RelationshipDAO.TABLE,
																	    RelationshipDAO.COLUMN_REQUESTERRESOURCETYPE_ID, true)
																	    + getQualifiedColumnName(RelationshipDAO.TABLE,
																		    RelationshipDAO.COLUMN_TARGETRESOURCETYPE_ID, false);
	if(relationshipType != null && (relationshipType.equals(C3parStaticNames.THIRD_PARTY) ||  
		relationshipType.equals(C3parStaticNames.U_TURN) || relationshipType.equals(C3parStaticNames.TEMPLATE_OBJ) ||
		relationshipType.equals(C3parStaticNames.IP_TEMPLATE) || relationshipType.equals(C3parStaticNames.PORT_TEMPLATE))){
	    stmt = stmt
	    + getFromClause(new String[] { RelationshipDAO.TABLE,  CommonLookupDataDAO.TABLE, 
		    BusinessUnitDAO.TABLE,  C3parUsersDAO.TABLE, ThirdPartyDAO.TABLE , RelCitiHierXrefDAO.TABLE,
		    CitiHierMasterDAO.TABLE, UserCitiHierXrefDAO.TABLE  });
	} else {
	    stmt = stmt
	    + getFromClause(new String[] { RelationshipDAO.TABLE,  CommonLookupDataDAO.TABLE, 
		    BusinessUnitDAO.TABLE,  C3parUsersDAO.TABLE , RelCitiHierXrefDAO.TABLE,
		    CitiHierMasterDAO.TABLE, UserCitiHierXrefDAO.TABLE });
	}
	return stmt;
    }

    /* (non-Javadoc)
     * @see com.mentisys.dao.AccessObject#getWhereExpression(com.mentisys.dao.query.Condition)
     */
    protected String getWhereExpression(Condition c) {
	StringBuffer buf = new StringBuffer();

	/*
	 * if (!isAdmin) { // String groupId =
	 * CommonCode.getGroupId(this.userId); // convert ids to String and get
	 * all List entInstEntities = CommonCode
	 * .getEntitlementInstance(this.userId);
	 * 
	 * String instids = convertListToString(entInstEntities); buf.append("
	 * AND " + RelationshipDAO.COLUMN_ENTINSTANCEID + " IN (" + instids +
	 * ")"); // buf.append(" AND " + EntitlementXrefDAO.COLUMN_GROUP_ID + " = " + //
	 * groupId ); }
	 */

	buf.append(c.getWhereExpression());
	/* ENTITLEMENT check in all the sectors the user is entitled */
	/*buf.append(" AND " + EntitlementInstanceDAO.COLUMN_INACTIVE + " = 'N'");
		if (attrs.getEntInstList() != null && attrs.getEntInstList().size() > 0) {
			String instids = convertListToString(attrs.getEntInstList());
			buf.append(" AND " + RelationshipDAO.COLUMN_ENTINSTANCEID + " IN ("
					+ instids + ")");
		}*/
	return buf.toString();
    }

    /**
     * Query with pagination.
     *
     * @param condition the condition
     * @param loadRefs the load refs
     * @param pageNum the page num
     * @param pageSize the page size
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List queryWithPagination(Condition condition, boolean loadRefs,
	    int pageNum, int pageSize) throws DatabaseException {
	if (pageNum == 0)
	    throw new RuntimeException("Page Number should start at 1");
	ArrayList list;
	String queryToExecute;
	DatabaseSession session;
	PreparedStatement st;
	ResultSet rs;
	list = new ArrayList();
	StringBuffer sb = new StringBuffer();
	sb.append("select *  from ( select a.*, rownum rnum from ( ");
	sb.append(getQuerySelectString());
	String where = getWhereExpression(condition);
	if (!"".equals(where)) {
	    sb.append(" WHERE ");
	    sb.append(where);
	}
	String groupBy = getGroupByExpression(condition);
	if (!"".equals(groupBy))
	    sb.append(" GROUP BY " + groupBy);
	String orderBy = getOrderByExpression(condition);
	if (!"".equals(orderBy))
	    sb.append(" ORDER BY " + orderBy);

	sb.append(" ) a where rownum <= ");
	sb.append((pageNum * pageSize) + 1);
	sb.append(" ) where rnum >= ");
	sb.append((pageNum * pageSize) - pageSize + (pageNum==1?1:2));
	queryToExecute = sb.toString();
	log.debug("Sql is :- " + queryToExecute);
	session = getSession();
	Connection connection = null;
	Object obj = null;
	st = null;
	rs = null;
	try {
	    connection = session.getConnection();
	    st = connection.prepareStatement(queryToExecute);
	    condition.setValuesToStatement(st);
	    for (rs = st.executeQuery(); rs.next(); list.add(obj)) {
		obj = createModel(rs);
		if (loadRefs)
		    loadModelReferences(obj);
	    }

	} catch (SQLException e) {
	    log.error("Exception during query :- " + e);

	    throw new DatabaseException("Could not run query = "
		    + queryToExecute, e);
	} catch (QueryException e) {
	    throw new DatabaseException("Could not run query = "
		    + queryToExecute, e);
	} finally {
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return list;
    }

    /**
     * Gets the count.
     *
     * @return the count
     * @throws DatabaseException the database exception
     */
    public int  getCount() throws DatabaseException {
	Condition condition= getQueryCondition();
	String queryToExecute;
	DatabaseSession session;
	PreparedStatement st;
	ResultSet rs;
	int cnt=0;
	StringBuffer sb = new StringBuffer();
	sb.append("select count(*) cnt  from ( ");
	sb.append(getQuerySelectString());
	String where = getWhereExpression(condition);
	if (!"".equals(where)) {
	    sb.append(" WHERE ");
	    sb.append(where);
	}
	String groupBy = getGroupByExpression(condition);
	if (!"".equals(groupBy))
	    sb.append(" GROUP BY " + groupBy);
	String orderBy = getOrderByExpression(condition);
	if (!"".equals(orderBy))
	    sb.append(" ORDER BY " + orderBy);

	sb.append(" ) a ");
	queryToExecute = sb.toString();
	log.debug("Sql is :- " + queryToExecute);
	session = getSession();
	Connection connection = null;
	Object obj = null;
	st = null;
	rs = null;
	try {
	    connection = session.getConnection();
	    st = connection.prepareStatement(queryToExecute);
	    condition.setValuesToStatement(st);
	    rs = st.executeQuery();
	    if(rs.next()) {
		cnt= rs.getInt(1);
	    }

	} catch (SQLException e) {
	    log.error("Exception during query:- " + e);

	    throw new DatabaseException("Could not run query = "
		    + queryToExecute, e);
	} catch (QueryException e) {
	    throw new DatabaseException("Could not run query = "
		    + queryToExecute, e);
	} finally {
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return cnt;
    }


    /**
     * Run query.
     *
     * @param pageNum the page num
     * @param pageSize the page size
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List runQuery(int pageNum, int pageSize) throws DatabaseException {
	return queryWithPagination(getQueryCondition(), false, pageNum, pageSize);
    }

    /**
     * Gets the query condition.
     *
     * @return the query condition
     * @throws DatabaseException the database exception
     */
    private Condition  getQueryCondition() throws DatabaseException {
	Condition condition = new Condition();
	if (attrs.getRelationshipId() != null && attrs.getRelationshipId().longValue() > 0) {
	    OperatorExpression connectionIdExp = new OperatorExpression(
		    RelationshipDAO.TABLE + "." + RelationshipDAO.COLUMN_ID,
		    Operator.EQUAL, attrs.getRelationshipId());
	    condition.addExpression(connectionIdExp);
	    String processType = attrs.getProcessType();
	    if ((processType != null) && (!"null".equals(processType))
		    && (!"".equals(processType))) {
		if (ScenarioNames.PROCESS_TYPE_CONNECTION
			.equalsIgnoreCase(processType)) {
		    OperatorExpression relationshipTypeLike = new OperatorExpression(
			    getQualifiedColumnName(
				    RelationshipDAO.TABLE,
				    RelationshipDAO.COLUMN_RELATIONSHIPTYPE,
				    false), Operator.NOT_EQUAL,
				    C3parStaticNames.CITI_IP);
		    condition.addExpression(relationshipTypeLike);

		} else {
		    OperatorExpression relationshipTypeLike = new OperatorExpression(
			    getQualifiedColumnName(
				    RelationshipDAO.TABLE,
				    RelationshipDAO.COLUMN_RELATIONSHIPTYPE,
				    false), Operator.NOT_EQUAL,
				    C3parStaticNames.CITI_CON);
		    condition.addExpression(relationshipTypeLike);

		    OperatorExpression relTypeUturnLike = new OperatorExpression(
			    getQualifiedColumnName(
				    RelationshipDAO.TABLE,
				    RelationshipDAO.COLUMN_RELATIONSHIPTYPE,
				    false), Operator.NOT_EQUAL,
				    C3parStaticNames.U_TURN);
		    condition.addExpression(relTypeUturnLike);
		}
	    }

	} else {

	    String relationshipType = attrs.getRelationshipType();
	    String processType = attrs.getProcessType();
	    if (FieldValidator.isValidString(relationshipType) && !relationshipType.equalsIgnoreCase(C3parStaticNames.ALL)) {
		if (C3parStaticNames.CITI_CON
			.equalsIgnoreCase(relationshipType)
			|| C3parStaticNames.CITI_IP
			.equalsIgnoreCase(relationshipType)) {
		    if ((processType != null) && (!"null".equals(processType))
			    && (!"".equals(processType))) {
			if (ScenarioNames.PROCESS_TYPE_CONNECTION
				.equalsIgnoreCase(processType)) {
			    OperatorExpression relationshipTypeLike = new OperatorExpression(
				    getQualifiedColumnName(
					    RelationshipDAO.TABLE,
					    RelationshipDAO.COLUMN_RELATIONSHIPTYPE,
					    false), Operator.EQUAL,
					    C3parStaticNames.CITI_CON);
			    condition.addExpression(relationshipTypeLike);
			} else {
			    OperatorExpression relationshipTypeLike = new OperatorExpression(
				    getQualifiedColumnName(
					    RelationshipDAO.TABLE,
					    RelationshipDAO.COLUMN_RELATIONSHIPTYPE,
					    false), Operator.EQUAL,
					    C3parStaticNames.CITI_IP);
			    condition.addExpression(relationshipTypeLike);
			}
		    } else {
			OperatorExpression relationshipTypeLike = new OperatorExpression(
				getQualifiedColumnName(
					RelationshipDAO.TABLE,
					RelationshipDAO.COLUMN_RELATIONSHIPTYPE,
					false), Operator.LIKE,
					C3parStaticNames.THIRD_PARTY);
			condition.addExpression(relationshipTypeLike);
		    }
		} else if(C3parStaticNames.U_TURN
			.equalsIgnoreCase(relationshipType)){
		    OperatorExpression relationshipTypeLike = new OperatorExpression(
			    getQualifiedColumnName(
				    RelationshipDAO.TABLE,
				    RelationshipDAO.COLUMN_RELATIONSHIPTYPE,
				    false), Operator.LIKE,
				    C3parStaticNames.U_TURN);
		    condition.addExpression(relationshipTypeLike);
		}else if(C3parStaticNames.TEMPLATE_OBJ
			.equalsIgnoreCase(relationshipType)){
		    OperatorExpression relationshipTypeLike = new OperatorExpression(
			    getQualifiedColumnName(
				    RelationshipDAO.TABLE,
				    RelationshipDAO.COLUMN_RELATIONSHIPTYPE,
				    false), Operator.EQUAL,
				    C3parStaticNames.TEMPLATE_OBJ);
		    condition.addExpression(relationshipTypeLike);
		} else if(C3parStaticNames.PORT_TEMPLATE
			.equalsIgnoreCase(relationshipType)){
		    OperatorExpression relationshipTypeLike = new OperatorExpression(
			    getQualifiedColumnName(
				    RelationshipDAO.TABLE,
				    RelationshipDAO.COLUMN_RELATIONSHIPTYPE,
				    false), Operator.LIKE,
				    C3parStaticNames.PORT_TEMPLATE);
		    condition.addExpression(relationshipTypeLike);
		} else if(C3parStaticNames.IP_TEMPLATE
			.equalsIgnoreCase(relationshipType)){
		    OperatorExpression relationshipTypeLike = new OperatorExpression(
			    getQualifiedColumnName(
				    RelationshipDAO.TABLE,
				    RelationshipDAO.COLUMN_RELATIONSHIPTYPE,
				    false), Operator.LIKE,
				    C3parStaticNames.IP_TEMPLATE);
		    condition.addExpression(relationshipTypeLike);
		} else  {
		    OperatorExpression relationshipTypeLike = new OperatorExpression(
			    getQualifiedColumnName(RelationshipDAO.TABLE,
				    RelationshipDAO.COLUMN_RELATIONSHIPTYPE,
				    false), Operator.LIKE,
				    C3parStaticNames.THIRD_PARTY);
		    condition.addExpression(relationshipTypeLike);
		}
	    } else {
		if ((processType != null) && (!"null".equals(processType))
			&& (!"".equals(processType))) {
		    if (ScenarioNames.PROCESS_TYPE_CONNECTION
			    .equalsIgnoreCase(processType)) {
			OperatorExpression relationshipTypeLike = new OperatorExpression(
				getQualifiedColumnName(
					RelationshipDAO.TABLE,
					RelationshipDAO.COLUMN_RELATIONSHIPTYPE,
					false), Operator.NOT_EQUAL,
					C3parStaticNames.CITI_IP);
			condition.addExpression(relationshipTypeLike);

		    } else {
			OperatorExpression relationshipTypeLike = new OperatorExpression(
				getQualifiedColumnName(
					RelationshipDAO.TABLE,
					RelationshipDAO.COLUMN_RELATIONSHIPTYPE,
					false), Operator.NOT_EQUAL,
					C3parStaticNames.CITI_CON);
			condition.addExpression(relationshipTypeLike);

			OperatorExpression relTypeUturnLike = new OperatorExpression(
				getQualifiedColumnName(
					RelationshipDAO.TABLE,
					RelationshipDAO.COLUMN_RELATIONSHIPTYPE,
					false), Operator.NOT_EQUAL,
					C3parStaticNames.U_TURN);
			condition.addExpression(relTypeUturnLike);
		    }
		}
	    }

	    Long classificationId = attrs.getDataClassification();
	    if (classificationId != null && classificationId.longValue() > 0 ) {

		OperatorExpression buidLike = new OperatorExpression(
			getQualifiedColumnName(CommonLookupDataDAO.TABLE,
				CommonLookupDataDAO.COLUMN_CLASSIFICATION_ID, false),
				Operator.EQUAL, classificationId);
		condition.addExpression(buidLike);

	    }
	    String bussUnit = attrs.getBusinessUnitName();
	    if (bussUnit != null) {
		OperatorExpression buidLike = new OperatorExpression(
			getQualifiedColumnName(BusinessUnitDAO.TABLE,
				BusinessUnitDAO.COLUMN_BUSINESSNAME, false),
				Operator.EQUAL, bussUnit);
		condition.addExpression(buidLike);
	    }

	    String reqBussUnit = attrs.getRequesterBusinessUnitName();
	    if (reqBussUnit != null) {
		OperatorExpression reqBuidLike = new OperatorExpression(
			getQualifiedColumnName(BusinessUnitDAO.TABLE,
				BusinessUnitDAO.COLUMN_BUSINESSNAME, false),
				Operator.EQUAL, reqBussUnit);
		condition.addExpression(reqBuidLike);
	    }

	    String participantId = attrs.getParticipantId();
	    if (participantId != null) {
		OperatorExpression partIdLike = new OperatorExpression(
			getQualifiedColumnName(C3parUsersDAO.TABLE,
				C3parUsersDAO.COLUMN_SSOID, false),
				Operator.EQUAL, participantId);
		condition.addExpression(partIdLike);
	    }

	    String thirdPartyName = attrs.getThirdPartyName();
	    if (thirdPartyName != null) {
		OperatorExpression thirdPartyIdLike = new OperatorExpression(
			getQualifiedColumnName(ThirdPartyDAO.TABLE,
				ThirdPartyDAO.COLUMN_NAME, false),
				Operator.EQUAL, thirdPartyName);
		condition.addExpression(thirdPartyIdLike);
	    }

	    Long reqResourceTypeId = attrs.getRequesterResourceTypeId();
	    if (reqResourceTypeId != null && reqResourceTypeId.longValue() > 0) {
		OperatorExpression reqResourceTypeIdLike = new OperatorExpression(
			getQualifiedColumnName(RelationshipDAO.TABLE,
				RelationshipDAO.COLUMN_REQUESTERRESOURCETYPE_ID, false),
				Operator.EQUAL, reqResourceTypeId);
		condition.addExpression(reqResourceTypeIdLike);
	    }

	    Long tarResourceTypeId = attrs.getTargetResourceTypeId();
	    if (tarResourceTypeId != null && tarResourceTypeId.longValue() > 0) {
		OperatorExpression tarResourceTypeIdLike = new OperatorExpression(
			getQualifiedColumnName(RelationshipDAO.TABLE,
				RelationshipDAO.COLUMN_TARGETRESOURCETYPE_ID, false),
				Operator.EQUAL, tarResourceTypeId);
		condition.addExpression(tarResourceTypeIdLike);
	    }

	    String connectionName = attrs.getRelationshipName();
	    if (FieldValidator.isValidString(connectionName)) {
		OperatorExpression connectionNameLike = new OperatorExpression(
			getQualifiedColumnName(RelationshipDAO.TABLE,
				RelationshipDAO.COLUMN_NAME, false),
				Operator.LIKE, connectionName.trim().toUpperCase());
		condition.addExpression(connectionNameLike);
	    }

	    String ospName = attrs.getOspServiceName();
	    if (FieldValidator.isValidString(ospName)) {
		OperatorExpression ospNameLike = new OperatorExpression(
			getQualifiedColumnName(RelationshipDAO.TABLE,
				RelationshipDAO.COLUMN_OSPSERVICENAME, false),
				Operator.LIKE, ospName.trim());
		condition.addExpression(ospNameLike);
	    }

	    String status = attrs.getStatus();
	    if (FieldValidator.isValidString(status)) {
		OperatorExpression statusLike = new OperatorExpression(
			getQualifiedColumnName(RelationshipDAO.TABLE,
				RelationshipDAO.COLUMN_STATUS, false),
				Operator.EQUAL, status.trim());
		condition.addExpression(statusLike);
	    }

	  /*  OperatorExpression entInActLike = new OperatorExpression(
		    getQualifiedColumnName(EntitlementInstanceDAO.TABLE,
			    EntitlementInstanceDAO.COLUMN_INACTIVE, false),
			    Operator.EQUAL, "N");
	    condition.addExpression(entInActLike);*/

	    String ssoId = attrs.getSsoId();
	    if (FieldValidator.isValidString(ssoId)) {
		//C3parUsersDAO userDao = new C3parUsersDAO(getSession());
		//C3parUsersEntity userEntity = userDao.get(attrs.getSsoId());
		//if (userEntity != null) {
		OperatorExpression createdByExp = new OperatorExpression(
			getQualifiedColumnName(RelationshipDAO.TABLE,
				RelationshipDAO.COLUMN_REQUESTERID, false),
				Operator.EQUAL, ssoId.toLowerCase());
		condition.addExpression(createdByExp);
		//}
	    }
	    addBoolStringFilter(attrs.getConnectivityExists(), condition,
		    getQualifiedColumnName(RelationshipDAO.TABLE,
			    RelationshipDAO.COLUMN_CONNECTIVITYEXISTS, false));
	    addBoolStringFilter(attrs.getAccessCitiData(), condition,
		    getQualifiedColumnName(RelationshipDAO.TABLE,
			    RelationshipDAO.COLUMN_ACCESSCITIDATA, false));
	    addBoolStringFilter(attrs.getAccessCustomerData(), condition,
		    getQualifiedColumnName(RelationshipDAO.TABLE,
			    RelationshipDAO.COLUMN_ACCESSCUSTOMERDATA, false));
	    addBoolStringFilter(attrs.getOspServiceProvided(), condition,
		    getQualifiedColumnName(RelationshipDAO.TABLE,
			    RelationshipDAO.COLUMN_ISOUTSOURCEPROVIDER, false));
	}
	// get only active instances
	JoinExpression j1 = new JoinExpression(RelationshipDAO.TABLE,
		RelationshipDAO.COLUMN_ID,
		RelCitiHierXrefDAO.TABLE, RelCitiHierXrefDAO.COLUMN_RELATIONSHIP_ID,
		false);
	condition.addExpression(j1);
	JoinExpression j2 = new JoinExpression(RelationshipDAO.TABLE,
		RelationshipDAO.COLUMN_LOOKUP_ID, CommonLookupDataDAO.TABLE,
		CommonLookupDataDAO.COLUMN_ID, false);
	condition.addExpression(j2);
	
	JoinExpression j7 = new JoinExpression(RelCitiHierXrefDAO.TABLE,
			RelCitiHierXrefDAO.COLUMN_CITI_HIERARCHY_MASTER_ID, CitiHierMasterDAO.TABLE,
			CitiHierMasterDAO.COLUMN_ID, false);
		condition.addExpression(j7);
	
	JoinExpression j3 = new JoinExpression(CitiHierMasterDAO.TABLE,
			CitiHierMasterDAO.COLUMN_BU_ID, BusinessUnitDAO.TABLE,
		BusinessUnitDAO.COLUMN_ID, false);
	condition.addExpression(j3);

	JoinExpression j4 = new JoinExpression(UserCitiHierXrefDAO.TABLE,
			UserCitiHierXrefDAO.COLUMN_USER_ID, C3parUsersDAO.TABLE,
			C3parUsersDAO.COLUMN_ID, false);
	condition.addExpression(j4);

	/*JoinExpression j5 = new JoinExpression(C3parUserEntitlementXrefDAO.TABLE,
		C3parUserEntitlementXrefDAO.COLUMN_USER_ID, C3parUsersDAO.TABLE,
		C3parUsersDAO.COLUMN_ID, false);
	condition.addExpression(j5);*/

	String relationshipType = attrs.getRelationshipType();		
	if(relationshipType != null && (relationshipType.equals(C3parStaticNames.THIRD_PARTY) 
		|| relationshipType.equals(C3parStaticNames.U_TURN))){
	    JoinExpression j6 = new JoinExpression(RelationshipDAO.TABLE,
		    RelationshipDAO.COLUMN_THIRDPARTY_ID, ThirdPartyDAO.TABLE,
		    ThirdPartyDAO.COLUMN_ID, false);
	    if (attrs.getThirdPartyName() != null) {
		condition.addExpression(j6);		
	    } else {
		OperatorExpression thirdPartyByExp = new OperatorExpression(
			getQualifiedColumnName(RelationshipDAO.TABLE,
				RelationshipDAO.COLUMN_THIRDPARTY_ID, false),
				Operator.EQUAL, null);

		LogicalExpression exp1 = new LogicalExpression(LogicalOperator.OR, j6, thirdPartyByExp);

		ArrayList listExpression = new ArrayList();
		listExpression.add(exp1);
		SubExpression subExpression = new SubExpression(listExpression, false);
		condition.addExpression(subExpression);		
	    }
	}

	condition.addOrderByField(RelationshipDAO.COLUMN_ID + " DESC");


	return condition;
    }

    /**
     * Adds the boolean filter.
     *
     * @param id the id
     * @param cond the cond
     * @param col the col
     */
    protected void addBooleanFilter(Long id, Condition cond, String col) {
	if (id != null && id.longValue() > 0) {
	    Expression expr;
	    if (id.longValue() == 1) {
		expr = new OperatorExpression(col, Operator.EQUAL, "Y");
	    } else {
		expr = new OperatorExpression(col, Operator.EQUAL, "N");
	    }
	    cond.addExpression(expr);
	}
    }

    /**
     * Adds the boolean filter.
     *
     * @param bool the bool
     * @param cond the cond
     * @param col the col
     */
    protected void addBooleanFilter(Boolean bool, Condition cond, String col) {
	if (bool != null) {
	    Expression expr;
	    if (bool.booleanValue()) {
		expr = new OperatorExpression(col, Operator.EQUAL, "Y");
	    } else {
		expr = new OperatorExpression(col, Operator.EQUAL, "N");
	    }
	    cond.addExpression(expr);
	}
    }

    /**
     * Adds the bool string filter.
     *
     * @param id the id
     * @param cond the cond
     * @param col the col
     */
    protected void addBoolStringFilter(Long id, Condition cond, String col) {
	if (id != null && id.longValue() > 0) {
	    Expression expr;
	    if (id.longValue() == 1) {
		expr = new OperatorExpression(col, Operator.EQUAL, "Y");
	    } else if (id.longValue() == 2){
		expr = new OperatorExpression(col, Operator.EQUAL, "N");
	    } else {
		expr = new OperatorExpression(col, Operator.EQUAL, "A");
	    }
	    cond.addExpression(expr);
	}
    }

    /**
     * Convert list to string.
     *
     * @param entInstEntities the ent inst entities
     * @return the string
     */
    protected String convertListToString(List entInstEntities) {
	List instIds = new ArrayList();
	if (entInstEntities != null) {
	    Iterator itr = entInstEntities.iterator();
	    while (itr.hasNext()) {
		EntitlementInstanceEntity entEntity = (EntitlementInstanceEntity) itr
		.next();
		instIds.add(entEntity.getId());
	    }
	}
	StringBuffer str = new StringBuffer();
	if (instIds != null) {
	    for (int i = 0; i < instIds.size(); i++) {
		str.append((Long) instIds.get(i));
		if (i != instIds.size() - 1)
		    str.append(",");

	    }

	}
	return (str.toString());

    }
}
