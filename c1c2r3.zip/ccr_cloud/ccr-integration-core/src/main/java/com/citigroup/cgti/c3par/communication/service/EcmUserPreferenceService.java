/**
 * 
 */
package com.citigroup.cgti.c3par.communication.service;

import java.util.Map;

import com.citigroup.cgti.c3par.communication.domain.AgentViewProcess;
import com.citigroup.cgti.c3par.communication.domain.CmpReqIdSearchProcess;
import com.citigroup.cgti.c3par.communication.domain.EcmLeadViewProcess;
import com.citigroup.cgti.c3par.communication.domain.EcmUserPreferenceDTO;
import com.citigroup.cgti.c3par.communication.domain.TeamViewProcess;

/**
 * @author ka58098
 * 
 */
public interface EcmUserPreferenceService {

	void getColumnList(Object object) throws Exception;

    EcmUserPreferenceDTO getUserSettingDetails(String ssoId, String viewId) throws Exception;

    EcmUserPreferenceDTO saveSettigsDetails(EcmUserPreferenceDTO ecmUserPreference) throws Exception;

    Map<Long, String> getColumnList(EcmLeadViewProcess ecmLeadViewProcess) throws Exception;

    Map<Long, String> getColumnList(TeamViewProcess teamViewProcess) throws Exception;

    Map<Long, String> getColumnList(CmpReqIdSearchProcess cmpReqIdSearchProcess) throws Exception;

}
