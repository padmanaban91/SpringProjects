package com.citigroup.cgti.c3par.communication.domain;

import org.springframework.beans.factory.annotation.Configurable;

import com.citigroup.cgti.c3par.domain.Base;

 
public class CmpConnectionDetail extends Base {
		
	 	private Long id;

	    /** The name. */
	    private String name;

	    /** The display_id. */
	    private String display_id;

	    /** The version_number. */
	    private Long version_number;

	    /** The status. */
	    private String status;

	    /** The phase. */
	    private String phase;

	    /** The type. */
	    private String type;

	    /** The ti process. */
	    private String tiProcess;

	    /** The role. */
	    private String role;

	    /** The priority. */
	    private String priority;

	    /** The participant. */
	    private String participant;

	    /** The bpm activity id. */
	    private String bpmActivityId;

	    /** The bmp instance id. */
	    private String bmpInstanceId;

	    /** The tirequestid. */
	    private Long tirequestid;

	    /** The task name. */
	    private String taskName;
	    
	    private String taskCode;

	    /** The bpm process name. */
	    private String bpmProcessName;
	    
	    /**process locked date */
	    private String lockedDate;
	    
	    /** process activity_code (or) task_code*/
	    private String activityCode;
	    
	    private Long timeInActivity;
	    
	    private Long activityTrialId;
	    
	    private String roleName;
	    
	    private String region; 
	    
	    private String sector;
	    
	    private String userAccess;
	    
	    private String submissionRole;
	    
	    private String bulkACVInstance;
	    
	    private String bulkACVActivity;
	    

		public Long getId() {
			return id;
		}



		public void setId(Long id) {
			this.id = id;
		}



		public String getName() {
			return name;
		}



		public void setName(String name) {
			this.name = name;
		}



		public String getDisplay_id() {
			return display_id;
		}



		public void setDisplay_id(String display_id) {
			this.display_id = display_id;
		}



		public Long getVersion_number() {
			return version_number;
		}



		public void setVersion_number(Long version_number) {
			this.version_number = version_number;
		}



		public String getStatus() {
			return status;
		}



		public void setStatus(String status) {
			this.status = status;
		}



		public String getPhase() {
			return phase;
		}



		public void setPhase(String phase) {
			this.phase = phase;
		}



		public String getType() {
			return type;
		}



		public void setType(String type) {
			this.type = type;
		}



		public String getTiProcess() {
			return tiProcess;
		}



		public void setTiProcess(String tiProcess) {
			this.tiProcess = tiProcess;
		}



		public String getRole() {
			return role;
		}



		public void setRole(String role) {
			this.role = role;
		}



		public String getPriority() {
			return priority;
		}



		public void setPriority(String priority) {
			this.priority = priority;
		}



		public String getParticipant() {
			return participant;
		}



		public void setParticipant(String participant) {
			this.participant = participant;
		}



		public String getBpmActivityId() {
			return bpmActivityId;
		}



		public void setBpmActivityId(String bpmActivityId) {
			this.bpmActivityId = bpmActivityId;
		}



		public String getBmpInstanceId() {
			return bmpInstanceId;
		}



		public void setBmpInstanceId(String bmpInstanceId) {
			this.bmpInstanceId = bmpInstanceId;
		}



		public Long getTirequestid() {
			return tirequestid;
		}



		public void setTirequestid(Long tirequestid) {
			this.tirequestid = tirequestid;
		}



		public String getTaskName() {
			return taskName;
		}



		public void setTaskName(String taskName) {
			this.taskName = taskName;
		}



		public String getTaskCode() {
			return taskCode;
		}



		public void setTaskCode(String taskCode) {
			this.taskCode = taskCode;
		}



		public String getBpmProcessName() {
			return bpmProcessName;
		}



		public void setBpmProcessName(String bpmProcessName) {
			this.bpmProcessName = bpmProcessName;
		}



		public String getLockedDate() {
			return lockedDate;
		}



		public void setLockedDate(String lockedDate) {
			this.lockedDate = lockedDate;
		}



		public String getActivityCode() {
			return activityCode;
		}



		public void setActivityCode(String activityCode) {
			this.activityCode = activityCode;
		}



		public Long getTimeInActivity() {
			return timeInActivity;
		}



		public void setTimeInActivity(Long timeInActivity) {
			this.timeInActivity = timeInActivity;
		}



		public Long getActivityTrialId() {
			return activityTrialId;
		}



		public void setActivityTrialId(Long activityTrialId) {
			this.activityTrialId = activityTrialId;
		}



		public String getRoleName() {
			return roleName;
		}



		public void setRoleName(String roleName) {
			this.roleName = roleName;
		}



		public String getRegion() {
			return region;
		}



		public void setRegion(String region) {
			this.region = region;
		}



		public String getSector() {
			return sector;
		}



		public void setSector(String sector) {
			this.sector = sector;
		}



		public String getUserAccess() {
			return userAccess;
		}



		public void setUserAccess(String userAccess) {
			this.userAccess = userAccess;
		}



		public String getSubmissionRole() {
			return submissionRole;
		}



		public void setSubmissionRole(String submissionRole) {
			this.submissionRole = submissionRole;
		}



		public String getBulkACVInstance() {
			return bulkACVInstance;
		}



		public void setBulkACVInstance(String bulkACVInstance) {
			this.bulkACVInstance = bulkACVInstance;
		}



		public String getBulkACVActivity() {
			return bulkACVActivity;
		}



		public void setBulkACVActivity(String bulkACVActivity) {
			this.bulkACVActivity = bulkACVActivity;
		}



	
}
