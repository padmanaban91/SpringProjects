package com.citigroup.cgti.c3par.configuation;

import java.sql.Clob;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;


public class CCRQueries {
	
	public JdbcTemplate jdbcTemplate;
	private static final String QUERY_RECORDS = "SELECT QUERY_NAME,QUERY_TEXT FROM CCR_QUERIES";
	private static final String QUERY_CHANGED = "SELECT IS_CHANGED FROM CCR_QUERIES WHERE QUERY_NAME=?";
	private static final String QUERY_CHANGED_TEXT = "SELECT QUERY_NAME,QUERY_TEXT FROM CCR_QUERIES WHERE QUERY_NAME=?";
	private static final String QUERY_UPDATE = "UPDATE CCR_QUERIES SET IS_CHANGED='N' , UPDATED_DATE=SYSDATE WHERE QUERY_NAME=?";
	private Map<String,String> ccr_query =  new HashMap<String,String>();
	private String environment;
	private static Logger log = Logger.getLogger(CCRQueries.class);
	
	private CCRQueries()
	{
	}
	
	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	@SuppressWarnings("unchecked")
	private void loadQueries()
	{
		 jdbcTemplate.query(QUERY_RECORDS, new RowMapper(){
			
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				String query_name = rs.getString("QUERY_NAME");
				String qur = new String();
				
				Clob cb = rs.getClob("QUERY_TEXT");
				if(cb!=null && cb.length()>0)
				{
					qur = cb.getSubString(1, (int)cb.length());
				
				}
				ccr_query.put(query_name, qur);
				return ccr_query;
			}
			
		});
	}
	
	
	public String getQueryByName(String name)
	{
		//commented by eg41091 for removing unwanted log
		//log.info("ccr_query:-"+ccr_query.get(name));
		if (ccr_query==null || ccr_query.size()==0)
		{
			this.loadQueries();
		}
		
		if (!"PRD".equals(getEnvironment())) {
			boolean b = isquerychanged(name);
			if(b || ccr_query.get(name)==null)
			{
				updateQueryinMap(name);
			}
		}
		return ccr_query.get(name);
	}
	
	@SuppressWarnings("unchecked")
	private boolean isquerychanged(String name)
	{
		String str = 
		 (String)jdbcTemplate.queryForObject(QUERY_CHANGED, new String[]{name}, new RowMapper(){
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException
			{
				return rs.getString("IS_CHANGED");
			}
			
		});
		
		return ("Y".equals(str)?true:false);
	}
	
	@SuppressWarnings("unchecked")
	private void updateQueryinMap(String name)
	{
		 jdbcTemplate.queryForObject(QUERY_CHANGED_TEXT,new Object[]{name},new RowMapper(){
			
			public Object mapRow(ResultSet rs,int rowNum) throws SQLException
			{
				String query_name = rs.getString("QUERY_NAME");
				String qur = new String();
				Clob cb = rs.getClob("QUERY_TEXT");
				if(cb!=null && cb.length()>0)
				{
					qur = cb.getSubString(1, (int)cb.length());
				
				}
				ccr_query.put(query_name, qur);
				jdbcTemplate.update(QUERY_UPDATE,new Object[]{query_name});
				return ccr_query;
			}
			
		});
	}
}
