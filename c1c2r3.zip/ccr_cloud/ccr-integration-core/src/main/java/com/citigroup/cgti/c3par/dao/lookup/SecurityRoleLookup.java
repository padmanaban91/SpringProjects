

/*
 * CONFIDENTIAL  AND PROPRIETARY
 * Copyright ? 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is 
 * strictly prohibited.
 */
package com.citigroup.cgti.c3par.dao.lookup;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.citigroup.cgti.c3par.model.*;
import com.citigroup.cgti.c3par.dao.*;
import com.mentisys.dao.*;
import com.mentisys.dao.query.*;


/**
 * The Class SecurityRoleLookup.
 */
public class SecurityRoleLookup
{

    /** The initialized. */
    private boolean		initialized = false;

    /** The ordered list. */
    private ArrayList 	orderedList = new ArrayList();

    /** The values by id. */
    private HashMap		valuesById = new HashMap();

    /** The values by name. */
    private HashMap		valuesByName = new HashMap();

    /** The values by description. */
    private HashMap		valuesByDescription = new HashMap();

    /** The values by display name. */
    private HashMap		valuesByDisplayName = new HashMap();

    /** The instance. */
    static private SecurityRoleLookup instance = null;

    //======================================================================
    /**
     * Gets the single instance of SecurityRoleLookup.
     *
     * @return single instance of SecurityRoleLookup
     */
    synchronized static public SecurityRoleLookup getInstance()
    {
	if (instance == null)
	{
	    instance = new SecurityRoleLookup();
	}
	return instance;
    }

    //======================================================================
    /**
     * Gets the single instance of SecurityRoleLookup.
     *
     * @param session the session
     * @return single instance of SecurityRoleLookup
     * @throws DatabaseException the database exception
     */
    synchronized static public SecurityRoleLookup getInstance(DatabaseSession session) throws DatabaseException
    {
	if (instance == null)
	{
	    instance = new SecurityRoleLookup();
	    instance.initialize(session);	
	}
	else if(!instance.isInitialized())
	{
	    instance.initialize(session);	
	}
	return instance;
    }

    //======================================================================
    /**
     * Instantiates a new security role lookup.
     */
    private SecurityRoleLookup()
    {
	super();
	initialized = false;
    }

    //======================================================================
    /**
     * Initialize.
     *
     * @param session the session
     * @throws DatabaseException the database exception
     */
    synchronized public void initialize(DatabaseSession session) throws DatabaseException
    {
	if (!initialized)
	{
	    SecurityRoleDAO dao = new SecurityRoleDAO(session);
	    SecurityRoleEntity entity = null;
	    Condition condition = new Condition();
	    condition.addOrderByField(SecurityRoleDAO.COLUMN_NAME);
	    try
	    {
		List list = dao.query(condition, false);
		Iterator it = list.iterator();

		while (it.hasNext())
		{
		    entity = (SecurityRoleEntity) it.next();
		    valuesById.put(entity.getId(), entity);
		    valuesByName.put(entity.getName(), entity);
		    valuesByDescription.put(entity.getDescription(), entity);
		    valuesByDisplayName.put(entity.getDisplayName(), entity);
		    orderedList.add(entity);
		}
		initialized = true;

		it = list.iterator();
		while (it.hasNext())
		{
		    entity = (SecurityRoleEntity) it.next();
		    dao.loadReferences((SecurityRoleEntity)entity);
		}
	    }
	    catch (DatabaseException e)
	    {
		throw e;
	    }
	}
    }

    //======================================================================
    /**
     * Reset.
     */
    synchronized public void reset()
    {
	valuesById = new HashMap();
	orderedList = new ArrayList();
	initialized = false;
	valuesByName = new HashMap();
	valuesByDescription = new HashMap();
	valuesByDisplayName = new HashMap();
    }

    //======================================================================
    /**
     * Gets the by id.
     *
     * @param id the id
     * @return the by id
     */
    synchronized public SecurityRoleEntity getById(Long id)
    {
	return (SecurityRoleEntity) valuesById.get(id);
    }

    //======================================================================
    /**
     * Gets the by id.
     *
     * @param session the session
     * @param id the id
     * @return the by id
     * @throws DatabaseException the database exception
     */
    synchronized public SecurityRoleEntity getById(DatabaseSession session, Long id) throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (SecurityRoleEntity) valuesById.get(id);
    }

    //======================================================================
    /**
     * Gets the by name.
     *
     * @param v the v
     * @return the by name
     */
    synchronized public SecurityRoleEntity getByName(String v)
    {
	return (SecurityRoleEntity) valuesByName.get(v);
    }

    //======================================================================
    /**
     * Gets the by name.
     *
     * @param session the session
     * @param v the v
     * @return the by name
     * @throws DatabaseException the database exception
     */
    synchronized public SecurityRoleEntity getByName(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (SecurityRoleEntity) valuesByName.get(v);
    }
    //======================================================================
    /**
     * Gets the by description.
     *
     * @param v the v
     * @return the by description
     */
    synchronized public SecurityRoleEntity getByDescription(String v)
    {
	return (SecurityRoleEntity) valuesByDescription.get(v);
    }

    //======================================================================
    /**
     * Gets the by description.
     *
     * @param session the session
     * @param v the v
     * @return the by description
     * @throws DatabaseException the database exception
     */
    synchronized public SecurityRoleEntity getByDescription(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (SecurityRoleEntity) valuesByDescription.get(v);
    }
    //======================================================================
    /**
     * Gets the by display name.
     *
     * @param v the v
     * @return the by display name
     */
    synchronized public SecurityRoleEntity getByDisplayName(String v)
    {
	return (SecurityRoleEntity) valuesByDisplayName.get(v);
    }

    //======================================================================
    /**
     * Gets the by display name.
     *
     * @param session the session
     * @param v the v
     * @return the by display name
     * @throws DatabaseException the database exception
     */
    synchronized public SecurityRoleEntity getByDisplayName(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (SecurityRoleEntity) valuesByDisplayName.get(v);
    }

    //======================================================================
    /**
     * Gets the all.
     *
     * @return the all
     */
    synchronized public ArrayList getAll()
    {
	return orderedList;
    }

    //======================================================================
    /**
     * Checks if is initialized.
     *
     * @return true, if is initialized
     */
    synchronized public boolean isInitialized()
    {
	return initialized;
    }
}
