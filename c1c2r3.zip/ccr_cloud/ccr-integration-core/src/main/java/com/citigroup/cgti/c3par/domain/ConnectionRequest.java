
package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;
import java.util.List;

import com.citigroup.cgti.c3par.relationship.domain.CoLookupData;

/**
 * The Class ConnectionRequest.
 *
 * @author pc79439
 */
@SuppressWarnings("unchecked")
public class ConnectionRequest extends Base implements Serializable{

    private String discriminator;

    private CoLookupData colookup;

    private Long netconId;

    private com.citigroup.cgti.c3par.relationship.domain.Relationship relationship;
    
    private String requireNetworkAccess;

    private String rationale;
    
    private String benefit;
    
    private String plcode;

    private String cobredundancyReq;

    private String connectionName;

    private String status;

    private String requestorId;

    private String semiannualentitlementReview;

    private String issconnectionCompliance;

    private String citipolicyAdherence;

    private String accesscitiGlobalNetwork;

    private String tptrainingAwarenessPrg;

    private String isdeleted;

    private com.citigroup.cgti.c3par.common.domain.ResourceType sourceResourceType;

    private com.citigroup.cgti.c3par.common.domain.ResourceType targetResourceType;

    private String fafgeneratedFlag;

    private String isaclVariance;

    private String fwtype;

    private Long fwmgmtRegionId;

    private String exportLicenseCoordinator;

    private String sponsorBusinessConsulted;

    private String fafrequestFlag;

    private String pafgeneratedFlag;

    private String aafgeneratedFlag;

    private String bulkRequest;

    private String splinstrAppsense;

    private String splinstrProxy;

    private String splinstrFirewall;

    private String jmsmsgflag;

    private String splinstrAclvar;

    private String exportLicenseCoordinatorNew;

    private String conforcustclient;
    
    private String directAccessByThirdparty;
    
    private String capappGroupCode;
    
    private String semiannualEntlReview;
    
    private String tptrainingAwarnessprg;
    
    private String splinstrIPreg;
    
    private String connectivityEstimate;
    
    private String detailedInfo;

    private List<VirtualConnReason> virtualConnReasons;
    
	public String getDiscriminator() {
		return discriminator;
	}

	public void setDiscriminator(String discriminator) {
		this.discriminator = discriminator;
	}

	public CoLookupData getColookup() {
		return colookup;
	}

	public void setColookup(CoLookupData colookup) {
		this.colookup = colookup;
	}

	public Long getNetconId() {
		return netconId;
	}

	public void setNetconId(Long netconId) {
		this.netconId = netconId;
	}

	public com.citigroup.cgti.c3par.relationship.domain.Relationship getRelationship() {
		return relationship;
	}

	public void setRelationship(
			com.citigroup.cgti.c3par.relationship.domain.Relationship relationship) {
		this.relationship = relationship;
	}

	public String getRequireNetworkAccess() {
		return requireNetworkAccess;
	}

	public void setRequireNetworkAccess(String requireNetworkAccess) {
		this.requireNetworkAccess = requireNetworkAccess;
	}

	public String getRationale() {
		return rationale;
	}

	public void setRationale(String rationale) {
		this.rationale = rationale;
	}

	public String getBenefit() {
		return benefit;
	}

	public void setBenefit(String benefit) {
		this.benefit = benefit;
	}

	public String getPlcode() {
		return plcode;
	}

	public void setPlcode(String plcode) {
		this.plcode = plcode;
	}

	public String getCobredundancyReq() {
		return cobredundancyReq;
	}

	public void setCobredundancyReq(String cobredundancyReq) {
		this.cobredundancyReq = cobredundancyReq;
	}

	public String getConnectionName() {
		return connectionName;
	}

	public void setConnectionName(String connectionName) {
		this.connectionName = connectionName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRequestorId() {
		return requestorId;
	}

	public void setRequestorId(String requestorId) {
		this.requestorId = requestorId;
	}

	public String getSemiannualentitlementReview() {
		return semiannualentitlementReview;
	}

	public void setSemiannualentitlementReview(String semiannualentitlementReview) {
		this.semiannualentitlementReview = semiannualentitlementReview;
	}

	public String getIssconnectionCompliance() {
		return issconnectionCompliance;
	}

	public void setIssconnectionCompliance(String issconnectionCompliance) {
		this.issconnectionCompliance = issconnectionCompliance;
	}

	public String getCitipolicyAdherence() {
		return citipolicyAdherence;
	}

	public void setCitipolicyAdherence(String citipolicyAdherence) {
		this.citipolicyAdherence = citipolicyAdherence;
	}

	public String getAccesscitiGlobalNetwork() {
		return accesscitiGlobalNetwork;
	}

	public void setAccesscitiGlobalNetwork(String accesscitiGlobalNetwork) {
		this.accesscitiGlobalNetwork = accesscitiGlobalNetwork;
	}

	public String getTptrainingAwarenessPrg() {
		return tptrainingAwarenessPrg;
	}

	public void setTptrainingAwarenessPrg(String tptrainingAwarenessPrg) {
		this.tptrainingAwarenessPrg = tptrainingAwarenessPrg;
	}

	public String getIsdeleted() {
		return isdeleted;
	}

	public void setIsdeleted(String isdeleted) {
		this.isdeleted = isdeleted;
	}

	public com.citigroup.cgti.c3par.common.domain.ResourceType getSourceResourceType() {
		return sourceResourceType;
	}

	public void setSourceResourceType(com.citigroup.cgti.c3par.common.domain.ResourceType sourceResourceType) {
		this.sourceResourceType = sourceResourceType;
	}

	public com.citigroup.cgti.c3par.common.domain.ResourceType getTargetResourceType() {
		return targetResourceType;
	}

	public void setTargetResourceType(com.citigroup.cgti.c3par.common.domain.ResourceType targetResourceType) {
		this.targetResourceType = targetResourceType;
	}

	public String getFafgeneratedFlag() {
		return fafgeneratedFlag;
	}

	public void setFafgeneratedFlag(String fafgeneratedFlag) {
		this.fafgeneratedFlag = fafgeneratedFlag;
	}

	public String getIsaclVariance() {
		return isaclVariance;
	}

	public void setIsaclVariance(String isaclVariance) {
		this.isaclVariance = isaclVariance;
	}

	public String getFwtype() {
		return fwtype;
	}

	public void setFwtype(String fwtype) {
		this.fwtype = fwtype;
	}

	public Long getFwmgmtRegionId() {
		return fwmgmtRegionId;
	}

	public void setFwmgmtRegionId(Long fwmgmtRegionId) {
		this.fwmgmtRegionId = fwmgmtRegionId;
	}

	public String getExportLicenseCoordinator() {
		return exportLicenseCoordinator;
	}

	public void setExportLicenseCoordinator(String exportLicenseCoordinator) {
		this.exportLicenseCoordinator = exportLicenseCoordinator;
	}

	public String getSponsorBusinessConsulted() {
		return sponsorBusinessConsulted;
	}

	public void setSponsorBusinessConsulted(String sponsorBusinessConsulted) {
		this.sponsorBusinessConsulted = sponsorBusinessConsulted;
	}

	public String getFafrequestFlag() {
		return fafrequestFlag;
	}

	public void setFafrequestFlag(String fafrequestFlag) {
		this.fafrequestFlag = fafrequestFlag;
	}

	public String getPafgeneratedFlag() {
		return pafgeneratedFlag;
	}

	public void setPafgeneratedFlag(String pafgeneratedFlag) {
		this.pafgeneratedFlag = pafgeneratedFlag;
	}

	public String getAafgeneratedFlag() {
		return aafgeneratedFlag;
	}

	public void setAafgeneratedFlag(String aafgeneratedFlag) {
		this.aafgeneratedFlag = aafgeneratedFlag;
	}

	public String getBulkRequest() {
		return bulkRequest;
	}

	public void setBulkRequest(String bulkRequest) {
		this.bulkRequest = bulkRequest;
	}

	public String getSplinstrAppsense() {
		return splinstrAppsense;
	}

	public void setSplinstrAppsense(String splinstrAppsense) {
		this.splinstrAppsense = splinstrAppsense;
	}

	public String getSplinstrProxy() {
		return splinstrProxy;
	}

	public void setSplinstrProxy(String splinstrProxy) {
		this.splinstrProxy = splinstrProxy;
	}

	public String getSplinstrFirewall() {
		return splinstrFirewall;
	}

	public void setSplinstrFirewall(String splinstrFirewall) {
		this.splinstrFirewall = splinstrFirewall;
	}

	public String getJmsmsgflag() {
		return jmsmsgflag;
	}

	public void setJmsmsgflag(String jmsmsgflag) {
		this.jmsmsgflag = jmsmsgflag;
	}

	public String getSplinstrAclvar() {
		return splinstrAclvar;
	}

	public void setSplinstrAclvar(String splinstrAclvar) {
		this.splinstrAclvar = splinstrAclvar;
	}

	public String getExportLicenseCoordinatorNew() {
		return exportLicenseCoordinatorNew;
	}

	public void setExportLicenseCoordinatorNew(String exportLicenseCoordinatorNew) {
		this.exportLicenseCoordinatorNew = exportLicenseCoordinatorNew;
	}

	public String getConforcustclient() {
		return conforcustclient;
	}

	public void setConforcustclient(String conforcustclient) {
		this.conforcustclient = conforcustclient;
	}

	public String getDirectAccessByThirdparty() {
		return directAccessByThirdparty;
	}

	public void setDirectAccessByThirdparty(String directAccessByThirdparty) {
		this.directAccessByThirdparty = directAccessByThirdparty;
	}

	public String getCapappGroupCode() {
		return capappGroupCode;
	}

	public void setCapappGroupCode(String capappGroupCode) {
		this.capappGroupCode = capappGroupCode;
	}

	public String getSemiannualEntlReview() {
		return semiannualEntlReview;
	}

	public void setSemiannualEntlReview(String semiannualEntlReview) {
		this.semiannualEntlReview = semiannualEntlReview;
	}

	public String getTptrainingAwarnessprg() {
		return tptrainingAwarnessprg;
	}

	public void setTptrainingAwarnessprg(String tptrainingAwarnessprg) {
		this.tptrainingAwarnessprg = tptrainingAwarnessprg;
	}

	public String getSplinstrIPreg() {
		return splinstrIPreg;
	}

	public void setSplinstrIPreg(String splinstrIPreg) {
		this.splinstrIPreg = splinstrIPreg;
	}

	public String getConnectivityEstimate() {
		return connectivityEstimate;
	}

	public void setConnectivityEstimate(String connectivityEstimate) {
		this.connectivityEstimate = connectivityEstimate;
	}

	public String getDetailedInfo() {
		return detailedInfo;
	}

	public void setDetailedInfo(String detailedInfo) {
		this.detailedInfo = detailedInfo;
	}

	public List<VirtualConnReason> getVirtualConnReasons() {
		return virtualConnReasons;
	}

	public void setVirtualConnReasons(List<VirtualConnReason> virtualConnReasons) {
		this.virtualConnReasons = virtualConnReasons;
	}
   
}