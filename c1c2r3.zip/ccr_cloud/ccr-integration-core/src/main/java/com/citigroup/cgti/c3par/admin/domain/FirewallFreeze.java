package com.citigroup.cgti.c3par.admin.domain;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Configurable;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.fw.domain.FirewallPolicy;

public class FirewallFreeze extends Base{

	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private FirewallPolicy fwPolicy;

	private Long id;
	
	private String region;
	
	private Date freezeStartDate;
	
	private Date freezeEndDate;
	
	private String comments;
	
	private String updatedBy;
	
	private String freezeStartDateDisplay;
	
	private String freezeEndDateDisplay;
	
	private String updatedDateDisplay;
	
	private String createdBy;
	
	
	public String getFreezeStartDateDisplay() {
		if(getFreezeStartDate() !=null){
			SimpleDateFormat dateformat = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss a");
			return dateformat.format(getFreezeStartDate());
		}
		return freezeStartDateDisplay;
	}

	public void setFreezeStartDateDisplay(String freezeStartDateDisplay) {
		this.freezeStartDateDisplay = freezeStartDateDisplay;
	}

	
	public String getFreezeEndDateDisplay() {
		if(getFreezeEndDate() !=null){
			SimpleDateFormat dateformat = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss a");
			return dateformat.format(getFreezeEndDate());
		}
		return freezeEndDateDisplay;
	}

	public void setFreezeEndDateDisplay(String freezeEndDateDisplay) {
		this.freezeEndDateDisplay = freezeEndDateDisplay;
	}

	public String getUpdatedDateDisplay() {
		if(getUpdated_date() != null){
			SimpleDateFormat dateformat = new SimpleDateFormat("dd-MMM-yyyy HH:mm:ss a");
			return dateformat.format(getUpdated_date());
		}
		
		return updatedDateDisplay;
	}
	
	public void setUpdatedDateDisplay(String updatedDateDisplay) {
		this.updatedDateDisplay = updatedDateDisplay;
	}


	public Date getFreezeStartDate() {
		return freezeStartDate;
	}

	public void setFreezeStartDate(Date freezeStartDate) {
		this.freezeStartDate = freezeStartDate;
	}

	public Date getFreezeEndDate() {
		return freezeEndDate;
	}

	public void setFreezeEndDate(Date freezeEndDate) {
		this.freezeEndDate = freezeEndDate;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	
	
	public FirewallPolicy getFwPolicy() {
		return fwPolicy;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public void setFwPolicy(FirewallPolicy fwPolicy) {
		this.fwPolicy = fwPolicy;
	}


	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	
	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}


	
}
