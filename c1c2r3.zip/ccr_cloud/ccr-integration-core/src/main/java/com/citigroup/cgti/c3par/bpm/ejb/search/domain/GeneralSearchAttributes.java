package com.citigroup.cgti.c3par.bpm.ejb.search.domain;

import java.io.Serializable;


/**
 * The Class GeneralSearchAttributes.
 */
public class GeneralSearchAttributes extends BaseSearchAttributes implements Serializable
{

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -5526177700411255270L;

    /** The process id. */
    private String processId = null;

    /** The process name. */
    private String processName = null;

    /** The relationship id. */
    private String relationshipId = null;

    /** The relationship name. */
    private String relationshipName = null;

    /** The task code. */
    private Long taskCode= null; //lookup

    /** The priority. */
    private Long priority = null;//lookup

    /** The requester soe id. */
    private String requesterSOEId = null;
    
    /** The business Owner soe id. */
    private String businessOwnerSOEId = null;

    /** The region. */
    private Long region = null; //lookup

    /** The sector. */
    private Long sector = null; //lookup

    /** The business unit. */
    private String businessUnit = null; //lookup

    /** The third party. */
    private String thirdParty = null;//lookup

    /** The data classification. */
    private Long dataClassification = null;//lookup
    
    /** The process id. */
    private String versionNo = null;

    /** The Cmp id. */
    private String cmpID;
    
    /** The Service Now ID */
    private String serviceNowID;
    
    private Long role = null;
    
    private String timeInActivity = null;
    
    private Long caspID;
    
    private Long caspDetailID;
    
    private int size;
    
    private String actualRequestor;
    
    private String gocCode;
    
    private String notes;
    
    private Long tag;

    public String getGocCode() {
		return gocCode;
	}
    
    public String getGocCodeForQuery() {
  		return validString(gocCode);
  	}

	public void setGocCode(String gocCode) {
		this.gocCode = gocCode;
	}

	public String getCmpID() {
		return cmpID;
	}

	public void setCmpID(String cmpID) {
		this.cmpID = cmpID;
	}

	public String getServiceNowID() {
		return serviceNowID;
	}

	public void setServiceNowID(String serviceNowID) {
		this.serviceNowID = serviceNowID;
	}

	/**
     * Gets the data classification.
     *
     * @return the data classification
     */
    public Long getDataClassification() {
	return dataClassification;
    }

    public Long getDataClassificationForQuery() {
	return validLong(dataClassification);
    }

    /**
     * Sets the data classification.
     *
     * @param dataClassification the new data classification
     */
    public void setDataClassification(Long dataClassification) {
	this.dataClassification = dataClassification;
    }

    /**
     * Gets the priority.
     *
     * @return the priority
     */
    public Long getPriority() {
	return priority;
    }

    public Long getPriorityForQuery() {
	return validLong(priority);
    }

    /**
     * Sets the priority.
     *
     * @param priority the new priority
     */
    public void setPriority(Long priority) {
	this.priority = priority;
    }

    /**
     * Gets the region.
     *
     * @return the region
     */
    public Long getRegion() {
	return region;
    }

    public Long getRegionForQuery() {
	return validLong(region);
    }

    /**
     * Sets the region.
     *
     * @param region the new region
     */
    public void setRegion(Long region) {
	this.region = region;
    }

    /**
     * Gets the sector.
     *
     * @return the sector
     */
    public Long getSector() {
	return sector;
    }
    
    public Long getSectorForQuery() {
	return validLong(sector);
    }

    /**
     * Sets the sector.
     *
     * @param sector the new sector
     */
    public void setSector(Long sector) {
	this.sector = sector;
    }

    /**
     * Gets the task code.
     *
     * @return the task code
     */
    public Long getTaskCode() {
	return taskCode;
    }

    public Long getTaskCodeForQuery() {
	return validLong(taskCode);
    }

    /**
     * Sets the task code.
     *
     * @param status the new task code
     */
    public void setTaskCode(Long status) {
	this.taskCode = status;
    }

    /**
     * Gets the business unit.
     *
     * @return the business unit
     */
    public String getBusinessUnit() {
	return businessUnit;
    }

    public String getBusinessUnitForQuery() {
	return validString(businessUnit);
    }

    /**
     * Sets the business unit.
     *
     * @param businessUnit the new business unit
     */
    public void setBusinessUnit(String businessUnit) {
	this.businessUnit = businessUnit;
    }

    /**
     * Gets the process id.
     *
     * @return the process id
     */
    public String getProcessId() {
        return processId == null ? null : processId.trim();
    }


	public String getProcessIdForQuery() {
	return validLongAsString(processId);
    }
	
	/**
	 * get the Version No
	 * @return
	 */
	public String getVersionNo() {
		return versionNo;
	}

	/**
	 * set the Version No
	 * @return
	 */
	public void setVersionNo(String versionNo) {
		this.versionNo = versionNo;
	}
	
	public String getVersionNoForQuery() {
		return validLongAsString(versionNo);
	}

    /**
     * Sets the process id.
     *
     * @param processId the new process id
     */
    public void setProcessId(String processId) {
        if(null != processId){
            this.processId = processId.trim();
        }else{
            this.processId = processId;
        }
    }

    /**
     * Gets the process name.
     *
     * @return the process name
     */
    public String getProcessName() {
	return processName;
    }

    public String getProcessNameForQuery() {
	return validString(processName);
    }

    /**
     * Sets the process name.
     *
     * @param processName the new process name
     */
    public void setProcessName(String processName) {
	this.processName = processName;
    }

    /**
     * Gets the relationship id.
     *
     * @return the relationship id
     */
    public String getRelationshipId() {
	return relationshipId;
    }

    public String getRelationshipIdForQuery() {
	return validLongAsString(relationshipId);
    }

    /**
     * Sets the relationship id.
     *
     * @param relationshipId the new relationship id
     */
    public void setRelationshipId(String relationshipId) {
	this.relationshipId = relationshipId;
    }

    /**
     * Gets the relationship name.
     *
     * @return the relationship name
     */
    public String getRelationshipName() {
	return relationshipName;
    }

    public String getRelationshipNameForQuery() {
	return validString(relationshipName);
    }

    /**
     * Sets the relationship name.
     *
     * @param relationshipName the new relationship name
     */
    public void setRelationshipName(String relationshipName) {
	this.relationshipName = relationshipName;
    }

    /**
     * Gets the requester soe id.
     *
     * @return the requester soe id
     */
    public String getRequesterSOEId() {
	return requesterSOEId;
    }

    public String getRequesterSOEIdForQuery() {
	return validString(requesterSOEId);
    }
    /**
     * Sets the requester soe id.
     *
     * @param requesterSOEId the new requester soe id
     */
    public void setRequesterSOEId(String requesterSOEId) {
	this.requesterSOEId = requesterSOEId;
    }

    /**
     * Gets the third party.
     *
     * @return the third party
     */
    public String getThirdParty() {
	return thirdParty;
    }

    public String getThirdPartyForQuery() {
	return validString(thirdParty);
    }

    /**
     * Sets the third party.
     *
     * @param thirdParty the new third party
     */
    public void setThirdParty(String thirdParty) {
	this.thirdParty = thirdParty;
    }
    
    public String getCMPIDforQuery() {
    	return validString(cmpID);
    }
    
    public String getServiceNowIDForQuery(){
    	return validString(serviceNowID);
    }
    
    	public void setRole(Long role) {
		this.role = role;
	}

	public Long getRole() {
		return role;
	}
	
	public Long getRoleForQuery() {
		return validLong(role);
	}
	
	public void setTimeInActivity(String timeInActivity) {
		this.timeInActivity = timeInActivity;
	}

	public String getTimeInActivity() {
		return timeInActivity;
	}
	public String getTimeInActivityForQuery() {
		return validString(timeInActivity);
	}

	public void setCaspID(Long caspID) {
		this.caspID = caspID;
	}

	public Long getCaspID() {
		return caspID;
	}
	public Long getCaspIDForQuery() {
		return validLong(caspID);
	}
	
	public void setCaspDetailID(Long caspDetailID) {
		this.caspDetailID = caspDetailID;
	}

	public Long getCaspDetailID() {
		return caspDetailID;
	}
	public Long getCaspDetailIDForQuery() {
		return validLong(caspDetailID);
	}

	public void setSize(int size) {
		this.size = size;
	}

	public int getSize() {
		return size;
	}

	public String getActualRequestor() {
		return actualRequestor;
	}

	public void setActualRequestor(String actualRequestor) {
		this.actualRequestor = actualRequestor;
	}

    public String getBusinessOwnerSOEId() {
        return businessOwnerSOEId;
    }

    public void setBusinessOwnerSOEId(String businessOwnerSOEId) {
        this.businessOwnerSOEId = businessOwnerSOEId;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
	
    public String getNotesForQuery() {
        return validString(notes);
    }

    public Long getTag() {
        return tag;
    }

    public void setTag(Long tag) {
        this.tag = tag;
    }
	   
    public Long getTagForQuery() {
        return validLong(tag);
    }
}