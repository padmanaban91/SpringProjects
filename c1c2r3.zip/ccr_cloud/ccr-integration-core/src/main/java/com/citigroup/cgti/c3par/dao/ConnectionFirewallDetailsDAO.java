


/** CONFIDENTIAL  AND PROPRIETARY
 * Copyright @ 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is
 * strictly prohibited.
 */

package com.citigroup.cgti.c3par.dao;

import java.io.Serializable;
import java.sql.*;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.model.*;
import com.citigroup.cgti.c3par.dao.lookup.*;
import com.mentisys.model.*;
import com.mentisys.dao.*;
import com.mentisys.dao.query.*;
import com.mentisys.dao.audit.*;


// Reference imports

// Entity name = ConnectionFirewallDetailsDAO
// Table name = CONNECTION_FIREWALL_DETAILS
// Superclass = <none>
// Subclasses = <none>

/**
 * The Class ConnectionFirewallDetailsDAO.
 */
public class ConnectionFirewallDetailsDAO
extends DatabaseAccessObject
implements Serializable
{

    /** The Constant TABLE. */
    public static final String	TABLE = "CONNECTION_FIREWALL_DETAILS";

    /** The custom sequence. */
    private String customSequence;

    /** The database sequence. */
    private String databaseSequence;

    /** The log. */
    private static Logger log = Logger.getLogger(ConnectionFirewallDetailsDAO.class);

    /** The Constant ENTITY_NAME. */
    public static final String	ENTITY_NAME = "ConnectionFirewallDetails";

    /** The Constant COLUMN_ID. */
    public static final String	COLUMN_ID = "ID";

    // Column names
    /** The Constant COLUMN_CIRCUIT_ID. */
    public static final String	COLUMN_CIRCUIT_ID = "CIRCUIT_ID";

    /** The Constant COLUMN_CIRCUIT_ID_LEN. */
    public static final int		COLUMN_CIRCUIT_ID_LEN = 255;

    /** The Constant COLUMN_PRIMARYFIREWALL. */
    public static final String	COLUMN_PRIMARYFIREWALL = "PRIMARY_FIREWALL";

    /** The Constant COLUMN_ACL. */
    public static final String	COLUMN_ACL = "ACL";

    /** The Constant COLUMN_ACLVARIANCE. */
    public static final String	COLUMN_ACLVARIANCE = "ACL_VARIANCE";

    /** The Constant COLUMN_ACLVARIANCE_LEN. */
    public static final int		COLUMN_ACLVARIANCE_LEN = 255;

    /** The Constant COLUMN_ROUTERID. */
    public static final String	COLUMN_ROUTERID = "ROUTER_ID";

    /** The Constant COLUMN_ROUTERID_LEN. */
    public static final int		COLUMN_ROUTERID_LEN = 255;

    /** The Constant COLUMN_LOCATION. */
    public static final String	COLUMN_LOCATION = "LOCATION";

    /** The Constant COLUMN_LOCATION_LEN. */
    public static final int		COLUMN_LOCATION_LEN = 255;
    // Column names of references
    /** The Constant COLUMN_BANDWIDTH_ID. */
    public static final String	COLUMN_BANDWIDTH_ID = "BANDWIDTH_ID";

    /** The Constant COLUMN_CONNECTIONREQUEST_ID. */
    public static final String	COLUMN_CONNECTIONREQUEST_ID = "CONNECTION_REQUEST_ID";

    /** The Constant COLUMN_CONNECTION_ID. */
    public static final String	COLUMN_CONNECTION_ID = "CONNECTION_ID";

    /** The Constant COLUMN_FIREWALL_ID. */
    public static final String	COLUMN_FIREWALL_ID = "FIREWALL_ID";

    // DAO Queries
    /** The SELEC t_ i d_ stmt. */
    private static String SELECT_ID_STMT = "SELECT "  + COLUMN_ID + " FROM " + ConnectionFirewallDetailsDAO.TABLE;

    /** The SELEC t_ stmt. */
    private static String SELECT_STMT = "SELECT "  + COLUMN_ID
    + ", " + COLUMN_CIRCUIT_ID
    + ", " + COLUMN_PRIMARYFIREWALL
    + ", " + COLUMN_ACL
    + ", " + COLUMN_ACLVARIANCE
    + ", " + COLUMN_ROUTERID
    + ", " + COLUMN_LOCATION
    + ", " + COLUMN_BANDWIDTH_ID
    + ", " + COLUMN_CONNECTIONREQUEST_ID
    + ", " + COLUMN_CONNECTION_ID
    + ", " + COLUMN_FIREWALL_ID
    + " FROM " + ConnectionFirewallDetailsDAO.TABLE;

    /** The SELEC t_ b y_ i d_ stmt. */
    private static String SELECT_BY_ID_STMT = ConnectionFirewallDetailsDAO.SELECT_STMT + " WHERE " + COLUMN_ID + " = ?";

    /** The UPDAT e_ b y_ i d_ stmt. */
    private static String UPDATE_BY_ID_STMT = "UPDATE " + ConnectionFirewallDetailsDAO.TABLE + " SET "
    + COLUMN_CIRCUIT_ID + " = ? "
    + ", " + COLUMN_PRIMARYFIREWALL + " = ? "
    + ", " + COLUMN_ACL + " = ? "
    + ", " + COLUMN_ACLVARIANCE + " = ? "
    + ", " + COLUMN_ROUTERID + " = ? "
    + ", " + COLUMN_LOCATION + " = ? "
    + ", " + COLUMN_BANDWIDTH_ID + " = ? "
    + ", " + COLUMN_CONNECTIONREQUEST_ID + " = ? "
    + ", " + COLUMN_CONNECTION_ID + " = ? "
    + ", " + COLUMN_FIREWALL_ID + " = ? "
    + " WHERE " + COLUMN_ID + " = ?";

    /** The INSER t_ stmt. */
    private static String INSERT_STMT = "INSERT INTO " + ConnectionFirewallDetailsDAO.TABLE
    + "(" + COLUMN_ID
    + ", " + COLUMN_CIRCUIT_ID 
    + ", " + COLUMN_PRIMARYFIREWALL 
    + ", " + COLUMN_ACL 
    + ", " + COLUMN_ACLVARIANCE 
    + ", " + COLUMN_ROUTERID 
    + ", " + COLUMN_LOCATION 
    + ", " + COLUMN_BANDWIDTH_ID
    + ", " + COLUMN_CONNECTIONREQUEST_ID
    + ", " + COLUMN_CONNECTION_ID
    + ", " + COLUMN_FIREWALL_ID
    + ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    /** The DELET e_ stmt. */
    private static String DELETE_STMT = "DELETE FROM " + ConnectionFirewallDetailsDAO.TABLE + " WHERE ID = ?";



    //======================================================================
    /**
     * Simple factory method.
     *
     * @param session the session
     * @return the connection firewall details dao
     */
    public static ConnectionFirewallDetailsDAO createInstance(DatabaseSession session)
    {
	return new ConnectionFirewallDetailsDAO(session);
    }

    // Contructors
    //======================================================================
    /**
     * Instantiates a new connection firewall details dao.
     *
     * @param session the session
     */
    public ConnectionFirewallDetailsDAO(DatabaseSession session)
    {
	super(session);
	log.debug("Creating ConnectionFirewallDetailsDAO (" + s_CreateCount + ")");
    }

    //Sequence Generator
    /**
     * Sets the custom sequence.
     *
     * @param customSequence the new custom sequence
     */
    public void setCustomSequence(String customSequence){

	this.customSequence=customSequence;
    }

    //Sequence Generator
    /**
     * Sets the database sequence.
     *
     * @param databaseSequence the new database sequence
     */
    public void setDatabaseSequence(String databaseSequence){

	this.databaseSequence=databaseSequence;
    }


    // Insert
    //======================================================================
    /**
     * Insert an entity into the database.
     *
     * @param entity The ConnectionFirewallDetailsEntity to insert
     * @return The id that was assigned to the entity
     * @throws DatabaseException the database exception
     */
    public Long insert(ConnectionFirewallDetailsEntity entity) throws DatabaseException
    {
	return insert(entity, null, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long insert(ConnectionFirewallDetailsEntity entity, boolean reset) throws DatabaseException
    {
	return insert(entity, null, reset);
    }

    //======================================================================
    /**
     * Insert an entity into the database.
     *
     * @param entity The ConnectionFirewallDetailsEntity to insert
     * @param archiver The archiver object used for tracking changes to the entity
     * @return The id that was assigned to the entity
     * @throws DatabaseException the database exception
     */
    public Long insert(ConnectionFirewallDetailsEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	return insert(entity, archiver, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param archiver the archiver
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long insert(ConnectionFirewallDetailsEntity entity, AuditArchiver archiver, boolean reset) throws DatabaseException
    {
	log.debug("Inserting ConnectionFirewallDetailsEntity");
	DatabaseSession session = getSession();

	if(primaryKeyExists(entity, false, session))
	    throw new DatabaseException("Could not insert '" + ConnectionFirewallDetailsDAO.ENTITY_NAME + "' with id = " + entity.getId() + " due to unique key constraint violation", null);

	Connection connection = null;

	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    // Update FOREIGN_KEY references for which we are the OWNER

	    // Generate a new id
	    long id=-1;
	    if(customSequence !=null)
		id = KeyGenerator.getInstance().getNextKey(session, customSequence);
	    else if(databaseSequence != null){
		try{
		    st=connection.prepareStatement("Select "+databaseSequence+".nextval from dual");
		    rs = st.executeQuery();
		    if (rs.next())
		    {
			id=rs.getLong(1);
		    }
		}finally{
		    try{
			if(rs!=null)rs.close();
			if(st!=null)st.close();
		    }catch(Exception xe){}

		}
	    }
	    else
		id = KeyGenerator.getInstance().getNextKey(session, ConnectionFirewallDetailsDAO.ENTITY_NAME);
	    entity.setId(Long.valueOf(id));
	    int position = 1;
	    st = connection.prepareStatement(INSERT_STMT);
	    setLongToStatement(st, position++, entity.getId());

	    // Attributes
	    position = setStringToStatement(st, position, entity.getCircuit_id(), COLUMN_CIRCUIT_ID_LEN);
	    position = setBooleanToStatement(st, position, entity.getPrimaryFirewall());
	    position = setBooleanToStatement(st, position, entity.getAcl());
	    position = setStringToStatement(st, position, entity.getAclVariance(), COLUMN_ACLVARIANCE_LEN);
	    position = setStringToStatement(st, position, entity.getRouterId(), COLUMN_ROUTERID_LEN);
	    position = setStringToStatement(st, position, entity.getLocation(), COLUMN_LOCATION_LEN);

	    // Association references
	    position = updateReferences(st, entity, position);

	    st.executeUpdate();
	    entity.setPrimaryKey(Long.valueOf(id));

	    // Update FOREIGN_KEY references for which we are the OWNER
	    if (archiver != null)
	    {
		archiver.storeSnapshotAuditLogForEntity(entity, "create");
	    }
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not insert '" + ConnectionFirewallDetailsDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return entity.getPrimaryKey();
    }

    //======================================================================
    /**
     * Update the state of an entity. If the entity doesn't exist in the database it gets automatically added.
     *
     * @param entity The ConnectionFirewallDetailsEntity to update.
     * @return The Id of the entity. If the entity had to be inserted this is the id assigned to it.
     * @throws DatabaseException the database exception
     */
    public Long update(ConnectionFirewallDetailsEntity entity) throws DatabaseException
    {
	return update(entity, null, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(ConnectionFirewallDetailsEntity entity, boolean reset) throws DatabaseException
    {
	return update(entity, null, reset);
    }

    //======================================================================
    /**
     * Update the state of an entity. If the entity doesn't exist in the database it gets automatically added.
     *
     * @param entity The ConnectionFirewallDetailsEntity to update
     * @param archiver The archiver object used for tracking changes to the entity
     * @return The Id of the entity. If the entity had to be inserted this is the id assigned to it.
     * @throws DatabaseException the database exception
     */
    public Long update(ConnectionFirewallDetailsEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	return update(entity, archiver, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param archiver the archiver
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(ConnectionFirewallDetailsEntity entity, AuditArchiver archiver, boolean reset) throws DatabaseException
    {
	if (entity.getPrimaryKey() == null)
	{
	    // Not created yet
	    return insert(entity, archiver, reset);
	}
	if (!entity.isModified())
	{
	    return entity.getPrimaryKey();
	}
	log.debug("Updating ConnectionFirewallDetailsEntity [" + entity.getId() + "]");
	DatabaseSession session = getSession();

	if(primaryKeyExists(entity, true, session))
	    throw new DatabaseException("Could not update '" + ConnectionFirewallDetailsDAO.ENTITY_NAME + "' with id = " + entity.getId() + " due to unique key constraint violation", null);

	Connection		connection = null;
	PreparedStatement st = null;
	ResultSet 		rs = null;

	try
	{
	    connection = session.getConnection();
	    // Update FOREIGN_KEY references for which we are the OWNER

	    int position = 1;
	    st = connection.prepareStatement(UPDATE_BY_ID_STMT);

	    // Attributes
	    position = setStringToStatement(st, position, entity.getCircuit_id(), COLUMN_CIRCUIT_ID_LEN);
	    position = setBooleanToStatement(st, position, entity.getPrimaryFirewall());
	    position = setBooleanToStatement(st, position, entity.getAcl());
	    position = setStringToStatement(st, position, entity.getAclVariance(), COLUMN_ACLVARIANCE_LEN);
	    position = setStringToStatement(st, position, entity.getRouterId(), COLUMN_ROUTERID_LEN);
	    position = setStringToStatement(st, position, entity.getLocation(), COLUMN_LOCATION_LEN);

	    // Association references
	    position = updateReferences(st, entity, position);

	    // where
	    setLongToStatement(st, position++, entity.getPrimaryKey());

	    st.executeUpdate();

	    // Update FOREIGN_KEY references for which we are the OWNER
	    if (archiver != null)
	    {
		archiver.storeAuditLogForEntity(entity, "update");
	    }
	    if (reset)
	    {
		session.addToResetList(entity);
	    }
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not update '" + ConnectionFirewallDetailsDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return entity.getPrimaryKey();
    }

    //======================================================================
    /**
     * Get the entity determined by the id. This method automatically loads all references maintained by the entity.
     *
     * @param id A Long identifying the entity to get.
     * @return The entity or null if no entity with that id exists.
     * @throws DatabaseException the database exception
     */
    public ConnectionFirewallDetailsEntity get(Long id) throws DatabaseException
    {
	return get(id, true);
    }

    //======================================================================
    /**
     * Get the entity determined by the id.
     *
     * @param id A Long identifying the entity to get.
     * @param load_refs A boolean that determines wether to load all the entities references. True to load, false to defer loading until later.
     * @return The entity or null if no entity with that id exists.
     * @throws DatabaseException the database exception
     */
    public ConnectionFirewallDetailsEntity get(Long id, boolean load_refs) throws DatabaseException
    {
	Long id_to_get = id;
	ConnectionFirewallDetailsEntity obj = (ConnectionFirewallDetailsEntity) getSession().getObjectFromSession(ENTITY_NAME, id_to_get);
	log.debug("Getting ConnectionFirewallDetailsEntity with id = " + id_to_get); 
	if(obj != null)
	{
	    log.debug(">>> ConnectionFirewallDetailsEntity >>> already LOADED !!!"); 
	}

	if(obj == null)
	{
	    DatabaseSession session = getSession();
	    Connection connection = null;

	    PreparedStatement st = null;
	    ResultSet rs = null;

	    try
	    {
		connection = session.getConnection();
		//				st = session.getPreparedStatement(SELECT_BY_ID_STMT);
		st = connection.prepareStatement(SELECT_BY_ID_STMT);
		setLongToStatement(st, 1, id_to_get);
		rs = st.executeQuery();

		if (rs.next())
		{
		    obj = (ConnectionFirewallDetailsEntity) createEntity(rs);
		}
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not load " + ConnectionFirewallDetailsDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	}

	if (obj != null && load_refs)
	{
	    try
	    {
		// Load the associated objects
		loadReferences(obj);
		obj.setModified(false);
	    }
	    catch (DatabaseException e)
	    {
		throw new DatabaseException("Failed to load references of " + ConnectionFirewallDetailsDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	}
	log.debug("DONE Getting ConnectionFirewallDetailsEntity with id = " + id_to_get); 

	return obj;
    }


    //======================================================================
    /**
     * Retrieve the entities indicated by the list argument provided.
     *
     * @param id_list list of entity ids to load
     * @param load_refs Flag that determines wether the references should be loaded as part of the operation
     * @return A List of all the entities loaded.
     * @throws DatabaseException the database exception
     */
    public List get(List id_list, boolean load_refs) throws DatabaseException
    {
	List 	entity_list = new ArrayList(16);
	if(id_list != null && id_list.size() > 0)
	{
	    DatabaseSession 	session = getSession();
	    Connection 			connection = null;
	    Statement 			st = null;
	    ResultSet 			rs = null;
	    ConnectionFirewallDetailsEntity 		entity = null;

	    try
	    {
		StringBuffer statement = new StringBuffer(SELECT_STMT + " WHERE " + COLUMN_ID + " IN (");

		Long only = null;
		long count = 0;
		Iterator iter = id_list.iterator();
		while(iter.hasNext())
		{
		    Long id = (Long)iter.next();
		    entity = (ConnectionFirewallDetailsEntity) getSession().getObjectFromSession(ENTITY_NAME, id);
		    if(entity != null)
		    {
			if(load_refs)
			{
			    loadReferences(entity);
			}
			entity_list.add(entity);
		    }
		    else // add the the id to the statement
		    {
			if(count++ > 0)
			{
			    statement.append(",");					
			}
			statement.append(id.toString());					
			only = id;
		    }
		}

		// check if we need to explicitly load any entities
		if(count == 1)
		{
		    entity_list.add(get(only, load_refs));					
		}
		else if(count > 1)
		{
		    statement.append(")");	// Close the statenemt's IN clause					
		    log.debug("DAO.get(List): executing statement. Count = (" + count + ") --> " + statement.toString());
		    connection = session.getConnection();
		    //					st = connection.prepareStatement(statement.toString());
		    //					rs = st.executeQuery();
		    st = connection.createStatement();
		    rs = st.executeQuery(statement.toString());

		    while(rs.next())
		    {
			entity = (ConnectionFirewallDetailsEntity) createEntity(rs);
			if(load_refs)
			{
			    loadReferences(entity);
			    entity.setModified(false);
			}
			entity_list.add(entity);					
		    }
		}
	    }
	    catch(SQLException e)
	    {
		throw new DatabaseException("Failed to load all entities of type " + ConnectionFirewallDetailsDAO.ENTITY_NAME + ".", e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		if(connection != null)
		{
		    session.releaseConnection();
		}
	    }
	}

	return entity_list;	
    }

    //======================================================================
    /**
     * Retrieve all entities.
     *
     * @param load_refs Flag that determines wether the references should be loaded as part of the operation
     * @return The list of all entities of type ConnectionFirewallDetailsEntity
     * @throws DatabaseException the database exception
     */
    public List getAll(boolean load_refs) throws DatabaseException
    {
	List 				entity_list = query(new Condition(), load_refs);
	/*
		DatabaseSession 	session = getSession();
		Connection 			connection = null;
		Statement 	st = null;
		ResultSet 			rs = null;
		ConnectionFirewallDetailsEntity 		entity = null;

		try
		{
			String select_stmt = "SELECT * FROM CONNECTION_FIREWALL_DETAILS";
			connection = session.getConnection();

			st = connection.createStatement();
			rs = st.executeQuery(select_stmt.toString());

			while(rs.next())
			{
				entity = (ConnectionFirewallDetailsEntity) createEntity(rs);
				if(load_refs)
				{
					loadReferences(entity);
					entity.setModified(false);
				}
				entity_list.add(entity);					
			}
		}
		catch(SQLException e)
		{
			throw new DatabaseException("Failed to load all entities of type " + ConnectionFirewallDetailsDAO.ENTITY_NAME + ".", e);
		}
		finally
		{
			closeResultSet(rs);
			closeStatement(st);
			session.releaseConnection();
		}
	 */
	return entity_list;	
    }	

    //======================================================================
    /**
     * Retrieve the IDs of all entities.
     *
     * @return A list of IDs of all the entities of type ConnectionFirewallDetailsEntity
     * @throws DatabaseException the database exception
     */
    public List getAllIds() throws DatabaseException
    {
	return queryForId(new Condition());
    }

    //======================================================================
    /**
     * Checks wether the entity with the given ID already exists in the database.
     *
     * @param id The id of the entity to test.
     * @return A boolean that indicates exsitence (true) or lack thereof (false)
     * @throws DatabaseException the database exception
     */
    public boolean exists(String id) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;

	PreparedStatement st = null;
	ResultSet rs = null;
	boolean exists = false;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_BY_ID_STMT);
	    st.setString(1, id);
	    rs = st.executeQuery();
	    exists = rs.next();
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not verify existence of '" + ConnectionFirewallDetailsDAO.ENTITY_NAME + "' with id = "
		    + id, e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return exists;
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param id The id of the entity to be deleted from the database.
     * @throws DatabaseException the database exception
     */
    public void delete(Long id) throws DatabaseException
    {
	if(id != null)
	{
	    ConnectionFirewallDetailsEntity entity = get(id, false);
	    delete(entity, null);
	}
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param id The id of the entity to be deleted from the database.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(Long id, AuditArchiver archiver) throws DatabaseException
    {
	if(id != null)
	{
	    ConnectionFirewallDetailsEntity entity = get(id, false);
	    delete(entity, archiver);
	}
    }

    //======================================================================
    /**
     * Delete a list of entities from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity_ids A list of Long objects providing the ids of the entities to be deleted.
     * @throws DatabaseException the database exception
     */
    public void delete(List entity_ids) throws DatabaseException
    {
	delete(entity_ids, null);
    }

    //======================================================================
    /**
     * Delete a list of entities from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity_ids A list of Long objects providing the ids of the entities to be deleted.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(List entity_ids, AuditArchiver archiver) throws DatabaseException
    {
	if(entity_ids != null)
	{
	    Iterator iter = entity_ids.iterator();
	    while(iter.hasNext())
	    {
		Long id = (Long)iter.next();		
		delete(id, archiver);
	    }
	}
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity The entity to be deleted from the database.
     * @throws DatabaseException the database exception
     */
    public void delete(ConnectionFirewallDetailsEntity entity) throws DatabaseException
    {
	delete(entity, null);
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity The entity to be deleted from the database.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(ConnectionFirewallDetailsEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	if(entity != null && entity.getId() != null)
	{
	    DatabaseSession session = getSession();
	    Connection connection = null;

	    if (archiver != null)
	    {
		archiver.storeSnapshotAuditLogForEntity(entity, "delete");
	    }


	    // Clear all associations and remove all compositions
	    deleteManyAssociations(entity);

	    // Delete ourself
	    PreparedStatement st = null;
	    ResultSet rs = null;

	    try
	    {
		connection = session.getConnection();
		// Generate a new id
		int position = 1;
		st = connection.prepareStatement(DELETE_STMT);
		position = setLongToStatement(st, position, entity.getPrimaryKey());

		st.execute();

		// COMPOSITION Delete ONE objects...

		entity.setPrimaryKey(null);
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not delete '" + ConnectionFirewallDetailsDAO.ENTITY_NAME + "' with id = "
			+ entity.getId(), e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	}
    }

    //======================================================================
    /**
     * Delete many associations.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    protected void deleteManyAssociations(ConnectionFirewallDetailsEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;

	try
	{
	    connection = session.getConnection();
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to perform association clean up during delete of'" + ConnectionFirewallDetailsDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    session.releaseConnection();
	}

    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#buildEntity(java.sql.ResultSet, com.mentisys.model.Entity)
     */
    protected void buildEntity(ResultSet rs, Entity obj) throws DatabaseException
    {
	ConnectionFirewallDetailsEntity entity = (ConnectionFirewallDetailsEntity) obj;
	try
	{
	    // TODO: Figure a better way of dealing with the absence of any attribute
	    dummyExceptionTosser(false);

	    int index = 1;

	    //			entity.setCircuit_id(getStringFromResultSet(rs, COLUMN_CIRCUIT_ID));
	    entity.setCircuit_id(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalCircuit_id(entity.getCircuit_id());
	    //			entity.setPrimaryFirewall(getBooleanFromResultSet(rs, COLUMN_PRIMARYFIREWALL));
	    entity.setPrimaryFirewall(getBooleanFromResultSetIndexed(rs, ++index));
	    entity.setOriginalPrimaryFirewall(entity.getPrimaryFirewall());
	    //			entity.setAcl(getBooleanFromResultSet(rs, COLUMN_ACL));
	    entity.setAcl(getBooleanFromResultSetIndexed(rs, ++index));
	    entity.setOriginalAcl(entity.getAcl());
	    //			entity.setAclVariance(getStringFromResultSet(rs, COLUMN_ACLVARIANCE));
	    entity.setAclVariance(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalAclVariance(entity.getAclVariance());
	    //			entity.setRouterId(getStringFromResultSet(rs, COLUMN_ROUTERID));
	    entity.setRouterId(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalRouterId(entity.getRouterId());
	    //			entity.setLocation(getStringFromResultSet(rs, COLUMN_LOCATION));
	    entity.setLocation(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalLocation(entity.getLocation());

	    // Single References
	    //			entity.setBandwidthId(getLongFromResultSet(rs, COLUMN_BANDWIDTH_ID));
	    entity.setBandwidthId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalBandwidthId(entity.getBandwidthId());
	    //			entity.setConnectionRequestId(getLongFromResultSet(rs, COLUMN_CONNECTIONREQUEST_ID));
	    entity.setConnectionRequestId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalConnectionRequestId(entity.getConnectionRequestId());
	    //			entity.setConnectionId(getLongFromResultSet(rs, COLUMN_CONNECTION_ID));
	    entity.setConnectionId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalConnectionId(entity.getConnectionId());
	    //			entity.setFirewallId(getLongFromResultSet(rs, COLUMN_FIREWALL_ID));
	    entity.setFirewallId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalFirewallId(entity.getFirewallId());

	    // Load multi reference Ids
	    loadReferenceIds(entity);

	    obj.setModified(false);
	}
	catch (DatabaseException e)
	{
	    throw new DatabaseException("Cannot build database entity object from result set", e);
	}
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#createEntity(java.sql.ResultSet)
     */
    protected Entity createEntity(ResultSet rs) throws DatabaseException
    {
	ConnectionFirewallDetailsEntity entity = null;
	try
	{
	    // get the ID of the entity we're to create, and check if that is already held in the session. Thereby allowing us to
	    // bypass the creation altogether and reuse the one in existence.			
	    Long _id = getLongFromResultSet(rs, COLUMN_ID);
	    entity = (ConnectionFirewallDetailsEntity) getSession().getObjectFromSession(ENTITY_NAME, _id);
	    if (entity == null)
	    {        
		entity = new ConnectionFirewallDetailsEntity(_id);
		buildEntity(rs, entity);
		getSession().addObjectToSession(entity, ENTITY_NAME, _id);
	    }
	}
	catch (DatabaseException e)
	{
	    throw new DatabaseException("Cannot create database entity object from result set", e);
	}
	return entity;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.AccessObject#getQuerySelectString()
     */
    protected String getQuerySelectString()
    {
	return SELECT_STMT;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#getQuerySelectIdString()
     */
    protected String getQuerySelectIdString()
    {
	return SELECT_ID_STMT;
    }

    //======================================================================
    /**
     * Load the IDs of the external references for the entity.
     *
     * @param obj The entity for which to load the IDs of its references
     * @throws DatabaseException the database exception
     */
    public void loadReferenceIds(Entity obj) throws DatabaseException
    {
	ConnectionFirewallDetailsEntity entity = (ConnectionFirewallDetailsEntity)obj;
    }

    //======================================================================
    /**
     * Load the external references for the entity.
     *
     * @param obj The entity for which to load its references
     * @throws DatabaseException the database exception
     */
    public void loadReferences(Entity obj) throws DatabaseException
    {
	if (obj.isReferencesLoaded())
	{
	    log.debug("FirewallMasterDAO.loadReferences(): References for ConnectionFirewallDetailsEntity [" + obj.getId() + "] already loaded");
	    return;
	}
	log.debug("FirewallMasterDAO.loadReferences(): Loading references for ConnectionFirewallDetailsEntity [" + obj.getId() + "].");
	obj.setReferencesLoaded(true);
	try
	{
	    ConnectionFirewallDetailsEntity entity = (ConnectionFirewallDetailsEntity)obj;

	    Long bandwidthId = entity.getBandwidthId();
	    if (bandwidthId != null)
	    {
		// Use lookup for optimized access
		entity.setBandwidth(GenericLookupLookup.getInstance().getById(getSession(), bandwidthId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalBandwidth(entity.getBandwidth());
	    }

	    Long connectionRequestId = entity.getConnectionRequestId();
	    if (connectionRequestId != null)
	    {
		//			ConnectionRequestDAO connectionRequestDAO = new ConnectionRequestDAO(getSession());
		ConnectionRequestDAO connectionRequestDAO = getConnectionRequestDAO();
		entity.setConnectionRequest((ConnectionRequestEntity)connectionRequestDAO.get(connectionRequestId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalConnectionRequest(entity.getConnectionRequest());
	    }

	    Long connectionId = entity.getConnectionId();
	    if (connectionId != null)
	    {
		//			ConnectionDAO connectionDAO = new ConnectionDAO(getSession());
		ConnectionDAO connectionDAO = getConnectionDAO();
		entity.setConnection((ConnectionEntity)connectionDAO.get(connectionId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalConnection(entity.getConnection());
	    }

	    Long firewallId = entity.getFirewallId();
	    if (firewallId != null)
	    {
		//			FirewallMasterDAO firewallDAO = new FirewallMasterDAO(getSession());
		FirewallMasterDAO firewallDAO = getFirewallDAO();
		entity.setFirewall((FirewallMasterEntity)firewallDAO.get(firewallId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalFirewall(entity.getFirewall());
	    }

	}
	catch(Exception e)
	{
	    obj.setReferencesLoaded(false);
	    throw new DatabaseException("Failed to load references for ConnectionFirewallDetailsEntity [" + obj.getId() + "].", e);
	}
    }

    //======================================================================
    /**
     * Load bandwidth with id.
     *
     * @param id the id
     * @return the generic lookup entity
     * @throws DatabaseException the database exception
     */
    public GenericLookupEntity loadBandwidthWithId(Long id) throws DatabaseException
    {
	GenericLookupEntity entity = null;
	if (id != null)
	{
	    // Use lookup for optimized access
	    entity = GenericLookupLookup.getInstance().getById(getSession(), id);
	}
	return entity;
    }
    //======================================================================
    /**
     * Load connection request with id.
     *
     * @param id the id
     * @return the connection request entity
     * @throws DatabaseException the database exception
     */
    public ConnectionRequestEntity loadConnectionRequestWithId(Long id) throws DatabaseException
    {
	ConnectionRequestEntity entity = null;
	if (id != null)
	{
	    //			ConnectionRequestDAO connectionRequestDAO = new ConnectionRequestDAO(getSession());
	    ConnectionRequestDAO connectionRequestDAO = getConnectionRequestDAO();
	    entity = (ConnectionRequestEntity)connectionRequestDAO.get(id);
	}
	return entity;
    }
    //======================================================================
    /**
     * Load connection with id.
     *
     * @param id the id
     * @return the connection entity
     * @throws DatabaseException the database exception
     */
    public ConnectionEntity loadConnectionWithId(Long id) throws DatabaseException
    {
	ConnectionEntity entity = null;
	if (id != null)
	{
	    //			ConnectionDAO connectionDAO = new ConnectionDAO(getSession());
	    ConnectionDAO connectionDAO = getConnectionDAO();
	    entity = (ConnectionEntity)connectionDAO.get(id);
	}
	return entity;
    }
    //======================================================================
    /**
     * Load firewall with id.
     *
     * @param id the id
     * @return the firewall master entity
     * @throws DatabaseException the database exception
     */
    public FirewallMasterEntity loadFirewallWithId(Long id) throws DatabaseException
    {
	FirewallMasterEntity entity = null;
	if (id != null)
	{
	    //			FirewallMasterDAO firewallDAO = new FirewallMasterDAO(getSession());
	    FirewallMasterDAO firewallDAO = getFirewallDAO();
	    entity = (FirewallMasterEntity)firewallDAO.get(id);
	}
	return entity;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#updateReferences(java.sql.PreparedStatement, com.mentisys.model.Entity, int)
     */
    protected int updateReferences(PreparedStatement st, Entity obj, int position)
    throws DatabaseException, SQLException
    {
	ConnectionFirewallDetailsEntity entity = (ConnectionFirewallDetailsEntity) obj;

	setLongToStatement(st, position++, entity.getBandwidth() != null ? entity.getBandwidth().getId() : entity.getBandwidthId());
	setLongToStatement(st, position++, entity.getConnectionRequest() != null ? entity.getConnectionRequest().getId() : entity.getConnectionRequestId());
	setLongToStatement(st, position++, entity.getConnection() != null ? entity.getConnection().getId() : entity.getConnectionId());
	setLongToStatement(st, position++, entity.getFirewall() != null ? entity.getFirewall().getId() : entity.getFirewallId());

	return position;
    }

    // Single non-composition 'bandwidth' helpers 'ConnectionFirewallDetails' does not need helper
    // Single non-composition 'connectionRequest' helpers 'ConnectionFirewallDetails' does not need helper
    // Single non-composition 'connection' helpers 'ConnectionFirewallDetails' does not need helper
    // Single non-composition 'firewall' helpers 'ConnectionFirewallDetails' does not need helper

    // Reference DAO caching methods	
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A GenericLookupDAO object 
     */
    protected GenericLookupDAO getBandwidthDAO()
    {
	GenericLookupDAO dao = (GenericLookupDAO)getSession().getDAO("GenericLookup");  
	if(dao == null)
	{
	    dao = new GenericLookupDAO(getSession());  		
	    getSession().putDAO("GenericLookup", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A ConnectionRequestDAO object 
     */
    protected ConnectionRequestDAO getConnectionRequestDAO()
    {
	ConnectionRequestDAO dao = (ConnectionRequestDAO)getSession().getDAO("ConnectionRequest");  
	if(dao == null)
	{
	    dao = new ConnectionRequestDAO(getSession());  		
	    getSession().putDAO("ConnectionRequest", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A ConnectionDAO object 
     */
    protected ConnectionDAO getConnectionDAO()
    {
	ConnectionDAO dao = (ConnectionDAO)getSession().getDAO("Connection");  
	if(dao == null)
	{
	    dao = new ConnectionDAO(getSession());  		
	    getSession().putDAO("Connection", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A FirewallMasterDAO object 
     */
    protected FirewallMasterDAO getFirewallDAO()
    {
	FirewallMasterDAO dao = (FirewallMasterDAO)getSession().getDAO("FirewallMaster");  
	if(dao == null)
	{
	    dao = new FirewallMasterDAO(getSession());  		
	    getSession().putDAO("FirewallMaster", dao);
	}		
	return dao;
    }

    //=====================================================================
    // Query helpers: 
    //=====================================================================

    //=====================================================================
    /**
     * Find all entities where the property [Circuit_id] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByCircuit_id(String value) throws DatabaseException
    {
	return findByCircuit_id(value, getSession());
    }

    /**
     * Find by circuit_id.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByCircuit_id(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionFirewallDetailsDAO.TABLE + " WHERE " + COLUMN_CIRCUIT_ID + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [PrimaryFirewall] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByPrimaryFirewall(Boolean value) throws DatabaseException
    {
	return findByPrimaryFirewall(value, getSession());
    }

    /**
     * Find by primary firewall.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByPrimaryFirewall(Boolean value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionFirewallDetailsDAO.TABLE + " WHERE " + COLUMN_PRIMARYFIREWALL + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [Acl] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByAcl(Boolean value) throws DatabaseException
    {
	return findByAcl(value, getSession());
    }

    /**
     * Find by acl.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByAcl(Boolean value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionFirewallDetailsDAO.TABLE + " WHERE " + COLUMN_ACL + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [AclVariance] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByAclVariance(String value) throws DatabaseException
    {
	return findByAclVariance(value, getSession());
    }

    /**
     * Find by acl variance.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByAclVariance(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionFirewallDetailsDAO.TABLE + " WHERE " + COLUMN_ACLVARIANCE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [RouterId] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByRouterId(String value) throws DatabaseException
    {
	return findByRouterId(value, getSession());
    }

    /**
     * Find by router id.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByRouterId(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionFirewallDetailsDAO.TABLE + " WHERE " + COLUMN_ROUTERID + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [Location] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByLocation(String value) throws DatabaseException
    {
	return findByLocation(value, getSession());
    }

    /**
     * Find by location.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByLocation(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionFirewallDetailsDAO.TABLE + " WHERE " + COLUMN_LOCATION + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [Bandwidth] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByBandwidth(Long value) throws DatabaseException
    {
	return findByBandwidth(value, getSession());
    }

    /**
     * Find by bandwidth.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByBandwidth(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionFirewallDetailsDAO.TABLE + " WHERE " + COLUMN_BANDWIDTH_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [ConnectionRequest] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByConnectionRequest(Long value) throws DatabaseException
    {
	return findByConnectionRequest(value, getSession());
    }

    /**
     * Find by connection request.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByConnectionRequest(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionFirewallDetailsDAO.TABLE + " WHERE " + COLUMN_CONNECTIONREQUEST_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [Connection] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByConnection(Long value) throws DatabaseException
    {
	return findByConnection(value, getSession());
    }

    /**
     * Find by connection.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByConnection(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionFirewallDetailsDAO.TABLE + " WHERE " + COLUMN_CONNECTION_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [Firewall] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByFirewall(Long value) throws DatabaseException
    {
	return findByFirewall(value, getSession());
    }

    /**
     * Find by firewall.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByFirewall(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + ConnectionFirewallDetailsDAO.TABLE + " WHERE " + COLUMN_FIREWALL_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find entities by property helper.
     *
     * @param sel_stmt the sel_stmt
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static protected List findEntitiesByPropertyHelper(String sel_stmt, DatabaseSession session) throws DatabaseException
    {
	List entities = null;
	Connection connection = null;
	Statement st = null;
	ResultSet rs = null;

	log.debug(sel_stmt);

	try
	{
	    connection = session.getConnection();
	    st = connection.createStatement();
	    rs = st.executeQuery(sel_stmt);

	    List found_entities = new ArrayList();		
	    while(rs.next())
	    {
		found_entities.add(Long.valueOf(rs.getLong(1)));			
	    }

	    if(found_entities.size() > 0)
	    {
		entities = found_entities;
	    }

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failure to find entities by Firewall", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    if(connection != null)
	    {
		session.releaseConnection();
	    }
	}

	return entities;
    }


    //=====================================================================
    /**
     * Dummy exception tosser.
     *
     * @param flag the flag
     * @throws DatabaseException the database exception
     */
    protected void dummyExceptionTosser(boolean flag) throws DatabaseException
    {
	if(flag)
	{
	    throw new DatabaseException("This exception should never be thrown....", new Exception("Another dummy"));
	}
    }

    /**
     * Primary key exists.
     *
     * @param entity the entity
     * @param update the update
     * @param session the session
     * @return true, if successful
     * @throws DatabaseException the database exception
     */
    private boolean primaryKeyExists(ConnectionFirewallDetailsEntity entity, boolean update, DatabaseSession session) 
    throws DatabaseException {

	boolean exists = false;

	return exists;
    }
}
