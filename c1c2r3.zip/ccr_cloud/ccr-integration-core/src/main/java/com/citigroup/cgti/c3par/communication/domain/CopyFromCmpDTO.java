package com.citigroup.cgti.c3par.communication.domain;

import java.io.Serializable;
import java.util.List;

import com.citigroup.cgti.c3par.businessjustification.domain.ConReqCitiContactXref;
import com.citigroup.cgti.c3par.businessjustification.domain.ConReqCitiReqConXref;

/**
 * DTO file for Copying CMP data fields to CCR
 * @author ac81662
 *
 */
public class CopyFromCmpDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    private String relationship_region;
    private String relationship_region_forDiv;
    private String relationship_sector;
    private String relationship_sector_forDiv;
    private String relationship_business;
    private String relationship_business_forDiv;
    private Long relationship_caspId;
    private Long relationship_caspId_forDiv;
    private Long relationship_caspDetailId;
    private Long relationship_caspDetailId_forDiv;
    private String relationship_relationshipType;
    private String relationship_relationshipType_forDiv;
    private String businessCase_detailedInfo;
    private String businessCase_detailedInfo_forDiv;
    private String businessCase_engCMPId;
    private String businessCase_engCMPId_forDiv;
    private String businessCase_businessJust;
    private String businessCase_businessJust_forDiv;
    private String businessCase_contratualSOW;
    private String businessCase_contratualSOW_forDiv;
    private String businessCase_dataAccessed_Citi;
    private String businessCase_dataAccessed_Citi_forDiv;
    private String businessCase_dataAccessed_Customer;
    private String businessCase_dataAccessed_Customer_forDiv;
    private String businessCase_connectivityFrequency;
    private String businessCase_connectivityFrequency_forDiv;
    private String businessCase_connectivityFor;
    private String businessCase_connectivityFor_forDiv;
    private String businessCase_businessApproverGroup;
    private String businessCase_businessApproverGroup_forDiv;
    private String businessCase_GOCcode;
    private String businessCase_GOCcode_forDiv;
    private String businessCase_directAccess;
    private String businessCase_directAccess_forDiv;
    private String businessCase_reasonsDirectCon;
    private String businessCase_reasonsDirectCon_forDiv;
    private String connectionBasicInfo_priority;
    private String connectionBasicInfo_priority_forDiv;
    private String connectionBasicInfo_affectedBusiness;
    private String connectionBasicInfo_affectedBusiness_forDiv;
    private List<ConReqCitiContactXref> conReqCitiContactXrefList;
    private List<ConReqCitiContactXref> conReqCitiContactXrefList_forDiv;
    private List<ConReqCitiReqConXref> ConReqCitiReqConXrefList;
    private List<ConReqCitiReqConXref> conReqCitiReqConXrefList_forDiv;
    
    public String getRelationship_region_forDiv() {
        return relationship_region_forDiv;
    }
    public void setRelationship_region_forDiv(String relationship_region_forDiv) {
        this.relationship_region_forDiv = relationship_region_forDiv;
    }
    public String getRelationship_sector_forDiv() {
        return relationship_sector_forDiv;
    }
    public void setRelationship_sector_forDiv(String relationship_sector_forDiv) {
        this.relationship_sector_forDiv = relationship_sector_forDiv;
    }
    public String getRelationship_business_forDiv() {
        return relationship_business_forDiv;
    }
    public void setRelationship_business_forDiv(String relationship_business_forDiv) {
        this.relationship_business_forDiv = relationship_business_forDiv;
    }
    public Long getRelationship_caspId_forDiv() {
        return relationship_caspId_forDiv;
    }
    public void setRelationship_caspId_forDiv(Long relationship_caspId_forDiv) {
        this.relationship_caspId_forDiv = relationship_caspId_forDiv;
    }
    public Long getRelationship_caspDetailId_forDiv() {
        return relationship_caspDetailId_forDiv;
    }
    public void setRelationship_caspDetailId_forDiv(Long relationship_caspDetailId_forDiv) {
        this.relationship_caspDetailId_forDiv = relationship_caspDetailId_forDiv;
    }
    public String getBusinessCase_detailedInfo_forDiv() {
        return businessCase_detailedInfo_forDiv;
    }
    public void setBusinessCase_detailedInfo_forDiv(String businessCase_detailedInfo_forDiv) {
        this.businessCase_detailedInfo_forDiv = businessCase_detailedInfo_forDiv;
    }
    public String getBusinessCase_engCMPId_forDiv() {
        return businessCase_engCMPId_forDiv;
    }
    public void setBusinessCase_engCMPId_forDiv(String businessCase_engCMPId_forDiv) {
        this.businessCase_engCMPId_forDiv = businessCase_engCMPId_forDiv;
    }
    public String getBusinessCase_businessJust_forDiv() {
        return businessCase_businessJust_forDiv;
    }
    public void setBusinessCase_businessJust_forDiv(String businessCase_businessJust_forDiv) {
        this.businessCase_businessJust_forDiv = businessCase_businessJust_forDiv;
    }
    public String getBusinessCase_contratualSOW_forDiv() {
        return businessCase_contratualSOW_forDiv;
    }
    public void setBusinessCase_contratualSOW_forDiv(String businessCase_contratualSOW_forDiv) {
        this.businessCase_contratualSOW_forDiv = businessCase_contratualSOW_forDiv;
    }
    public String getBusinessCase_dataAccessed_Citi_forDiv() {
        return businessCase_dataAccessed_Citi_forDiv;
    }
    public void setBusinessCase_dataAccessed_Citi_forDiv(String businessCase_dataAccessed_Citi_forDiv) {
        this.businessCase_dataAccessed_Citi_forDiv = businessCase_dataAccessed_Citi_forDiv;
    }
    public String getBusinessCase_dataAccessed_Customer_forDiv() {
        return businessCase_dataAccessed_Customer_forDiv;
    }
    public void setBusinessCase_dataAccessed_Customer_forDiv(String businessCase_dataAccessed_Customer_forDiv) {
        this.businessCase_dataAccessed_Customer_forDiv = businessCase_dataAccessed_Customer_forDiv;
    }
    public String getBusinessCase_connectivityFrequency_forDiv() {
        return businessCase_connectivityFrequency_forDiv;
    }
    public void setBusinessCase_connectivityFrequency_forDiv(String businessCase_connectivityFrequency_forDiv) {
        this.businessCase_connectivityFrequency_forDiv = businessCase_connectivityFrequency_forDiv;
    }
    public String getBusinessCase_connectivityFor_forDiv() {
        return businessCase_connectivityFor_forDiv;
    }
    public void setBusinessCase_connectivityFor_forDiv(String businessCase_connectivityFor_forDiv) {
        this.businessCase_connectivityFor_forDiv = businessCase_connectivityFor_forDiv;
    }
    public String getBusinessCase_businessApproverGroup_forDiv() {
        return businessCase_businessApproverGroup_forDiv;
    }
    public void setBusinessCase_businessApproverGroup_forDiv(String businessCase_businessApproverGroup_forDiv) {
        this.businessCase_businessApproverGroup_forDiv = businessCase_businessApproverGroup_forDiv;
    }
    public String getBusinessCase_GOCcode_forDiv() {
        return businessCase_GOCcode_forDiv;
    }
    public void setBusinessCase_GOCcode_forDiv(String businessCase_GOCcode_forDiv) {
        this.businessCase_GOCcode_forDiv = businessCase_GOCcode_forDiv;
    }
    public String getBusinessCase_directAccess_forDiv() {
        return businessCase_directAccess_forDiv;
    }
    public void setBusinessCase_directAccess_forDiv(String businessCase_directAccess_forDiv) {
        this.businessCase_directAccess_forDiv = businessCase_directAccess_forDiv;
    }
    public String getBusinessCase_reasonsDirectCon_forDiv() {
        return businessCase_reasonsDirectCon_forDiv;
    }
    public void setBusinessCase_reasonsDirectCon_forDiv(String businessCase_reasonsDirectCon_forDiv) {
        this.businessCase_reasonsDirectCon_forDiv = businessCase_reasonsDirectCon_forDiv;
    }
    public String getConnectionBasicInfo_priority_forDiv() {
        return connectionBasicInfo_priority_forDiv;
    }
    public void setConnectionBasicInfo_priority_forDiv(String connectionBasicInfo_priority_forDiv) {
        this.connectionBasicInfo_priority_forDiv = connectionBasicInfo_priority_forDiv;
    }
    public String getConnectionBasicInfo_affectedBusiness_forDiv() {
        return connectionBasicInfo_affectedBusiness_forDiv;
    }
    public void setConnectionBasicInfo_affectedBusiness_forDiv(String connectionBasicInfo_affectedBusiness_forDiv) {
        this.connectionBasicInfo_affectedBusiness_forDiv = connectionBasicInfo_affectedBusiness_forDiv;
    }
    public List<ConReqCitiContactXref> getConReqCitiContactXrefList_forDiv() {
        return conReqCitiContactXrefList_forDiv;
    }
    public void setConReqCitiContactXrefList_forDiv(List<ConReqCitiContactXref> conReqCitiContactXrefList_forDiv) {
        this.conReqCitiContactXrefList_forDiv = conReqCitiContactXrefList_forDiv;
    }
    public String getBusinessCase_detailedInfo() {
        return businessCase_detailedInfo;
    }
    public void setBusinessCase_detailedInfo(String businessCase_detailedInfo) {
        this.businessCase_detailedInfo = businessCase_detailedInfo;
    }
    public String getBusinessCase_engCMPId() {
        return businessCase_engCMPId;
    }
    public void setBusinessCase_engCMPId(String businessCase_engCMPId) {
        this.businessCase_engCMPId = businessCase_engCMPId;
    }
    public String getBusinessCase_businessJust() {
        return businessCase_businessJust;
    }
    public void setBusinessCase_businessJust(String businessCase_businessJust) {
        this.businessCase_businessJust = businessCase_businessJust;
    }
    public String getBusinessCase_contratualSOW() {
        return businessCase_contratualSOW;
    }
    public void setBusinessCase_contratualSOW(String businessCase_contratualSOW) {
        this.businessCase_contratualSOW = businessCase_contratualSOW;
    }
    public String getBusinessCase_dataAccessed_Citi() {
        return businessCase_dataAccessed_Citi;
    }
    public void setBusinessCase_dataAccessed_Citi(String businessCase_dataAccessed_Citi) {
        this.businessCase_dataAccessed_Citi = businessCase_dataAccessed_Citi;
    }
    public String getBusinessCase_dataAccessed_Customer() {
        return businessCase_dataAccessed_Customer;
    }
    public void setBusinessCase_dataAccessed_Customer(String businessCase_dataAccessed_Customer) {
        this.businessCase_dataAccessed_Customer = businessCase_dataAccessed_Customer;
    }
    public String getBusinessCase_connectivityFrequency() {
        return businessCase_connectivityFrequency;
    }
    public void setBusinessCase_connectivityFrequency(String businessCase_connectivityFrequency) {
        this.businessCase_connectivityFrequency = businessCase_connectivityFrequency;
    }
    public String getBusinessCase_connectivityFor() {
        return businessCase_connectivityFor;
    }
    public void setBusinessCase_connectivityFor(String businessCase_connectivityFor) {
        this.businessCase_connectivityFor = businessCase_connectivityFor;
    }
    public String getBusinessCase_businessApproverGroup() {
        return businessCase_businessApproverGroup;
    }
    public void setBusinessCase_businessApproverGroup(String businessCase_businessApproverGroup) {
        this.businessCase_businessApproverGroup = businessCase_businessApproverGroup;
    }
    public String getBusinessCase_GOCcode() {
        return businessCase_GOCcode;
    }
    public void setBusinessCase_GOCcode(String businessCase_GOCcode) {
        this.businessCase_GOCcode = businessCase_GOCcode;
    }
    public String getBusinessCase_directAccess() {
        return businessCase_directAccess;
    }
    public void setBusinessCase_directAccess(String businessCase_directAccess) {
        this.businessCase_directAccess = businessCase_directAccess;
    }
    public String getRelationship_region() {
        return relationship_region;
    }
    public void setRelationship_region(String relationship_region) {
        this.relationship_region = relationship_region;
    }
    public String getRelationship_sector() {
        return relationship_sector;
    }
    public void setRelationship_sector(String relationship_sector) {
        this.relationship_sector = relationship_sector;
    }
    public String getRelationship_business() {
        return relationship_business;
    }
    public void setRelationship_business(String relationship_business) {
        this.relationship_business = relationship_business;
    }
    public Long getRelationship_caspId() {
        return relationship_caspId;
    }
    public void setRelationship_caspId(Long relationship_caspId) {
        this.relationship_caspId = relationship_caspId;
    }
    public Long getRelationship_caspDetailId() {
        return relationship_caspDetailId;
    }
    public void setRelationship_caspDetailId(Long relationship_caspDetailId) {
        this.relationship_caspDetailId = relationship_caspDetailId;
    }
    public String getConnectionBasicInfo_priority() {
        return connectionBasicInfo_priority;
    }
    public void setConnectionBasicInfo_priority(String connectionBasicInfo_priority) {
        this.connectionBasicInfo_priority = connectionBasicInfo_priority;
    }
    public String getConnectionBasicInfo_affectedBusiness() {
        return connectionBasicInfo_affectedBusiness;
    }
    public void setConnectionBasicInfo_affectedBusiness(String connectionBasicInfo_affectedBusiness) {
        this.connectionBasicInfo_affectedBusiness = connectionBasicInfo_affectedBusiness;
    }
    public List<ConReqCitiContactXref> getConReqCitiContactXrefList() {
        return conReqCitiContactXrefList;
    }
    public void setConReqCitiContactXrefList(List<ConReqCitiContactXref> conReqCitiContactXrefList) {
        this.conReqCitiContactXrefList = conReqCitiContactXrefList;
    }
    public List<ConReqCitiReqConXref> getConReqCitiReqConXrefList() {
        return ConReqCitiReqConXrefList;
    }
    public void setConReqCitiReqConXrefList(List<ConReqCitiReqConXref> conReqCitiReqConXrefList) {
        ConReqCitiReqConXrefList = conReqCitiReqConXrefList;
    }
    public String getBusinessCase_reasonsDirectCon() {
        return businessCase_reasonsDirectCon;
    }
    public void setBusinessCase_reasonsDirectCon(String businessCase_reasonsDirectCon) {
        this.businessCase_reasonsDirectCon = businessCase_reasonsDirectCon;
    }
    public List<ConReqCitiReqConXref> getConReqCitiReqConXrefList_forDiv() {
        return conReqCitiReqConXrefList_forDiv;
    }
    public void setConReqCitiReqConXrefList_forDiv(List<ConReqCitiReqConXref> conReqCitiReqConXrefList_forDiv) {
        this.conReqCitiReqConXrefList_forDiv = conReqCitiReqConXrefList_forDiv;
    }
	public String getRelationship_relationshipType() {
		return relationship_relationshipType;
	}
	public void setRelationship_relationshipType(String relationship_relationshipType) {
		this.relationship_relationshipType = relationship_relationshipType;
	}
	public String getRelationship_relationshipType_forDiv() {
		return relationship_relationshipType_forDiv;
	}
	public void setRelationship_relationshipType_forDiv(String relationship_relationshipType_forDiv) {
		this.relationship_relationshipType_forDiv = relationship_relationshipType_forDiv;
	}
}
