package com.citigroup.cgti.c3par.communication.domain.soc.persist;

import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.ccrcmpmapping.service.CCRCMPMappingService;
import com.citigroup.cgti.c3par.common.domain.TIMailAudit;
import com.citigroup.cgti.c3par.communication.domain.CMPComments;
import com.citigroup.cgti.c3par.communication.domain.CMPReleasedMailGenerationProcess;
import com.citigroup.cgti.c3par.communication.domain.CMPRequest;
import com.citigroup.cgti.c3par.communication.domain.CMPRequestNotes;
import com.citigroup.cgti.c3par.communication.domain.CmpAttachmentsDTO;
import com.citigroup.cgti.c3par.communication.domain.CmpRequestDTO;
import com.citigroup.cgti.c3par.communication.domain.EmerBuscritQuestionaries;
import com.citigroup.cgti.c3par.domain.CMPRole;
import com.citigroup.cgti.c3par.relationship.domain.BusinessUnit;
import com.citigroup.cgti.c3par.relationship.domain.Sector;
import com.citigroup.cgti.c3par.relationship.domain.ThirdPartyContact;
import com.citigroup.cgti.c3par.user.domain.C3parUser;

 

public interface EmailGenerationViewServicePersistable {

	public List<Sector> loadSectorListByName(String regionName);
	public List<BusinessUnit> loadBusinessUnitListByName(String regionName, String sectorName);
	public List<CMPRole> loadCMPRoles();
	
	public CMPRequest getCMPRequestDetails(String cmpReqId);
	public CitiContact getAgentDetails(String ssoId);
	public List<CMPRequest> getCmpReqIdsList(String assignedUser, String cmpReqId);
	public List<CMPRequest> getCmpReqIdSearchList(String cmpReqId);
	public List<CMPRequest> getCMPRequestList(String[] cmpOrderIds);
	public C3parUser getLoginAssignedUser(String ssoId);		
	public void updateCMPRequestDetails(CMPRequest cmpRequest);	
	public void updateAddNoteDetails(CMPRequestNotes cmpRequestNotes);	
	public int transferEcmAgent(String reassignedUser,String cmpId , String userId);
	
	public void updateCmpRequestContactForTransfer(CitiContact citiContact, Long cmpContactId);
	
	public boolean isWaitingforBusinessReply(Long cmpId,String activityCode, Long tiRequestId);
	
	public void isWaitingforECMUserReply(CMPRequest cmpRequest);
	
	public boolean isAccessForm(Long tiRequestId,String ruleType);
	public boolean isSloNotification(Long tiRequestId,Long cmpId);
	public CitiContact getAgentDetailsByUserId(Long agentUserId);
	public CMPRequest getCMPRequestDetailsByOrderId(String cmpReqId);
	public int updateCMPRequestStatus(Long cmpId,String status);
	
	public List<Map<String, String>> getChangeRequestDetails(Long conReqId, String cmpId);
	
	public List<TIMailAudit> getAuditTrialDetail(Long cmpId);
	
	public void checkColourstatus(CMPRequest cmprequest,String tiRequestId);
	public boolean checkCmpAssitanceReqFlag(Long cmpId);
	
	public CmpAttachmentsDTO getDocumentForDownload(String cmpDocumentContentId);
	public void saveCmpAttachment(CmpAttachmentsDTO cmpAttachment, boolean fromCMPFeed);
	public void deleteCmpAttachment(String contentId, String userId,  Long cmpId);
	
	
	public Hashtable<String, String> getDocumentDropdownList();
	/**
	 * Method to get CMP History which includes list of cmpNotes, activityTrial, mailAudit objects
	 * @param cmpOrderItemId
	 * @param tiRequestId
	 * @return Map containing list of cmpNotes, activityTrial, mailAudit objects
	 */
	Map<String, Object> getCMPHistory(String cmpOrderItemId, Long tiRequestId);
	 public List<Map<String, String>> getChangeRequestDetails(Long requestId);
	 public void getTiActivityTrial(CMPRequest cmpRequest, Long tiRequestId) ;
	 public void saveEmerQuestionaries(List<EmerBuscritQuestionaries> emerBuscritQuestionariesList) ;
	 String getcmpRoleNameById(Long roleId);
	 ThirdPartyContact getThirdPartyContactByDetailId(Long detailId);
	 public Long getcmpRoleIdByName(String roleName);
	public String getProjectSectorName(String secId);
	public void sendCMPHoldReleasedEmail(CMPReleasedMailGenerationProcess cmpReleasedMailGenerationProcess, CCRCMPMappingService ccrCMPMappingService,
			String agentSsoId);

    public CMPComments getcmpAddInfoRequested(Long cmpAddInfoRequestedId);
    
    public List<String> getEcmManagers();

    public void unAssignUserFromCmp(Long cmpId);
    
    public void deLinkCCRs(String cmpOrderItemId) throws Exception;
    
    public void updateCMPAttachments(CmpAttachmentsDTO cmpAttachmentsDto);
    
    public boolean updateDirectorApproval(String cmpOrderItemId, String ssoId, boolean isApproved, String approvalSystem);

    public void saveDirApprovalCMPAttachment(CmpRequestDTO cmpRequestDTO);
}
