/**
 * 
 */
package com.citigroup.cgti.c3par.admin.dao.service;

import java.util.List;
import java.util.Map;

import com.citigroup.cgti.c3par.admin.domain.BulkContactUpdateDTO;
import com.citigroup.cgti.c3par.admin.domain.SearchResultDTO;
import com.citigroup.cgti.c3par.businessjustification.domain.ConReqCitiContactXref;
import com.citigroup.cgti.c3par.businessjustification.domain.ConReqCitiReqConXref;
import com.citigroup.cgti.c3par.domain.Role;
import com.citigroup.cgti.c3par.domain.TIRequest;

/**
 * @author ka58098
 * 
 */
public interface BulkContactUpdateDaoService {

   //  public List<BulkContactUpdateDTO> getSearchDetails(String ssoId, Long roleId);

    public List<ConReqCitiContactXref> getConReqCitiContact(String ssoId, Long roleId);
    public List<ConReqCitiReqConXref> getConReqCitiReqConXref(String ssoId, Long roleId);

    public TIRequest getTiRequest(Long requestId);

    public boolean updateContactDetails(List<BulkContactUpdateDTO> bulkContactUpdateDTOList);

    // public List<Role> getRoleList(String[] params);

    public Long getTiRequestId(Long processId);

    public String getContactNameForSsoId(String ssoId);

    public void updateContact(BulkContactUpdateDTO bulkContactUpdateDTO, List<Long> ccrIdList,List<String> contactTypeList, List<Long> citiContactIdList, Long citiContactId,
            String roleName, String newRoleName, Long replaceCitiContactId);

    public List<Role> getRoleList();

   // List<SearchResultDTO> getSearchDetails(Long contactId, String roleName);


    public void updatePrimaryOrNotifyContact(Map<Long, String> planningIdList, BulkContactUpdateDTO bulkContactUpdateDTO);
    
    void removeContacts(List<Long> targetIds, List<Long> requestorIds,String loginSoeId);

}
