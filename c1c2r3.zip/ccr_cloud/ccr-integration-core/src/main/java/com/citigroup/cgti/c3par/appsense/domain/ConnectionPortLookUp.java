package com.citigroup.cgti.c3par.appsense.domain;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.citigroup.cgti.c3par.domain.Base;


/**
 * The Class ConnectionPortLookUp.
 */
@XmlRootElement
public class ConnectionPortLookUp extends Base implements Serializable{

    /** The port number. */
    private String portNumber;

    /** The flow of data. */
    private String flowOfData;

    /** The protocol. */
    private String protocol;

    /** The control msg id. */
    private Long controlMsgId;

    /** The is riskport. */
    private String isRiskport;

    /** The bi directional. */
    private String biDirectional;
    //	private List connectionPortMasterList = new ArrayList();




/*
    *//**
     * Instantiates a new connection port look up.
     *//*
    public ConnectionPortLookUp() {
	setTableName("con_port_lookup");
	setSequenceName("seq_con_port_lookup");
	addToDBMapping("portNumber","port_number",1);
	addToDBMapping("flowOfData","flow_of_data",2);
	addToDBMapping("protocol","protocol",3);
	addToDBMapping("controlMsgId","control_message_id",4);
	addToDBMapping("created_date","created_date",5);
	addToDBMapping("updated_date","updated_date",6);
	addToDBMapping("isRiskport","IS_RISKPORT",7);
	addToDBMapping("biDirectional","BIDIRECTIONAL",8);

	//		addToChildList("connectionPortMasterList",new ConnectionPortMaster());

    }*/




    //	public List getConnectionPortMasterList() {
    //		return connectionPortMasterList;
    //	}
    //	public void setConnectionPortMasterList(List connectionPortMasterList) {
    //		this.connectionPortMasterList = connectionPortMasterList;
    //	}
    /**
     * Gets the control msg id.
     *
     * @return the control msg id
     */
    public Long getControlMsgId() {
	return controlMsgId;
    }

    /**
     * Sets the control msg id.
     *
     * @param controlMsgId the new control msg id
     */
    public void setControlMsgId(Long controlMsgId) {
	this.controlMsgId = controlMsgId;
    }

    /**
     * Gets the flow of data.
     *
     * @return the flow of data
     */
    public String getFlowOfData() {
	return flowOfData;
    }

    /**
     * Sets the flow of data.
     *
     * @param flowOfData the new flow of data
     */
    public void setFlowOfData(String flowOfData) {
	this.flowOfData = flowOfData;
    }

    /**
     * Gets the port number.
     *
     * @return the port number
     */
    @XmlElement
    public String getPortNumber() {
	return portNumber;
    }

    /**
     * Sets the port number.
     *
     * @param portNumber the new port number
     */
    public void setPortNumber(String portNumber) {
	this.portNumber = portNumber;
    }

    /**
     * Gets the protocol.
     *
     * @return the protocol
     */
    @XmlElement
    public String getProtocol() {
	return protocol;
    }

    /**
     * Sets the protocol.
     *
     * @param protocol the new protocol
     */
    public void setProtocol(String protocol) {
	this.protocol = protocol;
    }


    /**
     * Gets the checks if is riskport.
     *
     * @return the checks if is riskport
     */
    public String getIsRiskport() {
	return isRiskport;
    }




    /**
     * Sets the checks if is riskport.
     *
     * @param isRiskport the new checks if is riskport
     */
    public void setIsRiskport(String isRiskport) {
	this.isRiskport = isRiskport;
    }




    /**
     * Gets the bi directional.
     *
     * @return the bi directional
     */
    public String getBiDirectional() {
	return biDirectional;
    }




    /**
     * Sets the bi directional.
     *
     * @param biDirectional the new bi directional
     */
    public void setBiDirectional(String biDirectional) {
	this.biDirectional = biDirectional;
    }




}
