package com.citigroup.cgti.c3par.communication.domain;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.context.ApplicationContext;

import com.citigroup.cgti.c3par.user.domain.C3parUser;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

/**
 * @author sd96969
 * 
 */
public class CmpReqIdSearchProcess {

    private String cmpreqID;
    private String ccrID;
    private String orderByUser;
    private String currentStatus;
    private String ecmAgent;
    private String cmpStatus;
    private String changeId;
    private int recordStartCount;
    private int recordEndCount;
    private int totalRecords;
    private int totalCurrentPageRecords;
    private Long columnIndex;
    private String sortBy;
    private Long resultPerPage;
    private String orderBy;
    private String orderId;
    private String businessOwner;
    private String sortingColumnName;
    private List<String> viewColumnNamesList;
    private List<CmpSearchView> cmpSearchViewDetailsList;
    private Map<Long, String> map = new TreeMap<Long, String>();
    private String view;
    private List<String> cmpSearchResultsColumnList;
    private String ssoId;
    private String goc;
    private String ecomType;

    /* ****************** Getters and Setters ****************** */
    public String getCmpStatus() {
        return cmpStatus;
    }

    public void setCmpStatus(String cmpStatus) {
        this.cmpStatus = cmpStatus;
    }

    /**
     * @return the orderBy
     */
    public String getOrderBy() {
        return orderBy;
    }

    /**
     * @param orderBy
     *            the orderBy to set
     */
    public void setOrderBy(String orderBy) {
        this.orderBy = orderBy;
    }

    public String getChangeId() {
        return changeId;
    }

    public void setChangeId(String changeId) {
        this.changeId = changeId;
    }

    private Date fromDate;
    private Date toDate;

    public String getCurrentStatus() {
        return currentStatus;
    }

    public void setCurrentStatus(String currentStatus) {
        this.currentStatus = currentStatus;
    }

    public String getEcmAgent() {
        return ecmAgent;
    }

    public void setEcmAgent(String ecmAgent) {
        this.ecmAgent = ecmAgent;
    }

    public String getOrderByUser() {
        return orderByUser;
    }

    public void setOrderByUser(String orderByUser) {
        this.orderByUser = orderByUser;
    }

    public String getCcrID() {
        return ccrID;
    }

    public void setCcrID(String ccrID) {
        this.ccrID = ccrID;
    }

    public Date getFromDate() {
        return fromDate;
    }

    public void setFromDate(Date fromDate) {
        this.fromDate = fromDate;
    }

    public Date getToDate() {
        return toDate;
    }

    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }

    List<CMPRequest> cmpReqList;

    CCRBeanFactory ccrBeanFactory;

    {
        ApplicationContext appContext = CCRApplicationContextUtils.getApplicationContext();
        ccrBeanFactory = (CCRBeanFactory) appContext.getBean("cCRBeanFactory");
    }

    public String getCmpreqID() {
        return cmpreqID;
    }

    public void setCmpreqID(String cmpreqID) {
        this.cmpreqID = cmpreqID;
    }

    public List<CMPRequest> getCmpReqList() {
        return cmpReqList;
    }

    public void setCmpReqList(List<CMPRequest> cmpReqList) {
        this.cmpReqList = cmpReqList;
    }

    public List<CMPRequest> getCmpReqIdsList(String assignedUser, String cmpReqId) {
        return ccrBeanFactory.getEmailGenViewServicePersistable().getCmpReqIdsList(assignedUser, cmpReqId);
    }

    public List<CMPRequest> getCmpReqIdSearchList(String cmpReqId) {
        return ccrBeanFactory.getEmailGenViewServicePersistable().getCmpReqIdSearchList(cmpReqId);
    }

    public C3parUser getLoginAssignedUser(String ssoId) {
        return ccrBeanFactory.getEmailGenViewServicePersistable().getLoginAssignedUser(ssoId);
    }

    /**
     * @return the recordStartCount
     */
    public int getRecordStartCount() {
        return recordStartCount;
    }

    /**
     * @param recordStartCount
     *            the recordStartCount to set
     */
    public void setRecordStartCount(int recordStartCount) {
        this.recordStartCount = recordStartCount;
    }

    /**
     * @return the recordEndCount
     */
    public int getRecordEndCount() {
        return recordEndCount;
    }

    /**
     * @param recordEndCount
     *            the recordEndCount to set
     */
    public void setRecordEndCount(int recordEndCount) {
        this.recordEndCount = recordEndCount;
    }

    /**
     * @return the totalRecords
     */
    public int getTotalRecords() {
        return totalRecords;
    }

    /**
     * @param totalRecords
     *            the totalRecords to set
     */
    public void setTotalRecords(int totalRecords) {
        this.totalRecords = totalRecords;
    }

    /**
     * @return the totalCurrentPageRecords
     */
    public int getTotalCurrentPageRecords() {
        return totalCurrentPageRecords;
    }

    /**
     * @param totalCurrentPageRecords
     *            the totalCurrentPageRecords to set
     */
    public void setTotalCurrentPageRecords(int totalCurrentPageRecords) {
        this.totalCurrentPageRecords = totalCurrentPageRecords;
    }

    public Long getColumnIndex() {
        return columnIndex;
    }

    public void setColumnIndex(Long columnIndex) {
        this.columnIndex = columnIndex;
    }

    public String getSortBy() {
        return sortBy;
    }

    public void setSortBy(String sortBy) {
        this.sortBy = sortBy;
    }

    public Long getResultPerPage() {
        return resultPerPage;
    }

    public void setResultPerPage(Long resultPerPage) {
        this.resultPerPage = resultPerPage;
    }

    /**
     * @return the orderId
     */
    public String getOrderId() {
        return orderId;
    }

    /**
     * @param orderId
     *            the orderId to set
     */
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    /**
     * @return
     */
    public String getBusinessOwner() {
        return businessOwner;
    }

    /**
     * @param businessOwner
     */
    public void setBusinessOwner(String businessOwner) {
        this.businessOwner = businessOwner;
    }

    /**
     * @return the sortingColumnName
     */
    public String getSortingColumnName() {
        return sortingColumnName;
    }

    /**
     * @param sortingColumnName
     *            the sortingColumnName to set
     */
    public void setSortingColumnName(String sortingColumnName) {
        this.sortingColumnName = sortingColumnName;
    }

    /**
     * @return the viewColumnNamesList
     */
    public List<String> getViewColumnNamesList() {
        return viewColumnNamesList;
    }

    /**
     * @param viewColumnNamesList
     *            the viewColumnNamesList to set
     */
    public void setViewColumnNamesList(List<String> viewColumnNamesList) {
        this.viewColumnNamesList = viewColumnNamesList;
    }

    /**
     * @return the cmpSearchViewDetailsList
     */
    public List<CmpSearchView> getCmpSearchViewDetailsList() {
        return cmpSearchViewDetailsList;
    }

    /**
     * @param cmpSearchViewDetailsList
     *            the cmpSearchViewDetailsList to set
     */
    public void setCmpSearchViewDetailsList(List<CmpSearchView> cmpSearchViewDetailsList) {
        this.cmpSearchViewDetailsList = cmpSearchViewDetailsList;
    }

    /**
     * @return the map
     */
    public Map<Long, String> getMap() {
        return map;
    }

    /**
     * @param map
     *            the map to set
     */
    public void setMap(Map<Long, String> map) {
        this.map = map;
    }

    /**
     * @return the view
     */
    public String getView() {
        return view;
    }

    /**
     * @param view
     *            the view to set
     */
    public void setView(String view) {
        this.view = view;
    }

    /**
     * @return the cmpSearchResultsColumnList
     */
    public List<String> getCmpSearchResultsColumnList() {
        return cmpSearchResultsColumnList;
    }

    /**
     * @param cmpSearchResultsColumnList
     *            the cmpSearchResultsColumnList to set
     */
    public void setCmpSearchResultsColumnList(List<String> cmpSearchResultsColumnList) {
        this.cmpSearchResultsColumnList = cmpSearchResultsColumnList;
    }

    /**
     * @return the ssoId
     */
    public String getSsoId() {
        return ssoId;
    }

    /**
     * @param ssoId
     *            the ssoId to set
     */
    public void setSsoId(String ssoId) {
        this.ssoId = ssoId;
    }

	public String getGoc() {
		return goc;
	}

	public void setGoc(String goc) {
		this.goc = goc;
	}

    public String getEcomType() {
        return ecomType;
    }

    public void setEcomType(String ecomType) {
        this.ecomType = ecomType;
    }

	
    

}
