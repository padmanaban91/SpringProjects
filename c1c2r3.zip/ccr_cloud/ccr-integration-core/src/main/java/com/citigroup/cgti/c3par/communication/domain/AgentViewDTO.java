/**
 * 
 */
package com.citigroup.cgti.c3par.communication.domain;

import java.io.Serializable;
import java.util.Date;

/**
 * @author ka58098
 * 
 */
public class AgentViewDTO implements Serializable {

    private static final long serialVersionUID = 16456545L;

    private String ccrId;
    private String ccrIdValues;
    private String ccrIdWithVerNo;
    private Date updateAssignedUserDate;
    private String ecmSector;
    private String checkTiId;
    private String taskCodeColor;
    private String taskName;
    private String sloStatus;
    private String slo;
    private String requestTypeVal;
    private String chgId;
    private String chgDate;
    private String requestorName;
    private String dateAssigned;
    private String currentStatus;
    private String orderByUser;
    private String orderForUser;
    private String orderId;
    private String orderItemId;
    private String requestUrgency;
    // For Team View
    private String agentName;

    public String getCcrId() {
        return ccrId;
    }

    public void setCcrId(String ccrId) {
        this.ccrId = ccrId;
    }

    public String getCcrIdValues() {
        return ccrIdValues;
    }

    public String getCcrIdWithVerNo() {
        return ccrIdWithVerNo;
    }

    public void setCcrIdWithVerNo(String ccrIdWithVerNo) {
        this.ccrIdWithVerNo = ccrIdWithVerNo;
    }

    public void setCcrIdValues(String ccrIdValues) {
        this.ccrIdValues = ccrIdValues;
    }

    public Date getUpdateAssignedUserDate() {
        return updateAssignedUserDate;
    }

    public void setUpdateAssignedUserDate(Date updateAssignedUserDate) {
        this.updateAssignedUserDate = updateAssignedUserDate;
    }

    public String getEcmSector() {
        return ecmSector;
    }

    public void setEcmSector(String ecmSector) {
        this.ecmSector = ecmSector;
    }

    public String getCheckTiId() {
        return checkTiId;
    }

    public void setCheckTiId(String checkTiId) {
        this.checkTiId = checkTiId;
    }

    public String getTaskCodeColor() {
        return taskCodeColor;
    }

    public void setTaskCodeColor(String taskCodeColor) {
        this.taskCodeColor = taskCodeColor;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getSloStatus() {
        return sloStatus;
    }

    public void setSloStatus(String sloStatus) {
        this.sloStatus = sloStatus;
    }

    public String getSlo() {
        return slo;
    }

    public void setSlo(String slo) {
        this.slo = slo;
    }

    public String getRequestTypeVal() {
        return requestTypeVal;
    }

    public void setRequestTypeVal(String requestTypeVal) {
        this.requestTypeVal = requestTypeVal;
    }

    public String getChgId() {
        return chgId;
    }

    public void setChgId(String chgId) {
        this.chgId = chgId;
    }

    public String getChgDate() {
        return chgDate;
    }

    public void setChgDate(String chgDate) {
        this.chgDate = chgDate;
    }

    public String getRequestorName() {
        return requestorName;
    }

    public void setRequestorName(String requestorName) {
        this.requestorName = requestorName;
    }

    public String getDateAssigned() {
        return dateAssigned;
    }

    public void setDateAssigned(String dateAssigned) {
        this.dateAssigned = dateAssigned;
    }

    public String getCurrentStatus() {
        return currentStatus;
    }

    public void setCurrentStatus(String currentStatus) {
        this.currentStatus = currentStatus;
    }

    public String getOrderByUser() {
        return orderByUser;
    }

    public void setOrderByUser(String orderByUser) {
        this.orderByUser = orderByUser;
    }

    public String getOrderForUser() {
        return orderForUser;
    }

    public void setOrderForUser(String orderForUser) {
        this.orderForUser = orderForUser;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getOrderItemId() {
        return orderItemId;
    }

    public void setOrderItemId(String orderItemId) {
        this.orderItemId = orderItemId;
    }

    public String getRequestUrgency() {
        return requestUrgency;
    }

    public void setRequestUrgency(String requestUrgency) {
        this.requestUrgency = requestUrgency;
    }

    public String getAgentName() {
        return agentName;
    }

    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }

}
