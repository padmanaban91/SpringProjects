package com.citigroup.cgti.c3par.communication.domain;

import org.apache.commons.lang.builder.ToStringBuilder;

public class EcmViewColumn extends EcmBaseEntity{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1545785155L;
	private Long id;
    private EcmView ecmView;
    private EcmColumn ecmColumn;
    private Long viewId;
    private Long columnId;
    private String isSortable;
    private Long columnOrder;
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public EcmView getEcmView() {
        return ecmView;
    }

    public void setEcmView(EcmView ecmView) {
        this.ecmView = ecmView;
    }

    public EcmColumn getEcmColumn() {
        return ecmColumn;
    }

    public void setEcmColumn(EcmColumn ecmColumn) {
        this.ecmColumn = ecmColumn;
    }
    public Long getViewId() {
        return viewId;
    }

    public void setViewId(Long viewId) {
        this.viewId = viewId;
    }

    public Long getColumnId() {
        return columnId;
    }

    public void setColumnId(Long columnId) {
        this.columnId = columnId;
    }
    public String getIsSortable() {
		return isSortable;
	}

	public void setIsSortable(String isSortable) {
		this.isSortable = isSortable;
	}

	public Long getColumnOrder() {
		return columnOrder;
	}

	public void setColumnOrder(Long columnOrder) {
		this.columnOrder = columnOrder;
	}

	@Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

}
