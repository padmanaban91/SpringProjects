package com.citigroup.cgti.c3par.ccrcmpmapping.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citigroup.cgti.c3par.ccrcmpmapping.dao.service.CCRCMPMappingDAOService;
import com.citigroup.cgti.c3par.ccrcmpmapping.service.CCRCMPMappingService;
import com.citigroup.cgti.c3par.common.domain.TIMailAudit;
import com.citigroup.cgti.c3par.common.domain.TIMailAuditAttachments;
import com.citigroup.cgti.c3par.communication.domain.BusinessUserProcess;
import com.citigroup.cgti.c3par.communication.domain.CCRCMPMappingDTO;
import com.citigroup.cgti.c3par.communication.domain.CMPRequest;
import com.citigroup.cgti.c3par.communication.domain.CcrCmpXrefDto;
import com.citigroup.cgti.c3par.communication.domain.CmpRequestDTO;
import com.citigroup.cgti.c3par.communication.domain.EmailGenerationViewProcess;
import com.citigroup.cgti.c3par.communication.domain.QuickSearchProcess;
import com.citigroup.cgti.c3par.communication.domain.CMPComments;

/**
 * @author ky38518
 * 
 */
@Service
public class CCRCMPMappingServiceImpl implements CCRCMPMappingService {

    @Autowired
    private CCRCMPMappingDAOService CCRCMPMappingDAOService;

    /*
     * To save the CCR CMP Mapping Details into Data base
     */
    @Override
    public void saveCCRCMPXref(String cmpOrderItemId, long tiRequestId) {
        CCRCMPMappingDAOService.saveCCRCMPXref(cmpOrderItemId, tiRequestId);
    }

    /*
     * To get the cmp orderitem details based on searchString
     */
    @Override
    public List<CCRCMPMappingDTO> getCMPOrderItemList(String searchString) {
        return CCRCMPMappingDAOService.getCMPOrderItemList(searchString);
    }

    /*
     * To verify whether ccr cmp Mapping already exists in data base
     */

    @Override
    public boolean isCMPCCRMappingExists(String cmpOrderItem, long tiRequestId) {
        return CCRCMPMappingDAOService.isCMPCCRMappingExists(cmpOrderItem, tiRequestId);
    }

    /*
     * To delete ccr cmp mapping details from db based on id
     */

    @Override
    public boolean deleteCmpFromCCR(long cmpCcrMappingId) {
        return CCRCMPMappingDAOService.deleteCmpFromCCR(cmpCcrMappingId);
    }

    /*
     * To get ccr id details linked to cmpReqId
     */
    @Override
    public List<CcrCmpXrefDto> getCcrCmpXrefByOrderItemId(String cmpReqId) {

        return CCRCMPMappingDAOService.getCcrCmpXrefByOrderItemId(cmpReqId);
    }

    /*
     * To validate whether ccr is in active or ACV Status
     */
    @Override
    public List<String> validateLinkedCCR(String processId) {
        return CCRCMPMappingDAOService.validateLinkedCCR(processId);
    }

    /*
     * To get OrderItems for a given tiRequestId
     */
    @Override
    public String getOrderItemIdforTIRequest(long tiRequestId) {
        return CCRCMPMappingDAOService.getOrderItemIdforTIRequest(tiRequestId);
    }

    @Override
    public Long getTIRequestID(String ccrID) {

        return CCRCMPMappingDAOService.getTIRequestID(ccrID);
    }

    public CcrCmpXrefDto getCcrCmpXrefByOrderItemId(String cmpReqId, Long tiRequestId) {
        return CCRCMPMappingDAOService.getCcrCmpXrefByOrderItemId(cmpReqId, tiRequestId);
    }

    /*
     * To return a integer which represents the CMP status
     */
    @Override
    public int checkCMPStatus(long tiRequestId) {
        return CCRCMPMappingDAOService.checkCMPStatus(tiRequestId);
    }

    /*
     * To return a integer which represents the CMP status
     */
    @Override
    public Map<String, String> getCompletedUserDetails(long tiRequestId) {
        return CCRCMPMappingDAOService.getCompletedUserDetails(tiRequestId);
    }

    /*
     * To get the cmp item list for a given tiRequestId
     */
    @Override
    public Map<String, List<String>> getCMPCCRDetails(long tiRequestId) {
        return CCRCMPMappingDAOService.getCMPCCRDetails(tiRequestId);
    }

    /*
     * To get the cmp XML Content in string format
     */
    @Override
    public String getCMPXMLContent(String cmpId) {
        return CCRCMPMappingDAOService.getCMPXMLContent(cmpId);
    }

    /*
     * To update completed status for a CMP
     */
    public int updateCMPStatus(String status, String cmpId) {
        return CCRCMPMappingDAOService.updateCMPStatus(status, cmpId);
    }

    /*
     * To get the mapped CMP Ids for a tiRequestId
     */
    public Map<String, List<String>> getMappedCMPIdForCCRId(long activityTrailId) {
        return CCRCMPMappingDAOService.getMappedCMPIdForCCRId(activityTrailId);
    }

    /*
     * To get the GE Id for the given user Id
     */
    public String getGEIdforUser(String ssoId) {
        return CCRCMPMappingDAOService.getGEIdforUser(ssoId);
    }

    /*
     * To get the description for the current activity
     */
    public String getTaskDescriptionForActivity(long activityTrailId) {
        return CCRCMPMappingDAOService.getTaskDescriptionForActivity(activityTrailId);
    }

    /*
     * To get the CMP Request details for a given orderitemId
     */
    public CMPRequest getCMPRequestDetailsByOrderItemId(String cmpOrderItemId) {
        return CCRCMPMappingDAOService.getCMPRequestDetailsByOrderItemId(cmpOrderItemId);
    }

    @Override
    public Long getCmpSloHrs(long cmpId, String ccrId) {
        try {
            Long tiRequestId = CCRCMPMappingDAOService.getTIRequestID(ccrId);
            return CCRCMPMappingDAOService.getCmpSloHrs(cmpId, tiRequestId);
        } catch (Exception exp) {
            return null;
        }
    }

    /*
     * To delete the existing mapping between CCR and CMP
     */
    @Override
    public void clearMappedCMPIds(long tiRequestId) {
        CCRCMPMappingDAOService.clearMappedCMPIds(tiRequestId);
    }

    /*
     * To log ECM Activity
     */
    @Override
    public void logECMActivityTrail(long tiRequestId) {
        CCRCMPMappingDAOService.logECMActivityTrail(tiRequestId);
    }

    /*
     * To delete the existing mapping between CCR and CMP
     */
    @Override
    public void completeECMActivityTrail(long tiRequestId) {
        CCRCMPMappingDAOService.completeECMActivityTrail(tiRequestId);
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.ccrcmpmapping.service.CCRCMPMappingService#
     * completeECMActivtyTrail_By_TiReqId_CMP_OrdItemId(long, java.lang.String)
     */
    @Override
    public void completeECMActivtyTrail_By_TiReqId_CMP_OrdItemId(long tiRequestId, String cmpOrderItemId) {
        CCRCMPMappingDAOService.completeECMActivtyTrail_By_TiReqId_CMP_OrdItemId(tiRequestId, cmpOrderItemId);
    }

    @Override
    public List<Long> getCcrIdList(String cmpReqId) {
        return CCRCMPMappingDAOService.getCcrIdList(cmpReqId);
    }

    /*
     * To find audit Id of latest email sent
     */
    @Override
    public Long findResentMailAuditId(Long cmpId) {

        return CCRCMPMappingDAOService.findResentMailAuditId(cmpId);
    }

    /*
     * To find mail audit by id
     */
    @Override
    public TIMailAudit findTiMailAudit(Long tiMailAuditId) {

        return CCRCMPMappingDAOService.findTiMailAudit(tiMailAuditId);
    }

    /*
     * To get list of attachments by auditid
     */

    @Override
    public List<TIMailAuditAttachments> getEmailAuditTrailAttachments(Long auditId) {
        return CCRCMPMappingDAOService.getEmailAuditTrailAttachments(auditId);
    }

    @Override
    public Long saveCMPAddInfoRequested(CmpRequestDTO cmpRequestDTO) {
        return CCRCMPMappingDAOService.saveCmpComments(cmpRequestDTO);

    }

    @Override
    public void updateCMPAddInfoRequested(BusinessUserProcess businessUserProcess, CmpRequestDTO cmpRequestDTO) {
        CCRCMPMappingDAOService.updateCmpComments(businessUserProcess, cmpRequestDTO);
    }

    @Override
    public List<String> getRejectedCcrId(String cmpReqId) {
        return CCRCMPMappingDAOService.getRejectedCcrId(cmpReqId);
    }

    @Override
    public QuickSearchProcess finSearchProcessByCcrID(String ccrId) {

        return CCRCMPMappingDAOService.finSearchProcessByCcrID(ccrId);
    }

    @Override
    public String getCcrStatus(String tiRequestID) {
        return CCRCMPMappingDAOService.getCcrStatus(tiRequestID);
    }

    /*
     * To get additional Info in audit trail format
     */
    @Override
    public EmailGenerationViewProcess getECMReqInfo(EmailGenerationViewProcess emailGenerationViewProcess) {
        return CCRCMPMappingDAOService.getECMReqInfo(emailGenerationViewProcess);
    }

    /*
     * To load the values from CMP Comments and to store in BusinessUserProcess
     * VO
     */
    @Override
    public BusinessUserProcess getECMCommentsInfo(BusinessUserProcess businessUserProcess) {
        return CCRCMPMappingDAOService.getECMCommentsInfo(businessUserProcess);
    }

    /*
     * To get SectorName for Sector Id.
     */
    @Override
    public String getSectorName(String sectorId) {
        return CCRCMPMappingDAOService.getSectorName(sectorId);
    }

    /*
     * To get BusinessUnit Name for BusinessUnit Id.
     */
    @Override
    public String getBusinessUnitName(String businessUnitId) {
        return CCRCMPMappingDAOService.getBusinessUnitName(businessUnitId);
    }

    /*
     * 
     * To findCmpCommentsByMailAuditId
     */
    @Override
    public CMPComments findCmpCommentsByMailAuditId(Long auditId) {
        return CCRCMPMappingDAOService.findCmpCommentsByMailAuditId(auditId);
    }

    /*
     * 
     * To get CMP ID for given TiRequest ID
     */
	@Override
	public Long getCmpIdForTiRequestId(Long tiRequestId) {
		return CCRCMPMappingDAOService.getCmpIdForTiRequestId(tiRequestId);
	}

}
