package com.citigroup.cgti.c3par.bpm.ejb.search.domain;

import java.io.Serializable;


/**
 * The Class IPRegDetSearchAttributes.
 */
public class IPRegDetSearchAttributes   extends BaseSearchAttributes implements Serializable{

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 2882567683584328671L;

    /** The ip address. */
    private String ipAddress = null;

    /** The acl. */
    private String acl = null;

    /** The port. */
    private String port = null;

    /** The protocol. */
    private String protocol = null;

    /**
     * Gets the acl.
     *
     * @return the acl
     */
    public String getAcl() {
	return acl;
    }

    public String getAclForQuery() {
	return validString(acl);
    }

    /**
     * Sets the acl.
     *
     * @param acl the new acl
     */
    public void setAcl(String acl) {
	this.acl = acl;
    }

    /**
     * Gets the ip address.
     *
     * @return the ip address
     */
    public String getIpAddress() {
	return ipAddress;
    }

    public String getIpAddressForQuery() {
	return validString(ipAddress);
    }

    /**
     * Sets the ip address.
     *
     * @param ipAddress the new ip address
     */
    public void setIpAddress(String ipAddress) {
	this.ipAddress = ipAddress;
    }

    /**
     * Gets the port.
     *
     * @return the port
     */
    public String getPort() {
	return port;
    }

    public String getPortForQuery() {
	return validLongAsString(port);
    }
    /**
     * Sets the port.
     *
     * @param port the new port
     */
    public void setPort(String port) {
	this.port = port;
    }

    /**
     * Gets the protocol.
     *
     * @return the protocol
     */
    public String getProtocol() {
	return protocol;
    }

    public String getProtocolForQuery() {
	return validString(protocol);
    }

    /**
     * Sets the protocol.
     *
     * @param protocol the new protocol
     */
    public void setProtocol(String protocol) {
	this.protocol = protocol;
    }


}
