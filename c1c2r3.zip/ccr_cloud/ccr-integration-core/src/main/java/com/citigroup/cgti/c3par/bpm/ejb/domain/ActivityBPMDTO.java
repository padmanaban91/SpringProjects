package com.citigroup.cgti.c3par.bpm.ejb.domain;

import java.io.Serializable;


/**
 * The Class LookupDTO.
 */
public class ActivityBPMDTO implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 5178605931718464988L;

    /** The name. */
    private String activityName;

    /** The activity id. */
    private long activityId;

    /** The BPM instance id. */
    private String bpmInstanceId;
    
    /** The TiRequest id. */
    private Long tiRequestId;
    
    /** the Activity Trail ID */
    private Long activityTrailID;
    
    private Long userid;
    
    private long providedInfoActivityId;
    
    public Long getActivityTrailID() {
		return activityTrailID;
	}


	public void setActivityTrailID(Long activityTrailID) {
		this.activityTrailID = activityTrailID;
	}


	public Long getTiRequestId() {
		return tiRequestId;
	}


	public void setTiRequestId(Long tiRequestId) {
		this.tiRequestId = tiRequestId;
	}


	public ActivityBPMDTO (){}


	public String getActivityName() {
		return activityName;
	}


	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}


	public long getActivityId() {
		return activityId;
	}


	public void setActivityId(long activityId) {
		this.activityId = activityId;
	}


	public String getBpmInstanceId() {
		return bpmInstanceId;
	}


	public void setBpmInstanceId(String bpmInstanceId) {
		this.bpmInstanceId = bpmInstanceId;
	}


	public Long getUserid() {
		return userid;
	}


	public void setUserid(Long userid) {
		this.userid = userid;
	}


	public long getProvidedInfoActivityId() {
		return providedInfoActivityId;
	}


	public void setProvidedInfoActivityId(long providedInfoActivityId) {
		this.providedInfoActivityId = providedInfoActivityId;
	}
    
    
    


	
}
