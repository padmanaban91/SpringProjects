package com.citigroup.cgti.c3par.admin.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.citigroup.cgti.c3par.common.domain.GenericLookup;

/**
 * 
 *
 * @author ac81662
 */

/* DTO clas for Manage Firewall Policy Functionality */
public class FirewallPolicyDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    private Long policyId;
    private String searchPolicyName;
    private List<FirewallPolicyDTO> firewallPolicyDTOList = new ArrayList<FirewallPolicyDTO>();
    private boolean isSelected;
    private String policyName;
    private String fwType;
    private String mgmtRegion;
    private Date createdDate;
    private Date updatedDate;
    private String isZoned;
    private String group;
    private String deleteFlag;
    private String fwLocation;
    private String applicationInstance;
    private String comments;
    private String disabled;
    private String createdDateStr;
    private String updatedDateStr;
    private List<GenericLookup> firewallTypes;

    public String getPolicyName() {
        return policyName;
    }

    public void setPolicyName(String policyName) {
        this.policyName = policyName;
    }

    public String getFwType() {
        return fwType;
    }

    public void setFwType(String fwType) {
        this.fwType = fwType;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getIsZoned() {
        return isZoned;
    }

    public void setIsZoned(String isZoned) {
        this.isZoned = isZoned;
    }

    public String getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(String deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public String getMgmtRegion() {
        return mgmtRegion;
    }

    public void setMgmtRegion(String mgmtRegion) {
        this.mgmtRegion = mgmtRegion;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getFwLocation() {
        return fwLocation;
    }

    public void setFwLocation(String fwLocation) {
        this.fwLocation = fwLocation;
    }

    public String getApplicationInstance() {
        return applicationInstance;
    }

    public void setApplicationInstance(String applicationInstance) {
        this.applicationInstance = applicationInstance;
    }

    public String getSearchPolicyName() {
        return searchPolicyName;
    }

    public void setSearchPolicyName(String searchPolicyName) {
        this.searchPolicyName = searchPolicyName;
    }

    public List<FirewallPolicyDTO> getFirewallPolicyDTOList() {
        return firewallPolicyDTOList;
    }

    public void setFirewallPolicyDTOList(List<FirewallPolicyDTO> firewallPolicyDTOList) {
        this.firewallPolicyDTOList = firewallPolicyDTOList;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean isSelected) {
        this.isSelected = isSelected;
    }

    public Long getPolicyId() {
        return policyId;
    }

    public void setPolicyId(Long policyId) {
        this.policyId = policyId;
    }

    public List<GenericLookup> getFirewallTypes() {
        return firewallTypes;
    }

    public void setFirewallTypes(List<GenericLookup> firewallTypes) {
        this.firewallTypes = firewallTypes;
    }

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getDisabled() {
		return disabled;
	}

	public void setDisabled(String disabled) {
		this.disabled = disabled;
	}

	public String getCreatedDateStr() {
		return createdDateStr;
	}

	public void setCreatedDateStr(String createdDateStr) {
		this.createdDateStr = createdDateStr;
	}

	public String getUpdatedDateStr() {
		return updatedDateStr;
	}

	public void setUpdatedDateStr(String updatedDateStr) {
		this.updatedDateStr = updatedDateStr;
	}

}
