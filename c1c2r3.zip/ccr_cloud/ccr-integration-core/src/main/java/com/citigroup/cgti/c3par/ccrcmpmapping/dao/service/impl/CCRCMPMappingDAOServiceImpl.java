package com.citigroup.cgti.c3par.ccrcmpmapping.dao.service.impl;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import oracle.jdbc.OracleTypes;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.internal.SessionImpl;
import org.hibernate.transform.Transformers;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.lob.DefaultLobHandler;
import org.springframework.jdbc.support.lob.LobHandler;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.bpm.ejb.domain.ActivityDataDTO;
import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.ccrcmpmapping.dao.service.CCRCMPMappingDAOService;
import com.citigroup.cgti.c3par.common.domain.TIMailAudit;
import com.citigroup.cgti.c3par.common.domain.TIMailAuditAttachments;
import com.citigroup.cgti.c3par.common.domain.TITaskType;
import com.citigroup.cgti.c3par.communication.domain.BusinessUserProcess;
import com.citigroup.cgti.c3par.communication.domain.CCRCMPMappingDTO;
import com.citigroup.cgti.c3par.communication.domain.CCRCMPXref;
import com.citigroup.cgti.c3par.communication.domain.CMPComments;
import com.citigroup.cgti.c3par.communication.domain.CMPRequest;
import com.citigroup.cgti.c3par.communication.domain.CMPRequestContactXref;
import com.citigroup.cgti.c3par.communication.domain.CcrCmpXrefDto;
import com.citigroup.cgti.c3par.communication.domain.CmpReqIdSearchProcess;
import com.citigroup.cgti.c3par.communication.domain.CmpRequestDTO;
import com.citigroup.cgti.c3par.communication.domain.CmpSearchView;
import com.citigroup.cgti.c3par.communication.domain.ColumnsSortOrderSettings;
import com.citigroup.cgti.c3par.communication.domain.ECMConstants;
import com.citigroup.cgti.c3par.communication.domain.ECMUserSearchProcess;
import com.citigroup.cgti.c3par.communication.domain.EmailGenerationViewProcess;
import com.citigroup.cgti.c3par.communication.domain.EmerBuscritQuestionDto;
import com.citigroup.cgti.c3par.communication.domain.EmerBuscritQuestionaries;
import com.citigroup.cgti.c3par.communication.domain.QuickSearchProcess;
import com.citigroup.cgti.c3par.configuation.CCRQueries;
import com.citigroup.cgti.c3par.configuation.QueryConstants;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.domain.CMPRole;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCRequest;
import com.citigroup.cgti.c3par.util.StringUtil;

/**
 * @author ky38518
 * 
 */
@Repository
@Transactional
public class CCRCMPMappingDAOServiceImpl extends BasePersistanceImpl implements CCRCMPMappingDAOService {

    private static final Logger log = Logger.getLogger(CCRCMPMappingDAOServiceImpl.class.getName());

    @Autowired
    private SessionFactory sessionFactory;

    @Autowired
    @Qualifier("jdbcTemplate_ccr")
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private CCRQueries ccrQueries;
    private static final String MAIl_AUDIT_ID = "mailAuditId";

    public static final Map<String, String> ECMSearchColumnsMap;
    static {
        Map<String, String> searchColumnMap = new HashMap<String, String>();
        searchColumnMap.put("CMP ID", ECMConstants.ORDER_ITEM_ID_HBM_NAME);
        searchColumnMap.put("Agent Name", ECMConstants.AGENT_NAME_HBM_NAME);
        searchColumnMap.put("Date Assigned", ECMConstants.AVAILABLE_DATE_HBM_NAME);
        searchColumnMap.put("CMP Status", ECMConstants.CMP_STATUS_HBM_NAME);
        searchColumnMap.put("Current Status", ECMConstants.CURRENT_STATUS_HBM_NAME);
        searchColumnMap.put("Request Type", ECMConstants.TYPE_OF_CONN_INVOLVED_HBM_NAME);
        searchColumnMap.put("CCR ID", ECMConstants.CCR_ID_HBM_NAME);
        searchColumnMap.put("Change ID", ECMConstants.CHANGE_ID_HBM_NAME);

        ECMSearchColumnsMap = Collections.unmodifiableMap(searchColumnMap);
    }

    /*
     * To save the CCR CMP Mapping Details into Data base
     */
    @Override
    public void saveCCRCMPXref(String cmpOrderItemId, long tiRequestId) {
        try {
            log.info("cmpOrderItemId : " + cmpOrderItemId + " : tiRequestId : " + tiRequestId);
            Session session = sessionFactory.getCurrentSession();
            CCRCMPXref ccrCMPXref = new CCRCMPXref();
            ccrCMPXref.setCmpOrderItemId(cmpOrderItemId);
            ccrCMPXref.setTiRequestId(tiRequestId);
            ccrCMPXref.setCreatedDate(new DateTime().toDate());
            ccrCMPXref.setUpdatedDate(new DateTime().toDate());
            session.save(ccrCMPXref);
        } catch (Exception e) {
            log.error("Exception in saveCCRCMPXref" + e.toString(), e);
        }
    }

    /*
     * To get the cmp orderitem details based on searchString
     */
    @Override
    @Transactional(readOnly = true)
    public List<CCRCMPMappingDTO> getCMPOrderItemList(String searchString) {
        log.info("searchString : " + searchString);
        String CCRCMPMappingQuery = null;
        List<CCRCMPMappingDTO> result = null;
        try {
            if (searchString != null && !"".equals(searchString)) {
                if (searchString.indexOf(",") == -1) {
                    CCRCMPMappingQuery = ccrQueries
                            .getQueryByName(CCRCMPMappingConstants.CMP_ORDERITEMID_WITH_SEARCHSTRING);
                    searchString = "'%" + searchString.trim() + "%'";
                } else {
                    CCRCMPMappingQuery = ccrQueries
                            .getQueryByName(CCRCMPMappingConstants.CMP_ORDERITEMID_SEARCH_IN_CLAUSE);
                    searchString = "('" + searchString.trim() + "')";
                }
                CCRCMPMappingQuery = CCRCMPMappingQuery.replace(":CMP_ORDER_ITEM", searchString);
            } else {
                CCRCMPMappingQuery = ccrQueries.getQueryByName(CCRCMPMappingConstants.CMP_ORDERITEMID_SEARCH);
            }

            result = jdbcTemplate.query(CCRCMPMappingQuery, new RowMapper<CCRCMPMappingDTO>() {
                @Override
                public CCRCMPMappingDTO mapRow(ResultSet rs, int rownumber) throws SQLException {

                    CCRCMPMappingDTO ccrCMPMappingDTO = new CCRCMPMappingDTO();
                    ccrCMPMappingDTO.setCmpOrderItemId(rs.getString(1));
                    ccrCMPMappingDTO.setCmpApproverName(rs.getString(2));
                    ccrCMPMappingDTO.setCmpApproverGEId(rs.getString(3));
                    ccrCMPMappingDTO.setCmpApprovedDate(rs.getDate(4));

                    return ccrCMPMappingDTO;
                }
            });
        } catch (Exception e) {
            log.error("Exception occurred in getCMPOrderItemList : " + e.toString(), e);
        }
        return result;
    }

    /*
     * To verify whether ccr cmp Mapping already exists in data base
     */
    @Override
    @Transactional(readOnly = true)
    public boolean isCMPCCRMappingExists(String cmpOrderItemId, long tiRequestId) {
        boolean CCRCMPMappingExists = false;
        try {
            log.info("cmpOrderItemId : " + cmpOrderItemId + ", tiRequestId : " + tiRequestId);
            Session session = sessionFactory.getCurrentSession();
            Criteria crit = session.createCriteria(CCRCMPXref.class);
            crit.add(Restrictions.eq("cmpOrderItemId", cmpOrderItemId));
            crit.add(Restrictions.eq("tiRequestId", tiRequestId));
            List<CCRCMPXref> ccrCMPRefList = crit.list();
            if (ccrCMPRefList != null && ccrCMPRefList.size() > 0) {
                CCRCMPMappingExists = true;
            }
            log.info("CCRCMPMappingExists  : " + CCRCMPMappingExists);
        } catch (Exception e) {
            log.error("Exception occurred in isCMPCCRMappingExists : " + e.toString(), e);
        }
        return CCRCMPMappingExists;
    }

    /*
     * To delete ccr cmp mapping details from db based on id
     */

    @Override
    @Transactional(readOnly = false)
    public boolean deleteCmpFromCCR(long cmpCcrMappingId) {
        boolean deletionStatus = true;
        try {
            log.info("deleteCmpFromCCR Id" + cmpCcrMappingId);
            Session session = sessionFactory.getCurrentSession();
            CCRCMPXref ccrCMpXRef = (CCRCMPXref) session.load(CCRCMPXref.class, cmpCcrMappingId);
            session.delete(ccrCMpXRef);

        } catch (Exception e) {
            deletionStatus = false;
            log.error("Exception occurred in deleteCmpFromCCR Id : " + e.toString(), e);
        }
        return deletionStatus;
    }

    /*
     * To get ccr id details linked to cmpReqId
     */

    @Override
    public List<CcrCmpXrefDto> getCcrCmpXrefByOrderItemId(String cmpReqId) {
        List<CcrCmpXrefDto> ccrCmpXrefDtoList = new ArrayList<CcrCmpXrefDto>();
        try {
            Session session = sessionFactory.getCurrentSession();
            StringBuffer queryString = new StringBuffer();
            queryString
                    .append(" select  ( TIREQ.PROCESS_ID  || '.' ||  TIREQ.VERSION_NUMBER) ccrId,TIREQ.ID tiRequestId, CMPXREF.id ccrcmpXrefId from  CCR_CMP_XREF CMPXREF,TI_REQUEST TIREQ where CMPXREF.CMP_ORDER_ITEM_ID=:orderItemId AND  TIREQ.ID=CMPXREF.TI_REQUEST_ID ");
            SQLQuery query = session.createSQLQuery(queryString.toString());
            query.setParameter("orderItemId", cmpReqId);
            query.addScalar("ccrId", StringType.INSTANCE);
            query.addScalar("tiRequestId", LongType.INSTANCE);
            query.addScalar("ccrcmpXrefId", LongType.INSTANCE);
            query.setResultTransformer(Transformers.aliasToBean(CcrCmpXrefDto.class));
            ccrCmpXrefDtoList = query.list();

        } catch (Exception e) {
            log.error("Exception occurred in getCcrCmpXrefByOrderItemId  : " + e.toString(), e);
        }
        return ccrCmpXrefDtoList;

    }

    /*
     * To validate whether ccr is in active or ACV Status
     */
    @Override
    public List<String> validateLinkedCCR(String tiRequestID) {
        List<String> errorMessageList = new ArrayList<>();
        try {
            Session session = sessionFactory.getCurrentSession();
            String ccrStautsQuery = ccrQueries.getQueryByName(CCRCMPMappingConstants.CCR_TASK_STATUS);
            SQLQuery query = session.createSQLQuery(ccrStautsQuery);
            query.setParameter("reqId", tiRequestID);
            query.addScalar("taskname", StringType.INSTANCE);
            List<String> taskStatus = query.list();
            if (CollectionUtils.isEmpty(taskStatus)) {
                errorMessageList.add(CCRCMPMappingConstants.ERR_MSG_INVALID_CCR);
            } else if (Arrays.asList(CCRCMPMappingConstants.ACTIVE_ACV_STAUS).contains(taskStatus.get(0))) {
                errorMessageList.add(CCRCMPMappingConstants.ERR_MSG_INVALID_CCR_STATUS);
            } else if (CCRCMPMappingConstants.REJECTED_CCR_STATUS.equals(taskStatus.get(0))) {
                errorMessageList.add(CCRCMPMappingConstants.ERR_MSG_REJECTED_CCR_STATUS);
            } else if (CCRCMPMappingConstants.ABORTED.equals(taskStatus.get(0))) {
                errorMessageList.add(CCRCMPMappingConstants.ERR_MSG_ABORTED_CCR_STATUS);
            }
        } catch (Exception e) {
            log.error("Exception occurred in validateLinkedCCR  : " + e.toString(), e);
        }
        return errorMessageList;
    }

    /*
     * To return a string containing cmpOrderItems for a given TiRequestId
     */
    @Override
    @Transactional(readOnly = true)
    public String getOrderItemIdforTIRequest(long tiRequestId) {
        String cmpOrderItems = "";
        List<String> cmpOrderItemList = null;
        String orderItemIdForTiRequestQry = null;
        int count = 0;
        try {
            if (tiRequestId > 0) {
                Object[] params = { tiRequestId };
                orderItemIdForTiRequestQry = ccrQueries
                        .getQueryByName(CCRCMPMappingConstants.CMP_ORDERITEMS_FOR_TI_REQUESTID);
                cmpOrderItemList = jdbcTemplate.query(orderItemIdForTiRequestQry, params, new RowMapper<String>() {
                    public String mapRow(ResultSet rs, int rowNum) throws SQLException {
                        return rs.getString(1);
                    }
                });
                for (String cmpOrderItemId : cmpOrderItemList) {
                    if (count == cmpOrderItemList.size() - 1) {
                        cmpOrderItems = cmpOrderItems + cmpOrderItemId;
                    } else {
                        cmpOrderItems = cmpOrderItems + cmpOrderItemId + ",";
                    }
                    count++;
                }
            }
        } catch (Exception e) {
            log.error("Exception occurred in getOrderItemIdforTIRequest  : " + e.toString(), e);
        }
        return cmpOrderItems;
    }

    /*
     * To get tiRequestId based on ccrId
     */
    @Override
    public Long getTIRequestID(String ccrID) {
        Long tiRequestId = null;
        try {
            if (ccrID != null && ccrID.contains(".")) {
                String tiRequestuery = CCRCMPMappingConstants.TI_REQUEST_ID;
                Session session = sessionFactory.getCurrentSession();
                SQLQuery query = session.createSQLQuery(tiRequestuery);
                String processId = ccrID.split("\\.")[0];
                String versionNo = ccrID.split("\\.")[1];
                query.setParameter("processId", processId);
                query.setParameter("versionNo", versionNo);
                query.addScalar("id", LongType.INSTANCE);
                tiRequestId = (Long) query.uniqueResult();
            }

        } catch (Exception e) {
            log.error("Exception occurred in getTIRequestID  : " + e.toString(), e);
        }
        return tiRequestId;
    }

    @Override
    public CcrCmpXrefDto getCcrCmpXrefByOrderItemId(String cmpReqId, Long tiRequestId) {
        CcrCmpXrefDto ccrCmpXrefDto = new CcrCmpXrefDto();
        try {

            Session session = sessionFactory.getCurrentSession();
            StringBuffer queryString = new StringBuffer();
            queryString
                    .append(" select  ( TIREQ.PROCESS_ID  || '.' ||  TIREQ.VERSION_NUMBER) ccrId,TIREQ.ID tiRequestId, CMPXREF.id ccrcmpXrefId from  CCR_CMP_XREF CMPXREF,TI_REQUEST TIREQ where CMPXREF.CMP_ORDER_ITEM_ID=:orderItemId AND  TIREQ.ID=CMPXREF.TI_REQUEST_ID  AND  TIREQ.ID=:tiRequestId");
            SQLQuery query = session.createSQLQuery(queryString.toString());
            query.setParameter("orderItemId", cmpReqId);
            query.setParameter("tiRequestId", tiRequestId);
            query.addScalar("ccrId", StringType.INSTANCE);
            query.addScalar("tiRequestId", LongType.INSTANCE);
            query.addScalar("ccrcmpXrefId", LongType.INSTANCE);
            query.setResultTransformer(Transformers.aliasToBean(CcrCmpXrefDto.class));
            ccrCmpXrefDto = (CcrCmpXrefDto) query.uniqueResult();

        } catch (Exception e) {
            log.error("Exception occurred in getCcrCmpXrefByOrderItemId  : " + e.toString(), e);
        }
        return ccrCmpXrefDto;

    }

    /*
     * To return a integer which represents the CMP status
     */
    @Override
    @Transactional(readOnly = true)
    public int checkCMPStatus(long tiRequestId) {
        log.info("tiRequestId : " + tiRequestId);
        CallableStatement callstmn = null;
        int cmpStatus = 0;
        try {
            String procedureCall = "{? = call CHECK_CMP_STATUS(?)}";
            callstmn = ((SessionImpl) sessionFactory.getCurrentSession()).connection().prepareCall(procedureCall);
            callstmn.registerOutParameter(1, Types.INTEGER);
            callstmn.setLong(2, tiRequestId);
            callstmn.executeUpdate();
            cmpStatus = callstmn.getInt(1);
        } catch (Exception e) {
            log.error("Exception occurred in checkCMPStatus  : " + e.toString(), e);
        }
        return cmpStatus;
    }

    /*
     * To return Map containing the user details who completed the CMP
     */
    @Override
    @Transactional(readOnly = true)
    public Map<String, String> getCompletedUserDetails(long tiRequestId) {
        log.info("tiRequestId : " + tiRequestId);
        Map<String, String> userDetails = null;
        String userDetailsQuery = null;
        SqlRowSet rs = null;
        try {
            userDetails = new HashMap<String, String>();
            userDetailsQuery = ccrQueries.getQueryByName(CCRCMPMappingConstants.GET_COMPLETED_USER_DETAILS);
            Object[] params = { tiRequestId };
            rs = jdbcTemplate.queryForRowSet(userDetailsQuery, params);
            if (rs.next()) {
                userDetails.put("completedBy", rs.getString(1));
                userDetails.put("UserId", rs.getString(2));
            }
        } catch (Exception e) {
            log.error("Exception occurred in getCompletedUserDetails  : " + e.toString(), e);
        }
        return userDetails;
    }

    /*
     * To get the cmp item list for a given tiRequestId
     */
    @Override
    @Transactional(readOnly = true)
    public Map<String, List<String>> getCMPCCRDetails(long tiRequestId) {
        log.info("tiRequestId : " + tiRequestId);
        String CMPItemListQuery = null;
        Map<String, List<String>> cmpItemDetails = null;
        List<String> cmpDetails = null;
        List<String> ccrDetails = null;
        List<String> cmpOrderItemDetails = null;
        SqlRowSet rs = null;
        try {
            cmpItemDetails = new HashMap<String, List<String>>();
            cmpDetails = new ArrayList<String>();
            ccrDetails = new ArrayList<String>();
            cmpOrderItemDetails = new ArrayList<String>();
            if (tiRequestId > 0) {
                Object[] params = { tiRequestId };
                CMPItemListQuery = ccrQueries.getQueryByName(CCRCMPMappingConstants.GET_CMPID_FOR_MAPPED_CCR);
                rs = jdbcTemplate.queryForRowSet(CMPItemListQuery, params);
                while (rs.next()) {
                    cmpDetails.add(rs.getString(1));
                    ccrDetails.add(rs.getString(2));
                    cmpOrderItemDetails.add(rs.getString(3));
                }
                cmpItemDetails.put("cmpDetails", cmpDetails);
                cmpItemDetails.put("ccrDetails", ccrDetails);
                cmpItemDetails.put("cmpOrderItemDetails", cmpOrderItemDetails);
            }
        } catch (Exception e) {
            log.error("Exception occurred in getCMPItemList : " + e.toString(), e);
        }
        return cmpItemDetails;
    }

    /*
     * To get the cmp XML Content in string format
     */
    @Override
    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    public String getCMPXMLContent(String cmpId) {
        log.info("cmpId : " + cmpId);
        List<String> cmpXMLList = null;
        String CMPXMLContentQuery = "";
        String cmpXMLContent = "";
        try {
            if (cmpId != null && !cmpId.equals("")) {
                Object[] params = { cmpId };
                CMPXMLContentQuery = ccrQueries.getQueryByName(CCRCMPMappingConstants.GET_CMP_BLOB_CONTENT_IN_STRING);
                cmpXMLList = jdbcTemplate.query(CMPXMLContentQuery, params, new RowMapper() {
                    @Override
                    public String mapRow(ResultSet rs, int rowNum) throws SQLException {
                        LobHandler lobHandler = new DefaultLobHandler();
                        byte[] cmpByteArray = lobHandler.getBlobAsBytes(rs, "NOTIFY_XML");
                        String cmp_data = new String(cmpByteArray);
                        return cmp_data;
                    }
                });
                if (cmpXMLList != null && cmpXMLList.size() > 0) {
                    cmpXMLContent = (String) cmpXMLList.get(0);
                }
            }
        } catch (Exception e) {
            log.error("Exception occurred in getCMPXMLContent : " + e.toString(), e);
        }
        return cmpXMLContent;
    }

    /*
     * To update CMP Status into CMP_REQUEST table
     */
    @Override
    public int updateCMPStatus(String status, String cmpId) {
        log.info("status : " + status);
        log.info("cmpId : " + cmpId);
        String updateCMPStatusQuery = "";
        int updateCount = 0;
        try {
            Object[] params = { status, cmpId };
            updateCMPStatusQuery = ccrQueries.getQueryByName(CCRCMPMappingConstants.UPDATE_COMPLETED_STATUS_FOR_CMP);
            updateCount = jdbcTemplate.update(updateCMPStatusQuery, params);
        } catch (Exception e) {
            log.error("Exception occurred in updateCMPStatus : " + e.toString(), e);
        }
        return updateCount;
    }

    /*
     * To get the cmp item list for a given tiRequestId
     */
    @Override
    @Transactional(readOnly = true)
    public Map<String, List<String>> getMappedCMPIdForCCRId(long activityTrailId) {
        log.info("activityTrailId : " + activityTrailId);
        String CMPIdsMappedQuery = null;
        Map<String, List<String>> cmpMappedItemDetails = null;
        List<String> cmpDetails = null;
        List<String> ccrDetails = null;
        List<String> tiRequestDetails = null;
        List<String> ccrCMPXrefDetails = null;
        List<String> cmpOrderitemDetails = null;
        SqlRowSet rs = null;
        try {
            cmpMappedItemDetails = new HashMap<String, List<String>>();
            cmpDetails = new ArrayList<String>();
            ccrDetails = new ArrayList<String>();
            tiRequestDetails = new ArrayList<String>();
            ccrCMPXrefDetails = new ArrayList<String>();
            cmpOrderitemDetails = new ArrayList<String>();
            if (activityTrailId > 0) {
                Object[] params = { activityTrailId };
                CMPIdsMappedQuery = ccrQueries.getQueryByName(CCRCMPMappingConstants.GET_MAPPED_CMPIDS_FOR_CCR);
                rs = jdbcTemplate.queryForRowSet(CMPIdsMappedQuery, params);
                while (rs.next()) {
                    tiRequestDetails.add(rs.getString(1));
                    cmpDetails.add(rs.getString(2));
                    ccrDetails.add(rs.getString(3));
                    ccrCMPXrefDetails.add(rs.getString(4));
                    cmpOrderitemDetails.add(rs.getString(5));
                }
                cmpMappedItemDetails.put("cmpDetails", cmpDetails);
                cmpMappedItemDetails.put("ccrDetails", ccrDetails);
                cmpMappedItemDetails.put("tiRequestDetails", tiRequestDetails);
                cmpMappedItemDetails.put("ccrCMPXrefDetails", ccrCMPXrefDetails);
                cmpMappedItemDetails.put("cmpOrderitemDetails", cmpOrderitemDetails);
            }
        } catch (Exception e) {
            log.error("Exception occurred in getMappedCMPIdForCCRId : " + e.toString(), e);
        }
        return cmpMappedItemDetails;
    }

    /*
     * To get the GE Id for the given SSO Id
     */
    @Override
    @Transactional(readOnly = true)
    public String getGEIdforUser(String ssoId) {
        log.info("ssoId : " + ssoId);
        String GEId = "";
        SqlRowSet rs = null;
        final String GEIdQuery = "SELECT GEID FROM CITI_CONTACT WHERE UPPER(SSO_ID)=?";
        try {
            Object[] params = { ssoId };
            rs = jdbcTemplate.queryForRowSet(GEIdQuery, params);
            if (rs.next()) {
                GEId = rs.getString(1);
            }
        } catch (Exception e) {
            log.error("Exception occurred in getGEIdforUser : " + e.toString(), e);
        }
        return GEId;
    }

    /*
     * To get task description for the current activity
     */
    @Override
    @Transactional(readOnly = true)
    public String getTaskDescriptionForActivity(long activityTrailId) {
        log.info("activityTrailId : " + activityTrailId);
        String taskDescription = "";
        String taskDescriptionQuery = "";
        SqlRowSet rs = null;
        try {
            if (activityTrailId > 0) {
                Object[] params = { activityTrailId };
                taskDescriptionQuery = ccrQueries
                        .getQueryByName(CCRCMPMappingConstants.GET_TASKDESCRIPTION_FOR_ACTIVITY);
                rs = jdbcTemplate.queryForRowSet(taskDescriptionQuery, params);
                if (rs.next()) {
                    taskDescription = rs.getString(1);
                }
            }
        } catch (Exception e) {
            log.error("Exception occurred in getTaskDescriptionForActivity : " + e.toString(), e);
        }
        return taskDescription;
    }

    /*
     * To get the CMP Request details for a given orderitemId
     */
    @SuppressWarnings("unchecked")
    @Override
    @Transactional(readOnly = true)
    public CMPRequest getCMPRequestDetailsByOrderItemId(String cmpOrderItemId) {
        log.info("cmpOrderItemId - " + cmpOrderItemId);
        Session session = sessionFactory.getCurrentSession();
        CMPRequest cmpRequest = null;
        CallableStatement callstm = null;
        int time = 0;
        String procedureCall = "{call CALCULATE_ACTIVITY_TIME(?,?,?)}";
        try {
            Criteria criteria = session.createCriteria(CMPRequest.class);
            criteria.add(Restrictions.eq("orderItemId", cmpOrderItemId));
            List<CMPRequest> cmpReqList = criteria.list();

            if (cmpReqList != null && cmpReqList.size() > 0) {
                cmpRequest = cmpReqList.get(0);
                lazyInitialize(cmpRequest.getTiactivityTrail());
                lazyInitialize(cmpRequest.getCmpRequestNotes());
            }
            callstm = ((SessionImpl) session).connection().prepareCall(procedureCall);
            callstm.setLong(1, cmpRequest.getId());
            callstm.setString(2, "ECM TIMER");
            callstm.registerOutParameter(3, OracleTypes.BIGINT);
            callstm.executeUpdate();
            time = callstm.getBigDecimal(3).intValue();
            cmpRequest.setEcmTimer(Long.valueOf(time));
        } catch (Exception e) {
            log.error("Exception occurred in getCMPRequestDetailsByOrderItemId : " + e.toString(), e);
        }
        return cmpRequest;
    }

    /*
     * To return a integer which represents the CmpSloHrs
     */
    @Override
    @Transactional(readOnly = true)
    public Long getCmpSloHrs(long cmpId, Long tiRequestId) {
        log.info("tiRequestId : " + tiRequestId);
        CallableStatement callstmn = null;

        int time = 0;
        try {

            String procedureCall = "{call CALCULATE_SLOACTIVITY_TIME(?,?,?,?)}";
            callstmn = ((SessionImpl) sessionFactory.getCurrentSession()).connection().prepareCall(procedureCall);
            callstmn.setLong(1, cmpId);
            callstmn.setString(2, "ECM TIMER");
            if (tiRequestId != null) {
                callstmn.setLong(3, tiRequestId);
            } else {
                callstmn.setLong(3, -1L);
            }
            callstmn.registerOutParameter(4, OracleTypes.BIGINT);
            callstmn.executeUpdate();
            time = callstmn.getBigDecimal(4).intValue();

        } catch (Exception ex) {
            log.error("Exception occurred in getCmpSloHrs: " + ex.toString(), ex);
        }
        return Long.valueOf(time);
    }

    /*
     * To delete the existing mapping between CCR and CMP
     */
    @Override
    public void clearMappedCMPIds(long tiRequestId) {
        log.info("tiRequestId : " + tiRequestId);
        try {
            Session session = sessionFactory.getCurrentSession();
            Criteria crit = session.createCriteria(CCRCMPXref.class);
            crit.add(Restrictions.eq("tiRequestId", tiRequestId));
            List list = crit.list();
            log.info("list.size() : " + list.size());
            for (Object obj : list) {
                CCRCMPXref ccrcmpXref = (CCRCMPXref) obj;
                session.delete(ccrcmpXref);
            }
        } catch (Exception ex) {
            log.error("Exception occurred in clearMappedCMPIds: " + ex.toString(), ex);
        }
    }

    /*
     * To delete the existing mapping between CCR and CMP
     */
    @Override
    public void logECMActivityTrail(long tiRequestId) {
        log.info("tiRequestId : " + tiRequestId);
        SqlRowSet rs = null;
        String mappedCMPsforTirequestQry = null;
        long cmp_request_id = 0;
        try {
            Object[] params = { tiRequestId };
            mappedCMPsforTirequestQry = ccrQueries
                    .getQueryByName(CCRCMPMappingConstants.GET_MAPPEDCMPIDS_FOR_TIREQUESTID);
            rs = jdbcTemplate.queryForRowSet(mappedCMPsforTirequestQry, params);
            while (rs.next()) {
                cmp_request_id = rs.getLong(2);
                insertECMActivity(cmp_request_id);
            }
        } catch (Exception ex) {
            log.error("Exception occurred in logECMActivityTrail: " + ex.toString(), ex);
        }
    }

    /*
     * To insert ECM Audit Trail Entry
     */
    private void insertECMActivity(long cmp_request_id) {
        log.info("cmp_request_id : " + cmp_request_id);
        String insertECMAuditQry = null;
        try {
            Object[] params = { ECMConstants.STATUS_STARTED, ECMConstants.CMP_USER_CREATION, ActivityDataDTO.IS_NEW,
                    cmp_request_id };
            insertECMAuditQry = ccrQueries.getQueryByName(CCRCMPMappingConstants.INSERT_ECM_ACTIVITYTRAIL);
            jdbcTemplate.update(insertECMAuditQry, params);
        } catch (Exception e) {
            log.error("Exception occurred in insertECMActivity: " + e.toString(), e);
        }
    }

    /*
     * To delete the existing mapping between CCR and CMP
     */
    @Override
    public void completeECMActivityTrail(long tiRequestId) {
        log.info("tiRequestId : " + tiRequestId);
        SqlRowSet rs = null;
        String mappedCMPsforTirequestQry = null;
        long auditTrailId = 0;
        try {
            Object[] params = { tiRequestId, tiRequestId };
            mappedCMPsforTirequestQry = ccrQueries
                    .getQueryByName(CCRCMPMappingConstants.GET_ACTIVITYTRAIL_FOR_MAPPEDCMPIDS);
            rs = jdbcTemplate.queryForRowSet(mappedCMPsforTirequestQry, params);
            while (rs.next()) {
                auditTrailId = rs.getLong(3);
                completeECMActivity(auditTrailId);
            }
        } catch (Exception ex) {
            log.error("Exception occurred in logECMActivityTrail: " + ex.toString(), ex);
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see
     * com.citigroup.cgti.c3par.ccrcmpmapping.dao.service.CCRCMPMappingDAOService
     * #completeECMActivtyTrail_By_TiReqId_CMP_OrdItemId(long, String)
     */
    @Override
    public void completeECMActivtyTrail_By_TiReqId_CMP_OrdItemId(long tiRequestId, String cmpOrderItemId) {
        log.info("tiRequestId : " + tiRequestId + ", cmpOrderItemId : " + cmpOrderItemId);
        SqlRowSet rs = null;
        String mappedCMPsforTirequestQry = null;
        long auditTrailId = 0;
        try {
            Object[] params = { tiRequestId, tiRequestId };
            mappedCMPsforTirequestQry = ccrQueries
                    .getQueryByName(CCRCMPMappingConstants.GET_ACTIVITYTRAIL_FOR_MAPPEDCMPIDS);
            rs = jdbcTemplate.queryForRowSet(mappedCMPsforTirequestQry, params);
            while (rs.next()) {
                String cmpOrderItemId_From_DB = rs.getString(1);
                auditTrailId = rs.getLong(3);
                if (cmpOrderItemId.equals(cmpOrderItemId_From_DB)) {
                    completeECMActivity(auditTrailId);
                }

            }
        } catch (Exception ex) {
            log.error("An exception occurred while completing cmp " + ex.toString(), ex);
        }
    }

    /*
     * To update completion status for ECM activity
     */
    public void completeECMActivity(long auditTrailId) {
        log.info("auditTrailId : " + auditTrailId);
        String updateCompletionStatusQuery = "";
        int updateCount = 0;
        try {
            Object[] params = { ActivityData.STATUS_COMPLETED, auditTrailId, ActivityData.STATUS_STARTED };
            updateCompletionStatusQuery = ccrQueries.getQueryByName(CCRCMPMappingConstants.COMPLETE_ECM_ACTIVITYTRAIL);
            updateCount = jdbcTemplate.update(updateCompletionStatusQuery, params);
            log.info("updateCount : " + updateCount);
        } catch (Exception e) {
            log.error("An Exception occurred in completeECMActivity : " + e.toString(), e);
        }
    }

    @Override
    public List<Long> getCcrIdList(String cmpReqId) {

        List<Long> ccrCmpXrefDtoList = new ArrayList<Long>();
        try {
            Session session = sessionFactory.getCurrentSession();
            StringBuffer queryString = new StringBuffer();
            queryString
                    .append(" select  TIREQ.PROCESS_ID  ccrId   from  CCR_CMP_XREF CMPXREF,TI_REQUEST TIREQ where CMPXREF.CMP_ORDER_ITEM_ID=:orderItemId AND  TIREQ.ID=CMPXREF.TI_REQUEST_ID ");
            SQLQuery query = session.createSQLQuery(queryString.toString());
            query.setParameter("orderItemId", cmpReqId);
            query.addScalar("ccrId", LongType.INSTANCE);
            ccrCmpXrefDtoList = query.list();

        } catch (Exception e) {
            log.error("Exception occurred in getCcrIdList  : " + e.toString(), e);
        }
        return ccrCmpXrefDtoList;

    }

    /**
     * Dao method to get Task from DB for Search Screen
     * 
     * @return
     * @throws Exception
     */
    @Override
    public List<String> getTask() throws Exception {
        List<TITaskType> taskskList = new ArrayList<TITaskType>();
        List<String> resultList = new ArrayList<String>();
        Set<String> resultSet = new HashSet<String>();
        try {
            Session session = sessionFactory.getCurrentSession();
            Query query = session.createQuery("FROM TITaskType");
            taskskList = query.list();
            if (taskskList != null && taskskList.size() > 0) {
                for (TITaskType tasksk : taskskList) {
                    resultSet.add(tasksk.getTask());
                }
                resultList.addAll(resultSet);
                Collections.sort(resultList);
            }
        } catch (Exception e) {
            log.error("Exception occurred while getTask : " + e.toString(), e);
            throw new ApplicationException("Exception has occurred :: getTask() ", e);
        }
        return resultList;
    }

    /**
     * Dao method to get ECM agent List
     * 
     * @return
     * @throws Exception
     */
    @Override
    public List<String> getEcmAgent(boolean isServiceDesk) throws Exception {
        String searchText = "";
        List<String> resultList = new ArrayList<>();
        Set<String> resultSet = new HashSet<>();
        try {
            ECMUserSearchProcess ecmUsersSearchProcess = new ECMUserSearchProcess();
            List<ECMUserSearchProcess> ecmAgentList = ecmUsersSearchProcess.selectEcmUsers(searchText,isServiceDesk);
            List<ECMUserSearchProcess> finalList = new ArrayList<ECMUserSearchProcess>();
            if (ecmAgentList != null && ecmAgentList.size() > 0) {
                for (Object obj : ecmAgentList) {
                    Map map = (Map) obj;

                    finalList
                            .add(new ECMUserSearchProcess((String) map.get("SSO_ID"), (String) map.get("LAST_NAME"),
                                    (String) map.get("FIRST_NAME"), (String) map.get("IS_LOCKED"), (String) map
                                            .get("COMMENTS")));
                }
                for (ECMUserSearchProcess agents : finalList) {
                    resultSet.add(agents.getLastName() + ", " + agents.getFirstName());
                }
                resultList.addAll(resultSet);
                Collections.sort(resultList);
            }
        } catch (Exception e) {
            log.error("Exception while getEcmAgent " + e.toString(), e);
            throw new ApplicationException("Exception getEcmAgent ", e);
        }
        return resultList;
    }

    /**
     * Dao method to get list of CMP ids based on search criteria
     * 
     * @param cmpReqIdSearchProcess
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    public List<CmpSearchView> getCMPList(CmpReqIdSearchProcess cmpReqIdSearchProcess, boolean isExport,
            List<ColumnsSortOrderSettings> ecmColumnsOrderSettingsList) throws Exception {
        log.info("CCRCMPMappingDAOService.getCMPList starts");
        boolean isCriteriaAvailable = false;
        List<CmpSearchView> cmpList = new ArrayList<>();
        Session session = sessionFactory.getCurrentSession();
        try {
            String sortingColumnName = sortingcolumnNameConversion().get(cmpReqIdSearchProcess.getSortingColumnName());
            if (sortingColumnName == null) {
                sortingColumnName = ECMConstants.ORDER_ITEM_ID_HBM_NAME;
            }
            String cmpReqId = StringUtil.trim(cmpReqIdSearchProcess.getCmpreqID());
            String ccrId = StringUtil.trim(cmpReqIdSearchProcess.getCcrID());
            String ecmAgent = cmpReqIdSearchProcess.getEcmAgent();
            String cmpStatus = cmpReqIdSearchProcess.getCmpStatus();
            String requesterName = StringUtil.trim(cmpReqIdSearchProcess.getOrderByUser());
            String businessOwner = StringUtil.trim(cmpReqIdSearchProcess.getBusinessOwner());
            String currentStatus = cmpReqIdSearchProcess.getCurrentStatus();
            String changeId = StringUtil.trim(cmpReqIdSearchProcess.getChangeId());
            Date fromDate = cmpReqIdSearchProcess.getFromDate();
            Date toDate = cmpReqIdSearchProcess.getToDate();
            String goc = StringUtil.trim(cmpReqIdSearchProcess.getGoc());
            if (null != toDate) {
                Calendar cal = Calendar.getInstance();
                cal.setTime(toDate);
                cal.add(Calendar.DATE, 1);
                toDate = cal.getTime();
                log.info("toDate " + toDate);
            }

            Criteria criteria = session.createCriteria(CmpSearchView.class);
            if (!StringUtil.isNullorEmpty(cmpStatus)) {
                isCriteriaAvailable = true;
                if (cmpStatus.equals(ECMConstants.MGR_COMPLETE)) {
                    criteria.add(Restrictions.eq(ECMConstants.CMP_STATUS_HBM_NAME, ECMConstants.COMPLETED));
                    criteria.add(Restrictions.eq(ECMConstants.IS_MANAGER_COMPLETED_HBM_NAME, "Y"));
                } else {
                    criteria.add(Restrictions.eq(ECMConstants.CMP_STATUS_HBM_NAME, cmpStatus));
                }
            }
            log.info("cmpReqIdSearchProcess.getEcomType() :: "+cmpReqIdSearchProcess.getEcomType());
            if (!StringUtil.isNullorEmpty(cmpReqIdSearchProcess.getEcomType())) {
                if (ECMConstants.SERVICE_DESK.equals(cmpReqIdSearchProcess.getEcomType())) {
                    criteria.add(Restrictions.in(ECMConstants.TYPE_OF_CONN_INVOLVED_HBM_NAME,
                            ECMConstants.SEC_ACL_APPSENSE));
                } else if (ECMConstants.ECM.equals(cmpReqIdSearchProcess.getEcomType())) {
                    criteria.add(Restrictions.not(Restrictions.in(ECMConstants.TYPE_OF_CONN_INVOLVED_HBM_NAME,
                            ECMConstants.SEC_ACL_APPSENSE)));
                }
            }
            if (!StringUtil.isNullorEmpty(cmpReqId)) {
                isCriteriaAvailable = true;
                criteria.add(Restrictions.ilike(ECMConstants.ORDER_ITEM_ID_HBM_NAME, cmpReqId, MatchMode.ANYWHERE));
            }
            if (!StringUtil.isNullorEmpty(ccrId)) {
                isCriteriaAvailable = true;
                if (ccrId.contains(".")) {
                    String ccrIdVal = ccrId.substring(0, ccrId.indexOf('.'));
                    String ccrVer = ccrId.substring(ccrId.indexOf('.') + 1, ccrId.length());
                    criteria.add(Restrictions.eq(ECMConstants.CCR_ID_HBM_NAME, Long.parseLong(ccrIdVal)));
                    criteria.add(Restrictions.eq(ECMConstants.VERSION_HBM_NAME, Long.parseLong(ccrVer)));
                } else {
                    criteria.add(Restrictions.eq(ECMConstants.CCR_ID_HBM_NAME, Long.parseLong(ccrId)));
                }

            }
            if (!StringUtil.isNullorEmpty(ecmAgent)) {
                isCriteriaAvailable = true;
                criteria.add(Restrictions.ilike(ECMConstants.AGENT_NAME_HBM_NAME, ecmAgent, MatchMode.START));
            }
            if (!StringUtil.isNullorEmpty(requesterName)) {
                isCriteriaAvailable = true;
                criteria.add(Restrictions.ilike(ECMConstants.ORDER_BY_USER_HBM_NAME, requesterName, MatchMode.ANYWHERE));
            }
            if (!StringUtil.isNullorEmpty(businessOwner)) {
                List<CitiContact> citiContactList = new ArrayList<CitiContact>();
                List<Long> citiContactIdList = new ArrayList<Long>();
                List<CMPRequestContactXref> cmpRequestContactXrefList = new ArrayList<CMPRequestContactXref>();
                List<Long> cmpIdList = new ArrayList<Long>();
                Criteria crit = session.createCriteria(CitiContact.class);
                if (businessOwner.matches(".*\\d.*")) {
                    Criterion soeId = Restrictions.ilike("ssoId", businessOwner, MatchMode.EXACT);
                    crit.add(soeId);
                } else {
                    String[] businessOwnerName = businessOwner.split("\\s+");
                    Criterion firstName = Restrictions.ilike(ECMConstants.FIRST_NAME_HBM_NAME, businessOwnerName[0],
                            MatchMode.ANYWHERE);
                    if (businessOwnerName.length > 1) {
                        String businessOwnerLastName = "";
                        for (int i = 1; i < businessOwnerName.length; i++) {
                            businessOwnerLastName = businessOwnerName[i] + " ";
                        }
                        Criterion lastName = Restrictions.ilike(ECMConstants.LAST_NAME_HBM_NAME,
                                StringUtil.trim(businessOwnerLastName), MatchMode.ANYWHERE);
                        crit.add(Restrictions.and(firstName, lastName));
                    } else {
                        Criterion lastName = Restrictions.ilike(ECMConstants.LAST_NAME_HBM_NAME, businessOwnerName[0],
                                MatchMode.ANYWHERE);
                        crit.add(Restrictions.or(firstName, lastName));
                    }
                }
                citiContactList = crit.list();
                if (citiContactList != null && citiContactList.size() > 0) {
                    for (CitiContact citiContact : citiContactList) {
                        citiContactIdList.add(citiContact.getId());
                    }
                    List<CMPRole> cmpRoleList = new ArrayList<CMPRole>();
                    crit = session.createCriteria(CMPRole.class);
                    Criterion rest1 = Restrictions.ilike(ECMConstants.DISPLAY_NAME_HBM_NAME, "Business Owner");
                    Criterion rest2 = Restrictions
                            .ilike(ECMConstants.DISPLAY_NAME_HBM_NAME, "Secondary Business Owner");
                    crit.add(Restrictions.or(rest1, rest2));
                    cmpRoleList = crit.list();
                    crit = session.createCriteria(CMPRequestContactXref.class);
                    if (CollectionUtils.isNotEmpty(citiContactIdList)) {
                        crit.add(Restrictions.in("citicontact.id", citiContactIdList));
                    }
                    if (CollectionUtils.isNotEmpty(cmpRoleList)) {
                        List<Long> cmpRoleIdList = new ArrayList<Long>();
                        for (CMPRole cmpRole : cmpRoleList) {
                            cmpRoleIdList.add(cmpRole.getId());
                        }
                        crit.add(Restrictions.in("role.id", cmpRoleIdList));
                    }
                    cmpRequestContactXrefList = crit.list();
                    if (cmpRequestContactXrefList != null && cmpRequestContactXrefList.size() > 0) {
                        for (CMPRequestContactXref cmpRequestContactXref : cmpRequestContactXrefList) {
                            cmpIdList.add(cmpRequestContactXref.getCmpId());
                        }
                    }
                    if (cmpIdList.size() > 0) {
                        isCriteriaAvailable = true;
                        criteria.add(Restrictions.in(ECMConstants.CMP_ID_HBM_NAME, cmpIdList));
                    }
                }
            }
            if (!StringUtil.isNullorEmpty(currentStatus)) {
                isCriteriaAvailable = true;
                criteria.add(Restrictions.eq(ECMConstants.CURRENT_STATUS_HBM_NAME, currentStatus).ignoreCase());
            }
            if (!StringUtil.isNullorEmpty(changeId)) {
                isCriteriaAvailable = true;
                criteria.add(Restrictions.ilike(ECMConstants.CHANGE_ID_HBM_NAME, changeId, MatchMode.ANYWHERE));
            }
            if (fromDate != null && toDate != null) {
                isCriteriaAvailable = true;
                // Change this from available date to updated user assigned
                // date.
                criteria.add(Restrictions.between(ECMConstants.UPDATED_ASSIGNED_DATE_HBM_NAME, fromDate, toDate));
            }
            if (!StringUtil.isNullorEmpty(goc)) {
                boolean prefixWildCard = false;
                boolean suffixWildCard = false;
                boolean bothSidesWildCard = false;
                boolean noWildCard = false;
                if (goc.contains(ECMConstants.WILD_CARD_PERCENT)) {
                    goc = goc.replace(ECMConstants.WILD_CARD_PERCENT, ECMConstants.PERCENT);
                }
                if (goc.contains(ECMConstants.WILD_CARD_ASTERISK)) {
                    if (goc.startsWith(ECMConstants.WILD_CARD_ASTERISK)
                            && !(goc.endsWith(ECMConstants.WILD_CARD_ASTERISK))) {
                        prefixWildCard = true;
                    } else if (goc.endsWith(ECMConstants.WILD_CARD_ASTERISK)
                            && !(goc.startsWith(ECMConstants.WILD_CARD_ASTERISK))) {
                        suffixWildCard = true;
                    } else if (goc.startsWith(ECMConstants.WILD_CARD_ASTERISK)
                            && goc.endsWith(ECMConstants.WILD_CARD_ASTERISK)) {
                        bothSidesWildCard = true;
                    }
                    goc = goc.replace(ECMConstants.WILD_CARD_ASTERISK, ECMConstants.EMPTY_STRING);
                } else if (!goc.contains(ECMConstants.WILD_CARD_ASTERISK)) {
                    noWildCard = true;
                }
                Criteria crit = session.createCriteria(CMPRequest.class);
                if (prefixWildCard) {
                    crit.add(Restrictions.ilike(ECMConstants.GOC_CODE_HBM_NAME, goc, MatchMode.END));
                } else if (suffixWildCard) {
                    crit.add(Restrictions.ilike(ECMConstants.GOC_CODE_HBM_NAME, goc, MatchMode.START));
                } else if (bothSidesWildCard) {
                    crit.add(Restrictions.ilike(ECMConstants.GOC_CODE_HBM_NAME, goc, MatchMode.ANYWHERE));
                } else if (noWildCard) {
                    crit.add(Restrictions.eq(ECMConstants.GOC_CODE_HBM_NAME, goc));
                }
                crit.setProjection(Projections.property("id"));
                List<Long> cmpIdList = crit.list();
                if (null != cmpIdList && !cmpIdList.isEmpty()) {
                    isCriteriaAvailable = true;
                    criteria.add(Restrictions.in(ECMConstants.CMP_ID_HBM_NAME, cmpIdList));
                }
            }
            log.info("criteria value in service :: " + criteria.toString() + "isCriteriaAvailable :: "
                    + isCriteriaAvailable);
            if (isCriteriaAvailable) {
                List countList = criteria.list();
                cmpReqIdSearchProcess.setTotalRecords(countList.size());
                if (ECMConstants.ASC.equals(cmpReqIdSearchProcess.getOrderBy())) {
                    criteria.addOrder(Order.asc(sortingColumnName));
                } else {
                    criteria.addOrder(Order.desc(sortingColumnName));
                }
                if (CollectionUtils.isNotEmpty(ecmColumnsOrderSettingsList)) {
                    for (ColumnsSortOrderSettings ecmColumnsOrderSettings : ecmColumnsOrderSettingsList) {
                        if (ecmColumnsOrderSettings.getEcmColumn() != null
                                && !(StringUtil.isNullorEmpty(ecmColumnsOrderSettings.getSortOrder()))) {
                            String orderBy = ecmColumnsOrderSettings.getSortOrder();
                            sortingColumnName = ecmColumnsOrderSettings.getEcmColumn().getUiColumnName();
                            if (!StringUtil.isNullorEmpty(sortingColumnName)) {
                                if (ECMConstants.ASC.equals(orderBy)) {
                                    criteria.addOrder(Order.asc(ECMSearchColumnsMap.get(sortingColumnName)));
                                } else if (ECMConstants.DESC.equals(orderBy)) {
                                    criteria.addOrder(Order.desc(ECMSearchColumnsMap.get(sortingColumnName)));
                                }
                            }
                        }
                    }
                }
                if (!isExport) {
                    criteria.setFirstResult(cmpReqIdSearchProcess.getRecordStartCount());
                    criteria.setMaxResults(cmpReqIdSearchProcess.getRecordEndCount());
                }
                cmpList = criteria.list();
            }
        } catch (Exception e) {
            log.error("Exception while getCMPList " + e.toString(), e);
            throw new ApplicationException("Exception getCMPList ", e);
        }
        log.info("CCRCMPMappingDAOService.getCMPList ends");
        return cmpList;
    }

    /*
     * This method returns Map key is uicolumnName and value is hibernate
     * property
     */
    @Transactional(readOnly = true)
    private Map<String, String> sortingcolumnNameConversion() {
        Map<String, String> columnMap = new LinkedHashMap<>();
        columnMap.put("orderItemId", ECMConstants.ORDER_ITEM_ID_HBM_NAME);
        columnMap.put("assignedUser", ECMConstants.AGENT_NAME_HBM_NAME);
        columnMap.put("dateAssigned", ECMConstants.UPDATED_ASSIGNED_DATE_HBM_NAME);
        columnMap.put("status", ECMConstants.CMP_STATUS_HBM_NAME);
        columnMap.put("currentStatus", ECMConstants.CURRENT_STATUS_HBM_NAME);
        columnMap.put("requestType", ECMConstants.TYPE_OF_CONN_INVOLVED_HBM_NAME);
        columnMap.put("ccrIdWithVerNo", ECMConstants.CCR_ID_HBM_NAME);
        columnMap.put("chgId", ECMConstants.CHANGE_ID_HBM_NAME);
        return columnMap;
    }

    /**
     * Dao method to get Change request ID for tiRequest ID
     * 
     * @param tiRequestId
     * @return
     * @throws Exception
     */
    @Override
    public String getChangeRequestID(Long tiRequestId) throws Exception {
        log.info("CCRCMPMappingDAOService.getChangeRequestID starts");
        Session session = sessionFactory.getCurrentSession();
        String changeRequestId = "";
        try {
            Criteria criteria = session.createCriteria(RFCRequest.class);
            criteria.add(Restrictions.eq("tiRequest.id", tiRequestId));
            List<RFCRequest> rfcRequestList = criteria.list();
            for (RFCRequest rfcRequest : rfcRequestList) {
                if (rfcRequest.getRfcId() != null) {
                    changeRequestId = changeRequestId + rfcRequest.getRfcId() + " ";
                }
            }
        } catch (Exception e) {
            log.error("Exception while getChangeRequestID " + e.toString(), e);
            throw new ApplicationException("Exception getChangeRequestID ", e);
        }
        log.info("CCRCMPMappingDAOService.getChangeRequestID ends");
        return changeRequestId;
    }

    /**
     * Dao method to get Emer Buscrit Questions from DB
     * 
     * @param cmpRequestDirApproval
     * @return
     * @throws Exception
     */
    @Override
    public EmerBuscritQuestionDto getEmerBuscritQuestions(String cmpRequestDirApproval) throws Exception {
        log.info("CCRCMPMappingDAOServiceImpl getEmerBuscritQuestions starts");
        Map<String, String> resultMap = new LinkedHashMap<String, String>();
        EmerBuscritQuestionDto emerBuscritQuestionDto = new EmerBuscritQuestionDto();
        try {
            Session session = sessionFactory.getCurrentSession();
            @SuppressWarnings("unchecked")
            List<EmerBuscritQuestionaries> emerBuscritQuestionariesList = session
                    .createQuery(QueryConstants.GET_EmerBuscritQuestionaries)
                    .setString("orderItemId", cmpRequestDirApproval).list();
            if (emerBuscritQuestionariesList != null && emerBuscritQuestionariesList.size() > 0) {
                emerBuscritQuestionDto.setValidCmp(true);
                for (EmerBuscritQuestionaries emerBuscritQuestionaries : emerBuscritQuestionariesList) {
                    resultMap.put(emerBuscritQuestionaries.getQuestion(), emerBuscritQuestionaries.getAnswer());
                }
                Criteria criteria = session.createCriteria(CMPRequest.class);
                criteria.add(Restrictions.eq("orderItemId", cmpRequestDirApproval));
                List<CMPRequest> cmpRequestList = criteria.list();
                if (cmpRequestList != null && cmpRequestList.size() > 0) {
                    emerBuscritQuestionDto.setMDApprover(cmpRequestList.get(0).getDirectorApprover());
                    emerBuscritQuestionDto.setMDApprovalDate(cmpRequestList.get(0).getDirectorApprovalDate());
                }
                emerBuscritQuestionDto.setEmerBuscritQuestionAnswerMap(resultMap);
            } else {
                emerBuscritQuestionDto.setValidCmp(false);
            }
        } catch (Exception e) {
            log.error("Exception while getCMPRequest " + e.toString(), e);
            throw new ApplicationException("Exception getCMPRequest ", e);
        }
        log.info("CCRCMPMappingDAOServiceImpl getEmerBuscritQuestions ends");
        return emerBuscritQuestionDto;
    }

    /*
     * getDirectorApprovalCmpforTIRequest
     * 
     * @see com.citigroup.cgti.c3par.ccrcmpmapping.dao.service.
     * CCRCMPMappingDAOService #getDirectorApprovalCmpforTIRequest(long)
     */
    @Override
    @Transactional(readOnly = true)
    public String getDirectorApprovalCmpforTIRequest(long tiRequestId) {
        String cmpOrderItems = "";
        List<String> cmpOrderItemList = null;
        String orderItemIdForTiRequestQry = null;
        int count = 0;
        try {
            if (tiRequestId > 0) {
                Object[] params = { tiRequestId };
                orderItemIdForTiRequestQry = ccrQueries
                        .getQueryByName(CCRCMPMappingConstants.TIREQUEST_DIRECTOR_APPROVAL_CMP);
                cmpOrderItemList = jdbcTemplate.query(orderItemIdForTiRequestQry, params, new RowMapper<String>() {
                    public String mapRow(ResultSet rs, int rowNum) throws SQLException {
                        return rs.getString(1);
                    }
                });
                for (String cmpOrderItemId : cmpOrderItemList) {
                    if (count == cmpOrderItemList.size() - 1) {
                        cmpOrderItems = cmpOrderItems + cmpOrderItemId;
                    } else {
                        cmpOrderItems = cmpOrderItems + cmpOrderItemId + ",";
                    }
                    count++;
                }
            }
        } catch (Exception e) {
            log.error("Exception occurred in getDirectorApprovalCmpforTIRequest  : " + e.toString(), e);
        }
        return cmpOrderItems;
    }

    /**
     * Service method to find the lowest date available
     * 
     * @return
     * @throws Exception
     */
    @Override
    public Date getEarliestDate() throws Exception {
        log.info("CCRCMPMappingDAOServiceImpl getEarliestDate starts ");
        Date earliestDate = null;
        Session session = sessionFactory.getCurrentSession();
        try {
            Criteria criteria = session.createCriteria(CmpSearchView.class);
            criteria.setProjection(Projections.min(ECMConstants.AVAILABLE_DATE_HBM_NAME));
            List resultList = criteria.list();
            Iterator iter = resultList.iterator();
            if (!iter.hasNext()) {
                return earliestDate;
            }
            while (iter.hasNext()) {
                earliestDate = (Date) iter.next();
            }
        } catch (Exception e) {
            log.error("Exception while getEarliestDate " + e.toString(), e);
            throw new ApplicationException("Exception getEarliestDate ", e);
        }
        log.info("CCRCMPMappingDAOServiceImpl getEarliestDate ends ");
        return earliestDate;
    }

    /**
     * @param cmpId
     * @return Long
     */
    @Override
    @Transactional(readOnly = true)
    public Long findResentMailAuditId(Long cmpId) {
        Long mailAuditId = null;
        try {
            StringBuilder resentMailAuditQuery = new StringBuilder(
                    " select max(id) as mailAuditId  from TI_MAIL_AUDIT where CMP_ID=" + cmpId);
            resentMailAuditQuery.append("   and TYPE_OF_EMAIL='O' order by id desc");
            SQLQuery query = sessionFactory.getCurrentSession().createSQLQuery(resentMailAuditQuery.toString());
            query.addScalar("mailAuditId", LongType.INSTANCE);
            mailAuditId = (Long) query.uniqueResult();
        } catch (Exception ex) {
            log.error(ex.toString(), ex);
        }
        return mailAuditId;
    }

    /**
     * @param cmpId
     * @return Long
     */
    @Override
    @Transactional(readOnly = true)
    public TIMailAudit findTiMailAudit(Long auditId) {
        TIMailAudit tiMailAudit = null;
        tiMailAudit = (TIMailAudit) sessionFactory.getCurrentSession().get(TIMailAudit.class, auditId);
        return tiMailAudit;

    }

    /**
     * @param auditId
     * @return List<TIMailAuditAttachments>
     */
    @Override
    @Transactional(readOnly = true)
    public List<TIMailAuditAttachments> getEmailAuditTrailAttachments(Long auditId) {
        Session session = sessionFactory.getCurrentSession();

        List<TIMailAuditAttachments> TIMailAuditAttachmentsList = new ArrayList<TIMailAuditAttachments>();
        TIMailAuditAttachmentsList = (List<TIMailAuditAttachments>) session
                .createQuery("from TIMailAuditAttachments auditattachments where auditattachments.tiMailAudit.id = ?)")
                .setLong(0, auditId).list();

        return TIMailAuditAttachmentsList;
    }

    /**
     * @param tiRequestId
     * @return
     */
    @Override
    @Transactional(readOnly = true)
    public Map<String, String> getOrderItemIdStatusMap(String tiRequestId) throws Exception {
        Map<String, String> orderItemIdStatusmap = new HashMap<String, String>();
        String orderItemId = "";
        String taskName = "";
        try {
            List<String> orderItemIdList = new ArrayList<String>();
            List<String> taskNameList = new ArrayList<String>();
            String orderItemIdQuery = "select order_item_id, current_status from cmp_search_view where ti_request_id=?";
            SqlRowSet rs = jdbcTemplate.queryForRowSet(orderItemIdQuery, new Object[] { Long.valueOf(tiRequestId) });
            while (rs.next()) {
                orderItemIdList.add(rs.getString(1));
                taskNameList.add(rs.getString(2));
            }
            if (taskNameList != null && taskNameList.size() > 0) {
                if (taskNameList.contains(CCRCMPMappingConstants.cmpOnHoldStatus)) {
                    int orderItemIdIndex = 0;
                    for (String taskname : taskNameList) {
                        if (taskname.equals(CCRCMPMappingConstants.cmpOnHoldStatus)) {
                            orderItemId += orderItemIdList.get(orderItemIdIndex) + ";";
                            taskName = CCRCMPMappingConstants.cmpOnHoldStatus;
                        }
                        orderItemIdIndex++;
                    }
                } else {
                    taskName = taskNameList.get(0);
                }
            }
            orderItemIdStatusmap.put(orderItemId, taskName);
        } catch (Exception e) {
            log.error("Exception occurred in  getOrderItemId ::" + e.toString());
            log.error(e.toString(), e);
            throw new ApplicationException("Exception has occurred :: getOrderItemId() ", e);
        }
        return orderItemIdStatusmap;
    }

    @Override
    public Long saveCmpComments(CmpRequestDTO cmpRequestDTO) {
        Long id = null;
        try {
            CMPComments cmpComments = new CMPComments();
            cmpComments.setCmpId(cmpRequestDTO.getCmpRequestId());
            cmpComments.setTiRequestId(cmpRequestDTO.getTiRequestId());

            if (cmpRequestDTO.getChooseEmail().equals("CANCEL")) {
                cmpComments.setEcmComments(cmpRequestDTO.getCancelReason());
            } else {
                cmpComments.setEcmComments(cmpRequestDTO.getAddInfo());
                cmpComments.setBusinessJustificationReqInfo(cmpRequestDTO.getBusinessJustificationReqInfo());
                cmpComments.setCitiGrpDataReqInfo(cmpRequestDTO.getCitiGrpDataReqInfo());
                cmpComments.setCustomerDataReqInfo(cmpRequestDTO.getCustomerDataReqInfo());
                cmpComments.setConnectionFreqencyReqInfo(cmpRequestDTO.getConnectionFreqencyReqInfo());
                cmpComments.setGocCodeReqInfo(cmpRequestDTO.getGocCodeReqInfo());
                cmpComments.setTypeOfEntityReqInfo(cmpRequestDTO.getTypeOfEntityReqInfo());
                cmpComments.setDirectAccessReqInfo(cmpRequestDTO.getDirectAccessReqInfo());
                cmpComments.setReasonReqInfo(cmpRequestDTO.getReasonReqInfo());
                cmpComments.setUrgencyReqInfo(cmpRequestDTO.getUrgencyReqInfo());
                cmpComments.setAffectedBusinessReqInfo(cmpRequestDTO.getAffectedBusinessReqInfo());
                cmpComments.setRegionReqInfo(cmpRequestDTO.getRegionReqInfo());
                cmpComments.setSectorReqInfo(cmpRequestDTO.getSectorReqInfo());
                cmpComments.setBusinessUnitReqInfo(cmpRequestDTO.getBusinessUnitReqInfo());
                cmpComments.setCompanyNameReqInfo(cmpRequestDTO.getCompanyNameReqInfo());
                cmpComments.setTptContactNameReqInfo(cmpRequestDTO.getTptContactNameReqInfo());
                cmpComments.setCaspSuppIdReqInfo(cmpRequestDTO.getCaspSuppIdReqInfo());
                cmpComments.setTptContactTypeReqInfo(cmpRequestDTO.getTptContactTypeReqInfo());
                cmpComments.setCaspDetailIdReqInfo(cmpRequestDTO.getCaspDetailIdReqInfo());
                cmpComments.setTptContactPhoneReqInfo(cmpRequestDTO.getTptContactPhoneReqInfo());
                cmpComments.setTptContactEmailReqInfo(cmpRequestDTO.getTptContactEmailReqInfo());
                cmpComments.setReqSSOId(cmpRequestDTO.getReqSSOId());
            }
            cmpComments.setCreatedDate(new Date());
            id = (Long) sessionFactory.getCurrentSession().save(cmpComments);
        } catch (Exception ex) {
            log.error("Exception in saveCmpComments :" + ex);
            log.error(ex.toString(), ex);
        }
        return id;
    }

    @Override
    @Transactional
    public void updateCmpComments(BusinessUserProcess businessUserProcess, CmpRequestDTO cmpRequestDTO) {
        String updateBUCommentsQuery = "";
        int updateCount = 0;
        try {
            if (!StringUtil.isNullorEmpty(businessUserProcess.getAddInfoId())) {
                Object[] params = { businessUserProcess.getAddNote(),
                        businessUserProcess.getBusinessJustificationResponseInfo(),
                        businessUserProcess.getCitiGrpDataResponseInfo(),
                        businessUserProcess.getCustomerDataResponseInfo(),
                        businessUserProcess.getConnectionFreqencyResponseInfo(),
                        businessUserProcess.getGocCodeResponseInfo(),
                        businessUserProcess.getTypeOfEntityResponseInfo(),
                        businessUserProcess.getDirectAccessResponseInfo(), businessUserProcess.getReasonResponseInfo(),
                        businessUserProcess.getUrgencyResponseInfo(),
                        businessUserProcess.getAffectedBusinessResponseInfo(), cmpRequestDTO.getBuSSOId(),
                        businessUserProcess.getRegionResponseInfo(), businessUserProcess.getSectorResponseInfo(),
                        businessUserProcess.getBusinessUnitResponseInfo(),
                        businessUserProcess.getCompanyNameResponseInfo(),
                        businessUserProcess.getTptContactNameResponseInfo(),
                        businessUserProcess.getCaspSuppIdResponseInfo(),
                        businessUserProcess.getTptContactTypeResponseInfo(),
                        businessUserProcess.getCaspDetailIdResponseInfo(),
                        businessUserProcess.getTptContactPhoneResponseInfo(),
                        businessUserProcess.getTptContactEmailResponseInfo(), new Date(),
                        businessUserProcess.getAddInfoId() };
                int[] types = new int[] { Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
                        Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
                        Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR,
                        Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.TIMESTAMP,
                        Types.BIGINT };
                updateBUCommentsQuery = ccrQueries.getQueryByName(CCRCMPMappingConstants.UPDATE_USER_COMMENTS);
                updateCount = jdbcTemplate.update(updateBUCommentsQuery, params, types);
                log.debug("updateCount :" + updateCount);
            }
        } catch (Exception ex) {
            log.error("Exception Occurred in updateCmpComments: " + ex.toString());
            log.error(ex.toString(), ex);
        }
    }

    @Override
    public List<String> getRejectedCcrId(String cmpReqId) {
        List<String> listOfCCRIds = null;
        try {
            Session session = sessionFactory.getCurrentSession();
            String queryFromtheCCRQueriesTable = ccrQueries
                    .getQueryByName(CCRCMPMappingConstants.CCR_REJECTED_IDS_LINKED_TO_CMP);
            SQLQuery query = session.createSQLQuery(queryFromtheCCRQueriesTable);
            query.setParameter("reqId", cmpReqId);
            query.addScalar("ccrId", StringType.INSTANCE);
            listOfCCRIds = query.list();

        } catch (Exception ex) {
            log.error("Exception occurred in logECMActivityTrail: " + ex.toString());
            log.error(ex.toString(), ex);
        }
        return listOfCCRIds;
    }

    @Override
    @Transactional(readOnly = true)
    public QuickSearchProcess finSearchProcessByCcrID(String ccrId) {
        Object[] params = { ccrId };
        String orderItemIdForTiRequestQry = ccrQueries.getQueryByName(CCRCMPMappingConstants.QUICK_SEARCH_BY_CCR);

        List<QuickSearchProcess> quickSearchList = new ArrayList<QuickSearchProcess>();
        quickSearchList = jdbcTemplate.query(orderItemIdForTiRequestQry, params, new RowMapper<QuickSearchProcess>() {
            public QuickSearchProcess mapRow(ResultSet rs, int rowNum) throws SQLException {
                QuickSearchProcess quickSearchProcess = new QuickSearchProcess();
                quickSearchProcess.setTiRequestId(rs.getLong("REQ_ID"));
                quickSearchProcess.setPhase(rs.getString("PHASE"));
                quickSearchProcess.setActivityCode(rs.getString("TASK_CODE"));
                return quickSearchProcess;
            }
        });

        if (!CollectionUtils.isEmpty(quickSearchList)) {
            return quickSearchList.get(0);
        }
        return null;
    }

    @Override
    @Transactional(readOnly = true)
    public String getCcrStatus(String tiRequestID) {
        String status = "";
        List<String> ccrStatusList = null;
        try {
            Session session = sessionFactory.getCurrentSession();
            String ccrStautsQuery = ccrQueries.getQueryByName(CCRCMPMappingConstants.CCR_TASK_STATUS);
            SQLQuery query = session.createSQLQuery(ccrStautsQuery);
            query.setParameter("reqId", tiRequestID);
            query.addScalar("taskname", StringType.INSTANCE);
            ccrStatusList = query.list();
            if (!CollectionUtils.isEmpty(ccrStatusList)) {
                status = (String) ccrStatusList.get(0);
            }
            log.debug("status :"+status);
        } catch (Exception e) {
            log.error("Exception occurred in getCcrStatus : " + e.toString(), e);
        }
        return status;
    }

    /*
     * To display additional Info in audit trail format
     */
    @Override
    @Transactional(readOnly = true)
    public EmailGenerationViewProcess getECMReqInfo(EmailGenerationViewProcess emailGenerationViewProcess) {
        log.debug("getECMReqInfo starts : emailGenerationViewProcess.getCmpRequest().getId() :"
                + emailGenerationViewProcess.getCmpRequest().getId());
        String ecmReqInfoQry = null;
        String ecmReqInfoTempQry = null;
        try {

            List<String> cmpAddInfoColumnList = CCRCMPMappingConstants.CMP_ADD_INFORMATION_COLUMN_LIST;
            ecmReqInfoQry = ccrQueries.getQueryByName(CCRCMPMappingConstants.GET_ECM_REQUEST_INFO);
            for (String columnName : cmpAddInfoColumnList) {
                List<CmpRequestDTO> resultList = new ArrayList<CmpRequestDTO>();
                ecmReqInfoTempQry = ecmReqInfoQry;
                if (columnName.equals("BUS_JUS")) {
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":REQ_COLUMN_NAME", "BJ_REQ_INFO");
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":RES_COLUMN_NAME", "BJ_BU_RESPONSE");
                } else if (columnName.equals("CIT_GRP_DATA")) {
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":REQ_COLUMN_NAME", "CITI_GRP_DATA_REQ_INFO");
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":RES_COLUMN_NAME", "CITI_GRP_DATA_BU_RESPONSE");
                } else if (columnName.equals("CUSTOMER_DATA")) {
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":REQ_COLUMN_NAME", "CUST_DATA_REQ_INFO");
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":RES_COLUMN_NAME", "CUST_DATA_BU_RESPONSE");
                } else if (columnName.equals("CONNECTIVITY_FREQUENCY")) {
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":REQ_COLUMN_NAME", "CON_FREQ_REQ_INFO");
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":RES_COLUMN_NAME", "CON_FREQ_BU_RESPONSE");
                } else if (columnName.equals("GOC_CODE")) {
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":REQ_COLUMN_NAME", "GOC_CODE_REQ_INFO");
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":RES_COLUMN_NAME", "GOC_CODE_BU_RESPONSE");
                } else if (columnName.equals("TYPE_OF_ENTITY")) {
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":REQ_COLUMN_NAME", "TYPE_OF_ENTITY_REQ_INFO");
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":RES_COLUMN_NAME", "TYPE_OF_ENTITY_BU_RESPONSE");
                } else if (columnName.equals("DIRECT_ACCESS")) {
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":REQ_COLUMN_NAME", "DIRECT_ACCESS_REQ_INFO");
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":RES_COLUMN_NAME", "DIRECT_ACCESS_BU_RESPONSE");
                } else if (columnName.equals("REASON")) {
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":REQ_COLUMN_NAME", "REASON_REQ_INFO");
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":RES_COLUMN_NAME", "REASON_BU_RESPONSE");
                } else if (columnName.equals("URGENCY")) {
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":REQ_COLUMN_NAME", "URGENCY_REQ_INFO");
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":RES_COLUMN_NAME", "URGENCY_BU_RESPONSE");
                } else if (columnName.equals("AFFECTED_BUSINESS")) {
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":REQ_COLUMN_NAME", "AFFECTED_BUSS_REQ_INFO");
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":RES_COLUMN_NAME", "AFFECTED_BUSS_BU_RESPONSE");
                } else if (columnName.equals("REGION")) {
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":REQ_COLUMN_NAME", "REGION_REQ_INFO");
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":RES_COLUMN_NAME", "REGION_BU_RESPONSE");
                } else if (columnName.equals("SECTOR")) {
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":REQ_COLUMN_NAME", "SECTOR_REQ_INFO");
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":RES_COLUMN_NAME", "SECTOR_BU_RESPONSE");
                } else if (columnName.equals("BUSINESS_UNIT")) {
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":REQ_COLUMN_NAME", "BUSS_UNIT_REQ_INFO");
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":RES_COLUMN_NAME", "BUSS_UNIT_BU_RESPONSE");
                } else if (columnName.equals("COMPANY_NAME")) {
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":REQ_COLUMN_NAME", "COMPANY_NAME_REQ_INFO");
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":RES_COLUMN_NAME", "COMPANY_NAME_BU_RESPONSE");
                } else if (columnName.equals("TPT_CONTACT_NAME")) {
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":REQ_COLUMN_NAME", "TPT_CONTACT_NAME_REQ_INFO");
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":RES_COLUMN_NAME", "TPT_CONTACT_NAME_BU_RESPONSE");
                } else if (columnName.equals("CASP_SUPP_ID")) {
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":REQ_COLUMN_NAME", "CASP_SUPP_ID_REQ_INFO");
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":RES_COLUMN_NAME", "CASP_SUPP_ID_BU_RESPONSE");
                } else if (columnName.equals("TPT_CONTACT_TYPE")) {
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":REQ_COLUMN_NAME", "TPT_CONTACT_TYPE_REQ_INFO");
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":RES_COLUMN_NAME", "TPT_CONTACT_TYPE_BU_RESPONSE");
                } else if (columnName.equals("CASP_DETAIL_ID")) {
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":REQ_COLUMN_NAME", "CASP_DET_ID_REQ_INFO");
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":RES_COLUMN_NAME", "CASP_DET_ID_BU_RESPONSE");
                } else if (columnName.equals("TPT_CONTACT_PHONE")) {
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":REQ_COLUMN_NAME", "TPT_CONTACT_PHONE_REQ_INFO");
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":RES_COLUMN_NAME", "TPT_CONTACT_PHONE_BU_RESPONSE");
                } else if (columnName.equals("TPT_CONTACT_EMAIL")) {
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":REQ_COLUMN_NAME", "TPT_CONTACT_EMAIL_REQ_INFO");
                    ecmReqInfoTempQry = ecmReqInfoTempQry.replace(":RES_COLUMN_NAME", "TPT_CONTACT_EMAIL_BU_RESPONSE");
                }

                Object[] params = { emailGenerationViewProcess.getCmpRequest().getId(),
                        emailGenerationViewProcess.getCmpRequest().getId() };
                resultList = jdbcTemplate.query(ecmReqInfoTempQry, params, new RowMapper<CmpRequestDTO>() {
                    public CmpRequestDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
                        CmpRequestDTO cmpRequestDTO = new CmpRequestDTO();
                        cmpRequestDTO.setReqInfoCreatedDate(rs.getString("CREATED_DATE"));
                        cmpRequestDTO.setReqInfoParticipant(rs.getString("PARTICIPANT"));
                        cmpRequestDTO.setReqInfo(rs.getString("INFORMATION"));
                        return cmpRequestDTO;
                    }
                });
                if (columnName.equals("BUS_JUS")) {
                    emailGenerationViewProcess.setBjReqInfoList(resultList);
                } else if (columnName.equals("CIT_GRP_DATA")) {
                    emailGenerationViewProcess.setCitiGrpDataReqInfoList(resultList);
                } else if (columnName.equals("CUSTOMER_DATA")) {
                    emailGenerationViewProcess.setCustomerDataReqInfoList(resultList);
                } else if (columnName.equals("CONNECTIVITY_FREQUENCY")) {
                    emailGenerationViewProcess.setConnectivityFrequencyReqInfoList(resultList);
                } else if (columnName.equals("GOC_CODE")) {
                    emailGenerationViewProcess.setGocCodeReqInfoList(resultList);
                } else if (columnName.equals("TYPE_OF_ENTITY")) {
                    emailGenerationViewProcess.setTypeOfEntityReqInfoList(resultList);
                } else if (columnName.equals("DIRECT_ACCESS")) {
                    emailGenerationViewProcess.setDirectAccessReqInfoList(resultList);
                } else if (columnName.equals("REASON")) {
                    emailGenerationViewProcess.setReasonReqInfoList(resultList);
                } else if (columnName.equals("URGENCY")) {
                    emailGenerationViewProcess.setUrgencyReqInfoList(resultList);
                } else if (columnName.equals("AFFECTED_BUSINESS")) {
                    emailGenerationViewProcess.setAffectedBusinessReqInfoList(resultList);
                } else if (columnName.equals("REGION")) {
                    emailGenerationViewProcess.setRegionReqInfoList(resultList);
                } else if (columnName.equals("SECTOR")) {
                    emailGenerationViewProcess.setSectorReqInfoList(resultList);
                } else if (columnName.equals("BUSINESS_UNIT")) {
                    emailGenerationViewProcess.setBusinessUnitReqInfoList(resultList);
                } else if (columnName.equals("COMPANY_NAME")) {
                    emailGenerationViewProcess.setCompanyNameReqInfoList(resultList);
                } else if (columnName.equals("TPT_CONTACT_NAME")) {
                    emailGenerationViewProcess.setTptContactNameReqInfoList(resultList);
                } else if (columnName.equals("CASP_SUPP_ID")) {
                    emailGenerationViewProcess.setCaspSuppIdReqInfoList(resultList);
                } else if (columnName.equals("TPT_CONTACT_TYPE")) {
                    emailGenerationViewProcess.setTptContactTypeReqInfoList(resultList);
                } else if (columnName.equals("CASP_DETAIL_ID")) {
                    emailGenerationViewProcess.setCaspDetailIdReqInfoList(resultList);
                } else if (columnName.equals("TPT_CONTACT_PHONE")) {
                    emailGenerationViewProcess.setTptContactPhoneReqInfoList(resultList);
                } else if (columnName.equals("TPT_CONTACT_EMAIL")) {
                    emailGenerationViewProcess.setTptContactEmailReqInfoList(resultList);
                }
            }
        } catch (Exception ex) {
            log.error("Exception in getECMReqInfo :" + ex);
            log.error(ex.toString(), ex);
        }
        log.debug("getECMReqInfo ends");
        return emailGenerationViewProcess;
    }

    /*
     * To load the values from CMP Comments and to store in BusinessUserProcess
     * VO
     */
    @Override
    @Transactional(readOnly = true)
    public BusinessUserProcess getECMCommentsInfo(BusinessUserProcess businessUserProcess) {
        log.debug("AddInfoId :" + businessUserProcess.getAddInfoId());
        SqlRowSet rs = null;
        CMPComments cmpComments = null;
        try {
            Session session = sessionFactory.getCurrentSession();
            Criteria crit = session.createCriteria(CMPComments.class);
            crit.add(Restrictions.eq("id",
                    (businessUserProcess.getAddInfoId() == null || "".equals(businessUserProcess.getAddInfoId()) ? 0
                            : (Long.valueOf(businessUserProcess.getAddInfoId())))));
            List<CMPComments> list = crit.list();
            if (list != null && list.size() > 0) {
                cmpComments = (CMPComments) list.get(0);
                businessUserProcess.setBusinessJustificationReqInfo(cmpComments.getBusinessJustificationReqInfo());
                businessUserProcess.setCitiGrpDataReqInfo(cmpComments.getCitiGrpDataReqInfo());
                businessUserProcess.setCustomerDataReqInfo(cmpComments.getCustomerDataReqInfo());
                businessUserProcess.setConnectionFreqencyReqInfo(cmpComments.getConnectionFreqencyReqInfo());
                businessUserProcess.setGocCodeReqInfo(cmpComments.getGocCodeReqInfo());
                businessUserProcess.setTypeOfEntityReqInfo(cmpComments.getTypeOfEntityReqInfo());
                businessUserProcess.setDirectAccessReqInfo(cmpComments.getDirectAccessReqInfo());
                businessUserProcess.setReasonReqInfo(cmpComments.getReasonReqInfo());
                businessUserProcess.setUrgencyReqInfo(cmpComments.getUrgencyReqInfo());
                businessUserProcess.setAffectedBusinessReqInfo(cmpComments.getAffectedBusinessReqInfo());
                businessUserProcess.setRegionReqInfo(cmpComments.getRegionReqInfo());
                businessUserProcess.setSectorReqInfo(cmpComments.getSectorReqInfo());
                businessUserProcess.setBusinessUnitReqInfo(cmpComments.getBusinessUnitReqInfo());
                businessUserProcess.setCompanyNameReqInfo(cmpComments.getCompanyNameReqInfo());
                businessUserProcess.setTptContactNameReqInfo(cmpComments.getTptContactNameReqInfo());
                businessUserProcess.setCaspSuppIdReqInfo(cmpComments.getCaspSuppIdReqInfo());
                businessUserProcess.setTptContactTypeReqInfo(cmpComments.getTptContactTypeReqInfo());
                businessUserProcess.setCaspDetailIdReqInfo(cmpComments.getCaspDetailIdReqInfo());
                businessUserProcess.setTptContactPhoneReqInfo(cmpComments.getTptContactPhoneReqInfo());
                businessUserProcess.setTptContactEmailReqInfo(cmpComments.getTptContactEmailReqInfo());
            }
        } catch (Exception ex) {
            log.error("Exception in getECMCommentsInfo :" + ex);
            log.error(ex.toString(), ex);
        }
        log.debug("getECMCommentsInfo ends");
        return businessUserProcess;
    }

    /*
     * To get SectorName for Sector Id.
     */
    @Override
    @Transactional(readOnly = true)
    public String getSectorName(String sectorId) {
        log.debug("sectorId :" + sectorId);
        String sectorName = "";
        String sectorQuery = "";
        SqlRowSet rs = null;
        try {
            Object[] params = { sectorId };
            sectorQuery = ccrQueries.getQueryByName(CCRCMPMappingConstants.GET_SECTOR_NAME);
            rs = jdbcTemplate.queryForRowSet(sectorQuery, params);
            if (rs.next()) {
                sectorName = rs.getString(1);
            }
            log.debug("sectorName :" + sectorName);
        } catch (Exception ex) {
            log.error("Exception in getSectorName :" + ex);
            log.error(ex.toString(), ex);
        }
        return sectorName;
    }

    /*
     * To get BusinessUnit Name for BusinessUnit Id.
     */
    @Override
    @Transactional(readOnly = true)
    public String getBusinessUnitName(String businessUnitId) {
        log.debug("businessUnitId :" + businessUnitId);
        String businessUnitName = "";
        String businessUnitQuery = "";
        SqlRowSet rs = null;
        try {
            Object[] params = { businessUnitId };
            businessUnitQuery = ccrQueries.getQueryByName(CCRCMPMappingConstants.GET_BUSINESS_UNIT_NAME);
            rs = jdbcTemplate.queryForRowSet(businessUnitQuery, params);
            if (rs.next()) {
                businessUnitName = rs.getString(1);
            }
            log.debug("businessUnitName :" + businessUnitName);
        } catch (Exception ex) {
            log.error("Exception in getBusinessUnitName :" + ex);
            log.error(ex.toString(), ex);
        }
        return businessUnitName;
    }

    /*
     * To findCmpCommentsByMailAuditId
     */
    @Override
    @Transactional(readOnly = true)
    public CMPComments findCmpCommentsByMailAuditId(Long auditId) {
        CMPComments cmpComments = null;
        try {

            Session session = sessionFactory.getCurrentSession();
            Criteria crit = session.createCriteria(CMPComments.class);
            crit.add(Restrictions.eq(MAIl_AUDIT_ID, auditId));
            List<CMPComments> cmpCommentsList = crit.list();
            if (cmpCommentsList != null) {
                cmpComments = cmpCommentsList.get(0);
            }
        }

        catch (Exception ex) {
            log.error(ex.toString(), ex);
        }
        return cmpComments;

    }

	/**
	 * @param tiRequestId
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Long getCmpIdForTiRequestId(Long tiRequestId) {
		log.debug("getCmpIdForTiRequestId starts");
		Long cmpId = 0L;
		List<Long> cmpIdList = new ArrayList<Long>();
		try {
			Session session = sessionFactory.getCurrentSession();
			String cmpIdForTiRequestIdQuery = ccrQueries.getQueryByName(CCRCMPMappingConstants.GET_CMPID_FOR_TIREQUESTID); 
			SQLQuery query = session.createSQLQuery(cmpIdForTiRequestIdQuery);
			query.setParameter("tiRequestId", tiRequestId);
			query.addScalar("cmpId", LongType.INSTANCE);
			cmpIdList = query.list();
			if (CollectionUtils.isNotEmpty(cmpIdList)) {
				cmpId = (Long) cmpIdList.get(0);
			}
		} catch (Exception ex) {
			log.error("Exception in getCmpIdForTiRequestId :" + ex);
			log.error(ex.toString(), ex);
		}
		return cmpId;
	}
}