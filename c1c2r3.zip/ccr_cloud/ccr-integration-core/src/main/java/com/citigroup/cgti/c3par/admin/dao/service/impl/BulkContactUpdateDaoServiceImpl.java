/**
 * 
 */
package com.citigroup.cgti.c3par.admin.dao.service.impl;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.admin.dao.service.BulkContactUpdateDaoService;
import com.citigroup.cgti.c3par.admin.domain.BulkContactUpdateDTO;
import com.citigroup.cgti.c3par.businessjustification.domain.ConReqCitiContactXref;
import com.citigroup.cgti.c3par.businessjustification.domain.ConReqCitiReqConXref;
import com.citigroup.cgti.c3par.common.domain.AuditLog;
import com.citigroup.cgti.c3par.common.domain.AuditObjectType;
import com.citigroup.cgti.c3par.common.domain.HistoryContact;
import com.citigroup.cgti.c3par.configuation.QueryConstants;
import com.citigroup.cgti.c3par.domain.Role;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;

/**
 * @author ka58098
 * 
 */
@Repository
@Transactional
public class BulkContactUpdateDaoServiceImpl extends BasePersistanceImpl implements BulkContactUpdateDaoService {
    private static final Logger log = Logger.getLogger(BulkContactUpdateDaoServiceImpl.class.getName());

    @Autowired
    private SessionFactory sessionFactory;

    @Autowired
    @Qualifier("jdbcTemplate_ccr")
    private JdbcTemplate jdbcTemplate;

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    /**
     * @param jdbcTemplate
     *            the jdbcTemplate to set
     */
    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /*
     * @Override public List<BulkContactUpdateDTO> getSearchDetails(String
     * ssoId, Long roleId) { log.info("Entering :: ssoId =" + ssoId +
     * " role :: " + roleId); try { Session session =
     * sessionFactory.getCurrentSession();
     * 
     * Criteria criteria = session.createCriteria(ConReqCitiContactXref.class);
     * criteria.createAlias("role", "role");
     * criteria.add(Restrictions.eq("role.id", roleId));
     * criteria.createAlias("citicontact", "citicontact");
     * criteria.add(Restrictions.eq("citicontact.ssoId", ssoId).ignoreCase());
     * log.info("Search criteria query ::" + criteria.toString()); //
     * session.createQuery(queryString)
     * 
     * } catch (Exception e) { log.error(
     * "Error has occurred while tring to search contact details::" +
     * e.toString()); } log.info("Exiting ::"); return null; }
     */

    @Transactional(readOnly = true)
    public String getProcessName(Long processId) {
        String processName = new String();
        try {
            SQLQuery query = sessionFactory.getCurrentSession().createSQLQuery(
                    "select process_name processName from c3par.ti_process where id=" + processId.longValue());
            query.addScalar("processName", StringType.INSTANCE);
            processName = (String) query.uniqueResult();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        log.debug("for ProcessId " + processId + " Process name is " + processName);
        return processName;
    }

    private List<Long> getCcrIdforPlanningId(Long planningId) {
        List<Long> ccrIdList = new ArrayList<Long>();
        Set<Long> ccrIdSet = new HashSet<Long>();
        StringBuilder query = new StringBuilder();
        query.append(
                "select process_id from ti_request where id in (select ti_request_id from ti_request_planning_xref where planning_id = ");
        query.append(planningId);
        query.append(")");
        SqlRowSet result = null;
        try {
            result = jdbcTemplate.queryForRowSet(query.toString());
            int count = 1;
            while (result.next()) {
                ccrIdSet.add(result.getLong(1));
                log.debug(count + " Record added in ccrIdSet for planningId " + planningId);
                count++;
            }
            if (ccrIdSet.isEmpty()) {
                log.debug("No Records Found...");
            } else {
                log.debug("No. of Records Found are..." + ccrIdSet.size());
            }
        } catch (Exception e) {
            log.error(e, e);
        }

        ccrIdList.addAll(ccrIdSet);
        return ccrIdList;
    }

    @Override
    public List<ConReqCitiContactXref> getConReqCitiContact(String ssoId, Long roleId) {
        log.info("Entering :: ssoId =" + ssoId + " role :: " + roleId);
        List<ConReqCitiContactXref> resultList = null;
        try {
            Session session = sessionFactory.getCurrentSession();
            SQLQuery query = session.createSQLQuery(QueryConstants.GET_CITICONTXREF);
            query.setString("ssoId", ssoId);
            query.setLong("roleId", roleId);
            query.addEntity("b_conxref", ConReqCitiContactXref.class);
            log.info("getConReqCitiContact query value ::" + query.toString());
            resultList = query.list();
            log.info("getConReqCitiContact resultList size value is :: " + resultList.size());
        } catch (Exception e) {
            log.error("Error has occurred while tring to getConReqCitiContact details::" + e.toString());
        }
        log.info("Exiting ::");
        return resultList;
    }

    @Override
    public List<ConReqCitiReqConXref> getConReqCitiReqConXref(String ssoId, Long roleId) {
        log.info("Entering :: ssoId =" + ssoId + " role :: " + roleId);
        List<ConReqCitiReqConXref> resultList = null;
        try {
            Session session = sessionFactory.getCurrentSession();
            SQLQuery query = session.createSQLQuery(QueryConstants.GET_CITIREQCONTXREF);
            query.setString("ssoId", ssoId);
            query.setLong("roleId", roleId);
            query.addEntity("b_conxref", ConReqCitiReqConXref.class);
            log.info("getConReqCitiContact query value ::" + query.toString());
            resultList = query.list();
            log.info("getConReqCitiContact resultList size value is :: " + resultList.size());
        } catch (Exception e) {
            log.error("Error has occurred while tring to getConReqCitiContact details::" + e.toString());
        }
        log.info("Exiting ::");
        return resultList;
    }

    @Override
    public String getContactNameForSsoId(String ssoId) {
        Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;
        String firstName = new String();
        String lastName = new String();
        C3parSession dbsession = new C3parSession();
        try {
            StringBuffer str = new StringBuffer(
                    "select first_name, last_name from c3par_users where upper(sso_id) = upper('" + ssoId + "')");
            log.debug("BulkContactUpdate DAO Impl::getContactNameForSsoId::str==>" + str.toString());
            con = dbsession.getConnection();
            stmt = con.createStatement();
            rs = stmt.executeQuery(str.toString());
            if (rs != null && rs.next()) {
                firstName = rs.getString(1);
                lastName = rs.getString(2);

            }
        } catch (SQLException e) {
            log.error(e);
        } catch (Exception e) {
            log.error(e);
        } finally {
            try {
                if (rs != null)
                    rs.close();
                if (stmt != null)
                    stmt.close();
                if (con != null)
                    con.close();
            } catch (SQLException e) {
                log.error(e);
            }

        }
        return firstName + " " + lastName;
    }

    @Override
    public TIRequest getTiRequest(Long planningId) {
        log.info("Entering ::");
        List<TIRequest> resultList = null;
        List requestList = null;
        Long tiRequestId = null;
        try {
            Session session = sessionFactory.getCurrentSession();
            SQLQuery sqlQuery = session.createSQLQuery(QueryConstants.GET_TIREQUESTID);
            sqlQuery.setLong("planningId", planningId);
            sqlQuery.addScalar("tiRequestId", LongType.INSTANCE);
            requestList = sqlQuery.list();
            if (!CollectionUtils.isEmpty(requestList)) {
                tiRequestId = (Long) requestList.get(0);
                Query query = session.createQuery(QueryConstants.TI_REQUEST);
                query.setLong("planningId", tiRequestId);
                resultList = query.list();
                if (!CollectionUtils.isEmpty(resultList)) {
                    TIRequest tiRequest = (TIRequest) resultList.get(0);
                    return tiRequest;
                }
            }
        } catch (Exception e) {
            log.error("Error has occurred in getTiProcess method ::" + e);

        }
        log.info("Exiting ::");
        return null;
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    @Override
    public boolean updateContactDetails(List<BulkContactUpdateDTO> bulkContactUpdateDTOList) {
        try {
            HibernateTemplate session = getHibernateTemplate();
            for (BulkContactUpdateDTO bulkContactUpdateDTO : bulkContactUpdateDTOList) {
                if (bulkContactUpdateDTO.getIsChecked().equals(BulContactUpdateConstants.CONTACT_SELECTED)) {
                    long citiContactid = bulkContactUpdateDTO.getCitiContactId();
                    ConReqCitiContactXref conReqCitiContactXref = (ConReqCitiContactXref) session
                            .load(ConReqCitiContactXref.class, citiContactid);
                    switch (bulkContactUpdateDTO.getAction()) {
                        case BulContactUpdateConstants.PRIMARY_YES:
                            conReqCitiContactXref.setPrimaryContact("Y");
                            break;
                        case BulContactUpdateConstants.PRIMARY_NO:
                            conReqCitiContactXref.setPrimaryContact("N");
                            break;
                        case BulContactUpdateConstants.NOTIFY_YES:
                            conReqCitiContactXref.setNotifyContact("Y");
                            break;

                        case BulContactUpdateConstants.NOTIFY_NO:
                            conReqCitiContactXref.setNotifyContact("N");
                            break;

                    }
                    session.update(conReqCitiContactXref);
                    String objectName = "con_req_citi_contact_xref";
                    TIRequest tiRequest = new TIRequest();
                    tiRequest.setId(bulkContactUpdateDTO.getTiRequestId());
                    AuditLog auditLog = new AuditLog();
                    auditLog.setSoeID(bulkContactUpdateDTO.getSsoId());// Soe
                                                                       // and
                                                                       // sso
                                                                       // same
                                                                       // need
                                                                       // to
                                                                       // Check
                    auditLog.setCreated_date(new Date());
                    auditLog.setObjectName("Connection");
                    auditLog.setObjectAttribute("Contact");
                    auditLog.setNewValue(String.valueOf(citiContactid));
                    auditLog.setNewDisplayValue(bulkContactUpdateDTO.getSsoId());
                    auditLog.setNewAuditObjectType(getAuditObjectType(objectName));
                    auditLog.setAction("Update");
                    auditLog.setOldValue(String.valueOf(citiContactid));
                    auditLog.setOldDisplayValue(bulkContactUpdateDTO.getSsoId());
                    auditLog.setOldAuditObjectType(getAuditObjectType(objectName));
                    auditLog.setTiRequest(tiRequest);
                    auditLog.setIsReference("Y");
                    session.save(auditLog);
                }

            }
            return true;
        } catch (Exception exp) {
            log.error("Error has occurred in updateContactDetails method ::");
            return false;
        }
    }

    /*
     * @Override public List<Role> getRoleList(String[] params) { List<Role>
     * resultList = null; try { Session session =
     * sessionFactory.getCurrentSession(); Criteria criteria =
     * session.createCriteria(Role.class); criteria.add(Restrictions.in("name",
     * params)); resultList = criteria.list(); log.info(" resultList size ::" +
     * resultList.size()); } catch (Exception e) { log.error(
     * "Error has occurred in getRoleList method ::" + e.getMessage()); } return
     * resultList;
     * 
     * }
     */

    @Override
    public void updateContact(BulkContactUpdateDTO bulkContactUpdateDTO, List<Long> ccrIdList,
            List<String> contactTypeList, List<Long> citiContactIdList,final Long citiContactId, String roleName, String newRoleName,
            final Long replaceCitiContactId) {
        final Long roleId = Long.parseLong(roleName);
        final Long newRoleId = Long.parseLong(newRoleName);
        Map<Long,String> map=new HashMap<Long,String>();
        Map<Long,String> planningIdmap=new HashMap<Long,String>();
        int counter = 0;
        for(Long ccrId:ccrIdList){
            map.put(ccrId, contactTypeList.get(counter));
            counter++;
        }
        List<Long> planningIdList = getPlanningIdList(ccrIdList,map,planningIdmap);
        String sqlQuery = "";
        Long con_req_cit_rqcon_xref_id=0L;
        String sqlQueryReq = "update c3par.con_req_cit_rqcon_xref SET CITI_CONTACT_ID = ?, ROLE_ID= ? WHERE CITI_CONTACT_ID = ? and REQUEST_ID= ? and ROLE_ID= ?";
        String sqlQueryTarget = "update c3par.con_req_citi_contact_xref SET CITI_CONTACT_ID = ?, ROLE_ID= ? WHERE CITI_CONTACT_ID = ? and REQUEST_ID= ? and ROLE_ID= ?";
        for (Long planningId : planningIdList) {
            final Long planningID = planningId;
            String contactType=planningIdmap.get(planningID);
            log.debug("Inside update Contact loop");
            if (contactType.equalsIgnoreCase("requestor")) {
                sqlQuery = sqlQueryReq;
            } else {
                sqlQuery = sqlQueryTarget;
            }
            con_req_cit_rqcon_xref_id = getConReqCitiRqconXrefId(citiContactId, planningID, roleId,contactType);
            Long ti_request_id = getTiRequestIdForPlanningId(planningID);
            if(con_req_cit_rqcon_xref_id!=null && con_req_cit_rqcon_xref_id!=0){
                auditContactUpdate(bulkContactUpdateDTO, con_req_cit_rqcon_xref_id, ti_request_id,contactType,citiContactId);    
            }
            jdbcTemplate.update(sqlQuery, new PreparedStatementSetter() {
                public void setValues(PreparedStatement ps) throws SQLException {
                    ps.setLong(1, replaceCitiContactId);
                    ps.setLong(2, newRoleId);
                    ps.setLong(3, citiContactId);
                    ps.setLong(4, planningID);
                    ps.setLong(5, roleId);

                }
            });
        }

    }

    private Long getConReqCitiRqconXrefId(Long citiContactId, Long planningID, Long roleId, String contactType) {

        List<Long> IdList = new ArrayList<Long>();
        Long Id = 0L;
        StringBuilder sqlQuery=new StringBuilder();
        if(contactType.equalsIgnoreCase("requestor")){
            sqlQuery.append("SELECT ID FROM c3par.con_req_cit_rqcon_xref WHERE CITI_CONTACT_ID = ").append(citiContactId).append(" and REQUEST_ID= ")
            .append(planningID).append(" and ROLE_ID= ").append(roleId);
        }
        else{
            sqlQuery.append("SELECT ID FROM c3par.con_req_citi_contact_xref WHERE CITI_CONTACT_ID = ").append(citiContactId).append(" and REQUEST_ID= ")
            .append(planningID).append(" and ROLE_ID= ").append(roleId);
        }
        log.debug("The query is "+sqlQuery.toString());
        SqlRowSet rs = getJdbcTemplate().queryForRowSet(sqlQuery.toString());

        if (rs.next()) {
            IdList.add(rs.getLong(1));
        }
        if (IdList != null && !IdList.isEmpty()) {
            Id = IdList.get(0);
        }
        log.debug("The ID is "+Id);
        return Id;
    }

    private void auditContactUpdate(BulkContactUpdateDTO bulkContactUpdateDTO, Long con_req_cit_rqcon_xref_id,
            Long ti_request_id,String contactType, Long citiContactId) {

        AuditLog auditLog = new AuditLog();
        String objectName=new String();
        Long HistoryContactId=0L;
        if(contactType.equalsIgnoreCase("requestor")){
            objectName="con_req_cit_rqcon_xref";
            ConReqCitiReqConXref conReqCitiReqConXref=(ConReqCitiReqConXref) sessionFactory.getCurrentSession()
                    .load(ConReqCitiReqConXref.class, con_req_cit_rqcon_xref_id);
            HistoryContact HistoryConCitiContact = new HistoryContact();
            HistoryConCitiContact.setCreated_date(new Date());
            HistoryConCitiContact.setContactId(conReqCitiReqConXref.getCiticontact().getId());
            HistoryConCitiContact.setSoeId(conReqCitiReqConXref.getCiticontact().getSsoId());
            HistoryConCitiContact.setRoleId(conReqCitiReqConXref.getRole().getId());
            HistoryConCitiContact.setNotifyContact(conReqCitiReqConXref.getNotifyContact());
            HistoryConCitiContact.setPrimaryContact(conReqCitiReqConXref.getPrimaryContact());
            HistoryConCitiContact.setSystemGenerated(conReqCitiReqConXref.getSystemGenerated());
            HistoryContactId = (Long) sessionFactory.getCurrentSession().save(HistoryConCitiContact);
        }
        else{
            objectName="con_req_citi_contact_xref";
            ConReqCitiContactXref conReqCitiContactXref = (ConReqCitiContactXref) sessionFactory.getCurrentSession()
                    .load(ConReqCitiContactXref.class, con_req_cit_rqcon_xref_id);
            HistoryContact HistoryConCitiContact = new HistoryContact();
            HistoryConCitiContact.setCreated_date(new Date());
            HistoryConCitiContact.setContactId(conReqCitiContactXref.getCiticontact().getId());
            HistoryConCitiContact.setSoeId(conReqCitiContactXref.getCiticontact().getSsoId());
            HistoryConCitiContact.setRoleId(conReqCitiContactXref.getRole().getId());
            HistoryConCitiContact.setNotifyContact(conReqCitiContactXref.getNotifyContact());
            HistoryConCitiContact.setPrimaryContact(conReqCitiContactXref.getPrimaryContact());
            HistoryConCitiContact.setSystemGenerated(conReqCitiContactXref.getSystemGenerated());
            HistoryContactId = (Long) sessionFactory.getCurrentSession().save(HistoryConCitiContact);
        }
       
     

        auditLog.setSoeID(bulkContactUpdateDTO.getUserSsoId());// Soe and sso same need to Check
        auditLog.setCreated_date(new Date());
        auditLog.setObjectName("Connection");
        auditLog.setObjectAttribute("Contact");
        auditLog.setNewValue(con_req_cit_rqcon_xref_id.toString());
        auditLog.setNewDisplayValue(bulkContactUpdateDTO.getReplaceSsoId().toUpperCase());
        auditLog.setNewAuditObjectType(getAuditObjectType(objectName));
        auditLog.setAction("Update");
        auditLog.setOldValue(HistoryContactId.toString());
        auditLog.setOldDisplayValue(bulkContactUpdateDTO.getSsoId().toUpperCase());
        auditLog.setOldAuditObjectType(getAuditObjectType(objectName));
        auditLog.setTiRequest(getTIRequest(ti_request_id));
        auditLog.setIsReference("Y");
        sessionFactory.getCurrentSession().save(auditLog);
    }

    private AuditObjectType getAuditObjectType(String objectName) {

        AuditObjectType auditObjectType = null;
        List<AuditObjectType> auditObjectTypes = (List<AuditObjectType>) sessionFactory.getCurrentSession()
                .createQuery(" from AuditObjectType where objectName = '" + objectName + "'").list();

        if (auditObjectTypes != null && !auditObjectTypes.isEmpty()) {
            auditObjectType = auditObjectTypes.get(0);
        }
        return auditObjectType;

    }

    private List<Long> getPlanningIdList(List<Long> ccrIdList, Map<Long, String> ccrIdMap, Map<Long, String> planningIdMap) {
        List<Long> planningIdList = new ArrayList<Long>();
        Set<Long> planningIdSet = new HashSet<Long>();
        for (Long ccrId : ccrIdList) {
            StringBuilder query = new StringBuilder();
            query.append(
                    "select planning_id from ti_request_planning_xref where ti_request_id in (select id from ti_request where process_id =");
            query.append(ccrId);
            query.append(")");
            SqlRowSet result = null;
            try {
                result = jdbcTemplate.queryForRowSet(query.toString());
                int count = 1;
                while (result.next()) {
                    planningIdSet.add(result.getLong(1));
                    log.debug(count + " Record added in planningIdList for ccrId " + ccrId);
                    count++;
                }
                if (planningIdSet.isEmpty()) {
                    log.debug("No Records Found...");
                } else {
                    for(Long planningId:planningIdSet){
                        planningIdMap.put(planningId,ccrIdMap.get(ccrId));
                    }
                    log.debug("No. of Records Found are..." + planningIdSet.size());
                }
            } catch (Exception e) {
                log.error(e, e);
            }
        }
        planningIdList.addAll(planningIdSet);
        return planningIdList;
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<Role> getRoleList() {
        log.debug("Roles list Started");
        List<Role> rolesList = null;
        try {
            Session session = sessionFactory.getCurrentSession();

            String queryForRole = "select distinct role from ConReqCitiReqConXref";
            String queryForRole1 = "select distinct role from ConReqCitiContactXref";

            System.out.println("Query for Role: " + queryForRole);
            rolesList = session.createQuery(queryForRole).list();
            rolesList.addAll(session.createQuery(queryForRole1).list());
            rolesList = new ArrayList<Role>(new HashSet<Role>(rolesList));
            log.debug("Roles list Ended. Number of Roles: " + rolesList.size());
        } catch (Exception e) {
            log.error("Error has occurred in getRoleList method ::" + e.getMessage());
        }
        log.debug("Roles list Ended");
        return rolesList;
        /*
         * List<String> roleList = null; try { SQLQuery sqlQuery =
         * sessionFactory
         * .getCurrentSession().createSQLQuery(QueryConstants.GET_ROLE_LIST);
         * sqlQuery.addScalar("name", StringType.INSTANCE); roleList =
         * sqlQuery.list(); log.info("roleList size value is:: " +
         * roleList.size());
         * 
         * } catch (Exception e) { log.error(
         * "Exception occurred while getting the getSectorList : " +
         * e.toString()); throw new ApplicationException(
         * "Exception has occurred :: getSectorList() ", e); } return roleList;
         */
    }

    @Transactional
    public void removeContacts(List<Long> ccrIds, Long citiContactId, Long roleId) {
        log.debug("::Entering:: ");

        Session session = sessionFactory.getCurrentSession();

        try {

            for (Long ccrId : ccrIds) {
                String sql = "DELETE FROM C3PAR.CON_REQ_CITI_CONTACT_XREF WHERE ID = :ccrId";
                Query query = session.createQuery(sql);
                query.setLong("ccrId", ccrId);
                int recordsCount = query.executeUpdate();
                log.debug("Number of Records Deleted: " + recordsCount);
            }

        } catch (Exception e) {
            log.error("Error while removing contacts from connections: " + e.getMessage());
            throw e;
        }

        log.debug("::Exiting:: ");
    }

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @Override
    public Long getTiRequestId(Long processId) {
        List<Long> tiRequestIdList = new ArrayList<Long>();
        Long tiRequestId = 0L;
        SqlRowSet rs = getJdbcTemplate().queryForRowSet("SELECT MAX(ID) FROM TI_REQUEST WHERE PROCESS_ID = ?",
                new Object[] { processId });

        if (rs.next()) {
            tiRequestIdList.add(rs.getLong(1));
        }
        if (tiRequestIdList != null && !tiRequestIdList.isEmpty()) {
            tiRequestId = tiRequestIdList.get(0);
        }
        return tiRequestId;
    }

    private Long getTiRequestIdForPlanningId(Long planningId) {
        List<Long> tiRequestIdList = new ArrayList<Long>();
        Long tiRequestId = 0L;
        SqlRowSet rs = getJdbcTemplate().queryForRowSet(
                "select ti_request_id from ti_request_planning_xref where planning_id = ?",
                new Object[] { planningId });

        if (rs.next()) {
            tiRequestIdList.add(rs.getLong(1));
        }
        if (tiRequestIdList != null && !tiRequestIdList.isEmpty()) {
            tiRequestId = tiRequestIdList.get(0);
        }
        return tiRequestId;
    }

    public TIRequest getTIRequest(long tiRequestId) {
        TIRequest tiRequest = null;
        log.debug("BasePersistanceImpl:getTIRequest: Entered with Ti Request ID:" + tiRequestId);
        try {
            tiRequest = (TIRequest) sessionFactory.getCurrentSession().get(TIRequest.class, Long.valueOf(tiRequestId));
        } catch (Exception e) {
            log.error(e, e);
            throw new ApplicationException(" There was an exception while getting ti Request:" + tiRequestId);
        }
        log.debug("BasePersistanceImpl:getTIRequest: Exiting with Ti Request:" + tiRequestId);

        if (tiRequest != null && tiRequest.getTiProcess().getId() != null) {
            log.debug("BasePersistanceImpl:getTIRequest: Exiting with Ti Process: " + tiRequest.getTiProcess().getId());
        }

        return tiRequest;
    }

    @Override
    public void updatePrimaryOrNotifyContact(Map<Long, String> planningIdList,
            BulkContactUpdateDTO bulkContactUpdateDTO) {
        try {
            log.debug("updatePrimaryorNotifyContact starts...");
            Session session = sessionFactory.getCurrentSession();
            Long oldHistoryContactId = null;
            Long newHistoryContactid = null;
            StringBuilder query = new StringBuilder();
            for (Long citiContactid : planningIdList.keySet()) {
                // log.info("Selected
                // CCR"+bulkContactUpdateDTO.getCitiContactId());
                String contactType = planningIdList.get(citiContactid);
                if (contactType.equalsIgnoreCase("target")) {

                    ConReqCitiContactXref conReqCitiContactXref = (ConReqCitiContactXref) session
                            .load(ConReqCitiContactXref.class, citiContactid);

                    HistoryContact oldHistoryContact = new HistoryContact();
                    oldHistoryContact.setCreated_date(new Date());
                    oldHistoryContact.setContactId(conReqCitiContactXref.getCiticontact().getId());
                    oldHistoryContact.setSoeId(conReqCitiContactXref.getCiticontact().getSsoId());
                    oldHistoryContact.setRoleId(conReqCitiContactXref.getRole().getId());
                    oldHistoryContact.setNotifyContact(conReqCitiContactXref.getNotifyContact());
                    oldHistoryContact.setPrimaryContact(conReqCitiContactXref.getPrimaryContact());
                    oldHistoryContact.setSystemGenerated(conReqCitiContactXref.getSystemGenerated());
                    oldHistoryContactId = (Long) session.save(oldHistoryContact);
                    switch (bulkContactUpdateDTO.getAction()) {

                        case BulContactUpdateConstants.PRIMARY_YES:
                            conReqCitiContactXref.setPrimaryContact("Y");

                            log.info(" Primary Flag=" + conReqCitiContactXref.getPrimaryContact());
                            break;
                        case BulContactUpdateConstants.PRIMARY_NO:

                            conReqCitiContactXref.setPrimaryContact("N");

                            break;
                        case BulContactUpdateConstants.NOTIFY_YES:
                            conReqCitiContactXref.setNotifyContact("Y");

                            break;

                        case BulContactUpdateConstants.NOTIFY_NO:
                            conReqCitiContactXref.setNotifyContact("N");

                            break;

                    }

                    HistoryContact newHistioryContact = new HistoryContact();
                    newHistioryContact.setCreated_date(new Date());
                    newHistioryContact.setContactId(conReqCitiContactXref.getCiticontact().getId());
                    newHistioryContact.setSoeId(conReqCitiContactXref.getCiticontact().getSsoId());
                    newHistioryContact.setRoleId(conReqCitiContactXref.getRole().getId());
                    newHistioryContact.setNotifyContact(conReqCitiContactXref.getNotifyContact());
                    newHistioryContact.setPrimaryContact(conReqCitiContactXref.getPrimaryContact());
                    newHistioryContact.setSystemGenerated(conReqCitiContactXref.getSystemGenerated());
                    newHistoryContactid = (Long) session.save(newHistioryContact);

                    session.update(conReqCitiContactXref);
                    String objectName = "con_req_citi_contact_xref";
                    TIRequest tiRequest = getTiRequest(conReqCitiContactXref.getRequestid().getId());
                    AuditLog auditLog = new AuditLog();
                    auditLog.setSoeID(bulkContactUpdateDTO.getUserSsoId());
                    auditLog.setCreated_date(new Date());
                    auditLog.setObjectName("Connection");
                    auditLog.setObjectAttribute("Contact");
                    auditLog.setNewValue(String.valueOf(conReqCitiContactXref.getId()));
                    auditLog.setNewDisplayValue(bulkContactUpdateDTO.getSsoId().toUpperCase());
                    auditLog.setNewAuditObjectType(getAuditObjectType(objectName));
                    auditLog.setAction("Update");
                    auditLog.setOldValue(String.valueOf(oldHistoryContactId));
                    auditLog.setOldDisplayValue(bulkContactUpdateDTO.getSsoId().toUpperCase());
                    auditLog.setOldAuditObjectType(getAuditObjectType(objectName));
                    auditLog.setTiRequest(tiRequest);
                    auditLog.setIsReference("Y");
                    session.save(auditLog);
                    log.info(" conReqCitiContactXrefId :" + citiContactid + "Old History contact id:"
                            + oldHistoryContactId + "New History contact id" + newHistoryContactid);

                }

                else {
                    ConReqCitiReqConXref conReqCitiContactXref = (ConReqCitiReqConXref) session
                            .load(ConReqCitiReqConXref.class, citiContactid);
                    HistoryContact oldHistoryContact = new HistoryContact();
                    oldHistoryContact.setCreated_date(new Date());
                    oldHistoryContact.setContactId(conReqCitiContactXref.getCiticontact().getId());
                    oldHistoryContact.setSoeId(conReqCitiContactXref.getCiticontact().getSsoId());
                    oldHistoryContact.setRoleId(conReqCitiContactXref.getRole().getId());
                    oldHistoryContact.setNotifyContact(conReqCitiContactXref.getNotifyContact());
                    oldHistoryContact.setPrimaryContact(conReqCitiContactXref.getPrimaryContact());
                    oldHistoryContact.setSystemGenerated(conReqCitiContactXref.getSystemGenerated());
                    oldHistoryContactId = (Long) session.save(oldHistoryContact);
                    switch (bulkContactUpdateDTO.getAction()) {

                        case BulContactUpdateConstants.PRIMARY_YES:
                            conReqCitiContactXref.setPrimaryContact("Y");

                            break;
                        case BulContactUpdateConstants.PRIMARY_NO:
                            conReqCitiContactXref.setPrimaryContact("N");
                            break;
                        case BulContactUpdateConstants.NOTIFY_YES:
                            conReqCitiContactXref.setNotifyContact("Y");
                            break;

                        case BulContactUpdateConstants.NOTIFY_NO:
                            conReqCitiContactXref.setNotifyContact("N");
                            break;
                    }

                    HistoryContact newHistioryContact = new HistoryContact();
                    newHistioryContact.setCreated_date(new Date());
                    newHistioryContact.setContactId(conReqCitiContactXref.getCiticontact().getId());
                    newHistioryContact.setSoeId(conReqCitiContactXref.getCiticontact().getSsoId());
                    newHistioryContact.setRoleId(conReqCitiContactXref.getRole().getId());
                    newHistioryContact.setNotifyContact(conReqCitiContactXref.getNotifyContact());
                    newHistioryContact.setPrimaryContact(conReqCitiContactXref.getPrimaryContact());
                    newHistioryContact.setSystemGenerated(conReqCitiContactXref.getSystemGenerated());
                    newHistoryContactid = (Long) session.save(newHistioryContact);
                    session.update(conReqCitiContactXref);
                    String objectName = "con_req_cit_rqcon_xref";
                    TIRequest tiRequest = getTiRequest(conReqCitiContactXref.getRequestid().getId());
                    AuditLog auditLog = new AuditLog();
                    auditLog.setSoeID(bulkContactUpdateDTO.getUserSsoId());
                    auditLog.setCreated_date(new Date());
                    auditLog.setObjectName("Connection");
                    auditLog.setObjectAttribute("Contact");
                    auditLog.setNewValue(String.valueOf(conReqCitiContactXref.getId()));
                    auditLog.setNewDisplayValue(bulkContactUpdateDTO.getSsoId());
                    auditLog.setNewAuditObjectType(getAuditObjectType(objectName));
                    auditLog.setAction("Update");
                    auditLog.setOldValue(String.valueOf(oldHistoryContactId));
                    auditLog.setOldDisplayValue(bulkContactUpdateDTO.getSsoId());
                    auditLog.setOldAuditObjectType(getAuditObjectType(objectName));
                    auditLog.setTiRequest(tiRequest);
                    auditLog.setIsReference("Y");
                    session.save(auditLog);
                    log.info(" conReqCitiContactXrefId :" + citiContactid + "Old History contact id:"
                            + oldHistoryContactId + "New History contact id" + newHistoryContactid);

                }
            }

        }

        catch (Exception exp) {
            log.info("Exceprion occured while bulk contact update :" + exp.toString());
        } finally {

        }

    }

    @Override
    public void removeContacts(List<Long> targetIds, List<Long> requestorIds,String soeID) {
        log.debug("::Entering:: TagetIds : " + targetIds + " RequestorIds: " + requestorIds);

        Session session = sessionFactory.getCurrentSession();

        try {
            if (targetIds != null && !targetIds.isEmpty()) {

                for (Long targetId : targetIds) {
                    ConReqCitiContactXref conReqCitiContactXref = (ConReqCitiContactXref) session
                            .load(ConReqCitiContactXref.class, targetId);
                    HistoryContact newHistioryContact = new HistoryContact();
                    newHistioryContact.setCreated_date(new Date());
                    newHistioryContact.setContactId(conReqCitiContactXref.getCiticontact().getId());
                    newHistioryContact.setSoeId(conReqCitiContactXref.getCiticontact().getSsoId());
                    newHistioryContact.setRoleId(conReqCitiContactXref.getRole().getId());
                    newHistioryContact.setNotifyContact(conReqCitiContactXref.getNotifyContact());
                    newHistioryContact.setPrimaryContact(conReqCitiContactXref.getPrimaryContact());
                    newHistioryContact.setSystemGenerated(conReqCitiContactXref.getSystemGenerated());
                    Long newHistoryContactid = (Long) session.save(newHistioryContact);
                    log.info(" New history contact  values are saved:  old History Contact Id   :"
                            + newHistoryContactid);

                    
                    String objectName = "con_req_cit_rqcon_xref";
                    TIRequest tiRequest = getTiRequest(conReqCitiContactXref.getRequestid().getId());
                    AuditLog auditLog = new AuditLog();
                    auditLog.setSoeID(conReqCitiContactXref.getCiticontact().getSsoId());
                    auditLog.setCreated_date(new Date());
                    auditLog.setObjectName("Connection");
                    auditLog.setObjectAttribute("Contact");
                    auditLog.setNewAuditObjectType(getAuditObjectType(objectName));
                    auditLog.setAction("Delete");
                    auditLog.setOldValue(String.valueOf(newHistoryContactid));
                    auditLog.setOldDisplayValue(conReqCitiContactXref.getCiticontact().getSsoId());
                    auditLog.setOldAuditObjectType(getAuditObjectType(objectName));
                    auditLog.setTiRequest(tiRequest);
                    auditLog.setIsReference("Y");
                    session.save(auditLog);
                    session.delete(conReqCitiContactXref);

                }

                /*String sql = "DELETE FROM C3PAR.CON_REQ_CITI_CONTACT_XREF WHERE ID in (:targetIds)";
                Query query = session.createSQLQuery(sql);
                query.setParameterList("targetIds", targetIds);
                int recordsCount = query.executeUpdate();
                log.debug("Number of Records Deleted from Target contacts: " + recordsCount);*/
            }

            if (requestorIds != null && !requestorIds.isEmpty()) {
                for (Long requestorId : requestorIds) {
                    ConReqCitiReqConXref conReqCitiReqConXref = (ConReqCitiReqConXref) session
                            .load(ConReqCitiReqConXref.class, requestorId);
                    HistoryContact newHistioryContact = new HistoryContact();
                    newHistioryContact.setCreated_date(new Date());
                    newHistioryContact.setContactId(conReqCitiReqConXref.getCiticontact().getId());
                    newHistioryContact.setSoeId(conReqCitiReqConXref.getCiticontact().getSsoId());
                    newHistioryContact.setRoleId(conReqCitiReqConXref.getRole().getId());
                    newHistioryContact.setNotifyContact(conReqCitiReqConXref.getNotifyContact());
                    newHistioryContact.setPrimaryContact(conReqCitiReqConXref.getPrimaryContact());
                    newHistioryContact.setSystemGenerated(conReqCitiReqConXref.getSystemGenerated());
                    Long newHistoryContactid = (Long) session.save(newHistioryContact);
                    log.info(" New history contact  values are saved:  old History Contact Id   :"
                            + newHistoryContactid);

                    String objectName = "con_req_cit_rqcon_xref";
                    TIRequest tiRequest = getTiRequest(conReqCitiReqConXref.getRequestid().getId());
                    AuditLog auditLog = new AuditLog();
                    auditLog.setSoeID(soeID);
                    auditLog.setCreated_date(new Date());
                    auditLog.setObjectName("Connection");
                    auditLog.setObjectAttribute("Contact");
                    auditLog.setNewAuditObjectType(getAuditObjectType(objectName));
                    auditLog.setAction("Delete");
                    auditLog.setOldValue(String.valueOf(newHistoryContactid));
                    auditLog.setOldDisplayValue(conReqCitiReqConXref.getCiticontact().getSsoId());
                    auditLog.setOldAuditObjectType(getAuditObjectType(objectName));
                    auditLog.setTiRequest(tiRequest);
                    auditLog.setIsReference("Y");
                    session.save(auditLog);
                    session.delete(conReqCitiReqConXref);

                }

                /*String sql = "DELETE FROM C3PAR.CON_REQ_CITI_CONTACT_XREF WHERE ID in (:requestorIds)";
                Query query = session.createSQLQuery(sql);
                query.setParameterList("requestorIds", requestorIds);
                int recordsCount = query.executeUpdate();
                log.debug("Number of Records Deleted from Requestor contacts: " + recordsCount);*/
            }

        } catch (Exception e) {
            log.error("Error while removing contacts from connections: " + e.getMessage());

        }

        log.debug("::Exiting:: ");

    }

}
