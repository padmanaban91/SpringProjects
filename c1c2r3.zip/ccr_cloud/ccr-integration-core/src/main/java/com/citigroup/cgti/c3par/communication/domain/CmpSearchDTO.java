package com.citigroup.cgti.c3par.communication.domain;

import java.io.Serializable;

public class CmpSearchDTO implements Serializable {
    private String orderItemId;
    private String assignedUser;
    private String dateAssigned;
    private String status;
    private String currentStatus;
    private String requestType;
    private String ccrIdWithVerNo;
    private String ccrIdWithVersionNo;
    private String chgDate;
    private String chgId;
    private String ccrId;

    /**
     * @return the orderItemId
     */
    public String getOrderItemId() {
        return orderItemId;
    }

    /**
     * @param orderItemId
     *            the orderItemId to set
     */
    public void setOrderItemId(String orderItemId) {
        this.orderItemId = orderItemId;
    }

    /**
     * @return the assignedUser
     */
    public String getAssignedUser() {
        return assignedUser;
    }

    /**
     * @param assignedUser
     *            the assignedUser to set
     */
    public void setAssignedUser(String assignedUser) {
        this.assignedUser = assignedUser;
    }

    /**
     * @return the dateAssigned
     */
    public String getDateAssigned() {
        return dateAssigned;
    }

    /**
     * @param dateAssigned
     *            the dateAssigned to set
     */
    public void setDateAssigned(String dateAssigned) {
        this.dateAssigned = dateAssigned;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the requestType
     */
    public String getRequestType() {
        return requestType;
    }

    /**
     * @param requestType
     *            the requestType to set
     */
    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    /**
     * @return the ccrIdWithVerNo
     */
    public String getCcrIdWithVerNo() {
        return ccrIdWithVerNo;
    }

    /**
     * @param ccrIdWithVerNo
     *            the ccrIdWithVerNo to set
     */
    public void setCcrIdWithVerNo(String ccrIdWithVerNo) {
        this.ccrIdWithVerNo = ccrIdWithVerNo;
    }

    /**
     * @return the chgDate
     */
    public String getChgDate() {
        return chgDate;
    }

    /**
     * @param chgDate
     *            the chgDate to set
     */
    public void setChgDate(String chgDate) {
        this.chgDate = chgDate;
    }

    /**
     * @return the chgId
     */
    public String getChgId() {
        return chgId;
    }

    /**
     * @param chgId
     *            the chgId to set
     */
    public void setChgId(String chgId) {
        this.chgId = chgId;
    }

    /**
     * @return the ccrId
     */
    public String getCcrId() {
        return ccrId;
    }

    /**
     * @param ccrId
     *            the ccrId to set
     */
    public void setCcrId(String ccrId) {
        this.ccrId = ccrId;
    }

    /**
     * @return the ccrIdWithVersionNo
     */
    public String getCcrIdWithVersionNo() {
        return ccrIdWithVersionNo;
    }

    /**
     * @param ccrIdWithVersionNo
     *            to set
     */
    public void setCcrIdWithVersionNo(String ccrIdWithVersionNo) {
        this.ccrIdWithVersionNo = ccrIdWithVersionNo;
    }

    /**
     * @return the currentStatus
     */
    public String getCurrentStatus() {
        return currentStatus;
    }

    /**
     * @param currentStatus
     *            the currentStatus to set
     */
    public void setCurrentStatus(String currentStatus) {
        this.currentStatus = currentStatus;
    }

}
