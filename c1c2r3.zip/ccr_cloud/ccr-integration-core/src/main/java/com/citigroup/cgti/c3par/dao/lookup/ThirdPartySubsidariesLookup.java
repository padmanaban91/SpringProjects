

/*
 * CONFIDENTIAL  AND PROPRIETARY
 * Copyright ? 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is 
 * strictly prohibited.
 */
package com.citigroup.cgti.c3par.dao.lookup;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.citigroup.cgti.c3par.model.*;
import com.citigroup.cgti.c3par.dao.*;
import com.mentisys.dao.*;
import com.mentisys.dao.query.*;


/**
 * The Class ThirdPartySubsidariesLookup.
 */
public class ThirdPartySubsidariesLookup
{

    /** The initialized. */
    private boolean		initialized = false;

    /** The ordered list. */
    private ArrayList 	orderedList = new ArrayList();

    /** The values by id. */
    private HashMap		valuesById = new HashMap();

    /** The values by name. */
    private HashMap		valuesByName = new HashMap();

    /** The instance. */
    static private ThirdPartySubsidariesLookup instance = null;

    //======================================================================
    /**
     * Gets the single instance of ThirdPartySubsidariesLookup.
     *
     * @return single instance of ThirdPartySubsidariesLookup
     */
    synchronized static public ThirdPartySubsidariesLookup getInstance()
    {
	if (instance == null)
	{
	    instance = new ThirdPartySubsidariesLookup();
	}
	return instance;
    }

    //======================================================================
    /**
     * Gets the single instance of ThirdPartySubsidariesLookup.
     *
     * @param session the session
     * @return single instance of ThirdPartySubsidariesLookup
     * @throws DatabaseException the database exception
     */
    synchronized static public ThirdPartySubsidariesLookup getInstance(DatabaseSession session) throws DatabaseException
    {
	if (instance == null)
	{
	    instance = new ThirdPartySubsidariesLookup();
	    instance.initialize(session);	
	}
	else if(!instance.isInitialized())
	{
	    instance.initialize(session);	
	}
	return instance;
    }

    //======================================================================
    /**
     * Instantiates a new third party subsidaries lookup.
     */
    private ThirdPartySubsidariesLookup()
    {
	super();
	initialized = false;
    }

    //======================================================================
    /**
     * Initialize.
     *
     * @param session the session
     * @throws DatabaseException the database exception
     */
    synchronized public void initialize(DatabaseSession session) throws DatabaseException
    {
	if (!initialized)
	{
	    ThirdPartySubsidariesDAO dao = new ThirdPartySubsidariesDAO(session);
	    ThirdPartySubsidariesEntity entity = null;
	    Condition condition = new Condition();
	    condition.addOrderByField(ThirdPartySubsidariesDAO.COLUMN_NAME);
	    try
	    {
		List list = dao.query(condition, false);
		Iterator it = list.iterator();

		while (it.hasNext())
		{
		    entity = (ThirdPartySubsidariesEntity) it.next();
		    valuesById.put(entity.getId(), entity);
		    valuesByName.put(entity.getName(), entity);
		    orderedList.add(entity);
		}
		initialized = true;

		it = list.iterator();
		while (it.hasNext())
		{
		    entity = (ThirdPartySubsidariesEntity) it.next();
		    dao.loadReferences((ThirdPartySubsidariesEntity)entity);
		}
	    }
	    catch (DatabaseException e)
	    {
		throw e;
	    }
	}
    }

    //======================================================================
    /**
     * Reset.
     */
    synchronized public void reset()
    {
	valuesById = new HashMap();
	orderedList = new ArrayList();
	initialized = false;
	valuesByName = new HashMap();
    }

    //======================================================================
    /**
     * Gets the by id.
     *
     * @param id the id
     * @return the by id
     */
    synchronized public ThirdPartySubsidariesEntity getById(Long id)
    {
	return (ThirdPartySubsidariesEntity) valuesById.get(id);
    }

    //======================================================================
    /**
     * Gets the by id.
     *
     * @param session the session
     * @param id the id
     * @return the by id
     * @throws DatabaseException the database exception
     */
    synchronized public ThirdPartySubsidariesEntity getById(DatabaseSession session, Long id) throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (ThirdPartySubsidariesEntity) valuesById.get(id);
    }

    //======================================================================
    /**
     * Gets the by name.
     *
     * @param v the v
     * @return the by name
     */
    synchronized public ThirdPartySubsidariesEntity getByName(String v)
    {
	return (ThirdPartySubsidariesEntity) valuesByName.get(v);
    }

    //======================================================================
    /**
     * Gets the by name.
     *
     * @param session the session
     * @param v the v
     * @return the by name
     * @throws DatabaseException the database exception
     */
    synchronized public ThirdPartySubsidariesEntity getByName(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (ThirdPartySubsidariesEntity) valuesByName.get(v);
    }

    //======================================================================
    /**
     * Gets the all.
     *
     * @return the all
     */
    synchronized public ArrayList getAll()
    {
	return orderedList;
    }

    //======================================================================
    /**
     * Checks if is initialized.
     *
     * @return true, if is initialized
     */
    synchronized public boolean isInitialized()
    {
	return initialized;
    }
}
