package com.citigroup.cgti.c3par.configuation;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

public class DatabaseUtil {
	
	private JdbcTemplate jdbcTemplate;
	private CCRQueries ccrQueries;

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}
	
	public CCRQueries getCcrQueries() {
		return ccrQueries;
	}

	public void setCcrQueries(CCRQueries ccrQueries) {
		this.ccrQueries = ccrQueries;
	}
	
	
	//Check if Template/IpTemplate/PortTemplate Connection is Aborted and had atleast one implemented version
	public boolean isTemplateAborted(Long connectionId) {
		
		List<Map<String,Object>> i = jdbcTemplate.queryForList(ccrQueries.getQueryByName(QueryConstants.IS_TEMPLATE_CONNECTION_ABORTED),new Object[]{connectionId,connectionId});
		
		if(i!=null && i.size()>0){
			return true;
		}else{
			return false;
		}

	}
	
	//If Template/IpTemplate/PortTemplate Connection is Aborted, revert rules to last implemented cycle version
	public void revertTemplateRulesToImplementedVersion(Long connectionId) {

		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
				.withProcedureName("TEMPLATE_MASTER_REVERT_RULES");

		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("A_CONNX_ID", connectionId);

		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		simpleJdbcCall.execute(in);

	}
	
	
	public String getConnectionId(Long tiRequestId) {
		StringBuilder sb = new StringBuilder();

		sb.append("select process_id from ti_request where id = ? and rownum<=1 ");

		return (String)jdbcTemplate.queryForObject(sb.toString(), new Object[]{tiRequestId},String.class);

	}
	
	//Copy contacts to xref tables
	public void copyContactsToXrefs(Long connectionId) {

		SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
				.withProcedureName("COPY_CONTACTS_TO_XREF");

		Map<String, Object> inParamMap = new HashMap<String, Object>();
		inParamMap.put("A_CON_REQ_VALUE", connectionId);

		SqlParameterSource in = new MapSqlParameterSource(inParamMap);

		simpleJdbcCall.execute(in);

	}

}
