package com.citigroup.cgti.c3par.common.domain;

import com.citigroup.cgti.c3par.domain.Base;

public class ResourceType extends Base {

/**
 * 
 */
private static final long serialVersionUID = 1L;
private Long id;
private String name;
private String perimeter;
private String status;
private String createdBy;
private String modifiedBy;
private String broadAccessIp;
private String resourceTypeId;


public Long getId() {
	return id;
}
public void setId(Long id) {
	this.id = id;
}
public void setName(String name) {
	this.name = name;
}
public void setPerimeter(String perimeter) {
	this.perimeter = perimeter;
}
public void setStatus(String status) {
	this.status = status;
}
public void setModifiedBy(String modifiedBy) {
	this.modifiedBy = modifiedBy;
}
public void setBroadAccessIp(String broadAccessIp) {
	this.broadAccessIp = broadAccessIp;
}

public String getName() {
	return name;
}
public String getPerimeter() {
	return perimeter;
}
public String getStatus() {
	return status;
}
public String getModifiedBy() {
	return modifiedBy;
}
public String getBroadAccessIp() {
	return broadAccessIp;
}
/**
 * @return the createdBy
 */
public String getCreatedBy() {
	return createdBy;
}
/**
 * @param createdBy the createdBy to set
 */
public void setCreatedBy(String createdBy) {
	this.createdBy = createdBy;
}
public String getResourceTypeId() {
	return resourceTypeId;
}
public void setResourceTypeId(String resourceTypeId) {
	this.resourceTypeId = resourceTypeId;
}


}
