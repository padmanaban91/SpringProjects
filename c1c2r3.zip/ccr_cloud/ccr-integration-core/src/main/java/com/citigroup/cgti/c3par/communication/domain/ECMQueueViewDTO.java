package com.citigroup.cgti.c3par.communication.domain;

import java.io.Serializable;

import com.citigroup.cgti.c3par.domain.Base;

/**
 * @author mr89025
 * 
 */
public class ECMQueueViewDTO extends Base implements Serializable {

	private static final long serialVersionUID = 16456545L;

	private String ecmUserName;

	private String ecmUserRoleName;

	private String queueName;

	private String displayName;

	public String getEcmUserName() {
		return ecmUserName;
	}

	public void setEcmUserName(String ecmUserName) {
		this.ecmUserName = ecmUserName;
	}

	public String getEcmUserRoleName() {
		return ecmUserRoleName;
	}

	public void setEcmUserRoleName(String ecmUserRoleName) {
		this.ecmUserRoleName = ecmUserRoleName;
	}

	public String getQueueName() {
		return queueName;
	}

	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

}
