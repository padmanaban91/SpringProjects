package com.citigroup.cgti.c3par.businessjustification.domain;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.Planning;
import com.citigroup.cgti.c3par.domain.Role;


/**
 * The Class ConReqCitiContactXref.
 */
public class ConReqCitiReqConXref extends Base{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private CitiContact citicontact;
	private Role role;
	private Planning requestid;
	private String primaryContact;
	private String notifyContact;
	private String systemGenerated;
	private Long notifyCount;
	private String isreject;
	private String isexistsInCCR;
	private String modified;
   
	public CitiContact getCiticontact() {
		return citicontact;
	}
	public void setCiticontact(CitiContact citicontact) {
		this.citicontact = citicontact;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	public Planning getRequestid() {
		return requestid;
	}
	public void setRequestid(Planning requestid) {
		this.requestid = requestid;
	}
	public String getPrimaryContact() {
		return primaryContact;
	}
	public void setPrimaryContact(String primaryContact) {
		this.primaryContact = primaryContact;
	}
	public String getNotifyContact() {
		return notifyContact;
	}
	public void setNotifyContact(String notifyContact) {
		this.notifyContact = notifyContact;
	}
	public String getSystemGenerated() {
		return systemGenerated;
	}
	public void setSystemGenerated(String systemGenerated) {
		this.systemGenerated = systemGenerated;
	}
	public Long getNotifyCount() {
		return notifyCount;
	}
	public void setNotifyCount(Long notifyCount) {
		this.notifyCount = notifyCount;
	}
	public String getIsreject() {
		return isreject;
	}
	public void setIsreject(String isreject) {
		this.isreject = isreject;
	}
	public String getIsexistsInCCR() {
		return isexistsInCCR;
	}
	public void setIsexistsInCCR(String isexistsInCCR) {
		this.isexistsInCCR = isexistsInCCR;
	}
	public String getModified() {
		return modified;
	}
	public void setModified(String modified) {
		this.modified = modified;
	}
   
}
