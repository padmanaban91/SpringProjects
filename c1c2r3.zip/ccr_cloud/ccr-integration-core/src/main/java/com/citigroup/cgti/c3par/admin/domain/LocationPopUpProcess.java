/*
 * 
 */
package com.citigroup.cgti.c3par.admin.domain;

import java.io.Serializable;
import java.util.Map;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.relationship.domain.BusinessUnitLocationXref;
import com.citigroup.cgti.c3par.relationship.domain.Location;
import com.citigroup.cgti.c3par.relationship.domain.ResourceTypeLocXref;
import com.citigroup.cgti.c3par.relationship.domain.ThirdPartyLocationXref;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

/**
 * The Class ContactPopUpProcess
 */
public class LocationPopUpProcess extends Base implements Serializable {
	
	   CCRBeanFactory ccrBeanFactory;
		{
			ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
			if(appContext!=null && appContext.containsBean("cCRBeanFactory")){
				ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
			}else{
				System.out.println("appContext is null");
			}
			
		}
	
	private ThirdPartyLocationXref tpLocXref;
	private Location location;	
	private Long selectedThirdParty;
	private Long selectedBusUnit;
	private Long selectedResType;	
	private Map<Long,String> country;
	private Map<Long,String> region;		
	private String requestType;

	private BusinessUnitLocationXref buLocXref;
	private ResourceTypeLocXref resTypeLocXref;
	
	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public Long getSelectedThirdParty() {
		return selectedThirdParty;
	}

	public void setSelectedThirdParty(Long selectedThirdParty) {
		this.selectedThirdParty = selectedThirdParty;
	}
	
	public Map<Long, String> getCountry() {
		return country;
	}

	public void setCountry(Map<Long, String> country) {
		this.country = country;
	}

	public Map<Long, String> getRegion() {
		return region;
	}

	public void setRegion(Map<Long, String> region) {
		this.region = region;
	}
	
	public ThirdPartyLocationXref getTpLocXref() {
		return tpLocXref;
	}

	public void setTpLocXref(ThirdPartyLocationXref tpLocXref) {
		this.tpLocXref = tpLocXref;
	}

	public BusinessUnitLocationXref getBuLocXref() {
		return buLocXref;
	}

	public void setBuLocXref(BusinessUnitLocationXref buLocXref) {
		this.buLocXref = buLocXref;
	}

	public ResourceTypeLocXref getResTypeLocXref() {
		return resTypeLocXref;
	}

	public void setResTypeLocXref(ResourceTypeLocXref resTypeLocXref) {
		this.resTypeLocXref = resTypeLocXref;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public Long getSelectedBusUnit() {
		return selectedBusUnit;
	}

	public void setSelectedBusUnit(Long selectedBusUnit) {
		this.selectedBusUnit = selectedBusUnit;
	}

	public Long getSelectedResType() {
		return selectedResType;
	}

	public void setSelectedResType(Long selectedResType) {
		this.selectedResType = selectedResType;
	}

	
	public Map<Long,String> getListOfRegions() {
		return ccrBeanFactory.getThirdPartyPersistable().getListOfRegions();
	}
	
	
	public Map<Long, String> getListofCountries() {
		return ccrBeanFactory.getThirdPartyPersistable().getListofCountries();
	}
	
	
	public Location getLocation(Long id) {
		return ccrBeanFactory.getThirdPartyPersistable().getLocation(id);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void saveLocationDetails() {
		ccrBeanFactory.getThirdPartyPersistable().saveLocationDetails(this);
	}
	
	
	
}
