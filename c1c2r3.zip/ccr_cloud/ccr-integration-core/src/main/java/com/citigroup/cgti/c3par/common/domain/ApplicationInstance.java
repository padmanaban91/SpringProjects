package com.citigroup.cgti.c3par.common.domain;

import java.io.Serializable;

/**
 * 
 *
 * @author ac81662
 */

/* Application Instance Domain Class */
public class ApplicationInstance implements Serializable {

	private static final long serialVersionUID = 1L;

	private long Id;

	private String name;

	public ApplicationInstance() {

	}

	public long getId() {
		return Id;
	}

	public void setId(long id) {
		Id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
