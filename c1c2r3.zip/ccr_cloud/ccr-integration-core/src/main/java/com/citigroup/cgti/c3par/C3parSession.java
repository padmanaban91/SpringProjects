package com.citigroup.cgti.c3par;

/*
 * CONFIDENTIAL  AND PROPRIETARY
 */

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.util.C3parProperties;
import com.mentisys.dao.DatabaseAccessObject;
import com.mentisys.dao.DatabaseException;
import com.mentisys.dao.DatabaseSession;
import com.mentisys.dao.audit.AuditArchiver;
import com.mentisys.model.Entity;


/**
 * The Class C3parSession.
 */
public class C3parSession extends DatabaseSession
{

    /** The m_ dao map. */
    protected HashMap		m_DAOMap = null;

    /** The m_ update method map. */
    protected HashMap		m_UpdateMethodMap = null;

    /** The m_ delete method map. */
    protected HashMap		m_DeleteMethodMap = null;

    /** The m_ audit archiver. */
    protected AuditArchiver	m_AuditArchiver = null;

    /** The m_data source. */
    private DataSource m_dataSource =null;

    /** The log. */
    private final Logger log = Logger.getLogger(getClass().getName());

    //==================================================================================
    /**
     * Instantiates a new c3par session.
     */
    public C3parSession()
    {
	super();	
    }

    //==================================================================================
    /**
     * Instantiates a new c3par session.
     *
     * @param user_id the user_id
     * @param comment the comment
     * @throws DatabaseException the database exception
     */
    public C3parSession(String user_id, String comment) throws DatabaseException
    {
	super();	
	init(user_id, comment);
    }

    //==================================================================================
    /**
     * Initialize the session object.
     *
     * @throws DatabaseException the database exception
     */
    public void init() throws DatabaseException
    {
	super.getConnection();
	try
	{
	    super.startTransaction();
	}
	catch(Exception e)
	{
	    super.releaseConnection();
	    throw new  DatabaseException("Unable to start transaction." , e);
	}
    }

    //==================================================================================
    /**
     * Initialize the session object. Opens a connection, and starts an archiving transaction.
     *
     * @param user_id the user_id
     * @param comment the comment
     * @return the audit archiver
     * @throws DatabaseException the database exception
     */
    public AuditArchiver init(String user_id, String comment) throws DatabaseException
    {
	try
	{
	    super.getConnection();
	    super.startTransaction(C3parSchema.getInstance(), user_id, comment);
	    m_AuditArchiver = new AuditArchiver(this, C3parSchema.getInstance());
	}
	catch(DatabaseException e)
	{
	    super.releaseConnection();
	    throw new  DatabaseException("Unable to start transaction." , e);
	}
	return m_AuditArchiver;
    }

    //==================================================================================
    /**
     * Finish.
     *
     * @throws CommitException the commit exception
     * @throws RollbackException the rollback exception
     */
    public void finish() throws CommitException, RollbackException
    {
	try
	{
	    super.commit();
	}
	catch(Exception e)
	{
	    log.error("ERROR: Failed to commit transaction. Exception = " + e.toString());
	    try
	    {
		super.rollback();
	    }
	    catch(Exception rollback_exception)
	    {
		log.error("ERROR: Failed to rollback. Exception = " + e.toString()); 
		throw new RollbackException("Failed to rollback transaction.", rollback_exception);
	    }
	    throw new CommitException("Failed to commit transaction.", e);
	}
	finally
	{
	    super.releaseConnection();	
	}
    }

    //==================================================================================
    /**
     * Gets the archiver.
     *
     * @return the archiver
     */
    public AuditArchiver getArchiver()
    {
	return m_AuditArchiver;
    }

    //==================================================================================
    /**
     * Update entity.
     *
     * @param entity the entity
     * @throws UpdateException the update exception
     */
    public void updateEntity(Entity entity)
    throws UpdateException
    {
	initDAOMaps();
	try
	{
	    DatabaseAccessObject dao = getDAO(entity); 

	    String entity_name = "com.citigroup.cgti.c3par.model." + entity.getEntityName() + "Entity";
	    log.debug("Entity name = " + entity_name);
	    Method dao_update_method = (Method)m_UpdateMethodMap.get(entity_name);
	    if(dao_update_method == null)
	    {
		// get the update method for the dao object.
		Class method_params[] = { Class.forName(entity_name), AuditArchiver.class };
		dao_update_method = dao.getClass().getMethod("update", method_params);
		m_UpdateMethodMap.put(entity_name, dao_update_method);
	    }

	    // Invoke update on the dao
	    log.debug("Invoking method: " + dao_update_method.toString());
	    Object method_args[] = { entity, m_AuditArchiver }; 
	    dao_update_method.invoke(dao, method_args);
	}
	catch(Exception e)
	{
	    log.error("Exception during Session.update() - " + e.toString());
	    super.releaseConnection();	
	    throw new UpdateException(e.getMessage(), e);
	}
    }

    //==================================================================================
    /**
     * Delete entity.
     *
     * @param entity the entity
     * @throws UpdateException the update exception
     */
    public void deleteEntity(Entity entity)
    throws UpdateException
    {
	initDAOMaps();
	try
	{
	    DatabaseAccessObject dao = getDAO(entity); 

	    String entity_name = "com.citigroup.cgti.c3par.model." + entity.getEntityName() + "Entity";
	    log.debug("Entity name = " + entity_name);
	    Method dao_delete_method = (Method)m_DeleteMethodMap.get(entity_name);
	    if(dao_delete_method == null)
	    {
		// get the update method for the dao object.
		Class method_params[] = { Class.forName(entity_name), AuditArchiver.class };
		dao_delete_method = dao.getClass().getMethod("delete", method_params);
		m_DeleteMethodMap.put(entity_name, dao_delete_method);
	    }

	    // Invoke update on the dao
	    log.debug("Invoking method: " + dao_delete_method.toString());
	    Object method_args[] = { entity, m_AuditArchiver }; 
	    dao_delete_method.invoke(dao, method_args);
	}
	catch(Exception e)
	{
	    log.error("Exception during Session.deleteEntity() - " + e.toString());
	    super.releaseConnection();	
	    throw new UpdateException(e.getMessage(), e);
	}
    }

    //==================================================================================
    /**
     * Inits the dao maps.
     */
    protected void initDAOMaps()
    {
	if(m_DAOMap == null)
	{
	    m_DAOMap = new HashMap();
	}

	if(m_UpdateMethodMap == null)
	{
	    m_UpdateMethodMap = new HashMap();
	}

	if(m_DeleteMethodMap == null)
	{
	    m_DeleteMethodMap = new HashMap();
	}
    }

    //==================================================================================
    /**
     * Gets the dAO.
     *
     * @param entity the entity
     * @return the dAO
     * @throws ClassNotFoundException the class not found exception
     * @throws NoSuchMethodException the no such method exception
     * @throws InstantiationException the instantiation exception
     * @throws IllegalAccessException the illegal access exception
     * @throws InvocationTargetException the invocation target exception
     */
    protected DatabaseAccessObject getDAO(Entity entity) 
    throws ClassNotFoundException, NoSuchMethodException, 
    InstantiationException, IllegalAccessException, InvocationTargetException
    {
	String dao_name = "com.citigroup.cgti.c3par.dao." + entity.getEntityName() + "DAO";
	log.debug("DAO name = " + dao_name);
	DatabaseAccessObject dao = (DatabaseAccessObject)m_DAOMap.get(dao_name);
	if(dao == null)
	{
	    // get the contructor
	    Class ctor_params[] = { DatabaseSession.class }; 
	    Constructor ctor = Class.forName(dao_name).getDeclaredConstructor(ctor_params);

	    // And create the DAO object
	    Object ctor_args[] = { this };
	    dao = (DatabaseAccessObject)ctor.newInstance(ctor_args);
	    m_DAOMap.put(dao_name, dao);
	}

	return dao;			
    }

    //==================================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseSession#obtainConnection()
     */
    protected Connection obtainConnection() 
    throws SQLException
    {
	Connection connection = null;
	try {
	    if (null != m_dataSource) {
		log.debug("Getting a new Connection...");
		connection =m_dataSource.getConnection();
	    }else{
		InitialContext ctx = new InitialContext();
		DataSource source = (DataSource) ctx.lookup(C3parProperties.JDBC_DS);
		if (null != source) {
		    connection = source.getConnection();
		}	
	    }
	    if(connection == null)
		throw new Exception ("Failed to obtain a database connection");
	} catch (Exception e) {
	    log.error(e.getMessage(),e);
	}
	return connection;
    }

    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseSession#getConnection()
     */
    public Connection getConnection() throws DatabaseException {
	Connection connection = null;
	try {
	    connection = super.getConnection();
	    while(connection.isClosed()){
		super.releaseConnection();
		super.releaseConnection();
		connection = super.getConnection();
	    }

	} catch (SQLException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
	return connection;
    }

    /**
     * Sets the data source.
     *
     * @param dataSource the new data source
     */
    public void setDataSource(DataSource dataSource) {
	m_dataSource = dataSource;
    }







}