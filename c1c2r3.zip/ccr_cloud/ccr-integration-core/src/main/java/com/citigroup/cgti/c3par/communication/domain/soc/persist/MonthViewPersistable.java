package com.citigroup.cgti.c3par.communication.domain.soc.persist;

import java.util.List;
import java.util.Map;

import com.citigroup.cgti.c3par.communication.domain.MonthViewProcess;
import com.citigroup.cgti.c3par.persistance.Persistable;

public interface MonthViewPersistable extends Persistable {

	public Map<String, List<MonthViewProcess>> getAllDetails();
	
	public List<MonthViewProcess> getPopupDetailsDetails(int assignedUser, String sectorName,String startDate,String endDate, String status);
	
	public Map<String, List<MonthViewProcess>> getManagerViewDetails();

}