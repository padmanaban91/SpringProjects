package com.citigroup.cgti.c3par.connection.domain;

import java.util.Date;

import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;


/**
 * The Class ConnectionIpsecTunnelMaster.
 */
public class ConnectionIpsecTunnelMaster extends PerformerPagerDO {

    /** The tunnel name. */
    private String tunnelName;

    /** The citi router name. */
    private String citiRouterName;

    /** The remote ipsec peer addr. */
    private String remoteIpsecPeerAddr;

    /** The formatted remote addr. */
    private String formattedRemoteAddr;

    /** The citi ipsec peer addr. */
    private String citiIpsecPeerAddr;

    /** The formatted citi addr. */
    private String formattedCitiAddr;

    /** The primary firewall name. */
    private String primaryFirewallName;

    /** The secondary firewall name. */
    private String secondaryFirewallName;

    /** The share flag. */
    private String shareFlag;

    /** The delete flag. */
    private String deleteFlag;

    /** The created date. */
    private Date createdDate;

    /** The updated date. */
    private Date updatedDate;


    //	private Date created_date;
    //	private Date updated_date;


    /**
     * Instantiates a new connection ipsec tunnel master.
     */
    public ConnectionIpsecTunnelMaster() {
	//----------
	setTableName(PerformerTypes.TUNNEL_TABEL );
	setSequenceName(PerformerTypes.TUNNEL_SEQ);
	//----------
	addToDBMapping("tunnelName","TUNNEL_NAME",1);
	addToDBMapping("citiRouterName","CITI_ROUTER_NAME",2);
	addToDBMapping("remoteIpsecPeerAddr","REMOTE_IPSEC_PEER_ADDR",3);
	addToDBMapping("formattedRemoteAddr","FORMATTED_REMOTE_ADDR",4);
	addToDBMapping("citiIpsecPeerAddr","CITI_IPSEC_PEER_ADDR",5);
	addToDBMapping("formattedCitiAddr","FORMATTED_CITI_ADDR",6);
	addToDBMapping("primaryFirewallName","PRIMARY_FIREWALL_NAME",7);
	addToDBMapping("secondaryFirewallName","SECONDARY_FIREWALL_NAME",8);
	addToDBMapping("shareFlag","share_flag",9);
	addToDBMapping("deleteFlag","delete_flag",10);
	addToDBMapping("createdDate","CREATED_DATE",11);
	addToDBMapping("updatedDate","UPDATED_DATE",12);
	//-------------
    }

    /**
     * Gets the citi ipsec peer addr.
     *
     * @return the citi ipsec peer addr
     */
    public String getCitiIpsecPeerAddr() {
	return citiIpsecPeerAddr;
    }

    /**
     * Sets the citi ipsec peer addr.
     *
     * @param citiIpsecPeerAddr the new citi ipsec peer addr
     */
    public void setCitiIpsecPeerAddr(String citiIpsecPeerAddr) {
	this.citiIpsecPeerAddr = citiIpsecPeerAddr;
    }

    /**
     * Gets the citi router name.
     *
     * @return the citi router name
     */
    public String getCitiRouterName() {
	return citiRouterName;
    }

    /**
     * Sets the citi router name.
     *
     * @param citiRouterName the new citi router name
     */
    public void setCitiRouterName(String citiRouterName) {
	this.citiRouterName = citiRouterName;
    }

    /**
     * Gets the created date.
     *
     * @return the created date
     */
    public Date getCreatedDate() {
	return createdDate;
    }

    /**
     * Sets the created date.
     *
     * @param createdDate the new created date
     */
    public void setCreatedDate(Date createdDate) {
	this.createdDate = createdDate;
    }

    /**
     * Gets the delete flag.
     *
     * @return the delete flag
     */
    public String getDeleteFlag() {
	return deleteFlag;
    }

    /**
     * Sets the delete flag.
     *
     * @param deleteFlag the new delete flag
     */
    public void setDeleteFlag(String deleteFlag) {
	this.deleteFlag = deleteFlag;
    }

    /**
     * Gets the formatted citi addr.
     *
     * @return the formatted citi addr
     */
    public String getFormattedCitiAddr() {
	return formattedCitiAddr;
    }

    /**
     * Sets the formatted citi addr.
     *
     * @param formattedCitiAddr the new formatted citi addr
     */
    public void setFormattedCitiAddr(String formattedCitiAddr) {
	this.formattedCitiAddr = formattedCitiAddr;
    }

    /**
     * Gets the formatted remote addr.
     *
     * @return the formatted remote addr
     */
    public String getFormattedRemoteAddr() {
	return formattedRemoteAddr;
    }

    /**
     * Sets the formatted remote addr.
     *
     * @param formattedRemoteAddr the new formatted remote addr
     */
    public void setFormattedRemoteAddr(String formattedRemoteAddr) {
	this.formattedRemoteAddr = formattedRemoteAddr;
    }

    /**
     * Gets the remote ipsec peer addr.
     *
     * @return the remote ipsec peer addr
     */
    public String getRemoteIpsecPeerAddr() {
	return remoteIpsecPeerAddr;
    }

    /**
     * Sets the remote ipsec peer addr.
     *
     * @param remoteIpsecPeerAddr the new remote ipsec peer addr
     */
    public void setRemoteIpsecPeerAddr(String remoteIpsecPeerAddr) {
	this.remoteIpsecPeerAddr = remoteIpsecPeerAddr;
    }

    /**
     * Gets the share flag.
     *
     * @return the share flag
     */
    public String getShareFlag() {
	return shareFlag;
    }

    /**
     * Sets the share flag.
     *
     * @param shareFlag the new share flag
     */
    public void setShareFlag(String shareFlag) {
	this.shareFlag = shareFlag;
    }

    /**
     * Gets the tunnel name.
     *
     * @return the tunnel name
     */
    public String getTunnelName() {
	return tunnelName;
    }

    /**
     * Sets the tunnel name.
     *
     * @param tunnelName the new tunnel name
     */
    public void setTunnelName(String tunnelName) {
	this.tunnelName = tunnelName;
    }

    /**
     * Gets the updated date.
     *
     * @return the updated date
     */
    public Date getUpdatedDate() {
	return updatedDate;
    }

    /**
     * Sets the updated date.
     *
     * @param updatedDate the new updated date
     */
    public void setUpdatedDate(Date updatedDate) {
	this.updatedDate = updatedDate;
    }

    /**
     * Gets the primary firewall name.
     *
     * @return the primary firewall name
     */
    public String getPrimaryFirewallName() {
	return primaryFirewallName;
    }

    /**
     * Sets the primary firewall name.
     *
     * @param primaryFirewallName the new primary firewall name
     */
    public void setPrimaryFirewallName(String primaryFirewallName) {
	this.primaryFirewallName = primaryFirewallName;
    }

    /**
     * Gets the secondary firewall name.
     *
     * @return the secondary firewall name
     */
    public String getSecondaryFirewallName() {
	return secondaryFirewallName;
    }

    /**
     * Sets the secondary firewall name.
     *
     * @param secondaryFirewallName the new secondary firewall name
     */
    public void setSecondaryFirewallName(String secondaryFirewallName) {
	this.secondaryFirewallName = secondaryFirewallName;
    }


    /**
     * @return Returns the created_date.
     */
    /*public Date getCreated_date() {
		return created_date;
	}
     *//**
     * @param created_date The created_date to set.
     *//*
	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
      *//**
      * @return Returns the updated_date.
      *//*
	public Date getUpdated_date() {
		return updated_date;
	}
       *//**
       * @param updated_date The updated_date to set.
       *//*
	public void setUpdated_date(Date updated_date) {
		this.updated_date = updated_date;
	}*/
}
