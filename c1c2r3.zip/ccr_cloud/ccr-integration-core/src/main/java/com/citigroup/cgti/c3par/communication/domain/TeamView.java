/**
 * 
 */
package com.citigroup.cgti.c3par.communication.domain;

import java.util.List;
import java.util.Map;

import com.citigroup.cgti.c3par.common.domain.TIActivityTrail;
import com.citigroup.cgti.c3par.user.domain.C3parUser;

/**
 * @author ka58098
 *
 */
public class TeamView extends BaseView {
    private C3parUser assignedUser;
    private List<TIActivityTrail> tiactivityTrail;
    private List<CMPRequestNotes> cmpRequestNotes;
    private List<Map<String, String>> changeRequestDetails;
    private List<CMPRequestContactXref> cmpRequestContactXrefs;
    private String region;
    private String ecmSector;
    private List<String> changeRequestIDDetails;
    private List<String> changeRequestDateDetails;
    private String agentName;
    private Long elapsedTimer;

    public List<String> getChangeRequestIDDetails() {
        return changeRequestIDDetails;
    }

    public void setChangeRequestIDDetails(List<String> changeRequestIDDetails) {
        this.changeRequestIDDetails = changeRequestIDDetails;
    }

    public List<String> getChangeRequestDateDetails() {
        return changeRequestDateDetails;
    }

    public void setChangeRequestDateDetails(List<String> changeRequestDateDetails) {
        this.changeRequestDateDetails = changeRequestDateDetails;
    }


    public C3parUser getAssignedUser() {
        return assignedUser;
    }

    public void setAssignedUser(C3parUser assignedUser) {
        this.assignedUser = assignedUser;
    }

    public List<TIActivityTrail> getTiactivityTrail() {
        return tiactivityTrail;
    }

    public void setTiactivityTrail(List<TIActivityTrail> tiactivityTrail) {
        this.tiactivityTrail = tiactivityTrail;
    }

    public List<CMPRequestNotes> getCmpRequestNotes() {
        return cmpRequestNotes;
    }

    public void setCmpRequestNotes(List<CMPRequestNotes> cmpRequestNotes) {
        this.cmpRequestNotes = cmpRequestNotes;
    }

    public List<Map<String, String>> getChangeRequestDetails() {
        return changeRequestDetails;
    }

    public void setChangeRequestDetails(List<Map<String, String>> changeRequestDetails) {
        this.changeRequestDetails = changeRequestDetails;
    }

    public List<CMPRequestContactXref> getCmpRequestContactXrefs() {
        return cmpRequestContactXrefs;
    }

    public void setCmpRequestContactXrefs(List<CMPRequestContactXref> cmpRequestContactXrefs) {
        this.cmpRequestContactXrefs = cmpRequestContactXrefs;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getEcmSector() {
        return ecmSector;
    }

    public void setEcmSector(String ecmSector) {
        this.ecmSector = ecmSector;
    }

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

    public Long getElapsedTimer() {
        return elapsedTimer;
    }

    public void setElapsedTimer(Long elapsedTimer) {
        this.elapsedTimer = elapsedTimer;
    }

}
