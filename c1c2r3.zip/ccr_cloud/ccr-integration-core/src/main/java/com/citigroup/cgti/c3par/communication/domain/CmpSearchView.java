/**
 * 
 */
package com.citigroup.cgti.c3par.communication.domain;


import java.util.Date;
import java.util.List;

import com.citigroup.cgti.c3par.common.domain.TIActivityTrail;

/**
 * @author sb99936
 *
 */
public class CmpSearchView extends BaseView {

    /**
     * 
     */
    private static final long serialVersionUID = 18764566L;
    
    private Long assignedUser;
    private List<TIActivityTrail> tiactivityTrail;
    private List<String> changeRequestIDDetails;
    private List<String> changeRequestDateDetails;
    private Date closedDate;
    private Date updatedDate;
    private Date availableDate;
    private String agentName;
    private String isManagerCompleted;
    
    
    public Long getAssignedUser() {
        return assignedUser;
    }

    public void setAssignedUser(Long assignedUser) {
        this.assignedUser = assignedUser;
    }

    /**
     * @return the tiactivityTrail
     */
    public List<TIActivityTrail> getTiactivityTrail() {
        return tiactivityTrail;
    }

    /**
     * @param tiactivityTrail the tiactivityTrail to set
     */
    public void setTiactivityTrail(List<TIActivityTrail> tiactivityTrail) {
        this.tiactivityTrail = tiactivityTrail;
    }

    public List<String> getChangeRequestIDDetails() {
        return changeRequestIDDetails;
    }

    public void setChangeRequestIDDetails(List<String> changeRequestIDDetails) {
        this.changeRequestIDDetails = changeRequestIDDetails;
    }

    public List<String> getChangeRequestDateDetails() {
        return changeRequestDateDetails;
    }

    public void setChangeRequestDateDetails(List<String> changeRequestDateDetails) {
        this.changeRequestDateDetails = changeRequestDateDetails;
    }

	public Date getClosedDate() {
		return closedDate;
	}

	public void setClosedDate(Date closedDate) {
		this.closedDate = closedDate;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public Date getAvailableDate() {
		return availableDate;
	}

	public void setAvailableDate(Date availableDate) {
		this.availableDate = availableDate;
	}

	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

    public String getIsManagerCompleted() {
        return isManagerCompleted;
    }

    public void setIsManagerCompleted(String isManagerCompleted) {
        this.isManagerCompleted = isManagerCompleted;
    }
    
	
}
