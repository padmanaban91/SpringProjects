

/** CONFIDENTIAL  AND PROPRIETARY
 * Copyright @ 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is
 * strictly prohibited.
 */

package com.citigroup.cgti.c3par;

import com.mentisys.dao.schema.*;



/**
 * The Class C3parSchema.
 */
public class C3parSchema extends DatabaseSchema {

    /** The instance. */
    static private C3parSchema instance = null;

    /**
     * Gets the single instance of C3parSchema.
     *
     * @return single instance of C3parSchema
     */
    static public C3parSchema getInstance() {
	if (instance == null) {
	    instance = new C3parSchema();
	}
	return instance;
    }

    /**
     * Instantiates a new c3par schema.
     */
    private C3parSchema() {

	super("c3par");
	// Add all our entities
	addEntityBusinessUnit();
	addEntityCitiContact();
	addEntityBusinessLocationXref();
	addEntityThirdParty();
	addEntityThirdPartyContact();
	addEntityLocation();
	addEntityRelationship();
	addEntityGenericLookupDefs();
	addEntityGenericLookup();
	addEntityConnectionRequest();
	addEntityRole();
	addEntityCitiResource();
	addEntityPrivateLine();
	addEntityVPN();
	addEntityProjectJustificationXref();
	addEntityFacilitiesAffectedXref();
	addEntityThirdPartySubsidaries();
	addEntityThirdPartyCategory();
	addEntityThirdPartyService();
	addEntityDocumentMetaData();
	addEntityCommonLookupData();
	addEntityRelationshipTPContactXref();
	addEntityRelationshipCitiContactXref();
	addEntityRelationshipCitiResourceXref();
	addEntityThirdPartyLocationXref();
	addEntityRelationshipProjectJustificationXref();
	addEntityRelationshipFacilitiesAffectedXref();
	addEntityRelationshipTPServiceXref();
	addEntitySector();
	addEntityRelationshipCitiLocationXref();
	addEntityRelationshipTPLocationXref();
	addEntityOriginalRelationshipDataSource();
	addEntityC3parUsers();
	addEntityC3parUserRoleXref();
	addEntityEntitlementXref();
	addEntityC3PARAccessInfo();
	addEntityAttributeLevelAudit();
	addEntityRelationshipAudit();
	addEntitySecurityRole();
	addEntityLegacyLink();
	addEntityCitiContactXref();
	addEntityTPContactXref();
	addEntityResourceXref();
	addEntityNetworkConnection();
	addEntityPlanning();
	addEntityMaintenance();
	addEntityTermination();
	addEntityTPServiceXref();
	addEntityRegionsImpactedXref();
	addEntityConnection();
	addEntityConnectionProjectJustificationXref();
	addEntityConnectionFacilitiesAffectedXref();
	addEntityConnectionCitiContactXref();
	addEntityConnectionTPContactXref();
	addEntityConnectionTPServiceXref();
	addEntityConnectionResourceXref();
	addEntityMaterialBill();
	addEntityTerminationJustificationXref();
	addEntityPort();
	addEntityRoleReportXref();
	addEntityCitiLocation();
	addEntityProgressBar();
	addEntityPortServiceMapping();
	addEntityIPPair();
	addEntityOstiaAns();
	addEntityIPDetail();
	addEntityFirewallDetails();
	addEntityHierarchyNodeDetail();
	addEntityHierarchyDetail();
	addEntityHierarchyParentDetail();
	addEntityPortFirewallXref();
	addEntityEntitlementNode();
	addEntityRuleEntitlementNodeXref();
	addEntityRule();
	addEntityEntitlementData();
	addEntityEntitlementInstance();
	addEntityC3parUserEntitlementXref();
	addEntityRegion();
	addEntityC3parFunction();
	addEntityC3parRoleFunction();
	addEntityTIProcess();
	addEntityTIApplication();
	addEntityC3parProcessRoleXref();
	addEntityTIProcessType();
	addEntityTIStatusType();
	addEntityTIProcessStatus();
	addEntityTITaskType();
	addEntityTIRequestTask();
	addEntityTIRequest();
	addEntityTIRequestStatus();
	addEntityTIOstiaQuestion();
	addEntityTIRequestType();
	addEntityConnectionFirewallDetails();
	addEntityFirewallMaster();
	addEntityConnectionProcess();
	addEntityResourceType();
	addEntityResourceTypeLocationXref();
	addEntityRelationshipRequesterCitiContactXref();
	addEntityRelationshipRequesterCitiLocationXref();
	addEntityCitiReqContactXref();
	addEntityConnectionCitiReqContactXref();

    }

    /**
     * Adds the entity business unit.
     */
    private void addEntityBusinessUnit() {

	EntityDefinition ed = new EntityDefinition("BusinessUnit");

	// Add all our attributes
	ed.addAttribute("businessName", "String", 200);
	ed.addAttribute("costCenter", "String", 10);
	ed.addAttribute("description", "String", 500);
	ed.addAttribute("isActive", "String", 1);

	// All all our references
	ed.addReference("CitiContact", false, true,  false , "CitiContact");
	ed.addReference("location", true, true,  false , "BusinessLocationXref");
	ed.addReference("sector", false, false,  false , "Sector");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity citi contact.
     */
    private void addEntityCitiContact() {

	EntityDefinition ed = new EntityDefinition("CitiContact");

	// Add all our attributes
	ed.addAttribute("firstName", "String", 100);
	ed.addAttribute("lastName", "String", 100);
	ed.addAttribute("ritsId", "String", 100);
	ed.addAttribute("itlc", "String", 100);
	ed.addAttribute("organization", "String", 100);
	ed.addAttribute("phone", "String", 25);
	ed.addAttribute("email", "String", 50);
	ed.addAttribute("ssoId", "String", 100);

	// All all our references
	ed.addReference("businessunit", false, false,  false , "BusinessUnit");
	ed.addReference("location", true, false,  false , "Location");
	ed.addReference("resourceType", false, false,  false , "ResourceType");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity business location xref.
     */
    private void addEntityBusinessLocationXref() {

	EntityDefinition ed = new EntityDefinition("BusinessLocationXref");

	// Add all our attributes

	// All all our references
	ed.addReference("businessUnit", false, false,  false , "BusinessUnit");
	ed.addReference("location", false, false,  false , "Location");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity third party.
     */
    private void addEntityThirdParty() {

	EntityDefinition ed = new EntityDefinition("ThirdParty");

	// Add all our attributes
	ed.addAttribute("name", "String", 100);
	ed.addAttribute("description", "String", 500);
	ed.addAttribute("caspId", "Long", 0);
	ed.addAttribute("source", "String", 100);
	ed.addAttribute("parentId", "Long", 0);
	ed.addAttribute("parentName", "String", 150);
	ed.addAttribute("region", "String", 100);
	ed.addAttribute("country", "String", 100);
	ed.addAttribute("mainCategory", "String", 100);
	ed.addAttribute("subCategory", "String", 100);
	ed.addAttribute("detailId", "Long", 0);

	// All all our references
	ed.addReference("contact", true, true,  false , "ThirdPartyContact");
	ed.addReference("ThirdPartySubsidaries", true, true,  false , "ThirdPartySubsidaries");
	ed.addReference("location", true, true,  true, "ThirdPartyLocationXref");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity third party contact.
     */
    private void addEntityThirdPartyContact() {

	EntityDefinition ed = new EntityDefinition("ThirdPartyContact");

	// Add all our attributes
	ed.addAttribute("firstName", "String", 100);
	ed.addAttribute("lastName", "String", 100);
	ed.addAttribute("department", "String", 100);
	ed.addAttribute("email", "String", 50);
	ed.addAttribute("phone", "String", 25);
	ed.addAttribute("cellPhone", "String", 25);
	ed.addAttribute("pager", "String", 50);

	// All all our references
	ed.addReference("thirdparty", false, false,  false , "ThirdParty");
	ed.addReference("location", true, false,  false , "Location");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity location.
     */
    private void addEntityLocation() {

	EntityDefinition ed = new EntityDefinition("Location");

	// Add all our attributes
	ed.addAttribute("address", "String", 100);
	ed.addAttribute("address2", "String", 100);
	ed.addAttribute("city", "String", 100);
	ed.addAttribute("state", "String", 100);
	ed.addAttribute("zip", "String", 25);
	ed.addAttribute("department", "String", 100);
	ed.addAttribute("assesmentId", "String", 150);
	ed.addAttribute("asessmentDesc", "String", 250);
	ed.addAttribute("siteDetailId", "Long", 0);

	// All all our references
	ed.addReference("country", false, false,  false , "GenericLookup");
	ed.addReference("region", false, false,  false , "GenericLookup");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity relationship.
     */
    private void addEntityRelationship() {

	EntityDefinition ed = new EntityDefinition("Relationship");

	// Add all our attributes
	ed.addAttribute("name", "String", 350);
	ed.addAttribute("purpose", "String", 4000);
	ed.addAttribute("connectivityExists", "String", 10000);
	ed.addAttribute("readyDate", "Date", 0);
	ed.addAttribute("terminatedDate", "Date", 0);
	ed.addAttribute("status", "String", 25);
	ed.addAttribute("relationshipId", "Long", 0);
	ed.addAttribute("requesterId", "String", 50);
	ed.addAttribute("benefit", "String", 250);
	ed.addAttribute("plcode", "String", 100);
	ed.addAttribute("estimatedRevenueGenerated", "Double", 0);
	ed.addAttribute("estimatedCostSaving", "Double", 0);
	ed.addAttribute("cobRedundancyRequired", "Boolean", 0);
	ed.addAttribute("procurementCompletionDate", "Date", 0);
	ed.addAttribute("gnccApprovalAttained", "Boolean", 0);
	ed.addAttribute("comments", "String", 2000);
	ed.addAttribute("initialRiskAssesmentDate", "Date", 0);
	ed.addAttribute("oneTimeCost", "Double", 0);
	ed.addAttribute("monthlyCost", "Double", 0);
	ed.addAttribute("dataIsPublic", "Boolean", 0);
	ed.addAttribute("isOutsourceProvider", "String", 10000);
	ed.addAttribute("ospServiceName", "String", 100);
	ed.addAttribute("accessCitiData", "String", 10000);
	ed.addAttribute("accessCustomerData", "String", 10000);
	ed.addAttribute("contractRenewalDate", "Date", 0);
	ed.addAttribute("deleted", "Boolean", 0);
	ed.addAttribute("requestDate", "Date", 0);
	ed.addAttribute("entInstanceId", "Long", 0);
	ed.addAttribute("relationshipType", "String", 50);

	// All all our references
	ed.addReference("lookup", true, false,  false , "CommonLookupData");
	ed.addReference("thirdPartyContact", true, true,  false , "RelationshipTPContactXref");
	ed.addReference("citiContact", true, true,  false , "RelationshipCitiContactXref");
	ed.addReference("resource", true, true,  false , "RelationshipCitiResourceXref");
	ed.addReference("projectJustification", true, true,  false , "RelationshipProjectJustificationXref");
	ed.addReference("facilitiesAffected", true, true,  false , "RelationshipFacilitiesAffectedXref");
	ed.addReference("service", true, true,  false , "RelationshipTPServiceXref");
	ed.addReference("businessUnit", false, false,  false , "BusinessUnit");
	ed.addReference("citiLocation", true, true,  false , "RelationshipCitiLocationXref");
	ed.addReference("thirdParty", false, false,  false , "ThirdParty");
	ed.addReference("thirdPartyLocation", true, true,  false , "RelationshipTPLocationXref");
	ed.addReference("ownedby", true, false,  false , "EntitlementXref");
	ed.addReference("connections", false, true,  false , "Connection");
	ed.addReference("targetResourceType", false, false,  false , "ResourceType");
	ed.addReference("requesterResourceType", false, false,  false , "ResourceType");
	ed.addReference("citiReqContact", true, true,  false , "RelationshipRequesterCitiContactXref");
	ed.addReference("reqCitiLocation", true, true,  false , "RelationshipRequesterCitiLocationXref");
	ed.addReference("uturnThirdParty", false, false,  false , "ThirdParty");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity generic lookup defs.
     */
    private void addEntityGenericLookupDefs() {

	EntityDefinition ed = new EntityDefinition("GenericLookupDefs");

	// Add all our attributes
	ed.addAttribute("name", "String", 50);
	ed.addAttribute("label1", "String", 50);
	ed.addAttribute("label2", "String", 50);

	// All all our references
	ed.addReference("lookups", true, true,  false , "GenericLookup");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity generic lookup.
     */
    private void addEntityGenericLookup() {

	EntityDefinition ed = new EntityDefinition("GenericLookup");

	// Add all our attributes
	ed.addAttribute("value1", "String", 50);
	ed.addAttribute("value2", "String", 50);
	ed.addAttribute("deleted", "Boolean", 0);

	// All all our references
	ed.addReference("definition", false, false,  false , "GenericLookupDefs");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity connection request.
     */
    private void addEntityConnectionRequest() {

	EntityDefinition ed = new EntityDefinition("ConnectionRequest");

	// Add all our attributes
	ed.addAttribute("requireNetworkAccess", "Boolean", 0);
	ed.addAttribute("rationale", "String", 1000);
	ed.addAttribute("benefit", "String", 500);
	ed.addAttribute("plcode", "String", 25);
	ed.addAttribute("estimatedRevenueGenerated", "Double", 0);
	ed.addAttribute("estimatedCostSaving", "Double", 0);
	ed.addAttribute("cobRedundancyRequired", "Boolean", 0);
	ed.addAttribute("connectionName", "String", 150);
	ed.addAttribute("status", "String", 100);
	ed.addAttribute("requesterId", "String", 100);
	ed.addAttribute("semiAnnualEntitlementReview", "Boolean", 0);
	ed.addAttribute("issConnectionCompliance", "String", 1000);
	ed.addAttribute("citiPolicyAdherence", "String", 1);
	ed.addAttribute("accessCitiGlobalNetwork", "Boolean", 0);
	ed.addAttribute("tpTrainingAwarnessProgram", "Boolean", 0);
	ed.addAttribute("sponsorBusinessConsulted", "Boolean", 0);
	ed.addAttribute("exportLicenseCordinator", "Boolean", 0);

	// All all our references
	ed.addReference("facilitiesAffected", true, true,  false , "FacilitiesAffectedXref");
	ed.addReference("projectJustifications", true, true,  false , "ProjectJustificationXref");
	ed.addReference("citiContacts", true, true,  true, "CitiContactXref");
	ed.addReference("tpContacts", true, true,  true, "TPContactXref");
	ed.addReference("lookup", true, false,  false , "CommonLookupData");
	ed.addReference("resources", true, true,  true, "ResourceXref");
	ed.addReference("document", true, true,  false , "DocumentMetaData");
	ed.addReference("netCon", false, false,  false , "NetworkConnection");
	ed.addReference("services", true, true,  true, "TPServiceXref");
	ed.addReference("relationship", false, false,  false , "Relationship");
	ed.addReference("materialBill", true, true,  true, "MaterialBill");
	ed.addReference("firewalls", true, true,  false , "FirewallDetails");
	ed.addReference("connectionrequest", true, true,  true, "ConnectionProcess");
	ed.addReference("citiReqContacts", true, true,  true, "CitiReqContactXref");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity role.
     */
    private void addEntityRole() {

	EntityDefinition ed = new EntityDefinition("Role");

	// Add all our attributes
	ed.addAttribute("name", "String", 100);
	ed.addAttribute("citi", "Boolean", 0);
	ed.addAttribute("displayName", "String", 50);

	// All all our references

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity citi resource.
     */
    private void addEntityCitiResource() {

	EntityDefinition ed = new EntityDefinition("CitiResource");

	// Add all our attributes
	ed.addAttribute("name", "String", 100);
	ed.addAttribute("resourceid", "String", 100);
	ed.addAttribute("owner", "String", 100);
	ed.addAttribute("alternateType", "String", 100);
	ed.addAttribute("envDescription", "String", 500);
	ed.addAttribute("functionalityDescription", "String", 500);
	ed.addAttribute("ipAddress", "String", 15);
	ed.addAttribute("url", "String", 100);
	ed.addAttribute("dnsName", "String", 100);
	ed.addAttribute("isRegisteredInSource", "Boolean", 0);
	ed.addAttribute("cwhiId", "Long", 0);
	ed.addAttribute("ownerid", "String", 100);

	// All all our references
	ed.addReference("preferedType", false, false,  false , "GenericLookup");
	ed.addReference("criticality", false, false,  false , "GenericLookup");
	ed.addReference("classification", false, false,  false , "GenericLookup");
	ed.addReference("accessType", false, false,  false , "GenericLookup");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity private line.
     */
    private void addEntityPrivateLine() {

	EntityDefinition ed = new EntityDefinition("PrivateLine");

	// Add all our attributes
	ed.addAttribute("circuitCollectionId", "String", 50);

	// All all our references
	ed.addReference("citiRouterName", false, false,  false , "GenericLookup");
	ed.addReference("citiInterface", false, false,  false , "GenericLookup");
	ed.addReference("citiSubInterface", false, false,  false , "GenericLookup");
	ed.addReference("remoteRouterName", false, false,  false , "GenericLookup");
	ed.addReference("remoteInterface", false, false,  false , "GenericLookup");
	ed.addReference("remoteSubInterface", false, false,  false , "GenericLookup");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity vpn.
     */
    private void addEntityVPN() {

	EntityDefinition ed = new EntityDefinition("VPN");

	// Add all our attributes
	ed.addAttribute("circuitCollectionId", "String", 50);
	ed.addAttribute("cepPod", "String", 50);
	ed.addAttribute("peerIp", "String", 15);

	// All all our references
	ed.addReference("citiRouterName", false, false,  false , "GenericLookup");
	ed.addReference("remoteRouterName", false, false,  false , "GenericLookup");
	ed.addReference("policyNumber", false, false,  false , "GenericLookup");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity project justification xref.
     */
    private void addEntityProjectJustificationXref() {

	EntityDefinition ed = new EntityDefinition("ProjectJustificationXref");

	// Add all our attributes

	// All all our references
	ed.addReference("request", false, false,  false , "ConnectionRequest");
	ed.addReference("projectJustification", false, false,  false , "GenericLookup");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity facilities affected xref.
     */
    private void addEntityFacilitiesAffectedXref() {

	EntityDefinition ed = new EntityDefinition("FacilitiesAffectedXref");

	// Add all our attributes

	// All all our references
	ed.addReference("facilitiesAffected", false, false,  false , "GenericLookup");
	ed.addReference("request", false, false,  false , "ConnectionRequest");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity third party subsidaries.
     */
    private void addEntityThirdPartySubsidaries() {

	EntityDefinition ed = new EntityDefinition("ThirdPartySubsidaries");

	// Add all our attributes
	ed.addAttribute("name", "String", 200);

	// All all our references
	ed.addReference("ThirdParty", false, false,  false , "ThirdParty");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity third party category.
     */
    private void addEntityThirdPartyCategory() {

	EntityDefinition ed = new EntityDefinition("ThirdPartyCategory");

	// Add all our attributes
	ed.addAttribute("name", "String", 100);

	// All all our references
	ed.addReference("service", true, true,  true, "ThirdPartyService");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity third party service.
     */
    private void addEntityThirdPartyService() {

	EntityDefinition ed = new EntityDefinition("ThirdPartyService");

	// Add all our attributes
	ed.addAttribute("name", "String", 100);

	// All all our references
	ed.addReference("category", false, false,  false , "ThirdPartyCategory");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity document meta data.
     */
    private void addEntityDocumentMetaData() {

	EntityDefinition ed = new EntityDefinition("DocumentMetaData");

	// Add all our attributes
	ed.addAttribute("name", "String", 4000);
	ed.addAttribute("type", "String", 100);
	ed.addAttribute("contentType", "String", 150);

	// All all our references
	ed.addReference("request", false, false,  false , "ConnectionRequest");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity common lookup data.
     */
    private void addEntityCommonLookupData() {

	EntityDefinition ed = new EntityDefinition("CommonLookupData");

	// Add all our attributes
	ed.addAttribute("isPublic", "Boolean", 0);

	// All all our references
	ed.addReference("expDataInfoSize", false, false,  false , "GenericLookup");
	ed.addReference("expDataFeq", false, false,  false , "GenericLookup");
	ed.addReference("citigroupData", false, false,  false , "GenericLookup");
	ed.addReference("criticality", false, false,  false , "GenericLookup");
	ed.addReference("customerData", false, false,  false , "GenericLookup");
	ed.addReference("relationship", false, false,  false , "Relationship");
	ed.addReference("connectionType", false, false,  false , "GenericLookup");
	ed.addReference("classification", false, false,  false , "GenericLookup");
	ed.addReference("request", false, false,  false , "ConnectionRequest");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity relationship tp contact xref.
     */
    private void addEntityRelationshipTPContactXref() {

	EntityDefinition ed = new EntityDefinition("RelationshipTPContactXref");

	// Add all our attributes

	// All all our references
	ed.addReference("relationship", false, false,  false , "Relationship");
	ed.addReference("role", false, false,  false , "Role");
	ed.addReference("tpContact", false, false,  false , "ThirdPartyContact");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity relationship citi contact xref.
     */
    private void addEntityRelationshipCitiContactXref() {

	EntityDefinition ed = new EntityDefinition("RelationshipCitiContactXref");

	// Add all our attributes

	// All all our references
	ed.addReference("relationship", false, false,  false , "Relationship");
	ed.addReference("contact", false, false,  false , "CitiContact");
	ed.addReference("role", false, false,  false , "Role");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity relationship citi resource xref.
     */
    private void addEntityRelationshipCitiResourceXref() {

	EntityDefinition ed = new EntityDefinition("RelationshipCitiResourceXref");

	// Add all our attributes

	// All all our references
	ed.addReference("relationship", false, false,  false , "Relationship");
	ed.addReference("resource", false, false,  false , "CitiResource");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity third party location xref.
     */
    private void addEntityThirdPartyLocationXref() {

	EntityDefinition ed = new EntityDefinition("ThirdPartyLocationXref");

	// Add all our attributes

	// All all our references
	ed.addReference("thirdparty", false, false,  false , "ThirdParty");
	ed.addReference("location", false, false,  false , "Location");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity relationship project justification xref.
     */
    private void addEntityRelationshipProjectJustificationXref() {

	EntityDefinition ed = new EntityDefinition("RelationshipProjectJustificationXref");

	// Add all our attributes

	// All all our references
	ed.addReference("relationship", false, false,  false , "Relationship");
	ed.addReference("projectJustification", false, false,  false , "GenericLookup");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity relationship facilities affected xref.
     */
    private void addEntityRelationshipFacilitiesAffectedXref() {

	EntityDefinition ed = new EntityDefinition("RelationshipFacilitiesAffectedXref");

	// Add all our attributes

	// All all our references
	ed.addReference("relationship", false, false,  false , "Relationship");
	ed.addReference("facilitiesAffected", false, false,  false , "GenericLookup");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity relationship tp service xref.
     */
    private void addEntityRelationshipTPServiceXref() {

	EntityDefinition ed = new EntityDefinition("RelationshipTPServiceXref");

	// Add all our attributes

	// All all our references
	ed.addReference("relationship", false, false,  false , "Relationship");
	ed.addReference("service", false, false,  false , "ThirdPartyService");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity sector.
     */
    private void addEntitySector() {

	EntityDefinition ed = new EntityDefinition("Sector");

	// Add all our attributes
	ed.addAttribute("name", "String", 100);
	ed.addAttribute("isActive", "String", 1);
	ed.addAttribute("description", "String", 4000);

	// All all our references
	ed.addReference("businessUnit", false, true,  true, "BusinessUnit");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity relationship citi location xref.
     */
    private void addEntityRelationshipCitiLocationXref() {

	EntityDefinition ed = new EntityDefinition("RelationshipCitiLocationXref");

	// Add all our attributes

	// All all our references
	ed.addReference("relationship", false, false,  false , "Relationship");
	ed.addReference("location", false, false,  false , "Location");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity relationship tp location xref.
     */
    private void addEntityRelationshipTPLocationXref() {

	EntityDefinition ed = new EntityDefinition("RelationshipTPLocationXref");

	// Add all our attributes

	// All all our references
	ed.addReference("relationship", false, false,  false , "Relationship");
	ed.addReference("location", false, false,  false , "Location");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity original relationship data source.
     */
    private void addEntityOriginalRelationshipDataSource() {

	EntityDefinition ed = new EntityDefinition("OriginalRelationshipDataSource");

	// Add all our attributes
	ed.addAttribute("etoolsId", "Long", 0);

	// All all our references
	ed.addReference("relationship", false, false,  false , "Relationship");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity c3par users.
     */
    private void addEntityC3parUsers() {

	EntityDefinition ed = new EntityDefinition("C3parUsers");

	// Add all our attributes
	ed.addAttribute("ssoId", "String", 50);
	ed.addAttribute("firstName", "String", 100);
	ed.addAttribute("lastName", "String", 100);
	ed.addAttribute("description", "String", 250);
	ed.addAttribute("isActive", "String", 1);
	ed.addAttribute("isAdmin", "Boolean", 0);
	ed.addAttribute("password", "String", 50);
	ed.addAttribute("email", "String", 150);
	ed.addAttribute("createdUser", "String", 25);
	ed.addAttribute("createdDate", "Date", 0);
	ed.addAttribute("updatedUser", "String", 25);
	ed.addAttribute("updatedDate", "Date", 0);
	ed.addAttribute("wfStatus", "String", 25);
	ed.addAttribute("nonEmployee", "String", 1);
	ed.addAttribute("requestedBy", "String", 25);
	ed.addAttribute("isaApprover", "String", 25);
	ed.addAttribute("managerApprover", "String", 25);
	ed.addAttribute("rejectionComments", "String", 255);
	ed.addAttribute("activatedDate", "Date", 0);
	ed.addAttribute("mgrReviewedDate", "Date", 0);
	ed.addAttribute("isaReviewedDate", "Date", 0);
	ed.addAttribute("requestedDate", "Date", 0);
	ed.addAttribute("sysadminApprover", "String", 10000);
	ed.addAttribute("sysadminReviewedDate", "Date", 0);

	// All all our references
	ed.addReference("role", true, true,  false , "C3parUserRoleXref");
	ed.addReference("userEntitlements", true, true,  false , "C3parUserEntitlementXref");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity c3par user role xref.
     */
    private void addEntityC3parUserRoleXref() {

	EntityDefinition ed = new EntityDefinition("C3parUserRoleXref");

	// Add all our attributes

	// All all our references
	ed.addReference("user", false, false,  false , "C3parUsers");
	ed.addReference("role", false, false,  false , "SecurityRole");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity entitlement xref.
     */
    private void addEntityEntitlementXref() {

	EntityDefinition ed = new EntityDefinition("EntitlementXref");

	// Add all our attributes
	ed.addAttribute("entityName", "String", 50);

	// All all our references
	ed.addReference("relationship", false, false,  false , "Relationship");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity c3 par access info.
     */
    private void addEntityC3PARAccessInfo() {

	EntityDefinition ed = new EntityDefinition("C3PARAccessInfo");

	// Add all our attributes
	ed.addAttribute("userId", "String", 15);
	ed.addAttribute("actionPerformed", "String", 100);
	ed.addAttribute("actionTime", "Date", 0);

	// All all our references

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity attribute level audit.
     */
    private void addEntityAttributeLevelAudit() {

	EntityDefinition ed = new EntityDefinition("AttributeLevelAudit");

	// Add all our attributes
	ed.addAttribute("oldValue", "String", 500);
	ed.addAttribute("newValue", "String", 500);
	ed.addAttribute("action", "String", 50);
	ed.addAttribute("name", "String", 100);

	// All all our references
	ed.addReference("audit", false, false,  false , "RelationshipAudit");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity relationship audit.
     */
    private void addEntityRelationshipAudit() {

	EntityDefinition ed = new EntityDefinition("RelationshipAudit");

	// Add all our attributes
	ed.addAttribute("entityName", "String", 100);
	ed.addAttribute("modifiedBy", "String", 100);
	ed.addAttribute("owner", "String", 100);
	ed.addAttribute("dateChanged", "Date", 0);
	ed.addAttribute("entityId", "Long", 0);

	// All all our references
	ed.addReference("attributeChanged", true, true,  true, "AttributeLevelAudit");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity security role.
     */
    private void addEntitySecurityRole() {

	EntityDefinition ed = new EntityDefinition("SecurityRole");

	// Add all our attributes
	ed.addAttribute("name", "String", 50);
	ed.addAttribute("description", "String", 500);
	ed.addAttribute("displayName", "String", 50);

	// All all our references
	ed.addReference("function", true, true,  false , "C3parRoleFunction");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity legacy link.
     */
    private void addEntityLegacyLink() {

	EntityDefinition ed = new EntityDefinition("LegacyLink");

	// Add all our attributes
	ed.addAttribute("entityType", "String", 200);
	ed.addAttribute("legacyId", "Long", 0);
	ed.addAttribute("entityId", "Long", 0);
	ed.addAttribute("groupName", "String", 50);

	// All all our references

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity citi contact xref.
     */
    private void addEntityCitiContactXref() {

	EntityDefinition ed = new EntityDefinition("CitiContactXref");

	// Add all our attributes
	ed.addAttribute("primaryContact", "Boolean", 0);

	// All all our references
	ed.addReference("citiContact", false, false,  false , "CitiContact");
	ed.addReference("role", false, false,  false , "Role");
	ed.addReference("request", false, false,  false , "ConnectionRequest");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity tp contact xref.
     */
    private void addEntityTPContactXref() {

	EntityDefinition ed = new EntityDefinition("TPContactXref");

	// Add all our attributes

	// All all our references
	ed.addReference("tpContact", false, false,  false , "ThirdPartyContact");
	ed.addReference("role", false, false,  false , "Role");
	ed.addReference("request", false, false,  false , "ConnectionRequest");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity resource xref.
     */
    private void addEntityResourceXref() {

	EntityDefinition ed = new EntityDefinition("ResourceXref");

	// Add all our attributes

	// All all our references
	ed.addReference("request", false, false,  false , "ConnectionRequest");
	ed.addReference("resource", false, false,  false , "CitiResource");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity network connection.
     */
    private void addEntityNetworkConnection() {

	EntityDefinition ed = new EntityDefinition("NetworkConnection");

	// Add all our attributes
	ed.addAttribute("splitTunneling", "Boolean", 0);
	ed.addAttribute("splitTunnelingReason", "String", 2000);
	ed.addAttribute("virusContainmentStrategy", "String", 2000);
	ed.addAttribute("accessContainmentStrategy", "String", 2000);
	ed.addAttribute("primaryFirewallName", "String", 150);
	ed.addAttribute("primaryPhyConAddress", "String", 20);
	ed.addAttribute("primaryCircuitId", "String", 100);
	ed.addAttribute("primaryBandwidth", "String", 25);
	ed.addAttribute("secondaryFirewallName", "String", 150);
	ed.addAttribute("secondaryPhyConAddress", "String", 20);
	ed.addAttribute("secondaryCircuitId", "String", 100);
	ed.addAttribute("secondaryBandwidth", "String", 25);

	// All all our references
	ed.addReference("tpLocation", false, false,  false , "Location");
	ed.addReference("citiLocation", true, false,  false , "CitiLocation");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity planning.
     */
    private void addEntityPlanning() {

	EntityDefinition ed = new EntityDefinition("Planning");

	// Add all our attributes
	ed.addAttribute("plannedActivateDate", "Date", 0);
	ed.addAttribute("securityReviewComment", "String", 4000);
	ed.addAttribute("sponsorReviewComments", "String", 4000);
	ed.addAttribute("activateConnectionComment", "String", 4000);
	ed.addAttribute("approveDetailDesignComment", "String", 4000);
	ed.addAttribute("integrationCompleted", "Boolean", 0);
	ed.addAttribute("integrationStatusComments", "String", 4000);
	ed.addAttribute("procurementDate", "Date", 0);
	ed.addAttribute("procurementComments", "String", 4000);
	ed.addAttribute("procurementOptional", "Boolean", 0);
	ed.addAttribute("systemAdminComments", "String", 4000);
	ed.addAttribute("operationalAnalystComments", "String", 4000);
	ed.addAttribute("istgComments", "String", 4000);
	ed.addAttribute("infomanId", "Long", 0);
	ed.addAttribute("opAnalystScheduleDate", "Date", 0);
	ed.addAttribute("opAnalystCompletedDate", "Date", 0);
	ed.addAttribute("vaFlag", "String", 3);
	ed.addAttribute("vaNumber", "String", 20);
	ed.addAttribute("vaSchDate", "Date", 0);
	ed.addAttribute("vaComments", "String", 2000);

	// All all our references

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity maintenance.
     */
    private void addEntityMaintenance() {

	EntityDefinition ed = new EntityDefinition("Maintenance");

	// Add all our attributes
	ed.addAttribute("requestComment", "String", 4000);
	ed.addAttribute("updateType", "String", 100);
	ed.addAttribute("status", "String", 100);

	// All all our references
	ed.addReference("connection", false, false,  false , "Connection");
	ed.addReference("planning", false, false,  false , "Planning");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity termination.
     */
    private void addEntityTermination() {

	EntityDefinition ed = new EntityDefinition("Termination");

	// Add all our attributes
	ed.addAttribute("infomanId", "Long", 0);
	ed.addAttribute("requestComment", "String", 4000);
	ed.addAttribute("requesterId", "String", 100);
	ed.addAttribute("reviewComment", "String", 4000);
	ed.addAttribute("terminateComment", "String", 4000);
	ed.addAttribute("status", "String", 100);
	ed.addAttribute("terminationDate", "Date", 0);
	ed.addAttribute("systemAdminComments", "String", 4000);
	ed.addAttribute("opAnalystScheduleDate", "Date", 0);
	ed.addAttribute("opAnalystCompletedDate", "Date", 0);
	ed.addAttribute("operationalAnalystComments", "String", 4000);
	ed.addAttribute("projectCoordinatorComments", "String", 4000);

	// All all our references
	ed.addReference("regionsImpacted", true, true,  false , "RegionsImpactedXref");
	ed.addReference("connection", false, false,  false , "Connection");
	ed.addReference("justifications", true, true,  false , "TerminationJustificationXref");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity tp service xref.
     */
    private void addEntityTPServiceXref() {

	EntityDefinition ed = new EntityDefinition("TPServiceXref");

	// Add all our attributes

	// All all our references
	ed.addReference("service", false, false,  false , "ThirdPartyService");
	ed.addReference("request", false, false,  false , "ConnectionRequest");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity regions impacted xref.
     */
    private void addEntityRegionsImpactedXref() {

	EntityDefinition ed = new EntityDefinition("RegionsImpactedXref");

	// Add all our attributes

	// All all our references
	ed.addReference("terminationRequest", false, false,  false , "Termination");
	ed.addReference("regions", false, false,  false , "GenericLookup");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity connection.
     */
    private void addEntityConnection() {

	EntityDefinition ed = new EntityDefinition("Connection");

	// Add all our attributes
	ed.addAttribute("name", "String", 150);
	ed.addAttribute("status", "String", 100);
	ed.addAttribute("requesterId", "String", 100);
	ed.addAttribute("rationale", "String", 1000);
	ed.addAttribute("benefit", "String", 500);
	ed.addAttribute("plcode", "String", 25);
	ed.addAttribute("requireNetworkAccess", "Boolean", 0);
	ed.addAttribute("estimatedRevenueGenerated", "Double", 0);
	ed.addAttribute("estimatedCostSaving", "Double", 0);
	ed.addAttribute("cobRedundancyRequired", "Boolean", 0);
	ed.addAttribute("requestDate", "Date", 0);
	ed.addAttribute("readyDate", "Date", 0);
	ed.addAttribute("comments", "String", 4000);
	ed.addAttribute("semiAnnualEntitlementReview", "Boolean", 0);
	ed.addAttribute("issConnectionCompliance", "String", 2000);
	ed.addAttribute("citiPolicyAdherence", "String", 1);
	ed.addAttribute("accessCitiGlobalNetwork", "Boolean", 0);
	ed.addAttribute("tpTrainingAwarnessProgram", "Boolean", 0);
	ed.addAttribute("securityReviewComments", "String", 4000);
	ed.addAttribute("sponsorReviewComments", "String", 4000);
	ed.addAttribute("activateConComments", "String", 4000);
	ed.addAttribute("approveDesignComments", "String", 4000);
	ed.addAttribute("integrationStatusComments", "String", 4000);
	ed.addAttribute("procurementDate", "Date", 0);
	ed.addAttribute("procurementComments", "String", 4000);
	ed.addAttribute("connectionRequestId", "Long", 0);
	ed.addAttribute("systemAdminComments", "String", 4000);
	ed.addAttribute("infomanId", "Long", 0);
	ed.addAttribute("opAnalystScheduleDate", "Date", 0);
	ed.addAttribute("opAnalystCompletedDate", "Date", 0);
	ed.addAttribute("operationalAnalystComments", "String", 4000);
	ed.addAttribute("istgComments", "String", 4000);
	ed.addAttribute("sponsorBusinessConsulted", "Boolean", 0);
	ed.addAttribute("exportLicenseCordinator", "Boolean", 0);

	// All all our references
	ed.addReference("projectJustifications", true, true,  false , "ConnectionProjectJustificationXref");
	ed.addReference("facilitiesAffected", true, true,  false , "ConnectionFacilitiesAffectedXref");
	ed.addReference("lookup", false, false,  false , "CommonLookupData");
	ed.addReference("citiContacts", true, true,  false , "ConnectionCitiContactXref");
	ed.addReference("tpContacts", true, true,  false , "ConnectionTPContactXref");
	ed.addReference("resources", true, true,  false , "ConnectionResourceXref");
	ed.addReference("services", true, true,  false , "ConnectionTPServiceXref");
	ed.addReference("relationship", false, false,  false , "Relationship");
	ed.addReference("netCon", false, false,  false , "NetworkConnection");
	ed.addReference("materialBills", true, true,  false , "MaterialBill");
	ed.addReference("firewalls", true, true,  false , "FirewallDetails");
	ed.addReference("citiReqContacts", true, true,  false , "ConnectionCitiReqContactXref");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity connection project justification xref.
     */
    private void addEntityConnectionProjectJustificationXref() {

	EntityDefinition ed = new EntityDefinition("ConnectionProjectJustificationXref");

	// Add all our attributes

	// All all our references
	ed.addReference("connection", false, false,  false , "Connection");
	ed.addReference("projectJustification", false, false,  false , "GenericLookup");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity connection facilities affected xref.
     */
    private void addEntityConnectionFacilitiesAffectedXref() {

	EntityDefinition ed = new EntityDefinition("ConnectionFacilitiesAffectedXref");

	// Add all our attributes

	// All all our references
	ed.addReference("connection", false, false,  false , "Connection");
	ed.addReference("facilitiesAffected", false, false,  false , "GenericLookup");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity connection citi contact xref.
     */
    private void addEntityConnectionCitiContactXref() {

	EntityDefinition ed = new EntityDefinition("ConnectionCitiContactXref");

	// Add all our attributes
	ed.addAttribute("primaryContact", "Boolean", 0);

	// All all our references
	ed.addReference("connection", false, false,  false , "Connection");
	ed.addReference("role", false, false,  false , "Role");
	ed.addReference("citiContact", false, false,  false , "CitiContact");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity connection tp contact xref.
     */
    private void addEntityConnectionTPContactXref() {

	EntityDefinition ed = new EntityDefinition("ConnectionTPContactXref");

	// Add all our attributes

	// All all our references
	ed.addReference("connection", false, false,  false , "Connection");
	ed.addReference("tpContact", false, false,  false , "ThirdPartyContact");
	ed.addReference("role", false, false,  false , "Role");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity connection tp service xref.
     */
    private void addEntityConnectionTPServiceXref() {

	EntityDefinition ed = new EntityDefinition("ConnectionTPServiceXref");

	// Add all our attributes

	// All all our references
	ed.addReference("connection", false, false,  false , "Connection");
	ed.addReference("service", false, false,  false , "ThirdPartyService");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity connection resource xref.
     */
    private void addEntityConnectionResourceXref() {

	EntityDefinition ed = new EntityDefinition("ConnectionResourceXref");

	// Add all our attributes

	// All all our references
	ed.addReference("connection", false, false,  false , "Connection");
	ed.addReference("resource", false, false,  false , "CitiResource");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity material bill.
     */
    private void addEntityMaterialBill() {

	EntityDefinition ed = new EntityDefinition("MaterialBill");

	// Add all our attributes
	ed.addAttribute("item", "String", 250);
	ed.addAttribute("oneTimeCost", "Double", 0);
	ed.addAttribute("monthlyCost", "Double", 0);
	ed.addAttribute("serialNumber", "String", 150);

	// All all our references
	ed.addReference("ConnectionRequest", false, false,  false , "ConnectionRequest");
	ed.addReference("connection", false, false,  false , "Connection");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity termination justification xref.
     */
    private void addEntityTerminationJustificationXref() {

	EntityDefinition ed = new EntityDefinition("TerminationJustificationXref");

	// Add all our attributes

	// All all our references
	ed.addReference("terminationRequest", false, false,  false , "Termination");
	ed.addReference("justification", false, false,  false , "GenericLookup");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity port.
     */
    private void addEntityPort() {

	EntityDefinition ed = new EntityDefinition("Port");

	// Add all our attributes
	ed.addAttribute("applicationName", "String", 250);
	ed.addAttribute("portNumber", "String", 50);
	ed.addAttribute("protocol", "String", 100);
	ed.addAttribute("flowOfData", "String", 100);
	ed.addAttribute("justification", "String", 2000);

	// All all our references
	ed.addReference("answers", true, true,  false , "OstiaAns");
	ed.addReference("ipPair", false, false,  false , "IPPair");
	ed.addReference("firewalls", true, true,  false , "PortFirewallXref");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity role report xref.
     */
    private void addEntityRoleReportXref() {

	EntityDefinition ed = new EntityDefinition("RoleReportXref");

	// Add all our attributes
	ed.addAttribute("reportId", "Long", 0);

	// All all our references
	ed.addReference("role", false, false,  false , "SecurityRole");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity citi location.
     */
    private void addEntityCitiLocation() {

	EntityDefinition ed = new EntityDefinition("CitiLocation");

	// Add all our attributes
	ed.addAttribute("address1", "String", 250);
	ed.addAttribute("address2", "String", 250);
	ed.addAttribute("city", "String", 250);
	ed.addAttribute("county", "String", 250);
	ed.addAttribute("region", "String", 250);
	ed.addAttribute("country", "String", 250);
	ed.addAttribute("remsId", "Long", 0);
	ed.addAttribute("primaryId", "Long", 0);

	// All all our references
	ed.addReference("networkConnection", false, false,  false , "NetworkConnection");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity progress bar.
     */
    private void addEntityProgressBar() {

	EntityDefinition ed = new EntityDefinition("ProgressBar");

	// Add all our attributes
	ed.addAttribute("activityName", "String", 150);
	ed.addAttribute("role", "String", 150);
	ed.addAttribute("status", "String", 150);
	ed.addAttribute("statusDisplayValue", "String", 250);
	ed.addAttribute("context", "String", 150);
	ed.addAttribute("activity_order", "Long", 0);
	ed.addAttribute("required", "Boolean", 0);
	ed.addAttribute("progressImage", "String", 500);
	ed.addAttribute("process", "String", 250);
	ed.addAttribute("processType", "String", 250);

	// All all our references

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity port service mapping.
     */
    private void addEntityPortServiceMapping() {

	EntityDefinition ed = new EntityDefinition("PortServiceMapping");

	// Add all our attributes
	ed.addAttribute("portId", "Long", 0);
	ed.addAttribute("serviceType", "String", 250);
	ed.addAttribute("description", "String", 1000);

	// All all our references

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity ip pair.
     */
    private void addEntityIPPair() {

	EntityDefinition ed = new EntityDefinition("IPPair");

	// Add all our attributes
	ed.addAttribute("name", "String", 100);
	ed.addAttribute("resourceId", "Long", 0);
	ed.addAttribute("nATAddress", "String", 100);
	ed.addAttribute("ipA", "String", 15);
	ed.addAttribute("ipB", "String", 15);
	ed.addAttribute("connectionRequestId", "Long", 0);
	ed.addAttribute("connectionId", "Long", 0);

	// All all our references
	ed.addReference("ports", true, true,  true, "Port");
	ed.addReference("application", false, false,  false , "TIApplication");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity ostia ans.
     */
    private void addEntityOstiaAns() {

	EntityDefinition ed = new EntityDefinition("OstiaAns");

	// Add all our attributes
	ed.addAttribute("answer", "String", 4000);
	ed.addAttribute("questionNumber", "Long", 0);

	// All all our references
	ed.addReference("Port", false, false,  false , "Port");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity ip detail.
     */
    private void addEntityIPDetail() {

	EntityDefinition ed = new EntityDefinition("IPDetail");

	// Add all our attributes
	ed.addAttribute("ip", "String", 255);
	ed.addAttribute("type", "String", 1);
	ed.addAttribute("startIP", "String", 20);
	ed.addAttribute("endIP", "String", 20);
	ed.addAttribute("subnet", "String", 20);
	ed.addAttribute("noOfHost", "Long", 0);
	ed.addAttribute("broadCastAddress", "String", 20);
	ed.addAttribute("ipDestination", "String", 20);
	ed.addAttribute("connectionRequestId", "Long", 0);
	ed.addAttribute("connectionId", "Long", 0);

	// All all our references

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity firewall details.
     */
    private void addEntityFirewallDetails() {

	EntityDefinition ed = new EntityDefinition("FirewallDetails");

	// Add all our attributes
	ed.addAttribute("primaryFirewallName", "String", 150);
	ed.addAttribute("primaryPhyConAddress", "String", 20);
	ed.addAttribute("primaryCircuitId", "String", 100);
	ed.addAttribute("primaryBandwidth", "String", 25);
	ed.addAttribute("secondaryFirewallName", "String", 150);
	ed.addAttribute("secondaryPhyConAddress", "String", 20);
	ed.addAttribute("secondaryCircuitId", "String", 100);
	ed.addAttribute("secondaryBandwidth", "String", 25);

	// All all our references
	ed.addReference("connection", false, false,  false , "Connection");
	ed.addReference("connectionRequest", false, false,  false , "ConnectionRequest");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity hierarchy node detail.
     */
    private void addEntityHierarchyNodeDetail() {

	EntityDefinition ed = new EntityDefinition("HierarchyNodeDetail");

	// Add all our attributes
	ed.addAttribute("name", "String", 100);

	// All all our references

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity hierarchy detail.
     */
    private void addEntityHierarchyDetail() {

	EntityDefinition ed = new EntityDefinition("HierarchyDetail");

	// Add all our attributes
	ed.addAttribute("dataId", "Long", 0);

	// All all our references
	ed.addReference("nodeType", false, false,  false , "HierarchyNodeDetail");
	ed.addReference("parents", true, true,  false , "HierarchyParentDetail");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity hierarchy parent detail.
     */
    private void addEntityHierarchyParentDetail() {

	EntityDefinition ed = new EntityDefinition("HierarchyParentDetail");

	// Add all our attributes
	ed.addAttribute("parentId", "Long", 0);

	// All all our references
	ed.addReference("node", false, false,  false , "HierarchyDetail");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity port firewall xref.
     */
    private void addEntityPortFirewallXref() {

	EntityDefinition ed = new EntityDefinition("PortFirewallXref");

	// Add all our attributes

	// All all our references
	ed.addReference("port", false, false,  false , "Port");
	ed.addReference("firewall", false, false,  false , "FirewallDetails");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity entitlement node.
     */
    private void addEntityEntitlementNode() {

	EntityDefinition ed = new EntityDefinition("EntitlementNode");

	// Add all our attributes
	ed.addAttribute("entityName", "String", 100);

	// All all our references

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity rule entitlement node xref.
     */
    private void addEntityRuleEntitlementNodeXref() {

	EntityDefinition ed = new EntityDefinition("RuleEntitlementNodeXref");

	// Add all our attributes

	// All all our references
	ed.addReference("entitlementNode", false, false,  false , "EntitlementNode");
	ed.addReference("rule", false, false,  false , "Rule");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity rule.
     */
    private void addEntityRule() {

	EntityDefinition ed = new EntityDefinition("Rule");

	// Add all our attributes
	ed.addAttribute("rulename", "String", 100);

	// All all our references
	ed.addReference("entitlementNode", true, true,  false , "RuleEntitlementNodeXref");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity entitlement data.
     */
    private void addEntityEntitlementData() {

	EntityDefinition ed = new EntityDefinition("EntitlementData");

	// Add all our attributes
	ed.addAttribute("data", "Long", 0);

	// All all our references
	ed.addReference("entitlementInstance", false, false,  false , "EntitlementInstance");
	ed.addReference("entitlementNode", false, false,  false , "EntitlementNode");
	ed.addReference("rule", false, false,  false , "Rule");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity entitlement instance.
     */
    private void addEntityEntitlementInstance() {

	EntityDefinition ed = new EntityDefinition("EntitlementInstance");

	// Add all our attributes
	ed.addAttribute("name", "String", 500);
	ed.addAttribute("inactive", "String", 1);
	ed.addAttribute("inactivationReason", "String", 1000);
	ed.addAttribute("inactivatedDate", "Date", 0);

	// All all our references
	ed.addReference("entitlementData", true, true,  true, "EntitlementData");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity c3par user entitlement xref.
     */
    private void addEntityC3parUserEntitlementXref() {

	EntityDefinition ed = new EntityDefinition("C3parUserEntitlementXref");

	// Add all our attributes
	ed.addAttribute("permissions", "String", 30);
	ed.addAttribute("inactive", "String", 1);
	ed.addAttribute("inactivationreason", "String", 1000);
	ed.addAttribute("inactivationdate", "Date", 0);

	// All all our references
	ed.addReference("user", false, false,  false , "C3parUsers");
	ed.addReference("entitlementInstance", false, false,  false , "EntitlementInstance");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity region.
     */
    private void addEntityRegion() {

	EntityDefinition ed = new EntityDefinition("Region");

	// Add all our attributes
	ed.addAttribute("name", "String", 100);
	ed.addAttribute("isActive", "String", 1);
	ed.addAttribute("description", "String", 4000);

	// All all our references

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity c3par function.
     */
    private void addEntityC3parFunction() {

	EntityDefinition ed = new EntityDefinition("C3parFunction");

	// Add all our attributes
	ed.addAttribute("displayName", "String", 75);
	ed.addAttribute("description", "String", 275);
	ed.addAttribute("path", "String", 255);
	ed.addAttribute("parentFunction", "Long", 0);
	ed.addAttribute("displayPosition", "Long", 0);
	ed.addAttribute("imagePath", "String", 255);
	ed.addAttribute("displayCondition", "String", 300);

	// All all our references

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity c3par role function.
     */
    private void addEntityC3parRoleFunction() {

	EntityDefinition ed = new EntityDefinition("C3parRoleFunction");

	// Add all our attributes

	// All all our references
	ed.addReference("function", false, false,  false , "C3parFunction");
	ed.addReference("role", false, false,  false , "SecurityRole");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity ti process.
     */
    private void addEntityTIProcess() {

	EntityDefinition ed = new EntityDefinition("TIProcess");

	// Add all our attributes
	ed.addAttribute("processName", "String", 100);
	ed.addAttribute("createDate", "Date", 0);
	ed.addAttribute("updateDate", "Date", 0);
	ed.addAttribute("processTerminateReason", "String", 1000);
	ed.addAttribute("processUpdateReason", "String", 1000);
	ed.addAttribute("versionNumber", "Integer", 0);
	ed.addAttribute("isHighRisk", "String", 1);
	ed.addAttribute("isBroadAccess", "String", 1);
	ed.addAttribute("isDeleted", "String", 1);
	ed.addAttribute("processActivityMode", "String", 30);

	// All all our references
	ed.addReference("C3parProcessRoleXref", true, true,  true, "C3parProcessRoleXref");
	ed.addReference("processType", false, false,  false , "TIProcessType");
	ed.addReference("TIRequest", true, true,  true, "TIRequest");
	ed.addReference("entitlementInstance", false, false,  false , "EntitlementInstance");
	ed.addReference("relationship", false, false,  false , "Relationship");
	ed.addReference("processStatus", false, false,  false , "TITaskType");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity ti application.
     */
    private void addEntityTIApplication() {

	EntityDefinition ed = new EntityDefinition("TIApplication");

	// Add all our attributes
	ed.addAttribute("applicationId", "Long", 0);
	ed.addAttribute("applicationName", "String", 100);
	ed.addAttribute("applicaitonDesc", "String", 500);
	ed.addAttribute("appOwnerFullName", "String", 100);
	ed.addAttribute("appOwnerGeid", "String", 150);
	ed.addAttribute("isDevice", "String", 1);
	ed.addAttribute("deviceModel", "String", 250);
	ed.addAttribute("deviceOtherText", "String", 250);
	ed.addAttribute("isCsi", "String", 1);
	ed.addAttribute("appOwnerEmail", "String", 150);

	// All all our references
	ed.addReference("deviceType", false, false,  false , "GenericLookup");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity c3par process role xref.
     */
    private void addEntityC3parProcessRoleXref() {

	EntityDefinition ed = new EntityDefinition("C3parProcessRoleXref");

	// Add all our attributes
	ed.addAttribute("approval", "String", 100);
	ed.addAttribute("comments", "String", 1000);
	ed.addAttribute("isActive", "String", 1);

	// All all our references
	ed.addReference("process", false, false,  false , "TIProcess");
	ed.addReference("citiContact", false, false,  false , "CitiContact");
	ed.addReference("thirdPartyContact", false, false,  false , "ThirdPartyContact");
	ed.addReference("role", false, false,  false , "Role");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity ti process type.
     */
    private void addEntityTIProcessType() {

	EntityDefinition ed = new EntityDefinition("TIProcessType");

	// Add all our attributes
	ed.addAttribute("processType", "String", 50);

	// All all our references

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity ti status type.
     */
    private void addEntityTIStatusType() {

	EntityDefinition ed = new EntityDefinition("TIStatusType");

	// Add all our attributes
	ed.addAttribute("status", "String", 50);

	// All all our references

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity ti process status.
     */
    private void addEntityTIProcessStatus() {

	EntityDefinition ed = new EntityDefinition("TIProcessStatus");

	// Add all our attributes
	ed.addAttribute("statusDate", "Date", 0);
	ed.addAttribute("remarks", "String", 250);

	// All all our references
	ed.addReference("status", false, false,  false , "TIStatusType");
	ed.addReference("process", false, false,  false , "TIProcess");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity ti task type.
     */
    private void addEntityTITaskType() {

	EntityDefinition ed = new EntityDefinition("TITaskType");

	// Add all our attributes
	ed.addAttribute("task", "String", 50);
	ed.addAttribute("taskCode", "String", 50);

	// All all our references

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity ti request task.
     */
    private void addEntityTIRequestTask() {

	EntityDefinition ed = new EntityDefinition("TIRequestTask");

	// Add all our attributes
	ed.addAttribute("taskStartDate", "Date", 0);
	ed.addAttribute("taskEndDate", "Date", 0);

	// All all our references
	ed.addReference("request", true, false,  false , "TIRequest");
	ed.addReference("task", false, false,  false , "TITaskType");
	ed.addReference("taskContact", false, false,  false , "C3parProcessRoleXref");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity ti request.
     */
    private void addEntityTIRequest() {

	EntityDefinition ed = new EntityDefinition("TIRequest");

	// Add all our attributes
	ed.addAttribute("createDate", "Date", 0);
	ed.addAttribute("versionNumber", "Integer", 0);
	ed.addAttribute("isDeleted", "String", 1);
	ed.addAttribute("plannedCompletionDate", "Date", 0);
	ed.addAttribute("emerBuscritJustification", "String", 1000);
	ed.addAttribute("altBussMethods", "String", 1000);
	ed.addAttribute("reqNewAccess", "String", 1000);
	ed.addAttribute("vtTicketNo", "String", 100);
	ed.addAttribute("requestDeadline", "Date", 0);

	// All all our references
	ed.addReference("user", false, false,  false , "C3parUsers");
	ed.addReference("process", false, false,  false , "TIProcess");
	ed.addReference("tiRequestType", false, false,  false , "TIRequestType");
	ed.addReference("priority", false, false,  false , "GenericLookup");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity ti request status.
     */
    private void addEntityTIRequestStatus() {

	EntityDefinition ed = new EntityDefinition("TIRequestStatus");

	// Add all our attributes
	ed.addAttribute("statusDate", "Date", 0);
	ed.addAttribute("remarks", "String", 250);

	// All all our references
	ed.addReference("status", false, false,  false , "TIStatusType");
	ed.addReference("request", false, false,  false , "TIRequest");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity ti ostia question.
     */
    private void addEntityTIOstiaQuestion() {

	EntityDefinition ed = new EntityDefinition("TIOstiaQuestion");

	// Add all our attributes
	ed.addAttribute("question", "String", 1000);
	ed.addAttribute("position", "Long", 0);

	// All all our references

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity ti request type.
     */
    private void addEntityTIRequestType() {

	EntityDefinition ed = new EntityDefinition("TIRequestType");

	// Add all our attributes
	ed.addAttribute("requestType", "String", 100);

	// All all our references

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity connection firewall details.
     */
    private void addEntityConnectionFirewallDetails() {

	EntityDefinition ed = new EntityDefinition("ConnectionFirewallDetails");

	// Add all our attributes
	ed.addAttribute("circuit_id", "String", 255);
	ed.addAttribute("primaryFirewall", "Boolean", 0);
	ed.addAttribute("acl", "Boolean", 0);
	ed.addAttribute("aclVariance", "String", 255);
	ed.addAttribute("routerId", "String", 255);
	ed.addAttribute("location", "String", 255);

	// All all our references
	ed.addReference("bandwidth", false, false,  false , "GenericLookup");
	ed.addReference("connectionRequest", false, false,  false , "ConnectionRequest");
	ed.addReference("connection", false, false,  false , "Connection");
	ed.addReference("firewall", false, false,  false , "FirewallMaster");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity firewall master.
     */
    private void addEntityFirewallMaster() {

	EntityDefinition ed = new EntityDefinition("FirewallMaster");

	// Add all our attributes
	ed.addAttribute("firewallName", "String", 100);
	ed.addAttribute("firewallType", "String", 100);
	ed.addAttribute("firewallPolicy", "String", 100);
	ed.addAttribute("managementRegion", "String", 100);

	// All all our references

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity connection process.
     */
    private void addEntityConnectionProcess() {

	EntityDefinition ed = new EntityDefinition("ConnectionProcess");

	// Add all our attributes
	ed.addAttribute("processid", "String", 255);

	// All all our references
	ed.addReference("ConnectionRequest", false, false,  false , "ConnectionRequest");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity resource type.
     */
    private void addEntityResourceType() {

	EntityDefinition ed = new EntityDefinition("ResourceType");

	// Add all our attributes
	ed.addAttribute("name", "String", 100);
	ed.addAttribute("perimeter", "String", 100);
	ed.addAttribute("broadAccessIp", "String", 25);
	ed.addAttribute("status", "String", 25);
	ed.addAttribute("createdBy", "String", 50);
	ed.addAttribute("createdDate", "Date", 0);
	ed.addAttribute("modifiedBy", "String", 50);
	ed.addAttribute("modifiedDate", "Date", 0);

	// All all our references
	ed.addReference("CitiContact", false, true,  false , "CitiContact");
	ed.addReference("location", true, true,  false , "ResourceTypeLocationXref");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity resource type location xref.
     */
    private void addEntityResourceTypeLocationXref() {

	EntityDefinition ed = new EntityDefinition("ResourceTypeLocationXref");

	// Add all our attributes

	// All all our references
	ed.addReference("resourceType", false, false,  false , "ResourceType");
	ed.addReference("location", false, false,  false , "Location");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity relationship requester citi contact xref.
     */
    private void addEntityRelationshipRequesterCitiContactXref() {

	EntityDefinition ed = new EntityDefinition("RelationshipRequesterCitiContactXref");

	// Add all our attributes

	// All all our references
	ed.addReference("relationship", false, false,  false , "Relationship");
	ed.addReference("contact", false, false,  false , "CitiContact");
	ed.addReference("role", false, false,  false , "Role");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity relationship requester citi location xref.
     */
    private void addEntityRelationshipRequesterCitiLocationXref() {

	EntityDefinition ed = new EntityDefinition("RelationshipRequesterCitiLocationXref");

	// Add all our attributes

	// All all our references
	ed.addReference("relationship", false, false,  false , "Relationship");
	ed.addReference("location", false, false,  false , "Location");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity citi req contact xref.
     */
    private void addEntityCitiReqContactXref() {

	EntityDefinition ed = new EntityDefinition("CitiReqContactXref");

	// Add all our attributes
	ed.addAttribute("primaryContact", "Boolean", 0);

	// All all our references
	ed.addReference("request", false, false,  false , "ConnectionRequest");
	ed.addReference("citiContact", false, false,  false , "CitiContact");
	ed.addReference("role", false, false,  false , "Role");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }

    /**
     * Adds the entity connection citi req contact xref.
     */
    private void addEntityConnectionCitiReqContactXref() {

	EntityDefinition ed = new EntityDefinition("ConnectionCitiReqContactXref");

	// Add all our attributes
	ed.addAttribute("primaryContact", "Boolean", 0);

	// All all our references
	ed.addReference("connection", false, false,  false , "Connection");
	ed.addReference("citiContact", false, false,  false , "CitiContact");
	ed.addReference("role", false, false,  false , "Role");

	// Add the entity to the hashtable
	addEntityDefinition(ed);
    }


}

