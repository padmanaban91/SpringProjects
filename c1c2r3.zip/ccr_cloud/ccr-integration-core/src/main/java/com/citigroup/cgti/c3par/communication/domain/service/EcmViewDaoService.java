package com.citigroup.cgti.c3par.communication.domain.service;

public interface EcmViewDaoService {

}
