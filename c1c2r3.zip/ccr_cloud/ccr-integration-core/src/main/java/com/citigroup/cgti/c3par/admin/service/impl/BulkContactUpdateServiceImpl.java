/**
 * 
 */
package com.citigroup.cgti.c3par.admin.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.citigroup.cgti.c3par.admin.dao.service.BulkContactUpdateDaoService;
import com.citigroup.cgti.c3par.admin.domain.BulkContactUpdateDTO;
import com.citigroup.cgti.c3par.admin.service.BulkContactUpdateService;
import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.businessjustification.domain.ConReqCitiContactXref;
import com.citigroup.cgti.c3par.businessjustification.domain.ConReqCitiReqConXref;
import com.citigroup.cgti.c3par.domain.Role;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

/**
 * @author ka58098
 * 
 */
@Service
public class BulkContactUpdateServiceImpl implements BulkContactUpdateService {
    private static final Logger log = Logger.getLogger(BulkContactUpdateServiceImpl.class.getName());

    private static final String[] params = { "PROJECT COORDINATOR", "DESIGN ENGINEER", "Director", "Manager", "BISO",
            "Business_Tester", "Requestor" };

    @Autowired
    private BulkContactUpdateDaoService bulkContactUpdateDaoService;
    @Autowired
    private SessionFactory sessionFactory;
    CCRBeanFactory ccrBeanFactory;
    {
        ApplicationContext appContext = CCRApplicationContextUtils.getApplicationContext();
        ccrBeanFactory = (CCRBeanFactory) appContext.getBean("cCRBeanFactory");
    }

    @Override
    public BulkContactUpdateDTO getSearchDetails(BulkContactUpdateDTO bulkContactUpdate) {
        log.info("Entering ::");
        List<BulkContactUpdateDTO> searchDetail = new ArrayList<BulkContactUpdateDTO>();
        BulkContactUpdateDTO bulkContactUpdateDTO = null;
        try {
            log.debug("Long RoleId : " + Long.parseLong(bulkContactUpdate.getRoleName()));
            List<ConReqCitiContactXref> conReqContactList = bulkContactUpdateDaoService.getConReqCitiContact(bulkContactUpdate.getSsoId(),Long.parseLong(bulkContactUpdate.getRoleName()));
            if (!CollectionUtils.isEmpty(conReqContactList))
                for (ConReqCitiContactXref conReqCitiContact : conReqContactList) {
                    bulkContactUpdateDTO = new BulkContactUpdateDTO();
                    bulkContactUpdateDTO.setConReqCitiContactId(conReqCitiContact.getId());
                    bulkContactUpdateDTO.setCitiContactId(conReqCitiContact.getCiticontact().getId());
                    bulkContactUpdateDTO.setIsPrimary(conReqCitiContact.getPrimaryContact());
                    bulkContactUpdateDTO.setIsNotify(conReqCitiContact.getNotifyContact());
                    log.info("conReqCitiContact.getRequestid().getId() ::" + conReqCitiContact.getRequestid().getId());
                    TIRequest tiRequest = bulkContactUpdateDaoService
                            .getTiRequest(conReqCitiContact.getRequestid().getId());
                    if (tiRequest != null) {
                        TIProcess tiProcess = tiRequest.getTiProcess();
                        log.info("tiProcess.getId()  value ::" + tiProcess.getId());
                        bulkContactUpdateDTO.setCcrId(tiProcess.getId());
                        bulkContactUpdateDTO.setTiRequestId(tiRequest.getId());
                        bulkContactUpdateDTO.setCcrName(tiProcess.getProcessName());
                        bulkContactUpdateDTO.setContactType("target");
                        searchDetail.add(bulkContactUpdateDTO);
                    }

                }
            List<ConReqCitiReqConXref> conReqCitiReqConXrefList  = bulkContactUpdateDaoService.getConReqCitiReqConXref(bulkContactUpdate.getSsoId(),Long.parseLong(bulkContactUpdate.getRoleName()));
            if (!CollectionUtils.isEmpty(conReqCitiReqConXrefList))
            	for (ConReqCitiReqConXref conReqCitiReqConXref : conReqCitiReqConXrefList) {
                    bulkContactUpdateDTO = new BulkContactUpdateDTO();
                    bulkContactUpdateDTO.setConReqCitiContactId(conReqCitiReqConXref.getId());
                    bulkContactUpdateDTO.setCitiContactId(conReqCitiReqConXref.getCiticontact().getId());
                    bulkContactUpdateDTO.setIsPrimary(conReqCitiReqConXref.getPrimaryContact());
                    bulkContactUpdateDTO.setIsNotify(conReqCitiReqConXref.getNotifyContact());
                    log.info("conReqCitiContact.getRequestid().getId() ::" + conReqCitiReqConXref.getRequestid().getId());
                    TIRequest tiRequest = bulkContactUpdateDaoService
                            .getTiRequest(conReqCitiReqConXref.getRequestid().getId());
                    if (tiRequest != null) {
                        TIProcess tiProcess = tiRequest.getTiProcess();
                        log.info("tiProcess.getId()  value ::" + tiProcess.getId());
                        bulkContactUpdateDTO.setCcrId(tiProcess.getId());
                        bulkContactUpdateDTO.setTiRequestId(tiRequest.getId());
                        bulkContactUpdateDTO.setCcrName(tiProcess.getProcessName());
                        bulkContactUpdateDTO.setContactType("requestor");
                        searchDetail.add(bulkContactUpdateDTO);
                    }
                }
            if(!CollectionUtils.isEmpty(searchDetail)){
            	ContactComparator contactComparator=new ContactComparator();
            	Collections.sort(searchDetail, contactComparator);
            	bulkContactUpdate.setSearchResultDTOList(searchDetail);
            }
            bulkContactUpdate.setSearchResultDTOList(searchDetail);
            bulkContactUpdate.setRoleList(getRoleList());
            bulkContactUpdate.setContactName(getContactNameForSsoId(bulkContactUpdate.getSsoId()));
         } catch (Exception e) {
            log.error("Error has occurred in getSearchDetails()::" + e);

        }
        log.info("Exiting ::");
        return bulkContactUpdate;
    }

   

    public CitiContact getCitiContact(String ssoId) {
        // CitiContact
        // citiContact=ccrBeanFactory.getRelationshipServicePersistable().getCitiContact(ssoId.toUpperCase());
        return ccrBeanFactory.getCmpRequestPersistable().getUserIdForSsoId(ssoId);
    }

    @Override
    public Long getTIRequestID(Long processId) {
        return bulkContactUpdateDaoService.getTiRequestId(processId);
    }

    public List<BulkContactUpdateDTO> updateContactDetails(BulkContactUpdateDTO bulkContactUpdateDTO) {
        return null;
    }

    
    @Override
    public void updateContact(List<Long> ccrIdList, List<String> contactTypeList, List<Long> citiContactIdList,BulkContactUpdateDTO bulkContactUpdateDTO) {

        Long contactId = getCitiContact(bulkContactUpdateDTO.getSsoId()).getId();
        String roleName = bulkContactUpdateDTO.getRoleName();
        String newRoleName = bulkContactUpdateDTO.getNewRoleName();
        Long replaceContactId = getCitiContact(bulkContactUpdateDTO.getReplaceSsoId()).getId();

        bulkContactUpdateDaoService.updateContact(bulkContactUpdateDTO, ccrIdList, contactTypeList,citiContactIdList,contactId, roleName, newRoleName,
                replaceContactId);
    }

    @Override
    public void removeContact(BulkContactUpdateDTO bulkContactUpdateDTO) {
        try {

            List<Long> targetIds = new ArrayList<Long>();
            List<Long> requestorIds = new ArrayList<Long>();
            if (bulkContactUpdateDTO.getSearchResultDTOList() != null
                    && !bulkContactUpdateDTO.getSearchResultDTOList().isEmpty()) {
                for (BulkContactUpdateDTO resultDTO : bulkContactUpdateDTO.getSearchResultDTOList()) {
                    if (resultDTO.isSelected()) {
                       if (resultDTO.getContactType().equals("target")) {
                           targetIds.add(resultDTO.getConReqCitiContactId());
                       } else if (resultDTO.getContactType().equals("requestor")) {
                           requestorIds.add(resultDTO.getConReqCitiContactId());
                       }
                    }
                }
            }

            bulkContactUpdateDaoService.removeContacts(targetIds, requestorIds,bulkContactUpdateDTO.getUserSsoId());

        } catch (Exception e) {
            log.error("Error while removing Contacts:" + e.getMessage());
           
        }

    }
    
    @Override
    public List<Role> getRoleList() {
        
        RoleComparator roleComparator = new RoleComparator();
        List<Role> roleList = bulkContactUpdateDaoService.getRoleList();
        Collections.sort(roleList, roleComparator);        
        return roleList;
    }

    @Override
    public String getContactNameForSsoId(String ssoId) {
        return bulkContactUpdateDaoService.getContactNameForSsoId(ssoId);
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    @Override
    public void updatePrimaryOrNotifyContact(Map<Long, String> planningIdList, BulkContactUpdateDTO bulkContactUpdateDTO) {
        bulkContactUpdateDaoService.updatePrimaryOrNotifyContact(planningIdList, bulkContactUpdateDTO);

    }
}
