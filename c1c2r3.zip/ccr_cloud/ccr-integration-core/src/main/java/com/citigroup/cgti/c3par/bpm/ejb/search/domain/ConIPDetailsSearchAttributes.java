package com.citigroup.cgti.c3par.bpm.ejb.search.domain;

import java.io.Serializable;


/**
 * The Class ConIPDetailsSearchAttributes.
 */

/**
 * Created by nc43495
 */

public class ConIPDetailsSearchAttributes  extends BaseSearchAttributes implements Serializable{

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -3828763137580583865L;
    
    /** The source ip address. */
    private String sourceIpAddress=null;

    /** The source nat ip. */
    private String sourceNatIP=null;

    /** The Destination ip address. */
    private String destinationIpAddress = null;
    
    /** The Destination Nat IP */
    private String destinationNatIP=null;

    /** The firewall. */
    private String firewall=null;
    
    /** The Firewall Name */
    private String firewallName;
    private String firewallGroup;
    
    private String groupName;
    
    
    
    /**
	 * @return the groupName
	 */
	public String getGroupName() {
		return groupName;
	}

	/**
	 * @param groupName the groupName to set
	 */
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	
	public String getGroupNameForQuery()
	{
		return validString(groupName);
	}

	public String getFirewallName() {
		return firewallName;
	}

	public void setFirewallName(String firewallName) {
		this.firewallName = firewallName;
	}

	/** The port. */
    private String port=null;

    /** The protocol. */
    private String protocol=null;


	public String getFirewall() {
		return firewall;
	}

	public void setFirewall(String firewall) {
		this.firewall = firewall;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public String getProtocol() {
		return protocol;
	}

	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}
	
	public String getFirewallForQuery() {
		return validString(firewall);
	}
	
	public String getFirewallNameForQuery() {
		return validString(firewallName);
	}
	
	
	public String getSourceIpAddressForQuery() {
			return validString(sourceIpAddress);
	}

	public String getSourceNatIPForQuery() {
			return validString(sourceNatIP);
	}
		    
	public String getPortForQuery() {
		 return validString(port);
	}
	
	public String getSourceIpAddress() {
		return sourceIpAddress;
	}

	public void setSourceIpAddress(String sourceIpAddress) {
		this.sourceIpAddress = sourceIpAddress;
	}

	public String getSourceNatIP() {
		return sourceNatIP;
	}

	public void setSourceNatIP(String sourceNatIP) {
		this.sourceNatIP = sourceNatIP;
	}

	public String getDestinationIpAddress() {
		return destinationIpAddress;
	}

	public void setDestinationIpAddress(String destinationIpAddress) {
		this.destinationIpAddress = destinationIpAddress;
	}

	public String getDestinationNatIP() {
		return destinationNatIP;
	}

	public void setDestinationNatIP(String destinationNatIP) {
		this.destinationNatIP = destinationNatIP;
	}

	public String getProtocolForQuery() {
		return validString(protocol);
    }
	

	public String getDestIpAddressForQuery() {
			return validString(destinationIpAddress);
	}

	public String getDestNatIPForQuery() {
			return validString(destinationNatIP);
	}

	public String getFirewallGroup() {
		return firewallGroup;
	}

	public void setFirewallGroup(String firewallGroup) {
		this.firewallGroup = firewallGroup;
	}
	public String getFirewallGroupForQuery() {
		return validString(firewallGroup);
	}
	
	}
