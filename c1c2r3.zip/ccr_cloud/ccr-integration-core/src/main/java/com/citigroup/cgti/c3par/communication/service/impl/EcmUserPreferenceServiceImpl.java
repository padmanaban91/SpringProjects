package com.citigroup.cgti.c3par.communication.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.common.domain.soc.persist.AdminServicePersistable;
import com.citigroup.cgti.c3par.communication.domain.AgentViewProcess;
import com.citigroup.cgti.c3par.communication.domain.CmpReqIdSearchProcess;
import com.citigroup.cgti.c3par.communication.domain.ColumnDTO;
import com.citigroup.cgti.c3par.communication.domain.ColumnsSortOrderSettings;
import com.citigroup.cgti.c3par.communication.domain.EcmLeadViewProcess;
import com.citigroup.cgti.c3par.communication.domain.EcmUserPreference;
import com.citigroup.cgti.c3par.communication.domain.EcmUserPreferenceDTO;
import com.citigroup.cgti.c3par.communication.domain.EcmUserSetting;
import com.citigroup.cgti.c3par.communication.domain.EcmViewColumn;
import com.citigroup.cgti.c3par.communication.domain.TeamViewProcess;
import com.citigroup.cgti.c3par.communication.domain.service.EcmUserPreferenceDaoService;
import com.citigroup.cgti.c3par.communication.service.EcmUserPreferenceService;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleProcess;
import com.citigroup.cgti.c3par.util.StringUtil;
import com.citigroup.cgti.inbox.dto.InboxDTO;

@Service
public class EcmUserPreferenceServiceImpl implements EcmUserPreferenceService {

    private static final Logger LOGGER = Logger.getLogger(EcmUserPreferenceServiceImpl.class);
    @Autowired
    private EcmUserPreferenceDaoService ecmUserPreferenceDaoService;
    @Autowired
    private AdminServicePersistable adminServicePersistable;
    private Long userId;
    private String ssoId;

    @Override
	public void getColumnList(Object object) throws Exception {
		LOGGER.info("Entering ::");
		Map<Long, String> map = new TreeMap<Long, String>();
		List<String> columnList = new ArrayList<String>();
		AgentViewProcess agentViewProcess=null;
		InboxDTO inboxDTO=null;
		FireWallRuleProcess fireWallRuleProcess =null;
		String ssoId=null;
		String viewId=null;
		try {
			if(object instanceof AgentViewProcess){
				agentViewProcess=(AgentViewProcess)object;
				ssoId=agentViewProcess.getSsoId();
				viewId=agentViewProcess.getViewId();
			}else if(object instanceof InboxDTO){
				inboxDTO=(InboxDTO)object;
				ssoId=inboxDTO.getSsoId();
				viewId=inboxDTO.getViewId();
			}
			else if (object instanceof FireWallRuleProcess)
			{
				
				fireWallRuleProcess =(FireWallRuleProcess) object;
				ssoId = fireWallRuleProcess.getSsoId();
				viewId = fireWallRuleProcess.getViewId();
			}
			if (!StringUtil.isNullorEmpty(ssoId)
					&& !StringUtil.isNullorEmpty(viewId)) {
				/*
				 * List<EcmUserPreference> userPreferenceList =
				 * ecmUserPreferenceDaoService
				 * .getEcmUserPreference(agentViewProcess.getSsoId(),
				 * agentViewProcess.getViewId()); if
				 * (!CollectionUtils.isEmpty(userPreferenceList)) for
				 * (EcmUserPreference userPreference : userPreferenceList) { if
				 * (userPreference.getEcmViewColumn() != null) if
				 * (userPreference.getEcmViewColumn().getEcmColumn() != null) {
				 * isUserSettings = true;
				 * map.put(userPreference.getEcmViewColumn().getEcmColumn().
				 * getId(), userPreference.getEcmViewColumn().getEcmColumn().
				 * getUiColumnName());
				 * columnList.add(userPreference.getEcmViewColumn().getEcmColumn
				 * ().getUiColumnName()); }
				 * 
				 * }
				 */
				List<EcmViewColumn> viewColumnList = ecmUserPreferenceDaoService
						.getEcmViewColumn(viewId);
				if (!CollectionUtils.isEmpty(viewColumnList)) {
					for (EcmViewColumn ecmViewColumn : viewColumnList) {
						if (ecmViewColumn.getEcmColumn() != null) {
							map.put(ecmViewColumn.getEcmColumn().getId(),
									ecmViewColumn.getEcmColumn().getUiColumnName());
							columnList.add(ecmViewColumn.getEcmColumn().getUiColumnName());
						}
					}
				}
				EcmUserSetting ecmUserSetting = ecmUserPreferenceDaoService.getUseSetting(ssoId,
						viewId);
				if (null != ecmUserSetting) {
					ColumnsSortOrderSettings ecmColumnsOrderSettings = ecmUserPreferenceDaoService
							.getEcmFirstColumnOrderSetting(ecmUserSetting.getId());
					if (ecmColumnsOrderSettings != null) {
						EcmViewColumn ecmViewColumn = ecmUserPreferenceDaoService
								.getEcmViewColumn(ecmUserSetting.getViewId(), ecmColumnsOrderSettings.getColumnId());
						if (null != ecmViewColumn) {
							if (null != agentViewProcess) {
								agentViewProcess.setColumnIndex(ecmViewColumn.getColumnOrder());
								agentViewProcess.setResultPerPage(ecmUserSetting.getResultsPerPage());
								agentViewProcess.setSortBy(ecmColumnsOrderSettings.getSortOrder());
							}
							if (null != inboxDTO) {
								inboxDTO.setColumnIndex(ecmViewColumn.getColumnOrder());
								inboxDTO.setResultPerPage(ecmUserSetting.getResultsPerPage());
								inboxDTO.setSortBy(ecmColumnsOrderSettings.getSortOrder());
							}
							if (null != fireWallRuleProcess) {
								fireWallRuleProcess.setColumnIndex(ecmViewColumn.getColumnOrder());
								Integer resultsPerPage = 5;
								if (ecmUserSetting.getResultsPerPage() != null) {
									resultsPerPage = Integer.parseInt(ecmUserSetting.getResultsPerPage().toString());
								}
								fireWallRuleProcess.setMaxResult(resultsPerPage);
								fireWallRuleProcess.setSortBy(ecmColumnsOrderSettings.getSortOrder());
							}
						}
					}
				}
				if(null!=agentViewProcess){
					agentViewProcess.setColumnList(columnList);
					agentViewProcess.setMap(map);	
				}else if(null!=inboxDTO){
					inboxDTO.setColumnList(columnList);
				}
				else if(null!=fireWallRuleProcess){
					fireWallRuleProcess.setColumnList(columnList);
				}
			}
			

		} catch (Exception e) {
			LOGGER.error("Exception occurred while getting getColumnList : " + e.toString());
			throw new ApplicationException("Exception has occurred :: getColumnList() ", e);

		}
		LOGGER.info("Agent View Column list size value:- " + columnList);
	}


    @Override
    public EcmUserPreferenceDTO getUserSettingDetails(String ssoId, String viewId) throws Exception {
        EcmUserPreferenceDTO ecmUserPreferencedto = new EcmUserPreferenceDTO();
        ColumnDTO columnDTO = null;
        EcmUserSetting ecmUserSetting = null;
        List<ColumnsSortOrderSettings> ecmColumnsOrderSettingsList = null;
        try {
            Long ecmviewId = 0L;
            ecmUserPreferencedto.setColumnList(ecmUserPreferenceDaoService.getColumnDetails(viewId));
            List<EcmViewColumn> viewColumnSelList = ecmUserPreferenceDaoService.unselectedColumn(ssoId, viewId, true);
            if (!CollectionUtils.isEmpty(viewColumnSelList)) {
                List<ColumnDTO> selectedList = new ArrayList<>();
                for (EcmViewColumn ecmViewColumn : viewColumnSelList) {
                    columnDTO = new ColumnDTO();
                    columnDTO.setViewColumnId(ecmViewColumn.getId());
                    columnDTO.setColumnName(ecmViewColumn.getEcmColumn().getUiColumnName());
                    ecmviewId = ecmViewColumn.getViewId();
                    selectedList.add(columnDTO);
                }
                ecmUserPreferencedto.setSelectedList(selectedList);
            }
            List<EcmViewColumn> viewColumnUnSelLst = ecmUserPreferenceDaoService.unselectedColumn(ssoId, viewId, false);
            if (!CollectionUtils.isEmpty(viewColumnUnSelLst)) {
                List<ColumnDTO> unselectedList = new ArrayList<>();
                for (EcmViewColumn ecmViewColumn : viewColumnUnSelLst) {
                    columnDTO = new ColumnDTO();
                    columnDTO.setViewColumnId(ecmViewColumn.getId());
                    columnDTO.setColumnName(ecmViewColumn.getEcmColumn().getUiColumnName());
                    ecmviewId = ecmViewColumn.getViewId();
                    unselectedList.add(columnDTO);
                }
                ecmUserPreferencedto.setUnSelectedList(unselectedList);
            }
            ecmUserPreferencedto.setViewId(ecmviewId);
            ecmUserPreferencedto.setViewName(viewId);
            ecmUserSetting = (EcmUserSetting) ecmUserPreferenceDaoService.getUseSetting(ssoId, viewId);
			if (null != ecmUserSetting) {
				ecmColumnsOrderSettingsList = ecmUserPreferenceDaoService
						.getEcmColumnsOrderSetting(ecmUserSetting.getId());
				ecmUserPreferencedto.setResultsPerPage(ecmUserSetting.getResultsPerPage());
				if (CollectionUtils.isNotEmpty(ecmColumnsOrderSettingsList)) {
					ecmUserPreferencedto.setSortOrder(ecmColumnsOrderSettingsList.get(0).getSortOrder());
					ecmUserPreferencedto.setColumnId(ecmColumnsOrderSettingsList.get(0).getColumnId());
					for (ColumnsSortOrderSettings ecmColumnsOrderSettings : ecmColumnsOrderSettingsList) {
						if (ecmColumnsOrderSettings.getEcmColumnIdOrder() == 2) {
							ecmUserPreferencedto.setSecondColumnId(ecmColumnsOrderSettings.getColumnId());
							ecmUserPreferencedto.setSecondColSortOrder(ecmColumnsOrderSettings.getSortOrder());
						} else if (ecmColumnsOrderSettings.getEcmColumnIdOrder() == 3) {
							ecmUserPreferencedto.setThirdColumnId(ecmColumnsOrderSettings.getColumnId());
							ecmUserPreferencedto.setThirdColSortOrder(ecmColumnsOrderSettings.getSortOrder());
						} else if (ecmColumnsOrderSettings.getEcmColumnIdOrder() == 4) {
							ecmUserPreferencedto.setFourthColumnId(ecmColumnsOrderSettings.getColumnId());
							ecmUserPreferencedto.setFourthColSortOrder(ecmColumnsOrderSettings.getSortOrder());
						} else if (ecmColumnsOrderSettings.getEcmColumnIdOrder() == 5) {
							ecmUserPreferencedto.setFifthColumnId(ecmColumnsOrderSettings.getColumnId());
							ecmUserPreferencedto.setFifthColSortOrder(ecmColumnsOrderSettings.getSortOrder());
						} else if (ecmColumnsOrderSettings.getEcmColumnIdOrder() == 6) {
							ecmUserPreferencedto.setSixthColumnId(ecmColumnsOrderSettings.getColumnId());
							ecmUserPreferencedto.setSixthColSortOrder(ecmColumnsOrderSettings.getSortOrder());
						} else if (ecmColumnsOrderSettings.getEcmColumnIdOrder() == 7) {
							ecmUserPreferencedto.setSeventhColumnId(ecmColumnsOrderSettings.getColumnId());
							ecmUserPreferencedto.setSeventhColSortOrder(ecmColumnsOrderSettings.getSortOrder());
						} else if (ecmColumnsOrderSettings.getEcmColumnIdOrder() == 8) {
							ecmUserPreferencedto.setEighthColumnId(ecmColumnsOrderSettings.getColumnId());
							ecmUserPreferencedto.setEighthColSortOrder(ecmColumnsOrderSettings.getSortOrder());
						} else if (ecmColumnsOrderSettings.getEcmColumnIdOrder() == 9) {
							ecmUserPreferencedto.setNinethColumnId(ecmColumnsOrderSettings.getColumnId());
							ecmUserPreferencedto.setNinethColSortOrder(ecmColumnsOrderSettings.getSortOrder());
						}
					}
				}
				ecmUserPreferencedto.setUserSettingId(ecmUserSetting.getId());
			} else {
                ecmUserPreferencedto.setSortOrder("asc");
            }

        } catch (Exception e) {
            LOGGER.error("Exception occurred while getUserSettingDetails : " + e.toString());
            throw new ApplicationException("Exception has occurred :: getUserSettingDetails() ", e);

        }
        return ecmUserPreferencedto;
    }

    @Override
    public EcmUserPreferenceDTO saveSettigsDetails(EcmUserPreferenceDTO ecmUserPreferenceDTO) throws Exception {
        try {
            userId = adminServicePersistable.getUserId(ecmUserPreferenceDTO.getSsoId());
            ssoId = ecmUserPreferenceDTO.getSsoId();
            if (!StringUtil.isNullorEmpty(ecmUserPreferenceDTO.getSelectedColumn())) {
                EcmUserPreference ecmUserPreference = null;
                if (ecmUserPreferenceDTO.getSelectedColumn().contains(",")) {
                    String[] selectArr = ecmUserPreferenceDTO.getSelectedColumn().split(",");
                    for (String selectedId : selectArr) {
                        ecmUserPreference = new EcmUserPreference();
                        ecmUserPreference.setViewColumnId(Long.parseLong(selectedId));
                        setValuesForUserPreference(ecmUserPreference);
                        ecmUserPreferenceDaoService.saveOrDeleteEcmUserPreference(ecmUserPreference, true);
                    }
                } else {
                    ecmUserPreference = new EcmUserPreference();
                    ecmUserPreference.setViewColumnId(Long.parseLong(ecmUserPreferenceDTO.getSelectedColumn()));
                    setValuesForUserPreference(ecmUserPreference);
                    ecmUserPreferenceDaoService.saveOrDeleteEcmUserPreference(ecmUserPreference, true);
                }
            }
            if (!StringUtil.isNullorEmpty(ecmUserPreferenceDTO.getUnSelectedColumn())) {
                EcmUserPreference ecmUserPreference = null;
                if (ecmUserPreferenceDTO.getUnSelectedColumn().contains(",")) {
                    String[] selectArr = ecmUserPreferenceDTO.getUnSelectedColumn().split(",");
                    for (String selectedId : selectArr) {
                        ecmUserPreference = new EcmUserPreference();
                        ecmUserPreference.setViewColumnId(Long.parseLong(selectedId));
                        setValuesForUserPreference(ecmUserPreference);
                        ecmUserPreferenceDaoService.saveOrDeleteEcmUserPreference(ecmUserPreference, false);
                    }
                } else {
                    ecmUserPreference = new EcmUserPreference();
                    ecmUserPreference.setViewColumnId(Long.parseLong(ecmUserPreferenceDTO.getUnSelectedColumn()));
                    setValuesForUserPreference(ecmUserPreference);
                    ecmUserPreferenceDaoService.saveOrDeleteEcmUserPreference(ecmUserPreference, false);
                }
            }
            EcmUserSetting ecmUserSetting = new EcmUserSetting();
            if (ecmUserPreferenceDTO.getUserSettingId() != null) {
                ecmUserSetting.setId(ecmUserPreferenceDTO.getUserSettingId());
                ecmUserSetting.setUpdatedBy(ecmUserPreferenceDTO.getSsoId());
                ecmUserSetting.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
            } else {
                ecmUserSetting.setCreatedBy(ecmUserPreferenceDTO.getSsoId());
                ecmUserSetting.setCreatedDate(new Timestamp(System.currentTimeMillis()));
            }
            ecmUserSetting.setViewId(ecmUserPreferenceDTO.getViewId());
            ecmUserSetting.setUserId(userId);
            ecmUserSetting.setResultsPerPage(ecmUserPreferenceDTO.getResultsPerPage());
            ecmUserPreferenceDaoService.saveOrUpdateSetting(ecmUserSetting);
            
			List<Boolean> ifOtherColumnsPresentList = new ArrayList<Boolean>();
			saveColumnsSortOrderSettings(ecmUserPreferenceDTO.getColumnId(), ecmUserPreferenceDTO.getSortOrder(),
					ifOtherColumnsPresentList, ecmUserSetting, 1L);
			saveColumnsSortOrderSettings(ecmUserPreferenceDTO.getSecondColumnId(),
					ecmUserPreferenceDTO.getSecondColSortOrder(), ifOtherColumnsPresentList, ecmUserSetting, 2L);
			saveColumnsSortOrderSettings(ecmUserPreferenceDTO.getThirdColumnId(),
					ecmUserPreferenceDTO.getThirdColSortOrder(), ifOtherColumnsPresentList, ecmUserSetting, 3L);
			saveColumnsSortOrderSettings(ecmUserPreferenceDTO.getFourthColumnId(),
					ecmUserPreferenceDTO.getFourthColSortOrder(), ifOtherColumnsPresentList, ecmUserSetting, 4L);
			saveColumnsSortOrderSettings(ecmUserPreferenceDTO.getFifthColumnId(),
					ecmUserPreferenceDTO.getFifthColSortOrder(), ifOtherColumnsPresentList, ecmUserSetting, 5L);
			saveColumnsSortOrderSettings(ecmUserPreferenceDTO.getSixthColumnId(),
					ecmUserPreferenceDTO.getSixthColSortOrder(), ifOtherColumnsPresentList, ecmUserSetting, 6L);
			saveColumnsSortOrderSettings(ecmUserPreferenceDTO.getSeventhColumnId(),
					ecmUserPreferenceDTO.getSeventhColSortOrder(), ifOtherColumnsPresentList, ecmUserSetting, 7L);
			saveColumnsSortOrderSettings(ecmUserPreferenceDTO.getEighthColumnId(),
					ecmUserPreferenceDTO.getEighthColSortOrder(), ifOtherColumnsPresentList, ecmUserSetting, 8L);
			saveColumnsSortOrderSettings(ecmUserPreferenceDTO.getNinethColumnId(),
					ecmUserPreferenceDTO.getNinethColSortOrder(), ifOtherColumnsPresentList, ecmUserSetting, 9L);

			Long columnIdOrder = 1L;
			for (Boolean val : ifOtherColumnsPresentList) {
				if (!val) {
					ecmUserPreferenceDaoService.deleteEcmColumnsOrderSettingIfPresent(ecmUserSetting.getId(),
							columnIdOrder);
				}
				++columnIdOrder;
			}

            ecmUserPreferenceDTO = getUserSettingDetails(ecmUserPreferenceDTO.getSsoId(),
                    ecmUserPreferenceDTO.getViewName());
        } catch (Exception e) {
            LOGGER.error("Exception occurred while saveSettingsDetails:: " + e.toString());
            throw new ApplicationException("Exception has occurred :: saveSettingsDetails ", e);
        }

        return ecmUserPreferenceDTO;
    }

	private void saveColumnsSortOrderSettings(Long columnId, String sortOrder, List<Boolean> ifOtherColumnsPresentList,
			EcmUserSetting ecmUserSetting, long columnOrder) throws Exception {
		if (columnId != null && columnId > 0 && !(StringUtil.isNullorEmpty(sortOrder))) {
			ifOtherColumnsPresentList.add(true);
			saveEcmColumnsOrderSettings(ecmUserSetting, columnId, sortOrder, columnOrder);
		} else {
			ifOtherColumnsPresentList.add(false);
		}
	}

	private void saveEcmColumnsOrderSettings(EcmUserSetting ecmUserSetting, Long columnId, String colSortOrder,
			Long columnIdOrder) throws Exception {
		ColumnsSortOrderSettings ecmColumnsOrderSettings = new ColumnsSortOrderSettings();
		ecmUserPreferenceDaoService.deleteEcmColumnsOrderSettingIfPresent(ecmUserSetting.getId(), columnIdOrder);
		ecmColumnsOrderSettings.setEcmUserSetting(ecmUserSetting);
		ecmColumnsOrderSettings.setEcmUserSettingId(ecmUserSetting.getId());
		ecmColumnsOrderSettings.setColumnId(columnId);
		ecmColumnsOrderSettings.setSortOrder(colSortOrder);
		ecmColumnsOrderSettings.setEcmColumnIdOrder(columnIdOrder);
		ecmUserPreferenceDaoService.saveOrUpdateSetting(ecmColumnsOrderSettings);
	}
    
    private EcmUserPreference setValuesForUserPreference(EcmUserPreference ecmUserPreference) {
        ecmUserPreference.setUserId(userId);
        ecmUserPreference.setCreatedBy(ssoId);
        ecmUserPreference.setUpdatedBy(ssoId);
        ecmUserPreference.setCreatedDate(new Timestamp(System.currentTimeMillis()));
        ecmUserPreference.setUpdatedDate(new Timestamp(System.currentTimeMillis()));
        return ecmUserPreference;
    }

    @Override
    public Map<Long, String> getColumnList(EcmLeadViewProcess ecmLeadViewProcess) throws Exception {
        Map<Long, String> map = new LinkedHashMap<Long, String>();
        List<String> columnNames = new ArrayList<String>();
        try {

            List<EcmViewColumn> viewColumnList = ecmUserPreferenceDaoService.getEcmViewColumn(ecmLeadViewProcess
                    .getView());
            if (!CollectionUtils.isEmpty(viewColumnList)) {
                for (EcmViewColumn ecmViewColumn : viewColumnList) {
                    if (ecmViewColumn.getEcmColumn() != null) {
                        map.put(ecmViewColumn.getEcmColumn().getId(), ecmViewColumn.getEcmColumn().getUiColumnName());
                        columnNames.add(ecmViewColumn.getEcmColumn().getUiColumnName());
                    }
                }
            }
            EcmUserSetting ecmUserSetting = ecmUserPreferenceDaoService.getUseSetting(ecmLeadViewProcess.getSsoId(),
                    ecmLeadViewProcess.getView());
            if (null != ecmUserSetting) {
            	ColumnsSortOrderSettings ecmColumnsOrderSettings = ecmUserPreferenceDaoService
						.getEcmFirstColumnOrderSetting(ecmUserSetting.getId());
                ecmLeadViewProcess.setSortBy(ecmColumnsOrderSettings.getSortOrder());
                EcmViewColumn ecmViewColumn = ecmUserPreferenceDaoService.getEcmViewColumn(ecmUserSetting.getViewId(),
                		ecmColumnsOrderSettings.getColumnId());
                if (null != ecmViewColumn)
                    ecmLeadViewProcess.setColumnIndex(ecmViewColumn.getColumnOrder());
                ecmLeadViewProcess.setResultPerPage(ecmUserSetting.getResultsPerPage());
            }
            ecmLeadViewProcess.setUnassignedItemscolumnList(columnNames);

        } catch (Exception e) {
            LOGGER.error("Exception occurred while getting getColumnList : " + e.toString());
            throw new ApplicationException("Exception has occurred :: getColumnList() ", e);

        }
        return map;
    }

    @Override
    public Map<Long, String> getColumnList(TeamViewProcess teamViewProcess) throws Exception {
        Map<Long, String> map = new LinkedHashMap<Long, String>();
        List<String> columnList = new ArrayList<String>();
        try {

            List<EcmViewColumn> viewColumnList = ecmUserPreferenceDaoService
                    .getEcmViewColumn(teamViewProcess.getView());
            if (!CollectionUtils.isEmpty(viewColumnList)) {
                for (EcmViewColumn ecmViewColumn : viewColumnList) {
                    if (ecmViewColumn.getEcmColumn() != null) {
                        map.put(ecmViewColumn.getEcmColumn().getId(), ecmViewColumn.getEcmColumn().getUiColumnName());
                        columnList.add(ecmViewColumn.getEcmColumn().getUiColumnName());
                    }
                }
            }
            EcmUserSetting ecmUserSetting = ecmUserPreferenceDaoService.getUseSetting(teamViewProcess.getTeam(),
                    teamViewProcess.getView());
            if (null != ecmUserSetting) {
            	ColumnsSortOrderSettings ecmColumnsOrderSettings = ecmUserPreferenceDaoService
						.getEcmFirstColumnOrderSetting(ecmUserSetting.getId());
                teamViewProcess.setSortBy(ecmColumnsOrderSettings.getSortOrder());
                EcmViewColumn ecmViewColumn = ecmUserPreferenceDaoService.getEcmViewColumn(ecmUserSetting.getViewId(),
                		ecmColumnsOrderSettings.getColumnId());
                if (null != ecmViewColumn)
                    teamViewProcess.setColumnIndex(ecmViewColumn.getColumnOrder());
                teamViewProcess.setResultPerPage(ecmUserSetting.getResultsPerPage());
            }
            teamViewProcess.setColumnList(columnList);
        } catch (Exception e) {
            LOGGER.error("Exception occurred while getting getColumnList : " + e.toString());
            throw new ApplicationException("Exception has occurred :: getColumnList() ", e);

        }
        return map;

    }

    @Override
    public Map<Long, String> getColumnList(CmpReqIdSearchProcess cmpReqIdSearchProcess) throws Exception {
        Map<Long, String> map = new LinkedHashMap<Long, String>();
        List<String> columnNames = new ArrayList<String>();
        try {

            List<EcmViewColumn> viewColumnList = ecmUserPreferenceDaoService.getEcmViewColumn(cmpReqIdSearchProcess
                    .getView());
            if (!CollectionUtils.isEmpty(viewColumnList)) {
                for (EcmViewColumn ecmViewColumn : viewColumnList) {
                    if (ecmViewColumn.getEcmColumn() != null) {
                        map.put(ecmViewColumn.getEcmColumn().getId(), ecmViewColumn.getEcmColumn().getUiColumnName());
                        columnNames.add(ecmViewColumn.getEcmColumn().getUiColumnName());
                    }
                }
            }
            EcmUserSetting ecmUserSetting = ecmUserPreferenceDaoService.getUseSetting(cmpReqIdSearchProcess.getSsoId(),
                    cmpReqIdSearchProcess.getView());
            if (null != ecmUserSetting) {
            	ColumnsSortOrderSettings ecmColumnsOrderSettings = ecmUserPreferenceDaoService
						.getEcmFirstColumnOrderSetting(ecmUserSetting.getId());
                cmpReqIdSearchProcess.setSortBy(ecmColumnsOrderSettings.getSortOrder());
                EcmViewColumn ecmViewColumn = ecmUserPreferenceDaoService.getEcmViewColumn(ecmUserSetting.getViewId(),
                		ecmColumnsOrderSettings.getColumnId());
                if (null != ecmViewColumn)
                    cmpReqIdSearchProcess.setColumnIndex(ecmViewColumn.getColumnOrder());
                cmpReqIdSearchProcess.setResultPerPage(ecmUserSetting.getResultsPerPage());
            }
            cmpReqIdSearchProcess.setCmpSearchResultsColumnList(columnNames);

        } catch (Exception e) {
            LOGGER.error("Exception occurred while getting getColumnList : " + e.toString());
            throw new ApplicationException("Exception has occurred :: getColumnList() ", e);

        }
        return map;
    }

}
