/**
 * 
 */
package com.citigroup.cgti.c3par.admin.domain;

import java.io.Serializable;
import java.util.List;

import com.citigroup.cgti.c3par.domain.Role;

/**
 * @author ka58098
 * 
 */
public class BulkContactUpdateDTO implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = -8273396788366535888L;

    private String userSsoId;
    private String ssoId;
    private String contactName;
    private String id;
    private String roleName;
    private String newRoleName;
    private String fullName;
    private String firstName;
    private String lastName;
    private String action;
    private String replaceSsoId;
    private Long ccrId;
    private String ccrName;
    private String isPrimary;
    private String isNotify;
    private Long planningId;
    private Long tiRequestId;
    private Long citiContactId;
    private Long conReqCitiContactId;
    private String isChecked;
    private List<Role> roleList;
    private List<BulkContactUpdateDTO> searchResultDTOList;
    private Long roleId;
    private String email;
    private String contactType;
    private boolean isSelected;
    private String displayRoleName;
    private String displayNewRoleName;

    /**
     * @return the ssoId
     */
    public String getSsoId() {
        return ssoId;
    }

    /**
     * @param ssoId
     *            the ssoId to set
     */
    public void setSsoId(String ssoId) {
        this.ssoId = ssoId;
    }

    /**
     * @return the action
     */
    public String getAction() {
        return action;
    }

    /**
     * @param action
     *            the action to set
     */
    public void setAction(String action) {
        this.action = action;
    }

    /**
     * @return the replaceSsoId
     */
    public String getReplaceSsoId() {
        return replaceSsoId;
    }

    /**
     * @param replaceSsoId
     *            the replaceSsoId to set
     */
    public void setReplaceSsoId(String replaceSsoId) {
        this.replaceSsoId = replaceSsoId;
    }

    /**
     * @return the ccrId
     */
    public Long getCcrId() {
        return ccrId;
    }

    /**
     * @param ccrId
     *            the ccrId to set
     */
    public void setCcrId(Long ccrId) {
        this.ccrId = ccrId;
    }

    /**
     * @return the ccrName
     */
    public String getCcrName() {
        return ccrName;
    }

    /**
     * @param ccrName
     *            the ccrName to set
     */
    public void setCcrName(String ccrName) {
        this.ccrName = ccrName;
    }

    /**
     * @return the isPrimary
     */
    public String getIsPrimary() {
        return isPrimary;
    }

    /**
     * @param isPrimary
     *            the isPrimary to set
     */
    public void setIsPrimary(String isPrimary) {
        this.isPrimary = isPrimary;
    }

    /**
     * @return the isNotify
     */
    public String getIsNotify() {
        return isNotify;
    }

    /**
     * @param isNotify
     *            the isNotify to set
     */
    public void setIsNotify(String isNotify) {
        this.isNotify = isNotify;
    }

    /**
     * @return the planningId
     */
    public Long getPlanningId() {
        return planningId;
    }

    /**
     * @param planningId
     *            the planningId to set
     */
    public void setPlanningId(Long planningId) {
        this.planningId = planningId;
    }

    /**
     * @return the citiContactId
     */
    public Long getCitiContactId() {
        return citiContactId;
    }

    /**
     * @param citiContactId
     *            the citiContactId to set
     */
    public void setCitiContactId(Long citiContactId) {
        this.citiContactId = citiContactId;
    }

    /**
     * @return the conReqCitiContactId
     */
    public Long getConReqCitiContactId() {
        return conReqCitiContactId;
    }

    /**
     * @param conReqCitiContactId
     *            the conReqCitiContactId to set
     */
    public void setConReqCitiContactId(Long conReqCitiContactId) {
        this.conReqCitiContactId = conReqCitiContactId;
    }

    /**
     * @return the isChecked
     */
    public String getIsChecked() {
        return isChecked;
    }

    /**
     * @param isChecked
     *            the isChecked to set
     */
    public void setIsChecked(String isChecked) {
        this.isChecked = isChecked;
    }

    public void setRoleList(List<Role> roleList) {
        this.roleList = roleList;

    }

    public List<Role> getRoleList() {
        return roleList;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public Long getTiRequestId() {
        return tiRequestId;
    }

    public void setTiRequestId(Long tiRequestId) {
        this.tiRequestId = tiRequestId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Long getRoleId() {
        return roleId;
    }

    public void setRoleId(Long roleId) {
        this.roleId = roleId;
    }

    public String getNewRoleName() {
        return newRoleName;
    }

    public void setNewRoleName(String newRoleName) {
        this.newRoleName = newRoleName;
    }
   

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getContactName() {
        return contactName;
    }

    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    public String getUserSsoId() {
        return userSsoId;
    }

    public void setUserSsoId(String userSsoId) {
        this.userSsoId = userSsoId;
    }

	/**
	 * @return the searchResultDTOList
	 */
	public List<BulkContactUpdateDTO> getSearchResultDTOList() {
		return searchResultDTOList;
	}

	/**
	 * @param searchResultDTOList the searchResultDTOList to set
	 */
	public void setSearchResultDTOList(List<BulkContactUpdateDTO> searchResultDTOList) {
		this.searchResultDTOList = searchResultDTOList;
	}

	/**
	 * @return the contactType
	 */
	public String getContactType() {
		return contactType;
	}

	/**
	 * @param contactType the contactType to set
	 */
	public void setContactType(String contactType) {
		this.contactType = contactType;
	}

	/**
	 * @return the isSelected
	 */
	public boolean isSelected() {
		return isSelected;
	}

	/**
	 * @param isSelected the isSelected to set
	 */
	public void setSelected(boolean isSelected) {
		this.isSelected = isSelected;
	}

    public String getDisplayRoleName() {
        return displayRoleName;
    }

    public void setDisplayRoleName(String displayRoleName) {
        this.displayRoleName = displayRoleName;
    }

    public String getDisplayNewRoleName() {
        return displayNewRoleName;
    }

    public void setDisplayNewRoleName(String displayNewRoleName) {
        this.displayNewRoleName = displayNewRoleName;
    }
    

}
