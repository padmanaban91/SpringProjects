package com.citigroup.cgti.c3par.communication.domain.service;

import java.util.List;

import com.citigroup.cgti.c3par.communication.domain.EcmColumn;
import com.citigroup.cgti.c3par.communication.domain.ColumnsSortOrderSettings;
import com.citigroup.cgti.c3par.communication.domain.EcmUserPreference;
import com.citigroup.cgti.c3par.communication.domain.EcmUserSetting;
import com.citigroup.cgti.c3par.communication.domain.EcmViewColumn;

public interface EcmUserPreferenceDaoService {

	List<EcmUserPreference> getEcmUserPreference(String ssoId, String viewId) throws Exception;

	List<EcmViewColumn> getEcmViewColumn(String viewId) throws Exception;

	EcmUserSetting getUseSetting(String userId, String viewId) throws Exception;

	EcmViewColumn getEcmViewColumn(Long viewId, Long columnId) throws Exception;

	List<EcmViewColumn> unselectedColumn(String ssoId, String viewId, boolean isSelected) throws Exception;

	boolean saveOrDeleteEcmUserPreference(EcmUserPreference ecmUserPreference, boolean isSelected) throws Exception;

	Long saveOrUpdateSetting(EcmUserSetting ecmUserSetting) throws Exception;

	List<EcmColumn> getColumnDetails(String viewId) throws Exception;

	EcmUserPreference saveEcmUserPreference(String ssoId);

	List<ColumnsSortOrderSettings> getEcmColumnsOrderSetting(Long ecmUserSettingId) throws Exception;

	Long saveOrUpdateSetting(ColumnsSortOrderSettings ecmColumnsOrderSettings) throws Exception;

	void deleteEcmColumnsOrderSettingIfPresent(Long ecmUserSettingId, Long ecmColumnIdOrder) throws Exception;

	ColumnsSortOrderSettings getEcmFirstColumnOrderSetting(Long ecmUserSettingId) throws Exception;
}
