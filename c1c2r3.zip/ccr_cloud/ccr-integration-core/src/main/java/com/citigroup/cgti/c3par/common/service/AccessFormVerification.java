/**
 * 
 */
package com.citigroup.cgti.c3par.common.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.citigroup.cgti.c3par.ccrcmpmapping.service.CCRCMPMappingService;
import com.citigroup.cgti.c3par.communication.domain.BusinessUserProcess;
import com.citigroup.cgti.c3par.communication.domain.CMPRequest;
import com.citigroup.cgti.c3par.communication.domain.CMPRequestContactXref;
import com.citigroup.cgti.c3par.communication.domain.CcrCmpXrefDto;
import com.citigroup.cgti.c3par.communication.domain.CmpRequestDTO;
import com.citigroup.cgti.c3par.configuation.CCRQueries;
import com.citigroup.cgti.c3par.configuation.QueryConstants;

/**
 * @author ka58098
 *
 */
@Component("accessFormVerificationJob")
@Transactional
public class AccessFormVerification {
    private static final Logger LOGGER=Logger.getLogger(AccessFormVerification.class);
    
    private static final String TEMPALTE_ID="ACCESS_FORM_VERIFICATION";
    private static final String SYSTEM="system";
    
    @Autowired
    private SessionFactory sessionFactory;
    @Autowired
    private CCRCMPMappingService cCRCMPMappingService;
    @Autowired
    private CCRQueries ccrQueries;
    
    @SuppressWarnings("unchecked")
    public void accessFormVerification() {
        Session session = sessionFactory.getCurrentSession();
        String queryForAccessFormVerification = ccrQueries.getQueryByName(QueryConstants.ACCES_FORM_VERIFICATION);
        SQLQuery sqlQuery = session.createSQLQuery(queryForAccessFormVerification);
        sqlQuery.addScalar("CMP_ID", LongType.INSTANCE);
        sqlQuery.addScalar("TI_REQUEST_ID", LongType.INSTANCE);
        sqlQuery.addScalar("ORDER_ITEM_ID", StringType.INSTANCE);
        sqlQuery.addScalar("PROCESS_ID", LongType.INSTANCE);
        List<Object[]> resultList = sqlQuery.list();
        if(!CollectionUtils.isEmpty(resultList)){
            BusinessUserProcess businessUserProcess=new BusinessUserProcess();
            CMPRequest cmpRequest;
            CmpRequestDTO cmpRequestDTO;
            String cmpReqId;
            Long cmpId;
            Long tiRequestId;
            Long processId;
            for (Object[] obj : resultList) {
                try{
                if (null == obj[0] || null == obj[1] || null==obj[2] || null==obj[3] )
                    continue;
                cmpRequest = new CMPRequest();
                cmpRequestDTO = new CmpRequestDTO();
                cmpId = (Long)(obj[0]);
                tiRequestId = (Long) obj[1];
                processId=(Long)obj[3];
                LOGGER.info("obj[2]  value :: "+obj[2]);
                cmpReqId=String.valueOf( obj[2]);
                if (cmpReqId != null) {
                    cmpRequest = businessUserProcess.getCMPRequestDetails(cmpReqId);
                    businessUserProcess.setCmpCcrId(cmpRequest.getCcrId());
                    if (null!=cmpRequest) {
                        getToAddressDetais(cmpRequest,cmpRequestDTO);
                        setCCAddress(cmpRequest, cmpRequestDTO);
                        cmpRequestDTO.setTiRequestID(tiRequestId);
                        cmpRequestDTO.setSsoId(SYSTEM);
                        cmpRequestDTO.setCmpRequestId(cmpId);
                        cmpRequestDTO.setCmpId(cmpRequest.getOrderItemId());
                        cmpRequestDTO.setCcrId(String.valueOf(processId));
                        cmpRequestDTO.setCcrID(String.valueOf(processId));
                        cmpRequestDTO.setOrderId(cmpRequest.getOrderItemId());
                        cmpRequestDTO.setChooseEmail(TEMPALTE_ID);
                        businessUserProcess.sendEmailGenerationView(TEMPALTE_ID, cmpRequestDTO);  
                    }
             }
                
                }catch(Exception ex){
                    LOGGER.error(ex.toString(),ex);
                }

            }
        }

    }
    private void getToAddressDetais(CMPRequest cmpRequest,CmpRequestDTO cmpRequestDTO){
        StringBuilder primaryOwnerName=new StringBuilder();
        StringBuilder toAddress=new StringBuilder();
        for (CMPRequestContactXref cmpRequestContactXref : cmpRequest.getCmpRequestContactXrefs()) {
            try{
            String role = cmpRequestContactXref.getRole().getName();
            if (null==role  || null== cmpRequestContactXref.getCiticontact()) {
                continue;
                }
                if ("Requestor".equalsIgnoreCase(role) || "Business_Owner".equalsIgnoreCase(role) || "Sec_Business_Owner".equalsIgnoreCase(role) ) {
                    if (primaryOwnerName.length() < 1) {
                        primaryOwnerName.append(cmpRequestContactXref.getCiticontact().getFirstName() + " "
                                + cmpRequestContactXref.getCiticontact().getLastName());
                    } else {
                        primaryOwnerName.append(", " + cmpRequestContactXref.getCiticontact().getFirstName() + " "
                                + cmpRequestContactXref.getCiticontact().getLastName());
                    }
                    if (toAddress.length() < 1) {
                        toAddress.append(cmpRequestContactXref.getCiticontact().getEmail());
                    } else {
                        toAddress.append("; " + cmpRequestContactXref.getCiticontact().getEmail());
                    }
                    if (!"E".equalsIgnoreCase(cmpRequestContactXref.getCiticontact().getEmployeeType())) {
                        cmpRequestDTO.setSecondTemplate(true);
                    }
                } 
        
            }catch(Exception ex){
                LOGGER.error(ex.toString(),ex);
            }
        }
        cmpRequestDTO.setToAddresses(toAddress.toString());
        cmpRequestDTO.setRequestorName(primaryOwnerName.toString());
        
    }
    
    /**
     * Method to set Agent in CCAddress of mail notification. 
     * @param cmpRequest
     * @param cmpRequestDTO
     */
    private void setCCAddress(CMPRequest cmpRequest,CmpRequestDTO cmpRequestDTO) {
        StringBuilder ccAddress=new StringBuilder();
        if(cmpRequest.getAssignedUser() != null) {
            ccAddress.append(cmpRequest.getAssignedUser().getEmail());
        }
        LOGGER.debug("CMP Request : " + cmpRequest.getOrderItemId() + " ccAddress: " + ccAddress);
        cmpRequestDTO.setCcAddresses(ccAddress.toString());        
    }
    
}
