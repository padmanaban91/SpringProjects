package com.citigroup.cgti.c3par.common.domain;

import java.io.Serializable;
import java.util.Date;

public class TIMailAuditAttachments implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private Long id;

    private TIMailAudit tiMailAudit;
    
    private byte[] fileContent;
    
    private Date createdDate;
    
    private String fileName;
    
    private String documentMimeType;
    
    private String createdBy;
    
    private String documentName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public TIMailAudit getTiMailAudit() {
        return tiMailAudit;
    }

    public void setTiMailAudit(TIMailAudit tiMailAudit) {
        this.tiMailAudit = tiMailAudit;
    }

    public byte[] getFileContent() {
        return fileContent;
    }

    public void setFileContent(byte[] fileContent) {
        this.fileContent = fileContent;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getDocumentMimeType() {
        return documentMimeType;
    }

    public void setDocumentMimeType(String documentMimeType) {
        this.documentMimeType = documentMimeType;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
    
}
