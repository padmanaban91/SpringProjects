/**
 * 
 */
package com.citigroup.cgti.c3par.businessjustification.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.citigroup.cgti.c3par.domain.CMPRole;
import com.citigroup.cgti.c3par.domain.Role;

/**
 * @author ka58098
 *
 */
public class DistributionListDTO implements Serializable {

	private static final long serialVersionUID = 2852381701938494521L;
	
	private Long citiContactId;

	private List<CitiContact> citiContactList=new ArrayList<>();
	
	private List<Role> roleList=new ArrayList<>();
	
	private List<CMPRole> cmpRoleList=new ArrayList<>();
	
	private Long roleId;
	
	private String[] roleIds;
	
	private Long tiRequestId;
	
	private Long planningId;
	
	private Long cmpId;
	
	private String searchContent;
	
	private String contactType;
	
	private String status;

	public Long getCitiContactId() {
		return citiContactId;
	}

	public void setCitiContactId(Long citiContactId) {
		this.citiContactId = citiContactId;
	}

	public List<CitiContact> getCitiContactList() {
		return citiContactList;
	}

	public void setCitiContactList(List<CitiContact> citiContactList) {
		this.citiContactList = citiContactList;
	}

	public List<Role> getRoleList() {
		return roleList;
	}

	public void setRoleList(List<Role> roleList) {
		this.roleList = roleList;
	}
	
	

	public List<CMPRole> getCmpRoleList() {
		return cmpRoleList;
	}

	public void setCmpRoleList(List<CMPRole> cmpRoleList) {
		this.cmpRoleList = cmpRoleList;
	}

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}
	public String[] getRoleIds() {
		return roleIds;
	}

	public void setRoleIds(String[] roleIds) {
		this.roleIds = roleIds;
	}

	public Long getTiRequestId() {
		return tiRequestId;
	}

	public void setTiRequestId(Long tiRequestId) {
		this.tiRequestId = tiRequestId;
	}
	public Long getPlanningId() {
		return planningId;
	}

	public void setPlanningId(Long planningId) {
		this.planningId = planningId;
	}
	public Long getCmpId() {
		return cmpId;
	}

	public void setCmpId(Long cmpId) {
		this.cmpId = cmpId;
	}

	public String getSearchContent() {
		return searchContent;
	}

	public void setSearchContent(String searchContent) {
		this.searchContent = searchContent;
	}
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getContactType() {
		return contactType;
	}

	public void setContactType(String contactType) {
		this.contactType = contactType;
	}
	
}
