package com.citigroup.cgti.c3par.bpm.ejb.search.domain;

import java.io.Serializable;


/**
 * The Class ConIPAddressSearchAttributes.
 */
public class ConIPAddressSearchAttributes  extends BaseSearchAttributes implements Serializable{

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -3828763137580583865L;

    /** The ip address. */
    private String ipAddress=null;

    /** The nat ip. */
    private String natIP=null;

    /** The virtual ip. */
    private String virtualIP=null;

    /** The virtual natip. */
    private String virtualNATIP=null;

    /**
     * Gets the ip address.
     *
     * @return the ip address
     */
    public String getIpAddress() {
	return ipAddress;
    }

    public String getIpAddressForQuery() {
	return validString(ipAddress);
    }
    /**
     * Sets the ip address.
     *
     * @param ipAddress the new ip address
     */
    public void setIpAddress(String ipAddress) {
	this.ipAddress = ipAddress;
    }

    /**
     * Gets the nat ip.
     *
     * @return the nat ip
     */
    public String getNatIP() {
	return natIP;
    }

    public String getNatIPForQuery() {
	return validString(natIP);
    }
    /**
     * Sets the nat ip.
     *
     * @param natIP the new nat ip
     */
    public void setNatIP(String natIP) {
	this.natIP = natIP;
    }

    /**
     * Gets the virtual ip.
     *
     * @return the virtual ip
     */
    public String getVirtualIP() {
	return virtualIP;
    }

    public String getVirtualIPForQuery() {
	return validString(virtualIP);
    }
    /**
     * Sets the virtual ip.
     *
     * @param virtualIP the new virtual ip
     */
    public void setVirtualIP(String virtualIP) {
	this.virtualIP = virtualIP;
    }

    /**
     * Gets the virtual natip.
     *
     * @return the virtual natip
     */
    public String getVirtualNATIP() {
	return virtualNATIP;
    }

    public String getVirtualNATIPForQuery() {
	return validString(virtualNATIP);
    }
    /**
     * Sets the virtual natip.
     *
     * @param virtualNATIP the new virtual natip
     */
    public void setVirtualNATIP(String virtualNATIP) {
	this.virtualNATIP = virtualNATIP;
    }

}
