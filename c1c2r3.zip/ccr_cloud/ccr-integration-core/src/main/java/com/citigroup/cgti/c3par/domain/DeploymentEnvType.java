package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;

/**
 * The Class DeploymentEnvType.
 */
public class DeploymentEnvType extends Name implements Serializable{

}
