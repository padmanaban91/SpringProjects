package com.citigroup.cgti.c3par.ccrcmpmapping.dao.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.citigroup.cgti.c3par.common.domain.TIMailAudit;
import com.citigroup.cgti.c3par.common.domain.TIMailAuditAttachments;
import com.citigroup.cgti.c3par.communication.domain.BusinessUserProcess;
import com.citigroup.cgti.c3par.communication.domain.CCRCMPMappingDTO;
import com.citigroup.cgti.c3par.communication.domain.CMPRequest;
import com.citigroup.cgti.c3par.communication.domain.CcrCmpXrefDto;
import com.citigroup.cgti.c3par.communication.domain.CmpReqIdSearchProcess;
import com.citigroup.cgti.c3par.communication.domain.CmpRequestDTO;
import com.citigroup.cgti.c3par.communication.domain.CmpSearchView;
import com.citigroup.cgti.c3par.communication.domain.ColumnsSortOrderSettings;
import com.citigroup.cgti.c3par.communication.domain.EmailGenerationViewProcess;
import com.citigroup.cgti.c3par.communication.domain.EmerBuscritQuestionDto;
import com.citigroup.cgti.c3par.communication.domain.QuickSearchProcess;
import com.citigroup.cgti.c3par.communication.domain.CMPComments;

/**
 * @author ky38518
 * 
 */
public interface CCRCMPMappingDAOService {

    public void saveCCRCMPXref(String cmpOrderItemId, long tiRequestId);

    public List<CCRCMPMappingDTO> getCMPOrderItemList(String searchString);

    public boolean isCMPCCRMappingExists(String cmpOrderItemId, long tiRequestId);

    public boolean deleteCmpFromCCR(long cmpCcrMappingId);

    public List<CcrCmpXrefDto> getCcrCmpXrefByOrderItemId(String cmpReqId);

    public List<String> validateLinkedCCR(String processId);

    public String getOrderItemIdforTIRequest(long tiRequestId);

    public Long getTIRequestID(String ccrID);

    public CcrCmpXrefDto getCcrCmpXrefByOrderItemId(String cmpReqId, Long tiRequestId);

    public int checkCMPStatus(long tiRequestId);

    public Map<String, String> getCompletedUserDetails(long tiRequestId);

    public Map<String, List<String>> getCMPCCRDetails(long tiRequestId);

    public String getCMPXMLContent(String cmpId);

    public int updateCMPStatus(String status, String cmpId);

    public Map<String, List<String>> getMappedCMPIdForCCRId(long tiRequestId);

    public String getGEIdforUser(String ssoId);

    public String getTaskDescriptionForActivity(long activityTrailId);

    public CMPRequest getCMPRequestDetailsByOrderItemId(String cmpOrderItemId);

    public Long getCmpSloHrs(long cmpId, Long tiRequestId);

    public void clearMappedCMPIds(long tiRequestId);

    public void logECMActivityTrail(long tiRequestId);

    public void completeECMActivityTrail(long tiRequestId);

    public List<Long> getCcrIdList(String cmpReqId);

    /**
     * @param cmpReqIdSearchProcess
     * @param ecmColumnsOrderSettingsList
     * @return
     * @throws Exception
     */
    public List<CmpSearchView> getCMPList(CmpReqIdSearchProcess cmpReqIdSearchProcess, boolean isExport,
            List<ColumnsSortOrderSettings> ecmColumnsOrderSettingsList) throws Exception;

    /**
     * @return
     * @throws Exception
     */
    public List<String> getTask() throws Exception;

    /**
     * @return
     * @throws Exception
     */
    public List<String> getEcmAgent(boolean isServiceDesk) throws Exception;

    /**
     * @param tiRequestId
     * @return
     * @throws Exception
     */
    public String getChangeRequestID(Long tiRequestId) throws Exception;

    /**
     * @param cmpRequestDirApproval
     * @return
     * @throws Exception
     */
    public EmerBuscritQuestionDto getEmerBuscritQuestions(String cmpRequestDirApproval) throws Exception;

    public String getDirectorApprovalCmpforTIRequest(long tiRequestId);

    public Date getEarliestDate() throws Exception;

    public Long findResentMailAuditId(Long cmpId);

    public TIMailAudit findTiMailAudit(Long auditId);

    public List<TIMailAuditAttachments> getEmailAuditTrailAttachments(Long auditId);

    /**
     * Given a ccr id (tirequestid) and a cmp order item id , this method marks
     * all the open status in activity trail as completed. Please note , it only
     * updates the audit trail table for cmp only not ccr. (where cmp id is not
     * null and ccr id is null)
     * 
     * This method is used to update the activity trail table when a ccr linked
     * to a cmp is completed/made active. Once all ccrs linked to a cmp goes
     * active , the corresponding cmp should also be marked as completed.
     * however the audit trail was remaining open , this resulted in incorrect
     * timer calculation.
     * 
     * @param tiRequestId
     * @param cmpOrderItemId
     */
    public void completeECMActivtyTrail_By_TiReqId_CMP_OrdItemId(long tiRequestId, String cmpOrderItemId);

    public Map<String, String> getOrderItemIdStatusMap(String tiRequestId) throws Exception;

    public Long saveCmpComments(CmpRequestDTO cmpRequestDTO);

    public void updateCmpComments(BusinessUserProcess businessUserProcess, CmpRequestDTO cmpRequestDTO);

    public List<String> getRejectedCcrId(String cmpReqId);

    public QuickSearchProcess finSearchProcessByCcrID(String ccrId);

    public String getCcrStatus(String tiRequestID);

    public EmailGenerationViewProcess getECMReqInfo(EmailGenerationViewProcess emailGenerationViewProcess);

    public BusinessUserProcess getECMCommentsInfo(BusinessUserProcess businessUserProcess);

    public String getSectorName(String sectorId);

    public String getBusinessUnitName(String businessUnitId);

    public CMPComments findCmpCommentsByMailAuditId(Long auditId);

	public Long getCmpIdForTiRequestId(Long tiRequestId);

}
