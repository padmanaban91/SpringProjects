package com.citigroup.cgti.c3par.admin.domain;

import java.io.Serializable;
import java.util.List;

/**
 * @author ac81662
 *
 */
public class ManageMoreInfoTagDTO  implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private String tag;
    private Long tagId;
    private boolean isSelected;
    private List<ManageMoreInfoTagDTO> tagsList;
    
    public String getTag() {
        return tag;
    }
    public void setTag(String tag) {
        this.tag = tag;
    }
    public Long getTagId() {
        return tagId;
    }
    public void setTagId(Long tagId) {
        this.tagId = tagId;
    }
    public List<ManageMoreInfoTagDTO> getTagsList() {
        return tagsList;
    }
    public void setTagsList(List<ManageMoreInfoTagDTO> tagsList) {
        this.tagsList = tagsList;
    }
    public boolean isSelected() {
        return isSelected;
    }
    public void setSelected(boolean isSelected) {
        this.isSelected = isSelected;
    }  
}
