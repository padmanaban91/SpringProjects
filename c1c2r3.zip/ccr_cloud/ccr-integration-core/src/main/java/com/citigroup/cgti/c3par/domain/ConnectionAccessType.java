package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;

/**
 * The Class ConnectionAccessType.
 */
public class ConnectionAccessType extends Name implements Serializable{

}
