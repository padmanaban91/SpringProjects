/**
 * 
 */
package com.citigroup.cgti.c3par.common.domain;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.apache.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.transform.Transformers;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.audit.domain.AuditC3parUsersData;
import com.citigroup.cgti.c3par.common.domain.soc.persist.CommonServicePersistable;
import com.citigroup.cgti.c3par.configuation.CCRQueries;
import com.citigroup.cgti.c3par.relationship.domain.CitiHierarchyMaster;
import com.citigroup.cgti.c3par.relationship.domain.Region;
import com.citigroup.cgti.c3par.relationship.domain.Sector;
import com.citigroup.cgti.c3par.user.domain.C3parUser;
import com.citigroup.cgti.c3par.user.domain.C3parUserHierarchyXref;
import com.citigroup.cgti.c3par.user.domain.C3parUserRoleXref;
import com.citigroup.cgti.c3par.user.domain.SecurityRole;
import com.citigroup.cgti.c3par.util.C3parProperties;
import com.mentisys.util.databaserealm.PasswordEncryption;

/**
 * @author ka58098
 *
 */
@Component("citiUserEntitlementScheduler")
@Transactional
public class CitiUserEntitlementScheduler {
	private static final Logger LOGGER = Logger.getLogger(CitiUserEntitlementScheduler.class);
	@Autowired
	private SessionFactory sessionFactory;
	@Autowired
	private CCRQueries ccrQueries;
	@Autowired
	private CommonServicePersistable commonServicePersistable;
	private static final String CITI_CONTACT_ENTITLE_START = "CITI_CONTACT_ENTITLE_START";
	private static final String GET_CITI_CONTACT_ENTITLE = "GET_CITI_CONTACT_ENTITLE";

	private static final String PLANNING_ID = "planningId";
	private static final String PROCESS_ID = "processId";
	private static final String RELATIONSHIP_ID = "relationshipId";
	private static final String TI_REQUEST_ID = "tiRequestId";
	private static final String CITI_CONTACT_ID = "citiContactId";
	private static final String USER_SSO_ID = "userSsoId";
	private static final String FIRST_NAME = "firstName";
	private static final String LAST_NAME = "lastName";
	private static final String EMAIL = "email";
	private static final String PHONE = "phone";
	
	private List<CitiContactAutoEntitlementDTO> userEntitlementList = new ArrayList<>();
	@Transactional
	public void citiUserEntitlement() {
		if (commonServicePersistable.isStartingFlag(CITI_CONTACT_ENTITLE_START)) {
			Session session = sessionFactory.getCurrentSession();
			SQLQuery sqlQuery = session.createSQLQuery(ccrQueries.getQueryByName(GET_CITI_CONTACT_ENTITLE));
			sqlQuery.addScalar(PROCESS_ID, LongType.INSTANCE);
			sqlQuery.addScalar(PLANNING_ID, LongType.INSTANCE);
			sqlQuery.addScalar(TI_REQUEST_ID, LongType.INSTANCE);
			sqlQuery.addScalar(RELATIONSHIP_ID, LongType.INSTANCE);
			sqlQuery.addScalar(CITI_CONTACT_ID, LongType.INSTANCE);
			sqlQuery.addScalar(USER_SSO_ID, StringType.INSTANCE);
			sqlQuery.addScalar(FIRST_NAME, StringType.INSTANCE);
			sqlQuery.addScalar(LAST_NAME, StringType.INSTANCE);
			sqlQuery.addScalar(EMAIL, StringType.INSTANCE);
			sqlQuery.addScalar(PHONE, StringType.INSTANCE);
			sqlQuery.setResultTransformer(Transformers.aliasToBean(CitiContactAutoEntitlementDTO.class));
			userEntitlementList = sqlQuery.list();
			giveUserEntitlement();
		}

	}
	private void giveUserEntitlement() {
		C3parUser c3parUser;
		AdminProcess adminprocess = new AdminProcess();
		List<SecurityRole> securityRolelist = adminprocess.getSecurityRolesForCitiUser();
		Long c3parUserId;
		boolean isAdd;
		for (CitiContactAutoEntitlementDTO citiContactDTO : userEntitlementList) {
			try {
				c3parUser=adminprocess.retrieveC3parUser(citiContactDTO.getUserSsoId());
				if(null==c3parUser){
				c3parUser = new C3parUser();
				c3parUser.setFirstName(citiContactDTO.getFirstName().trim());
				c3parUser.setLastName(citiContactDTO.getLastName().trim());
				c3parUser.setEmail(citiContactDTO.getEmail().trim());
				c3parUser.setSsoId(citiContactDTO.getUserSsoId().trim());
				String password = citiContactDTO.getUserSsoId().trim().toLowerCase() + "!!";
				password = PasswordEncryption.getInstance().encrypt(password);
				c3parUser.setPassword(password);
				c3parUser.setCreated_date(new Date());
				c3parUser.setActive("Y");
				c3parUser.setWfStatus("system_new_user");
				c3parUser.setRequestedBy("initialize_migration");
				c3parUser.setRequestedDate(new Date());
				List<C3parUserRoleXref> userRoleList = new ArrayList<>();
				C3parUserRoleXref c3parUserRoleXref;
				for (SecurityRole securityRole : securityRolelist) {
					c3parUserRoleXref = new C3parUserRoleXref();
					c3parUserRoleXref.setC3parUser(c3parUser);
					c3parUserRoleXref.setSecurityRole(securityRole);
					c3parUserRoleXref.setUpdated_date(new Date());
					userRoleList.add(c3parUserRoleXref);
				}
				c3parUser.setUserRoleList(userRoleList);
				List<CitiHierarchyMaster> citihiermaslist = adminprocess
						.getConnectionRegSecBU(citiContactDTO.getProcessId());
				List<C3parUserHierarchyXref> hierxreflist = new ArrayList<>();
				C3parUserHierarchyXref hierxref;
				CitiHierarchyMaster hiermas;
				for (CitiHierarchyMaster citihiermas : citihiermaslist) {
					hierxref = new C3parUserHierarchyXref();
					hiermas = new CitiHierarchyMaster();
					hiermas.setRegion(new Region());
					hiermas.getRegion().setId(citihiermas.getRegion().getId());
					hiermas.setSector(new Sector());
					hiermas.getSector().setId(citihiermas.getSector().getId());
					LOGGER.debug("requestUserEntitlement :: new UserEntitlement:: citihiermas.getRegion().getId()"
							+ citihiermas.getRegion().getId() + " = citihiermas.getSector().getId()-"
							+ citihiermas.getSector().getId());
					hierxref.setCitiHierarchyMaster(hiermas);
					hierxref.setInactive("N");
					hierxref.setC3parUser(c3parUser);
					hierxreflist.add(hierxref);
				}
				c3parUser.setUserHierarchyList(hierxreflist);
				c3parUser.setCreatedUser("system");
				c3parUser.setAdmin("N");
				adminprocess.setC3parUser(c3parUser);
				c3parUserId = adminprocess.saveC3parUser();
				LOGGER.debug("User Saved If Block " + c3parUserId);
				AuditC3parUsersData auditC3parUsersData = UserEntitlementUtil.createAuditUsersData(c3parUserId, adminprocess, "system");
				LOGGER.info("auditC3parUsersData.getUserId() :: "+auditC3parUsersData.getUserId());
				String status = auditC3parUsersData.getIsActiveCurrent();
				if (status != null) {
					status = status.equals("Y") ? "ACTIVE" : "IN-ACTIVE";
				}
				auditC3parUsersData.setAction("CREATE");
				auditC3parUsersData.setEventDescription("User " + c3parUser.getSsoId() + " Created and Status is " + status);
				auditC3parUsersData.setRoleStrCurrent("Business User,C3PARUSER,Entitlement Requester");
				auditC3parUsersData.setHostName(C3parProperties.CCR_HOST_NAME);
				auditC3parUsersData.setHostNameAddress(C3parProperties.CCR_HOST_NAME+".citigroup.net");
				LOGGER.debug("Before auditC3parUsersData Save " + auditC3parUsersData.toString());
				adminprocess.saveAuditUsersData();
				} else {
                    // add region and sector if not exists
                    List<CitiHierarchyMaster> citihiermaslist = adminprocess.getConnectionRegSecBU(citiContactDTO.getProcessId());
                    List<C3parUserHierarchyXref> userhierxreflist = c3parUser.getUserHierarchyList();
                    List<C3parUserHierarchyXref> hierxreflist = new ArrayList<C3parUserHierarchyXref>();
                    C3parUserHierarchyXref hierxref = null;
                    CitiHierarchyMaster hiermas = null;
                    for (CitiHierarchyMaster citihiermas : citihiermaslist) {
                        isAdd = true;
                        if (userhierxreflist != null && !userhierxreflist.isEmpty()) {
                            for (C3parUserHierarchyXref userhierxref : userhierxreflist) {
                                if (citihiermas.getRegion().getId()
                                        .equals(userhierxref.getCitiHierarchyMaster().getRegion().getId())
                                        && citihiermas.getSector().getId()
                                                .equals(userhierxref.getCitiHierarchyMaster().getSector().getId())) {
                                    isAdd = false;
                                }
                            }
                        }
                        if (isAdd) {
                            hierxref = new C3parUserHierarchyXref();
                            hiermas = new CitiHierarchyMaster();
                            hiermas.setRegion(new Region());
                            hiermas.getRegion().setId(citihiermas.getRegion().getId());
                            hiermas.setSector(new Sector());
                            hiermas.getSector().setId(citihiermas.getSector().getId());
                            LOGGER.debug("requestUserEntitlement :: new UserEntitlement:: citihiermas.getRegion().getId()"
                                    + citihiermas.getRegion().getId()
                                    + " = citihiermas.getSector().getId()-"
                                    + citihiermas.getSector().getId());
                            hierxref.setCitiHierarchyMaster(hiermas);
                            hierxref.setInactive("N");
                             hierxreflist.add(hierxref);
                        }
                    }
                    c3parUser.getUserHierarchyList().addAll(hierxreflist);
                    LOGGER.debug("requestUserEntitlement :: update requestUserEntitlement:: getUserHierarchyList - "
                            + c3parUser.getUserHierarchyList().size());
                    c3parUser.setWfStatus("system_new_user");
                    c3parUser.setRequestedBy("initialize_migration");
                    // save the user
                    adminprocess.setC3parUser(c3parUser);
                    c3parUserId = adminprocess.saveC3parUser();
                    LOGGER.debug("User Saved Else Block");
				}
				
			} catch (Exception ex) {
				LOGGER.error("Error has occurred at " + ex);
			}
		}

	}
}
