/**
 * 
 */
package com.citigroup.cgti.c3par.communication.domain;

import java.io.Serializable;
import java.util.Date;

/**
 * @author ka58098
 *
 */
public class BaseView implements Serializable {

    private static final long serialVersionUID = 1L;
    private Long id;
    private Long cmpId;
    private Long tiRequestId;
    private Long processId;
    private Long version;
    private String orderId;
    private String orderItemId;
    private String status;
    private String orderByUser;
    private String orderForUser;
    private String requestType;
    private String typeofConnectivityInvolved;
    private String requestUrgency;
    private Long sloDays;
    private Long ccrId;
    private String ccrIdWithVerNo;
    private Date updateAssignedUserDate;
    private String checkTiId;
    private String taskName;
    private String taskCode;
    private String sloStatus;
    private String slo;
    private String chgId;
    private String chgDate;
    private String dateAssigned;
    private String currentStatus;
    private Long ecmTimer;
    private Long cmpCcrId;
    private String requestTypeValue;
    public String getRequestTypeValue() {
		return requestTypeValue;
	}

	public void setRequestTypeValue(String requestTypeValue) {
		this.requestTypeValue = requestTypeValue;
	}

	public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCmpId() {
        return cmpId;
    }

    public void setCmpId(Long cmpId) {
        this.cmpId = cmpId;
    }

    public Long getTiRequestId() {
        return tiRequestId;
    }

    public void setTiRequestId(Long tiRequestId) {
        this.tiRequestId = tiRequestId;
    }

    public Long getProcessId() {
        return processId;
    }

    public void setProcessId(Long processId) {
        this.processId = processId;
    }

    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getOrderItemId() {
        return orderItemId;
    }

    public void setOrderItemId(String orderItemId) {
        this.orderItemId = orderItemId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getOrderByUser() {
        return orderByUser;
    }

    public void setOrderByUser(String orderByUser) {
        this.orderByUser = orderByUser;
    }

    public String getOrderForUser() {
        return orderForUser;
    }

    public void setOrderForUser(String orderForUser) {
        this.orderForUser = orderForUser;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public String getTypeofConnectivityInvolved() {
        return typeofConnectivityInvolved;
    }

    public void setTypeofConnectivityInvolved(String typeofConnectivityInvolved) {
        this.typeofConnectivityInvolved = typeofConnectivityInvolved;
    }

    public String getRequestUrgency() {
        return requestUrgency;
    }

    public void setRequestUrgency(String requestUrgency) {
        this.requestUrgency = requestUrgency;
    }

    public Long getSloDays() {
        return sloDays;
    }

    public void setSloDays(Long sloDays) {
        this.sloDays = sloDays;
    }

    public Long getCcrId() {
        return ccrId;
    }

    public void setCcrId(Long ccrId) {
        this.ccrId = ccrId;
    }

    public String getCcrIdWithVerNo() {
        return ccrIdWithVerNo;
    }

    public void setCcrIdWithVerNo(String ccrIdWithVerNo) {
        this.ccrIdWithVerNo = ccrIdWithVerNo;
    }

    public Date getUpdateAssignedUserDate() {
        return updateAssignedUserDate;
    }

    public void setUpdateAssignedUserDate(Date updateAssignedUserDate) {
        this.updateAssignedUserDate = updateAssignedUserDate;
    }

    public String getCheckTiId() {
        return checkTiId;
    }

    public void setCheckTiId(String checkTiId) {
        this.checkTiId = checkTiId;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getTaskCode() {
        return taskCode;
    }

    public void setTaskCode(String taskCode) {
        this.taskCode = taskCode;
    }

    public String getSloStatus() {
        return sloStatus;
    }

    public void setSloStatus(String sloStatus) {
        this.sloStatus = sloStatus;
    }

    public String getSlo() {
        return slo;
    }

    public void setSlo(String slo) {
        this.slo = slo;
    }

    public String getChgId() {
        return chgId;
    }

    public void setChgId(String chgId) {
        this.chgId = chgId;
    }

    public String getChgDate() {
        return chgDate;
    }

    public void setChgDate(String chgDate) {
        this.chgDate = chgDate;
    }

    public String getDateAssigned() {
        return dateAssigned;
    }

    public void setDateAssigned(String dateAssigned) {
        this.dateAssigned = dateAssigned;
    }

    public String getCurrentStatus() {
        return currentStatus;
    }

    public void setCurrentStatus(String currentStatus) {
        this.currentStatus = currentStatus;
    }

    public Long getEcmTimer() {
        return ecmTimer;
    }

    public void setEcmTimer(Long ecmTimer) {
        this.ecmTimer = ecmTimer;
    }

    public Long getCmpCcrId() {
        return cmpCcrId;
    }

    public void setCmpCcrId(Long cmpCcrId) {
        this.cmpCcrId = cmpCcrId;
    }
}
