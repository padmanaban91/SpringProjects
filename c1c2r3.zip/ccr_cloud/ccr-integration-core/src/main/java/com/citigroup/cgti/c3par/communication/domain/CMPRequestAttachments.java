package com.citigroup.cgti.c3par.communication.domain;

import com.citigroup.cgti.c3par.domain.Base;

public class CMPRequestAttachments extends Base {

	private Long cmpId;
	private String fileName;
	private String attchedFileUrl;
	private String attachmentName;	
	

	public Long getCmpId() {
		return cmpId;
	}

	public void setCmpId(Long cmpId) {
		this.cmpId = cmpId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getAttchedFileUrl() {
		return attchedFileUrl;
	}

	public void setAttchedFileUrl(String attchedFileUrl) {
		this.attchedFileUrl = attchedFileUrl;
	}

	public String getAttachmentName() {
		return attachmentName;
	}

	public void setAttachmentName(String attachmentName) {
		this.attachmentName = attachmentName;
	}
	

}
