package com.citigroup.cgti.c3par.communication.domain;

import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.CMPRole;


public class CMPRequestContactXref extends Base{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long cmpId;	
	private CitiContact citicontact;
	private CMPRole role;
	
	public Long getCmpId() {
		return cmpId;
	}
	public void setCmpId(Long cmpId) {
		this.cmpId = cmpId;
	}
	public CitiContact getCiticontact() {
		return citicontact;
	}
	public void setCiticontact(CitiContact citicontact) {
		this.citicontact = citicontact;
	}	
	public CMPRole getRole() {
		return role;
	}
	public void setRole(CMPRole role) {
		this.role = role;
	}	
}
