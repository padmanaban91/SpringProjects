package com.citigroup.cgti.c3par;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import com.citigroup.cgti.c3par.util.StringUtil;




/**
 * The Class POIExcelReaderProxy.
 */
@SuppressWarnings("unchecked")
public class POIExcelReaderProxy {
    
    private static Logger LOGGER = Logger.getLogger(POIExcelReaderProxy.class);
    /**
     * Instantiates a new pOI excel reader proxy.
     */
    public POIExcelReaderProxy() {
    }

    /**
     * Gets the cell value.
     *
     * @param cell the cell
     * @return the cell value
     */
    public static String getCellValue(Cell cell) {
    if (cell == null) {
        return null;
    }
    String cellValue = null;

    switch (cell.getCellType()) {
    case Cell.CELL_TYPE_NUMERIC:
        cellValue = String.valueOf(cell.getNumericCellValue());
        break;
    case Cell.CELL_TYPE_STRING:
        cellValue = cell.getStringCellValue();
        break;
    case Cell.CELL_TYPE_BLANK:
        cellValue = "";
        break;
    }

    return cellValue.trim();
    }

    /**
     * Parses the sheet.
     *
     * @param workbook the workbook
     * @param sheetName the sheet name
     * @return the list
     */
    public List parseSheet(Workbook workbook, String sheetName) {

    List columns = null;
    List rows = null;

	Sheet sheet = workbook.getSheet(sheetName);
	if (sheet != null) {
	    rows = new ArrayList();
	}
	List<Integer> emptyRowList = new ArrayList<Integer>();
	 LOGGER.debug("sheet.getPhysicalNumberOfRows():: "+sheet.getPhysicalNumberOfRows());
	for (int i = 1; i < sheet.getPhysicalNumberOfRows(); i++) {
	    Row xlRow = sheet.getRow(i);
	    if (xlRow == null) {
	    	continue;
	    } else {
			int noOfColumns = xlRow.getPhysicalNumberOfCells();
			noOfColumns=11;
			columns = new ArrayList();
			int count = 0;
			// for loop for number of cells which have contents
			for (int cellIndx = 0; cellIndx < noOfColumns; cellIndx++) {
			    Cell cell = xlRow.getCell((short) cellIndx);
	
			    /*if (cell == null) {
							continue;
						}*/
	
			    String cellValue = getCellValue(cell);
			    columns.add(cellValue);
			    if(StringUtil.isNullorEmpty(cellValue)) {
			    	++count;
			    }
			}
			if(count == noOfColumns) {
				emptyRowList.add(i);
			}
	    }
	    if (columns != null && columns.size() > 0) {
	    	rows.add(columns);
	    }
	}
	for(int i = emptyRowList.size()-1; i >= 0; --i) {
		int emptyRow = emptyRowList.get(i);
		rows.remove(emptyRow-1);
	}
	return rows;
    }

}
