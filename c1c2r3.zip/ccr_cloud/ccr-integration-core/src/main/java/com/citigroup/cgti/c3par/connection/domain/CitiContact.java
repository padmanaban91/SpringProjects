package com.citigroup.cgti.c3par.connection.domain;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.citigroup.cgti.c3par.model.CitiContactEntity;


/**
 * The Class CitiContact.
 */
@XmlRootElement
public class CitiContact extends CitiContactEntity implements Serializable{

    /** The dev access. */
    private String devAccess;

    /** The prd access. */
    private String prdAccess;

    /** The cross environment access. */
    private String crossEnvironmentAccess ;
    
    /** The local folder access. */
    private String localFolderAccess;
    
    private String devAccessXsl;
    
    private String prdAccessXsl;
    
    private String crossEnvXsl;
    
    private String localFolderXsl;
    
    private String employeeType;

    /**
     * Gets the cross environment access.
     *
     * @return the crossEnvironmentAccess
     */
    public String getCrossEnvironmentAccess() {
	return crossEnvironmentAccess;
    }

    /**
     * Sets the cross environment access.
     *
     * @param crossEnvironmentAccess the crossEnvironmentAccess to set
     */
    public void setCrossEnvironmentAccess(String crossEnvironmentAccess) {
	this.crossEnvironmentAccess = crossEnvironmentAccess;
    }

    /**
     * Gets the local folder access.
     *
     * @return the localFolderAccess
     */
    public String getLocalFolderAccess() {
	return localFolderAccess;
    }

    /**
     * Sets the local folder access.
     *
     * @param localFolderAccess the localFolderAccess to set
     */
    public void setLocalFolderAccess(String localFolderAccess) {
	this.localFolderAccess = localFolderAccess;
    }

    

    /**
     * Gets the dev access.
     *
     * @return the dev access
     */
    public String getDevAccess() {
	return devAccess;
    }

    /**
     * Sets the dev access.
     *
     * @param devAccess the new dev access
     */
    public void setDevAccess(String devAccess) {
	this.devAccess = devAccess;
    }

    /**
     * Gets the prd access.
     *
     * @return the prd access
     */
    public String getPrdAccess() {
	return prdAccess;
    }

    /**
     * Sets the prd access.
     *
     * @param prdAccess the new prd access
     */
    public void setPrdAccess(String prdAccess) {
	this.prdAccess = prdAccess;
    }
    
    @XmlElement
	public String getDevAccessXsl() {
		StringBuilder str = new StringBuilder();
		if(this.devAccess != null && this.devAccess.equalsIgnoreCase("N")){
			str.append("No Access");
		}if(this.devAccess != null && this.devAccess.equalsIgnoreCase("U")){
			str.append("User Access");
		}if(this.devAccess != null && this.devAccess.equalsIgnoreCase("A")){
			str.append("Admin Access");
		}
		return str.toString();
	}

	public void setDevAccessXsl(String devAccessXsl) {
		this.devAccessXsl = devAccessXsl;
	}
	
	 @XmlElement
	public String getPrdAccessXsl() {
		StringBuilder str = new StringBuilder();
		if(this.prdAccess != null && this.prdAccess.equalsIgnoreCase("N")){
			str.append("No Access");
		}if(this.prdAccess != null && this.prdAccess.equalsIgnoreCase("U")){
			str.append("User Access");
		}if(this.prdAccess != null && this.prdAccess.equalsIgnoreCase("A")){
			str.append("Admin Access");
		}
		return str.toString();
	}

	public void setPrdAccessXsl(String prdAccessXsl) {
		this.prdAccessXsl = prdAccessXsl;
	}
	 @XmlElement
	public String getCrossEnvXsl() {
		StringBuilder str = new StringBuilder();
		if(this.crossEnvironmentAccess != null && this.crossEnvironmentAccess.equalsIgnoreCase("N")){
			str.append("No");
		}if(this.crossEnvironmentAccess != null && this.crossEnvironmentAccess.equalsIgnoreCase("Y")){
			str.append("Yes");
		}
		return str.toString();
	}

	public void setCrossEnvXsl(String crossEnvXsl) {
		this.crossEnvXsl = crossEnvXsl;
	}
	 @XmlElement
	public String getLocalFolderXsl() {
		StringBuilder str = new StringBuilder();
		if(this.localFolderAccess != null && this.localFolderAccess.equalsIgnoreCase("N")){
			str.append("No");
		}if(this.localFolderAccess != null && this.localFolderAccess.equalsIgnoreCase("Y")){
			str.append("Yes");
		}
		return str.toString();
	}

	public void setLocalFolderXsl(String localFolderXsl) {
		this.localFolderXsl = localFolderXsl;
	}

	public String getEmployeeType() {
		return employeeType;
	}

	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}
        
}
