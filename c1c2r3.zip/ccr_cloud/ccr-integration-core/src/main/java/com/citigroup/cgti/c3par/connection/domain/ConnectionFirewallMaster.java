package com.citigroup.cgti.c3par.connection.domain;

import java.io.Serializable;

import com.citigroup.cgti.c3par.domain.Name;
import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;


/*
 * 
 * 
 * @author nu29793
 *
 * CREATE TABLE FIREWALL_MASTER ( 
  ID                    NUMBER        NOT NULL, 
  FIREWALL_NAME VARCHAR2(100) NULL, 
  FIREWALL_TYPE VARCHAR2(100) NULL, 
  FIREWALL_POLICY VARCHAR2(100) NULL,
  MANAGEMENT_REGION VARCHAR2(100) NULL
 );
 */

/**
 * The Class ConnectionFirewallMaster.
 */
public class ConnectionFirewallMaster extends PerformerPagerDO implements Serializable {

    /** The firewall type. */
    private String firewallType = new String();

    /** The firewall policy. */
    private String firewallPolicy = new String();

    /** The management region. */
    private String managementRegion = new String();

    /** The firewall name. */
    private String firewallName = new String();




    /**
     * Instantiates a new connection firewall master.
     */
    public ConnectionFirewallMaster() {
	//		----------
	setTableName(PerformerTypes.CON_FW_MASTER_TABLE);
	setSequenceName(PerformerTypes.CON_FW_MASTER_SEQ);
	//----------

	addToDBMapping("firewallType","FIREWALL_TYPE",1);
	addToDBMapping("firewallPolicy","FIREWALL_POLICY",2);
	addToDBMapping("managementRegion","MANAGEMENT_REGION",3);
	addToDBMapping("firewallName","FIREWALL_NAME",4);
	//-------------
    }


    /**
     * Gets the firewall type.
     *
     * @return the firewall type
     */
    public String getFirewallType() {
	return firewallType;

    }

    /**
     * Sets the firewall type.
     *
     * @param firewallType the new firewall type
     */
    public void setFirewallType(String firewallType) {
	this.firewallType = firewallType;
    }

    /**
     * Gets the firewall policy.
     *
     * @return the firewall policy
     */
    public String getFirewallPolicy() {
	return firewallPolicy;
    }

    /**
     * Sets the firewall policy.
     *
     * @param firewallPolicy the new firewall policy
     */
    public void setFirewallPolicy(String firewallPolicy) {
	this.firewallPolicy = firewallPolicy;
    }

    /**
     * Gets the management region.
     *
     * @return the management region
     */
    public String getManagementRegion() {
	return managementRegion;
    }

    /**
     * Sets the management region.
     *
     * @param managementRegion the new management region
     */
    public void setManagementRegion(String managementRegion) {
	this.managementRegion = managementRegion;
    }


    /**
     * Gets the firewall name.
     *
     * @return the firewall name
     */
    public String getFirewallName() {
	return firewallName;
    }


    /**
     * Sets the firewall name.
     *
     * @param firewallName the new firewall name
     */
    public void setFirewallName(String firewallName) {
	this.firewallName = firewallName;
    }

}
