/**
 * 
 */
package com.citigroup.cgti.c3par.common.domain.soc.persist;

import java.util.List;
import java.util.Map;

import com.citigroup.cgti.c3par.admin.domain.DailyLoad;
import com.citigroup.cgti.c3par.admin.domain.FirewallFreeze;
import com.citigroup.cgti.c3par.admin.domain.ProxyFreeze;
import com.citigroup.cgti.c3par.admin.domain.VacationFreeze;
import com.citigroup.cgti.c3par.audit.domain.AuditTrailProcess;
import com.citigroup.cgti.c3par.bpm.ejb.domain.ActivityBPMDTO;
import com.citigroup.cgti.c3par.bpm.ejb.rel.domain.RelationshipDTO;
import com.citigroup.cgti.c3par.comments.domain.TiRequestComments;
import com.citigroup.cgti.c3par.common.domain.AuditLog;
import com.citigroup.cgti.c3par.common.domain.ContactDetailsDTO;
import com.citigroup.cgti.c3par.common.domain.FirewallLocation;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.common.domain.GenericLookupDef;
import com.citigroup.cgti.c3par.common.domain.ResourceType;
import com.citigroup.cgti.c3par.common.domain.TIMailAudit;
import com.citigroup.cgti.c3par.common.domain.TIMailAuditResponse;
import com.citigroup.cgti.c3par.communication.domain.EmailGenerationViewProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.fw.domain.FAFRequestInfo;
import com.citigroup.cgti.c3par.persistance.Persistable;
import com.citigroup.cgti.c3par.relationship.domain.BusinessUnit;
import com.citigroup.cgti.c3par.relationship.domain.Relationship;
import com.citigroup.cgti.c3par.relationship.domain.SearchRelationshipProcess;
import com.citigroup.cgti.c3par.relationship.domain.ThirdPartyLocationXref;
import com.citigroup.cgti.c3par.user.domain.C3parUser;

/**
 * @author ne36745
 * 
 */
public interface CommonServicePersistable extends Persistable {

    List<GenericLookup> getConnectivityTypes();

    List<FirewallLocation> getFirewallLocations();

    FirewallLocation getFirewallLocByName(String name);

    List<GenericLookup> getControlMessagesList();

    List<GenericLookup> getDeviceTypes();

    List<ResourceType> getResourceTypes(Long processId);

    List<ResourceType> getInternalResourceTypes(Long processId);

    List<ResourceType> getIPConnResourceTypes(Long processId);

    FAFRequestInfo getConnectionInfo(FAFRequestInfo fafRequestInfo, String isIPReg);

    TIRequest getTIRequest(long processId, int version);

    Map<Long, String> getAllCyclesAndVersion(long processId, String isIPReg);

    TIRequest getPlanningTIRequest(Long processId);

    Long getPlanningIdForTiRequestId(Long tirequestid);

    List<Long> getTiRequestIdForCASPId(Long caspId, Long detailId);

    boolean isBuscritEmerConnection(Long tirequestid);

    // FireWallZone getFirewallZone(String name);

    ResourceType getNetworkZone(String name);

    GenericLookup getControlMessage(String name);

    List<GenericLookup> getProtocols();

    List<GenericLookup> getFirewallTypes();

    GenericLookup getControlMessage(Long controlMsgId);

    List<TIMailAudit> getEMailAuditTrailList(AuditTrailProcess auditTrailProcess);

    List<AuditLog> getAdminChangeDetails(Long processID);

    List<ContactDetailsDTO> getContactsDetails(Long contactID, String objectName, String entry);

    List<RelationshipDTO> getRelationshipDetails(Long relationID);

    void saveDailyLoad(List<DailyLoad> uploadedFile);

    void saveVacationFreeze(List<VacationFreeze> uploadedFile);

    void saveFirewallFreeze(List<FirewallFreeze> uploadedFile);

    void saveProxyFreeze(List<ProxyFreeze> uploadFile);

    List<DailyLoad> getDailyLoad();

    List<VacationFreeze> getVFreeze();

    List<FirewallFreeze> getFwFreeze();

    List<ProxyFreeze> getProxyFreeze();

    GenericLookup getDay(String day);

    List<ActivityBPMDTO> getActivity(Long processId);

    List<ActivityBPMDTO> getAllActivity();

    void updateInstance(Long processID, String activityID);

    TIMailAudit getEMailAuditTrail(AuditTrailProcess auditTrailProcess);

    List<RelationshipDTO> getRelationshipList(SearchRelationshipProcess searchRelationshipProcess);

    TIMailAuditResponse getResponseEMailAuditTrail(AuditTrailProcess auditTrailProcess);

    void updateActivityTrail(Long activityTrailId, String userId);

    boolean validateISOContact(String ssoID);

    List<Relationship> getListOfRelationship(SearchRelationshipProcess searchRelationshipProcess);

    List<BusinessUnit> getBusiUnitList(SearchRelationshipProcess searchRelationshipProcess);

    List<ResourceType> getResourceList();

    List getThirdPartyList1(SearchRelationshipProcess searchRelationshipProcess);

    List<BusinessUnit> getBusiUnitListForTp(SearchRelationshipProcess searchRelationshipProcess);

    List getDatClassificationList();

    List<GenericLookupDef> getListLookupData();

    List getListLookupDataDefList(Long id, String type);

    void saveLookUpData(Long id, String value);

    void saveLookUpData(Long id, String value, String value1);

    void updateLookUpData(Long lookUpDefID, Long id, String value);

    void updateLookUpData(Long lookUpDefID, Long id, String value, String value1);

    ThirdPartyLocationXref loadThirdPartyLocation(Long thirdpartyId);

    List<GenericLookup> getListLookupDataById(Long id);

    List<GenericLookup> getGenericLookupByName(String name);

    List<GenericLookup> getGenericLookupData(List<String> names);

    List<ActivityBPMDTO> getActivityByStatus(Long processId, String status);

    List<GenericLookup> getEmailTemplateList(String name);

    List<GenericLookup> getEmailTemplateListForCurrentTask(EmailGenerationViewProcess emailGenerationViewProcess);

    boolean isAccessForm(Long tiRequestId, String ruleType);
    
    boolean isStartingFlag(String jobName);
    
    TIRequest getTiRequestById(long tiRequestId);
    
    void addRISOStaticComments(TiRequestComments tiRequestComments, String role);

    public C3parUser getC3parUser(long UserId);
}
