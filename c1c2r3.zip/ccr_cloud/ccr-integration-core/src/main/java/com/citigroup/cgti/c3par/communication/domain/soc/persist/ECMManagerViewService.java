package com.citigroup.cgti.c3par.communication.domain.soc.persist;

import java.util.List;

import com.citigroup.cgti.c3par.communication.domain.CmpRequestDTO;

public interface ECMManagerViewService {
    
    List<List<Object>> getTodayProducts();
    List<List<Object>> getTodayPriority();
    List<List<Object>> getTodayPcProvideInfo();
    List<CmpRequestDTO> getProductRecords(String product);
    List<CmpRequestDTO> getPriorityRecords(String priority);
    List<CmpRequestDTO> getPcProvideRecords(String pcProvide);
    String getCognosURL();
}
