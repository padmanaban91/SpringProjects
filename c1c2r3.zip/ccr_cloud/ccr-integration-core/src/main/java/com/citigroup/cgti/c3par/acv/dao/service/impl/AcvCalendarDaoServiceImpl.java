/**
 * 
 */
package com.citigroup.cgti.c3par.acv.dao.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.citi.cgti.c3par.acv.domain.AcvCalendarDTO;
import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.acv.dao.service.AcvCalendarDaoService;
import com.citigroup.cgti.c3par.configuation.CCRQueries;

/**
 * @author ky38518
 * 
 */
@Repository
@Transactional
public class AcvCalendarDaoServiceImpl implements AcvCalendarDaoService {
    private static final Logger log = Logger.getLogger(AcvCalendarQueryConstants.class.getName());

    @Autowired
    private SessionFactory sessionFactory;

    @Autowired
    @Qualifier("jdbcTemplate_ccr")
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private CCRQueries ccrQueries;

    public CCRQueries getCcrQueries() {
        return ccrQueries;
    }

    public void setCcrQueries(CCRQueries ccrQueries) {
        this.ccrQueries = ccrQueries;
    }

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    @Transactional(readOnly = true)
    public Map<String, Integer> getMonthlyAcvConCntDetails(AcvCalendarDTO acvCalendarDto) throws ApplicationException {
        log.info("Fetching MonthlyAcvConCntDetails Started:" + acvCalendarDto.getSoeId() + ":Selected year"
                + acvCalendarDto.getYear());

        Map<String, Integer> acvMonthlyCcrCount = acvCalendarDto.getAcvMonthlyCcrCount();
        String acvMonthlyPendingQuery = null;
        Object[] params = { acvCalendarDto.getSoeId(), "01/01/" + acvCalendarDto.getYear(),
                "01/01/" + acvCalendarDto.getYear(), "01/01/" + acvCalendarDto.getYear(),
                "01/01/" + acvCalendarDto.getYear() };
        acvMonthlyPendingQuery = ccrQueries.getQueryByName(AcvCalendarQueryConstants.ACV_MONTHLY_PENDING_COUNT);
        SqlRowSet resultAcvMonthlyPendingCount = null;
        try {
            String queryRoleName = getRolename(acvCalendarDto.getSelectedRoles());
            acvMonthlyPendingQuery = acvMonthlyPendingQuery.replace(":ROLENAME", queryRoleName);
            resultAcvMonthlyPendingCount = jdbcTemplate.queryForRowSet(acvMonthlyPendingQuery, params);
            while (resultAcvMonthlyPendingCount.next()) {
                acvMonthlyCcrCount.put(resultAcvMonthlyPendingCount.getString("MONTH"),
                        resultAcvMonthlyPendingCount.getInt("COUNT"));

            }

        } catch (Exception e) {
            log.error("Exception occurred while getting the getMonthlyAcvConCntDetails : " + e.toString());
            throw new ApplicationException("Exception has occurred :: getMonthlyAcvConCntDetails ", e);
        }
        log.info("Fetching MonthlyAcvConCntDetails Ends:" + acvCalendarDto.getSoeId() + ":Selected year"
                + acvCalendarDto.getYear() + "acvMonthlyCcrCount" + acvMonthlyCcrCount);
        return acvMonthlyCcrCount;
    }

    @Override
    @Transactional(readOnly = true)
    public List<AcvCalendarDTO> getAcvConnectionsMonthlyDetails(AcvCalendarDTO acvCalendarDto)
            throws ApplicationException {
        log.info("Fetching AcvConnectionsMonthlyDetails Started:" + acvCalendarDto.getSoeId() + ":Selected year"
                + acvCalendarDto.getYear() + ":Selected Month" + acvCalendarDto.getSelectedMonth());
        String date = null;
        String acvConnectionsMonthlyDetails = null;
        String acvRoleCountQuery = null;
        acvRoleCountQuery = getAcvRoleCount(acvCalendarDto.getLoggedInUser()).toString();
        List<AcvCalendarDTO> acvCaledarDtoList = new ArrayList<AcvCalendarDTO>();
        SqlRowSet result = null;
        SqlRowSet acvRoleCountResult = null;
        boolean accessFlag = false;
        try {
            date = "01/" + acvCalendarDto.getSelectedMonth() + "/" + acvCalendarDto.getYear();
            if (acvCalendarDto != null && acvCalendarDto.getSelectedRoles() != null
                    && (acvCalendarDto.getSelectedRoles().size() > 0)) {
                String queryRoleName = getRolename(acvCalendarDto.getSelectedRoles());
                Object[] params = { acvCalendarDto.getSoeId(), date, date, date, date };
                acvConnectionsMonthlyDetails = ccrQueries
                        .getQueryByName(AcvCalendarQueryConstants.ACV_MONTHLY_CCR_WITH_ROLEID);
                acvConnectionsMonthlyDetails = acvConnectionsMonthlyDetails.replace(":ROLENAME", queryRoleName);
                result = jdbcTemplate.queryForRowSet(acvConnectionsMonthlyDetails, params);
            } else {
                Object[] params = { acvCalendarDto.getSoeId(), date, date, date, date };
                acvConnectionsMonthlyDetails = ccrQueries
                        .getQueryByName(AcvCalendarQueryConstants.ACV_MONTHLY_CCR_CONNECTIONS);
                result = jdbcTemplate.queryForRowSet(acvConnectionsMonthlyDetails, params);
            }

            acvRoleCountResult = jdbcTemplate.queryForRowSet(acvRoleCountQuery);

            if (acvRoleCountResult.next()) {
                int count = acvRoleCountResult.getInt("count");
                if (count > 0) {
                    accessFlag = true;
                }
            }

            while (result.next()) {
                AcvCalendarDTO acvCalendarDTO = new AcvCalendarDTO();
                acvCalendarDTO.setCcrId(result.getString("CONNECTION ID"));
                acvCalendarDTO.setActivity(result.getString("CURRENT ACTIVITY"));

                acvCalendarDTO.setConName(result.getString("CONNECTION NAME"));
                acvCalendarDTO.setDaysInAcv(result.getString("DAYS IN ACT / DAYS TO EXPIRE"));
                acvCalendarDTO.setAcvDate(result.getString("ACT EXP DATE / ACV EXP DATE"));
                acvCalendarDTO.setConType(result.getString("Relationship Type"));
                acvCalendarDTO.setAcvFlag(result.getString("USER_ACCESS"));
                acvCalendarDTO.setStatus(result.getString("STATUS"));
                acvCalendarDTO.setTiRequestId(result.getString("TI_REQUEST_ID"));
                acvCalendarDTO.setAcvRoleEnabled(accessFlag);

                acvCaledarDtoList.add(acvCalendarDTO);

            }

        } catch (Exception e) {
            log.error("Exception occurred while getting the getAcvConnectionsMonthlyDetails : " + e.toString());
            throw new ApplicationException("Exception has occurred :: getAcvConnectionsMonthlyDetails ", e);
        }
        log.info("Fetching AcvConnectionsMonthlyDetails Ends");
        return acvCaledarDtoList;
    }

    @Override
    @Transactional(readOnly = true)
    public List<AcvCalendarDTO> getAcvConnectionsyearlyDetails(AcvCalendarDTO acvCalendarDto)
            throws ApplicationException {
        log.info("Fetching AcvConnectionsyearlyDetails Started:" + acvCalendarDto.getSoeId() + ":Selected year"
                + acvCalendarDto.getYear());
        String acvRoleCountQuery = null;
        acvRoleCountQuery = getAcvRoleCount(acvCalendarDto.getLoggedInUser()).toString();
        String acvConnectionsMonthlyDetails = null;
        List<AcvCalendarDTO> acvCaledarDtoList = new ArrayList<AcvCalendarDTO>();
        String date = null;

        SqlRowSet result = null;
        SqlRowSet acvRoleCountResult = null;
        boolean accessFlag = false;
        try {

            date = "01/01" + acvCalendarDto.getYear() + "";

            if (acvCalendarDto != null && acvCalendarDto.getSelectedRoles() != null
                    && (acvCalendarDto.getSelectedRoles().size() > 0)) {
                String queryRoleName = getRolename(acvCalendarDto.getSelectedRoles());
                Object[] params = { acvCalendarDto.getSoeId(), date, date, date, date };
                acvConnectionsMonthlyDetails = ccrQueries
                        .getQueryByName(AcvCalendarQueryConstants.ACV_YEARLY_CCR_WITH_ROLEID);
                acvConnectionsMonthlyDetails = acvConnectionsMonthlyDetails.replace(":ROLENAME", queryRoleName);

                result = jdbcTemplate.queryForRowSet(acvConnectionsMonthlyDetails, params);
            } else {
                Object[] params = { acvCalendarDto.getSoeId(), date, date, date, date };
                acvConnectionsMonthlyDetails = ccrQueries
                        .getQueryByName(AcvCalendarQueryConstants.ACV_YEARLY_CCR_CONNECTIONS);
                result = jdbcTemplate.queryForRowSet(acvConnectionsMonthlyDetails, params);
            }

            acvRoleCountResult = jdbcTemplate.queryForRowSet(acvRoleCountQuery);

            if (acvRoleCountResult.next()) {
                int count = acvRoleCountResult.getInt("count");
                if (count > 0) {
                    accessFlag = true;
                }
            }

            while (result.next()) {
                AcvCalendarDTO acvCalendarDTO = new AcvCalendarDTO();

                acvCalendarDTO.setCcrId(result.getString("CONNECTION ID"));
                acvCalendarDTO.setActivity(result.getString("CURRENT ACTIVITY"));

                acvCalendarDTO.setConName(result.getString("CONNECTION NAME"));
                acvCalendarDTO.setDaysInAcv(result.getString("DAYS IN ACT / DAYS TO EXPIRE"));
                acvCalendarDTO.setAcvDate(result.getString("ACT EXP DATE / ACV EXP DATE"));
                acvCalendarDTO.setConType(result.getString("Relationship Type"));
                acvCalendarDTO.setAcvFlag(result.getString("USER_ACCESS"));
                acvCalendarDTO.setStatus(result.getString("STATUS"));
                acvCalendarDTO.setTiRequestId(result.getString("TI_REQUEST_ID"));
                acvCalendarDTO.setAcvRoleEnabled(accessFlag);

                acvCaledarDtoList.add(acvCalendarDTO);

            }

        } catch (Exception e) {
            log.error("Exception occurred while getting the getAcvConnectionsyearlyDetails : " + e.toString());
            throw new ApplicationException("Exception has occurred :: getAcvConnectionsyearlyDetails ", e);
        }
        log.info("Fetching AcvConnectionsyearlyDetails Ends");
        return acvCaledarDtoList;
    }

    @Override
    @Transactional(readOnly = true)
    public List<String> getAcvYearList() throws ApplicationException {
        List<String> list = new ArrayList<String>();
        try {
            log.info("Fetching AcvYearList Drop down stared");

            Integer minYear = null;
            String acyYearListQuery = ccrQueries.getQueryByName(AcvCalendarQueryConstants.ACV_MIN_YEAR);
            SqlRowSet result = null;
            result = jdbcTemplate.queryForRowSet(acyYearListQuery.toString());
            int currentYear = Calendar.getInstance().get(Calendar.YEAR);
            if (result.next()) {
                minYear = result.getInt("year");
            }
            for (int year = minYear; year <= currentYear + 1; year++) {
                list.add(String.valueOf(year));
            }
            log.info("Fetching AcvYearList Drop down Ends");
        }

        catch (Exception e) {
            log.error("Exception occurred while getting the getAcvYearList : " + e.toString());
            throw new ApplicationException("Exception has occurred :: getAcvYearList ", e);
        }

        return list;
    }

    @Override
    @Transactional(readOnly = true)
    public Map<String, String> getAcvInstanceId(Long tiRequestId, String ssoId) throws Exception {
        String instanceId = null;
        String role = null;
        String activityId = null;
        String activityStatus = null;
        String lockedBy = null;
        String nextAction = null;
        String taskIdForACVSQL = null;
        Map<String, String> taskIdDetails = null;
        try {
            log.info("tiRequestId :" + tiRequestId + " , ssoId :" + ssoId);
            taskIdDetails = new HashMap<String, String>();
            taskIdForACVSQL = ccrQueries.getQueryByName(AcvCalendarQueryConstants.FETCH_ACV_INSTANCE_ID);
            log.info("taskIdForACVSQL :" + taskIdForACVSQL);
            SqlRowSet rs = jdbcTemplate.queryForRowSet(taskIdForACVSQL, new Object[] { ssoId, tiRequestId });
            if (rs.next()) {
                instanceId = rs.getString(1);
                role = rs.getString(2);
                activityId = rs.getString(3);
                activityStatus = rs.getString(4);
                lockedBy = rs.getString(5);
                taskIdDetails.put("instanceId", instanceId);
                taskIdDetails.put("role", role);
                taskIdDetails.put("activityId", activityId);
                log.info("instanceId :" + instanceId + " , role :" + role + " , activityId :" + activityId
                        + " , activityStatus :" + activityStatus + " , lockedBy :" + lockedBy);
                if (activityStatus != null && !"".equalsIgnoreCase(activityStatus)
                        && "Ready".equalsIgnoreCase(activityStatus)) {
                    nextAction = "LOCK";
                } else if (activityStatus != null && !"".equalsIgnoreCase(activityStatus)
                        && "Completed".equalsIgnoreCase(activityStatus)) {
                    nextAction = "COMPLETED";
                } else if (activityStatus != null && !"".equalsIgnoreCase(activityStatus)
                        && "Reserved".equalsIgnoreCase(activityStatus) && lockedBy != null
                        && !"".equalsIgnoreCase(lockedBy) && (ssoId).equalsIgnoreCase(lockedBy)) {
                    nextAction = "COMPLETE";
                } else {
                    nextAction = "UNLOCK";
                }
            } else {
                nextAction = "";
            }
            taskIdDetails.put("nextAction", nextAction);
        } catch (Exception e) {
            log.error("Error has occurred in  getAcvInstanceId ::" + e.toString(), e);
        }
        return taskIdDetails;
    }

    @Override
    @Transactional(readOnly = true)
    public boolean isUserEligibleForACV(String ssoId) throws Exception {
        boolean isUserEligibleForACV = false;
        String userEligiblityForACVSQL = null;
        try {
            log.info("ssoId :" + ssoId);
            userEligiblityForACVSQL = ccrQueries.getQueryByName(AcvCalendarQueryConstants.USER_ELIGIBLITY_FOR_ACV);
            log.info("userEligiblityForACVSQL :" + userEligiblityForACVSQL);
            SqlRowSet rs = jdbcTemplate.queryForRowSet(userEligiblityForACVSQL, new Object[] { ssoId });
            if (rs.next()) {
                if (rs.getInt(1) > 0) {
                    isUserEligibleForACV = true;
                }
            }
            log.info("isUserEligibleForACV : " + isUserEligibleForACV);
        } catch (Exception e) {
            log.error("Error has occurred in  isUserEligibleForACV ::" + e.toString(), e);
        }
        return isUserEligibleForACV;
    }

    @Override
    public int updateAuditDetails(String ssoId, long tiRequestId) throws Exception {
        String userDetailsQuery = null;
        String UpdateUserDetailsQuery = null;
        long user_id = 0;
        long user_role_id = 0;
        int updateCount = 0;
        try {
            log.info("ssoId :" + ssoId);
            userDetailsQuery = ccrQueries.getQueryByName(AcvCalendarQueryConstants.USER_ROLE_DETAILS_FOR_ACV);
            log.info("userDetailsQuery :" + userDetailsQuery);
            SqlRowSet rs = jdbcTemplate.queryForRowSet(userDetailsQuery, new Object[] { ssoId });
            if (rs.next()) {
                user_id = rs.getInt(1);
                user_role_id = rs.getInt(2);
                log.info("user_id : " + user_id + ", user_role_id : " + user_role_id);
                UpdateUserDetailsQuery = ccrQueries
                        .getQueryByName(AcvCalendarQueryConstants.UPDATE_AUDIT_DETAILS_FOR_ACV);
                log.info("userDetailsQuery :" + userDetailsQuery);
                updateCount = jdbcTemplate.update(UpdateUserDetailsQuery, new Object[] { user_id, user_role_id,
                        tiRequestId });
                log.info("updateCount : " + updateCount);
            }
        } catch (Exception e) {
            log.error("Error has occurred in  updateAuditDetails ::" + e.toString(), e);
        }
        return updateCount;
    }

    private StringBuilder getAcvRoleCount(String soeId) {
        StringBuilder SQL = new StringBuilder();
        SQL.append("SELECT \n");
        SQL.append("  COUNT(*) count \n");
        SQL.append("FROM \n");
        SQL.append("  C3PAR_USERS CU \n");
        SQL.append("JOIN C3PAR_USER_ROLE_XREF CURF \n");
        SQL.append("ON \n");
        SQL.append("  CURF.USER_ID = CU.ID \n");
        SQL.append("JOIN ROLE RL \n");
        SQL.append("ON \n");
        SQL.append("  RL.ID = CURF.ROLE_ID \n");
        SQL.append("JOIN SECURITY_ROLE SR \n");
        SQL.append("ON \n");
        SQL.append("  SR.ID = RL.SECURITY_ROLE_ID \n");
        SQL.append("JOIN GENERIC_LOOKUP GL \n");
        SQL.append("ON \n");
        SQL.append("  GL.VALUE1 = SR.NAME \n");
        SQL.append("JOIN GENERIC_LOOKUP_DEFS GLD \n");
        SQL.append("ON \n");
        SQL.append("  GLD.ID = GL.DEFINITION_ID \n");
        SQL.append("WHERE \n");
        SQL.append("  UPPER(CU.SSO_ID) = UPPER('" + soeId + "') \n");
        SQL.append("AND GLD.NAME       ='ACV_CALENDER_ROLES' \n");
        SQL.append("ORDER BY \n");
        SQL.append("  GL.VALUE2");
        return SQL;
    }

    private String getRolename(List<String> roleName) {

        String queryForName = "";
        for (int count = 0; count < roleName.size(); count++) {
            if (count == roleName.size() - 1) {
                queryForName = queryForName + "'" + roleName.get(count) + "'";
            } else {
                queryForName = queryForName + "'" + roleName.get(count) + "',";
            }
        }
        return queryForName;
    }

    @Override
    @Transactional(readOnly = true)
    public String getRoleNameForUser(String ssoId) throws Exception {
        String role = null;
        String roleNameForACVSQL = null;
        try {
            roleNameForACVSQL = ccrQueries.getQueryByName(AcvCalendarQueryConstants.ASSIGNEDROLE_FOR_ACV_CALENDAR);
            log.info("roleNameForACVSQL :" + roleNameForACVSQL);
            SqlRowSet rs = jdbcTemplate.queryForRowSet(roleNameForACVSQL, new Object[] { ssoId });
            if (rs.next()) {
                role = rs.getString(1);
            }
            log.info("role : " + role);
        } catch (Exception e) {
            log.error("Error has occurred in  getRoleNameForUser ::" + e.toString(), e);
        }
        return role;
    }

    @Override
    @Transactional(readOnly = true)
    public String getCcrEntitilementCMPProductURL() throws ApplicationException {
        String key_value = null;
        String cmpProductUrl = new String(
                "SELECT KEY_VALUE from server_constants where KEY_NAME = ? and key_env = (select key_value from server_constants where key_name = ?)");
        try {
            SqlRowSet result = jdbcTemplate.queryForRowSet(cmpProductUrl, new Object[] {
                    AcvCalendarQueryConstants.CCR_ENTITLEMENT_CMP_PRODUCT_URL, AcvCalendarQueryConstants.ENVIRONMENT });
            if (result.next()) {
                key_value = result.getString(1);
            }
        } catch (Exception e) {
            log.error("Exception occurred while getting the getCcrEntitilementCMPProductURL : " + e.toString(), e);
            throw new ApplicationException("Exception has occurred :: getCcrEntitilementCMPProductURL ", e);
        }
        return key_value;

    }

    @Override
    @Transactional(readOnly = true)
    public boolean isConnectionActive(long processId) {
        boolean isConnectionActive = false;
        String activeCheckSQL = null;
        try {
            log.debug("processId :" + processId);
            activeCheckSQL = ccrQueries.getQueryByName(AcvCalendarQueryConstants.ACTIVE_CONNECTION_CHECK);
            SqlRowSet rs = jdbcTemplate.queryForRowSet(activeCheckSQL, new Object[] { processId });
            if (rs.next()) {
                if (rs.getInt(1) > 0) {
                    isConnectionActive = true;
                }
            }
            log.info("isConnectionActive : " + isConnectionActive);
        } catch (Exception e) {
            log.error("Exception in isConnectionActive :" + e);
            log.error(e.toString(), e);
        }
        return isConnectionActive;
    }

    @Override
    @Transactional(readOnly = true)
    public boolean isACVScheduled(long processId) {
        boolean isACVScheduled = false;
        String acvScheduledCheckSQL = null;
        try {
            log.debug("processId :" + processId);
            acvScheduledCheckSQL = ccrQueries.getQueryByName(AcvCalendarQueryConstants.ACV_SCHEDULED_CHECK);
            SqlRowSet rs = jdbcTemplate.queryForRowSet(acvScheduledCheckSQL, new Object[] { processId });
            if (rs.next()) {
                if (rs.getInt(1) > 0) {
                    isACVScheduled = true;
                }
            }
            log.info("isACVScheduled : " + isACVScheduled);
        } catch (Exception e) {
            log.error("Exception in isACVScheduled :" + e);
            log.error(e.toString(), e);
        }
        return isACVScheduled;
    }
}
