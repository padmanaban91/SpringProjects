package com.citigroup.cgti.c3par.bpm.ejb.search.domain;

import java.io.Serializable;


public class SecAclSearchAttributes  extends BaseSearchAttributes implements Serializable{

   /**
	 * 
	 */
	private static final long serialVersionUID = -7870530458123040224L;

	private String aclName;
   
	private String aclDevice;

	public String getAclName() {
		return aclName;
	}
	
	public void setAclName(String aclName) {
		this.aclName = aclName;
	}
	
	public String getAclDevice() {
		return aclDevice;
	}
	
	public void setAclDevice(String aclDevice) {
		this.aclDevice = aclDevice;
	}
		
}
