package com.citigroup.cgti.c3par.bpm.ejb.search;


/**
 * The Interface ISearchProxy.
 */
public interface ResolveITQueueSender {
	
	public void sendMesage(String message);
}
