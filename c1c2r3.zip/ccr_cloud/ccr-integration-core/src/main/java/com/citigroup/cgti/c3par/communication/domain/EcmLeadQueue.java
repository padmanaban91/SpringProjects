package com.citigroup.cgti.c3par.communication.domain;

import com.citigroup.cgti.c3par.domain.Base;

public class EcmLeadQueue extends Base {

    private String agentName;

    private Long inQueue;

    private Long isBAU;

    private Long isBusCrit;

    private Long isAssitance;

    private Long assignedThisWeek;

    private Long totalInQueue;

    private String agentID;

    private String isLocked;

    private String role;

    private String comments;

    private String sector;

    private Long currentDayBAUCount;

    private Long currentWeekBAUCount;

    private Long currentDayBUSCRITCount;

    private Long currentWeekBUSCRITCount;

    private String firstname;

    private String lastname;

    private boolean selected;

    private Long agentUserId;

    private Long bau;

    private Long buscrit_emer;

    private Long assistance;

    private Long today;

    private Long thisWeek;

    private Long previousWeek;

    public String getAgentName() {
        return agentName;
    }

    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }

    public Long getInQueue() {
        return inQueue;
    }

    public void setInQueue(Long inQueue) {
        this.inQueue = inQueue;
    }

    public Long getIsBAU() {
        return isBAU;
    }

    public void setIsBAU(Long isBAU) {
        this.isBAU = isBAU;
    }

    public Long getIsBusCrit() {
        return isBusCrit;
    }

    public void setIsBusCrit(Long isBusCrit) {
        this.isBusCrit = isBusCrit;
    }

    public Long getIsAssitance() {
        return isAssitance;
    }

    public void setIsAssitance(Long isAssitance) {
        this.isAssitance = isAssitance;
    }

    public Long getAssignedThisWeek() {
        return assignedThisWeek;
    }

    public void setAssignedThisWeek(Long assignedThisWeek) {
        this.assignedThisWeek = assignedThisWeek;
    }

    public Long getTotalInQueue() {
        return totalInQueue;
    }

    public void setTotalInQueue(Long totalInQueue) {
        this.totalInQueue = totalInQueue;
    }

    public String getAgentID() {
        return agentID;
    }

    public void setAgentID(String agentID) {
        this.agentID = agentID;
    }

    public String getIsLocked() {
        return isLocked;
    }

    public void setIsLocked(String isLocked) {
        this.isLocked = isLocked;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getSector() {
        return sector;
    }

    public void setSector(String sector) {
        this.sector = sector;
    }

    /**
     * @return the currentDayBAUCount
     */
    public Long getCurrentDayBAUCount() {
        return currentDayBAUCount;
    }

    /**
     * @param currentDayBAUCount
     *            the currentDayBAUCount to set
     */
    public void setCurrentDayBAUCount(Long currentDayBAUCount) {
        this.currentDayBAUCount = currentDayBAUCount;
    }

    /**
     * @return the currentWeekBAUCount
     */
    public Long getCurrentWeekBAUCount() {
        return currentWeekBAUCount;
    }

    /**
     * @param currentWeekBAUCount
     *            the currentWeekBAUCount to set
     */
    public void setCurrentWeekBAUCount(Long currentWeekBAUCount) {
        this.currentWeekBAUCount = currentWeekBAUCount;
    }

    /**
     * @return the currentDayBUSCRITCount
     */
    public Long getCurrentDayBUSCRITCount() {
        return currentDayBUSCRITCount;
    }

    /**
     * @param currentDayBUSCRITCount
     *            the currentDayBUSCRITCount to set
     */
    public void setCurrentDayBUSCRITCount(Long currentDayBUSCRITCount) {
        this.currentDayBUSCRITCount = currentDayBUSCRITCount;
    }

    /**
     * @return the currentWeekBUSCRITCount
     */
    public Long getCurrentWeekBUSCRITCount() {
        return currentWeekBUSCRITCount;
    }

    /**
     * @param currentWeekBUSCRITCount
     *            the currentWeekBUSCRITCount to set
     */
    public void setCurrentWeekBUSCRITCount(Long currentWeekBUSCRITCount) {
        this.currentWeekBUSCRITCount = currentWeekBUSCRITCount;
    }

    /**
     * @return the firstname
     */
    public String getFirstname() {
        return firstname;
    }

    /**
     * @param firstname
     *            the firstname to set
     */
    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    /**
     * @return the lastname
     */
    public String getLastname() {
        return lastname;
    }

    /**
     * @param lastname
     *            the lastname to set
     */
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    /**
     * @return the selected
     */
    public boolean isSelected() {
        return selected;
    }

    /**
     * @param selected
     *            the selected to set
     */
    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public Long getAgentUserId() {
        return agentUserId;
    }

    public void setAgentUserId(Long agentUserId) {
        this.agentUserId = agentUserId;
    }

    /**
     * @return the bau
     */
    public Long getBau() {
        return bau;
    }

    /**
     * @return the buscrit_emer
     */
    public Long getBuscrit_emer() {
        return buscrit_emer;
    }

    /**
     * @return the assistance
     */
    public Long getAssistance() {
        return assistance;
    }

    /**
     * @return the today
     */
    public Long getToday() {
        return today;
    }

    /**
     * @return the thisWeek
     */
    public Long getThisWeek() {
        return thisWeek;
    }

    /**
     * @return the previousWeek
     */
    public Long getPreviousWeek() {
        return previousWeek;
    }

    /**
     * @param bau
     *            the bau to set
     */
    public void setBau(Long bau) {
        this.bau = bau;
    }

    /**
     * @param buscrit_emer
     *            the buscrit_emer to set
     */
    public void setBuscrit_emer(Long buscrit_emer) {
        this.buscrit_emer = buscrit_emer;
    }

    /**
     * @param assistance
     *            the assistance to set
     */
    public void setAssistance(Long assistance) {
        this.assistance = assistance;
    }

    /**
     * @param today
     *            the today to set
     */
    public void setToday(Long today) {
        this.today = today;
    }

    /**
     * @param thisWeek
     *            the thisWeek to set
     */
    public void setThisWeek(Long thisWeek) {
        this.thisWeek = thisWeek;
    }

    /**
     * @param previousWeek
     *            the previousWeek to set
     */
    public void setPreviousWeek(Long previousWeek) {
        this.previousWeek = previousWeek;
    }

}
