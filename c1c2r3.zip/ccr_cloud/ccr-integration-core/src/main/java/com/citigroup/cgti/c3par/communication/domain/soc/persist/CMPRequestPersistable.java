package com.citigroup.cgti.c3par.communication.domain.soc.persist;

import java.util.List;

import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.communication.domain.CMPRequestAttachments;
import com.citigroup.cgti.c3par.communication.domain.CmpChangeLogDetails;
import com.citigroup.cgti.c3par.communication.domain.CmpDocumentMetaData;
import com.citigroup.cgti.c3par.persistance.Persistable;


public interface CMPRequestPersistable extends Persistable{
	
	public Long saveCmpRequestfield(String cmpRequestString);
	
	public void cmpActivityTrail(Long cmpId, String ssoId, String taskCode, String activityStatus, Long tiRequestID);
 
	public CitiContact getUserIdForSsoId(String ssoId);
	
	public CitiContact getUserIdForEmailId(String emailId);
	
	public byte[] getCmpData(String cmpReqId);
	
	public String getRequestUrgencyFromCMP(String cmpOrderItemId);
	
	public int saveDirectorApprover(String orderItemId, String approverName,String approverGeid);
	
	public List<CmpDocumentMetaData> getDocumentDetail(String orderItemId);
	
	CitiContact getuserIdForgGeid (String geId);

    public void cmpMgrActivityTrail(Long cmpId, String ssoId, String taskCode, String activityStatus, Long tiRequestId,
            String mgrCompletedReason);
    
    public void getCmpAttachments(List<CMPRequestAttachments> cmpRequestAttachmentList, String cmpOrderItemId,
            String orderById);

    public void saveCmpChangeLogDetails(CmpChangeLogDetails cmpChangeLogDetails);
}
