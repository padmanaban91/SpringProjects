package com.citigroup.cgti.c3par.bpm.ejb.useradmin;

public class CCRUser {
	
	private int businessunit_id;
	private int location_id;
	private String first_name;
	private String last_name;
	private String rits_id;
	private String organization;
	private String phone;
	private String email;
	private String sso_id;
	private String employee_type;
	private String geid;
	private String employee_status;
	private String supervisor_geid;
	private String employee_termination_date;
	private String supervisor_email;
	private String latest_supervisor_geid;
	
	public int getBusinessunit_id() {
		return businessunit_id;
	}
	public void setBusinessunit_id(int businessunitId) {
		businessunit_id = businessunitId;
	}
	public int getLocation_id() {
		return location_id;
	}
	public void setLocation_id(int locationId) {
		location_id = locationId;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String firstName) {
		first_name = firstName;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String lastName) {
		last_name = lastName;
	}
	public String getRits_id() {
		return rits_id;
	}
	public void setRits_id(String ritsId) {
		rits_id = ritsId;
	}
	public String getOrganization() {
		return organization;
	}
	public void setOrganization(String organization) {
		this.organization = organization;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSso_id() {
		return sso_id;
	}
	public void setSso_id(String ssoId) {
		sso_id = ssoId;
	}
	public String getEmployee_type() {
		return employee_type;
	}
	public void setEmployee_type(String employeeType) {
		employee_type = employeeType;
	}
	public String getGeid() {
		return geid;
	}
	public void setGeid(String geid) {
		this.geid = geid;
	}
	public String getEmployee_status() {
		return employee_status;
	}
	public void setEmployee_status(String employeeStatus) {
		employee_status = employeeStatus;
	}
	public String getSupervisor_geid() {
		return supervisor_geid;
	}
	public void setSupervisor_geid(String supervisorGeid) {
		supervisor_geid = supervisorGeid;
	}
	public String getEmployee_termination_date() {
		return employee_termination_date;
	}
	public void setEmployee_termination_date(String employeeTerminationDate) {
		employee_termination_date = employeeTerminationDate;
	}
	public String getSupervisor_email() {
		return supervisor_email;
	}
	public void setSupervisor_email(String supervisorEmail) {
		supervisor_email = supervisorEmail;
	}
	public String getLatest_supervisor_geid() {
		return latest_supervisor_geid;
	}
	public void setLatest_supervisor_geid(String latestSupervisorGeid) {
		latest_supervisor_geid = latestSupervisorGeid;
	}

}
