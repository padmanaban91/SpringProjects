package com.citigroup.cgti.c3par.admin.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.common.domain.GenericLookupDef;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;


public class ListLookupProcess {
	
	
	
	 /** The m_ lookup defs. */
    private List 	m_LookupDefs;

    /** The m_ lookup value. */
    private	String	m_LookupValue;
    
    private String lookupValue;
    
    
    private List<ListLookupProcess> lookUpList;
    

    /** The m_ lookup def id. */
    private Long	m_LookupDefId;

    /** The m_ include deleted. */
    private Boolean	m_IncludeDeleted;

    /** The m_ include deleted state. */
    private String	m_IncludeDeletedState;

    /** The m_ have result. */
    private boolean m_HaveResult;
    
    private String	ids;
    
    private String name;
    private String lookupValue1;
    
    



	CCRBeanFactory ccrBeanFactory;
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}
    public ListLookupProcess() {
 		 
  	}
    public String getLookupValue1() {
		return lookupValue1;
	}

	public void setLookupValue1(String lookupValue1) {
		this.lookupValue1 = lookupValue1;
	}
    public ListLookupProcess(String ids,String name,String m_LookupValue) {
  		super();
  		this.ids = ids;
  		this.name = name;
  		this.m_LookupValue = m_LookupValue; 
  	}


    /**
     * Gets the lookup defs.
     *
     * @return Returns the Lookup Definitions.
     */
    public List getLookupDefs() {
	return m_LookupDefs;
    }

    /**
     * Sets the lookup defs.
     *
     * @param lookup_defs The Lookup Definitions to set.
     */
    public void setLookupDefs(List lookup_defs) {
	m_LookupDefs = lookup_defs;
    }

 
	    public String getLookupValue() { return m_LookupValue; }

	    
	    public void setLookupValue(String lv) { m_LookupValue = lv; }
	public Long getM_LookupDefId() {
		return m_LookupDefId;
	}

	public void setM_LookupDefId(Long m_LookupDefId) {
		this.m_LookupDefId = m_LookupDefId;
	}

	public Boolean getM_IncludeDeleted() {
		return m_IncludeDeleted;
	}

	public void setM_IncludeDeleted(Boolean m_IncludeDeleted) {
		this.m_IncludeDeleted = m_IncludeDeleted;
	}

	public String getM_IncludeDeletedState() {
		return m_IncludeDeletedState;
	}

	public void setM_IncludeDeletedState(String m_IncludeDeletedState) {
		this.m_IncludeDeletedState = m_IncludeDeletedState;
	}

	public boolean isM_HaveResult() {
		return m_HaveResult;
	}

	public void setM_HaveResult(boolean m_HaveResult) {
		this.m_HaveResult = m_HaveResult;
	}
	   
	    public Long getLookupDefId() { return m_LookupDefId; }

	    
	    public void setLookupDefId(Long id) { m_LookupDefId = id; }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
    
    

	public String getIds() {
		return ids;
	}

	public void setIds(String ids) {
		this.ids = ids;
	}

	
	public List<GenericLookupDef> getListLookupData() {
		return ccrBeanFactory.getCommonServicePersistable() .getListLookupData();
	}
	
	
	
	public List getListLookupDataDefList(Long id,String type) {
		return ccrBeanFactory.getCommonServicePersistable().getListLookupDataDefList(id,type);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void saveLookUpData(Long id,String value) {
		ccrBeanFactory.getCommonServicePersistable().saveLookUpData(id,value);
	}
	

@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void saveLookUpData(Long id,String value, String value1) {
		ccrBeanFactory.getCommonServicePersistable().saveLookUpData(id,value,value1);
	}

	 
	

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void updateLookUpData(Long lookUpDefID,Long id,String value) {
		ccrBeanFactory.getCommonServicePersistable().updateLookUpData(lookUpDefID,id,value);
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void updateLookUpData(Long lookUpDefID,Long id,String value,String value1) {
		ccrBeanFactory.getCommonServicePersistable().updateLookUpData(lookUpDefID,id,value,value1);
	}
	 

	
	public List<GenericLookup> getListLookupDataById(Long id) {
		return ccrBeanFactory.getCommonServicePersistable().getListLookupDataById(id);
	}
	

}
