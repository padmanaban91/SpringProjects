package com.citigroup.cgti.c3par.communication.domain;

import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.common.domain.TIMailAudit;
import com.citigroup.cgti.c3par.domain.CMPRole;
import com.citigroup.cgti.c3par.domain.ConnectionRequest;
import com.citigroup.cgti.c3par.relationship.domain.BusinessUnit;
import com.citigroup.cgti.c3par.relationship.domain.DsmtSgmntSector;
import com.citigroup.cgti.c3par.relationship.domain.Region;
import com.citigroup.cgti.c3par.relationship.domain.RelationshipProcess;
import com.citigroup.cgti.c3par.relationship.domain.Sector;
import com.citigroup.cgti.c3par.relationship.domain.ThirdPartyContact;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

/**
 * @author ky38518
 *
 */
public class EmailGenerationViewProcess {
    CCRBeanFactory ccrBeanFactory;
    {
        ApplicationContext appContext = CCRApplicationContextUtils.getApplicationContext();
        ccrBeanFactory = (CCRBeanFactory) appContext.getBean("cCRBeanFactory");
    }
    private CMPRequest cmpRequest;
    private ConnectionRequest connectionRequest;
    private List<CMPRequest> resolveITMessageList;

    private String cmpreqID;
    private Date dateAssigned;
    private Date chgDate;
    private Date implementedDate;
    private String ccrID;
    private String requester;
    private String primaryOwner;
    private String additionalContacts;
    private String chooseEmail;
    private String ecmAgent;
    private String addNote;
    private String chgID;
    private String affectedBus;
    private String link;
    private String projectName;
    private String phoneNo;
    private String firstName;
    private String lastName;
    private String soeId;
    private String roleName;
    private String caspUrl;
    private String globalDirUrl;
    private String resolveItDetailUrl;
    private String requestUrgency;
    private String cmpRequestUrgency;
    private List itemValueList;
    private List<CMPRole> cmprolesList;
    private List<Region> regionList;
    private List<Sector> sectorList;
    private List<BusinessUnit> businessUnitList;

    private List<GenericLookup> urgencyList;
    private List<GenericLookup> requestTypeList;
    private List<GenericLookup> affectedBusinessList;
    private List<GenericLookup> typeOfConnectivityList;
    private List<GenericLookup> emailTemplateList;
    private List<GenericLookup> slodaysList;
    private List<TIMailAudit> tiMailAuditList;
    private List<GenericLookup> classificationList;
	private List<GenericLookup> conestimateList;
    private List<GenericLookup> cmpEntityList;
    private List<GenericLookup> reasonB2BList;

    private String textForSubject;
    private String additionalText;
    private String additionalTextHold;

    private String assignedUser;
    private String assistanceRequested;
    private String cancelReason;
    private Long sloDays;
    private String assignUser;
    private String leadComment;
    /* ECM Start Work FLow */
    private String comments;
    private String reqAdditionalInfo;
    /* ECM End Work FLow */

    private List<CommonsMultipartFile> attachedFile;
    private boolean closeAssistanceReqFlag;
    private List<Sector> projectSectorList;

    private List<DsmtSgmntSector> dsmtSegmentSectorList;

    private CommonsMultipartFile attachedDocument;
    private String deleteDocumentContentId;
    private Hashtable<String, String> dropDownTable;
    private String attachmentDocumentName;
    private Long tiRequestId;
    private Long selectedCmpCcrxrefId;

    private Long deletedCcrCmpXrefId;
    private List<CcrCmpXrefDto> ccrList;
    private Map<String, Object> cmpHistoryMap;
    private String activeCcrId;
    private boolean hasErrors;
    private String ccrCreated;
    private boolean emerBuscrit;
    private Long planningId;
    
    private List<EmerBuscritQuestionaries> emerBuscritQuestionaries;
    private RelationshipProcess relationshipProcess;
    private ThirdPartyContact thirdPartyContact;
    private Long resentMailAuditId;
    
    private List<String> rejectIds;
    
    private String ccrStatus;
    private String mgrCompleteFlag;
    private String mgrCompletedReason;
    private String elgibleToUnAsgnUsrFromCmp;
    
    private String businessJustificationReqInfo;

    private String citiGrpDataReqInfo;

    private String customerDataReqInfo;

    private String connectionFreqencyReqInfo;

    private String gocCodeReqInfo;

    private String typeOfEntityReqInfo;

    private String directAccessReqInfo;

    private String reasonReqInfo;

    private String urgencyReqInfo;

    private String affectedBusinessReqInfo;
    
    private List<CmpRequestDTO> bjReqInfoList;
    
    private List<CmpRequestDTO> citiGrpDataReqInfoList;
    
    private List<CmpRequestDTO> customerDataReqInfoList;
    
    private List<CmpRequestDTO> connectivityFrequencyReqInfoList;
    
    private List<CmpRequestDTO> gocCodeReqInfoList;
    
    private List<CmpRequestDTO> typeOfEntityReqInfoList;
    
    private List<CmpRequestDTO> directAccessReqInfoList;
    
    private List<CmpRequestDTO> reasonReqInfoList;
    
    private List<CmpRequestDTO> urgencyReqInfoList;
    
    private List<CmpRequestDTO> affectedBusinessReqInfoList;
    
    private String CMPStatus;
    
    private List<CmpRequestDTO> regionReqInfoList;

    private List<CmpRequestDTO> sectorReqInfoList;

    private List<CmpRequestDTO> businessUnitReqInfoList;

    private List<CmpRequestDTO> companyNameReqInfoList;

    private List<CmpRequestDTO> tptContactNameReqInfoList;

    private List<CmpRequestDTO> caspSuppIdReqInfoList;

    private List<CmpRequestDTO> tptContactTypeReqInfoList;

    private List<CmpRequestDTO> caspDetailIdReqInfoList;

    private List<CmpRequestDTO> tptContactPhoneReqInfoList;

    private List<CmpRequestDTO> tptContactEmailReqInfoList;
    
    private String regionReqInfo;

    private String sectorReqInfo;

    private String businessUnitReqInfo;

    private String companyNameReqInfo;

    private String tptContactNameReqInfo;

    private String caspSuppIdReqInfo;

    private String tptContactTypeReqInfo;

    private String caspDetailIdReqInfo;

    private String tptContactPhoneReqInfo;

    private String tptContactEmailReqInfo;

    /**
     * @return the cmpHistoryMap
     */
    public Map<String, Object> getCmpHistoryMap() {
        return cmpHistoryMap;
    }

    /**
     * @param cmpHistoryMap
     *            the cmpHistoryMap to set
     */
    public void setCmpHistoryMap(Map<String, Object> cmpHistoryMap) {
        this.cmpHistoryMap = cmpHistoryMap;
    }

    /**
     * @return the ccrList
     */
    public List<CcrCmpXrefDto> getCcrList() {
        return ccrList;
    }

    /**
     * @param ccrList
     *            the ccrList to set
     */
    public void setCcrList(List<CcrCmpXrefDto> ccrList) {
        this.ccrList = ccrList;
    }

    /**
     * @return the deletedCcrCmpXrefId
     */
    public Long getDeletedCcrCmpXrefId() {
        return deletedCcrCmpXrefId;
    }

    /**
     * @return the deletedCcrCmpXrefId
     */

    public void setDeletedCcrCmpXrefId(Long deletedCcrCmpXrefId) {
        this.deletedCcrCmpXrefId = deletedCcrCmpXrefId;
    }

    /**
     * @return the selectedCmpCcrxrefId
     */
    public Long getSelectedCmpCcrxrefId() {
        return selectedCmpCcrxrefId;
    }

    /**
     * @param selectedCmpCcrxrefId
     *            the selectedCmpCcrxrefId to set
     */
    public void setSelectedCmpCcrxrefId(Long selectedCmpCcrxrefId) {
        this.selectedCmpCcrxrefId = selectedCmpCcrxrefId;
    }

    /**
     * @return the tiRequestId
     */
    public Long getTiRequestId() {
        return tiRequestId;
    }

    /**
     * @param tiRequestId
     *            the tiRequestId to set
     */
    public void setTiRequestId(Long tiRequestId) {
        this.tiRequestId = tiRequestId;
    }

    public EmailGenerationViewProcess() {
    }

    public EmailGenerationViewProcess(String soeId, String lasName, String firstName) {
        super();
        this.soeId = soeId;
        this.lastName = lasName;
        this.firstName = firstName;
    }

    public List<Sector> getProjectSectorList() {
        return projectSectorList;
    }

    public void setProjectSectorList(List<Sector> projectSectorList) {
        this.projectSectorList = projectSectorList;
    }

    public String getAdditionalTextHold() {
        return additionalTextHold;
    }

    public void setAdditionalTextHold(String additionalTextHold) {
        this.additionalTextHold = additionalTextHold;
    }

    /* ECM Start Work FLow */

    public String getComments() {
        return comments;
    }

    public boolean isCloseAssistanceReqFlag() {
        return closeAssistanceReqFlag;
    }

    public void setCloseAssistanceReqFlag(boolean closeAssistanceReqFlag) {
        this.closeAssistanceReqFlag = closeAssistanceReqFlag;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getReqAdditionalInfo() {
        return reqAdditionalInfo;
    }

    public void setReqAdditionalInfo(String reqAdditionalInfo) {
        this.reqAdditionalInfo = reqAdditionalInfo;
    }

    /* ECM End Work FLow */

    public String getLeadComment() {
        return leadComment;
    }

    public List<DsmtSgmntSector> getDsmtSegmentSectorList() {
        return dsmtSegmentSectorList;
    }

    public void setDsmtSegmentSectorList(List<DsmtSgmntSector> dsmtSegmentSectorList) {
        this.dsmtSegmentSectorList = dsmtSegmentSectorList;
    }

    public void setLeadComment(String leadComment) {
        this.leadComment = leadComment;
    }

    public List<CMPRequest> getResolveITMessageList() {
        return resolveITMessageList;
    }

    public void setResolveITMessageList(List<CMPRequest> resolveITMessageList) {
        this.resolveITMessageList = resolveITMessageList;
    }

    public CMPRequest getCmpRequest() {
        return cmpRequest;
    }

    public void setCmpRequest(CMPRequest cmpRequest) {
        this.cmpRequest = cmpRequest;
    }

    public String getCancelReason() {
        return cancelReason;
    }

    public void setCancelReason(String cancelReason) {
        this.cancelReason = cancelReason;
    }

    public Long getSloDays() {
        return sloDays;
    }

    public void setSloDays(Long sloDays) {
        this.sloDays = sloDays;
    }

    public String getCmpreqID() {
        return cmpreqID;
    }

    public void setCmpreqID(String cmpreqID) {
        this.cmpreqID = cmpreqID;
    }

    public Date getDateAssigned() {
        return dateAssigned;
    }

    public void setDateAssigned(Date dateAssigned) {
        this.dateAssigned = dateAssigned;
    }

    public Date getChgDate() {
        return chgDate;
    }

    public void setChgDate(Date chgDate) {
        this.chgDate = chgDate;
    }

    public Date getImplementedDate() {
        return implementedDate;
    }

    public void setImplementedDate(Date implementedDate) {
        this.implementedDate = implementedDate;
    }

    public String getCcrID() {
        return ccrID;
    }

    public void setCcrID(String ccrID) {
        this.ccrID = ccrID;
    }

    public String getRequester() {
        return requester;
    }

    public void setRequester(String requester) {
        this.requester = requester;
    }

    public String getPrimaryOwner() {
        return primaryOwner;
    }

    public void setPrimaryOwner(String primaryOwner) {
        this.primaryOwner = primaryOwner;
    }

    public String getAdditionalContacts() {
        return additionalContacts;
    }

    public void setAdditionalContacts(String additionalContacts) {
        this.additionalContacts = additionalContacts;
    }

    public String getChooseEmail() {
        return chooseEmail;
    }

    public void setChooseEmail(String chooseEmail) {
        this.chooseEmail = chooseEmail;
    }

    public String getAdditionalText() {
        return additionalText;
    }

    public void setAdditionalText(String additionalText) {
        this.additionalText = additionalText;
    }

    public String getEcmAgent() {
        return ecmAgent;
    }

    public void setEcmAgent(String ecmAgent) {
        this.ecmAgent = ecmAgent;
    }

    public String getAddNote() {
        return addNote;
    }

    public void setAddNote(String addNote) {
        this.addNote = addNote;
    }

    public String getChgID() {
        return chgID;
    }

    public void setChgID(String chgID) {
        this.chgID = chgID;
    }

    public String getAffectedBus() {
        return affectedBus;
    }

    public void setAffectedBus(String affectedBus) {
        this.affectedBus = affectedBus;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public List<Region> getRegionList() {
        return regionList;
    }

    public void setRegionList(List<Region> regionList) {
        this.regionList = regionList;
    }

    public List<Sector> getSectorList() {
        return sectorList;
    }

    public void setSectorList(List<Sector> sectorList) {
        this.sectorList = sectorList;
    }

    public List<GenericLookup> getUrgencyList() {
        return urgencyList;
    }

    public void setUrgencyList(List<GenericLookup> urgencyList) {
        this.urgencyList = urgencyList;
    }

    public List<GenericLookup> getRequestTypeList() {
        return requestTypeList;
    }

    public void setRequestTypeList(List<GenericLookup> requestTypeList) {
        this.requestTypeList = requestTypeList;
    }

    public List<GenericLookup> getAffectedBusinessList() {
        return affectedBusinessList;
    }

    public void setAffectedBusinessList(List<GenericLookup> affectedBusinessList) {
        this.affectedBusinessList = affectedBusinessList;
    }

    public List<BusinessUnit> getBusinessUnitList() {
        return businessUnitList;
    }

    public void setBusinessUnitList(List<BusinessUnit> businessUnitList) {
        this.businessUnitList = businessUnitList;
    }

    public String getAssignedUser() {
        return assignedUser;
    }

    public void setAssignedUser(String assignedUser) {
        this.assignedUser = assignedUser;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getTextForSubject() {
        return textForSubject;
    }

    public void setTextForSubject(String textForSubject) {
        this.textForSubject = textForSubject;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getSoeId() {
        return soeId;
    }

    public void setSoeId(String soeId) {
        this.soeId = soeId;
    }

    public List getItemValueList() {
        return itemValueList;
    }

    public void setItemValueList(List itemValueList) {
        this.itemValueList = itemValueList;
    }

    public List<CMPRole> getCmprolesList() {
        return cmprolesList;
    }

    public void setCmprolesList(List<CMPRole> cmprolesList) {
        this.cmprolesList = cmprolesList;
    }

    public List<GenericLookup> getTypeOfConnectivityList() {
        return typeOfConnectivityList;
    }

    public void setTypeOfConnectivityList(List<GenericLookup> typeOfConnectivityList) {
        this.typeOfConnectivityList = typeOfConnectivityList;
    }

    public List<GenericLookup> getEmailTemplateList() {
        return emailTemplateList;
    }

    public void setEmailTemplateList(List<GenericLookup> emailTemplateList) {
        this.emailTemplateList = emailTemplateList;
    }

    public List<TIMailAudit> getTiMailAuditList() {
        return tiMailAuditList;
    }

    public void setTiMailAuditList(List<TIMailAudit> tiMailAuditList) {
        this.tiMailAuditList = tiMailAuditList;
    }

    public String getAssistanceRequested() {
        return assistanceRequested;
    }

    public void setAssistanceRequested(String assistanceRequested) {
        this.assistanceRequested = assistanceRequested;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public String getCaspUrl() {
        return caspUrl;
    }

    public void setCaspUrl(String caspUrl) {
        this.caspUrl = caspUrl;
    }

    public String getGlobalDirUrl() {
        return globalDirUrl;
    }

    public void setGlobalDirUrl(String globalDirUrl) {
        this.globalDirUrl = globalDirUrl;
    }

    public String getResolveItDetailUrl() {
        return resolveItDetailUrl;
    }

    public void setResolveItDetailUrl(String resolveItDetailUrl) {
        this.resolveItDetailUrl = resolveItDetailUrl;
    }

    public List<CommonsMultipartFile> getAttachedFile() {
        return attachedFile;
    }

    public void setAttachedFile(List<CommonsMultipartFile> attachedFile) {
        this.attachedFile = attachedFile;
    }

    public List<GenericLookup> getSlodaysList() {
        return slodaysList;
    }

    public void setSlodaysList(List<GenericLookup> slodaysList) {
        this.slodaysList = slodaysList;
    }

    public CommonsMultipartFile getAttachedDocument() {
        return attachedDocument;
    }

    public void setAttachedDocument(CommonsMultipartFile attachedDocument) {
        this.attachedDocument = attachedDocument;
    }

    public String getDeleteDocumentContentId() {
        return deleteDocumentContentId;
    }

    public void setDeleteDocumentContentId(String deleteDocumentContentId) {
        this.deleteDocumentContentId = deleteDocumentContentId;
    }

    public Hashtable<String, String> getDropDownTable() {
        return dropDownTable;
    }

    public void setDropDownTable(Hashtable<String, String> dropDownTable) {
        this.dropDownTable = dropDownTable;
    }

    public String getAttachmentDocumentName() {
        return attachmentDocumentName;
    }

    public void setAttachmentDocumentName(String attachmentDocumentName) {
        this.attachmentDocumentName = attachmentDocumentName;
    }

    public void sendEmailGenView(String chooseEmail, CMPRequest resolveITMessage) {
        ccrBeanFactory.getiMailModule().sendEcmEmailGeneration(chooseEmail, resolveITMessage);
    }

    public void sendEmailGenerationView(String chooseEmail, CmpRequestDTO commEmail) {
        ccrBeanFactory.getiMailModule().sendEcmEmailViewGeneration(chooseEmail, commEmail);
    }
    public void sendBreachNotification(String templateId,CmpRequestDTO cmpRequestDto){
        ccrBeanFactory.getiMailModule().sendSloNotification(templateId, cmpRequestDto);
    }
    public List<GenericLookup> loadGenericLookupByName(String name) {
        return ccrBeanFactory.getCommonServicePersistable().getGenericLookupByName(name);
    }

    public List<GenericLookup> loadEmailTemplatesByName(String name) {
        return ccrBeanFactory.getCommonServicePersistable().getEmailTemplateList(name);
    }

    public List<GenericLookup> loadGenericLookupData(List<String> names) {
        return ccrBeanFactory.getCommonServicePersistable().getGenericLookupData(names);
    }

    public List<Region> loadRegionList() {
        return ccrBeanFactory.getRelationshipServicePersistable().getRegionList();
    }

    public CitiContact getCitiContactDetails(String ssoId) {
        return ccrBeanFactory.getCmpRequestPersistable().getUserIdForSsoId(ssoId);
    }

    public void cmpActivityTrail(Long cmpId, String ssoId, String taskCode, String activityStatus) {
        ccrBeanFactory.getCmpRequestPersistable().cmpActivityTrail(cmpId, ssoId, taskCode, activityStatus,0l);
    }

    public List<Sector> loadSectorList(String regionName) {
        return ccrBeanFactory.getEmailGenViewServicePersistable().loadSectorListByName(regionName);
    }

    public List<BusinessUnit> loadBusinessUnitList(String regionName, String sectorName) {
        return ccrBeanFactory.getEmailGenViewServicePersistable().loadBusinessUnitListByName(regionName, sectorName);
    }

    public List<CMPRole> loadCMPRoles() {
        return ccrBeanFactory.getEmailGenViewServicePersistable().loadCMPRoles();
    }

    public CMPRequest getCMPRequestDetails(String cmpReqId) {
        return ccrBeanFactory.getEmailGenViewServicePersistable().getCMPRequestDetails(cmpReqId);
    }
    public List<CMPRequest> getCMPRequestList(String[] cmpOrderIds){
    	return ccrBeanFactory.getEmailGenViewServicePersistable().getCMPRequestList(cmpOrderIds);
    }
    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public void updateCMPRequestDetails(CMPRequest cmpRequest) {
        ccrBeanFactory.getEmailGenViewServicePersistable().updateCMPRequestDetails(cmpRequest);
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public void updateAddNoteDetails(CMPRequestNotes cmpRequestNotes) {
        ccrBeanFactory.getEmailGenViewServicePersistable().updateAddNoteDetails(cmpRequestNotes);
    }

    public void transferEcmAgent(String reassignedUser, String cmpId, String userId) {
        ccrBeanFactory.getEmailGenViewServicePersistable().transferEcmAgent(reassignedUser, cmpId, userId);
    }

    public void updateCmpRequestContactForTransfer(CitiContact citiContact, Long cmpContactId){
        ccrBeanFactory.getEmailGenViewServicePersistable().updateCmpRequestContactForTransfer(citiContact, cmpContactId);
    }
    
    public CitiContact getAgentDetails(String ssoId) {
        return ccrBeanFactory.getEmailGenViewServicePersistable().getAgentDetails(ssoId);
    }

    public CMPRequest getCMPRequestDetailsByOerderId(String cmpReqId) {
        return ccrBeanFactory.getEmailGenViewServicePersistable().getCMPRequestDetailsByOrderId(cmpReqId);
    }

    public int updateCMPRequestStatus(Long cmpId, String status) {
        return ccrBeanFactory.getEmailGenViewServicePersistable().updateCMPRequestStatus(cmpId, status);
    }

    public List<Map<String, String>> getChangeRequestDetails(Long conReqId, String cmpId) {
        return ccrBeanFactory.getEmailGenViewServicePersistable().getChangeRequestDetails(conReqId, cmpId);
    }

    public List<TIMailAudit> getAuditTrialDetail(Long cmpId) {
        return ccrBeanFactory.getEmailGenViewServicePersistable().getAuditTrialDetail(cmpId);
    }

    public boolean isWaitingforBusinessReply(Long cmpId, String activityCode, Long tiRequestId) {
        return ccrBeanFactory.getEmailGenViewServicePersistable().isWaitingforBusinessReply(cmpId, activityCode, tiRequestId);
    }
    public boolean isAccessForm(Long tiRequestId, String ruleType){
    	return ccrBeanFactory.getEmailGenViewServicePersistable().isAccessForm(tiRequestId, ruleType);
    }
    public boolean isSloNotification(Long tiRequestId,Long cmpId){
        return ccrBeanFactory.getEmailGenViewServicePersistable().isSloNotification(tiRequestId, cmpId);
    }
    public CitiContact getAgentDetailsByUserId(Long agentUserId){
        return ccrBeanFactory.getEmailGenViewServicePersistable().getAgentDetailsByUserId(agentUserId);
    }
    
    public boolean checkValidUser(String ssoid) {
        return ccrBeanFactory.getResolveITFieldPersistable().checkValidUser(ssoid);
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public boolean updateAssignedEcmUser(String orderId, String assignedUser2, Long sloDays2, String remoteUser,
            String leadComments) {
        return ccrBeanFactory.getResolveITFieldPersistable().updateAssignedEcmUser(orderId, assignedUser2, sloDays2,
                remoteUser, leadComments);
    }

    /*
     * @Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
     * public void checkTi(CMPRequest cmprequest){ return
     * emailGenViewServicePersistable.checkTi(cmprequest); }
     */

    public String getAssignUser() {
        return assignUser;
    }

    public void setAssignUser(String assignUser) {
        this.assignUser = assignUser;
    }

    public void checkColourstatus(CMPRequest cmprequest, String tiRequestId) {
        ccrBeanFactory.getEmailGenViewServicePersistable().checkColourstatus(cmprequest, tiRequestId);
    }

    public boolean checkCmpAssitanceReqFlag(Long cmpId) {
        boolean cmpCloseAssistanceReqFlag = ccrBeanFactory.getEmailGenViewServicePersistable()
                .checkCmpAssitanceReqFlag(cmpId);
        return cmpCloseAssistanceReqFlag;
    }

    public List<Sector> loadProjectSectorList() {
        return ccrBeanFactory.getResolveITFieldPersistable().getProjectSectorList();
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public boolean updateAssignedEcmUser(String orderId, String assignedUser2, Long sloDays2, String remoteUser,
            String leadComments, String projectSector) {
        return ccrBeanFactory.getResolveITFieldPersistable().updateAssignedEcmUser(orderId, assignedUser2, sloDays2,
                remoteUser, leadComments, projectSector);
    }

    public CitiContact getCitiContactByGEId(String geId) {
        return ccrBeanFactory.getCmpRequestPersistable().getuserIdForgGeid(geId);
    }

    public List<DsmtSgmntSector> getDsmtSgmntSectorList() {
        return ccrBeanFactory.getResolveITFieldPersistable().getDsmtSgmntSectorList();
    }

    public void addAttachmentToCmp(CmpAttachmentsDTO cmpAttachment, boolean fromCMPFeed) {
        ccrBeanFactory.getEmailGenViewServicePersistable().saveCmpAttachment(cmpAttachment, fromCMPFeed);
    }

    public void deleteAttachment(String contentId, String userId, Long cmpId) {
        ccrBeanFactory.getEmailGenViewServicePersistable().deleteCmpAttachment(contentId, userId,cmpId);
    }

    public Hashtable<String, String> getDocumentDropdownList() {
        return ccrBeanFactory.getEmailGenViewServicePersistable().getDocumentDropdownList();
    }

    public List<Map<String, String>> getChangeRequestDetails(Long conReqId) {
        return ccrBeanFactory.getEmailGenViewServicePersistable().getChangeRequestDetails(conReqId);
    }
    
    public List<GenericLookup> getEmailTemplateListForCurrentTask(EmailGenerationViewProcess emailGenerationViewProcess) {
        return ccrBeanFactory.getCommonServicePersistable().getEmailTemplateListForCurrentTask(emailGenerationViewProcess);
    }
    
    public ThirdPartyContact loadThirdPartyContact(Long detailId) {
        return ccrBeanFactory.getEmailGenViewServicePersistable().getThirdPartyContactByDetailId(detailId);
    }

    public String getActiveCcrId() {
        return activeCcrId;
    }

    public void setActiveCcrId(String activeCcrId) {
        this.activeCcrId = activeCcrId;
    }

    /**
     * @return the hasErrors
     */
    public boolean isHasErrors() {
        return hasErrors;
    }

    /**
     * @param hasErrors
     *            the hasErrors to set
     */
    public void setHasErrors(boolean hasErrors) {
        this.hasErrors = hasErrors;
    }

    public String getRequestUrgency() {
        return requestUrgency;
    }

    public void setRequestUrgency(String requestUrgency) {
        this.requestUrgency = requestUrgency;
    }
    public String getCmpRequestUrgency() {
		return cmpRequestUrgency;
	}

	public void setCmpRequestUrgency(String cmpRequestUrgency) {
		this.cmpRequestUrgency = cmpRequestUrgency;
	}

	public String getCcrCreated() {
        return ccrCreated;
    }

    public void setCcrCreated(String ccrCreated) {
        this.ccrCreated = ccrCreated;
    }

    public List<EmerBuscritQuestionaries> getEmerBuscritQuestionaries() {
        return emerBuscritQuestionaries;
    }

    public void setEmerBuscritQuestionaries(List<EmerBuscritQuestionaries> emerBuscritQuestionaries) {
        this.emerBuscritQuestionaries = emerBuscritQuestionaries;
    }

    public boolean isEmerBuscrit() {
        return emerBuscrit;
    }

    public void setEmerBuscrit(boolean emerBuscrit) {
        this.emerBuscrit = emerBuscrit;
    }
    
    public String getCMPRoleDisplayName(Long roleId) {
        return ccrBeanFactory.getEmailGenViewServicePersistable().getcmpRoleNameById(roleId);
    }

    public RelationshipProcess getRelationshipProcess() {
        return relationshipProcess;
    }

    public void setRelationshipProcess(RelationshipProcess relationshipProcess) {
        this.relationshipProcess = relationshipProcess;
    }

    public ThirdPartyContact getThirdPartyContact() {
        return thirdPartyContact;
    }

    public void setThirdPartyContact(ThirdPartyContact thirdPartyContact) {
        this.thirdPartyContact = thirdPartyContact;
    }

	public ConnectionRequest getConnectionRequest() {
		return connectionRequest;
	}

	public void setConnectionRequest(ConnectionRequest connectionRequest) {
		this.connectionRequest = connectionRequest;
	}

	public List<GenericLookup> getClassificationList() {
		return classificationList;
	}

	public void setClassificationList(List<GenericLookup> classificationList) {
		this.classificationList = classificationList;
	}

	public List<GenericLookup> getConestimateList() {
		return conestimateList;
	}

	public void setConestimateList(List<GenericLookup> conestimateList) {
		this.conestimateList = conestimateList;
	}

	public List<GenericLookup> getCmpEntityList() {
		return cmpEntityList;
	}

	public void setCmpEntityList(List<GenericLookup> cmpEntityList) {
		this.cmpEntityList = cmpEntityList;
	}

	public List<GenericLookup> getReasonB2BList() {
		return reasonB2BList;
	}

	public void setReasonB2BList(List<GenericLookup> reasonB2BList) {
		this.reasonB2BList = reasonB2BList;
	}
	
	public List<GenericLookup> getGenericLookupDropDown(String defname) {
		return  ccrBeanFactory.getBusjusServicePersistable().getGenericLookupDropDown(defname);		
	}

	public ConnectionRequest getConnectionRequest(Long conreqid) {
		return  ccrBeanFactory.getBusjusServicePersistable().getConnectionRequest(conreqid);		
	}
	
	public Long getPlanningId(Long tirequestid) {
		return ccrBeanFactory.getCommonServicePersistable().getPlanningIdForTiRequestId(tirequestid);		
	}
	@Transactional(readOnly = true)
	public String getRequestUrgencyFromCMP(String cmpOrderItemId){
	    return ccrBeanFactory.getCmpRequestPersistable().getRequestUrgencyFromCMP(cmpOrderItemId);
	}

    public List<DsmtSgmntSector> getDsmtSgmntSectorList(String region) {
        return ccrBeanFactory.getResolveITFieldPersistable().getDsmtSgmntSectorList(region);
    }

    /**
     * @return the resentMailAuditId
     */
    public Long getResentMailAuditId() {
        return resentMailAuditId;
    }

    /**
     * @param resentMailAuditId
     *            the resentMailAuditId to set
     */
    public void setResentMailAuditId(Long resentMailAuditId) {
        this.resentMailAuditId = resentMailAuditId;
    }

    /**
     * @param resentMailAuditId
     * 
     */
    public void resendEmailGenView(CmpRequestDTO cmpRequestDTO) {
        ccrBeanFactory.getiMailModule().resendEcmEmailViewGeneration(cmpRequestDTO);
    }
    
    
    /**
     * 
     * @param rolename
     * @return
     */
    public Long getcmpRoleIdByName(String rolename) {
        return ccrBeanFactory.getEmailGenViewServicePersistable().getcmpRoleIdByName(rolename);
    }
    
    public List<String> getRejectIds() {
		return rejectIds;
	}

	public void setRejectIds(List<String> rejectIds) {
		this.rejectIds = rejectIds;
	}

    /**
     * @return the ccrStatus
     */
    public String getCcrStatus() {
        return ccrStatus;
    }

    /**
     * @param ccrStatus
     *            the ccrStatus to set
     */
    public void setCcrStatus(String ccrStatus) {
        this.ccrStatus = ccrStatus;
    }

    /**
     * @return the mgrCompleteFlag
     */
    public String getMgrCompleteFlag() {
        return mgrCompleteFlag;
    }

    /**
     * @param mgrCompleteFlag
     *            the mgrCompleteFlag to set
     */
    public void setMgrCompleteFlag(String mgrCompleteFlag) {
        this.mgrCompleteFlag = mgrCompleteFlag;
    }

    /**
     * @return the mgrCompletedReason
     */
    public String getMgrCompletedReason() {
        return mgrCompletedReason;
    }

    /**
     * @param mgrCompletedReason
     *            the mgrCompletedReason to set
     */
    public void setMgrCompletedReason(String mgrCompletedReason) {
        this.mgrCompletedReason = mgrCompletedReason;
    }

    /**
     * @return the elgibleToUnAsgnUsrFromCmp
     */
    public String getElgibleToUnAsgnUsrFromCmp() {
        return elgibleToUnAsgnUsrFromCmp;
    }

    /**
     * @param elgibleToUnAsgnUsrFromCmp
     *            the elgibleToUnAsgnUsrFromCmp to set
     */
    public void setElgibleToUnAsgnUsrFromCmp(String elgibleToUnAsgnUsrFromCmp) {
        this.elgibleToUnAsgnUsrFromCmp = elgibleToUnAsgnUsrFromCmp;
    }

    public String getBusinessJustificationReqInfo() {
        return businessJustificationReqInfo;
    }

    public void setBusinessJustificationReqInfo(String businessJustificationReqInfo) {
        this.businessJustificationReqInfo = businessJustificationReqInfo;
    }

    public String getCitiGrpDataReqInfo() {
        return citiGrpDataReqInfo;
    }

    public void setCitiGrpDataReqInfo(String citiGrpDataReqInfo) {
        this.citiGrpDataReqInfo = citiGrpDataReqInfo;
    }

    public String getCustomerDataReqInfo() {
        return customerDataReqInfo;
    }

    public void setCustomerDataReqInfo(String customerDataReqInfo) {
        this.customerDataReqInfo = customerDataReqInfo;
    }

    public String getConnectionFreqencyReqInfo() {
        return connectionFreqencyReqInfo;
    }

    public void setConnectionFreqencyReqInfo(String connectionFreqencyReqInfo) {
        this.connectionFreqencyReqInfo = connectionFreqencyReqInfo;
    }

    public String getGocCodeReqInfo() {
        return gocCodeReqInfo;
    }

    public void setGocCodeReqInfo(String gocCodeReqInfo) {
        this.gocCodeReqInfo = gocCodeReqInfo;
    }

    public String getTypeOfEntityReqInfo() {
        return typeOfEntityReqInfo;
    }

    public void setTypeOfEntityReqInfo(String typeOfEntityReqInfo) {
        this.typeOfEntityReqInfo = typeOfEntityReqInfo;
    }

    public String getDirectAccessReqInfo() {
        return directAccessReqInfo;
    }

    public void setDirectAccessReqInfo(String directAccessReqInfo) {
        this.directAccessReqInfo = directAccessReqInfo;
    }

    public String getReasonReqInfo() {
        return reasonReqInfo;
    }

    public void setReasonReqInfo(String reasonReqInfo) {
        this.reasonReqInfo = reasonReqInfo;
    }

    public String getUrgencyReqInfo() {
        return urgencyReqInfo;
    }

    public void setUrgencyReqInfo(String urgencyReqInfo) {
        this.urgencyReqInfo = urgencyReqInfo;
    }

    public String getAffectedBusinessReqInfo() {
        return affectedBusinessReqInfo;
    }

    public void setAffectedBusinessReqInfo(String affectedBusinessReqInfo) {
        this.affectedBusinessReqInfo = affectedBusinessReqInfo;
    }

    public List<CmpRequestDTO> getBjReqInfoList() {
        return bjReqInfoList;
    }

    public void setBjReqInfoList(List<CmpRequestDTO> bjReqInfoList) {
        this.bjReqInfoList = bjReqInfoList;
    }

    public List<CmpRequestDTO> getCitiGrpDataReqInfoList() {
        return citiGrpDataReqInfoList;
    }

    public void setCitiGrpDataReqInfoList(List<CmpRequestDTO> citiGrpDataReqInfoList) {
        this.citiGrpDataReqInfoList = citiGrpDataReqInfoList;
    }

    public List<CmpRequestDTO> getCustomerDataReqInfoList() {
        return customerDataReqInfoList;
    }

    public void setCustomerDataReqInfoList(List<CmpRequestDTO> customerDataReqInfoList) {
        this.customerDataReqInfoList = customerDataReqInfoList;
    }

    public List<CmpRequestDTO> getConnectivityFrequencyReqInfoList() {
        return connectivityFrequencyReqInfoList;
    }

    public void setConnectivityFrequencyReqInfoList(List<CmpRequestDTO> connectivityFrequencyReqInfoList) {
        this.connectivityFrequencyReqInfoList = connectivityFrequencyReqInfoList;
    }

    public List<CmpRequestDTO> getGocCodeReqInfoList() {
        return gocCodeReqInfoList;
    }

    public void setGocCodeReqInfoList(List<CmpRequestDTO> gocCodeReqInfoList) {
        this.gocCodeReqInfoList = gocCodeReqInfoList;
    }

    public List<CmpRequestDTO> getTypeOfEntityReqInfoList() {
        return typeOfEntityReqInfoList;
    }

    public void setTypeOfEntityReqInfoList(List<CmpRequestDTO> typeOfEntityReqInfoList) {
        this.typeOfEntityReqInfoList = typeOfEntityReqInfoList;
    }

    public List<CmpRequestDTO> getDirectAccessReqInfoList() {
        return directAccessReqInfoList;
    }

    public void setDirectAccessReqInfoList(List<CmpRequestDTO> directAccessReqInfoList) {
        this.directAccessReqInfoList = directAccessReqInfoList;
    }

    public List<CmpRequestDTO> getReasonReqInfoList() {
        return reasonReqInfoList;
    }

    public void setReasonReqInfoList(List<CmpRequestDTO> reasonReqInfoList) {
        this.reasonReqInfoList = reasonReqInfoList;
    }

    public List<CmpRequestDTO> getUrgencyReqInfoList() {
        return urgencyReqInfoList;
    }

    public void setUrgencyReqInfoList(List<CmpRequestDTO> urgencyReqInfoList) {
        this.urgencyReqInfoList = urgencyReqInfoList;
    }

    public List<CmpRequestDTO> getAffectedBusinessReqInfoList() {
        return affectedBusinessReqInfoList;
    }

    public void setAffectedBusinessReqInfoList(List<CmpRequestDTO> affectedBusinessReqInfoList) {
        this.affectedBusinessReqInfoList = affectedBusinessReqInfoList;
    }

    public String getCMPStatus() {
        return CMPStatus;
    }

    public void setCMPStatus(String cMPStatus) {
        CMPStatus = cMPStatus;
    }

    public List<CmpRequestDTO> getRegionReqInfoList() {
        return regionReqInfoList;
    }

    public void setRegionReqInfoList(List<CmpRequestDTO> regionReqInfoList) {
        this.regionReqInfoList = regionReqInfoList;
    }

    public List<CmpRequestDTO> getSectorReqInfoList() {
        return sectorReqInfoList;
    }

    public void setSectorReqInfoList(List<CmpRequestDTO> sectorReqInfoList) {
        this.sectorReqInfoList = sectorReqInfoList;
    }

    public List<CmpRequestDTO> getBusinessUnitReqInfoList() {
        return businessUnitReqInfoList;
    }

    public void setBusinessUnitReqInfoList(List<CmpRequestDTO> businessUnitReqInfoList) {
        this.businessUnitReqInfoList = businessUnitReqInfoList;
    }

    public List<CmpRequestDTO> getCompanyNameReqInfoList() {
        return companyNameReqInfoList;
    }

    public void setCompanyNameReqInfoList(List<CmpRequestDTO> companyNameReqInfoList) {
        this.companyNameReqInfoList = companyNameReqInfoList;
    }

    public List<CmpRequestDTO> getTptContactNameReqInfoList() {
        return tptContactNameReqInfoList;
    }

    public void setTptContactNameReqInfoList(List<CmpRequestDTO> tptContactNameReqInfoList) {
        this.tptContactNameReqInfoList = tptContactNameReqInfoList;
    }

    public List<CmpRequestDTO> getCaspSuppIdReqInfoList() {
        return caspSuppIdReqInfoList;
    }

    public void setCaspSuppIdReqInfoList(List<CmpRequestDTO> caspSuppIdReqInfoList) {
        this.caspSuppIdReqInfoList = caspSuppIdReqInfoList;
    }

    public List<CmpRequestDTO> getTptContactTypeReqInfoList() {
        return tptContactTypeReqInfoList;
    }

    public void setTptContactTypeReqInfoList(List<CmpRequestDTO> tptContactTypeReqInfoList) {
        this.tptContactTypeReqInfoList = tptContactTypeReqInfoList;
    }

    public List<CmpRequestDTO> getCaspDetailIdReqInfoList() {
        return caspDetailIdReqInfoList;
    }

    public void setCaspDetailIdReqInfoList(List<CmpRequestDTO> caspDetailIdReqInfoList) {
        this.caspDetailIdReqInfoList = caspDetailIdReqInfoList;
    }

    public List<CmpRequestDTO> getTptContactPhoneReqInfoList() {
        return tptContactPhoneReqInfoList;
    }

    public void setTptContactPhoneReqInfoList(List<CmpRequestDTO> tptContactPhoneReqInfoList) {
        this.tptContactPhoneReqInfoList = tptContactPhoneReqInfoList;
    }

    public List<CmpRequestDTO> getTptContactEmailReqInfoList() {
        return tptContactEmailReqInfoList;
    }

    public void setTptContactEmailReqInfoList(List<CmpRequestDTO> tptContactEmailReqInfoList) {
        this.tptContactEmailReqInfoList = tptContactEmailReqInfoList;
    }

    public String getRegionReqInfo() {
        return regionReqInfo;
    }

    public void setRegionReqInfo(String regionReqInfo) {
        this.regionReqInfo = regionReqInfo;
    }

    public String getSectorReqInfo() {
        return sectorReqInfo;
    }

    public void setSectorReqInfo(String sectorReqInfo) {
        this.sectorReqInfo = sectorReqInfo;
    }

    public String getBusinessUnitReqInfo() {
        return businessUnitReqInfo;
    }

    public void setBusinessUnitReqInfo(String businessUnitReqInfo) {
        this.businessUnitReqInfo = businessUnitReqInfo;
    }

    public String getCompanyNameReqInfo() {
        return companyNameReqInfo;
    }

    public void setCompanyNameReqInfo(String companyNameReqInfo) {
        this.companyNameReqInfo = companyNameReqInfo;
    }

    public String getTptContactNameReqInfo() {
        return tptContactNameReqInfo;
    }

    public void setTptContactNameReqInfo(String tptContactNameReqInfo) {
        this.tptContactNameReqInfo = tptContactNameReqInfo;
    }

    public String getCaspSuppIdReqInfo() {
        return caspSuppIdReqInfo;
    }

    public void setCaspSuppIdReqInfo(String caspSuppIdReqInfo) {
        this.caspSuppIdReqInfo = caspSuppIdReqInfo;
    }

    public String getTptContactTypeReqInfo() {
        return tptContactTypeReqInfo;
    }

    public void setTptContactTypeReqInfo(String tptContactTypeReqInfo) {
        this.tptContactTypeReqInfo = tptContactTypeReqInfo;
    }

    public String getCaspDetailIdReqInfo() {
        return caspDetailIdReqInfo;
    }

    public void setCaspDetailIdReqInfo(String caspDetailIdReqInfo) {
        this.caspDetailIdReqInfo = caspDetailIdReqInfo;
    }

    public String getTptContactPhoneReqInfo() {
        return tptContactPhoneReqInfo;
    }

    public void setTptContactPhoneReqInfo(String tptContactPhoneReqInfo) {
        this.tptContactPhoneReqInfo = tptContactPhoneReqInfo;
    }

    public String getTptContactEmailReqInfo() {
        return tptContactEmailReqInfo;
    }

    public void setTptContactEmailReqInfo(String tptContactEmailReqInfo) {
        this.tptContactEmailReqInfo = tptContactEmailReqInfo;
    }
    
    public void updateCMPAttachments(CmpAttachmentsDTO cmpAttachmentsDto) {
    	ccrBeanFactory.getEmailGenViewServicePersistable().updateCMPAttachments(cmpAttachmentsDto);
    }
    
    public void downloadCMPAttachments(CMPRequest cmpRequest) {
    	ccrBeanFactory.getCmpRequestPersistable().getCmpAttachments(cmpRequest.getCmpRequestAttachments(), cmpRequest.getOrderItemId(), cmpRequest.getOrderBySoeID());
    }
    
}
