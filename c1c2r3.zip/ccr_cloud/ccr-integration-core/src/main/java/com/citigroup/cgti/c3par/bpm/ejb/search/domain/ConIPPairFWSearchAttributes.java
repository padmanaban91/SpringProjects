package com.citigroup.cgti.c3par.bpm.ejb.search.domain;

import java.io.Serializable;


/**
 * The Class ConIPPairFWSearchAttributes.
 */
public class ConIPPairFWSearchAttributes  extends BaseSearchAttributes implements Serializable{


    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -7857746390560695826L;

    /** The ip pair. */
    private String ipPair=null;

    /** The firewall. */
    private String firewall=null;

    /**
     * Gets the firewall.
     *
     * @return the firewall
     */
    public String getFirewall() {
	return firewall;
    }

    public String getFirewallForQuery() {
	return validString(firewall);
    }
    /**
     * Sets the firewall.
     *
     * @param firewall the new firewall
     */
    public void setFirewall(String firewall) {
	this.firewall = firewall;
    }

    /**
     * Gets the ip pair.
     *
     * @return the ip pair
     */
    public String getIpPair() {
	return ipPair;
    }

    public String getIpPairForQuery() {
	return validString(ipPair);
    }

    /**
     * Sets the ip pair.
     *
     * @param ipPair the new ip pair
     */
    public void setIpPair(String ipPair) {
	this.ipPair = ipPair;
    }
}
