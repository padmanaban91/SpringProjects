package com.citigroup.cgti.c3par.communication.domain;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.communication.domain.soc.persist.MonthViewPersistable;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

public class MonthViewProcess {
	
CCRBeanFactory ccrBeanFactory;
	
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}
	private String assignedUser;
	private String lastName;
	private String firstName;
	private String role;
	private int totalAssignedCount;
	private int totalCompleteCancelCount;
	private double totalAvg;
	private boolean totalSLOCrossed;
	private Integer [] monthAssignedCount;          
	private Integer [] monthCompleteCancelCount; 
	private Double [] monthAvgCount;
	private Boolean [] monthSLOCrossed;
	
	private String orderId;
	private String status;
	private String timeToMarket;
	private String availableDate;
	private String closedDate;
	private String assignedGroup;
	private String requestType;	
	private String typeofConnectivityInvolved;
	private String requestUrgency;
	private String projectSector;
	private String region;	
	private String crossedSLO;
	
	@Transactional(propagation=Propagation.SUPPORTS, readOnly=true)
	public  Map<String, List<MonthViewProcess>> getAllDetails() {
		return ccrBeanFactory.getMonthViewPersistable().getAllDetails();		
	}
	
	@Transactional(propagation=Propagation.SUPPORTS, readOnly=true)
	public  List<MonthViewProcess> getPopupDetailsDetails(int assignedUser, String sectorName,String startDate,String endDate,String status) {
		return ccrBeanFactory.getMonthViewPersistable().getPopupDetailsDetails(assignedUser,sectorName,startDate,endDate,status);		
	}
	
	@Transactional(propagation=Propagation.SUPPORTS, readOnly=true)
	public  Map<String, List<MonthViewProcess>> getManagerViewDetails() {
		return ccrBeanFactory.getMonthViewPersistable().getManagerViewDetails();		
	}
	
	public String printMe(){
		
		return "lastName: "+lastName+" firstName: "+ firstName+ " role: "+role+" monthAssignedCount: "+ Arrays.asList(monthAssignedCount) +" monthCompleteCancelCount: "+Arrays.asList(monthCompleteCancelCount)+
				
				" totalAssignedCount: "+totalAssignedCount+" totalCompleteCancelCount: "+totalCompleteCancelCount;
	}

	public MonthViewPersistable getMonthViewPersistable() {
		return ccrBeanFactory.getMonthViewPersistable();
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public int getTotalAssignedCount() {
		return totalAssignedCount;
	}

	public void setTotalAssignedCount(int totalAssignedCount) {
		this.totalAssignedCount = totalAssignedCount;
	}

	public int getTotalCompleteCancelCount() {
		return totalCompleteCancelCount;
	}

	public void setTotalCompleteCancelCount(int totalCompleteCancelCount) {
		this.totalCompleteCancelCount = totalCompleteCancelCount;
	}

	public Integer[] getMonthAssignedCount() {
		return monthAssignedCount;
	}

	public void setMonthAssignedCount(Integer[] monthAssignedCount) {
		this.monthAssignedCount = monthAssignedCount;
	}

	public Integer[] getMonthCompleteCancelCount() {
		return monthCompleteCancelCount;
	}

	public void setMonthCompleteCancelCount(Integer[] monthCompleteCancelCount) {
		this.monthCompleteCancelCount = monthCompleteCancelCount;
	}	

	public String getAssignedUser() {
		return assignedUser;
	}

	public void setAssignedUser(String assignedUser) {
		this.assignedUser = assignedUser;
	}
	
	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getTypeofConnectivityInvolved() {
		return typeofConnectivityInvolved;
	}

	public void setTypeofConnectivityInvolved(String typeofConnectivityInvolved) {
		this.typeofConnectivityInvolved = typeofConnectivityInvolved;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTimeToMarket() {
		return timeToMarket;
	}

	public void setTimeToMarket(String timeToMarket) {
		this.timeToMarket = timeToMarket;
	}

	public String getAvailableDate() {
		return availableDate;
	}

	public void setAvailableDate(String availableDate) {
		this.availableDate = availableDate;
	}

	public String getClosedDate() {
		return closedDate;
	}

	public void setClosedDate(String closedDate) {
		this.closedDate = closedDate;
	}

	public String getAssignedGroup() {
		return assignedGroup;
	}

	public void setAssignedGroup(String assignedGroup) {
		this.assignedGroup = assignedGroup;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getRequestUrgency() {
		return requestUrgency;
	}

	public void setRequestUrgency(String requestUrgency) {
		this.requestUrgency = requestUrgency;
	}

	public String getProjectSector() {
		return projectSector;
	}

	public void setProjectSector(String projectSector) {
		this.projectSector = projectSector;
	}

	public Double [] getMonthAvgCount() {
		return monthAvgCount;
	}

	public void setMonthAvgCount(Double [] monthAvgCount) {
		this.monthAvgCount = monthAvgCount;
	}

	public Boolean [] getMonthSLOCrossed() {
		return monthSLOCrossed;
	}

	public void setMonthSLOCrossed(Boolean [] monthSLOCrossed) {
		this.monthSLOCrossed = monthSLOCrossed;
	}

	public boolean isTotalSLOCrossed() {
		return totalSLOCrossed;
	}

	public void setTotalSLOCrossed(boolean totalSLOCrossed) {
		this.totalSLOCrossed = totalSLOCrossed;
	}

	public double getTotalAvg() {
		return totalAvg;
	}

	public void setTotalAvg(double totalAvg) {
		this.totalAvg = totalAvg;
	}

	public String getCrossedSLO() {
		return crossedSLO;
	}

	public void setCrossedSLO(String crossedSLO) {
		this.crossedSLO = crossedSLO;
	}
	
}