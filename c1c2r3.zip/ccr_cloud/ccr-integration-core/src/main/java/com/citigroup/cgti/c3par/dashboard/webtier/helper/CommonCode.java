package com.citigroup.cgti.c3par.dashboard.webtier.helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.dao.lookup.GenericLookupLookup;
import com.citigroup.cgti.c3par.dao.lookup.SectorLookup;
import com.citigroup.cgti.c3par.lookup.C3parUsersLookup;
import com.citigroup.cgti.c3par.model.C3parUsersEntity;
import com.citigroup.cgti.c3par.model.EntitlementInstanceEntity;
import com.citigroup.cgti.c3par.model.GenericLookupEntity;
import com.citigroup.cgti.c3par.model.SectorEntity;
import com.citigroup.cgti.c3par.util.C3parStaticNames;
import com.mentisys.dao.DatabaseException;
import com.mentisys.dao.DatabaseSession;
import com.mentisys.dao.query.Condition;
import com.mentisys.dao.query.Operator;
import com.mentisys.dao.query.OperatorExpression;
import com.mentisys.impl.gen.locking.dao.LockDAO;
import com.mentisys.impl.gen.locking.model.LockEntity;
import com.mentisys.model.ManyAssociationList;


/**
 * The Class CommonCode.
 */
public class CommonCode
{

    /**
     * Gets the from lookup.
     *
     * @param lookupId the lookup id
     * @return the from lookup
     */
    public static GenericLookupEntity getFromLookup(Long lookupId)
    {
	GenericLookupLookup lookup = GenericLookupLookup.getInstance();
	return lookup.getById(lookupId);
    }

    /**
     * Gets the sector.
     *
     * @param sectorId the sector id
     * @return the sector
     */
    public static SectorEntity getSector(Long sectorId)
    {
	SectorLookup sector = SectorLookup.getInstance();
	return sector.getById(sectorId);
    }

    /**
     * Gets the current user id.
     *
     * @param request the request
     * @return the current user id
     */
    public static Long getCurrentUserId(HttpServletRequest request)
    {
	C3parUsersEntity entity = C3parUsersLookup.getInstance().getBySsoId(request.getUserPrincipal().getName().toLowerCase());
	return entity.getId();
    }
    /*ENTITLEMENT  commented out createEntitlement*/
    /*public static EntitlementXrefEntity createEntitlement(Long user_id, Entity ent)
		throws DatabaseException
	{
		EntitlementXrefEntity entitlement = new EntitlementXrefEntity();
		C3parUsersEntity user = C3parUsersLookup.getInstance().getById(new C3parSession(), user_id);
		ContainerGroupsEntity groupEntity = user.getGroup();
		String ownerName = groupEntity.getOwnerName();

		user = C3parUsersLookup.getInstance().getBySsoId(new C3parSession(), ownerName.toLowerCase());

		entitlement.setGroup(user.getGroup());
		entitlement.setEntityName(ent.getEntityName());

		return entitlement;
	}*/

    /**
     * Checks if is admin.
     *
     * @param session the session
     * @return true, if is admin
     */
    public static boolean isAdmin(HttpSession session)
    {
	Boolean isAdmin = (Boolean)session.getAttribute("IS_ADMIN");
	return isAdmin.booleanValue();
    }
    /* ENTITLEMENT ADDITION */
    //Given a user id get all entitements
    /**
     * Gets the entitlement instance.
     *
     * @param userId the user id
     * @return the entitlement instance
     */
    public static List getEntitlementInstance(Long userId)
    {
    	List activeEntilements=new ArrayList();
	/*//List entInstids=new ArrayList();
	C3parUsersLookup userLookup = C3parUsersLookup.getInstance();
	C3parUsersEntity userEntity = userLookup.getById(userId);
	List usrEntList=userEntity.getUserEntitlements();
	List activeEntilements=new ArrayList();

	if(usrEntList!=null)
	{
	    Iterator entItr=usrEntList.iterator();
	    while(entItr.hasNext())
	    {
		C3parUserEntitlementXrefEntity usrEntEntity=(C3parUserEntitlementXrefEntity)entItr.next();
		EntitlementInstanceEntity ent=usrEntEntity.getEntitlementInstance();
		if(ent.getInactive().equals("N"))
		    activeEntilements.add(usrEntEntity.getEntitlementInstance());
	    }

	}*/

	return activeEntilements;

    }
    // Retruns EntitlementInstance with Permissions as a Map
    /**
     * Gets the active entitlements.
     *
     * @param usrEntList the usr ent list
     * @return the active entitlements
     */
    public static Map getActiveEntitlements(ManyAssociationList usrEntList)

    {
	//List entInstids=new ArrayList();
	//List activeEntilements=new ArrayList();
	Map activeEntilements=new HashMap();

	if(usrEntList!=null)
	{
	   /* Iterator entItr=usrEntList.iterator();
	    while(entItr.hasNext())
	    {
		C3parUserEntitlementXrefEntity usrEntEntity=(C3parUserEntitlementXrefEntity)entItr.next();
		EntitlementInstanceEntity ent=usrEntEntity.getEntitlementInstance();
		if(ent.getInactive().equals("N"))
		    activeEntilements.put(usrEntEntity.getEntitlementInstanceId(),usrEntEntity.getPermissions());

	    }
*/
	}

	return activeEntilements;
    }

    /* ENTITLEMENT COMMENT getGroupId*/
    /*public static String getGroupId(Long userId)
	{
		C3parUsersLookup userLookup = C3parUsersLookup.getInstance();
		C3parUsersEntity userEntity = userLookup.getById(userId);
		return userEntity.getGroup().getId().toString();
	}*/
    /* ENTITLEMENT COMMENT GETGROUPNAME() */
    /* public static String getGroupName(Long userId)
	{
		C3parUsersLookup userLookup = C3parUsersLookup.getInstance();
		C3parUsersEntity userEntity = userLookup.getById(userId);
		return userEntity.getGroup().getName();
	} */
    /* ENTITLEMENT COMMENT GETGROUP */
    /*	public static EntitlementXrefEntity getGroup(Long groupId)
	throws DatabaseException
	{
		EntitlementXrefDAO dao = new EntitlementXrefDAO(new C3parSession());
		return dao.get(groupId);
	}*/

    /**
     * Checks if is relationship locked.
     *
     * @param relationshipId the relationship id
     * @param session the session
     * @return the lock entity
     * @throws DatabaseException the database exception
     */
    public static LockEntity isRelationshipLocked(Long relationshipId, DatabaseSession session)
    throws DatabaseException
    {
	Condition condition = new Condition();

	OperatorExpression relationshipIdExp =
	    new OperatorExpression(LockDAO.COLUMN_ENTITYID, Operator.EQUAL, relationshipId);
	condition.addExpression(relationshipIdExp);

	LockDAO dao = new LockDAO(session);
	List list = dao.query(condition, false);
	LockEntity entity = null;
	if(list != null && list.size() > 0)
	    entity = (LockEntity)list.get(0);

	return entity;
    }
    // commoncode is parent
    /**
     * Gets the from cache.
     *
     * @param relationshipId the relationship id
     * @param request the request
     * @return the from cache
     * @throws DatabaseException the database exception
     */
    public static List getFromCache(Long relationshipId, HttpServletRequest request)
    throws DatabaseException
    {
	RelationshipSearchAttributes attrs = new RelationshipSearchAttributes();
	if(!CommonCode.isAdmin(request.getSession())){
	    List entInstEntities=CommonCode.getEntitlementInstance(CommonCode.getCurrentUserId(request));
	    attrs.setEntInstList(entInstEntities);
	}	
	attrs.setRelationshipId(relationshipId);
	SearchRelationship searchRel = new SearchRelationship(new C3parSession(),attrs);
	return searchRel.runQuery(1, 10);
    }

    /**
     * Gets the from cache.
     *
     * @param relationshipId the relationship id
     * @param request the request
     * @param classificationId the classification id
     * @param pageNum the page num
     * @param pageSize the page size
     * @return the from cache
     * @throws DatabaseException the database exception
     */
    public static List getFromCache(List relationshipId, HttpServletRequest request, Long classificationId,int pageNum, int pageSize)
    throws DatabaseException
    {
	/* ENTITLEMENT comment the next line and instead of group name send entitlement instance ids */
	//List fromCache = CacheRelationship.getInstance().getRelationship(CommonCode.getGroupName(CommonCode.getCurrentUserId(request)), request.getSession());
	RelationshipSearchAttributes attrs = new RelationshipSearchAttributes();
	if(!CommonCode.isAdmin(request.getSession())){
	    /*List entInstEntities=CommonCode.getEntitlementInstance(CommonCode.getCurrentUserId(request));
	    attrs.setEntInstList(entInstEntities);*/
	}	
	attrs.setDataClassification(classificationId);
	SearchRelationship searchRel = new SearchRelationship(new C3parSession(),attrs);
	return searchRel.runQuery(pageNum, pageSize);
    }

    /**
     * Checks if is support agent role.
     *
     * @param session the session
     * @return true, if is support agent role
     */
    public static boolean isRole(HttpSession session,String roleName)
    {
	boolean isRole = false;
	Set sessionRole = (session.getAttribute("ROLE")== null) ? (new HashSet()) : ((HashSet) session.getAttribute("ROLE")) ;
	Iterator itr = sessionRole.iterator();
	while (itr.hasNext()) {
	    String role = (String) itr.next();
	    if (roleName.equalsIgnoreCase(role)) {
		isRole = true;
		break;
	    }
	}
	return isRole;
    }
}