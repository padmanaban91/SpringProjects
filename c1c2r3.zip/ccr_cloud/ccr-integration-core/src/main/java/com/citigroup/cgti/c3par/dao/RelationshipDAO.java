


/** CONFIDENTIAL  AND PROPRIETARY
 * Copyright @ 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is
 * strictly prohibited.
 */

package com.citigroup.cgti.c3par.dao;

import java.io.Serializable;
import java.sql.*;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.model.*;
import com.citigroup.cgti.c3par.dao.lookup.*;
import com.mentisys.model.*;
import com.mentisys.dao.*;
import com.mentisys.dao.query.*;
import com.mentisys.dao.audit.*;


// Reference imports

// Entity name = RelationshipDAO
// Table name = RELATIONSHIP
// Superclass = <none>
// Subclasses = <none>

/**
 * The Class RelationshipDAO.
 */
public class RelationshipDAO
extends DatabaseAccessObject
implements Serializable
{

    /** The Constant TABLE. */
    public static final String	TABLE = "RELATIONSHIP";

    /** The custom sequence. */
    private String customSequence;

    /** The database sequence. */
    private String databaseSequence;

    /** The log. */
    private static Logger log = Logger.getLogger(RelationshipDAO.class);

    /** The Constant ENTITY_NAME. */
    public static final String	ENTITY_NAME = "Relationship";

    /** The Constant COLUMN_ID. */
    public static final String	COLUMN_ID = "ID";

    // Column names
    /** The Constant COLUMN_NAME. */
    public static final String	COLUMN_NAME = "NAME";

    /** The Constant COLUMN_NAME_LEN. */
    public static final int		COLUMN_NAME_LEN = 350;

    /** The Constant COLUMN_PURPOSE. */
    public static final String	COLUMN_PURPOSE = "PURPOSE";

    /** The Constant COLUMN_PURPOSE_LEN. */
    public static final int		COLUMN_PURPOSE_LEN = 4000;

    /** The Constant COLUMN_CONNECTIVITYEXISTS. */
    public static final String	COLUMN_CONNECTIVITYEXISTS = "CONNECTIVITY_EXISTS";

    /** The Constant COLUMN_CONNECTIVITYEXISTS_LEN. */
    public static final int		COLUMN_CONNECTIVITYEXISTS_LEN = 10000;

    /** The Constant COLUMN_READYDATE. */
    public static final String	COLUMN_READYDATE = "READY_DATE";

    /** The Constant COLUMN_TERMINATEDDATE. */
    public static final String	COLUMN_TERMINATEDDATE = "TERMINATED_DATE";

    /** The Constant COLUMN_STATUS. */
    public static final String	COLUMN_STATUS = "STATUS";

    /** The Constant COLUMN_STATUS_LEN. */
    public static final int		COLUMN_STATUS_LEN = 25;

/*    *//** The Constant COLUMN_RELATIONSHIPID. *//*
    public static final String	COLUMN_RELATIONSHIPID = "RELATIONSHIP_ID";
*/
    /** The Constant COLUMN_REQUESTERID. */
    public static final String	COLUMN_REQUESTERID = "REQUESTER_ID";

    /** The Constant COLUMN_REQUESTERID_LEN. */
    public static final int		COLUMN_REQUESTERID_LEN = 50;

    /** The Constant COLUMN_BENEFIT. */
    public static final String	COLUMN_BENEFIT = "BENEFIT";

    /** The Constant COLUMN_BENEFIT_LEN. */
    public static final int		COLUMN_BENEFIT_LEN = 250;

    /** The Constant COLUMN_PLCODE. */
    public static final String	COLUMN_PLCODE = "PLCODE";

    /** The Constant COLUMN_PLCODE_LEN. */
    public static final int		COLUMN_PLCODE_LEN = 100;

    /** The Constant COLUMN_ESTIMATEDREVENUEGENERATED. */
    public static final String	COLUMN_ESTIMATEDREVENUEGENERATED = "ESTIMATED_REVENUE_GENERATED";

    /** The Constant COLUMN_ESTIMATEDCOSTSAVING. */
    public static final String	COLUMN_ESTIMATEDCOSTSAVING = "ESTIMATED_COST_SAVING";

    /** The Constant COLUMN_COBREDUNDANCYREQUIRED. */
    public static final String	COLUMN_COBREDUNDANCYREQUIRED = "COB_REDUNDANCY_REQUIRED";

    /** The Constant COLUMN_PROCUREMENTCOMPLETIONDATE. */
    public static final String	COLUMN_PROCUREMENTCOMPLETIONDATE = "PROCUREMENT_COMPLETION_DATE";

    /** The Constant COLUMN_GNCCAPPROVALATTAINED. */
    public static final String	COLUMN_GNCCAPPROVALATTAINED = "GNCC_APPROVAL_ATTAINED";

    /** The Constant COLUMN_COMMENTS. */
    public static final String	COLUMN_COMMENTS = "COMMENTS";

    /** The Constant COLUMN_COMMENTS_LEN. */
    public static final int		COLUMN_COMMENTS_LEN = 2000;

    /** The Constant COLUMN_INITIALRISKASSESMENTDATE. */
    public static final String	COLUMN_INITIALRISKASSESMENTDATE = "INITIAL_RISK_ASSESMENT_DATE";

    /** The Constant COLUMN_ONETIMECOST. */
    public static final String	COLUMN_ONETIMECOST = "ONE_TIME_COST";

    /** The Constant COLUMN_MONTHLYCOST. */
    public static final String	COLUMN_MONTHLYCOST = "MONTHLY_COST";

    /** The Constant COLUMN_DATAISPUBLIC. */
    public static final String	COLUMN_DATAISPUBLIC = "DATA_IS_PUBLIC";

    /** The Constant COLUMN_ISOUTSOURCEPROVIDER. */
    public static final String	COLUMN_ISOUTSOURCEPROVIDER = "IS_OUTSOURCE_PROVIDER";

    /** The Constant COLUMN_ISOUTSOURCEPROVIDER_LEN. */
    public static final int		COLUMN_ISOUTSOURCEPROVIDER_LEN = 10000;

    /** The Constant COLUMN_OSPSERVICENAME. */
    public static final String	COLUMN_OSPSERVICENAME = "OSP_SERVICE_NAME";

    /** The Constant COLUMN_OSPSERVICENAME_LEN. */
    public static final int		COLUMN_OSPSERVICENAME_LEN = 100;

    /** The Constant COLUMN_ACCESSCITIDATA. */
    public static final String	COLUMN_ACCESSCITIDATA = "ACCESS_CITI_DATA";

    /** The Constant COLUMN_ACCESSCITIDATA_LEN. */
    public static final int		COLUMN_ACCESSCITIDATA_LEN = 10000;

    /** The Constant COLUMN_ACCESSCUSTOMERDATA. */
    public static final String	COLUMN_ACCESSCUSTOMERDATA = "ACCESS_CUSTOMER_DATA";

    /** The Constant COLUMN_ACCESSCUSTOMERDATA_LEN. */
    public static final int		COLUMN_ACCESSCUSTOMERDATA_LEN = 10000;

    /** The Constant COLUMN_CONTRACTRENEWALDATE. */
    public static final String	COLUMN_CONTRACTRENEWALDATE = "CONTRACT_RENEWAL_DATE";

    /** The Constant COLUMN_DELETED. */
    public static final String	COLUMN_DELETED = "DELETED";

    /** The Constant COLUMN_REQUESTDATE. */
    public static final String	COLUMN_REQUESTDATE = "REQUEST_DATE";

    /** The Constant COLUMN_ENTINSTANCEID. */
    public static final String	COLUMN_ENTINSTANCEID = "ENT_INSTANCE_ID";

    /** The Constant COLUMN_RELATIONSHIPTYPE. */
    public static final String	COLUMN_RELATIONSHIPTYPE = "RELATIONSHIP_TYPE";

    /** The Constant COLUMN_RELATIONSHIPTYPE_LEN. */
    public static final int		COLUMN_RELATIONSHIPTYPE_LEN = 50;
    // Column names of references
    /** The Constant COLUMN_LOOKUP_ID. */
    public static final String	COLUMN_LOOKUP_ID = "LOOKUP_ID";

    /** The Constant COLUMN_BUSINESSUNIT_ID. */
    public static final String	COLUMN_BUSINESSUNIT_ID = "BUSINESS_UNIT_ID";

    /** The Constant COLUMN_THIRDPARTY_ID. */
    public static final String	COLUMN_THIRDPARTY_ID = "THIRD_PARTY_ID";

    /** The Constant COLUMN_OWNEDBY_ID. */
    public static final String	COLUMN_OWNEDBY_ID = "OWNEDBY_ID";

    /** The Constant COLUMN_TARGETRESOURCETYPE_ID. */
    public static final String	COLUMN_TARGETRESOURCETYPE_ID = "TARGET_RESOURCE_TYPE_ID";

    /** The Constant COLUMN_REQUESTERRESOURCETYPE_ID. */
    public static final String	COLUMN_REQUESTERRESOURCETYPE_ID = "REQUESTER_RESOURCE_TYPE_ID";

    /** The Constant COLUMN_UTURNTHIRDPARTY_ID. */
    public static final String	COLUMN_UTURNTHIRDPARTY_ID = "UTURN_THIRD_PARTY_ID";

    // DAO Queries
    /** The SELEC t_ i d_ stmt. */
    private static String SELECT_ID_STMT = "SELECT "  + COLUMN_ID + " FROM " + RelationshipDAO.TABLE;

    /** The SELEC t_ stmt. */
    private static String SELECT_STMT = "SELECT "  + COLUMN_ID
    + ", " + COLUMN_NAME
    + ", " + COLUMN_PURPOSE
    + ", " + COLUMN_CONNECTIVITYEXISTS
    + ", " + COLUMN_READYDATE
    + ", " + COLUMN_TERMINATEDDATE
    + ", " + COLUMN_STATUS
    + ", " + COLUMN_REQUESTERID
    + ", " + COLUMN_BENEFIT
    + ", " + COLUMN_PLCODE
    + ", " + COLUMN_ESTIMATEDREVENUEGENERATED
    + ", " + COLUMN_ESTIMATEDCOSTSAVING
    + ", " + COLUMN_COBREDUNDANCYREQUIRED
    + ", " + COLUMN_PROCUREMENTCOMPLETIONDATE
    + ", " + COLUMN_GNCCAPPROVALATTAINED
    + ", " + COLUMN_COMMENTS
    + ", " + COLUMN_INITIALRISKASSESMENTDATE
    + ", " + COLUMN_ONETIMECOST
    + ", " + COLUMN_MONTHLYCOST
    + ", " + COLUMN_DATAISPUBLIC
    + ", " + COLUMN_ISOUTSOURCEPROVIDER
    + ", " + COLUMN_OSPSERVICENAME
    + ", " + COLUMN_ACCESSCITIDATA
    + ", " + COLUMN_ACCESSCUSTOMERDATA
    + ", " + COLUMN_CONTRACTRENEWALDATE
    + ", " + COLUMN_DELETED
    + ", " + COLUMN_REQUESTDATE
    //+ ", " + COLUMN_ENTINSTANCEID
    + ", " + COLUMN_RELATIONSHIPTYPE
    + ", " + COLUMN_LOOKUP_ID
  //  + ", " + COLUMN_BUSINESSUNIT_ID
    + ", " + COLUMN_THIRDPARTY_ID
    + ", " + COLUMN_OWNEDBY_ID
    + ", " + COLUMN_TARGETRESOURCETYPE_ID
    + ", " + COLUMN_REQUESTERRESOURCETYPE_ID
    + ", " + COLUMN_UTURNTHIRDPARTY_ID
    + " FROM " + RelationshipDAO.TABLE;

    /** The SELEC t_ b y_ i d_ stmt. */
    private static String SELECT_BY_ID_STMT = RelationshipDAO.SELECT_STMT + " WHERE " + COLUMN_ID + " = ?";

    /** The UPDAT e_ b y_ i d_ stmt. */
    private static String UPDATE_BY_ID_STMT = "UPDATE " + RelationshipDAO.TABLE + " SET "
    + COLUMN_NAME + " = ? "
    + ", " + COLUMN_PURPOSE + " = ? "
    + ", " + COLUMN_CONNECTIVITYEXISTS + " = ? "
    + ", " + COLUMN_READYDATE + " = ? "
    + ", " + COLUMN_TERMINATEDDATE + " = ? "
    + ", " + COLUMN_STATUS + " = ? "
    + ", " + COLUMN_REQUESTERID + " = ? "
    + ", " + COLUMN_BENEFIT + " = ? "
    + ", " + COLUMN_PLCODE + " = ? "
    + ", " + COLUMN_ESTIMATEDREVENUEGENERATED + " = ? "
    + ", " + COLUMN_ESTIMATEDCOSTSAVING + " = ? "
    + ", " + COLUMN_COBREDUNDANCYREQUIRED + " = ? "
    + ", " + COLUMN_PROCUREMENTCOMPLETIONDATE + " = ? "
    + ", " + COLUMN_GNCCAPPROVALATTAINED + " = ? "
    + ", " + COLUMN_COMMENTS + " = ? "
    + ", " + COLUMN_INITIALRISKASSESMENTDATE + " = ? "
    + ", " + COLUMN_ONETIMECOST + " = ? "
    + ", " + COLUMN_MONTHLYCOST + " = ? "
    + ", " + COLUMN_DATAISPUBLIC + " = ? "
    + ", " + COLUMN_ISOUTSOURCEPROVIDER + " = ? "
    + ", " + COLUMN_OSPSERVICENAME + " = ? "
    + ", " + COLUMN_ACCESSCITIDATA + " = ? "
    + ", " + COLUMN_ACCESSCUSTOMERDATA + " = ? "
    + ", " + COLUMN_CONTRACTRENEWALDATE + " = ? "
    + ", " + COLUMN_DELETED + " = ? "
    + ", " + COLUMN_REQUESTDATE + " = ? "
  //  + ", " + COLUMN_ENTINSTANCEID + " = ? "
    + ", " + COLUMN_RELATIONSHIPTYPE + " = ? "
    + ", " + COLUMN_LOOKUP_ID + " = ? "
    //+ ", " + COLUMN_BUSINESSUNIT_ID + " = ? "
    + ", " + COLUMN_THIRDPARTY_ID + " = ? "
    + ", " + COLUMN_OWNEDBY_ID + " = ? "
    + ", " + COLUMN_TARGETRESOURCETYPE_ID + " = ? "
    + ", " + COLUMN_REQUESTERRESOURCETYPE_ID + " = ? "
    + ", " + COLUMN_UTURNTHIRDPARTY_ID + " = ? "
    + " WHERE " + COLUMN_ID + " = ?";

    /** The INSER t_ stmt. */
    private static String INSERT_STMT = "INSERT INTO " + RelationshipDAO.TABLE
    + "(" + COLUMN_ID
    + ", " + COLUMN_NAME 
    + ", " + COLUMN_PURPOSE 
    + ", " + COLUMN_CONNECTIVITYEXISTS 
    + ", " + COLUMN_READYDATE 
    + ", " + COLUMN_TERMINATEDDATE 
    + ", " + COLUMN_STATUS 
    + ", " + COLUMN_REQUESTERID 
    + ", " + COLUMN_BENEFIT 
    + ", " + COLUMN_PLCODE 
    + ", " + COLUMN_ESTIMATEDREVENUEGENERATED 
    + ", " + COLUMN_ESTIMATEDCOSTSAVING 
    + ", " + COLUMN_COBREDUNDANCYREQUIRED 
    + ", " + COLUMN_PROCUREMENTCOMPLETIONDATE 
    + ", " + COLUMN_GNCCAPPROVALATTAINED 
    + ", " + COLUMN_COMMENTS 
    + ", " + COLUMN_INITIALRISKASSESMENTDATE 
    + ", " + COLUMN_ONETIMECOST 
    + ", " + COLUMN_MONTHLYCOST 
    + ", " + COLUMN_DATAISPUBLIC 
    + ", " + COLUMN_ISOUTSOURCEPROVIDER 
    + ", " + COLUMN_OSPSERVICENAME 
    + ", " + COLUMN_ACCESSCITIDATA 
    + ", " + COLUMN_ACCESSCUSTOMERDATA 
    + ", " + COLUMN_CONTRACTRENEWALDATE 
    + ", " + COLUMN_DELETED 
    + ", " + COLUMN_REQUESTDATE 
    //+ ", " + COLUMN_ENTINSTANCEID 
    + ", " + COLUMN_RELATIONSHIPTYPE 
    + ", " + COLUMN_LOOKUP_ID
    //+ ", " + COLUMN_BUSINESSUNIT_ID
    + ", " + COLUMN_THIRDPARTY_ID
    + ", " + COLUMN_OWNEDBY_ID
    + ", " + COLUMN_TARGETRESOURCETYPE_ID
    + ", " + COLUMN_REQUESTERRESOURCETYPE_ID
    + ", " + COLUMN_UTURNTHIRDPARTY_ID
    + ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    /** The DELET e_ stmt. */
    private static String DELETE_STMT = "DELETE FROM " + RelationshipDAO.TABLE + " WHERE ID = ?";

    /** The Constant SELECT_THIRDPARTYCONTACT_REFERENCE_IDS_STMT. */
    private static final String SELECT_THIRDPARTYCONTACT_REFERENCE_IDS_STMT = "SELECT " + RelationshipTPContactXrefDAO.COLUMN_ID + " FROM " + RelationshipTPContactXrefDAO.TABLE + " WHERE " + RelationshipTPContactXrefDAO.COLUMN_RELATIONSHIP_ID + " = ?";

    /** The Constant SELECT_CITICONTACT_REFERENCE_IDS_STMT. */
    private static final String SELECT_CITICONTACT_REFERENCE_IDS_STMT = "SELECT " + RelationshipCitiContactXrefDAO.COLUMN_ID + " FROM " + RelationshipCitiContactXrefDAO.TABLE + " WHERE " + RelationshipCitiContactXrefDAO.COLUMN_RELATIONSHIP_ID + " = ?";

    /** The Constant SELECT_RESOURCE_REFERENCE_IDS_STMT. */
    private static final String SELECT_RESOURCE_REFERENCE_IDS_STMT = "SELECT " + RelationshipCitiResourceXrefDAO.COLUMN_ID + " FROM " + RelationshipCitiResourceXrefDAO.TABLE + " WHERE " + RelationshipCitiResourceXrefDAO.COLUMN_RELATIONSHIP_ID + " = ?";

    /** The Constant SELECT_PROJECTJUSTIFICATION_REFERENCE_IDS_STMT. */
    private static final String SELECT_PROJECTJUSTIFICATION_REFERENCE_IDS_STMT = "SELECT " + RelationshipProjectJustificationXrefDAO.COLUMN_ID + " FROM " + RelationshipProjectJustificationXrefDAO.TABLE + " WHERE " + RelationshipProjectJustificationXrefDAO.COLUMN_RELATIONSHIP_ID + " = ?";

    /** The Constant SELECT_FACILITIESAFFECTED_REFERENCE_IDS_STMT. */
    private static final String SELECT_FACILITIESAFFECTED_REFERENCE_IDS_STMT = "SELECT " + RelationshipFacilitiesAffectedXrefDAO.COLUMN_ID + " FROM " + RelationshipFacilitiesAffectedXrefDAO.TABLE + " WHERE " + RelationshipFacilitiesAffectedXrefDAO.COLUMN_RELATIONSHIP_ID + " = ?";

    /** The Constant SELECT_SERVICE_REFERENCE_IDS_STMT. */
    private static final String SELECT_SERVICE_REFERENCE_IDS_STMT = "SELECT " + RelationshipTPServiceXrefDAO.COLUMN_ID + " FROM " + RelationshipTPServiceXrefDAO.TABLE + " WHERE " + RelationshipTPServiceXrefDAO.COLUMN_RELATIONSHIP_ID + " = ?";

    /** The Constant SELECT_CITILOCATION_REFERENCE_IDS_STMT. */
    private static final String SELECT_CITILOCATION_REFERENCE_IDS_STMT = "SELECT " + RelationshipCitiLocationXrefDAO.COLUMN_ID + " FROM " + RelationshipCitiLocationXrefDAO.TABLE + " WHERE " + RelationshipCitiLocationXrefDAO.COLUMN_RELATIONSHIP_ID + " = ?";

    /** The Constant SELECT_THIRDPARTYLOCATION_REFERENCE_IDS_STMT. */
    private static final String SELECT_THIRDPARTYLOCATION_REFERENCE_IDS_STMT = "SELECT " + RelationshipTPLocationXrefDAO.COLUMN_ID + " FROM " + RelationshipTPLocationXrefDAO.TABLE + " WHERE " + RelationshipTPLocationXrefDAO.COLUMN_RELATIONSHIP_ID + " = ?";

    /** The Constant SELECT_CONNECTIONS_REFERENCE_IDS_STMT. */
    private static final String SELECT_CONNECTIONS_REFERENCE_IDS_STMT = "SELECT " + ConnectionDAO.COLUMN_ID + " FROM " + ConnectionDAO.TABLE + " WHERE " + ConnectionDAO.COLUMN_RELATIONSHIP_ID + " = ?";

    /** The Constant UPDATE_CONNECTIONS_REFERENCE_IDS_STMT. */
    private static final String UPDATE_CONNECTIONS_REFERENCE_IDS_STMT = "UPDATE " + ConnectionDAO.TABLE + " SET " + ConnectionDAO.COLUMN_RELATIONSHIP_ID + " = ? WHERE " + ConnectionDAO.COLUMN_RELATIONSHIP_ID + " = ?";

    /** The Constant SELECT_CITIREQCONTACT_REFERENCE_IDS_STMT. */
    private static final String SELECT_CITIREQCONTACT_REFERENCE_IDS_STMT = "SELECT " + RelationshipRequesterCitiContactXrefDAO.COLUMN_ID + " FROM " + RelationshipRequesterCitiContactXrefDAO.TABLE + " WHERE " + RelationshipRequesterCitiContactXrefDAO.COLUMN_RELATIONSHIP_ID + " = ?";

    /** The Constant SELECT_REQCITILOCATION_REFERENCE_IDS_STMT. */
    private static final String SELECT_REQCITILOCATION_REFERENCE_IDS_STMT = "SELECT " + RelationshipRequesterCitiLocationXrefDAO.COLUMN_ID + " FROM " + RelationshipRequesterCitiLocationXrefDAO.TABLE + " WHERE " + RelationshipRequesterCitiLocationXrefDAO.COLUMN_RELATIONSHIP_ID + " = ?";
    
    private static final String SELECT_REL_CITI_HIER_XREF_IDS_STMT = "SELECT " + RelCitiHierXrefDAO.COLUMN_ID + " FROM " + RelCitiHierXrefDAO.TABLE + " WHERE " + RelCitiHierXrefDAO.COLUMN_RELATIONSHIP_ID + " = ?";


    //======================================================================
    /**
     * Simple factory method.
     *
     * @param session the session
     * @return the relationship dao
     */
    public static RelationshipDAO createInstance(DatabaseSession session)
    {
	return new RelationshipDAO(session);
    }

    // Contructors
    //======================================================================
    /**
     * Instantiates a new relationship dao.
     *
     * @param session the session
     */
    public RelationshipDAO(DatabaseSession session)
    {
	super(session);
	log.debug("Creating RelationshipDAO (" + s_CreateCount + ")");
    }

    //Sequence Generator
    /**
     * Sets the custom sequence.
     *
     * @param customSequence the new custom sequence
     */
    public void setCustomSequence(String customSequence){

	this.customSequence=customSequence;
    }

    //Sequence Generator
    /**
     * Sets the database sequence.
     *
     * @param databaseSequence the new database sequence
     */
    public void setDatabaseSequence(String databaseSequence){

	this.databaseSequence=databaseSequence;
    }


    // Insert
    //======================================================================
    /**
     * Insert an entity into the database.
     *
     * @param entity The RelationshipEntity to insert
     * @return The id that was assigned to the entity
     * @throws DatabaseException the database exception
     */
    public Long insert(RelationshipEntity entity) throws DatabaseException
    {
	return insert(entity, null, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long insert(RelationshipEntity entity, boolean reset) throws DatabaseException
    {
	return insert(entity, null, reset);
    }

    //======================================================================
    /**
     * Insert an entity into the database.
     *
     * @param entity The RelationshipEntity to insert
     * @param archiver The archiver object used for tracking changes to the entity
     * @return The id that was assigned to the entity
     * @throws DatabaseException the database exception
     */
    public Long insert(RelationshipEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	return insert(entity, archiver, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param archiver the archiver
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long insert(RelationshipEntity entity, AuditArchiver archiver, boolean reset) throws DatabaseException
    {
	log.debug("Inserting RelationshipEntity");
	DatabaseSession session = getSession();

	if(primaryKeyExists(entity, false, session))
	    throw new DatabaseException("Could not insert '" + RelationshipDAO.ENTITY_NAME + "' with id = " + entity.getId() + " due to unique key constraint violation", null);

	Connection connection = null;

	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
		//Added for the Task 43686 - Adding Oracle SQL Sequences in place of KeyGenerator By NE36745 - Starts
		customSequence = null;
		
		databaseSequence = "SEQ_RELATIONSHIP";
		//Added for the Task 43686 - Adding Oracle SQL Sequences in place of KeyGenerator By NE36745 - Ends
		
	    connection = session.getConnection();
	    // Update FOREIGN_KEY references for which we are the OWNER
	    beforeUpdateLookupReferences((RelationshipEntity) entity);
	    beforeUpdateOwnedbyReferences((RelationshipEntity) entity);

	    // Generate a new id
	    long id=-1;
	    if(customSequence !=null)
		id = KeyGenerator.getInstance().getNextKey(session, customSequence);
	    else if(databaseSequence != null){
		try{
		    st=connection.prepareStatement("Select "+databaseSequence+".nextval from dual");
		    rs = st.executeQuery();
		    if (rs.next())
		    {
			id=rs.getLong(1);
		    }
		}finally{
		    try{
			if(rs!=null)rs.close();
			if(st!=null)st.close();
		    }catch(Exception xe){}

		}
	    }
	    else
		id = KeyGenerator.getInstance().getNextKey(session, RelationshipDAO.ENTITY_NAME);
	    entity.setId(Long.valueOf(id));
	    int position = 1;
	    st = connection.prepareStatement(INSERT_STMT);
	    setLongToStatement(st, position++, entity.getId());

	    // Attributes
	    position = setStringToStatement(st, position, entity.getName(), COLUMN_NAME_LEN);
	    position = setStringToStatement(st, position, entity.getPurpose(), COLUMN_PURPOSE_LEN);
	    position = setStringToStatement(st, position, entity.getConnectivityExists(), COLUMN_CONNECTIVITYEXISTS_LEN);
	    position = setDateToStatement(st, position, entity.getReadyDate());
	    position = setDateToStatement(st, position, entity.getTerminatedDate());
	    position = setStringToStatement(st, position, entity.getStatus(), COLUMN_STATUS_LEN);
	    position = setStringToStatement(st, position, entity.getRequesterId(), COLUMN_REQUESTERID_LEN);
	    position = setStringToStatement(st, position, entity.getBenefit(), COLUMN_BENEFIT_LEN);
	    position = setStringToStatement(st, position, entity.getPlcode(), COLUMN_PLCODE_LEN);
	    position = setDoubleToStatement(st, position, entity.getEstimatedRevenueGenerated());
	    position = setDoubleToStatement(st, position, entity.getEstimatedCostSaving());
	    position = setBooleanToStatement(st, position, entity.getCobRedundancyRequired());
	    position = setDateToStatement(st, position, entity.getProcurementCompletionDate());
	    position = setBooleanToStatement(st, position, entity.getGnccApprovalAttained());
	    position = setStringToStatement(st, position, entity.getComments(), COLUMN_COMMENTS_LEN);
	    position = setDateToStatement(st, position, entity.getInitialRiskAssesmentDate());
	    position = setDoubleToStatement(st, position, entity.getOneTimeCost());
	    position = setDoubleToStatement(st, position, entity.getMonthlyCost());
	    position = setBooleanToStatement(st, position, entity.getDataIsPublic());
	    position = setStringToStatement(st, position, entity.getIsOutsourceProvider(), COLUMN_ISOUTSOURCEPROVIDER_LEN);
	    position = setStringToStatement(st, position, entity.getOspServiceName(), COLUMN_OSPSERVICENAME_LEN);
	    position = setStringToStatement(st, position, entity.getAccessCitiData(), COLUMN_ACCESSCITIDATA_LEN);
	    position = setStringToStatement(st, position, entity.getAccessCustomerData(), COLUMN_ACCESSCUSTOMERDATA_LEN);
	    position = setDateToStatement(st, position, entity.getContractRenewalDate());
	    position = setBooleanToStatement(st, position, entity.getDeleted());
	    position = setDateToStatement(st, position, entity.getRequestDate());
	    //position = setLongToStatement(st, position, entity.getEntInstanceId());
	    position = setStringToStatement(st, position, entity.getRelationshipType(), COLUMN_RELATIONSHIPTYPE_LEN);

	    // Association references
	    position = updateReferences(st, entity, position);

	    st.executeUpdate();
	    entity.setPrimaryKey(Long.valueOf(id));

	    // Update FOREIGN_KEY references for which we are the OWNER
	    afterUpdateLookupReferences((RelationshipEntity) entity);
	    updateThirdPartyContactReferences((RelationshipEntity) entity);
	    updateCitiContactReferences((RelationshipEntity) entity);
	    updateResourceReferences((RelationshipEntity) entity);
	    updateProjectJustificationReferences((RelationshipEntity) entity);
	    updateFacilitiesAffectedReferences((RelationshipEntity) entity);
	    updateServiceReferences((RelationshipEntity) entity);
	    updateCitiLocationReferences((RelationshipEntity) entity);
	    updateThirdPartyLocationReferences((RelationshipEntity) entity);
	    afterUpdateOwnedbyReferences((RelationshipEntity) entity);
	    updateCitiReqContactReferences((RelationshipEntity) entity);
	    updateReqCitiLocationReferences((RelationshipEntity) entity);
	    if (archiver != null)
	    {
		archiver.storeSnapshotAuditLogForEntity(entity, "create");
	    }
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not insert '" + RelationshipDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return entity.getPrimaryKey();
    }

    //======================================================================
    /**
     * Update the state of an entity. If the entity doesn't exist in the database it gets automatically added.
     *
     * @param entity The RelationshipEntity to update.
     * @return The Id of the entity. If the entity had to be inserted this is the id assigned to it.
     * @throws DatabaseException the database exception
     */
    public Long update(RelationshipEntity entity) throws DatabaseException
    {
	return update(entity, null, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(RelationshipEntity entity, boolean reset) throws DatabaseException
    {
	return update(entity, null, reset);
    }

    //======================================================================
    /**
     * Update the state of an entity. If the entity doesn't exist in the database it gets automatically added.
     *
     * @param entity The RelationshipEntity to update
     * @param archiver The archiver object used for tracking changes to the entity
     * @return The Id of the entity. If the entity had to be inserted this is the id assigned to it.
     * @throws DatabaseException the database exception
     */
    public Long update(RelationshipEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	return update(entity, archiver, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param archiver the archiver
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(RelationshipEntity entity, AuditArchiver archiver, boolean reset) throws DatabaseException
    {
	if (entity.getPrimaryKey() == null)
	{
	    // Not created yet
	    return insert(entity, archiver, reset);
	}
	if (!entity.isModified())
	{
	    return entity.getPrimaryKey();
	}
	log.debug("Updating RelationshipEntity [" + entity.getId() + "]");
	DatabaseSession session = getSession();

	if(primaryKeyExists(entity, true, session))
	    throw new DatabaseException("Could not update '" + RelationshipDAO.ENTITY_NAME + "' with id = " + entity.getId() + " due to unique key constraint violation", null);

	Connection		connection = null;
	PreparedStatement st = null;
	ResultSet 		rs = null;

	try
	{
	    connection = session.getConnection();
	    // Update FOREIGN_KEY references for which we are the OWNER
	    beforeUpdateLookupReferences((RelationshipEntity) entity);
	    beforeUpdateOwnedbyReferences((RelationshipEntity) entity);

	    int position = 1;
	    st = connection.prepareStatement(UPDATE_BY_ID_STMT);

	    // Attributes
	    position = setStringToStatement(st, position, entity.getName(), COLUMN_NAME_LEN);
	    position = setStringToStatement(st, position, entity.getPurpose(), COLUMN_PURPOSE_LEN);
	    position = setStringToStatement(st, position, entity.getConnectivityExists(), COLUMN_CONNECTIVITYEXISTS_LEN);
	    position = setDateToStatement(st, position, entity.getReadyDate());
	    position = setDateToStatement(st, position, entity.getTerminatedDate());
	    position = setStringToStatement(st, position, entity.getStatus(), COLUMN_STATUS_LEN);
	    position = setStringToStatement(st, position, entity.getRequesterId(), COLUMN_REQUESTERID_LEN);
	    position = setStringToStatement(st, position, entity.getBenefit(), COLUMN_BENEFIT_LEN);
	    position = setStringToStatement(st, position, entity.getPlcode(), COLUMN_PLCODE_LEN);
	    position = setDoubleToStatement(st, position, entity.getEstimatedRevenueGenerated());
	    position = setDoubleToStatement(st, position, entity.getEstimatedCostSaving());
	    position = setBooleanToStatement(st, position, entity.getCobRedundancyRequired());
	    position = setDateToStatement(st, position, entity.getProcurementCompletionDate());
	    position = setBooleanToStatement(st, position, entity.getGnccApprovalAttained());
	    position = setStringToStatement(st, position, entity.getComments(), COLUMN_COMMENTS_LEN);
	    position = setDateToStatement(st, position, entity.getInitialRiskAssesmentDate());
	    position = setDoubleToStatement(st, position, entity.getOneTimeCost());
	    position = setDoubleToStatement(st, position, entity.getMonthlyCost());
	    position = setBooleanToStatement(st, position, entity.getDataIsPublic());
	    position = setStringToStatement(st, position, entity.getIsOutsourceProvider(), COLUMN_ISOUTSOURCEPROVIDER_LEN);
	    position = setStringToStatement(st, position, entity.getOspServiceName(), COLUMN_OSPSERVICENAME_LEN);
	    position = setStringToStatement(st, position, entity.getAccessCitiData(), COLUMN_ACCESSCITIDATA_LEN);
	    position = setStringToStatement(st, position, entity.getAccessCustomerData(), COLUMN_ACCESSCUSTOMERDATA_LEN);
	    position = setDateToStatement(st, position, entity.getContractRenewalDate());
	    position = setBooleanToStatement(st, position, entity.getDeleted());
	    position = setDateToStatement(st, position, entity.getRequestDate());
	    //position = setLongToStatement(st, position, entity.getEntInstanceId());
	    position = setStringToStatement(st, position, entity.getRelationshipType(), COLUMN_RELATIONSHIPTYPE_LEN);

	    // Association references
	    position = updateReferences(st, entity, position);

	    // where
	    setLongToStatement(st, position++, entity.getPrimaryKey());

	    st.executeUpdate();

	    // Update FOREIGN_KEY references for which we are the OWNER
	    afterUpdateLookupReferences((RelationshipEntity) entity);
	    updateThirdPartyContactReferences((RelationshipEntity) entity);
	    updateCitiContactReferences((RelationshipEntity) entity);
	    updateResourceReferences((RelationshipEntity) entity);
	    updateProjectJustificationReferences((RelationshipEntity) entity);
	    updateFacilitiesAffectedReferences((RelationshipEntity) entity);
	    updateServiceReferences((RelationshipEntity) entity);
	    updateCitiLocationReferences((RelationshipEntity) entity);
	    updateThirdPartyLocationReferences((RelationshipEntity) entity);
	    afterUpdateOwnedbyReferences((RelationshipEntity) entity);
	    updateCitiReqContactReferences((RelationshipEntity) entity);
	    updateReqCitiLocationReferences((RelationshipEntity) entity);
	    if (archiver != null)
	    {
		archiver.storeAuditLogForEntity(entity, "update");
	    }
	    if (reset)
	    {
		session.addToResetList(entity);
	    }
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not update '" + RelationshipDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return entity.getPrimaryKey();
    }

    //======================================================================
    /**
     * Get the entity determined by the id. This method automatically loads all references maintained by the entity.
     *
     * @param id A Long identifying the entity to get.
     * @return The entity or null if no entity with that id exists.
     * @throws DatabaseException the database exception
     */
    public RelationshipEntity get(Long id) throws DatabaseException
    {
	return get(id, true);
    }

    //======================================================================
    /**
     * Get the entity determined by the id.
     *
     * @param id A Long identifying the entity to get.
     * @param load_refs A boolean that determines wether to load all the entities references. True to load, false to defer loading until later.
     * @return The entity or null if no entity with that id exists.
     * @throws DatabaseException the database exception
     */
    public RelationshipEntity get(Long id, boolean load_refs) throws DatabaseException
    {
	Long id_to_get = id;
	RelationshipEntity obj = (RelationshipEntity) getSession().getObjectFromSession(ENTITY_NAME, id_to_get);
	log.debug("Getting RelationshipEntity with id = " + id_to_get); 
	if(obj != null)
	{
	    log.debug(">>> RelationshipEntity >>> already LOADED !!!"); 
	}

	if(obj == null)
	{
	    DatabaseSession session = getSession();
	    Connection connection = null;

	    PreparedStatement st = null;
	    ResultSet rs = null;

	    try
	    {
		connection = session.getConnection();
		//				st = session.getPreparedStatement(SELECT_BY_ID_STMT);
		st = connection.prepareStatement(SELECT_BY_ID_STMT);
		setLongToStatement(st, 1, id_to_get);
		rs = st.executeQuery();

		if (rs.next())
		{
		    obj = (RelationshipEntity) createEntity(rs);
		}
	    }
	    catch (SQLException e)
	    {
	    	log.error(e,e);
		throw new DatabaseException("Could not load " + RelationshipDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	}

	if (obj != null && load_refs)
	{
	    try
	    {
		// Load the associated objects
		loadReferences(obj);
		obj.setModified(false);
	    }
	    catch (DatabaseException e)
	    {
	    	log.error(e,e);
		throw new DatabaseException("Failed to load references of " + RelationshipDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	}
	log.debug("DONE Getting RelationshipEntity with id = " + id_to_get); 

	return obj;
    }


    //======================================================================
    /**
     * Retrieve the entities indicated by the list argument provided.
     *
     * @param id_list list of entity ids to load
     * @param load_refs Flag that determines wether the references should be loaded as part of the operation
     * @return A List of all the entities loaded.
     * @throws DatabaseException the database exception
     */
    public List get(List id_list, boolean load_refs) throws DatabaseException
    {
	List 	entity_list = new ArrayList(16);
	if(id_list != null && id_list.size() > 0)
	{
	    DatabaseSession 	session = getSession();
	    Connection 			connection = null;
	    Statement 			st = null;
	    ResultSet 			rs = null;
	    RelationshipEntity 		entity = null;

	    try
	    {
		StringBuffer statement = new StringBuffer(SELECT_STMT + " WHERE " + COLUMN_ID + " IN (");

		Long only = null;
		long count = 0;
		Iterator iter = id_list.iterator();
		while(iter.hasNext())
		{
		    Long id = (Long)iter.next();
		    entity = (RelationshipEntity) getSession().getObjectFromSession(ENTITY_NAME, id);
		    if(entity != null)
		    {
			if(load_refs)
			{
			    loadReferences(entity);
			}
			entity_list.add(entity);
		    }
		    else // add the the id to the statement
		    {
			if(count++ > 0)
			{
			    statement.append(",");					
			}
			statement.append(id.toString());					
			only = id;
		    }
		}

		// check if we need to explicitly load any entities
		if(count == 1)
		{
		    entity_list.add(get(only, load_refs));					
		}
		else if(count > 1)
		{
		    statement.append(")");	// Close the statenemt's IN clause					
		    log.debug("DAO.get(List): executing statement. Count = (" + count + ") --> " + statement.toString());
		    connection = session.getConnection();
		    //					st = connection.prepareStatement(statement.toString());
		    //					rs = st.executeQuery();
		    st = connection.createStatement();
		    rs = st.executeQuery(statement.toString());

		    while(rs.next())
		    {
			entity = (RelationshipEntity) createEntity(rs);
			if(load_refs)
			{
			    loadReferences(entity);
			    entity.setModified(false);
			}
			entity_list.add(entity);					
		    }
		}
	    }
	    catch(SQLException e)
	    {
		throw new DatabaseException("Failed to load all entities of type " + RelationshipDAO.ENTITY_NAME + ".", e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		if(connection != null)
		{
		    session.releaseConnection();
		}
	    }
	}

	return entity_list;	
    }

    //======================================================================
    /**
     * Retrieve all entities.
     *
     * @param load_refs Flag that determines wether the references should be loaded as part of the operation
     * @return The list of all entities of type RelationshipEntity
     * @throws DatabaseException the database exception
     */
    public List getAll(boolean load_refs) throws DatabaseException
    {
	List 				entity_list = query(new Condition(), load_refs);
	/*
		DatabaseSession 	session = getSession();
		Connection 			connection = null;
		Statement 	st = null;
		ResultSet 			rs = null;
		RelationshipEntity 		entity = null;

		try
		{
			String select_stmt = "SELECT * FROM RELATIONSHIP";
			connection = session.getConnection();

			st = connection.createStatement();
			rs = st.executeQuery(select_stmt.toString());

			while(rs.next())
			{
				entity = (RelationshipEntity) createEntity(rs);
				if(load_refs)
				{
					loadReferences(entity);
					entity.setModified(false);
				}
				entity_list.add(entity);					
			}
		}
		catch(SQLException e)
		{
			throw new DatabaseException("Failed to load all entities of type " + RelationshipDAO.ENTITY_NAME + ".", e);
		}
		finally
		{
			closeResultSet(rs);
			closeStatement(st);
			session.releaseConnection();
		}
	 */
	return entity_list;	
    }	

    //======================================================================
    /**
     * Retrieve the IDs of all entities.
     *
     * @return A list of IDs of all the entities of type RelationshipEntity
     * @throws DatabaseException the database exception
     */
    public List getAllIds() throws DatabaseException
    {
	return queryForId(new Condition());
    }

    //======================================================================
    /**
     * Checks wether the entity with the given ID already exists in the database.
     *
     * @param id The id of the entity to test.
     * @return A boolean that indicates exsitence (true) or lack thereof (false)
     * @throws DatabaseException the database exception
     */
    public boolean exists(String id) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;

	PreparedStatement st = null;
	ResultSet rs = null;
	boolean exists = false;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_BY_ID_STMT);
	    st.setString(1, id);
	    rs = st.executeQuery();
	    exists = rs.next();
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not verify existence of '" + RelationshipDAO.ENTITY_NAME + "' with id = "
		    + id, e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return exists;
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param id The id of the entity to be deleted from the database.
     * @throws DatabaseException the database exception
     */
    public void delete(Long id) throws DatabaseException
    {
	if(id != null)
	{
	    RelationshipEntity entity = get(id, false);
	    delete(entity, null);
	}
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param id The id of the entity to be deleted from the database.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(Long id, AuditArchiver archiver) throws DatabaseException
    {
	if(id != null)
	{
	    RelationshipEntity entity = get(id, false);
	    delete(entity, archiver);
	}
    }

    //======================================================================
    /**
     * Delete a list of entities from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity_ids A list of Long objects providing the ids of the entities to be deleted.
     * @throws DatabaseException the database exception
     */
    public void delete(List entity_ids) throws DatabaseException
    {
	delete(entity_ids, null);
    }

    //======================================================================
    /**
     * Delete a list of entities from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity_ids A list of Long objects providing the ids of the entities to be deleted.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(List entity_ids, AuditArchiver archiver) throws DatabaseException
    {
	if(entity_ids != null)
	{
	    Iterator iter = entity_ids.iterator();
	    while(iter.hasNext())
	    {
		Long id = (Long)iter.next();		
		delete(id, archiver);
	    }
	}
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity The entity to be deleted from the database.
     * @throws DatabaseException the database exception
     */
    public void delete(RelationshipEntity entity) throws DatabaseException
    {
	delete(entity, null);
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity The entity to be deleted from the database.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(RelationshipEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	if(entity != null && entity.getId() != null)
	{
	    DatabaseSession session = getSession();
	    Connection connection = null;

	    if (archiver != null)
	    {
		archiver.storeSnapshotAuditLogForEntity(entity, "delete");
	    }


	    // Clear all associations and remove all compositions
	    deleteManyAssociations(entity);

	    // Delete ourself
	    PreparedStatement st = null;
	    ResultSet rs = null;

	    try
	    {
		connection = session.getConnection();
		// Generate a new id
		int position = 1;
		st = connection.prepareStatement(DELETE_STMT);
		position = setLongToStatement(st, position, entity.getPrimaryKey());

		st.execute();

		// COMPOSITION Delete ONE objects...
		if(entity.getOriginalLookupId() != null)
		{
		    CommonLookupDataDAO lookupDAO = getLookupDAO();
		    if(entity.getOriginalLookup() != null)
		    {
			lookupDAO.delete(entity.getOriginalLookup());
		    }
		    else
		    {
			lookupDAO.delete(entity.getOriginalLookupId());
		    }
		}
		if(entity.getOriginalOwnedbyId() != null)
		{
		    EntitlementXrefDAO ownedbyDAO = getOwnedbyDAO();
		    if(entity.getOriginalOwnedby() != null)
		    {
			ownedbyDAO.delete(entity.getOriginalOwnedby());
		    }
		    else
		    {
			ownedbyDAO.delete(entity.getOriginalOwnedbyId());
		    }
		}

		entity.setPrimaryKey(null);
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not delete '" + RelationshipDAO.ENTITY_NAME + "' with id = "
			+ entity.getId(), e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	}
    }

    //======================================================================
    /**
     * Delete many associations.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void deleteManyAssociations(RelationshipEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;

	try
	{
	    connection = session.getConnection();

	    // Go through the many association list and delete any entities that exist in it.
	    RelationshipTPContactXrefDAO thirdPartyContactDAO = getThirdPartyContactDAO();
	    List original_thirdPartyContact_ids = entity.getOriginalThirdPartyContactIds();
	    Iterator thirdPartyContactIt = entity.getThirdPartyContact().getDeletedList().iterator();
	    while (thirdPartyContactIt.hasNext())
	    {
		RelationshipTPContactXrefEntity o = (RelationshipTPContactXrefEntity)thirdPartyContactIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_thirdPartyContact_ids.remove(id);
		}
		thirdPartyContactDAO.delete(o);
	    }

	    thirdPartyContactIt = entity.getThirdPartyContact().iterator();
	    while (thirdPartyContactIt.hasNext())
	    {
		RelationshipTPContactXrefEntity o = (RelationshipTPContactXrefEntity)thirdPartyContactIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_thirdPartyContact_ids.remove(id);
		}
		thirdPartyContactDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    thirdPartyContactDAO.delete(original_thirdPartyContact_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    RelationshipCitiContactXrefDAO citiContactDAO = getCitiContactDAO();
	    List original_citiContact_ids = entity.getOriginalCitiContactIds();
	    Iterator citiContactIt = entity.getCitiContact().getDeletedList().iterator();
	    while (citiContactIt.hasNext())
	    {
		RelationshipCitiContactXrefEntity o = (RelationshipCitiContactXrefEntity)citiContactIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_citiContact_ids.remove(id);
		}
		citiContactDAO.delete(o);
	    }

	    citiContactIt = entity.getCitiContact().iterator();
	    while (citiContactIt.hasNext())
	    {
		RelationshipCitiContactXrefEntity o = (RelationshipCitiContactXrefEntity)citiContactIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_citiContact_ids.remove(id);
		}
		citiContactDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    citiContactDAO.delete(original_citiContact_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    RelationshipCitiResourceXrefDAO resourceDAO = getResourceDAO();
	    List original_resource_ids = entity.getOriginalResourceIds();
	    Iterator resourceIt = entity.getResource().getDeletedList().iterator();
	    while (resourceIt.hasNext())
	    {
		RelationshipCitiResourceXrefEntity o = (RelationshipCitiResourceXrefEntity)resourceIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_resource_ids.remove(id);
		}
		resourceDAO.delete(o);
	    }

	    resourceIt = entity.getResource().iterator();
	    while (resourceIt.hasNext())
	    {
		RelationshipCitiResourceXrefEntity o = (RelationshipCitiResourceXrefEntity)resourceIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_resource_ids.remove(id);
		}
		resourceDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    resourceDAO.delete(original_resource_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    RelationshipProjectJustificationXrefDAO projectJustificationDAO = getProjectJustificationDAO();
	    List original_projectJustification_ids = entity.getOriginalProjectJustificationIds();
	    Iterator projectJustificationIt = entity.getProjectJustification().getDeletedList().iterator();
	    while (projectJustificationIt.hasNext())
	    {
		RelationshipProjectJustificationXrefEntity o = (RelationshipProjectJustificationXrefEntity)projectJustificationIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_projectJustification_ids.remove(id);
		}
		projectJustificationDAO.delete(o);
	    }

	    projectJustificationIt = entity.getProjectJustification().iterator();
	    while (projectJustificationIt.hasNext())
	    {
		RelationshipProjectJustificationXrefEntity o = (RelationshipProjectJustificationXrefEntity)projectJustificationIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_projectJustification_ids.remove(id);
		}
		projectJustificationDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    projectJustificationDAO.delete(original_projectJustification_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    RelationshipFacilitiesAffectedXrefDAO facilitiesAffectedDAO = getFacilitiesAffectedDAO();
	    List original_facilitiesAffected_ids = entity.getOriginalFacilitiesAffectedIds();
	    Iterator facilitiesAffectedIt = entity.getFacilitiesAffected().getDeletedList().iterator();
	    while (facilitiesAffectedIt.hasNext())
	    {
		RelationshipFacilitiesAffectedXrefEntity o = (RelationshipFacilitiesAffectedXrefEntity)facilitiesAffectedIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_facilitiesAffected_ids.remove(id);
		}
		facilitiesAffectedDAO.delete(o);
	    }

	    facilitiesAffectedIt = entity.getFacilitiesAffected().iterator();
	    while (facilitiesAffectedIt.hasNext())
	    {
		RelationshipFacilitiesAffectedXrefEntity o = (RelationshipFacilitiesAffectedXrefEntity)facilitiesAffectedIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_facilitiesAffected_ids.remove(id);
		}
		facilitiesAffectedDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    facilitiesAffectedDAO.delete(original_facilitiesAffected_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    RelationshipTPServiceXrefDAO serviceDAO = getServiceDAO();
	    List original_service_ids = entity.getOriginalServiceIds();
	    Iterator serviceIt = entity.getService().getDeletedList().iterator();
	    while (serviceIt.hasNext())
	    {
		RelationshipTPServiceXrefEntity o = (RelationshipTPServiceXrefEntity)serviceIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_service_ids.remove(id);
		}
		serviceDAO.delete(o);
	    }

	    serviceIt = entity.getService().iterator();
	    while (serviceIt.hasNext())
	    {
		RelationshipTPServiceXrefEntity o = (RelationshipTPServiceXrefEntity)serviceIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_service_ids.remove(id);
		}
		serviceDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    serviceDAO.delete(original_service_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    RelationshipCitiLocationXrefDAO citiLocationDAO = getCitiLocationDAO();
	    List original_citiLocation_ids = entity.getOriginalCitiLocationIds();
	    Iterator citiLocationIt = entity.getCitiLocation().getDeletedList().iterator();
	    while (citiLocationIt.hasNext())
	    {
		RelationshipCitiLocationXrefEntity o = (RelationshipCitiLocationXrefEntity)citiLocationIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_citiLocation_ids.remove(id);
		}
		citiLocationDAO.delete(o);
	    }

	    citiLocationIt = entity.getCitiLocation().iterator();
	    while (citiLocationIt.hasNext())
	    {
		RelationshipCitiLocationXrefEntity o = (RelationshipCitiLocationXrefEntity)citiLocationIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_citiLocation_ids.remove(id);
		}
		citiLocationDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    citiLocationDAO.delete(original_citiLocation_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    RelationshipTPLocationXrefDAO thirdPartyLocationDAO = getThirdPartyLocationDAO();
	    List original_thirdPartyLocation_ids = entity.getOriginalThirdPartyLocationIds();
	    Iterator thirdPartyLocationIt = entity.getThirdPartyLocation().getDeletedList().iterator();
	    while (thirdPartyLocationIt.hasNext())
	    {
		RelationshipTPLocationXrefEntity o = (RelationshipTPLocationXrefEntity)thirdPartyLocationIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_thirdPartyLocation_ids.remove(id);
		}
		thirdPartyLocationDAO.delete(o);
	    }

	    thirdPartyLocationIt = entity.getThirdPartyLocation().iterator();
	    while (thirdPartyLocationIt.hasNext())
	    {
		RelationshipTPLocationXrefEntity o = (RelationshipTPLocationXrefEntity)thirdPartyLocationIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_thirdPartyLocation_ids.remove(id);
		}
		thirdPartyLocationDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    thirdPartyLocationDAO.delete(original_thirdPartyLocation_ids);

	    // reset the back references to us in the Connection
	    st = connection.prepareStatement(UPDATE_CONNECTIONS_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, null);
	    setLongToStatement(st, 2, entity.getPrimaryKey());
	    st.execute();
	    closeStatement(st);

	    // Go through the many association list and delete any entities that exist in it.
	    RelationshipRequesterCitiContactXrefDAO citiReqContactDAO = getCitiReqContactDAO();
	    List original_citiReqContact_ids = entity.getOriginalCitiReqContactIds();
	    Iterator citiReqContactIt = entity.getCitiReqContact().getDeletedList().iterator();
	    while (citiReqContactIt.hasNext())
	    {
		RelationshipRequesterCitiContactXrefEntity o = (RelationshipRequesterCitiContactXrefEntity)citiReqContactIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_citiReqContact_ids.remove(id);
		}
		citiReqContactDAO.delete(o);
	    }

	    citiReqContactIt = entity.getCitiReqContact().iterator();
	    while (citiReqContactIt.hasNext())
	    {
		RelationshipRequesterCitiContactXrefEntity o = (RelationshipRequesterCitiContactXrefEntity)citiReqContactIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_citiReqContact_ids.remove(id);
		}
		citiReqContactDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    citiReqContactDAO.delete(original_citiReqContact_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    RelationshipRequesterCitiLocationXrefDAO reqCitiLocationDAO = getReqCitiLocationDAO();
	    List original_reqCitiLocation_ids = entity.getOriginalReqCitiLocationIds();
	    Iterator reqCitiLocationIt = entity.getReqCitiLocation().getDeletedList().iterator();
	    while (reqCitiLocationIt.hasNext())
	    {
		RelationshipRequesterCitiLocationXrefEntity o = (RelationshipRequesterCitiLocationXrefEntity)reqCitiLocationIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_reqCitiLocation_ids.remove(id);
		}
		reqCitiLocationDAO.delete(o);
	    }

	    reqCitiLocationIt = entity.getReqCitiLocation().iterator();
	    while (reqCitiLocationIt.hasNext())
	    {
		RelationshipRequesterCitiLocationXrefEntity o = (RelationshipRequesterCitiLocationXrefEntity)reqCitiLocationIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_reqCitiLocation_ids.remove(id);
		}
		reqCitiLocationDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    reqCitiLocationDAO.delete(original_reqCitiLocation_ids);
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to perform association clean up during delete of'" + RelationshipDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    session.releaseConnection();
	}

    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#buildEntity(java.sql.ResultSet, com.mentisys.model.Entity)
     */
    protected void buildEntity(ResultSet rs, Entity obj) throws DatabaseException
    {
	RelationshipEntity entity = (RelationshipEntity) obj;
	try
	{
	    // TODO: Figure a better way of dealing with the absence of any attribute
	    dummyExceptionTosser(false);

	    int index = 1;

	    //			entity.setName(getStringFromResultSet(rs, COLUMN_NAME));
	    entity.setName(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalName(entity.getName());
	    //			entity.setPurpose(getStringFromResultSet(rs, COLUMN_PURPOSE));
	    entity.setPurpose(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalPurpose(entity.getPurpose());
	    //			entity.setConnectivityExists(getStringFromResultSet(rs, COLUMN_CONNECTIVITYEXISTS));
	    entity.setConnectivityExists(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalConnectivityExists(entity.getConnectivityExists());
	    //			entity.setReadyDate(getDateFromResultSet(rs, COLUMN_READYDATE));
	    entity.setReadyDate(getDateFromResultSetIndexed(rs, ++index));
	    entity.setOriginalReadyDate(entity.getReadyDate());
	    //			entity.setTerminatedDate(getDateFromResultSet(rs, COLUMN_TERMINATEDDATE));
	    entity.setTerminatedDate(getDateFromResultSetIndexed(rs, ++index));
	    entity.setOriginalTerminatedDate(entity.getTerminatedDate());
	    //			entity.setStatus(getStringFromResultSet(rs, COLUMN_STATUS));
	    entity.setStatus(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalStatus(entity.getStatus());
	    //			entity.setRelationshipId(getLongFromResultSet(rs, COLUMN_RELATIONSHIPID));
	    //			entity.setRequesterId(getStringFromResultSet(rs, COLUMN_REQUESTERID));
	    entity.setRequesterId(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalRequesterId(entity.getRequesterId());
	    //			entity.setBenefit(getStringFromResultSet(rs, COLUMN_BENEFIT));
	    entity.setBenefit(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalBenefit(entity.getBenefit());
	    //			entity.setPlcode(getStringFromResultSet(rs, COLUMN_PLCODE));
	    entity.setPlcode(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalPlcode(entity.getPlcode());
	    //			entity.setEstimatedRevenueGenerated(getDoubleFromResultSet(rs, COLUMN_ESTIMATEDREVENUEGENERATED));
	    entity.setEstimatedRevenueGenerated(getDoubleFromResultSetIndexed(rs, ++index));
	    entity.setOriginalEstimatedRevenueGenerated(entity.getEstimatedRevenueGenerated());
	    //			entity.setEstimatedCostSaving(getDoubleFromResultSet(rs, COLUMN_ESTIMATEDCOSTSAVING));
	    entity.setEstimatedCostSaving(getDoubleFromResultSetIndexed(rs, ++index));
	    entity.setOriginalEstimatedCostSaving(entity.getEstimatedCostSaving());
	    //			entity.setCobRedundancyRequired(getBooleanFromResultSet(rs, COLUMN_COBREDUNDANCYREQUIRED));
	    entity.setCobRedundancyRequired(getBooleanFromResultSetIndexed(rs, ++index));
	    entity.setOriginalCobRedundancyRequired(entity.getCobRedundancyRequired());
	    //			entity.setProcurementCompletionDate(getDateFromResultSet(rs, COLUMN_PROCUREMENTCOMPLETIONDATE));
	    entity.setProcurementCompletionDate(getDateFromResultSetIndexed(rs, ++index));
	    entity.setOriginalProcurementCompletionDate(entity.getProcurementCompletionDate());
	    //			entity.setGnccApprovalAttained(getBooleanFromResultSet(rs, COLUMN_GNCCAPPROVALATTAINED));
	    entity.setGnccApprovalAttained(getBooleanFromResultSetIndexed(rs, ++index));
	    entity.setOriginalGnccApprovalAttained(entity.getGnccApprovalAttained());
	    //			entity.setComments(getStringFromResultSet(rs, COLUMN_COMMENTS));
	    entity.setComments(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalComments(entity.getComments());
	    //			entity.setInitialRiskAssesmentDate(getDateFromResultSet(rs, COLUMN_INITIALRISKASSESMENTDATE));
	    entity.setInitialRiskAssesmentDate(getDateFromResultSetIndexed(rs, ++index));
	    entity.setOriginalInitialRiskAssesmentDate(entity.getInitialRiskAssesmentDate());
	    //			entity.setOneTimeCost(getDoubleFromResultSet(rs, COLUMN_ONETIMECOST));
	    entity.setOneTimeCost(getDoubleFromResultSetIndexed(rs, ++index));
	    entity.setOriginalOneTimeCost(entity.getOneTimeCost());
	    //			entity.setMonthlyCost(getDoubleFromResultSet(rs, COLUMN_MONTHLYCOST));
	    entity.setMonthlyCost(getDoubleFromResultSetIndexed(rs, ++index));
	    entity.setOriginalMonthlyCost(entity.getMonthlyCost());
	    //			entity.setDataIsPublic(getBooleanFromResultSet(rs, COLUMN_DATAISPUBLIC));
	    entity.setDataIsPublic(getBooleanFromResultSetIndexed(rs, ++index));
	    entity.setOriginalDataIsPublic(entity.getDataIsPublic());
	    //			entity.setIsOutsourceProvider(getStringFromResultSet(rs, COLUMN_ISOUTSOURCEPROVIDER));
	    entity.setIsOutsourceProvider(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalIsOutsourceProvider(entity.getIsOutsourceProvider());
	    //			entity.setOspServiceName(getStringFromResultSet(rs, COLUMN_OSPSERVICENAME));
	    entity.setOspServiceName(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalOspServiceName(entity.getOspServiceName());
	    //			entity.setAccessCitiData(getStringFromResultSet(rs, COLUMN_ACCESSCITIDATA));
	    entity.setAccessCitiData(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalAccessCitiData(entity.getAccessCitiData());
	    //			entity.setAccessCustomerData(getStringFromResultSet(rs, COLUMN_ACCESSCUSTOMERDATA));
	    entity.setAccessCustomerData(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalAccessCustomerData(entity.getAccessCustomerData());
	    //			entity.setContractRenewalDate(getDateFromResultSet(rs, COLUMN_CONTRACTRENEWALDATE));
	    entity.setContractRenewalDate(getDateFromResultSetIndexed(rs, ++index));
	    entity.setOriginalContractRenewalDate(entity.getContractRenewalDate());
	    //			entity.setDeleted(getBooleanFromResultSet(rs, COLUMN_DELETED));
	    entity.setDeleted(getBooleanFromResultSetIndexed(rs, ++index));
	    entity.setOriginalDeleted(entity.getDeleted());
	    //			entity.setRequestDate(getDateFromResultSet(rs, COLUMN_REQUESTDATE));
	    entity.setRequestDate(getDateFromResultSetIndexed(rs, ++index));
	    entity.setOriginalRequestDate(entity.getRequestDate());
	    //			entity.setEntInstanceId(getLongFromResultSet(rs, COLUMN_ENTINSTANCEID));
	   // entity.setEntInstanceId(getLongFromResultSetIndexed(rs, ++index));
	    //entity.setOriginalEntInstanceId(entity.getEntInstanceId());
	    //			entity.setRelationshipType(getStringFromResultSet(rs, COLUMN_RELATIONSHIPTYPE));
	    entity.setRelationshipType(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalRelationshipType(entity.getRelationshipType());

	    // Single References
	    //			entity.setLookupId(getLongFromResultSet(rs, COLUMN_LOOKUP_ID));
	    entity.setLookupId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalLookupId(entity.getLookupId());
	    //			entity.setBusinessUnitId(getLongFromResultSet(rs, COLUMN_BUSINESSUNIT_ID));
	   // entity.setBusinessUnitId(getLongFromResultSetIndexed(rs, ++index));
	    //entity.setOriginalBusinessUnitId(entity.getBusinessUnitId());
	    //			entity.setThirdPartyId(getLongFromResultSet(rs, COLUMN_THIRDPARTY_ID));
	    entity.setThirdPartyId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalThirdPartyId(entity.getThirdPartyId());
	    //			entity.setOwnedbyId(getLongFromResultSet(rs, COLUMN_OWNEDBY_ID));
	    entity.setOwnedbyId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalOwnedbyId(entity.getOwnedbyId());
	    //			entity.setTargetResourceTypeId(getLongFromResultSet(rs, COLUMN_TARGETRESOURCETYPE_ID));
	    entity.setTargetResourceTypeId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalTargetResourceTypeId(entity.getTargetResourceTypeId());
	    //			entity.setRequesterResourceTypeId(getLongFromResultSet(rs, COLUMN_REQUESTERRESOURCETYPE_ID));
	    entity.setRequesterResourceTypeId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalRequesterResourceTypeId(entity.getRequesterResourceTypeId());
	    //			entity.setUturnThirdPartyId(getLongFromResultSet(rs, COLUMN_UTURNTHIRDPARTY_ID));
	    entity.setUturnThirdPartyId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalUturnThirdPartyId(entity.getUturnThirdPartyId());

	    // Load multi reference Ids
	    loadReferenceIds(entity);

	    obj.setModified(false);
	}
	catch (DatabaseException e)
	{
	    throw new DatabaseException("Cannot build database entity object from result set", e);
	}
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#createEntity(java.sql.ResultSet)
     */
    protected Entity createEntity(ResultSet rs) throws DatabaseException
    {
	RelationshipEntity entity = null;
	try
	{
	    // get the ID of the entity we're to create, and check if that is already held in the session. Thereby allowing us to
	    // bypass the creation altogether and reuse the one in existence.			
	    Long _id = getLongFromResultSet(rs, COLUMN_ID);
	    entity = (RelationshipEntity) getSession().getObjectFromSession(ENTITY_NAME, _id);
	    if (entity == null)
	    {        
		entity = new RelationshipEntity(_id);
		buildEntity(rs, entity);
		getSession().addObjectToSession(entity, ENTITY_NAME, _id);
	    }
	}
	catch (DatabaseException e)
	{
	    throw new DatabaseException("Cannot create database entity object from result set", e);
	}
	return entity;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.AccessObject#getQuerySelectString()
     */
    protected String getQuerySelectString()
    {
	return SELECT_STMT;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#getQuerySelectIdString()
     */
    protected String getQuerySelectIdString()
    {
	return SELECT_ID_STMT;
    }

    //======================================================================
    /**
     * Load the IDs of the external references for the entity.
     *
     * @param obj The entity for which to load the IDs of its references
     * @throws DatabaseException the database exception
     */
    public void loadReferenceIds(Entity obj) throws DatabaseException
    {
	RelationshipEntity entity = (RelationshipEntity)obj;
	loadThirdPartyContactReferenceIds(entity);
	loadCitiContactReferenceIds(entity);
	loadResourceReferenceIds(entity);
	loadProjectJustificationReferenceIds(entity);
	loadFacilitiesAffectedReferenceIds(entity);
	loadServiceReferenceIds(entity);
	loadCitiLocationReferenceIds(entity);
	loadThirdPartyLocationReferenceIds(entity);
	loadConnectionsReferenceIds(entity);
	loadCitiReqContactReferenceIds(entity);
	loadReqCitiLocationReferenceIds(entity);
	loadRelHierXrefIds(entity);
    }

    //======================================================================
    /**
     * Load the external references for the entity.
     *
     * @param obj The entity for which to load its references
     * @throws DatabaseException the database exception
     */
    public void loadReferences(Entity obj) throws DatabaseException
    {
	if (obj.isReferencesLoaded())
	{
	    log.debug("ThirdPartyDAO.loadReferences(): References for RelationshipEntity [" + obj.getId() + "] already loaded");
	    return;
	}
	log.debug("ThirdPartyDAO.loadReferences(): Loading references for RelationshipEntity [" + obj.getId() + "].");
	obj.setReferencesLoaded(true);
	try
	{
	    RelationshipEntity entity = (RelationshipEntity)obj;

	    Long lookupId = entity.getLookupId();
	    if (lookupId != null)
	    {
		//			CommonLookupDataDAO lookupDAO = new CommonLookupDataDAO(getSession());
		CommonLookupDataDAO lookupDAO = getLookupDAO();
		entity.setLookup((CommonLookupDataEntity)lookupDAO.get(lookupId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalLookup(entity.getLookup());
		// Set the bi-directional reference to us
		if (entity.getLookup() != null)
		{
		    entity.getLookup().setOriginalRelationship(entity);
		    entity.getLookup().setRelationship(entity);
		}
	    }
	    
	    
	   loadThirdPartyContactReferences(entity);

	    loadCitiContactReferences(entity);

	    loadResourceReferences(entity);

	    loadProjectJustificationReferences(entity);

	    loadFacilitiesAffectedReferences(entity);

	    loadServiceReferences(entity);

	    /*Long businessUnitId = entity.getBusinessUnitId();
	    if (businessUnitId != null)
	    {
		//			BusinessUnitDAO businessUnitDAO = new BusinessUnitDAO(getSession());
		BusinessUnitDAO businessUnitDAO = getBusinessUnitDAO();
		entity.setBusinessUnit((BusinessUnitEntity)businessUnitDAO.get(businessUnitId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalBusinessUnit(entity.getBusinessUnit());
	    }
*/
	    loadCitiLocationReferences(entity);

	    Long thirdPartyId = entity.getThirdPartyId();
	    if (thirdPartyId != null)
	    {
		//			ThirdPartyDAO thirdPartyDAO = new ThirdPartyDAO(getSession());
		ThirdPartyDAO thirdPartyDAO = getThirdPartyDAO();
		entity.setThirdParty((ThirdPartyEntity)thirdPartyDAO.get(thirdPartyId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalThirdParty(entity.getThirdParty());
	    }

	    loadThirdPartyLocationReferences(entity);

	    Long ownedbyId = entity.getOwnedbyId();
	    if (ownedbyId != null)
	    {
		//			EntitlementXrefDAO ownedbyDAO = new EntitlementXrefDAO(getSession());
		EntitlementXrefDAO ownedbyDAO = getOwnedbyDAO();
		entity.setOwnedby((EntitlementXrefEntity)ownedbyDAO.get(ownedbyId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalOwnedby(entity.getOwnedby());
		// Set the bi-directional reference to us
		if (entity.getOwnedby() != null)
		{
		    entity.getOwnedby().setOriginalRelationship(entity);
		    entity.getOwnedby().setRelationship(entity);
		}
	    }
	    
	   // Commented for Slowness defect 39312- c3par very slow - 
	//    loadConnectionsReferences(entity);

	    Long targetResourceTypeId = entity.getTargetResourceTypeId();
	    if (targetResourceTypeId != null)
	    {
		// Use lookup for optimized access
		entity.setTargetResourceType(ResourceTypeLookup.getInstance().getById(getSession(), targetResourceTypeId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalTargetResourceType(entity.getTargetResourceType());
	    }

	    Long requesterResourceTypeId = entity.getRequesterResourceTypeId();
	    if (requesterResourceTypeId != null)
	    {
		// Use lookup for optimized access
		entity.setRequesterResourceType(ResourceTypeLookup.getInstance().getById(getSession(), requesterResourceTypeId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalRequesterResourceType(entity.getRequesterResourceType());
	    }

	    loadCitiReqContactReferences(entity);

	    loadReqCitiLocationReferences(entity);

	    Long uturnThirdPartyId = entity.getUturnThirdPartyId();
	    if (uturnThirdPartyId != null)
	    {
		//			ThirdPartyDAO uturnThirdPartyDAO = new ThirdPartyDAO(getSession());
		ThirdPartyDAO uturnThirdPartyDAO = getUturnThirdPartyDAO();
		entity.setUturnThirdParty((ThirdPartyEntity)uturnThirdPartyDAO.get(uturnThirdPartyId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalUturnThirdParty(entity.getUturnThirdParty());
	    }
	    
	    loadRelCitiHierXrefReferences(entity);

	}
	catch(Exception e)
	{
		log.error(e,e);
	    obj.setReferencesLoaded(false);
	    throw new DatabaseException("Failed to load references for RelationshipEntity [" + obj.getId() + "].", e);
	}
    }

    //======================================================================
    /**
     * Load lookup with id.
     *
     * @param id the id
     * @return the common lookup data entity
     * @throws DatabaseException the database exception
     */
    public CommonLookupDataEntity loadLookupWithId(Long id) throws DatabaseException
    {
	CommonLookupDataEntity entity = null;
	if (id != null)
	{
	    //			CommonLookupDataDAO lookupDAO = new CommonLookupDataDAO(getSession());
	    CommonLookupDataDAO lookupDAO = getLookupDAO();
	    entity = (CommonLookupDataEntity)lookupDAO.get(id);
	}
	return entity;
    }
    //======================================================================
    /**
     * Load business unit with id.
     *
     * @param id the id
     * @return the business unit entity
     * @throws DatabaseException the database exception
     */
    public BusinessUnitEntity loadBusinessUnitWithId(Long id) throws DatabaseException
    {
	BusinessUnitEntity entity = null;
	if (id != null)
	{
	    //			BusinessUnitDAO businessUnitDAO = new BusinessUnitDAO(getSession());
	    BusinessUnitDAO businessUnitDAO = getBusinessUnitDAO();
	    entity = (BusinessUnitEntity)businessUnitDAO.get(id);
	}
	return entity;
    }
    //======================================================================
    /**
     * Load third party with id.
     *
     * @param id the id
     * @return the third party entity
     * @throws DatabaseException the database exception
     */
    public ThirdPartyEntity loadThirdPartyWithId(Long id) throws DatabaseException
    {
	ThirdPartyEntity entity = null;
	if (id != null)
	{
	    //			ThirdPartyDAO thirdPartyDAO = new ThirdPartyDAO(getSession());
	    ThirdPartyDAO thirdPartyDAO = getThirdPartyDAO();
	    entity = (ThirdPartyEntity)thirdPartyDAO.get(id);
	}
	return entity;
    }
    //======================================================================
    /**
     * Load ownedby with id.
     *
     * @param id the id
     * @return the entitlement xref entity
     * @throws DatabaseException the database exception
     */
    public EntitlementXrefEntity loadOwnedbyWithId(Long id) throws DatabaseException
    {
	EntitlementXrefEntity entity = null;
	if (id != null)
	{
	    //			EntitlementXrefDAO ownedbyDAO = new EntitlementXrefDAO(getSession());
	    EntitlementXrefDAO ownedbyDAO = getOwnedbyDAO();
	    entity = (EntitlementXrefEntity)ownedbyDAO.get(id);
	}
	return entity;
    }
    //======================================================================
    /**
     * Load target resource type with id.
     *
     * @param id the id
     * @return the resource type entity
     * @throws DatabaseException the database exception
     */
    public ResourceTypeEntity loadTargetResourceTypeWithId(Long id) throws DatabaseException
    {
	ResourceTypeEntity entity = null;
	if (id != null)
	{
	    // Use lookup for optimized access
	    entity = ResourceTypeLookup.getInstance().getById(getSession(), id);
	}
	return entity;
    }
    //======================================================================
    /**
     * Load requester resource type with id.
     *
     * @param id the id
     * @return the resource type entity
     * @throws DatabaseException the database exception
     */
    public ResourceTypeEntity loadRequesterResourceTypeWithId(Long id) throws DatabaseException
    {
	ResourceTypeEntity entity = null;
	if (id != null)
	{
	    // Use lookup for optimized access
	    entity = ResourceTypeLookup.getInstance().getById(getSession(), id);
	}
	return entity;
    }
    //======================================================================
    /**
     * Load uturn third party with id.
     *
     * @param id the id
     * @return the third party entity
     * @throws DatabaseException the database exception
     */
    public ThirdPartyEntity loadUturnThirdPartyWithId(Long id) throws DatabaseException
    {
	ThirdPartyEntity entity = null;
	if (id != null)
	{
	    //			ThirdPartyDAO uturnThirdPartyDAO = new ThirdPartyDAO(getSession());
	    ThirdPartyDAO uturnThirdPartyDAO = getUturnThirdPartyDAO();
	    entity = (ThirdPartyEntity)uturnThirdPartyDAO.get(id);
	}
	return entity;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#updateReferences(java.sql.PreparedStatement, com.mentisys.model.Entity, int)
     */
    protected int updateReferences(PreparedStatement st, Entity obj, int position)
    throws DatabaseException, SQLException
    {
	RelationshipEntity entity = (RelationshipEntity) obj;

	setLongToStatement(st, position++, entity.getLookup() != null ? entity.getLookup().getId() : entity.getLookupId());
	//setLongToStatement(st, position++, entity.getBusinessUnit() != null ? entity.getBusinessUnit().getId() : entity.getBusinessUnitId());
	setLongToStatement(st, position++, entity.getThirdParty() != null ? entity.getThirdParty().getId() : entity.getThirdPartyId());
	setLongToStatement(st, position++, entity.getOwnedby() != null ? entity.getOwnedby().getId() : entity.getOwnedbyId());
	setLongToStatement(st, position++, entity.getTargetResourceType() != null ? entity.getTargetResourceType().getId() : entity.getTargetResourceTypeId());
	setLongToStatement(st, position++, entity.getRequesterResourceType() != null ? entity.getRequesterResourceType().getId() : entity.getRequesterResourceTypeId());
	setLongToStatement(st, position++, entity.getUturnThirdParty() != null ? entity.getUturnThirdParty().getId() : entity.getUturnThirdPartyId());

	return position;
    }

    // Single Composition 'lookup' helpers 'relationship'
    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void beforeUpdateLookupReferences(RelationshipEntity entity) throws DatabaseException
    {
	if (entity.getLookup() != null)
	{
	    CommonLookupDataDAO dao = getLookupDAO();
	    dao.update(entity.getLookup(), false);
	}
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void afterUpdateLookupReferences(RelationshipEntity entity) throws DatabaseException
    {
	if (entity.getOriginalLookupId() != null && !entity.getOriginalLookupId().equals(entity.getLookupId()))
	{
	    CommonLookupDataDAO dao = getLookupDAO();
	    if(entity.getOriginalLookup() != null)
	    {
		dao.delete(entity.getOriginalLookup());
	    }
	    else
	    {
		dao.delete(entity.getOriginalLookupId());
	    }
	}

	//		if (entity.getOriginalLookup() != null && !entity.getOriginalLookup().equals(entity.getLookup()))
	//		{
	//			CommonLookupDataDAO dao = getLookupDAO();
	//			dao.delete(entity.getOriginalLookup());
	//		}
    }

    // Many Composition 'thirdPartyContact' helpers 'relationship'
    //======================================================================
    /**
     * Loads all the RelationshipTPContactXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadThirdPartyContactReferences(RelationshipEntity entity) throws DatabaseException
    {
	loadThirdPartyContactReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the RelationshipTPContactXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadThirdPartyContactReferences(RelationshipEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading ThirdPartyContact references for RelationshipEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getThirdPartyContact();
	    List id_list = entity.getOriginalThirdPartyContactIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		RelationshipTPContactXrefDAO dao = getThirdPartyContactDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		RelationshipTPContactXrefDAO dao = getThirdPartyContactDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading ThirdPartyContact references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load ThirdPartyContact References for RelationshipEntity [" + entity.getId() + "].", e);
	}


	//		entity.setThirdPartyContact(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the ThirdPartyContact references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadThirdPartyContactReferenceIds(RelationshipEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_THIRDPARTYCONTACT_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalThirdPartyContactIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load ThirdPartyContact Reference IDs from RelationshipEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update third party contact references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateThirdPartyContactReferences(RelationshipEntity entity) throws DatabaseException
    {
	ManyAssociationList thirdPartyContact = entity.getThirdPartyContact();
	RelationshipTPContactXrefDAO dao = getThirdPartyContactDAO();

	Iterator itDeleted = thirdPartyContact.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    RelationshipTPContactXrefEntity e = (RelationshipTPContactXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = thirdPartyContact.iterator();
	while (it.hasNext())
	{
	    RelationshipTPContactXrefEntity e = (RelationshipTPContactXrefEntity) it.next();
	    e.setRelationship(entity);
	    dao.update(e, false);
	}
    }
    // Many Composition 'citiContact' helpers 'relationship'
    //======================================================================
    /**
     * Loads all the RelationshipCitiContactXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadCitiContactReferences(RelationshipEntity entity) throws DatabaseException
    {
	loadCitiContactReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the RelationshipCitiContactXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadCitiContactReferences(RelationshipEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading CitiContact references for RelationshipEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getCitiContact();
	    List id_list = entity.getOriginalCitiContactIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		RelationshipCitiContactXrefDAO dao = getCitiContactDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		RelationshipCitiContactXrefDAO dao = getCitiContactDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading CitiContact references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load CitiContact References for RelationshipEntity [" + entity.getId() + "].", e);
	}


	//		entity.setCitiContact(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the CitiContact references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadCitiContactReferenceIds(RelationshipEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_CITICONTACT_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalCitiContactIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load CitiContact Reference IDs from RelationshipEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update citi contact references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateCitiContactReferences(RelationshipEntity entity) throws DatabaseException
    {
	ManyAssociationList citiContact = entity.getCitiContact();
	RelationshipCitiContactXrefDAO dao = getCitiContactDAO();

	Iterator itDeleted = citiContact.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    RelationshipCitiContactXrefEntity e = (RelationshipCitiContactXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = citiContact.iterator();
	while (it.hasNext())
	{
	    RelationshipCitiContactXrefEntity e = (RelationshipCitiContactXrefEntity) it.next();
	    e.setRelationship(entity);
	    dao.update(e, false);
	}
    }
    // Many Composition 'resource' helpers 'relationship'
    //======================================================================
    /**
     * Loads all the RelationshipCitiResourceXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadResourceReferences(RelationshipEntity entity) throws DatabaseException
    {
	loadResourceReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the RelationshipCitiResourceXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadResourceReferences(RelationshipEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading Resource references for RelationshipEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getResource();
	    List id_list = entity.getOriginalResourceIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		RelationshipCitiResourceXrefDAO dao = getResourceDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		RelationshipCitiResourceXrefDAO dao = getResourceDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading Resource references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Resource References for RelationshipEntity [" + entity.getId() + "].", e);
	}


	//		entity.setResource(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the Resource references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadResourceReferenceIds(RelationshipEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_RESOURCE_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalResourceIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Resource Reference IDs from RelationshipEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update resource references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateResourceReferences(RelationshipEntity entity) throws DatabaseException
    {
	ManyAssociationList resource = entity.getResource();
	RelationshipCitiResourceXrefDAO dao = getResourceDAO();

	Iterator itDeleted = resource.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    RelationshipCitiResourceXrefEntity e = (RelationshipCitiResourceXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = resource.iterator();
	while (it.hasNext())
	{
	    RelationshipCitiResourceXrefEntity e = (RelationshipCitiResourceXrefEntity) it.next();
	    e.setRelationship(entity);
	    dao.update(e, false);
	}
    }
    // Many Composition 'projectJustification' helpers 'relationship'
    //======================================================================
    /**
     * Loads all the RelationshipProjectJustificationXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadProjectJustificationReferences(RelationshipEntity entity) throws DatabaseException
    {
	loadProjectJustificationReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the RelationshipProjectJustificationXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadProjectJustificationReferences(RelationshipEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading ProjectJustification references for RelationshipEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getProjectJustification();
	    List id_list = entity.getOriginalProjectJustificationIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		RelationshipProjectJustificationXrefDAO dao = getProjectJustificationDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		RelationshipProjectJustificationXrefDAO dao = getProjectJustificationDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading ProjectJustification references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load ProjectJustification References for RelationshipEntity [" + entity.getId() + "].", e);
	}


	//		entity.setProjectJustification(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the ProjectJustification references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadProjectJustificationReferenceIds(RelationshipEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_PROJECTJUSTIFICATION_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalProjectJustificationIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load ProjectJustification Reference IDs from RelationshipEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update project justification references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateProjectJustificationReferences(RelationshipEntity entity) throws DatabaseException
    {
	ManyAssociationList projectJustification = entity.getProjectJustification();
	RelationshipProjectJustificationXrefDAO dao = getProjectJustificationDAO();

	Iterator itDeleted = projectJustification.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    RelationshipProjectJustificationXrefEntity e = (RelationshipProjectJustificationXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = projectJustification.iterator();
	while (it.hasNext())
	{
	    RelationshipProjectJustificationXrefEntity e = (RelationshipProjectJustificationXrefEntity) it.next();
	    e.setRelationship(entity);
	    dao.update(e, false);
	}
    }
    // Many Composition 'facilitiesAffected' helpers 'relationship'
    //======================================================================
    /**
     * Loads all the RelationshipFacilitiesAffectedXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadFacilitiesAffectedReferences(RelationshipEntity entity) throws DatabaseException
    {
	loadFacilitiesAffectedReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the RelationshipFacilitiesAffectedXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadFacilitiesAffectedReferences(RelationshipEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading FacilitiesAffected references for RelationshipEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getFacilitiesAffected();
	    List id_list = entity.getOriginalFacilitiesAffectedIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		RelationshipFacilitiesAffectedXrefDAO dao = getFacilitiesAffectedDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		RelationshipFacilitiesAffectedXrefDAO dao = getFacilitiesAffectedDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading FacilitiesAffected references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load FacilitiesAffected References for RelationshipEntity [" + entity.getId() + "].", e);
	}


	//		entity.setFacilitiesAffected(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the FacilitiesAffected references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadFacilitiesAffectedReferenceIds(RelationshipEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_FACILITIESAFFECTED_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalFacilitiesAffectedIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load FacilitiesAffected Reference IDs from RelationshipEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update facilities affected references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateFacilitiesAffectedReferences(RelationshipEntity entity) throws DatabaseException
    {
	ManyAssociationList facilitiesAffected = entity.getFacilitiesAffected();
	RelationshipFacilitiesAffectedXrefDAO dao = getFacilitiesAffectedDAO();

	Iterator itDeleted = facilitiesAffected.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    RelationshipFacilitiesAffectedXrefEntity e = (RelationshipFacilitiesAffectedXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = facilitiesAffected.iterator();
	while (it.hasNext())
	{
	    RelationshipFacilitiesAffectedXrefEntity e = (RelationshipFacilitiesAffectedXrefEntity) it.next();
	    e.setRelationship(entity);
	    dao.update(e, false);
	}
    }
    // Many Composition 'service' helpers 'relationship'
    //======================================================================
    /**
     * Loads all the RelationshipTPServiceXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadServiceReferences(RelationshipEntity entity) throws DatabaseException
    {
	loadServiceReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the RelationshipTPServiceXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadServiceReferences(RelationshipEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading Service references for RelationshipEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getService();
	    List id_list = entity.getOriginalServiceIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		RelationshipTPServiceXrefDAO dao = getServiceDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		RelationshipTPServiceXrefDAO dao = getServiceDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading Service references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Service References for RelationshipEntity [" + entity.getId() + "].", e);
	}


	//		entity.setService(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the Service references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadServiceReferenceIds(RelationshipEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_SERVICE_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalServiceIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Service Reference IDs from RelationshipEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update service references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateServiceReferences(RelationshipEntity entity) throws DatabaseException
    {
	ManyAssociationList service = entity.getService();
	RelationshipTPServiceXrefDAO dao = getServiceDAO();

	Iterator itDeleted = service.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    RelationshipTPServiceXrefEntity e = (RelationshipTPServiceXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = service.iterator();
	while (it.hasNext())
	{
	    RelationshipTPServiceXrefEntity e = (RelationshipTPServiceXrefEntity) it.next();
	    e.setRelationship(entity);
	    dao.update(e, false);
	}
    }
    // Single non-composition 'businessUnit' helpers 'Relationship' does not need helper
    // Many Composition 'citiLocation' helpers 'relationship'
    //======================================================================
    /**
     * Loads all the RelationshipCitiLocationXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadCitiLocationReferences(RelationshipEntity entity) throws DatabaseException
    {
	loadCitiLocationReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the RelationshipCitiLocationXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadCitiLocationReferences(RelationshipEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading CitiLocation references for RelationshipEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getCitiLocation();
	    List id_list = entity.getOriginalCitiLocationIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		RelationshipCitiLocationXrefDAO dao = getCitiLocationDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		RelationshipCitiLocationXrefDAO dao = getCitiLocationDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading CitiLocation references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load CitiLocation References for RelationshipEntity [" + entity.getId() + "].", e);
	}


	//		entity.setCitiLocation(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the CitiLocation references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadCitiLocationReferenceIds(RelationshipEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_CITILOCATION_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalCitiLocationIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load CitiLocation Reference IDs from RelationshipEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update citi location references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateCitiLocationReferences(RelationshipEntity entity) throws DatabaseException
    {
	ManyAssociationList citiLocation = entity.getCitiLocation();
	RelationshipCitiLocationXrefDAO dao = getCitiLocationDAO();

	Iterator itDeleted = citiLocation.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    RelationshipCitiLocationXrefEntity e = (RelationshipCitiLocationXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = citiLocation.iterator();
	while (it.hasNext())
	{
	    RelationshipCitiLocationXrefEntity e = (RelationshipCitiLocationXrefEntity) it.next();
	    e.setRelationship(entity);
	    dao.update(e, false);
	}
    }
    // Single non-composition 'thirdParty' helpers 'Relationship' does not need helper
    // Many Composition 'thirdPartyLocation' helpers 'relationship'
    //======================================================================
    /**
     * Loads all the RelationshipTPLocationXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadThirdPartyLocationReferences(RelationshipEntity entity) throws DatabaseException
    {
	loadThirdPartyLocationReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the RelationshipTPLocationXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadThirdPartyLocationReferences(RelationshipEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading ThirdPartyLocation references for RelationshipEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getThirdPartyLocation();
	    List id_list = entity.getOriginalThirdPartyLocationIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		RelationshipTPLocationXrefDAO dao = getThirdPartyLocationDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		RelationshipTPLocationXrefDAO dao = getThirdPartyLocationDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading ThirdPartyLocation references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load ThirdPartyLocation References for RelationshipEntity [" + entity.getId() + "].", e);
	}


	//		entity.setThirdPartyLocation(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the ThirdPartyLocation references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadThirdPartyLocationReferenceIds(RelationshipEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_THIRDPARTYLOCATION_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalThirdPartyLocationIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load ThirdPartyLocation Reference IDs from RelationshipEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update third party location references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateThirdPartyLocationReferences(RelationshipEntity entity) throws DatabaseException
    {
	ManyAssociationList thirdPartyLocation = entity.getThirdPartyLocation();
	RelationshipTPLocationXrefDAO dao = getThirdPartyLocationDAO();

	Iterator itDeleted = thirdPartyLocation.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    RelationshipTPLocationXrefEntity e = (RelationshipTPLocationXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = thirdPartyLocation.iterator();
	while (it.hasNext())
	{
	    RelationshipTPLocationXrefEntity e = (RelationshipTPLocationXrefEntity) it.next();
	    e.setRelationship(entity);
	    dao.update(e, false);
	}
    }
    // Single Composition 'ownedby' helpers 'relationship'
    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void beforeUpdateOwnedbyReferences(RelationshipEntity entity) throws DatabaseException
    {
	if (entity.getOwnedby() != null)
	{
	    EntitlementXrefDAO dao = getOwnedbyDAO();
	    dao.update(entity.getOwnedby(), false);
	}
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void afterUpdateOwnedbyReferences(RelationshipEntity entity) throws DatabaseException
    {
	if (entity.getOriginalOwnedbyId() != null && !entity.getOriginalOwnedbyId().equals(entity.getOwnedbyId()))
	{
	    EntitlementXrefDAO dao = getOwnedbyDAO();
	    if(entity.getOriginalOwnedby() != null)
	    {
		dao.delete(entity.getOriginalOwnedby());
	    }
	    else
	    {
		dao.delete(entity.getOriginalOwnedbyId());
	    }
	}

	//		if (entity.getOriginalOwnedby() != null && !entity.getOriginalOwnedby().equals(entity.getOwnedby()))
	//		{
	//			EntitlementXrefDAO dao = getOwnedbyDAO();
	//			dao.delete(entity.getOriginalOwnedby());
	//		}
    }

    // Many Association 'connections' helpers 'relationship'
    //======================================================================
    /**
     * Loads all the Connection references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadConnectionsReferences(RelationshipEntity entity) throws DatabaseException
    {
	loadConnectionsReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the Connection references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadConnectionsReferences(RelationshipEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading Connections references for RelationshipEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getConnections();
	    List id_list = entity.getOriginalConnectionsIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		ConnectionDAO dao = getConnectionsDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		ConnectionDAO dao = getConnectionsDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading Connections references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Connections References for RelationshipEntity [" + entity.getId() + "].", e);
	}


	//		entity.setConnections(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the Connections references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadConnectionsReferenceIds(RelationshipEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_CONNECTIONS_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalConnectionsIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load Connections Reference IDs from RelationshipEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update connections references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateConnectionsReferences(RelationshipEntity entity) throws DatabaseException
    {
	ManyAssociationList entity_list = entity.getConnections();

	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;

	try
	{
	    String update_statement = "UPDATE " + ConnectionDAO.TABLE + " SET " + ConnectionDAO.COLUMN_RELATIONSHIP_ID + " = ? WHERE" + ConnectionDAO.COLUMN_RELATIONSHIP_ID + " IN (";
	    StringBuffer statement = new StringBuffer(update_statement);

	    connection = session.getConnection();

	    // Go through all the entities that were removed from the being associated with this entity,
	    // and ensure that their references are set to null.
	    Iterator iter = entity_list.getDeletedList().iterator();
	    long first = 0;
	    while(iter.hasNext())
	    {
		Entity referenced_entity = (Entity)iter.next();		
		Long id = referenced_entity.getPrimaryKey();
		if(id != null)
		{
		    if(first++ > 0)
		    {
			statement.append(",");
		    }
		    statement.append(id.toString());
		}
	    }

	    statement.append(")");
	    st = connection.prepareStatement(UPDATE_CONNECTIONS_REFERENCE_IDS_STMT);

	    setLongToStatement(st, 1, null);
	    st.execute();
	    closeStatement(st);


	    // Now we go through all the entities that were added to being associated with this entity,
	    // and ensure that their references are set to us.
	    statement = new StringBuffer(update_statement);

	    iter = entity_list.getAddedList().iterator();
	    first = 0;
	    while(iter.hasNext())
	    {
		Entity referenced_entity = (Entity)iter.next();		
		Long id = referenced_entity.getPrimaryKey();
		if(id != null)
		{
		    if(first++ > 0)
		    {
			statement.append(",");
		    }
		    statement.append(id.toString());
		}
	    }

	    statement.append(")");
	    st = connection.prepareStatement(UPDATE_CONNECTIONS_REFERENCE_IDS_STMT);

	    setLongToStatement(st, 1, entity.getPrimaryKey());
	    st.execute();
	    closeStatement(st);
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to update Connections References from RelationshipEntity", e);
	}
	finally
	{
	    session.releaseConnection();
	}
    }	
    // Single non-composition 'targetResourceType' helpers 'Relationship' does not need helper
    // Single non-composition 'requesterResourceType' helpers 'Relationship' does not need helper
    // Many Composition 'citiReqContact' helpers 'relationship'
    //======================================================================
    /**
     * Loads all the RelationshipRequesterCitiContactXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadCitiReqContactReferences(RelationshipEntity entity) throws DatabaseException
    {
	loadCitiReqContactReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the RelationshipRequesterCitiContactXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadCitiReqContactReferences(RelationshipEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading CitiReqContact references for RelationshipEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getCitiReqContact();
	    List id_list = entity.getOriginalCitiReqContactIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		RelationshipRequesterCitiContactXrefDAO dao = getCitiReqContactDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		RelationshipRequesterCitiContactXrefDAO dao = getCitiReqContactDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading CitiReqContact references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load CitiReqContact References for RelationshipEntity [" + entity.getId() + "].", e);
	}


	//		entity.setCitiReqContact(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the CitiReqContact references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadCitiReqContactReferenceIds(RelationshipEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_CITIREQCONTACT_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalCitiReqContactIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load CitiReqContact Reference IDs from RelationshipEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update citi req contact references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateCitiReqContactReferences(RelationshipEntity entity) throws DatabaseException
    {
	ManyAssociationList citiReqContact = entity.getCitiReqContact();
	RelationshipRequesterCitiContactXrefDAO dao = getCitiReqContactDAO();

	Iterator itDeleted = citiReqContact.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    RelationshipRequesterCitiContactXrefEntity e = (RelationshipRequesterCitiContactXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = citiReqContact.iterator();
	while (it.hasNext())
	{
	    RelationshipRequesterCitiContactXrefEntity e = (RelationshipRequesterCitiContactXrefEntity) it.next();
	    e.setRelationship(entity);
	    dao.update(e, false);
	}
    }
    // Many Composition 'reqCitiLocation' helpers 'relationship'
    //======================================================================
    /**
     * Loads all the RelationshipRequesterCitiLocationXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadReqCitiLocationReferences(RelationshipEntity entity) throws DatabaseException
    {
	loadReqCitiLocationReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the RelationshipRequesterCitiLocationXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadReqCitiLocationReferences(RelationshipEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading ReqCitiLocation references for RelationshipEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getReqCitiLocation();
	    List id_list = entity.getOriginalReqCitiLocationIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		RelationshipRequesterCitiLocationXrefDAO dao = getReqCitiLocationDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		RelationshipRequesterCitiLocationXrefDAO dao = getReqCitiLocationDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading ReqCitiLocation references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load ReqCitiLocation References for RelationshipEntity [" + entity.getId() + "].", e);
	}


	//		entity.setReqCitiLocation(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the ReqCitiLocation references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadReqCitiLocationReferenceIds(RelationshipEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_REQCITILOCATION_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalReqCitiLocationIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load ReqCitiLocation Reference IDs from RelationshipEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update req citi location references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateReqCitiLocationReferences(RelationshipEntity entity) throws DatabaseException
    {
	ManyAssociationList reqCitiLocation = entity.getReqCitiLocation();
	RelationshipRequesterCitiLocationXrefDAO dao = getReqCitiLocationDAO();

	Iterator itDeleted = reqCitiLocation.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    RelationshipRequesterCitiLocationXrefEntity e = (RelationshipRequesterCitiLocationXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = reqCitiLocation.iterator();
	while (it.hasNext())
	{
	    RelationshipRequesterCitiLocationXrefEntity e = (RelationshipRequesterCitiLocationXrefEntity) it.next();
	    e.setRelationship(entity);
	    dao.update(e, false);
	}
    }
    // Single non-composition 'uturnThirdParty' helpers 'Relationship' does not need helper

    // Reference DAO caching methods	
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A CommonLookupDataDAO object 
     */
    protected CommonLookupDataDAO getLookupDAO()
    {
	CommonLookupDataDAO dao = (CommonLookupDataDAO)getSession().getDAO("CommonLookupData");  
	if(dao == null)
	{
	    dao = new CommonLookupDataDAO(getSession());  		
	    getSession().putDAO("CommonLookupData", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A RelationshipTPContactXrefDAO object 
     */
    protected RelationshipTPContactXrefDAO getThirdPartyContactDAO()
    {
	RelationshipTPContactXrefDAO dao = (RelationshipTPContactXrefDAO)getSession().getDAO("RelationshipTPContactXref");  
	if(dao == null)
	{
	    dao = new RelationshipTPContactXrefDAO(getSession());  		
	    getSession().putDAO("RelationshipTPContactXref", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A RelationshipCitiContactXrefDAO object 
     */
    protected RelationshipCitiContactXrefDAO getCitiContactDAO()
    {
	RelationshipCitiContactXrefDAO dao = (RelationshipCitiContactXrefDAO)getSession().getDAO("RelationshipCitiContactXref");  
	if(dao == null)
	{
	    dao = new RelationshipCitiContactXrefDAO(getSession());  		
	    getSession().putDAO("RelationshipCitiContactXref", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A RelationshipCitiResourceXrefDAO object 
     */
    protected RelationshipCitiResourceXrefDAO getResourceDAO()
    {
	RelationshipCitiResourceXrefDAO dao = (RelationshipCitiResourceXrefDAO)getSession().getDAO("RelationshipCitiResourceXref");  
	if(dao == null)
	{
	    dao = new RelationshipCitiResourceXrefDAO(getSession());  		
	    getSession().putDAO("RelationshipCitiResourceXref", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A RelationshipProjectJustificationXrefDAO object 
     */
    protected RelationshipProjectJustificationXrefDAO getProjectJustificationDAO()
    {
	RelationshipProjectJustificationXrefDAO dao = (RelationshipProjectJustificationXrefDAO)getSession().getDAO("RelationshipProjectJustificationXref");  
	if(dao == null)
	{
	    dao = new RelationshipProjectJustificationXrefDAO(getSession());  		
	    getSession().putDAO("RelationshipProjectJustificationXref", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A RelationshipFacilitiesAffectedXrefDAO object 
     */
    protected RelationshipFacilitiesAffectedXrefDAO getFacilitiesAffectedDAO()
    {
	RelationshipFacilitiesAffectedXrefDAO dao = (RelationshipFacilitiesAffectedXrefDAO)getSession().getDAO("RelationshipFacilitiesAffectedXref");  
	if(dao == null)
	{
	    dao = new RelationshipFacilitiesAffectedXrefDAO(getSession());  		
	    getSession().putDAO("RelationshipFacilitiesAffectedXref", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A RelationshipTPServiceXrefDAO object 
     */
    protected RelationshipTPServiceXrefDAO getServiceDAO()
    {
	RelationshipTPServiceXrefDAO dao = (RelationshipTPServiceXrefDAO)getSession().getDAO("RelationshipTPServiceXref");  
	if(dao == null)
	{
	    dao = new RelationshipTPServiceXrefDAO(getSession());  		
	    getSession().putDAO("RelationshipTPServiceXref", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A BusinessUnitDAO object 
     */
    protected BusinessUnitDAO getBusinessUnitDAO()
    {
	BusinessUnitDAO dao = (BusinessUnitDAO)getSession().getDAO("BusinessUnit");  
	if(dao == null)
	{
	    dao = new BusinessUnitDAO(getSession());  		
	    getSession().putDAO("BusinessUnit", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A RelationshipCitiLocationXrefDAO object 
     */
    protected RelationshipCitiLocationXrefDAO getCitiLocationDAO()
    {
	RelationshipCitiLocationXrefDAO dao = (RelationshipCitiLocationXrefDAO)getSession().getDAO("RelationshipCitiLocationXref");  
	if(dao == null)
	{
	    dao = new RelationshipCitiLocationXrefDAO(getSession());  		
	    getSession().putDAO("RelationshipCitiLocationXref", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A ThirdPartyDAO object 
     */
    protected ThirdPartyDAO getThirdPartyDAO()
    {
	ThirdPartyDAO dao = (ThirdPartyDAO)getSession().getDAO("ThirdParty");  
	if(dao == null)
	{
	    dao = new ThirdPartyDAO(getSession());  		
	    getSession().putDAO("ThirdParty", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A RelationshipTPLocationXrefDAO object 
     */
    protected RelationshipTPLocationXrefDAO getThirdPartyLocationDAO()
    {
	RelationshipTPLocationXrefDAO dao = (RelationshipTPLocationXrefDAO)getSession().getDAO("RelationshipTPLocationXref");  
	if(dao == null)
	{
	    dao = new RelationshipTPLocationXrefDAO(getSession());  		
	    getSession().putDAO("RelationshipTPLocationXref", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A EntitlementXrefDAO object 
     */
    protected EntitlementXrefDAO getOwnedbyDAO()
    {
	EntitlementXrefDAO dao = (EntitlementXrefDAO)getSession().getDAO("EntitlementXref");  
	if(dao == null)
	{
	    dao = new EntitlementXrefDAO(getSession());  		
	    getSession().putDAO("EntitlementXref", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A ConnectionDAO object 
     */
    protected ConnectionDAO getConnectionsDAO()
    {
	ConnectionDAO dao = (ConnectionDAO)getSession().getDAO("Connection");  
	if(dao == null)
	{
	    dao = new ConnectionDAO(getSession());  		
	    getSession().putDAO("Connection", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A ResourceTypeDAO object 
     */
    protected ResourceTypeDAO getTargetResourceTypeDAO()
    {
	ResourceTypeDAO dao = (ResourceTypeDAO)getSession().getDAO("ResourceType");  
	if(dao == null)
	{
	    dao = new ResourceTypeDAO(getSession());  		
	    getSession().putDAO("ResourceType", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A ResourceTypeDAO object 
     */
    protected ResourceTypeDAO getRequesterResourceTypeDAO()
    {
	ResourceTypeDAO dao = (ResourceTypeDAO)getSession().getDAO("ResourceType");  
	if(dao == null)
	{
	    dao = new ResourceTypeDAO(getSession());  		
	    getSession().putDAO("ResourceType", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A RelationshipRequesterCitiContactXrefDAO object 
     */
    protected RelationshipRequesterCitiContactXrefDAO getCitiReqContactDAO()
    {
	RelationshipRequesterCitiContactXrefDAO dao = (RelationshipRequesterCitiContactXrefDAO)getSession().getDAO("RelationshipRequesterCitiContactXref");  
	if(dao == null)
	{
	    dao = new RelationshipRequesterCitiContactXrefDAO(getSession());  		
	    getSession().putDAO("RelationshipRequesterCitiContactXref", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A RelationshipRequesterCitiLocationXrefDAO object 
     */
    protected RelationshipRequesterCitiLocationXrefDAO getReqCitiLocationDAO()
    {
	RelationshipRequesterCitiLocationXrefDAO dao = (RelationshipRequesterCitiLocationXrefDAO)getSession().getDAO("RelationshipRequesterCitiLocationXref");  
	if(dao == null)
	{
	    dao = new RelationshipRequesterCitiLocationXrefDAO(getSession());  		
	    getSession().putDAO("RelationshipRequesterCitiLocationXref", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A ThirdPartyDAO object 
     */
    protected ThirdPartyDAO getUturnThirdPartyDAO()
    {
	ThirdPartyDAO dao = (ThirdPartyDAO)getSession().getDAO("ThirdParty");  
	if(dao == null)
	{
	    dao = new ThirdPartyDAO(getSession());  		
	    getSession().putDAO("ThirdParty", dao);
	}		
	return dao;
    }

    //=====================================================================
    // Query helpers: 
    //=====================================================================

    //=====================================================================
    /**
     * Find all entities where the property [Name] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByName(String value) throws DatabaseException
    {
	return findByName(value, getSession());
    }

    /**
     * Find by name.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByName(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_NAME + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [Purpose] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByPurpose(String value) throws DatabaseException
    {
	return findByPurpose(value, getSession());
    }

    /**
     * Find by purpose.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByPurpose(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_PURPOSE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [ConnectivityExists] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByConnectivityExists(String value) throws DatabaseException
    {
	return findByConnectivityExists(value, getSession());
    }

    /**
     * Find by connectivity exists.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByConnectivityExists(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_CONNECTIVITYEXISTS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [ReadyDate] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByReadyDate(Date value) throws DatabaseException
    {
	return findByReadyDate(value, getSession());
    }

    /**
     * Find by ready date.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByReadyDate(Date value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_READYDATE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [TerminatedDate] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByTerminatedDate(Date value) throws DatabaseException
    {
	return findByTerminatedDate(value, getSession());
    }

    /**
     * Find by terminated date.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByTerminatedDate(Date value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_TERMINATEDDATE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [Status] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByStatus(String value) throws DatabaseException
    {
	return findByStatus(value, getSession());
    }

    /**
     * Find by status.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByStatus(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_STATUS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [RelationshipId] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByRelationshipId(Long value) throws DatabaseException
    {
	return findByRelationshipId(value, getSession());
    }

    /**
     * Find by relationship id.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByRelationshipId(Long value, DatabaseSession session) throws DatabaseException
    {
    	String sel_stmt = null;
	//String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_RELATIONSHIPID + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [RequesterId] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByRequesterId(String value) throws DatabaseException
    {
	return findByRequesterId(value, getSession());
    }

    /**
     * Find by requester id.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByRequesterId(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_REQUESTERID + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [Benefit] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByBenefit(String value) throws DatabaseException
    {
	return findByBenefit(value, getSession());
    }

    /**
     * Find by benefit.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByBenefit(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_BENEFIT + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [Plcode] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByPlcode(String value) throws DatabaseException
    {
	return findByPlcode(value, getSession());
    }

    /**
     * Find by plcode.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByPlcode(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_PLCODE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [EstimatedRevenueGenerated] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByEstimatedRevenueGenerated(Double value) throws DatabaseException
    {
	return findByEstimatedRevenueGenerated(value, getSession());
    }

    /**
     * Find by estimated revenue generated.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByEstimatedRevenueGenerated(Double value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_ESTIMATEDREVENUEGENERATED + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [EstimatedCostSaving] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByEstimatedCostSaving(Double value) throws DatabaseException
    {
	return findByEstimatedCostSaving(value, getSession());
    }

    /**
     * Find by estimated cost saving.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByEstimatedCostSaving(Double value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_ESTIMATEDCOSTSAVING + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [CobRedundancyRequired] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByCobRedundancyRequired(Boolean value) throws DatabaseException
    {
	return findByCobRedundancyRequired(value, getSession());
    }

    /**
     * Find by cob redundancy required.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByCobRedundancyRequired(Boolean value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_COBREDUNDANCYREQUIRED + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [ProcurementCompletionDate] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByProcurementCompletionDate(Date value) throws DatabaseException
    {
	return findByProcurementCompletionDate(value, getSession());
    }

    /**
     * Find by procurement completion date.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByProcurementCompletionDate(Date value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_PROCUREMENTCOMPLETIONDATE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [GnccApprovalAttained] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByGnccApprovalAttained(Boolean value) throws DatabaseException
    {
	return findByGnccApprovalAttained(value, getSession());
    }

    /**
     * Find by gncc approval attained.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByGnccApprovalAttained(Boolean value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_GNCCAPPROVALATTAINED + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [Comments] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByComments(String value) throws DatabaseException
    {
	return findByComments(value, getSession());
    }

    /**
     * Find by comments.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByComments(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_COMMENTS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [InitialRiskAssesmentDate] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByInitialRiskAssesmentDate(Date value) throws DatabaseException
    {
	return findByInitialRiskAssesmentDate(value, getSession());
    }

    /**
     * Find by initial risk assesment date.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByInitialRiskAssesmentDate(Date value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_INITIALRISKASSESMENTDATE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [OneTimeCost] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByOneTimeCost(Double value) throws DatabaseException
    {
	return findByOneTimeCost(value, getSession());
    }

    /**
     * Find by one time cost.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByOneTimeCost(Double value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_ONETIMECOST + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [MonthlyCost] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByMonthlyCost(Double value) throws DatabaseException
    {
	return findByMonthlyCost(value, getSession());
    }

    /**
     * Find by monthly cost.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByMonthlyCost(Double value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_MONTHLYCOST + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [DataIsPublic] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByDataIsPublic(Boolean value) throws DatabaseException
    {
	return findByDataIsPublic(value, getSession());
    }

    /**
     * Find by data is public.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByDataIsPublic(Boolean value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_DATAISPUBLIC + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [IsOutsourceProvider] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByIsOutsourceProvider(String value) throws DatabaseException
    {
	return findByIsOutsourceProvider(value, getSession());
    }

    /**
     * Find by is outsource provider.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByIsOutsourceProvider(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_ISOUTSOURCEPROVIDER + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [OspServiceName] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByOspServiceName(String value) throws DatabaseException
    {
	return findByOspServiceName(value, getSession());
    }

    /**
     * Find by osp service name.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByOspServiceName(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_OSPSERVICENAME + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [AccessCitiData] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByAccessCitiData(String value) throws DatabaseException
    {
	return findByAccessCitiData(value, getSession());
    }

    /**
     * Find by access citi data.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByAccessCitiData(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_ACCESSCITIDATA + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [AccessCustomerData] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByAccessCustomerData(String value) throws DatabaseException
    {
	return findByAccessCustomerData(value, getSession());
    }

    /**
     * Find by access customer data.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByAccessCustomerData(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_ACCESSCUSTOMERDATA + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [ContractRenewalDate] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByContractRenewalDate(Date value) throws DatabaseException
    {
	return findByContractRenewalDate(value, getSession());
    }

    /**
     * Find by contract renewal date.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByContractRenewalDate(Date value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_CONTRACTRENEWALDATE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [Deleted] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByDeleted(Boolean value) throws DatabaseException
    {
	return findByDeleted(value, getSession());
    }

    /**
     * Find by deleted.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByDeleted(Boolean value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_DELETED + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [RequestDate] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByRequestDate(Date value) throws DatabaseException
    {
	return findByRequestDate(value, getSession());
    }

    /**
     * Find by request date.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByRequestDate(Date value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_REQUESTDATE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [EntInstanceId] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByEntInstanceId(Long value) throws DatabaseException
    {
	return findByEntInstanceId(value, getSession());
    }

    /**
     * Find by ent instance id.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByEntInstanceId(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_ENTINSTANCEID + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [RelationshipType] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByRelationshipType(String value) throws DatabaseException
    {
	return findByRelationshipType(value, getSession());
    }

    /**
     * Find by relationship type.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByRelationshipType(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_RELATIONSHIPTYPE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [Lookup] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByLookup(Long value) throws DatabaseException
    {
	return findByLookup(value, getSession());
    }

    /**
     * Find by lookup.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByLookup(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_LOOKUP_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [BusinessUnit] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByBusinessUnit(Long value) throws DatabaseException
    {
	return findByBusinessUnit(value, getSession());
    }

    /**
     * Find by business unit.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByBusinessUnit(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_BUSINESSUNIT_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [ThirdParty] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByThirdParty(Long value) throws DatabaseException
    {
	return findByThirdParty(value, getSession());
    }

    /**
     * Find by third party.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByThirdParty(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_THIRDPARTY_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [Ownedby] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByOwnedby(Long value) throws DatabaseException
    {
	return findByOwnedby(value, getSession());
    }

    /**
     * Find by ownedby.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByOwnedby(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_OWNEDBY_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [TargetResourceType] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByTargetResourceType(Long value) throws DatabaseException
    {
	return findByTargetResourceType(value, getSession());
    }

    /**
     * Find by target resource type.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByTargetResourceType(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_TARGETRESOURCETYPE_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [RequesterResourceType] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByRequesterResourceType(Long value) throws DatabaseException
    {
	return findByRequesterResourceType(value, getSession());
    }

    /**
     * Find by requester resource type.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByRequesterResourceType(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_REQUESTERRESOURCETYPE_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [UturnThirdParty] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByUturnThirdParty(Long value) throws DatabaseException
    {
	return findByUturnThirdParty(value, getSession());
    }

    /**
     * Find by uturn third party.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByUturnThirdParty(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + RelationshipDAO.TABLE + " WHERE " + COLUMN_UTURNTHIRDPARTY_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find entities by property helper.
     *
     * @param sel_stmt the sel_stmt
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static protected List findEntitiesByPropertyHelper(String sel_stmt, DatabaseSession session) throws DatabaseException
    {
	List entities = null;
	Connection connection = null;
	Statement st = null;
	ResultSet rs = null;

	log.debug(sel_stmt);

	try
	{
	    connection = session.getConnection();
	    st = connection.createStatement();
	    rs = st.executeQuery(sel_stmt);

	    List found_entities = new ArrayList();		
	    while(rs.next())
	    {
		found_entities.add(Long.valueOf(rs.getLong(1)));			
	    }

	    if(found_entities.size() > 0)
	    {
		entities = found_entities;
	    }

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failure to find entities by UturnThirdParty", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    if(connection != null)
	    {
		session.releaseConnection();
	    }
	}

	return entities;
    }


    //=====================================================================
    /**
     * Dummy exception tosser.
     *
     * @param flag the flag
     * @throws DatabaseException the database exception
     */
    protected void dummyExceptionTosser(boolean flag) throws DatabaseException
    {
	if(flag)
	{
	    throw new DatabaseException("This exception should never be thrown....", new Exception("Another dummy"));
	}
    }

    /**
     * Primary key exists.
     *
     * @param entity the entity
     * @param update the update
     * @param session the session
     * @return true, if successful
     * @throws DatabaseException the database exception
     */
    private boolean primaryKeyExists(RelationshipEntity entity, boolean update, DatabaseSession session) 
    throws DatabaseException {

	boolean exists = false;

	return exists;
    }
    
    public void loadRelHierXrefIds(RelationshipEntity entity) throws DatabaseException
    {
    	log.debug("into loadRelHierXrefIds method" );
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_REL_CITI_HIER_XREF_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setRelCitiHierListIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load ReqCitiHierXref Reference IDs from RelationshipEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }
    
    protected RelCitiHierXrefDAO getRelCitiHierXrefDAO()
    {
    	RelCitiHierXrefDAO dao = (RelCitiHierXrefDAO)getSession().getDAO("RelCitiHierXref");  
	if(dao == null)
	{
	    dao = new RelCitiHierXrefDAO(getSession());  		
	    getSession().putDAO("RelCitiHierXref", dao);
	}		
	return dao;
    }
    
    public void loadRelCitiHierXrefReferences(RelationshipEntity entity) throws DatabaseException
    {
    	loadRelCitiHierXrefReferences(entity, true); 
    }
    
    public void loadRelCitiHierXrefReferences(RelationshipEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading RelCitiHierXref references for RelationshipEntity [" + entity.getPrimaryKey() + "].");
	    List entity_list = entity.getRelCitiHierList();
	    List id_list = entity.getRelCitiHierListIds();
	    log.debug("list size" +id_list.size());
	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		RelCitiHierXrefDAO dao = getRelCitiHierXrefDAO();
		entity_list.add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
	    	RelCitiHierXrefDAO dao = getRelCitiHierXrefDAO();
		entity_list.addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading ReqCitiLocation references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
		log.error(e,e);
	    throw new DatabaseException("Failed to load ReqCitiLocation References for RelationshipEntity [" + entity.getId() + "].", e);
	}


	//		entity.setReqCitiLocation(entity_list);
    }

    
}
