/**
 * 
 */
package com.citigroup.cgti.c3par.communication.domain;

import java.io.Serializable;

/**
 * @author ka58098
 *
 */
public class ColumnDTO implements Serializable {

    private static final long serialVersionUID = -156485488L;
    
    private Long viewColumnId;
    private String columnName;
    
    public Long getViewColumnId() {
        return viewColumnId;
    }
    public void setViewColumnId(Long viewColumnId) {
        this.viewColumnId = viewColumnId;
    }
    public String getColumnName() {
        return columnName;
    }
    public void setColumnName(String columnName) {
        this.columnName = columnName;
    }
    

}
