/*
 * CONFIDENTIAL  AND PROPRIETARY
 *  2005 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is 
 * strictly prohibited.
 */
package com.citigroup.cgti.c3par;

import com.mentisys.dao.DatabaseException;


/**
 * The Class RollbackException.
 */
public class RollbackException extends DatabaseException
{

    /** The m_ nested exception. */
    Throwable m_NestedException = null;

    /**
     * Instantiates a new rollback exception.
     *
     * @param msg the msg
     * @param t the t
     */
    public RollbackException(String msg, Throwable t)
    {
	super(msg, t);
	m_NestedException = t;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    public String toString()
    {
	String s = super.toString();
	if (m_NestedException != null)
	{
	    s += " >>>NESTED>>> " + m_NestedException.toString();
	}

	return s;
    }

    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseException#getNestedException()
     */
    public Throwable getNestedException()
    {
	return m_NestedException;
    }
}
