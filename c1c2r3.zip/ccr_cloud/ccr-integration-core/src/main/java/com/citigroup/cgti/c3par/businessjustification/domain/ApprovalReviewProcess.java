/**
 *
 */
package com.citigroup.cgti.c3par.businessjustification.domain;

import java.rmi.RemoteException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import com.citigroup.cgti.c3par.admin.domain.CCRTags;
import com.citigroup.cgti.c3par.businessjustification.domain.soc.persist.ApprovalReviewServicePersistable;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.user.domain.C3parUser;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

public class ApprovalReviewProcess {

    CCRBeanFactory ccrBeanFactory;
    {
        ApplicationContext appContext = CCRApplicationContextUtils.getApplicationContext();
        ccrBeanFactory = (CCRBeanFactory) appContext.getBean("cCRBeanFactory");
    }

    private Map<Long, String> reviewCycles;
    private long reviewVersionSelected;
    private String notesText;
    private String tagsText;
    private TIRequest tiRequest;
    private Long tiProcessId;
    private String userSoeId;
    private C3parUser c3ParUser;
    private Date createdDate;
    private String createdDateString;
    private String tag;
    private CCRTags ccrTags;
    private List<CCRTags> tagsList;

    @Autowired
    private ApprovalReviewServicePersistable approvalReviewServicePersistable;

    public long getReviewVersionSelected() {
        return reviewVersionSelected;
    }

    public void setReviewVersionSelected(long reviewVersionSelected) {
        this.reviewVersionSelected = reviewVersionSelected;
    }

    public HashMap<String, String> fetchRequestInfo(String requestId, String action) {
        return getApprovalReviewServicePersistable().fetchRequestInfo(requestId, action);
    }

    public List<HashMap<String, String>> extractReviewComments(long requestId) throws Exception {
        return getApprovalReviewServicePersistable().extractReviewComments(requestId);
    }

    public int getCount(String listType, Long ti_request_id, String role) throws Exception {
        return getApprovalReviewServicePersistable().getCount(listType, ti_request_id, role);
    }

    public HashMap extractReviewInfo(long requestId) throws Exception {
        return getApprovalReviewServicePersistable().extractReviewInfo(requestId);
    }

    public HashMap extractReviewInfoForIP(long requestId) throws Exception {
        return getApprovalReviewServicePersistable().extractReviewInfoForIP(requestId);
    }

    public List getAllDiscussions(String listType, Long ti_request_id, String role, int pageNum, int pageSize)
            throws RemoteException {
        return getApprovalReviewServicePersistable().getAllDiscussions(listType, ti_request_id, role, pageNum,
                pageSize);
    }

    public TIRequest getTIRequestDetails(Long tiRequestId) {
        return getApprovalReviewServicePersistable().getTIRequest(tiRequestId);
    }

    public ApprovalReviewServicePersistable getApprovalReviewServicePersistable() {
        return approvalReviewServicePersistable;
    }

    public void setApprovalReviewServicePersistable(ApprovalReviewServicePersistable approvalReviewServicePersistable) {
        this.approvalReviewServicePersistable = approvalReviewServicePersistable;
    }

    public Map<Long, String> getAllCyclesAndVersion(long processId, String isIPReg) {

        return ccrBeanFactory.getCommonServicePersistable().getAllCyclesAndVersion(processId, isIPReg);
    }

    public Map<Long, String> getReviewCycles() {
        return reviewCycles;
    }

    public void setReviewCycles(Map<Long, String> reviewCycles) {
        this.reviewCycles = reviewCycles;
    }

    public String getNotesText() {
        return notesText;
    }

    public void setNotesText(String notesText) {
        this.notesText = notesText;
    }

    public TIRequest getTiRequest() {
        return tiRequest;
    }

    public void setTiRequest(TIRequest tiRequest) {
        this.tiRequest = tiRequest;
    }

    public String getUserSoeId() {
        return userSoeId;
    }

    public void setUserSoeId(String userSoeId) {
        this.userSoeId = userSoeId;
    }

    public C3parUser getC3ParUser() {
        return c3ParUser;
    }

    public void setC3ParUser(C3parUser c3ParUser) {
        this.c3ParUser = c3ParUser;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Long getTiProcessId() {
        return tiProcessId;
    }

    public void setTiProcessId(Long tiProcessId) {
        this.tiProcessId = tiProcessId;
    }

    public List<CCRTags> getTagsList() {
        return tagsList;
    }

    public void setTagsList(List<CCRTags> tagsList) {
        this.tagsList = tagsList;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public CCRTags getCcrTags() {
        return ccrTags;
    }

    public void setCcrTags(CCRTags ccrTags) {
        this.ccrTags = ccrTags;
    }

    public String getTagsText() {
        return tagsText;
    }

    public void setTagsText(String tagsText) {
        this.tagsText = tagsText;
    }

    public String getCreatedDateString() {
        return createdDateString;
    }

    public void setCreatedDateString(String createdDateString) {
        this.createdDateString = createdDateString;
    }
    
    public boolean saveNote() throws Exception {
        C3parUser c3ParUser = ccrBeanFactory.getUserAdminServicePersistable().getC3parUserData(getUserSoeId(), false,
                null);
        setC3ParUser(c3ParUser);
        return ccrBeanFactory.getApprovalReviewServicePersistable().saveNote(this);
    }

    public List<ApprovalReviewProcess> getMappedNotes(Long tiProcessId) throws Exception {
        return ccrBeanFactory.getApprovalReviewServicePersistable().getNotes(tiProcessId);
    }
    
    public List<CCRTags> getAllTags() throws Exception {
        return ccrBeanFactory.getManageTagsDao().getAllTags();
    }

    public boolean saveTag() throws Exception {
        C3parUser c3ParUser = ccrBeanFactory.getUserAdminServicePersistable().getC3parUserData(getUserSoeId(), false,
                null);
        setC3ParUser(c3ParUser);
        CCRTags ccrTags = ccrBeanFactory.getManageTagsDao().getCCrTag(Long.valueOf(getTag()));
        setCcrTags(ccrTags);
        return ccrBeanFactory.getApprovalReviewServicePersistable().saveTag(this);
    }

    public List<ApprovalReviewProcess> getMappedTags(Long tiProcessId) throws Exception {
        return ccrBeanFactory.getApprovalReviewServicePersistable().getTags(tiProcessId);
    }
    
}
