package com.citigroup.cgti.c3par.communication.domain;

import org.apache.commons.lang.builder.ToStringBuilder;

public class EcmColumn extends EcmBaseEntity {

	private static final long serialVersionUID = 1548545L;
	private Long id;
    private String uiColumnName;
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUiColumnName() {
        return uiColumnName;
    }

    public void setUiColumnName(String uiColumnName) {
        this.uiColumnName = uiColumnName;
    }
    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

}
