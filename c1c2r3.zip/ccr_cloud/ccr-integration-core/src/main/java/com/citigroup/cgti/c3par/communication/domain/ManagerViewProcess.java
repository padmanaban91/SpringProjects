package com.citigroup.cgti.c3par.communication.domain;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.communication.domain.soc.persist.ManagerViewPersistable;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

public class ManagerViewProcess {
	
CCRBeanFactory ccrBeanFactory;
	
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}
	
	private CMPRequest cmpRequest;
	
	private List<CMPRequest> cmpRequestList;
	
	private String lastName;
	private String firstName;
	private String role;
	private int totalYearAssignedCount;
	private int byAppStatusCount;
	private int byCompStatusCount;
	private int byCancStatusCount;
	public int getByAppStatusCount() {
		return byAppStatusCount;
	}

	public void setByAppStatusCount(int byAppStatusCount) {
		this.byAppStatusCount = byAppStatusCount;
	}

	public int getByCompStatusCount() {
		return byCompStatusCount;
	}

	public void setByCompStatusCount(int byCompStatusCount) {
		this.byCompStatusCount = byCompStatusCount;
	}

	public int getByCancStatusCount() {
		return byCancStatusCount;
	}

	public void setByCancStatusCount(int byCancStatusCount) {
		this.byCancStatusCount = byCancStatusCount;
	}

	//private Integer [] byStatusCount;
	private int bySectorCount;
	private int byRegionCount;
	private int byTypeCount;
	private int byUrgencyCount;
	

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	
	public int getTotalYearAssignedCount() {
		return totalYearAssignedCount;
	}

	public void setTotalYearAssignedCount(int totalYearAssignedCount) {
		this.totalYearAssignedCount = totalYearAssignedCount;
	}

	


	

	public int getBySectorCount() {
		return bySectorCount;
	}

	public void setBySectorCount(int bySectorCount) {
		this.bySectorCount = bySectorCount;
	}

	public int getByRegionCount() {
		return byRegionCount;
	}

	public void setByRegionCount(int byRegionCount) {
		this.byRegionCount = byRegionCount;
	}

	public int getByTypeCount() {
		return byTypeCount;
	}

	public void setByTypeCount(int byTypeCount) {
		this.byTypeCount = byTypeCount;
	}

	public int getByUrgencyCount() {
		return byUrgencyCount;
	}

	public void setByUrgencyCount(int byUrgencyCount) {
		this.byUrgencyCount = byUrgencyCount;
	}
	
	public CMPRequest getCmpRequest() {
		return cmpRequest;
	}

	public void setCmpRequest(CMPRequest cmpRequest) {
		this.cmpRequest = cmpRequest;
	}
	
		
	public List<CMPRequest> getCmpRequestList() {
		return cmpRequestList;
	}

	public void setCmpRequestList(List<CMPRequest> cmpRequestList) {
		this.cmpRequestList = cmpRequestList;
	}

	public ManagerViewPersistable getManagerViewPersistable() {
		return ccrBeanFactory.getManagerViewPersistable();
	}


	@Transactional(propagation=Propagation.SUPPORTS, readOnly=true)
	public  Map<String, List<ManagerViewProcess>> getDetails() {
		return ccrBeanFactory.getManagerViewPersistable().getDetails();		
	}
	
}