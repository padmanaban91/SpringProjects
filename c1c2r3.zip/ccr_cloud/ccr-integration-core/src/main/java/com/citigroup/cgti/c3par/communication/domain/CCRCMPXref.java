package com.citigroup.cgti.c3par.communication.domain;

import java.io.Serializable;
import java.util.Date;

import com.citigroup.cgti.c3par.domain.TIRequest;

/**
 * @author ky38518
 * 
 */
public class CCRCMPXref implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;

    private String cmpOrderItemId;

    private Long tiRequestId;

    private Date createdDate;

    private Date updatedDate;
    private TIRequest tiRequest;

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the cmpOrderItemId
     */
    public String getCmpOrderItemId() {
        return cmpOrderItemId;
    }

    /**
     * @param cmpOrderItemId
     *            the cmpOrderItemId to set
     */
    public void setCmpOrderItemId(String cmpOrderItemId) {
        this.cmpOrderItemId = cmpOrderItemId;
    }

    /**
     * @return the tiRequestId
     */
    public Long getTiRequestId() {
        return tiRequestId;
    }

    /**
     * @param tiRequestId
     *            the tiRequestId to set
     */
    public void setTiRequestId(Long tiRequestId) {
        this.tiRequestId = tiRequestId;
    }

    /**
     * @return the createdDate
     */
    public Date getCreatedDate() {
        return createdDate;
    }

    /**
     * @param createdDate
     *            the createdDate to set
     */
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    /**
     * @return the updatedDate
     */
    public Date getUpdatedDate() {
        return updatedDate;
    }

    /**
     * @param updatedDate
     *            the updatedDate to set
     */
    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    /**
     * @return the tiRequest
     */
    public TIRequest getTiRequest() {
        return tiRequest;
    }

    /**
     * @param tiRequest the tiRequest to set
     */
    public void setTiRequest(TIRequest tiRequest) {
        this.tiRequest = tiRequest;
    }
    
    

}
