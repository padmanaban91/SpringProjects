/**
 * 
 */
package com.citigroup.cgti.c3par.common.domain.soc.persist;

import java.util.List;
import java.util.Map;

import com.citigroup.cgti.c3par.admin.domain.ContactPopUpProcess;
import com.citigroup.cgti.c3par.admin.domain.LocationPopUpProcess;
import com.citigroup.cgti.c3par.persistance.Persistable;
import com.citigroup.cgti.c3par.relationship.domain.Location;
import com.citigroup.cgti.c3par.relationship.domain.Relationship;
import com.citigroup.cgti.c3par.relationship.domain.ThirdParty;
import com.citigroup.cgti.c3par.relationship.domain.ThirdPartyContact;
import com.citigroup.cgti.c3par.relationship.domain.ThirdPartySearchProcess;


/**
 * @author ne36745
 * 
 */
public interface ThirdPartyPersistable extends Persistable {

	List<ThirdParty> getThirdPartyList(String search);
	public void deleteThirdParty(Long id);
	List<ThirdPartyContact> getTpContactsForId(Long id);
	List<Location> getTpLocationsForId(Long id);
	List<Relationship> getTpRelationshipForId(Long id);
	ThirdPartyContact getThirdPartyForId(Long id);
	int getTpRelationshipForContact(long id);
	void deleteContactById(Long id);
	Location getLocation(Long id);
	Map<Long, String> getListofCountries();
	Map<Long,String> getListOfRegions();
	int getTpRelationshipForLocation(Long id);
	void deleteLocationById(Long id);
	void saveThirdPartyContact(ContactPopUpProcess contactPopUpProcess);
	void saveLocationDetails(LocationPopUpProcess locationPopUpProcess); 
	
	List<ThirdParty> loadThirdPartyProcessList(ThirdPartySearchProcess thirdPartySearchProcess);	
	Long saveThirdPartyDetails(ThirdParty thirdParty);
	
	int getRelationshipForCitiLocation(Long id);
	void deleteCitiLocationXrefById(Long id);
}
