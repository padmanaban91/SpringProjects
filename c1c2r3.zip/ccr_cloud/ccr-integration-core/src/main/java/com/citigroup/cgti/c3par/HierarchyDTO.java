package com.citigroup.cgti.c3par;





/**
 * The Class HierarchyDTO.
 */
@SuppressWarnings("unchecked")
public class HierarchyDTO implements Comparable {

    /** The name. */
    private String name;

    /** The business name. */
    private String businessName;

    /** The id. */
    private Long id;


    /**
     * Sets the name.
     *
     * @param name the new name
     */
    public void setName(String name){
	this.name = name;
    }

    /**
     * Gets the name.
     *
     * @return the name
     */
    public String getName(){
	return name;
    }

    /**
     * Sets the business name.
     *
     * @param businessName the new business name
     */
    public void setBusinessName(String businessName){
	this.businessName = businessName;
    }

    /**
     * Gets the business name.
     *
     * @return the business name
     */
    public String getBusinessName(){
	return businessName;
    }


    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id){
	this.id = id;
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    public Long getId(){
	return id;
    }


    /* (non-Javadoc)
     * @see java.lang.Comparable#compareTo(java.lang.Object)
     */
    public int compareTo(Object hierarchyDTO) throws ClassCastException {
	return this.getName().compareTo(((HierarchyDTO)hierarchyDTO).getName());
    }




}