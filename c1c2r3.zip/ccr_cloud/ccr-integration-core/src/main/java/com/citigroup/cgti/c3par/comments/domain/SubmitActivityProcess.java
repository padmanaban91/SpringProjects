package com.citigroup.cgti.c3par.comments.domain;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.appsense.domain.AppsenseADGroup;
import com.citigroup.cgti.c3par.bpm.ejb.domain.ProcessRFCDTO;
import com.citigroup.cgti.c3par.bpm.ejb.domain.RFCRequestDTO;
import com.citigroup.cgti.c3par.bpm.ejb.domain.TIProcessDTO;
import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.domain.LookUpVO;
import com.citigroup.cgti.c3par.domain.ProxyImplNotificationVO;
import com.citigroup.cgti.c3par.domain.ProxyImplementationVO;
import com.citigroup.cgti.c3par.domain.RisoTiRequestXref;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.dto.ChangeDetails;
import com.citigroup.cgti.c3par.dto.ServiceNowChangeDetails;
import com.citigroup.cgti.c3par.fw.domain.FAFRequest;
import com.citigroup.cgti.c3par.fw.domain.FafFirewallRule;
import com.citigroup.cgti.c3par.fw.domain.IPAddress;
import com.citigroup.cgti.c3par.fw.domain.Port;
import com.citigroup.cgti.c3par.proxy.domain.ProxyInstance;
import com.citigroup.cgti.c3par.soa.vc.util.OneApprovalConstants;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;
import com.citigroup.cgti.c3par.webtier.helper.Util;


public class SubmitActivityProcess {

    CCRBeanFactory ccrBeanFactory;
    {
        ApplicationContext appContext = CCRApplicationContextUtils.getApplicationContext();
        ccrBeanFactory = (CCRBeanFactory) appContext.getBean("cCRBeanFactory");
    }

    private static Logger LOGGER = Logger.getLogger(SubmitActivityProcess.class);

    private HashMap<String, String> roles;
    //Added a new variable to store riso approved - true or false. 
    //This variable is used to determine if the gis drop down option should show riso approval or temp approval.
    private String risoApproved;
    
    TIRequest tiReq;

    TIProcess tiProcess;

    private String rejectRole;

    private String provideInfoRole;

    private String movedRole;

    private TiRequestComments tiComments;

    private List<TiRequestComments> tiReqCmtsList;

    private List<TiRequestComments> discussCmtsList;

    private List<GenericLookup> risoApprovalList;

    private String risoSSOID;

    private String tempApprovalReason;

    private String raReNumber;

    private boolean bypassServiceNow = false;

    private List<GenericLookup> tempApprovalReasonsList;

    private List<GenericLookup> acvExtensionOptionsList;

    private String acvExtensionType;

    private int acvExtensionValue = 0;

    private String acvExtendedDate;

    /** The approval record count. */
    private int approvalRecordCount;

    /** The discussion record count. */
    private int discussionRecordCount;

    /** The comments. */
    private String comments;

    /** The app spl instrcomments. */
    private String appSplInstrcomments;

    /** The prx spl instrcomments. */
    private String prxSplInstrcomments;

    /** The firwall spl instrcomments. */
    private String firwallSplInstrcomments;

    /** The acl Var Spl Instrcomments. */
    private String aclVarSplInstrcomments;

    private String ipRegSplInstrcomments;

    /** The current action. */
    private String currentAction;

    /** The current role. */
    private String currentRole;

    /** The activity role. */
    private String activityRole;

    /** The activity instance id. */
    private String activityInstanceId;

    /** The current discussion page no. */
    private int currentDiscussionPageNo;

    /** The current approval page no. */
    private int currentApprovalPageNo;

    /** The iss connection compliance. */
    private String issConnectionCompliance;

    /** The security review comments. */
    private String securityReviewComments;

    /** The biso approval. */
    private boolean bisoApproval;

    /** The biso_assess_risk. */
    private String biso_assess_risk;

    /** The biso_assess_risk_other. */
    private String biso_assess_risk_other;

    /** The annual verification. */
    private String annualVerification;

    /** The SOW. */
    private String SOW;

    /** The proxy port number. */
    private String proxyPortNumber;

    /** The proxy ins name. */
    private String proxyInsName;

    /** The infoman id. */
    private Long infomanID;

    /** The op analyst schedule date. */
    private String opAnalystScheduleDate;

    /** The op analyst completed date. */
    private String opAnalystCompletedDate;

    /** The op analyst schedule time. */
    private String opAnalystScheduleTime;

    /** The op analyst completed time. */
    private String opAnalystCompletedTime;

    /** The infoman id. */
    private String changeNumber;

    /** The op analyst schedule date. */
    private String ipRegOpAnalystScheduleDate;

    /** The op analyst completed date. */
    private String ipRegOpAnalystCompletedDate;

    /** The op analyst schedule time. */
    private String ipRegOpAnalystScheduleTime;

    /** The op analyst completed time. */
    private String ipRegOpAnalystCompletedTime;

    /** The aps imp schedule date. */
    private String apsImpScheduleDate;

    /** The prx imp schedule date. */
    private String prxImpScheduleDate;

    /** The prx imp completed date. */
    private String prxImpCompletedDate;

    /** The aps imp completed date. */
    private String apsImpCompletedDate;

    /** The prx imp completed time. */
    private String prxImpCompletedTime;

    /** The aps imp completed time. */
    private String apsImpCompletedTime;

    /** The aps imp schedule time. */
    private String apsImpScheduleTime;

    /** The prx imp schedule time. */
    private String prxImpScheduleTime;

    /** The aps infoman id. */
    private Long apsInfomanID;

    /** The prx infoman id. */
    private Long prxInfomanID;

    /** The tpw review type. */
    private String tpwReviewType;

    /** The tpw review status. */
    private String tpwReviewStatus;

    /** The review sch date. */
    private String reviewSchDate;

    /** The review rej date. */
    private String reviewRejDate;

    /** The review temp date. */
    private String reviewTempDate;

    /** The review hold date */
    private String reviewHoldDate;

    private int recommendedLoggingPeriod;

    /** The maintenance con req id. */
    private Long maintenanceConReqId = null;

    /** The gncc imp completed time. */
    private String gnccImpCompletedTime;

    /** The gncc infoman id. */
    private Long gnccInfomanID;

    /** The gncc imp schedule time. */
    private String gnccImpScheduleTime;

    /** The gncc imp schedule date. */
    private String gnccImpScheduleDate;

    /** The gncc imp completed date. */
    private String gnccImpCompletedDate;

    /** The fireflow list. */
    private List fireflowList;

    /** The appsense policy master id. */
    private Long appsensePolicyMasterID;

    /** The dir apr comments. */
    private String dirAprComments;

    List<IPAddress> objectIPList;

    List<IPAddress> ipRegObjectIPList;

    private String ostiaRiskCheckByPassed;

    private String extendedDate;

    List<Port> objectPortList;

    List<Port> ipRegObjectPortList;

    /** The appsense policy id. */
    private String appsensePolicyID;

    /** The appsense policy name. */
    private String appsensePolicyName;

    /** The appsense policy status. */
    private String appsensePolicyStatus;

    private String appsenseADGroupName;

    /** The selected sup review roles. */
    private String[] selectedSupReviewRoles = null;

    /** The sup review roles. */
    private List<LookUpVO> supReviewRoles = null;

    /** The proxy instance list. */
    private List<ProxyInstance> proxyInstanceList;

    /** The PAC list. */
    private List<ProxyInstance> PACList;

    /** The process rfcdto. */
    private ProcessRFCDTO processRFCDTO;

    /** The appsense ad group id. */
    private Long appsenseADGroupID;

    /** The shared serv question. */
    private String sharedServQuestion;

    /** The shared serv answer. */
    private String sharedServAnswer;

    /** The is multiple rework roles. */
    private boolean isMultipleReworkRoles;

    /** The proxy instance. */
    private ProxyInstance proxyInstance;

    private TIProcessDTO tiprocessDTO;

    private Long requestID;

    private String taskCode;

    private String firewallType;

    private String proxyType;

    private String isACLVariance;

    private String isIPReg;

    private String appsenseType;

    private String completedOnBehalf;
    
    private String gisSpecialInstructions;
    
    private boolean nextCycleGISMandate = false;
    
    private List<ProxyImplementationVO> plugImplVOList;
    
    private List<ProxyImplementationVO> socksImplVOList;

    private String acvLogExpDate;

    private String tpaswgSpecialInstructions;
    
    private String validationWarning = "";
    
    private boolean deleteFlag;
    
    public String getIsACLVariance() {
        return isACLVariance;
    }

    public void setIsACLVariance(String isACLVariance) {
        this.isACLVariance = isACLVariance;
    }

    public String getIsIPReg() {
        return isIPReg;
    }

    public void setIsIPReg(String isIPReg) {
        this.isIPReg = isIPReg;
    }

    public String getAppsenseType() {
        return appsenseType;
    }

    public void setAppsenseType(String appsenseType) {
        this.appsenseType = appsenseType;
    }

    public String getFirewallType() {
        return firewallType;
    }

    public String getProxyType() {
        return proxyType;
    }

    public void setFirewallType(String firewallType) {
        this.firewallType = firewallType;
    }

    public void setProxyType(String proxyType) {
        this.proxyType = proxyType;
    }

    public String getRaReNumber() {
        return raReNumber;
    }

    public void setRaReNumber(String raReNumber) {
        this.raReNumber = raReNumber;
    }

    public List<TiRequestComments> getDiscussCmtsList() {
        return discussCmtsList;
    }

    public void setDiscussCmtsList(List<TiRequestComments> discussCmtsList) {
        this.discussCmtsList = discussCmtsList;
    }

    public List<TiRequestComments> getTiReqCmtsList() {
        return tiReqCmtsList;
    }

    public void setTiReqCmtsList(List<TiRequestComments> tiReqCmtsList) {
        this.tiReqCmtsList = tiReqCmtsList;
    }

    public String getMovedRole() {
        return movedRole;
    }

    public void setMovedRole(String movedRole) {
        this.movedRole = movedRole;
    }

    public String getRejectRole() {
        return rejectRole;
    }

    public void setRejectRole(String rejectRole) {
        this.rejectRole = rejectRole;
    }

    public String getProvideInfoRole() {
        return provideInfoRole;
    }

    public void setProvideInfoRole(String provideInfoRole) {
        this.provideInfoRole = provideInfoRole;
    }

    public TiRequestComments getTiComments() {
        return tiComments;
    }

    public void setTiComments(TiRequestComments tiComments) {
        this.tiComments = tiComments;
    }

    public TIRequest getTiReq() {
        return tiReq;
    }

    public void setTiReq(TIRequest tiReq) {
        this.tiReq = tiReq;
    }

    public TIProcess getTiProcess() {
        return tiProcess;
    }

    public void setTiProcess(TIProcess tiProcess) {
        this.tiProcess = tiProcess;
    }

    public List<LookUpVO> getSupReviewRoles() {
        return supReviewRoles;
    }

    public void setSupReviewRoles(List<LookUpVO> supReviewRoles) {
        this.supReviewRoles = supReviewRoles;
    }

    public HashMap<String, String> getRoles() {
        return roles;
    }

    public void setRoles(HashMap<String, String> roles) {
        this.roles = roles;
    }

    public int getApprovalRecordCount() {
        return approvalRecordCount;
    }

    public void setApprovalRecordCount(int approvalRecordCount) {
        this.approvalRecordCount = approvalRecordCount;
    }

    public int getDiscussionRecordCount() {
        return discussionRecordCount;
    }

    public void setDiscussionRecordCount(int discussionRecordCount) {
        this.discussionRecordCount = discussionRecordCount;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getAppSplInstrcomments() {
        return appSplInstrcomments;
    }

    public void setAppSplInstrcomments(String appSplInstrcomments) {
        this.appSplInstrcomments = appSplInstrcomments;
    }

    public String getPrxSplInstrcomments() {
        return prxSplInstrcomments;
    }

    public void setPrxSplInstrcomments(String prxSplInstrcomments) {
        this.prxSplInstrcomments = prxSplInstrcomments;
    }

    public String getFirwallSplInstrcomments() {
        return firwallSplInstrcomments;
    }

    public void setFirwallSplInstrcomments(String firwallSplInstrcomments) {
        this.firwallSplInstrcomments = firwallSplInstrcomments;
    }

    public String getAclVarSplInstrcomments() {
        return aclVarSplInstrcomments;
    }

    public void setAclVarSplInstrcomments(String aclVarSplInstrcomments) {
        this.aclVarSplInstrcomments = aclVarSplInstrcomments;
    }

    public String getIpRegSplInstrcomments() {
        return ipRegSplInstrcomments;
    }

    public void setIpRegSplInstrcomments(String ipRegSplInstrcomments) {
        this.ipRegSplInstrcomments = ipRegSplInstrcomments;
    }

    public String getCurrentAction() {
        return currentAction;
    }

    public void setCurrentAction(String currentAction) {
        this.currentAction = currentAction;
    }

    public String getCurrentRole() {
        return currentRole;
    }

    public void setCurrentRole(String currentRole) {
        this.currentRole = currentRole;
    }

    public String getActivityRole() {
        return activityRole;
    }

    public void setActivityRole(String activityRole) {
        this.activityRole = activityRole;
    }

    public String getActivityInstanceId() {
        return activityInstanceId;
    }

    public void setActivityInstanceId(String activityInstanceId) {
        this.activityInstanceId = activityInstanceId;
    }

    public int getCurrentDiscussionPageNo() {
        return currentDiscussionPageNo;
    }

    public void setCurrentDiscussionPageNo(int currentDiscussionPageNo) {
        this.currentDiscussionPageNo = currentDiscussionPageNo;
    }

    public int getCurrentApprovalPageNo() {
        return currentApprovalPageNo;
    }

    public void setCurrentApprovalPageNo(int currentApprovalPageNo) {
        this.currentApprovalPageNo = currentApprovalPageNo;
    }

    public String getIssConnectionCompliance() {
        return issConnectionCompliance;
    }

    public void setIssConnectionCompliance(String issConnectionCompliance) {
        this.issConnectionCompliance = issConnectionCompliance;
    }

    public String getSecurityReviewComments() {
        return securityReviewComments;
    }

    public void setSecurityReviewComments(String securityReviewComments) {
        this.securityReviewComments = securityReviewComments;
    }

    public boolean isBisoApproval() {
        return bisoApproval;
    }

    public void setBisoApproval(boolean bisoApproval) {
        this.bisoApproval = bisoApproval;
    }

    public String getBiso_assess_risk() {
        return biso_assess_risk;
    }

    public void setBiso_assess_risk(String biso_assess_risk) {
        this.biso_assess_risk = biso_assess_risk;
    }

    public String getBiso_assess_risk_other() {
        return biso_assess_risk_other;
    }

    public void setBiso_assess_risk_other(String biso_assess_risk_other) {
        this.biso_assess_risk_other = biso_assess_risk_other;
    }

    public String getAnnualVerification() {
        return annualVerification;
    }

    public void setAnnualVerification(String annualVerification) {
        this.annualVerification = annualVerification;
    }

    public String getSOW() {
        return SOW;
    }

    public void setSOW(String sOW) {
        SOW = sOW;
    }

    public String getProxyPortNumber() {
        return proxyPortNumber;
    }

    public void setProxyPortNumber(String proxyPortNumber) {
        this.proxyPortNumber = proxyPortNumber;
    }

    public String getProxyInsName() {
        return proxyInsName;
    }

    public void setProxyInsName(String proxyInsName) {
        this.proxyInsName = proxyInsName;
    }

    public Long getInfomanID() {
        return infomanID;
    }

    public void setInfomanID(Long infomanID) {
        this.infomanID = infomanID;
    }

    public String getOpAnalystScheduleDate() {
        return opAnalystScheduleDate;
    }

    public void setOpAnalystScheduleDate(String opAnalystScheduleDate) {
        this.opAnalystScheduleDate = opAnalystScheduleDate;
    }

    public String getOpAnalystCompletedDate() {
        return opAnalystCompletedDate;
    }

    public void setOpAnalystCompletedDate(String opAnalystCompletedDate) {
        this.opAnalystCompletedDate = opAnalystCompletedDate;
    }

    public String getOpAnalystScheduleTime() {
        return opAnalystScheduleTime;
    }

    public void setOpAnalystScheduleTime(String opAnalystScheduleTime) {
        this.opAnalystScheduleTime = opAnalystScheduleTime;
    }

    public String getOpAnalystCompletedTime() {
        return opAnalystCompletedTime;
    }

    public void setOpAnalystCompletedTime(String opAnalystCompletedTime) {
        this.opAnalystCompletedTime = opAnalystCompletedTime;
    }

    public String getChangeNumber() {
        return changeNumber;
    }

    public void setChangeNumber(String changeNumber) {
        this.changeNumber = changeNumber;
    }

    public String getIpRegOpAnalystScheduleDate() {
        return ipRegOpAnalystScheduleDate;
    }

    public void setIpRegOpAnalystScheduleDate(String ipRegOpAnalystScheduleDate) {
        this.ipRegOpAnalystScheduleDate = ipRegOpAnalystScheduleDate;
    }

    public String getIpRegOpAnalystCompletedDate() {
        return ipRegOpAnalystCompletedDate;
    }

    public void setIpRegOpAnalystCompletedDate(String ipRegOpAnalystCompletedDate) {
        this.ipRegOpAnalystCompletedDate = ipRegOpAnalystCompletedDate;
    }

    public String getIpRegOpAnalystScheduleTime() {
        return ipRegOpAnalystScheduleTime;
    }

    public void setIpRegOpAnalystScheduleTime(String ipRegOpAnalystScheduleTime) {
        this.ipRegOpAnalystScheduleTime = ipRegOpAnalystScheduleTime;
    }

    public String getIpRegOpAnalystCompletedTime() {
        return ipRegOpAnalystCompletedTime;
    }

    public void setIpRegOpAnalystCompletedTime(String ipRegOpAnalystCompletedTime) {
        this.ipRegOpAnalystCompletedTime = ipRegOpAnalystCompletedTime;
    }

    public String getApsImpScheduleDate() {
        return apsImpScheduleDate;
    }

    public void setApsImpScheduleDate(String apsImpScheduleDate) {
        this.apsImpScheduleDate = apsImpScheduleDate;
    }

    public String getPrxImpScheduleDate() {
        return prxImpScheduleDate;
    }

    public void setPrxImpScheduleDate(String prxImpScheduleDate) {
        this.prxImpScheduleDate = prxImpScheduleDate;
    }

    public String getPrxImpCompletedDate() {
        return prxImpCompletedDate;
    }

    public void setPrxImpCompletedDate(String prxImpCompletedDate) {
        this.prxImpCompletedDate = prxImpCompletedDate;
    }

    public String getApsImpCompletedDate() {
        return apsImpCompletedDate;
    }

    public void setApsImpCompletedDate(String apsImpCompletedDate) {
        this.apsImpCompletedDate = apsImpCompletedDate;
    }

    public String getPrxImpCompletedTime() {
        return prxImpCompletedTime;
    }

    public void setPrxImpCompletedTime(String prxImpCompletedTime) {
        this.prxImpCompletedTime = prxImpCompletedTime;
    }

    public String getApsImpCompletedTime() {
        return apsImpCompletedTime;
    }

    public void setApsImpCompletedTime(String apsImpCompletedTime) {
        this.apsImpCompletedTime = apsImpCompletedTime;
    }

    public String getApsImpScheduleTime() {
        return apsImpScheduleTime;
    }

    public void setApsImpScheduleTime(String apsImpScheduleTime) {
        this.apsImpScheduleTime = apsImpScheduleTime;
    }

    public String getPrxImpScheduleTime() {
        return prxImpScheduleTime;
    }

    public void setPrxImpScheduleTime(String prxImpScheduleTime) {
        this.prxImpScheduleTime = prxImpScheduleTime;
    }

    public Long getApsInfomanID() {
        return apsInfomanID;
    }

    public void setApsInfomanID(Long apsInfomanID) {
        this.apsInfomanID = apsInfomanID;
    }

    public Long getPrxInfomanID() {
        return prxInfomanID;
    }

    public void setPrxInfomanID(Long prxInfomanID) {
        this.prxInfomanID = prxInfomanID;
    }

    public String getTpwReviewType() {
        return tpwReviewType;
    }

    public void setTpwReviewType(String tpwReviewType) {
        this.tpwReviewType = tpwReviewType;
    }

    public String getTpwReviewStatus() {
        return tpwReviewStatus;
    }

    public void setTpwReviewStatus(String tpwReviewStatus) {
        this.tpwReviewStatus = tpwReviewStatus;
    }

    public String getReviewSchDate() {
        return reviewSchDate;
    }

    public void setReviewSchDate(String reviewSchDate) {
        this.reviewSchDate = reviewSchDate;
    }

    public String getReviewRejDate() {
        return reviewRejDate;
    }

    public void setReviewRejDate(String reviewRejDate) {
        this.reviewRejDate = reviewRejDate;
    }

    public String getReviewTempDate() {
        return reviewTempDate;
    }

    public void setReviewTempDate(String reviewTempDate) {
        this.reviewTempDate = reviewTempDate;
    }

    public String getReviewHoldDate() {
        return reviewHoldDate;
    }

    public void setReviewHoldDate(String reviewHoldDate) {
        this.reviewHoldDate = reviewHoldDate;
    }

    public int getRecommendedLoggingPeriod() {
        return recommendedLoggingPeriod;
    }

    public void setRecommendedLoggingPeriod(int recommendedLoggingPeriod) {
        this.recommendedLoggingPeriod = recommendedLoggingPeriod;
    }

    public Long getMaintenanceConReqId() {
        return maintenanceConReqId;
    }

    public void setMaintenanceConReqId(Long maintenanceConReqId) {
        this.maintenanceConReqId = maintenanceConReqId;
    }

    public String getGnccImpCompletedTime() {
        return gnccImpCompletedTime;
    }

    public void setGnccImpCompletedTime(String gnccImpCompletedTime) {
        this.gnccImpCompletedTime = gnccImpCompletedTime;
    }

    public Long getGnccInfomanID() {
        return gnccInfomanID;
    }

    public void setGnccInfomanID(Long gnccInfomanID) {
        this.gnccInfomanID = gnccInfomanID;
    }

    public String getGnccImpScheduleTime() {
        return gnccImpScheduleTime;
    }

    public void setGnccImpScheduleTime(String gnccImpScheduleTime) {
        this.gnccImpScheduleTime = gnccImpScheduleTime;
    }

    public String getGnccImpScheduleDate() {
        return gnccImpScheduleDate;
    }

    public void setGnccImpScheduleDate(String gnccImpScheduleDate) {
        this.gnccImpScheduleDate = gnccImpScheduleDate;
    }

    public String getGnccImpCompletedDate() {
        return gnccImpCompletedDate;
    }

    public void setGnccImpCompletedDate(String gnccImpCompletedDate) {
        this.gnccImpCompletedDate = gnccImpCompletedDate;
    }

    public List getFireflowList() {
        return fireflowList;
    }

    public void setFireflowList(List fireflowList) {
        this.fireflowList = fireflowList;
    }

    public Long getAppsensePolicyMasterID() {
        return appsensePolicyMasterID;
    }

    public void setAppsensePolicyMasterID(Long appsensePolicyMasterID) {
        this.appsensePolicyMasterID = appsensePolicyMasterID;
    }

    public String getDirAprComments() {
        return dirAprComments;
    }

    public void setDirAprComments(String dirAprComments) {
        this.dirAprComments = dirAprComments;
    }

    public List<IPAddress> getObjectIPList() {
        return objectIPList;
    }

    public void setObjectIPList(List<IPAddress> objectIPList) {
        this.objectIPList = objectIPList;
    }

    public List<IPAddress> getIpRegObjectIPList() {
        return ipRegObjectIPList;
    }

    public void setIpRegObjectIPList(List<IPAddress> ipRegObjectIPList) {
        this.ipRegObjectIPList = ipRegObjectIPList;
    }

    public String getOstiaRiskCheckByPassed() {
        return ostiaRiskCheckByPassed;
    }

    public void setOstiaRiskCheckByPassed(String ostiaRiskCheckByPassed) {
        this.ostiaRiskCheckByPassed = ostiaRiskCheckByPassed;
    }

    public String getExtendedDate() {
        return extendedDate;
    }

    public void setExtendedDate(String extendedDate) {
        this.extendedDate = extendedDate;
    }

    public List<Port> getObjectPortList() {
        return objectPortList;
    }

    public void setObjectPortList(List<Port> objectPortList) {
        this.objectPortList = objectPortList;
    }

    public List<Port> getIpRegObjectPortList() {
        return ipRegObjectPortList;
    }

    public void setIpRegObjectPortList(List<Port> ipRegObjectPortList) {
        this.ipRegObjectPortList = ipRegObjectPortList;
    }

    public String getAppsensePolicyID() {
        return appsensePolicyID;
    }

    public void setAppsensePolicyID(String appsensePolicyID) {
        this.appsensePolicyID = appsensePolicyID;
    }

    public String getAppsensePolicyName() {
        return appsensePolicyName;
    }

    public void setAppsensePolicyName(String appsensePolicyName) {
        this.appsensePolicyName = appsensePolicyName;
    }

    public String getAppsensePolicyStatus() {
        return appsensePolicyStatus;
    }

    public void setAppsensePolicyStatus(String appsensePolicyStatus) {
        this.appsensePolicyStatus = appsensePolicyStatus;
    }

    public String getAppsenseADGroupName() {
        return appsenseADGroupName;
    }

    public void setAppsenseADGroupName(String appsenseADGroupName) {
        this.appsenseADGroupName = appsenseADGroupName;
    }

    public String getRisoSSOID() {
        return risoSSOID;
    }

    public void setRisoSSOID(String risoSSOID) {
        this.risoSSOID = risoSSOID;
    }

    public String getTempApprovalReason() {
        return tempApprovalReason;
    }

    public void setTempApprovalReason(String tempApprovalReason) {
        this.tempApprovalReason = tempApprovalReason;
    }

    public List<ProxyInstance> getProxyInstanceList() {
        return proxyInstanceList;
    }

    public void setProxyInstanceList(List<ProxyInstance> proxyInstanceList) {
        this.proxyInstanceList = proxyInstanceList;
    }

    public List<ProxyInstance> getPACList() {
        return PACList;
    }

    public void setPACList(List<ProxyInstance> pACList) {
        PACList = pACList;
    }

    public ProcessRFCDTO getProcessRFCDTO() {
        return processRFCDTO;
    }

    public void setProcessRFCDTO(ProcessRFCDTO processRFCDTO) {
        this.processRFCDTO = processRFCDTO;
    }

    public String[] getSelectedSupReviewRoles() {
        return selectedSupReviewRoles;
    }

    public void setSelectedSupReviewRoles(String[] selectedSupReviewRoles) {
        this.selectedSupReviewRoles = selectedSupReviewRoles;
    }

    public Long getAppsenseADGroupID() {
        return appsenseADGroupID;
    }

    public void setAppsenseADGroupID(Long appsenseADGroupID) {
        this.appsenseADGroupID = appsenseADGroupID;
    }

    public String getSharedServQuestion() {
        return sharedServQuestion;
    }

    public void setSharedServQuestion(String sharedServQuestion) {
        this.sharedServQuestion = sharedServQuestion;
    }

    public String getSharedServAnswer() {
        return sharedServAnswer;
    }

    public void setSharedServAnswer(String sharedServAnswer) {
        this.sharedServAnswer = sharedServAnswer;
    }

    public boolean isMultipleReworkRoles() {
        return isMultipleReworkRoles;
    }

    public void setMultipleReworkRoles(boolean isMultipleReworkRoles) {
        this.isMultipleReworkRoles = isMultipleReworkRoles;
    }

    public ProxyInstance getProxyInstance() {
        return proxyInstance;
    }

    public void setProxyInstance(ProxyInstance proxyInstance) {
        this.proxyInstance = proxyInstance;
    }

    public List<GenericLookup> getRisoApprovalList() {
        return risoApprovalList;
    }

    public void setRisoApprovalList(List<GenericLookup> risoApprovalList) {
        this.risoApprovalList = risoApprovalList;
    }

    public List<GenericLookup> getTempApprovalReasonsList() {
        return tempApprovalReasonsList;
    }

    public void setTempApprovalReasonsList(List<GenericLookup> tempApprovalReasonsList) {
        this.tempApprovalReasonsList = tempApprovalReasonsList;
    }

    public List<String> getSelectedSupReviewRoles(Long tiReq, String role) {
        return ccrBeanFactory.getSubmitActivityPersistable().getSelectedSupReviewRoles(tiReq, role);
    }

    public HashMap<String, String> findInstanceId(Long tiRequestId, Long activityId) {
        return ccrBeanFactory.getSubmitActivityPersistable().findInstanceId(tiRequestId, activityId);
    }

    public List<LookUpVO> getSupReviewRoles(String role) {
        return ccrBeanFactory.getSubmitActivityPersistable().getSupReviewRoles(role);
    }

    public String getSharedServAttestation(Long tiRequestId, String con_type) {
        String ssAnswer = ccrBeanFactory.getRfc().getSharedServiceAttestationAnswer(tiRequestId, con_type);
        return ssAnswer;
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public void insertSharedServAttestation(Long tiRequestId, String ssAnswer) {
        ccrBeanFactory.getRfc().storeSharedServAttestation(tiRequestId, ssAnswer);
    }

    public TIProcess getProcessData(long requestID) throws Exception {
        return ccrBeanFactory.getManageTIProcess().getProcessData(requestID, null, null);
    }

    public TIRequest getTIRequest(long tiRequestId) {
        return ccrBeanFactory.getSubmitActivityPersistable().getTIRequest(tiRequestId);
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public boolean deleteSupReviewRoles(Long tiReq, String roleName) {
        return ccrBeanFactory.getSubmitActivityPersistable().deleteSupReviewRoles(tiReq, roleName);
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public boolean insertSupReviewRoles(Long tiReq, String roleName, String[] suppRole) {
        return ccrBeanFactory.getSubmitActivityPersistable().insertSupReviewRoles(tiReq, roleName, suppRole);
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public boolean specialInstructionUpdate(long tiReq, String apsSplInstruction, String prxSplInstruction,
            String firewallSplInstruction, String ipRegSplInstrcomments, String aclVarSplInstruction) {
        return ccrBeanFactory.getSubmitActivityPersistable().specialInstructionUpdate(tiReq, apsSplInstruction,
                prxSplInstruction, firewallSplInstruction, ipRegSplInstrcomments, aclVarSplInstruction);
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public void addComments(TiRequestComments tiReqComments, String commentType, String actionType) {
        ccrBeanFactory.getSubmitActivityPersistable().addComments(tiReqComments, commentType, actionType);
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public void addSpecialInstructions(String specialInstructions, long tiRequestId, String userId, String specialInstructionsBy) {
        ccrBeanFactory.getSubmitActivityPersistable().addSpecialInstructions(specialInstructions, getTIRequest(tiRequestId), userId, specialInstructionsBy);
    }
    
    public List<TiRequestComments> getComments(Long tiReq, String role, String commentType) {
        return ccrBeanFactory.getSubmitActivityPersistable().getComments(tiReq, role, commentType);
    }

    public Long getPlanningId(Long tirequestid) {
        return ccrBeanFactory.getCommonServicePersistable().getPlanningIdForTiRequestId(tirequestid);
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public void isoInformationUpdate(long tiReq, String issCompliance, String accessRisk, Long planningID) {
        ccrBeanFactory.getSubmitActivityPersistable()
                .isoInformationUpdate(tiReq, issCompliance, accessRisk, planningID);
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public void verifySOWUpdate(long tiRequestId, String verificationFlag, String SOW) {
        ccrBeanFactory.getSubmitActivityPersistable().verifySOWUpdate(tiRequestId, verificationFlag, SOW);
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public void tpwgUpdate(long tiRequestId, String reviewType, String reviewStatus, String scheduleDate,
            String rejectedDate, String reviewTempDate) {
        ccrBeanFactory.getSubmitActivityPersistable().tpwgUpdate(tiRequestId, reviewType, reviewStatus, scheduleDate,
                rejectedDate, reviewTempDate);
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public void updateLoggingDetails(long tiRequestId, String loggingDate, int recommendedLoggingPeriod) {
        ccrBeanFactory.getSubmitActivityPersistable().updateLoggingDetails(tiRequestId, loggingDate,
                recommendedLoggingPeriod);
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public void updateOstiaQuestionairre(Long tiRequestId) {
        ccrBeanFactory.getSubmitActivityPersistable().updateOstiaQuestionairre(tiRequestId);
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public void gnccImpUpdate(long tireq, Long infomanID, String schTsmp, String compTsmp) {
        ccrBeanFactory.getSubmitActivityPersistable().gnccImpUpdate(tireq, infomanID, schTsmp, compTsmp);
    }

    public String getRFCERequestErrorLog(Long rfcId) {
        return ccrBeanFactory.getRfc().getRFCRequestErrorLog(rfcId);
    }

    public Map<String, String> getRFCRequestFlag(Long tiRequestId) {
        return ccrBeanFactory.getRfc().getRFCRequestFlag(tiRequestId);
    }

    public String getRFCReqManualFlag(Long tiRequestId) {
        return ccrBeanFactory.getRfc().getRFCReqManualFlag(tiRequestId);
    }

    public List<Object[]> getRFCRequestList(Long ti_request_id, boolean createTypeFlag, String conType)
            throws Exception {
        return ccrBeanFactory.getRfc().getRFCRequestData(ti_request_id, createTypeFlag, conType);
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public List<RFCRequestDTO> updateRFCId(ProcessRFCDTO processRFCDTO) {
        return ccrBeanFactory.getRfc().storeRFCId(processRFCDTO);
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public void ipRegopAnalystUpdate(long tiReq, String changeNo, String schTsmp, String compTsmp) {
        ccrBeanFactory.getSubmitActivityPersistable().ipRegopAnalystUpdate(tiReq, changeNo, schTsmp, compTsmp);
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public void proxyImpUpdate(long tiReq, String schTsmp, String compTsmp) {
        ccrBeanFactory.getSubmitActivityPersistable().proxyImpUpdate(tiReq, schTsmp, compTsmp);
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public void sendCommentsEmail(Long tiRequestId, String activityCode, String comments, String extendedDate) {
        ccrBeanFactory.getMailModuleImpl().sendCommentsEmail(tiRequestId, activityCode, comments, extendedDate);
    }

    public void sendRisoEmail(Long tiRequestId, String gisCmnts, boolean isGis, boolean isSendOneApproval, String activityCode) {
        RisoTiRequestXref risoContact = null;
        CitiContact risoCitiContact = null;
        if(StringUtils.isNotEmpty(this.getRisoSSOID())){
            risoContact = ccrBeanFactory.getSubmitActivityPersistable().addRisoXref(tiRequestId, this.getRisoSSOID());
        }else{
            risoContact = ccrBeanFactory.getSubmitActivityPersistable().getRisoTiRequestXref(tiRequestId);
            LOGGER.info("risoContact id : "+risoContact.getId());
        }
        risoCitiContact = risoContact.getCitiContact();
        
        ccrBeanFactory.getMailModuleImpl().sendRisoEmail(tiRequestId, gisCmnts, risoCitiContact, isGis, isSendOneApproval,activityCode);
    }
    
    public RisoTiRequestXref getRisoXref(Long tiRequestId) {
        return ccrBeanFactory.getSubmitActivityPersistable().getRisoTiRequestXref(tiRequestId);
    }
    
    public void cancelOneApproval(Long tiRequestId){
        TIRequest tiRequest = ccrBeanFactory.getCommonServicePersistable().getTiRequestById(tiRequestId);
        ccrBeanFactory.getOneApprovalPersistable().createOneApproval(tiRequest.getTiProcess().getId(), tiRequestId, null, 
                tiRequest.getTiProcess().getVersionNo(), OneApprovalConstants.ACTIVITY_RISO_APP, true,"");
    }
    
    public void addRisoContactXref(Long tiRequestId) {
        if(StringUtils.isNotEmpty(this.getRisoSSOID())){
            RisoTiRequestXref risoContact = ccrBeanFactory.getSubmitActivityPersistable().addRisoXref(tiRequestId, this.getRisoSSOID());
            LOGGER.info("risoContact id : "+risoContact.getId());
        }
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public void tpwgtempAppDateUpdate(long tiReq) {
        ccrBeanFactory.getSubmitActivityPersistable().tpwgtempAppDateUpdate(tiReq);
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public void appsenseImpUpdate(long tiReq, Long infomanID, String schTsmp, String compTsmp) {
        ccrBeanFactory.getSubmitActivityPersistable().appsenseImpUpdate(tiReq, infomanID, schTsmp, compTsmp);
    }

    public String validateADGroupName(AppsenseADGroup appsenseADGroup) {
        return ccrBeanFactory.getSubmitActivityPersistable().validateADGroupName(appsenseADGroup);
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public void updateAppsensePolicyID(String policyName, String policyId, String ADGroupName, Long appsId) {
        ccrBeanFactory.getSubmitActivityPersistable().updateAppsensePolicyID(policyName, policyId, ADGroupName, appsId);
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public void opAnalystUpdate(long tiReq, String schTsmp, String compTsmp) {
        ccrBeanFactory.getSubmitActivityPersistable().opAnalystUpdate(tiReq, schTsmp, compTsmp);
    }

    public List<LookUpVO> getTPASWGReviewStatus() {
        return ccrBeanFactory.getSubmitActivityPersistable().getTPASWGReviewStatus();
    }

    public List<LookUpVO> getTPASWGReviewType() {
        return ccrBeanFactory.getSubmitActivityPersistable().getTPASWGReviewType();
    }

    public String isUTurnConnection(long tiRequestId) {
        return ccrBeanFactory.getSubmitActivityPersistable().isUTurnConnection(tiRequestId);
    }

    /**
     * @param processid
     * @return
     */
    public List<ProxyInstance> getProxyInstancesToModify(Long processid) {
        return ccrBeanFactory.getProxyPersistable().getProxyInstancesToModify(processid);
    }
    
    /**
     * @param tiRequestId
     * @return
     */
    public List<ProxyImplementationVO> getListOfCombinations_PLUG(Long tiRequestId){
        return ccrBeanFactory.getProxyPersistable().getListOfCombinations_PLUG(tiRequestId);
    }
    
    
   /**
    * @param tiRequestId
    * @return
    */
   public List<ProxyImplNotificationVO> getListOfCombinations(Long tiRequestId){
       LOGGER.debug("Getting list of combinations for :: "+tiRequestId);
       List<ProxyImplNotificationVO> proxyImplNotificationVOList = new ArrayList<ProxyImplNotificationVO>();
       List<ProxyImplementationVO> proxyImplVoList = ccrBeanFactory.getProxyPersistable().getListOfCombinations(tiRequestId);
       ProxyImplNotificationVO tempProxyImplNotificationVO = null;
       String tempProxyInstanceName = "";
       for(ProxyImplementationVO currRec:proxyImplVoList){
           
           if(!tempProxyInstanceName.equalsIgnoreCase(currRec.getProxyInstName())){
               if(null!=tempProxyImplNotificationVO){
                   proxyImplNotificationVOList.add(tempProxyImplNotificationVO);
               }
              
               //create a new record.
               tempProxyImplNotificationVO = new ProxyImplNotificationVO();
               tempProxyImplNotificationVO.setType(currRec.getRecordType());
               tempProxyImplNotificationVO.setRegion(currRec.getProxyInstRegion());
               tempProxyImplNotificationVO.setProxyInstanceName(currRec.getProxyInstName());
               tempProxyImplNotificationVO.setProxyInstanceDesc(currRec.getProxyInstDesc());
               LOGGER.debug("Proxy Instance name is "+ currRec.getProxyInstName());
               tempProxyImplNotificationVO.setIpAddressList(new Util().getProxySockIpList(currRec.getProxyInstName()));
               
               
           }
           tempProxyInstanceName = currRec.getProxyInstName();
           if(null!=tempProxyImplNotificationVO.getProxyImplVOList()){
               tempProxyImplNotificationVO.getProxyImplVOList().add(currRec);
           }else{
               List<ProxyImplementationVO> tempVo = new ArrayList<ProxyImplementationVO>();
               tempVo.add(currRec);
               tempProxyImplNotificationVO.setProxyImplVOList(tempVo);
           }
           
       }
       //add this for the last iteration.
       proxyImplNotificationVOList.add(tempProxyImplNotificationVO);
       return proxyImplNotificationVOList;
   }
   
    /**
     * @param tiRequestId
     * @return
     */
    public List<ProxyImplementationVO> getListOfCombinations_SOCKS(Long tiRequestId){
        return ccrBeanFactory.getProxyPersistable().getListOfCombinations_SOCKS(tiRequestId);
    }

    public void saveProxyImplementationVOList(List<ProxyImplementationVO> proxyImplVOList,Long tiRequestId){
        ccrBeanFactory.getProxyPersistable().saveProxyImplementationVOList(proxyImplVOList, tiRequestId);
    }
    
    public List<ProxyInstance> getPACToModify(Long processid) {
        return ccrBeanFactory.getProxyPersistable().getPACToModify(processid);
    }

    public ProxyInstance getInstanceforPAC(long PACInstanceId) {
        return ccrBeanFactory.getProxyPersistable().getInstanceforPAC(PACInstanceId);
    }

    public boolean isPACLocked(long PACInstanceId) {
        return ccrBeanFactory.getProxyPersistable().isPACLocked(PACInstanceId);
    }

    public String validateProxyInstance(List<ProxyInstance> proxyInstanceList) throws Exception {
        return ccrBeanFactory.getProxyPersistable().validateProxyInstance(proxyInstanceList);
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public void updateRisoDetails(long tiRequestId, String tempApp, String raReNo) {
        ccrBeanFactory.getSubmitActivityPersistable().updateRisoDetails(tiRequestId, tempApp, raReNo);
    }

    public List<GenericLookup> getRISOEmail() {
        return ccrBeanFactory.getSubmitActivityPersistable().getRISOEmail();
    }

    public List<GenericLookup> getACVExtensionOptions() {
        return ccrBeanFactory.getSubmitActivityPersistable().getACVExtensionOptions();
    }

    @Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
    public CitiContact getUserIdForSsoId(String ssoid) {
        return ccrBeanFactory.getCmpRequestPersistable().getUserIdForSsoId(ssoid);
    }
    
    @Transactional(readOnly = true)
    public CitiContact getUserIdForEmailId(String emailId) {
        return ccrBeanFactory.getCmpRequestPersistable().getUserIdForEmailId(emailId);
    }
    
    public ServiceNowChangeDetails getSericeNowChangeStatus(Long tiRequestId, String rfcType){
        return ccrBeanFactory.getSubmitActivityPersistable().getSericeNowChangeStatus(tiRequestId, rfcType);
    }
    
    public String getChangeNumbers(List<ChangeDetails> changeNumbersList){
        StringBuilder builder = new StringBuilder();
        String changeNumbers = "";
        if(CollectionUtils.isNotEmpty(changeNumbersList)){
            for(ChangeDetails changeDetails : changeNumbersList){
                builder.append(changeDetails.getChangeNumber()).append(", ");
            }
            changeNumbers = StringUtils.removeEnd(builder.toString(), ", ");
        }
        LOGGER.info("Returing with changeNumbers : "+changeNumbers);
        return changeNumbers;
    }

    public List<GenericLookup> getTempApprovalReasons() {
        return ccrBeanFactory.getSubmitActivityPersistable().getTempApprovalReasons();
    }

    public TIProcessDTO getTiprocessDTO() {
        if (getRequestID() != null && this.tiprocessDTO == null) {
            try {
                this.tiprocessDTO = ccrBeanFactory.getManageTIProcess().getProcessDTO(getRequestID(), "", null);
            } catch (Exception e) {
                LOGGER.error(e.toString(), e);
            }
        }
        return this.tiprocessDTO;
    }

    public void setTiprocessDTO(TIProcessDTO tiprocessDTO) {
        this.tiprocessDTO = tiprocessDTO;
    }

    public Long getRequestID() {
        return requestID;
    }

    public void setRequestID(Long requestID) {
        this.requestID = requestID;
    }

    public String getTaskCode() {
        return taskCode;
    }

    public void setTaskCode(String taskCode) {
        this.taskCode = taskCode;
    }

    public boolean isBypassServiceNow() {
        return bypassServiceNow;
    }

    public void setBypassServiceNow(boolean bypassServiceNow) {
        this.bypassServiceNow = bypassServiceNow;
    }

    public List<GenericLookup> getAcvExtensionOptionsList() {
        return acvExtensionOptionsList;
    }

    public void setAcvExtensionOptionsList(List<GenericLookup> acvExtensionOptionsList) {
        this.acvExtensionOptionsList = acvExtensionOptionsList;
    }

    public String getAcvExtensionType() {
        return acvExtensionType;
    }

    public void setAcvExtensionType(String acvExtensionType) {
        this.acvExtensionType = acvExtensionType;
    }

    public int getAcvExtensionValue() {
        return acvExtensionValue;
    }

    public void setAcvExtensionValue(int acvExtensionValue) {
        this.acvExtensionValue = acvExtensionValue;
    }

    public String getAcvExtendedDate() {
        return acvExtendedDate;
    }

    public void setAcvExtendedDate(String acvExtendedDate) {
        this.acvExtendedDate = acvExtendedDate;
    }

    /**
     * @return the completedOnBehalf
     */
    public String getCompletedOnBehalf() {
        return completedOnBehalf;
    }

    /**
     * @param completedOnBehalf
     *            the completedOnBehalf to set
     */
    public void setCompletedOnBehalf(String completedOnBehalf) {
        this.completedOnBehalf = completedOnBehalf;
    }
    
    public String getGisSpecialInstructions() {
        return gisSpecialInstructions;
    }

    public void setGisSpecialInstructions(String gisSpecialInstructions) {
        this.gisSpecialInstructions = gisSpecialInstructions;
    }

    public String getRisoApproved() {
        return risoApproved;
    }

    public void setRisoApproved(String risoApproved) {
        this.risoApproved = risoApproved;
    }
    
    public String checkRisoApprovedFlag(Long tiRequestId){
        return ccrBeanFactory.getSubmitActivityPersistable().isRISOApproved(tiRequestId);
    }
    
    public TIRequest fetchTemporaryApprovalDetails(Long tiRequestId){
        return ccrBeanFactory.getSubmitActivityPersistable().getTIRequest(tiRequestId);
    }
    
    @Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public void updateACVLoggingExpDate(long tiReqId, String acvLogExpDate) {
        ccrBeanFactory.getSubmitActivityPersistable().updateACVLoggingExpDate(tiReqId, acvLogExpDate);
    }
    
    public List<ProxyImplementationVO> getPlugImplVOList() {
        return plugImplVOList;
    }

    public void setPlugImplVOList(List<ProxyImplementationVO> plugImplVOList) {
        this.plugImplVOList = plugImplVOList;
    }

    public List<ProxyImplementationVO> getSocksImplVOList() {
        return socksImplVOList;
    }

    public void setSocksImplVOList(List<ProxyImplementationVO> socksImplVOList) {
        this.socksImplVOList = socksImplVOList;
    }
    
    public String getAcvLogExpDate() {
        return acvLogExpDate;
    }

    public void setAcvLogExpDate(String acvLogExpDate) {
        this.acvLogExpDate = acvLogExpDate;
    }
    
    public String getTpaswgSpecialInstructions(){
        return tpaswgSpecialInstructions;
    }
    
    public void setTpaswgSpecialInstructions(String tpaswgSpecialInstructions){
        this.tpaswgSpecialInstructions = tpaswgSpecialInstructions;
    }

    public boolean isNextCycleGISMandate() {
        return nextCycleGISMandate;
    }

    public void setNextCycleGISMandate(boolean nextCycleGISMandate) {
        this.nextCycleGISMandate = nextCycleGISMandate;
    }
    
    public String getValidationWarning() {
        return validationWarning;
    }

    public void setValidationWarning(String validationWarning) {
        this.validationWarning = validationWarning;
    }

  
    public void sendEmailTempApp(Long tiRequestId, String activityCode, String comments, String extendedDate) {
        ccrBeanFactory.getMailModuleImpl().sendEmailTempApp(tiRequestId, activityCode, comments, extendedDate);
    }

    public boolean isDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(boolean deleteFlag) {
        this.deleteFlag = deleteFlag;
    }
    
    /**
     * Method to check whether Firewall/IPReg rule is deleted in this Cycle
     * @param tiRequestId
     * @return deleteFlag
     */
    @Transactional(readOnly = true)
    public boolean checkForDeleteRule(Long tiRequestId) {
        boolean deleteFlag = false;
        FAFRequest fafRequest = new FAFRequest();
        fafRequest.setTiRequest(tiRequestId);
        fafRequest.setType("N");
        fafRequest.setIsIPReg("N");
        List<FafFirewallRule> rules = fafRequest.findRequestedRulesByRequest();
        if (rules != null && !rules.isEmpty()) {
            for (FafFirewallRule rule : rules) {
                if ("D".equals(String.valueOf(rule.getFafFireFlowTicket().getType()))) {
                    deleteFlag = true;
                    break;
                }
            }
        }
        fafRequest.setIsIPReg("Y");
        rules = fafRequest.findRequestedRulesByRequest();
        if (rules != null && !rules.isEmpty()) {
            for (FafFirewallRule rule : rules) {
                if ("D".equals(String.valueOf(rule.getFafFireFlowTicket().getType()))) {
                    deleteFlag = true;
                    break;
                }
            }
        }
        // 97896 - Ends
        LOGGER.debug("Contains delete rules: " + deleteFlag);
        return deleteFlag;
    }
    
    public void sendReconAdminEmail(Long tiRequestId, String gisCmnts, boolean isGis, boolean isSendOneApproval) {
       LOGGER.info("Mail contacts fetch logic to be added for Recon Admin");
       CitiContact reconAdminCitiContact = null;
       ccrBeanFactory.getMailModuleImpl().sendReconAdminEmail(tiRequestId, gisCmnts, reconAdminCitiContact, isGis, isSendOneApproval);
    	
    }
    
    public void expandRulesAndSave(Long tiRequestId){
        ccrBeanFactory.getSubmitActivityPersistable().expandRulesAndSave(tiRequestId);
    }
    
    public void deleteExpandedRules(Long tiRequestId){
        ccrBeanFactory.getSubmitActivityPersistable().deleteExpandedRules(tiRequestId);
    }
    

}