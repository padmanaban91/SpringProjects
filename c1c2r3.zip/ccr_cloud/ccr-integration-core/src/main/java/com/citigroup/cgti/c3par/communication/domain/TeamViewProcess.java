package com.citigroup.cgti.c3par.communication.domain;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.bpm.ejb.domain.TIProcessDTO;
import com.citigroup.cgti.c3par.bpm.ejb.manageprocess.IManageTIProcess;
import com.citigroup.cgti.c3par.common.domain.soc.persist.AdminServicePersistable;
import com.citigroup.cgti.c3par.communication.domain.service.EcmUserPreferenceDaoService;
import com.citigroup.cgti.c3par.communication.domain.soc.persist.TeamViewPersistable;
import com.citigroup.cgti.c3par.soa.vc.logic.RFCService;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

public class TeamViewProcess {

    CCRBeanFactory ccrBeanFactory;

    {
        ApplicationContext appContext = CCRApplicationContextUtils.getApplicationContext();
        ccrBeanFactory = (CCRBeanFactory) appContext.getBean("cCRBeanFactory");
    }

    @Autowired
    private RFCService rfc;

    private CMPRequest resolveITMessage;

    private List<CMPRequest> cmpRequestMessageList;

    private List<TeamView> teamViewDetailsList;
    
    private List<String> columnList;

    private String team;

    private String servicenowURL;
    // pagination properties
    private int limit;
    private int rowCount;
    private int offset;

    private int pageNo;
    private String field;
    private int totalPages;

    private int recordStartCount;
    private int recordEndCount;
    private int totalRecords;

    private String orderBy;
    private String sortingColumnName;

    private String errorMessage;

    private String selectedColumnName;

    private String sameColumnSelected;

    private TIProcessDTO tiProcessDTO;

    private String lastNameFiler;

    private List<String> lastNameList;

    private List<String> sectorList;

    private String sectorFiler;

    private String filterColumn;

    private String filterValue;
    
    private List<String> viewColumnNamesList;
    
    private String ssoId;
    
    private String view;
    private Long columnIndex;
    private String sortBy;
    private Long resultPerPage;
    private String ecomType;
    
    private Map<Long,String> map=new LinkedHashMap<Long,String>();

    public String getSectorFiler() {
        return sectorFiler;
    }

    public void setSectorFiler(String sectorFiler) {
        this.sectorFiler = sectorFiler;
    }

    public List<String> getSectorList() {
        return ccrBeanFactory.getTeamViewPersistable().getSectorList();
    }

    public void setSectorList(List<String> sectorList) {
        this.sectorList = sectorList;
    }

	public List<TeamView> getTeamCmpReqData(boolean isExport) throws Exception {
		EcmUserPreferenceDaoService ecmUserPreferenceDaoService = ccrBeanFactory.getEcmUserPreferenceDaoService();
		EcmUserSetting ecmUserSetting = ecmUserPreferenceDaoService.getUseSetting(this.getTeam(),
				ECMConstants.ECM_TEAM_VIEW);
		List<ColumnsSortOrderSettings> ecmColumnsOrderSettingsList = new ArrayList<ColumnsSortOrderSettings>();
		if (ecmUserSetting != null) {
			ecmColumnsOrderSettingsList = ecmUserPreferenceDaoService.getEcmColumnsOrderSetting(ecmUserSetting.getId());
		}
		return ccrBeanFactory.getTeamViewPersistable().getTeamViewCmpReqData(this, isExport,
				ecmColumnsOrderSettingsList);
	}

    public List<CCRCMPXref> getCcrCmpXref(String orderItemId) {
        return ccrBeanFactory.getAgentViewPersistable().getCcrCmpXref(orderItemId);
    }

    public List<String> getAssignedLastNameList() {
        return ccrBeanFactory.getTeamViewPersistable().getAssignedLastNameList();
    }

    public Long getUserId(String ssoId) {
        return ccrBeanFactory.getAdminServicePersistable().getUserId(ssoId);
    }

    public String getSnUrl() {
        return ccrBeanFactory.getRfc().getSnUrl();
    }

    public String getTeam() {
        return team;
    }

    public void setTeam(String team) {
        this.team = team;
    }
    

    public Long getColumnIndex() {
		return columnIndex;
	}

	public void setColumnIndex(Long columnIndex) {
		this.columnIndex = columnIndex;
	}

	public String getSortBy() {
		return sortBy;
	}

	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}

	public Long getResultPerPage() {
		return resultPerPage;
	}

	public void setResultPerPage(Long resultPerPage) {
		this.resultPerPage = resultPerPage;
	}

	public TeamViewPersistable getTeamViewPersistable() {
        return ccrBeanFactory.getTeamViewPersistable();
    }

    public AdminServicePersistable getAdminServicePersistable() {
        return ccrBeanFactory.getAdminServicePersistable();
    }

    public List<CMPRequest> getCmpRequestMessageList() {
        return cmpRequestMessageList;
    }

    public void setCmpRequestMessageList(List<CMPRequest> cmpRequestMessageList) {
        this.cmpRequestMessageList = cmpRequestMessageList;
    }

    public List<TeamView> getTeamViewDetailsList() {
        return teamViewDetailsList;
    }

    public void setTeamViewDetailsList(List<TeamView> teamViewDetailsList) {
        this.teamViewDetailsList = teamViewDetailsList;
    }

    public IManageTIProcess getManageTIProcessImpl() {
        return ccrBeanFactory.getManageTIProcess();
    }

    public CMPRequest getResolveITMessage() {
        return resolveITMessage;
    }

    public void setResolveITMessage(CMPRequest resolveITMessage) {
        this.resolveITMessage = resolveITMessage;
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }

    public int getRowCount() {
        return rowCount;
    }

    public void setRowCount(int rowCount) {
        this.rowCount = rowCount;
    }

    public int getOffset() {
        return offset;
    }

    public void setOffset(int offset) {
        this.offset = offset;
    }

    public int getPageNo() {
        return pageNo;
    }

    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public int getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(int totalPages) {
        this.totalPages = totalPages;
    }

    public int getRecordStartCount() {
        return recordStartCount;
    }

    public void setRecordStartCount(int recordStartCount) {
        this.recordStartCount = recordStartCount;
    }

    public int getRecordEndCount() {
        return recordEndCount;
    }

    public void setRecordEndCount(int recordEndCount) {
        this.recordEndCount = recordEndCount;
    }

    public int getTotalRecords() {
        return totalRecords;
    }

    public void setTotalRecords(int totalRecords) {
        this.totalRecords = totalRecords;
    }

    public String getOrderBy() {
        return orderBy;
    }

    public void setOrderBy(String orderBy) {
        this.orderBy = orderBy;
    }

    public String getSortingColumnName() {
        return sortingColumnName;
    }

    public void setSortingColumnName(String sortingColumnName) {
        this.sortingColumnName = sortingColumnName;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getSelectedColumnName() {
        return selectedColumnName;
    }

    public void setSelectedColumnName(String selectedColumnName) {
        this.selectedColumnName = selectedColumnName;
    }

    public String getSameColumnSelected() {
        return sameColumnSelected;
    }

    public void setSameColumnSelected(String sameColumnSelected) {
        this.sameColumnSelected = sameColumnSelected;
    }

    public TIProcessDTO getTiProcessDTO() {
        return tiProcessDTO;
    }

    public void setTiProcessDTO(TIProcessDTO tiProcessDTO) {
        this.tiProcessDTO = tiProcessDTO;
    }

    public RFCService getRfc() {
        return rfc;
    }

    public void setRfc(RFCService rfc) {
        this.rfc = rfc;
    }

    public String getServicenowURL() {
        return servicenowURL;
    }

    public void setServicenowURL(String servicenowURL) {
        this.servicenowURL = servicenowURL;
    }

    public String getLastNameFiler() {
        return lastNameFiler;
    }

    public void setLastNameFiler(String lastNameFiler) {
        this.lastNameFiler = lastNameFiler;
    }

    public List<String> getLastNameList() {
        return lastNameList;
    }

    public void setLastNameList(List<String> lastNameList) {
        this.lastNameList = lastNameList;
    }

    public String getFilterColumn() {
        return filterColumn;
    }

    public void setFilterColumn(String filterColumn) {
        this.filterColumn = filterColumn;
    }

    public String getFilterValue() {
        return filterValue;
    }

    public void setFilterValue(String filterValue) {
        this.filterValue = filterValue;
    }

    public List<String> getViewColumnNamesList() {
        return viewColumnNamesList;
    }

    public void setViewColumnNamesList(List<String> viewColumnNamesList) {
        this.viewColumnNamesList = viewColumnNamesList;
    }

    public String getSsoId() {
        return ssoId;
    }

    public void setSsoId(String ssoId) {
        this.ssoId = ssoId;
    }

    public String getView() {
        return view;
    }

    public void setView(String view) {
        this.view = view;
    }

    public Map<Long, String> getMap() {
        return map;
    }

    public void setMap(Map<Long, String> map) {
        this.map = map;
    }

	public List<String> getColumnList() {
		return columnList;
	}

	public void setColumnList(List<String> columnList) {
		this.columnList = columnList;
	}

    public String getEcomType() {
        return ecomType;
    }

    public void setEcomType(String ecomType) {
        this.ecomType = ecomType;
    }
	
}
