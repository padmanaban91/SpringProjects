package com.citigroup.cgti.c3par.connection.domain;

import java.util.Date;

import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;


/**
 * The Class FAFPortState.
 */
public class FAFPortState extends PerformerPagerDO {

    /** The firewall state id. */
    private Long firewallStateId;

    /** The port id. */
    private Long portId;

    /** The created_date. */
    private Date created_date;

    /** The updated_date. */
    private Date updated_date;

    /**
     * Instantiates a new fAF port state.
     */
    public FAFPortState() {
	//---------------------
	setTableName("faf_port_state");
	setSequenceName("");
	//---------------------
	addToDBMapping("firewallStateId","FIREWALL_STATE_ID",1);
	addToDBMapping("portId","port_id",2);
	addToDBMapping("created_date","created_date",3);
	addToDBMapping("updated_date","updated_date",4);
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.domain.Base#getCreated_date()
     */
    public Date getCreated_date() {
	return created_date;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.domain.Base#setCreated_date(java.util.Date)
     */
    public void setCreated_date(Date created_date) {
	this.created_date = created_date;
    }

    /**
     * Gets the firewall state id.
     *
     * @return the firewall state id
     */
    public Long getFirewallStateId() {
	return firewallStateId;
    }

    /**
     * Sets the firewall state id.
     *
     * @param firewallStateId the new firewall state id
     */
    public void setFirewallStateId(Long firewallStateId) {
	this.firewallStateId = firewallStateId;
    }

    /**
     * Gets the port id.
     *
     * @return the port id
     */
    public Long getPortId() {
	return portId;
    }

    /**
     * Sets the port id.
     *
     * @param portId the new port id
     */
    public void setPortId(Long portId) {
	this.portId = portId;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.domain.Base#getUpdated_date()
     */
    public Date getUpdated_date() {
	return updated_date;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.domain.Base#setUpdated_date(java.util.Date)
     */
    public void setUpdated_date(Date updated_date) {
	this.updated_date = updated_date;
    }
}
