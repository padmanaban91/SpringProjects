package com.citigroup.cgti.c3par.appsense.domain;

import java.io.Serializable;

import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.domain.TIRequest;


/**
 * The Class AppsenseUser.
 */
public class AppsenseUser extends Base implements Serializable{

    /** The ti process. */
    private TIProcess tiProcess = new TIProcess();

    /** The ti request. */
    private TIRequest tiRequest = new TIRequest();

    /** The citi contact. */
    private CitiContact citiContact = new CitiContact();

    /** The record type. */
    private String recordType = "U";

    /** The dev access. */
    private String devAccess;

    /** The prd access. */
    private String prdAccess;

    /** The dev admin access. */
    private String devAdminAccess;

    /** The prd admin access. */
    private String prdAdminAccess;

    private boolean alreadyAccessed;
    /**
	 * @return the alreadyAccessed
	 */
	public boolean isAlreadyAccessed() {
		return alreadyAccessed;
	}

	/**
	 * @param alreadyAccessed the alreadyAccessed to set
	 */
	public void setAlreadyAccessed(boolean alreadyAccessed) {
		this.alreadyAccessed = alreadyAccessed;
	}
    /**
     * Gets the dev admin access.
     *
     * @return the devAdminAccess
     */
    public String getDevAdminAccess() {
	return devAdminAccess;
    }

    /**
     * Sets the dev admin access.
     *
     * @param devAdminAccess the devAdminAccess to set
     */
    public void setDevAdminAccess(String devAdminAccess) {
	this.devAdminAccess = devAdminAccess;
    }

    /**
     * Gets the prd admin access.
     *
     * @return the prdAdminAccess
     */
    public String getPrdAdminAccess() {
	return prdAdminAccess;
    }

    /**
     * Sets the prd admin access.
     *
     * @param prdAdminAccess the prdAdminAccess to set
     */
    public void setPrdAdminAccess(String prdAdminAccess) {
	this.prdAdminAccess = prdAdminAccess;
    }

    /** The appsense ad group. */
    private AppsenseADGroup appsenseADGroup = new AppsenseADGroup();



    /** The status. */
    private String status;

    /** The cross environment access. */
    private String crossEnvironmentAccess ;

    /**
     * Gets the cross environment access.
     *
     * @return the crossEnvironmentAccess
     */
    public String getCrossEnvironmentAccess() {
	return crossEnvironmentAccess;
    }

    /**
     * Sets the cross environment access.
     *
     * @param crossEnvironmentAccess the crossEnvironmentAccess to set
     */
    public void setCrossEnvironmentAccess(String crossEnvironmentAccess) {
	this.crossEnvironmentAccess = crossEnvironmentAccess;
    }

    /**
     * Gets the local folder access.
     *
     * @return the localFolderAccess
     */
    public String getLocalFolderAccess() {
	return localFolderAccess;
    }

    /**
     * Sets the local folder access.
     *
     * @param localFolderAccess the localFolderAccess to set
     */
    public void setLocalFolderAccess(String localFolderAccess) {
	this.localFolderAccess = localFolderAccess;
    }

    /** The local folder access. */
    private String localFolderAccess;

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
	return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
	this.status = status;
    }

    /**
     * Gets the appsense ad group.
     *
     * @return the appsense ad group
     */
    public AppsenseADGroup getAppsenseADGroup() {
	return appsenseADGroup;
    }

    /**
     * Sets the appsense ad group.
     *
     * @param appsenseADGroup the new appsense ad group
     */
    public void setAppsenseADGroup(AppsenseADGroup appsenseADGroup) {
	this.appsenseADGroup = appsenseADGroup;
    }

    /**
     * Instantiates a new appsense user.
     */
    public  AppsenseUser(){  	}

    /**
     * Gets the ti process.
     *
     * @return the ti process
     */
    public TIProcess getTiProcess() {
	return tiProcess;
    }

    /**
     * Sets the ti process.
     *
     * @param tiProcess the new ti process
     */
    public void setTiProcess(TIProcess tiProcess) {
	this.tiProcess = tiProcess;
    }

    /**
     * Gets the ti request.
     *
     * @return the ti request
     */
    public TIRequest getTiRequest() {
	return tiRequest;
    }

    /**
     * Sets the ti request.
     *
     * @param tiRequest the new ti request
     */
    public void setTiRequest(TIRequest tiRequest) {
	this.tiRequest = tiRequest;
    }

    /**
     * Gets the citi contact.
     *
     * @return the citi contact
     */
    public CitiContact getCitiContact() {
	return citiContact;
    }

    /**
     * Sets the citi contact.
     *
     * @param citiContact the new citi contact
     */
    public void setCitiContact(CitiContact citiContact) {
	this.citiContact = citiContact;
    }

    /**
     * Gets the record type.
     *
     * @return the record type
     */
    private String getRecordType() {
	return recordType;
    }

    /**
     * Sets the record type.
     *
     * @param recordType the new record type
     */
    private void setRecordType(String recordType) {
	this.recordType = recordType;
    }

    /**
     * Gets the dev access.
     *
     * @return the dev access
     */
    public String getDevAccess() {
	return devAccess;
    }

    /**
     * Sets the dev access.
     *
     * @param devAccess the new dev access
     */
    public void setDevAccess(String devAccess) {
	this.devAccess = devAccess;
    }

    /**
     * Gets the prd access.
     *
     * @return the prd access
     */
    public String getPrdAccess() {
	return prdAccess;
    }

    /**
     * Sets the prd access.
     *
     * @param prdAccess the new prd access
     */
    public void setPrdAccess(String prdAccess) {
	this.prdAccess = prdAccess;
    }

}
