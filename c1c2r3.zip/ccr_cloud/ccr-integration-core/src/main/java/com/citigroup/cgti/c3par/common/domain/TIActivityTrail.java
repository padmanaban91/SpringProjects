/*
 * 
 */
package com.citigroup.cgti.c3par.common.domain;

import java.io.Serializable;
import java.util.Date;

import com.citigroup.cgti.c3par.communication.domain.CMPRequest;
import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.TIRequest;

/**
 * The Class TIMailAudit.
 */
public class TIActivityTrail extends Base implements Serializable {

	private TIRequest tiRequest;
	
	private String activityStage;
	private TITaskType activity;
	private String activityType;
	private String activityStatus;	
	private Long userRoleId;
	private Long userId;
	private Long tiRequestId;
	private Long activityId;
	private Long infoUserRoleId;
	private Date activityStartDate;
	private Date activityEndDate;	
	private Long lockedBy;	
	private Date lockedDate;	
	private String activityMode;	
	private String bpminstanceID;
	private String taskCode;
    private TIActivityTrail pirequestedActivity;
    private Long versionNo;
	private String approvalSystem;
    
    private CMPRequest cmpRequest;

	public TIRequest getTiRequest() {
		return tiRequest;
	}

	public void setTiRequest(TIRequest tiRequest) {
		this.tiRequest = tiRequest;
	}

	public String getActivityStage() {
		return activityStage;
	}

	public void setActivityStage(String activityStage) {
		this.activityStage = activityStage;
	}

	public TITaskType getActivity() {
		return activity;
	}

	public void setActivity(TITaskType activity) {
		this.activity = activity;
	}

	public String getActivityType() {
		return activityType;
	}

	public void setActivityType(String activityType) {
		this.activityType = activityType;
	}

	public String getActivityStatus() {
		return activityStatus;
	}

	public void setActivityStatus(String activityStatus) {
		this.activityStatus = activityStatus;
	}

	public Long getUserRoleId() {
		return userRoleId;
	}

	public void setUserRoleId(Long userRoleId) {
		this.userRoleId = userRoleId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getInfoUserRoleId() {
		return infoUserRoleId;
	}

	public void setInfoUserRoleId(Long infoUserRoleId) {
		this.infoUserRoleId = infoUserRoleId;
	}

	public Date getActivityStartDate() {
		return activityStartDate;
	}

	public void setActivityStartDate(Date activityStartDate) {
		this.activityStartDate = activityStartDate;
	}

	public Date getActivityEndDate() {
		return activityEndDate;
	}

	public void setActivityEndDate(Date activityEndDate) {
		this.activityEndDate = activityEndDate;
	}

	public Long getLockedBy() {
		return lockedBy;
	}

	public void setLockedBy(Long lockedBy) {
		this.lockedBy = lockedBy;
	}

	public Date getLockedDate() {
		return lockedDate;
	}

	public void setLockedDate(Date lockedDate) {
		this.lockedDate = lockedDate;
	}

	public String getActivityMode() {
		return activityMode;
	}

	public void setActivityMode(String activityMode) {
		this.activityMode = activityMode;
	}
	public String getTaskCode() {
        return taskCode;
    }

    public void setTaskCode(String taskCode) {
        this.taskCode = taskCode;
    }

    public String getBpminstanceID() {
		return bpminstanceID;
	}

	public void setBpminstanceID(String bpminstanceID) {
		this.bpminstanceID = bpminstanceID;
	}	

	public TIActivityTrail getPirequestedActivity() {
		return pirequestedActivity;
	}

	public void setPirequestedActivity(TIActivityTrail pirequestedActivity) {
		this.pirequestedActivity = pirequestedActivity;
	}

	public Long getVersionNo() {
		return versionNo;
	}

	public void setVersionNo(Long versionNo) {
		this.versionNo = versionNo;
	}

	public String getApprovalSystem() {
		return approvalSystem;
	}

	public void setApprovalSystem(String approvalSystem) {
		this.approvalSystem = approvalSystem;
	}

	public CMPRequest getCmpRequest() {
		return cmpRequest;
	}

	public void setCmpRequest(CMPRequest cmpRequest) {
		this.cmpRequest = cmpRequest;
	}

	/**
	 * @return the tiRequestId
	 */
	public Long getTiRequestId() {
		return tiRequestId;
	}

	/**
	 * @param tiRequestId the tiRequestId to set
	 */
	public void setTiRequestId(Long tiRequestId) {
		this.tiRequestId = tiRequestId;
	}
	/**
	 * @return the activityId
	 */
	public Long getActivityId() {
		return activityId;
	}

	/**
	 * @param activityId the activityId to set
	 */
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}

}
