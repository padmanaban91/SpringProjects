package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


/**
 * The Class BusinessCase.
 */
public class BusinessCase implements Serializable{

    /** The application. */
    private Application application=new Application();

    /** The conn access type. */
    private ConnectionAccessType connAccessType=new ConnectionAccessType();

    //private NetworkAccessType networkAccessType=new NetworkAccessType();
    /** The network access type. */
    private Long[] networkAccessType = new Long[0];

    /** The deployment env type. */
    private DeploymentEnvType deploymentEnvType=new DeploymentEnvType();

    private String regionName;
    
    /** The region List. */
    private List<Region> regionList =  new ArrayList<Region>();

    /** The sector. */
    private Sector sector=new Sector();

    /** The business unit. */
    private BusinessUnit businessUnit=new BusinessUnit();

    /** The cost center. */
    private CostCenter costCenter= new CostCenter();

    /** The comment. */
    private String comment;

    /** The business reason other text. */
    private String businessReasonOtherText;

    /** The business reason id. */
    private Long businessReasonID;

    /** The process type. */
    private ProcessType processType=new ProcessType();

    /** The ap cost center. */
    private CostCenter apCostCenter = new CostCenter();

    /** The update comments. */
    private String updateComments;

    /** The termination comments. */
    private String terminationComments;

    /** The is broad access. */
    private String isBroadAccess;

    /** The Entitlement. */
    private Name Entitlement =new Name();

    /**
     * Gets the entitlement.
     *
     * @return the entitlement
     */
    public Name getEntitlement() {
	return Entitlement;
    }

    /**
     * Sets the entitlement.
     *
     * @param entitlement the new entitlement
     */
    public void setEntitlement(Name entitlement) {
	Entitlement = entitlement;
    }

    /**
     * Gets the checks if is broad access.
     *
     * @return the checks if is broad access
     */
    public String getIsBroadAccess() {
	return isBroadAccess;
    }

    /**
     * Sets the checks if is broad access.
     *
     * @param isBroadAccess the new checks if is broad access
     */
    public void setIsBroadAccess(String isBroadAccess) {
	this.isBroadAccess = isBroadAccess;
    }

    /**
     * Gets the termination comments.
     *
     * @return the termination comments
     */
    public String getTerminationComments() {
	return terminationComments;
    }

    /**
     * Sets the termination comments.
     *
     * @param terminationComments the new termination comments
     */
    public void setTerminationComments(String terminationComments) {
	this.terminationComments = terminationComments;
    }

    /**
     * Gets the ap cost center.
     *
     * @return the ap cost center
     */
    public CostCenter getApCostCenter() {
	return apCostCenter;
    }

    /**
     * Sets the ap cost center.
     *
     * @param apCostCenter the new ap cost center
     */
    public void setApCostCenter(CostCenter apCostCenter) {
	this.apCostCenter = apCostCenter;
    }

    /**
     * Gets the business unit.
     *
     * @return the business unit
     */
    public BusinessUnit getBusinessUnit() {
	return businessUnit;
    }

    /**
     * Sets the business unit.
     *
     * @param businessUnit the new business unit
     */
    public void setBusinessUnit(BusinessUnit businessUnit) {
	this.businessUnit = businessUnit;
    }

    /**
     * Gets the application.
     *
     * @return the application
     */
    public Application getApplication() {
	return application;
    }

    /**
     * Sets the application.
     *
     * @param application the new application
     */
    public void setApplication(Application application) {
	this.application = application;
    }

    /**
     * Gets the comment.
     *
     * @return the comment
     */
    public String getComment() {
	return comment;
    }

    /**
     * Sets the comment.
     *
     * @param comments the new comment
     */
    public void setComment(String comments) {
	this.comment = comments;
    }

    /**
     * Gets the conn access type.
     *
     * @return the conn access type
     */
    public ConnectionAccessType getConnAccessType() {
	return connAccessType;
    }

    /**
     * Sets the conn access type.
     *
     * @param connAccessType the new conn access type
     */
    public void setConnAccessType(ConnectionAccessType connAccessType) {
	this.connAccessType = connAccessType;
    }

    /**
     * Gets the cost center.
     *
     * @return the cost center
     */
    public CostCenter getCostCenter() {
	return costCenter;
    }

    /**
     * Sets the cost center.
     *
     * @param costCenter the new cost center
     */
    public void setCostCenter(CostCenter costCenter) {
	this.costCenter = costCenter;
    }

    /**
     * Gets the deployment env type.
     *
     * @return the deployment env type
     */
    public DeploymentEnvType getDeploymentEnvType() {
	return deploymentEnvType;
    }

    /**
     * Sets the deployment env type.
     *
     * @param deploymentEnvType the new deployment env type
     */
    public void setDeploymentEnvType(DeploymentEnvType deploymentEnvType) {
	this.deploymentEnvType = deploymentEnvType;
    }

    
    public List<Region> getRegionList() {
		return regionList;
	}

	public void setRegionList(List<Region> regionList) {
		this.regionList = regionList;
	}

	/**
     * Gets the sector.
     *
     * @return the sector
     */
    public Sector getSector() {
	return sector;
    }   

    /**
     * Sets the sector.
     *
     * @param sector the new sector
     */
    public void setSector(Sector sector) {
	this.sector = sector;
    }

    /**
     * Gets the process type.
     *
     * @return the process type
     */
    public ProcessType getProcessType() {
	return processType;
    }

    /**
     * Sets the process type.
     *
     * @param processType the new process type
     */
    public void setProcessType(ProcessType processType) {
	this.processType = processType;
    }

    /**
     * Gets the network access type.
     *
     * @return the network access type
     */
    public Long[] getNetworkAccessType() {
	return networkAccessType;
    }

    /**
     * Sets the network access type.
     *
     * @param networkAccessType the new network access type
     */
    public void setNetworkAccessType(Long[] networkAccessType) {
	this.networkAccessType = networkAccessType;
    }

    /**
     * Gets the business reason id.
     *
     * @return the business reason id
     */
    public Long getBusinessReasonID() {
	return businessReasonID;
    }

    /**
     * Sets the business reason id.
     *
     * @param businessReasonID the new business reason id
     */
    public void setBusinessReasonID(Long businessReasonID) {
	this.businessReasonID = businessReasonID;
    }

    /**
     * Gets the business reason other text.
     *
     * @return the business reason other text
     */
    public String getBusinessReasonOtherText() {
	return businessReasonOtherText;
    }

    /**
     * Sets the business reason other text.
     *
     * @param businessReasonOtherText the new business reason other text
     */
    public void setBusinessReasonOtherText(String businessReasonOtherText) {
	this.businessReasonOtherText = businessReasonOtherText;
    }


    /**
     * Gets the update comments.
     *
     * @return the update comments
     */
    public String getUpdateComments() {
	return updateComments;
    }

    /**
     * Sets the update comments.
     *
     * @param updateComments the new update comments
     */
    public void setUpdateComments(String updateComments) {
	this.updateComments = updateComments;
    }

	public String getRegionName() {
		return regionName;
	}

	public void setRegionName(String regionName) {
		this.regionName = regionName;
	}
    
    
}
