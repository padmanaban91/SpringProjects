package com.citigroup.cgti.c3par.communication.domain;

import java.io.Serializable;

/**
 * @author ky38518
 * 
 */
public class CmpContactDetails implements Serializable {
    private Long contactId;
    private String ssoId;
    private boolean disabled;
    private String operation;
    private Long cmpRoleId;

    /**
     * @return the contactId
     */
    public Long getContactId() {
        return contactId;
    }

    /**
     * @param contactId
     *            the contactId to set
     */
    public void setContactId(Long contactId) {
        this.contactId = contactId;
    }

    /**
     * @return the ssoId
     */
    public String getSsoId() {
        return ssoId;
    }

    /**
     * @param ssoId
     *            the ssoId to set
     */
    public void setSsoId(String ssoId) {
        this.ssoId = ssoId;
    }

    /**
     * @return the disabled
     */
    public boolean isDisabled() {
        return disabled;
    }

    /**
     * @param disabled
     *            the disabled to set
     */
    public void setDisabled(boolean disabled) {
        this.disabled = disabled;
    }

    /**
     * @return the operation
     */
    public String getOperation() {
        return operation;
    }

    /**
     * @param operation
     *            the operation to set
     */
    public void setOperation(String operation) {
        this.operation = operation;
    }

    /**
     * @return the cmpRoleId
     */
    public Long getCmpRoleId() {
        return cmpRoleId;
    }

    /**
     * @param cmpRoleId
     *            the cmpRoleId to set
     */
    public void setCmpRoleId(Long cmpRoleId) {
        this.cmpRoleId = cmpRoleId;
    }

}
