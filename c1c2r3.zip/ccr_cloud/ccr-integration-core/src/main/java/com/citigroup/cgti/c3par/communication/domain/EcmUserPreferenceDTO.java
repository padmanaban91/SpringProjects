package com.citigroup.cgti.c3par.communication.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author ka58098
 *
 */
public class EcmUserPreferenceDTO implements Serializable {

    private static final long serialVersionUID = 54578548L;
    private String columnName;
    private String showVal;
    private String sortingColumn;
    private String sortBy;
    private String sortOrder;
    private Long resultsPerPage;
    private Long columnId;
    private Long viewId;
    private String viewName;
    private String unSelectedColumn;
    private String selectedColumn;
    private String ssoId;
    private Long userSettingId;
    private String status;
    private Long secondColumnId;
    private String secondColSortOrder;
    private Long thirdColumnId;
    private String thirdColSortOrder;
    private Long fourthColumnId;
    private String fourthColSortOrder;
    private Long fifthColumnId;
    private String fifthColSortOrder;
    private Long sixthColumnId;
    private String sixthColSortOrder;
    private Long seventhColumnId;
    private String seventhColSortOrder;
    private Long eighthColumnId;
    private String eighthColSortOrder;
    private Long ninethColumnId;
    private String ninethColSortOrder;
    
    private List<ColumnDTO> selectedList=new ArrayList<>();
    private List<ColumnDTO> unSelectedList=new ArrayList<>();
    private List<EcmColumn> columnList = new ArrayList<EcmColumn>();
    private List<String> sortColumnList = new ArrayList<>();

    private boolean isSelected;

    public String getColumnName() {
        return columnName;
    }

    public void setColumnName(String columnName) {
        this.columnName = columnName;
    }

    public String getShowVal() {
        return showVal;
    }

    public void setShowVal(String showVal) {
        this.showVal = showVal;
    }
    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean isSelected) {
        this.isSelected = isSelected;
    }
    public String getSortingColumn() {
        return sortingColumn;
    }

    public void setSortingColumn(String sortingColumn) {
        this.sortingColumn = sortingColumn;
    }

    public String getSortBy() {
        return sortBy;
    }

    public void setSortBy(String sortBy) {
        this.sortBy = sortBy;
    }
    
    public String getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(String sortOrder) {
        this.sortOrder = sortOrder;
    }

    public Long getResultsPerPage() {
        return resultsPerPage;
    }

    public void setResultsPerPage(Long resultsPerPage) {
        this.resultsPerPage = resultsPerPage;
    }

    public Long getColumnId() {
        return columnId;
    }

    public void setColumnId(Long columnId) {
        this.columnId = columnId;
    }

    public Long getViewId() {
        return viewId;
    }

    public void setViewId(Long viewId) {
        this.viewId = viewId;
    }

    public String getViewName() {
        return viewName;
    }

    public void setViewName(String viewName) {
        this.viewName = viewName;
    }

    public String getUnSelectedColumn() {
        return unSelectedColumn;
    }

    public void setUnSelectedColumn(String unSelectedColumn) {
        this.unSelectedColumn = unSelectedColumn;
    }

    public String getSelectedColumn() {
        return selectedColumn;
    }

    public void setSelectedColumn(String selectedColumn) {
        this.selectedColumn = selectedColumn;
    }
    public String getSsoId() {
        return ssoId;
    }

    public void setSsoId(String ssoId) {
        this.ssoId = ssoId;
    }
    public Long getUserSettingId() {
        return userSettingId;
    }

    public void setUserSettingId(Long userSettingId) {
        this.userSettingId = userSettingId;
    }
  	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	public List<ColumnDTO> getSelectedList() {
        return selectedList;
    }

    public void setSelectedList(List<ColumnDTO> selectedList) {
        this.selectedList = selectedList;
    }

    public List<ColumnDTO> getUnSelectedList() {
        return unSelectedList;
    }

    public void setUnSelectedList(List<ColumnDTO> unSelectedList) {
        this.unSelectedList = unSelectedList;
    }

    public List<EcmColumn> getColumnList() {
        return columnList;
    }

    public void setColumnList(List<EcmColumn> columnList) {
        this.columnList = columnList;
    }

    public List<String> getSortColumnList() {
        return sortColumnList;
    }

    public void setSortColumnList(List<String> sortColumnList) {
        this.sortColumnList = sortColumnList;
    }

	public String getSecondColSortOrder() {
		return secondColSortOrder;
	}

	public void setSecondColSortOrder(String secondColSortOrder) {
		this.secondColSortOrder = secondColSortOrder;
	}

	public Long getSecondColumnId() {
		return secondColumnId;
	}

	public void setSecondColumnId(Long secondColumnId) {
		this.secondColumnId = secondColumnId;
	}

	public Long getThirdColumnId() {
		return thirdColumnId;
	}

	public void setThirdColumnId(Long thirdColumnId) {
		this.thirdColumnId = thirdColumnId;
	}

	public String getThirdColSortOrder() {
		return thirdColSortOrder;
	}

	public void setThirdColSortOrder(String thirdColSortOrder) {
		this.thirdColSortOrder = thirdColSortOrder;
	}

	public Long getFourthColumnId() {
		return fourthColumnId;
	}

	public void setFourthColumnId(Long fourthColumnId) {
		this.fourthColumnId = fourthColumnId;
	}

	public String getFourthColSortOrder() {
		return fourthColSortOrder;
	}

	public void setFourthColSortOrder(String fourthColSortOrder) {
		this.fourthColSortOrder = fourthColSortOrder;
	}

	public Long getFifthColumnId() {
		return fifthColumnId;
	}

	public void setFifthColumnId(Long fifthColumnId) {
		this.fifthColumnId = fifthColumnId;
	}

	public String getFifthColSortOrder() {
		return fifthColSortOrder;
	}

	public void setFifthColSortOrder(String fifthColSortOrder) {
		this.fifthColSortOrder = fifthColSortOrder;
	}

	public Long getSixthColumnId() {
		return sixthColumnId;
	}

	public void setSixthColumnId(Long sixthColumnId) {
		this.sixthColumnId = sixthColumnId;
	}

	public String getSixthColSortOrder() {
		return sixthColSortOrder;
	}

	public void setSixthColSortOrder(String sixthColSortOrder) {
		this.sixthColSortOrder = sixthColSortOrder;
	}

	public Long getSeventhColumnId() {
		return seventhColumnId;
	}

	public void setSeventhColumnId(Long seventhColumnId) {
		this.seventhColumnId = seventhColumnId;
	}

	public String getSeventhColSortOrder() {
		return seventhColSortOrder;
	}

	public void setSeventhColSortOrder(String seventhColSortOrder) {
		this.seventhColSortOrder = seventhColSortOrder;
	}

	public Long getEighthColumnId() {
		return eighthColumnId;
	}

	public void setEighthColumnId(Long eighthColumnId) {
		this.eighthColumnId = eighthColumnId;
	}

	public String getEighthColSortOrder() {
		return eighthColSortOrder;
	}

	public void setEighthColSortOrder(String eighthColSortOrder) {
		this.eighthColSortOrder = eighthColSortOrder;
	}

	public Long getNinethColumnId() {
		return ninethColumnId;
	}

	public void setNinethColumnId(Long ninethColumnId) {
		this.ninethColumnId = ninethColumnId;
	}

	public String getNinethColSortOrder() {
		return ninethColSortOrder;
	}

	public void setNinethColSortOrder(String ninethColSortOrder) {
		this.ninethColSortOrder = ninethColSortOrder;
	}

}
