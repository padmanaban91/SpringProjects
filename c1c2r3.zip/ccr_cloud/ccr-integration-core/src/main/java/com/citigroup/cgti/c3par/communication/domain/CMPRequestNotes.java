/*
 * 
 */
package com.citigroup.cgti.c3par.communication.domain;

import java.io.Serializable;
import java.sql.Clob;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.domain.Base;

/**
 * The Class TIMailAudit.
 */
public class CMPRequestNotes extends Base implements Serializable {
    
    private static final Logger LOGGER = Logger.getLogger(CMPRequestNotes.class);
    private static final long serialVersionUID = 1L;
    private String notes;
    private Clob newNotes;
    private String type;
    private CMPRequest cmpRequest;
    private Long cmpId;
    private byte[] uploadfile;
    private String filetype;
    private CitiContact citiContact;

    public String getFiletype() {
        return filetype;
    }

    public void setFiletype(String filetype) {
        this.filetype = filetype;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public CMPRequest getCmpRequest() {
        return cmpRequest;
    }

    public void setCmpRequest(CMPRequest cmpRequest) {
        this.cmpRequest = cmpRequest;
    }

    public Long getCmpId() {
        return cmpId;
    }

    public void setCmpId(Long cmpId) {
        this.cmpId = cmpId;
    }

    public void setUploadfile(byte[] uploadfile) {
        this.uploadfile = uploadfile;
    }

    public byte[] getUploadfile() {
        return uploadfile;
    }

    public void setNewNotes(Clob newNotes) {
        try {
            this.newNotes = newNotes;
            if(newNotes != null){
                this.setNotes(IOUtils.toString(newNotes.getCharacterStream()));
            }
        } catch (Exception e) {
            LOGGER.error(e.toString(), e);
        }
    }

    public Clob getNewNotes() {
        return newNotes;
    }

    public CitiContact getCitiContact() {
        return citiContact;
    }

    public void setCitiContact(CitiContact citiContact) {
        this.citiContact = citiContact;
    }

}
