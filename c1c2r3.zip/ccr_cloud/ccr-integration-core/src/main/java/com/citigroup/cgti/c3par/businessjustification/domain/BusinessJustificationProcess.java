/**
 *
 */
package com.citigroup.cgti.c3par.businessjustification.domain;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.common.domain.ContactDetailsDTO;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.common.domain.HistoryContact;
import com.citigroup.cgti.c3par.communication.domain.CCRCMPMappingDTO;
import com.citigroup.cgti.c3par.communication.domain.CmpRequestDTO;
import com.citigroup.cgti.c3par.communication.domain.CopyFromCmpDTO;
import com.citigroup.cgti.c3par.domain.ConnectionRequest;
import com.citigroup.cgti.c3par.domain.Planning;
import com.citigroup.cgti.c3par.domain.Role;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.fw.domain.ResolveITNotifyLog;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCDetail;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCLookup;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCRequest;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

/**
 * @author pc79439
 *
 */
public class BusinessJustificationProcess {

	CCRBeanFactory ccrBeanFactory;

	{
		System.out.println("AdminProcess inside --Start");
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
		System.out.println("ccrBeanFactory"+ccrBeanFactory);
		System.out.println("BusinessJustificationProcess inside --End");
	}
	
	private ConnectionRequest connectionRequest;
	private TIRequest tirequest;
	private Planning planning;
	private ConnectionRequest conreq;
	
	private List<GenericLookup> detailedInfoList;
	private List<GenericLookup> classificationList;
	private List<GenericLookup> conestimateList;
	private List<GenericLookup> reasonforVirConList;
	private List<GenericLookup> priorityList;
	private List<GenericLookup> affectedBusinessList;
		
	private List<ConReqCitiReqConXref> requesterContacts;	
	private List<ConReqCitiContactXref> targetContacts;
	private List<ConReqTPContactXref> targetTPContacts;	
	private List<ConReqTPContactXref> requesterTPContacts;
	List<ResolveITNotifyLog> resolveITNotifyLogLst;
	List capApproverCodeList;
	List<CCRCMPMappingDTO> ccrCMPMappingDTOList;

	private String[] virtualConnReasons;
	private String[] affectedBusiness;
	private String[] citiContactIds;
	
	private String currBusJustfi;
	private String connectionName;
	private String donotimplDate;
	private String sectorName;
	private String businessUnitName;
	
	private Integer currVersionNo;	
	private Long oldrelationshipID;
	private Long planningId;
	private Long tiRequestId;
	private String copyFromCMPRequestId;
	private List<String> cmpRequestList;
	private String citigroupData;
	private String customerData;
	private String priority;
	private String affectedBusinessforCopyFromCmp;
	private String reasonsForDirectConnection;
	private CopyFromCmpDTO copyFromCmpDto;
	private String selectedCmpId;
	private String selectedGroupId;
	private String callbackPage;
	
	public ConnectionRequest getConnectionRequest() {
		return connectionRequest;
	}

	public void setConnectionRequest(ConnectionRequest connectionRequest) {
		this.connectionRequest = connectionRequest;
	}

	public TIRequest getTirequest() {
		return tirequest;
	}

	public void setTirequest(TIRequest tirequest) {
		this.tirequest = tirequest;
	}
	
	public Planning getPlanning() {
		return planning;
	}

	public void setPlanning(Planning planning) {
		this.planning = planning;
	}
	
	public ConnectionRequest getConreq() {
		return conreq;
	}

	public void setConreq(ConnectionRequest conreq) {
		this.conreq = conreq;
	}

	public String getCurrBusJustfi() {
		return currBusJustfi;
	}

	public void setCurrBusJustfi(String currBusJustfi) {
		this.currBusJustfi = currBusJustfi;
	}

	public List<GenericLookup> getDetailedInfoList() {
		return detailedInfoList;
	}

	public void setDetailedInfoList(List<GenericLookup> detailedInfoList) {
		this.detailedInfoList = detailedInfoList;
	}

	public List<GenericLookup> getClassificationList() {
		return classificationList;
	}

	public void setClassificationList(List<GenericLookup> classificationList) {
		this.classificationList = classificationList;
	}

	public List<GenericLookup> getConestimateList() {
		return conestimateList;
	}

	public void setConestimateList(List<GenericLookup> conestimateList) {
		this.conestimateList = conestimateList;
	}

	public List<GenericLookup> getReasonforVirConList() {
		return reasonforVirConList;
	}

	public void setReasonforVirConList(List<GenericLookup> reasonforVirConList) {
		this.reasonforVirConList = reasonforVirConList;
	}

	public List<GenericLookup> getPriorityList() {
		return priorityList;
	}

	public void setPriorityList(List<GenericLookup> priorityList) {
		this.priorityList = priorityList;
	}

	public List<GenericLookup> getAffectedBusinessList() {
		return affectedBusinessList;
	}

	public void setAffectedBusinessList(List<GenericLookup> affectedBusinessList) {
		this.affectedBusinessList = affectedBusinessList;
	}

	public String[] getVirtualConnReasons() {
		return virtualConnReasons;
	}

	public void setVirtualConnReasons(String[] virtualConnReasons) {
		this.virtualConnReasons = virtualConnReasons;
	}

	public String[] getAffectedBusiness() {
		return affectedBusiness;
	}

	public void setAffectedBusiness(String[] affectedBusiness) {
		this.affectedBusiness = affectedBusiness;
	}

	public String getConnectionName() {
		return connectionName;
	}

	public void setConnectionName(String connectionName) {
		this.connectionName = connectionName;
	}

	public String getDonotimplDate() {
		return donotimplDate;
	}

	public void setDonotimplDate(String donotimplDate) {
		this.donotimplDate = donotimplDate;
	}

	public List<ConReqCitiReqConXref> getRequesterContacts() {
		return requesterContacts;
	}

	public void setRequesterContacts(List<ConReqCitiReqConXref> requesterContacts) {
		this.requesterContacts = requesterContacts;
	}

	public List<ConReqCitiContactXref> getTargetContacts() {
		return targetContacts;
	}

	public void setTargetContacts(List<ConReqCitiContactXref> targetContacts) {
		this.targetContacts = targetContacts;
	}

	public Integer getCurrVersionNo() {
		return currVersionNo;
	}

	public void setCurrVersionNo(Integer currVersionNo) {
		this.currVersionNo = currVersionNo;
	}
	
	public String[] getCitiContactIds() {
		return citiContactIds;
	}

	public void setCitiContactIds(String[] citiContactIds) {
		this.citiContactIds = citiContactIds;
	}
	
	public List<ConReqTPContactXref> getTargetTPContacts() {
		return targetTPContacts;
	}

	public void setTargetTPContacts(List<ConReqTPContactXref> targetTPContacts) {
		this.targetTPContacts = targetTPContacts;
	}

	public List<ConReqTPContactXref> getRequesterTPContacts() {
		return requesterTPContacts;
	}

	public void setRequesterTPContacts(List<ConReqTPContactXref> requesterTPContacts) {
		this.requesterTPContacts = requesterTPContacts;
	}

	public Long getOldrelationshipID() {
		return oldrelationshipID;
	}

	public void setOldrelationshipID(Long oldrelationshipID) {
		this.oldrelationshipID = oldrelationshipID;
	}

	public List getCapApproverCodeList() {
		return capApproverCodeList;
	}

	public void setCapApproverCodeList(List capApproverCodeList) {
		this.capApproverCodeList = capApproverCodeList;
	}

	public List<ResolveITNotifyLog> getResolveITNotifyLogLst() {
		return resolveITNotifyLogLst;
	}

	public void setResolveITNotifyLogLst(
			List<ResolveITNotifyLog> resolveITNotifyLogLst) {
		this.resolveITNotifyLogLst = resolveITNotifyLogLst;
	}

	public String getSectorName() {
		return sectorName;
	}

	public void setSectorName(String sectorName) {
		this.sectorName = sectorName;
	}

	public String getBusinessUnitName() {
		return businessUnitName;
	}

	public void setBusinessUnitName(String businessUnitName) {
		this.businessUnitName = businessUnitName;
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void updateTiRequestCMP(String cmpId, String tiRequestId) {
		ccrBeanFactory.getResolveitRequestPersistable().updateTiRequestCMP(cmpId, tiRequestId);
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void deleteUploadedDocument(String tiRequestId, String docType) {
		ccrBeanFactory.getResolveitRequestPersistable().deleteUploadedDocument(tiRequestId,docType);
	}

	
	public List<ResolveITNotifyLog> getResolveITNotifyLogList(String searchString) {
		return ccrBeanFactory.getResolveitRequestPersistable().getResolveITNotifyLogList(searchString);
	}

    
    public List<ResolveITNotifyLog> getCMPDetails(String searchString) {
    	return ccrBeanFactory.getResolveitRequestPersistable().getCMPDetails(searchString);
    }

    
 	public List<ResolveITNotifyLog> getResolveITNotifyLogList() {
 		return ccrBeanFactory.getResolveitRequestPersistable().getResolveITNotifyLogList();
 	}
    
	
	public Long getPlanningId(Long tirequestid) {
		return ccrBeanFactory.getCommonServicePersistable().getPlanningIdForTiRequestId(tirequestid);		
	}
	public TIRequest getTiRequestById(long tiRequestId) {
        return ccrBeanFactory.getCommonServicePersistable().getTIRequest(tiRequestId);       
    }
	public List<Long> getTiRequestId(Long caspId,Long detailId){
		return ccrBeanFactory.getCommonServicePersistable().getTiRequestIdForCASPId(caspId, detailId);
	}
	public void sendNotification(String templateId,CmpRequestDTO cmpRequestDto ){
		ccrBeanFactory.getiMailModule().sendSloNotification(templateId, cmpRequestDto);
	}
	public boolean isBuscritEmerConnection(Long tirequestid) {
		return ccrBeanFactory.getCommonServicePersistable().isBuscritEmerConnection(tirequestid);		
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public boolean validateISOContact(String soeId) {
		return ccrBeanFactory.getCommonServicePersistable().validateISOContact(soeId);
	}
	
	
	public void sendMailForUserEntitlementCreate(ContactDetailsDTO contactDetailsDTO, TIRequest tiRequest) {
		ccrBeanFactory.getMailModuleImpl().sendMailForUserEntitlementCreate(contactDetailsDTO, tiRequest);		
	}
	
	
	public void sendMailToTargetContacts(List list, TIRequest tiReq,String contactType) {
		ccrBeanFactory.getMailModuleImpl().sendMailToTargetContacts(list, tiReq, contactType);	
	}
	
	
	public RFCRequest getGenericRFCRequest(TIRequest tirequest) {
		return ccrBeanFactory.getRfc().getGenericRFCRequest(tirequest);		
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public int deleteRFCDetailAnswer(RFCDetail rfcDetail) {
		return ccrBeanFactory.getRfc().deleteRFCDetailAnswer(rfcDetail);
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void addRFCDetail(RFCDetail rfcDetail) {
		ccrBeanFactory.getRfc().addRFCDetail(rfcDetail);
	}

	
	public RFCLookup getRFCLookup(String defname) {
		return ccrBeanFactory.getRfc().getRFCLookup(defname);		
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void deleteRFCDetail(RFCDetail rfcDetail) {
		ccrBeanFactory.getRfc().deleteRFCDetail(rfcDetail);
	}

	
	public RFCRequest getEMERGenericRFCRequest(TIRequest tiRequest,String isActive) {
		return ccrBeanFactory.getRfc().getEMERGenericRFCRequest(tiRequest,isActive);		
	}

	
	public Role getRole(Long roleId) {
		return ccrBeanFactory.getRelationshipServicePersistable().getRole(roleId);
	}	
	
	
	public TIRequest getTIRequestDetails(Long tirequestid) {
		return ccrBeanFactory.getBusjusServicePersistable().getTIRequest(tirequestid);		
	}
	
	
	public Planning getPlanningDetails(Long planningid) {
		return  ccrBeanFactory.getBusjusServicePersistable().getPlanningDetails(planningid);		
	}

	
	public ConnectionRequest getConnectionRequest(Long conreqid) {
		return  ccrBeanFactory.getBusjusServicePersistable().getConnectionRequest(conreqid);		
	}
	
	
	public List<GenericLookup> getGenericLookupDropDown(String defname) {
		return  ccrBeanFactory.getBusjusServicePersistable().getGenericLookupDropDown(defname);		
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void updateConnectionBasicInfoBySA(String connectionname, String oldConnectionName, Long tiRequestId, String soeId) {
		 ccrBeanFactory.getBusjusServicePersistable().updateConnectionBasicInfoBySA(connectionname, oldConnectionName, tiRequestId, soeId);
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void updateConnectionBasicInfo(Long tiRequestID, Long priority, String donotimpl, String vtTicketNo, Date date) {
		 ccrBeanFactory.getBusjusServicePersistable().updateConnectionBasicInfo(tiRequestID,priority,donotimpl,vtTicketNo,date);
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void updateBusinessCaseInfo(TIRequest tirequest,ConnectionRequest conreq,String[] virtualConReason) {
		 ccrBeanFactory.getBusjusServicePersistable().updateBusinessCaseInfo(tirequest,conreq,virtualConReason);
	}

	
	public List<ConReqCitiReqConXref> getRequesterContactsList(Long planningId) {
		return  ccrBeanFactory.getBusjusServicePersistable().getRequesterContactsList(planningId);		
	}

	
	public List<ConReqCitiContactXref> getTargetContactsList(Long planningId) {
		return  ccrBeanFactory.getBusjusServicePersistable().getTargetContactsList(planningId);		
	}
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public List<Long> saveConReqCitiContactXref(Long planningId, CitiContact citiContact, String[] roleIds) {
		return  ccrBeanFactory.getBusjusServicePersistable().saveConReqCitiContactXref(planningId, citiContact, roleIds);
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void updateConReqCitiContactXref(List<ConReqCitiContactXref> citiContactXrefs,Long planningId) {
		 ccrBeanFactory.getBusjusServicePersistable().updateConReqCitiContactXref(citiContactXrefs,planningId);
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void deleteConReqCitiContactXref(String[] conIds) {
		 ccrBeanFactory.getBusjusServicePersistable().deleteConReqCitiContactXref(conIds);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public List<Long> saveConReqCitiReqContactXref(Long planningId, CitiContact citiContact, String[] roleIds) {
		return  ccrBeanFactory.getBusjusServicePersistable().saveConReqCitiReqContactXref(planningId, citiContact, roleIds);
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void updateConReqCitiReqContactXref(List<ConReqCitiReqConXref> citiContactXrefs,Long planningId) {
		 ccrBeanFactory.getBusjusServicePersistable().updateConReqCitiReqContactXref(citiContactXrefs,planningId);
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void deleteConReqCitiReqContactXref(String[] conIds) {
		 ccrBeanFactory.getBusjusServicePersistable().deleteConReqCitiReqContactXref(conIds);
	}
	
	
	public Long getTiRequestForVersion(Integer version, Long processId) {
		return  ccrBeanFactory.getBusjusServicePersistable().getTiRequestForVersion(version, processId);		
	}
	
	
	public List<ConReqTPContactXref> getTargetTPContactsList(Long planningId){
		return  ccrBeanFactory.getBusjusServicePersistable().getTargetTPContactsList(planningId);		
	}

	
	public List<ConReqTPContactXref> getRequesterTPContactsList(Long planningId){
		return  ccrBeanFactory.getBusjusServicePersistable().getRequesterTPContactsList(planningId);		
	}

	
	public String getConnectionBusinessJustification(Long processId, Long tiRequestId){
		return  ccrBeanFactory.getBusjusServicePersistable().getConnectionBusinessJustification(processId, tiRequestId);		
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void deleteContactsBySA(List<HistoryContact> historyContacts, Long tiRequestId, String soeId, String requestFrom) {
		 ccrBeanFactory.getBusjusServicePersistable().deleteContactsBySA(historyContacts, tiRequestId, soeId, requestFrom);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void addContactsBySA(List<HistoryContact> historyContacts, Long tiRequestId, String soeId, String requestFrom) {
		 ccrBeanFactory.getBusjusServicePersistable().addContactsBySA(historyContacts, tiRequestId, soeId, requestFrom);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void updateContactsBySA(Map<Integer, HistoryContact> newHistoryContacts, Map<Integer, HistoryContact> oldHistoryContacts, Long tiRequestId, String soeId, String requestFrom) {
		 ccrBeanFactory.getBusjusServicePersistable().updateContactsBySA(newHistoryContacts, oldHistoryContacts, tiRequestId, soeId, requestFrom);
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void copyContactsFromRelationship(Long tiRequestId) {
		 ccrBeanFactory.getBusjusServicePersistable().copyContactsFromRelationship(tiRequestId);
	}

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void updateBusinessCaseBySA(Long relationshipId, Long oldRelationshipId, Long tiRequestId, String soeId) {
		 ccrBeanFactory.getBusjusServicePersistable().updateBusinessCaseBySA(relationshipId, oldRelationshipId, tiRequestId, soeId);
	}

	
	public List<Role> getRoles() {
		return  ccrBeanFactory.getBusjusServicePersistable().getRoles();	
	}
	

	public CitiContact getBusinessOwnerDetails(Long tiRequestId,String relationType) {
		return ccrBeanFactory.getBusjusServicePersistable().getBusinessOwnerDetails(tiRequestId, relationType);	
	}

    /**
     * @return the ccrCMPMappingDTOList
     */
    public List<CCRCMPMappingDTO> getCcrCMPMappingDTOList() {
        return ccrCMPMappingDTOList;
    }

    /**
     * @param ccrCMPMappingDTOList the ccrCMPMappingDTOList to set
     */
    public void setCcrCMPMappingDTOList(List<CCRCMPMappingDTO> ccrCMPMappingDTOList) {
        this.ccrCMPMappingDTOList = ccrCMPMappingDTOList;
    }

	public Long getPlanningId() {
		return planningId;
	}

	public void setPlanningId(Long planningId) {
		this.planningId = planningId;
	}

	public Long getTiRequestId() {
		return tiRequestId;
	}

	public void setTiRequestId(Long tiRequestId) {
		this.tiRequestId = tiRequestId;
	}

    public CopyFromCmpDTO getCmpDetailsForCopy(BusinessJustificationProcess busjusProcess, String screenName, CopyFromCmpDTO copyFromCmpDTO, String relationshipType) throws Exception {
        return ccrBeanFactory.getBusjusServicePersistable().getCmpDetailsForCopy(busjusProcess,screenName,copyFromCmpDTO, relationshipType); 
    }

    public String getCopyFromCMPRequestId() {
        return copyFromCMPRequestId;
    }

    public void setCopyFromCMPRequestId(String copyFromCMPRequestId) {
        this.copyFromCMPRequestId = copyFromCMPRequestId;
    }

    public List<String> getCmpRequestList() throws Exception {
        return ccrBeanFactory.getBusjusServicePersistable().getCmpRequestList(this);
    }

    public void setCmpRequestList(List<String> cmpRequestList) {
        this.cmpRequestList = cmpRequestList;
    }

    public String getCitigroupData() {
        return citigroupData;
    }

    public void setCitigroupData(String citigroupData) {
        this.citigroupData = citigroupData;
    }

    public String getCustomerData() {
        return customerData;
    }

    public void setCustomerData(String customerData) {
        this.customerData = customerData;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getAffectedBusinessforCopyFromCmp() {
        return affectedBusinessforCopyFromCmp;
    }

    public void setAffectedBusinessforCopyFromCmp(String affectedBusinessforCopyFromCmp) {
        this.affectedBusinessforCopyFromCmp = affectedBusinessforCopyFromCmp;
    }

    public String getReasonsForDirectConnection() {
        return reasonsForDirectConnection;
    }

    public void setReasonsForDirectConnection(String reasonsForDirectConnection) {
        this.reasonsForDirectConnection = reasonsForDirectConnection;
    }

    public CopyFromCmpDTO getCopyFromCmpDto() {
        return copyFromCmpDto;
    }

    public void setCopyFromCmpDto(CopyFromCmpDTO copyFromCmpDto) {
        this.copyFromCmpDto = copyFromCmpDto;
    }

    /**
     * @return the selectedCmpId
     */
    public String getSelectedCmpId() {
        return selectedCmpId;
    }

    /**
     * @param selectedCmpId
     *            the selectedCmpId to set
     */
    public void setSelectedCmpId(String selectedCmpId) {
        this.selectedCmpId = selectedCmpId;
    }

    /**
     * @return the selectedGroupId
     */
    public String getSelectedGroupId() {
        return selectedGroupId;
    }

    /**
     * @param selectedGroupId the selectedGroupId to set
     */
    public void setSelectedGroupId(String selectedGroupId) {
        this.selectedGroupId = selectedGroupId;
    }

    /**
     * @return the callbackPage
     */
    public String getCallbackPage() {
        return callbackPage;
    }

    /**
     * @param callbackPage the callbackPage to set
     */
    public void setCallbackPage(String callbackPage) {
        this.callbackPage = callbackPage;
    }  

    /**
     * @param businessJustification
     * @param soeId
     */
    @Transactional(readOnly = false)
    public void updateBusinessCaseInfoByAdmin(String businessJustification, String soeId) {
        ccrBeanFactory.getBusjusServicePersistable().updateBusinessCaseInfoByAdmin(tirequest, conreq,
                businessJustification, soeId);
    }

    /**
     * @param processId
     * @return
     */

    public String getFirstCycleBusinessJustification(long processId, long versionNumber) {
        return ccrBeanFactory.getAccessFormText().getOrigBusJustification(processId, versionNumber);
    }

}
