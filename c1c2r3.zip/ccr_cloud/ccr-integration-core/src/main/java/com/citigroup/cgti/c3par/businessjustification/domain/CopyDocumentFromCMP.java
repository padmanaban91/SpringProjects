/**
 * 
 */
package com.citigroup.cgti.c3par.businessjustification.domain;

import java.io.Serializable;

/**
 * @author ka58098
 *
 */
public class CopyDocumentFromCMP implements Serializable {
	private static final long serialVersionUID = 15849785L;
	private String fileName;
	private Long cmpDocMetaId;
	private boolean isSelected;
	private String disPlayName;
	private String documentName;
	private String docType;
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public Long getCmpDocMetaId() {
		return cmpDocMetaId;
	}
	public void setCmpDocMetaId(Long cmpDocMetaId) {
		this.cmpDocMetaId = cmpDocMetaId;
	}
	public boolean isSelected() {
		return isSelected;
	}
	public void setSelected(boolean isSelected) {
		this.isSelected = isSelected;
	}
	public String getDisPlayName() {
		return disPlayName;
	}
	public void setDisPlayName(String disPlayName) {
		this.disPlayName = disPlayName;
	}
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	public String getDocType() {
		return docType;
	}
	public void setDocType(String docType) {
		this.docType = docType;
	}
	
	
}
