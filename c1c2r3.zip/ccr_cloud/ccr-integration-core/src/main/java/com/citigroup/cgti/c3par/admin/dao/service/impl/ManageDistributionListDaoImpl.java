package com.citigroup.cgti.c3par.admin.dao.service.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.admin.dao.service.ManageDistributionListDao;
import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.configuation.QueryConstants;

/**
 * DAO class to perform interaction with DB for Managing DL
 * @author ac81662
 *
 */
@Repository
@Transactional
public class ManageDistributionListDaoImpl implements ManageDistributionListDao {

    private static final Logger log = Logger.getLogger(ManageDistributionListDaoImpl.class.getName());

    @Autowired
    private SessionFactory sessionFactory;

    @Autowired
    @Qualifier("jdbcTemplate_ccr")
    private JdbcTemplate jdbcTemplate;

    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    public HibernateTemplate getHibernateTemplate() {
        return createHibernateTemplate(sessionFactory);
    }

    protected HibernateTemplate createHibernateTemplate(SessionFactory sessionFactory) {
        return new HibernateTemplate(sessionFactory);
    }

    /**
     * Dao impl method to add DL
     * @param citiContact
     * @return
     */
    @Override
    public Long addDL(CitiContact citiContact) throws Exception {
        log.info("Dao method addDL starts");
        Long id = 0L;
        try {
            if (citiContact != null) {
                id = (Long) getHibernateTemplate().save(citiContact);
                String ssoId = id + "DL";
                citiContact.setSsoId(ssoId);
                getHibernateTemplate().update(citiContact);
            }
        } catch (Exception e) {
            log.error("Exception while addDL " + e.toString());
            log.error(e, e);
            throw new ApplicationException("Exception in addDL ", e);
        }
        log.info("Dao method addDL ends");
        return id;
    }

    /**
     * Dao impl method to get DL List
     * @return
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @Override
    public List<CitiContact> getManageDLList() throws Exception {
        log.info("Dao method getManageDLList starts");
        Session session = sessionFactory.getCurrentSession();
        List<CitiContact> resultList = null;
        try {
            Query query = session.createQuery(QueryConstants.GET_CITI_CONTACT_LIKE);
            query.setParameter("ssoID", "%" + "DL");
            resultList = query.list();
        } catch (Exception e) {
            log.error("Exception occurred while getManageDLList: " + e.toString());
            log.error(e, e);
            throw new ApplicationException("Exception has occurred :: getManageDLList() ", e);
        }
        log.info("Dao method getManageDLList ends");
        return resultList;
    }

    /**
     * Dao impl method to save edited DL
     * @param citiContact
     * @return
     */
    @SuppressWarnings("unchecked")
    @Override
    public boolean saveDL(CitiContact citiContact) throws Exception {
        log.info("Dao method saveDL starts");
        Boolean isSuccessful = false;
        try {
            if (citiContact != null) {
                Session session = sessionFactory.getCurrentSession();
                Query query = session.createQuery(QueryConstants.GET_CITI_CONTACT);
                query.setString("ssoID", citiContact.getSsoId());
                List<CitiContact> result = query.list();
                result.get(0).setFirstName(citiContact.getFirstName());
                result.get(0).setLastName(citiContact.getLastName());
                result.get(0).setEmail(citiContact.getEmail());
                result.get(0).setSsoId(citiContact.getSsoId());
                result.get(0).setEmployeeStatus(citiContact.getEmployeeStatus());
                result.get(0).setEmployeeType(citiContact.getEmployeeType());
                getHibernateTemplate().update(result.get(0));
                isSuccessful = true;
            }
        } catch (Exception e) {
            log.error("Exception occurred while saveDL : " + e.toString());
            log.error(e, e);
            throw new ApplicationException("Exception has occurred :: saveDL() ", e);
        }
        log.info("Dao method saveDL ends");
        return isSuccessful;
    }

    /**
     * Dao impl Method to delete Selected DLs
     * @param citiContact
     * @return
     */
    @SuppressWarnings("unchecked")
    @Override
    public boolean deleteDL(CitiContact citiContact) throws Exception {
        log.info("Dao method deleteDL starts");
        Boolean isSuccessful = false;
        try {
            if (citiContact != null) {
                Session session = sessionFactory.getCurrentSession();
                Query query = session.createQuery(QueryConstants.GET_CITI_CONTACT);
                query.setString("ssoID", citiContact.getSsoId());
                List<CitiContact> result = query.list();
                result.get(0).setFirstName(citiContact.getFirstName());
                result.get(0).setLastName(citiContact.getLastName());
                result.get(0).setEmail(citiContact.getEmail());
                String newSsoId = citiContact.getSsoId().replace("DL", "DD");
                citiContact.setSsoId(newSsoId);
                result.get(0).setSsoId(citiContact.getSsoId());
                result.get(0).setEmployeeStatus(citiContact.getEmployeeStatus());
                result.get(0).setEmployeeType(citiContact.getEmployeeType());
                getHibernateTemplate().update(result.get(0));
                isSuccessful = true;
            }
        } catch (Exception e) {
            log.error("Exception occurred while deleteDL : " + e.toString());
            log.error(e, e);
            throw new ApplicationException("Exception has occurred :: deleteDL() ", e);
        }
        log.info("Dao method deleteDL ends");
        return isSuccessful;
    }
}
