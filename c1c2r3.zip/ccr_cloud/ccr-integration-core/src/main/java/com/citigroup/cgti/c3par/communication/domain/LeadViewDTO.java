package com.citigroup.cgti.c3par.communication.domain;

import java.io.Serializable;
import java.util.Date;

/**
 * @author mr89025
 * 
 */
public class LeadViewDTO implements Serializable {

    private static final long serialVersionUID = 16456545L;

    private String agentName;

    private Long inQueue;

    private Long bau;

    private Long buscrit_emer;

    private Long assistance;

    private Long today;

    private Long thisWeek;

    private Long previousWeek;

    private String agentID;

    private String isLocked;

    private String comments;

    private String firstname;

    private String lastname;

    private boolean selected;

    private Long agentUserId;

    /**
     * @return the agentName
     */
    public String getAgentName() {
        return agentName;
    }

    /**
     * @return the inQueue
     */
    public Long getInQueue() {
        return inQueue;
    }

    /**
     * @return the bau
     */
    public Long getBau() {
        return bau;
    }

    /**
     * @return the buscrit_emer
     */
    public Long getBuscrit_emer() {
        return buscrit_emer;
    }

    /**
     * @return the assistance
     */
    public Long getAssistance() {
        return assistance;
    }

    /**
     * @return the today
     */
    public Long getToday() {
        return today;
    }

    /**
     * @return the thisWeek
     */
    public Long getThisWeek() {
        return thisWeek;
    }

    /**
     * @return the previousWeek
     */
    public Long getPreviousWeek() {
        return previousWeek;
    }

    /**
     * @return the agentID
     */
    public String getAgentID() {
        return agentID;
    }

    /**
     * @return the isLocked
     */
    public String getIsLocked() {
        return isLocked;
    }

    /**
     * @return the comments
     */
    public String getComments() {
        return comments;
    }

    /**
     * @return the firstname
     */
    public String getFirstname() {
        return firstname;
    }

    /**
     * @return the lastname
     */
    public String getLastname() {
        return lastname;
    }

    /**
     * @return the selected
     */
    public boolean isSelected() {
        return selected;
    }

    /**
     * @return the agentUserId
     */
    public Long getAgentUserId() {
        return agentUserId;
    }

    /**
     * @param agentName
     *            the agentName to set
     */
    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }

    /**
     * @param inQueue
     *            the inQueue to set
     */
    public void setInQueue(Long inQueue) {
        this.inQueue = inQueue;
    }

    /**
     * @param bau
     *            the bau to set
     */
    public void setBau(Long bau) {
        this.bau = bau;
    }

    /**
     * @param buscrit_emer
     *            the buscrit_emer to set
     */
    public void setBuscrit_emer(Long buscrit_emer) {
        this.buscrit_emer = buscrit_emer;
    }

    /**
     * @param assistance
     *            the assistance to set
     */
    public void setAssistance(Long assistance) {
        this.assistance = assistance;
    }

    /**
     * @param today
     *            the today to set
     */
    public void setToday(Long today) {
        this.today = today;
    }

    /**
     * @param thisWeek
     *            the thisWeek to set
     */
    public void setThisWeek(Long thisWeek) {
        this.thisWeek = thisWeek;
    }

    /**
     * @param previousWeek
     *            the previousWeek to set
     */
    public void setPreviousWeek(Long previousWeek) {
        this.previousWeek = previousWeek;
    }

    /**
     * @param agentID
     *            the agentID to set
     */
    public void setAgentID(String agentID) {
        this.agentID = agentID;
    }

    /**
     * @param isLocked
     *            the isLocked to set
     */
    public void setIsLocked(String isLocked) {
        this.isLocked = isLocked;
    }

    /**
     * @param comments
     *            the comments to set
     */
    public void setComments(String comments) {
        this.comments = comments;
    }

    /**
     * @param firstname
     *            the firstname to set
     */
    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    /**
     * @param lastname
     *            the lastname to set
     */
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    /**
     * @param selected
     *            the selected to set
     */
    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    /**
     * @param agentUserId
     *            the agentUserId to set
     */
    public void setAgentUserId(Long agentUserId) {
        this.agentUserId = agentUserId;
    }

}
