package com.citigroup.cgti.c3par.connection.domain;

import java.util.ArrayList;
import java.util.List;

import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;


/**
 * The Class ConnectionFirewallPolicyLookUp.
 */
public class ConnectionFirewallPolicyLookUp extends PerformerPagerDO {


    /** The connection fw policy master list. */
    private List connectionFWPolicyMasterList = new ArrayList();


    /**
     * Instantiates a new connection firewall policy look up.
     */
    public ConnectionFirewallPolicyLookUp() {

	addToChildList("connectionFWPolicyMasterList",new ConnectionFWPolicyMaster());


    }

    /**
     * Gets the connection fw policy master list.
     *
     * @return the connection fw policy master list
     */
    public List getConnectionFWPolicyMasterList() {
	return connectionFWPolicyMasterList;
    }

    /**
     * Sets the connection fw policy master list.
     *
     * @param connectionFWPolicyMasterList the new connection fw policy master list
     */
    public void setConnectionFWPolicyMasterList(List connectionFWPolicyMasterList) {
	this.connectionFWPolicyMasterList = connectionFWPolicyMasterList;
    }



}
