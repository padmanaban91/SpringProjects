package com.citigroup.cgti.c3par.communication.domain;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.format.annotation.DateTimeFormat;

import com.citigroup.cgti.c3par.domain.MailTemplates;

public class EmailTemplateUpdationProcess {
	
	private static Logger log = Logger.getLogger(EmailTemplateUpdationProcess.class);

	private List<MailTemplates> emailTemplateList;
	private String selectedTemplateId;
	private String selectedTemplateSubject;
	private String selectedTemplateBody;
	private HashMap<String, MailTemplates> mailTemplateMap;
	private String mailTemplateJson;
	private String selectedTemplateUpdatedBy;
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss.SSS")
	private Timestamp selectedTemplateUpdatedDate;
	
	private Map<String, String> rolesList;
    private String toRoles;
    private String ccRoles;
    private String mailTemplateType;
    private String readOnlyFlag;

	public String getSelectedTemplateUpdatedBy() {
		return selectedTemplateUpdatedBy;
	}

	public void setSelectedTemplateUpdatedBy(String selectedTemplateUpdatedBy) {
		this.selectedTemplateUpdatedBy = selectedTemplateUpdatedBy;
	}

	public Timestamp getSelectedTemplateUpdatedDate() {
		return selectedTemplateUpdatedDate;
	}

	public void setSelectedTemplateUpdatedDate(Timestamp SelectedTemplateUpdatedDate) {
		this.selectedTemplateUpdatedDate = SelectedTemplateUpdatedDate;
	}

	public List<MailTemplates> getEmailTemplateList() {
		return emailTemplateList;
	}

	public void setEmailTemplateList(List<MailTemplates> emailTemplateList) {
		this.emailTemplateList = emailTemplateList;
		buildJsonObectArray(emailTemplateList);
	}
	
	public String getSelectedTemplateId() {
		return selectedTemplateId;
	}

	public void setSelectedTemplateId(String selectedTemplateId) {
		this.selectedTemplateId = selectedTemplateId;
	}

	public String getSelectedTemplateSubject() {
		return selectedTemplateSubject;
	}

	public void setSelectedTemplateSubject(String selectedTemplateSubject) {
		this.selectedTemplateSubject = selectedTemplateSubject;
	}

	public String getSelectedTemplateBody() {
		return selectedTemplateBody;
	}

	public void setSelectedTemplateBody(String selectedTemplateBody) {
		this.selectedTemplateBody = selectedTemplateBody;
	}
	
	public void setMailTemplateHashMap(List<MailTemplates> emailTemplateList){
		if(emailTemplateList == null || emailTemplateList.size() == 0){
			return;
		}
		mailTemplateMap = new HashMap<String, MailTemplates>();
		for(MailTemplates mailTemplate:emailTemplateList){
			mailTemplateMap.put(mailTemplate.getTemplate_id(), mailTemplate);
		}
		
	}
	
	public void buildJsonObectArray(List<MailTemplates> emailTemplateList){
		StringBuffer mailTemplateJSONSB = new StringBuffer();	
		//set the resource type list in JSON object format
		mailTemplateJSONSB.append("[");
		for(MailTemplates mailTemplate:emailTemplateList){
            mailTemplateJSONSB.append("{\"templateId\":\""+mailTemplate.getTemplate_id()+"\",\"subject\":\""+mailTemplate.getSubject()+"\"");
            mailTemplateJSONSB.append(",\"lastUpdatedBy\":\""+mailTemplate.getLastUpdatedBy()+"\",\"lastUpdatedDate\":\""+mailTemplate.getLastUpdatedDate()+
                    "\",\"toUserRole\":\""+mailTemplate.getToUserRole()+"\",\"ccUserRole\":\""+mailTemplate.getCcUserRole()+
                    "\",\"mailTemplateType\":\"" + mailTemplate.getMailTemplateType()+
                    "\",\"readOnlyFlag\":\"" + mailTemplate.getReadOnlyFlag() +"\"},");
        }
		mailTemplateJSONSB.deleteCharAt(mailTemplateJSONSB.length()-1);
		mailTemplateJSONSB.append("]");
	    
	   //log.info("ManageRelationshipController::setSelectedResourceType method ends..."+mailTemplateJSONSB.toString());
	    this.mailTemplateJson= mailTemplateJSONSB.toString();
	}
	
	public String getMailTemplateJson(){
		return this.mailTemplateJson;
	}
	
	public HashMap<String, MailTemplates> getMailTemplateMap(){
		return mailTemplateMap;
	}

    public String getToRoles() {
        return toRoles;
    }

    public void setToRoles(String toRoles) {
        this.toRoles = toRoles;
    }

    public String getCcRoles() {
        return ccRoles;
    }

    public void setCcRoles(String ccRoles) {
        this.ccRoles = ccRoles;
    }

    public String getMailTemplateType() {
        return mailTemplateType;
    }

    public void setMailTemplateType(String mailTemplateType) {
        this.mailTemplateType = mailTemplateType;
    }

    public String getReadOnlyFlag() {
        return readOnlyFlag;
    }

    public void setReadOnlyFlag(String readOnlyFlag) {
        this.readOnlyFlag = readOnlyFlag;
    }

    public Map<String, String> getRolesList() {
        return rolesList;
    }

    public void setRolesList(Map<String, String> rolesList) {
        this.rolesList = rolesList;
    }

}
