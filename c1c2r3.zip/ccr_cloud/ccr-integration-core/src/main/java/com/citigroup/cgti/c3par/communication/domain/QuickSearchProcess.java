package com.citigroup.cgti.c3par.communication.domain;

/**
 * @author ky38518
 * 
 */
public class QuickSearchProcess {
    private Long tiRequestId;
    private String phase;
    private String activityCode;
    private String loggedInUser;
    private String cmpReqId;

    public Long getTiRequestId() {
        return tiRequestId;
    }

    public void setTiRequestId(Long tiRequestId) {
        this.tiRequestId = tiRequestId;
    }

    public String getPhase() {
        return phase;
    }

    public void setPhase(String phase) {
        this.phase = phase;
    }

    public String getActivityCode() {
        return activityCode;
    }

    public void setActivityCode(String activityCode) {
        this.activityCode = activityCode;
    }

    public String getLoggedInUser() {
        return loggedInUser;
    }

    public void setLoggedInUser(String loggedInUser) {
        this.loggedInUser = loggedInUser;
    }

	public String getCmpReqId() {
		return cmpReqId;
	}

	public void setCmpReqId(String cmpReqId) {
		this.cmpReqId = cmpReqId;
	}

}
