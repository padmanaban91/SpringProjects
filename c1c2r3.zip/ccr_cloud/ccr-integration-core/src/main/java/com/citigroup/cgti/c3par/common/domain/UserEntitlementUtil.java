package com.citigroup.cgti.c3par.common.domain;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.audit.domain.AuditC3parUsersData;
import com.citigroup.cgti.c3par.relationship.domain.CitiHierarchyMaster;
import com.citigroup.cgti.c3par.user.domain.C3parUser;
import com.citigroup.cgti.c3par.user.domain.C3parUserHierarchyXref;

public class UserEntitlementUtil {
	private static final Logger LOGGER = Logger.getLogger(UserEntitlementUtil.class);
	private static final String TIME_ZONE_UTC = "UTC";
	public static AuditC3parUsersData createAuditUsersData(Long userId, AdminProcess adminProcess, String loginSSOId) {
		LOGGER.info("Entering TargetContactsController createAuditUsersData.");
		AuditC3parUsersData auditC3parUsersData = new AuditC3parUsersData();
		C3parUser c3parUser = adminProcess.getC3parUser();
		auditC3parUsersData.setUserId(userId);
		auditC3parUsersData.setUpdatedByUser(loginSSOId);
		auditC3parUsersData.setUpdated_date(new Date());
		auditC3parUsersData.setMgrApprover("");
		auditC3parUsersData.setMgrApprovedDate(null);
		auditC3parUsersData.setIsaApprover("");
		auditC3parUsersData.setIsaApprovedDate(null);
		auditC3parUsersData.setIsActiveCurrent(c3parUser.getActive());
		auditC3parUsersData.setEntStrCurrent(getEntitlements(c3parUser));
		auditC3parUsersData.setAuditLogInsertedDate(new Date());
		auditC3parUsersData.setSysadminApprover("");
		auditC3parUsersData.setSysadminReviewedDate(null);
		auditC3parUsersData.setLogDateTime(getDateTimeInUTC());
		auditC3parUsersData.setAffectedUser(c3parUser.getSsoId());
		adminProcess.setAuditC3parUsersData(auditC3parUsersData);
		LOGGER.info("Exiting TargetContactsController createAuditUsersData.");
		return auditC3parUsersData;
	}

	public static Calendar getDateTimeInUTC() {
		TimeZone timeZone = TimeZone.getTimeZone(TIME_ZONE_UTC);
		Calendar calendar = Calendar.getInstance(timeZone);
		return calendar;
	}

	public static String getEntitlements(C3parUser c3parUser) {
		LOGGER.info("Entering TargetContactsController getEntitlements.");
		StringBuilder entitlements = new StringBuilder("");
		List<C3parUserHierarchyXref> c3parUserHierarchyXrefList = c3parUser.getUserHierarchyList();
		if (c3parUserHierarchyXrefList != null && c3parUserHierarchyXrefList.size() > 0) {
			for (C3parUserHierarchyXref c3parUserHierarchyXref : c3parUserHierarchyXrefList) {
				CitiHierarchyMaster citiHierarchyMaster = c3parUserHierarchyXref.getCitiHierarchyMaster();
				if (citiHierarchyMaster != null) {
					LOGGER.debug("ID: " + citiHierarchyMaster.getRegion().getName() + " - Name "
							+ citiHierarchyMaster.getSector().getName());
					entitlements.append(citiHierarchyMaster.getRegion().getName()).append("-")
							.append(citiHierarchyMaster.getSector().getName()).append(",");
				}
			}
			if (!entitlements.equals("")) {
				entitlements.deleteCharAt(entitlements.length() - 1);
			}
			LOGGER.debug("Formated Entitlements with Region:" + entitlements.toString());
		}
		LOGGER.info("Exiting TargetContactsController getEntitlements.");
		return entitlements.toString();
	}
}
