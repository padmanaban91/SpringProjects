package com.citigroup.cgti.c3par.comments.domain;

public class GISSubmitActivityProcess extends SubmitActivityProcess {

        private String lastCycleApprovalStatus;

        public String getLastCycleApprovalStatus() {
            return lastCycleApprovalStatus;
        }

        public void setLastCycleApprovalStatus(String lastCycleApprovalStatus) {
            this.lastCycleApprovalStatus = lastCycleApprovalStatus;
        }

        public GISSubmitActivityProcess() {
            super();
        }
        
        public String fetchLastCycleApprovalStatus(Long tiRequestId, String strGIS_or_TPASWG) {
            return ccrBeanFactory.getSubmitActivityPersistable().getLastCycleApprovalStatus(tiRequestId, strGIS_or_TPASWG);
        }
        
        
        
        
        
}
