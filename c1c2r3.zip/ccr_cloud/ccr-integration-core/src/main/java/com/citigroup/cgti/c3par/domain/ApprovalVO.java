package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;


/**
 * The Class ApprovalVO.
 */
public class ApprovalVO extends Base implements Serializable{

    /** The approval. */
    private String approval;

    /** The comments. */
    private String comments;

    /** The role. */
    private Role role=new Role();

    /** The soe id. */
    private String soeID;

    /** The approver id. */
    private Long approverID;

    /**
     * Gets the approval.
     *
     * @return the approval
     */
    public String getApproval() {
	return approval;
    }

    /**
     * Sets the approval.
     *
     * @param approval the new approval
     */
    public void setApproval(String approval) {
	this.approval = approval;
    }

    /**
     * Gets the comments.
     *
     * @return the comments
     */
    public String getComments() {
	return comments;
    }

    /**
     * Sets the comments.
     *
     * @param comments the new comments
     */
    public void setComments(String comments) {
	this.comments = comments;
    }

    /**
     * Gets the soe id.
     *
     * @return the soe id
     */
    public String getSoeID() {
	return soeID;
    }

    /**
     * Sets the soe id.
     *
     * @param soeID the new soe id
     */
    public void setSoeID(String soeID) {
	this.soeID = soeID;
    }

    /**
     * Gets the role.
     *
     * @return the role
     */
    public Role getRole() {
	return role;
    }

    /**
     * Sets the role.
     *
     * @param role the new role
     */
    public void setRole(Role role) {
	this.role = role;
    }

    /**
     * Gets the approver id.
     *
     * @return the approver id
     */
    public Long getApproverID() {
	return approverID;
    }

    /**
     * Sets the approver id.
     *
     * @param approverID the new approver id
     */
    public void setApproverID(Long approverID) {
	this.approverID = approverID;
    }
}
