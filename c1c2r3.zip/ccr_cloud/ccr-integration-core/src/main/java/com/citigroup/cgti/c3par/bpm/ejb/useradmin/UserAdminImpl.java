package com.citigroup.cgti.c3par.bpm.ejb.useradmin;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import com.citigroup.cgti.c3par.C3parSession;
import com.citigroup.cgti.c3par.C3parTxSession;
import com.citigroup.cgti.c3par.bpm.ejb.domain.C3PARUserDTO;
import com.citigroup.cgti.c3par.common.domain.soc.persist.UserAdminServicePersistable;
import com.citigroup.cgti.c3par.dao.C3parUsersDAO;
import com.citigroup.cgti.c3par.domain.C3PARUser;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
import com.citigroup.cgti.c3par.user.domain.C3parUser;
import com.citigroup.cgti.c3par.user.domain.C3parUserHierarchyXref;
import com.citigroup.cgti.c3par.user.domain.C3parUserRoleXref;

/**
 * The Class UserAdminImpl.
 */
@Transactional
public class UserAdminImpl extends BasePersistanceImpl implements UserAdminServicePersistable {
	
	/** The c3par session. */
	private C3parSession c3parSession;
	
	/** The c3par tx session. */
	private C3parTxSession c3parTxSession;
	
	/** The c3par user dao. */
	private C3parUsersDAO  c3parUserDao;

	/** The log. */
	private static Logger log = Logger.getLogger(UserAdminImpl.class);

	/**
	 * Sets the c3par session.
	 *
	 * @param session the new c3par session
	 */
	public void setC3parSession(C3parSession session) {
		c3parSession = session;
	}

	/**
	 * Sets the c3par tx session.
	 *
	 * @param txSession the new c3par tx session
	 */
	public void setC3parTxSession(C3parTxSession txSession) {
		c3parTxSession = txSession;
	}

	/*
	 * Exposed to ALBPM to get single user details
	 */
	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.useradmin.IUserAdmin#getUserData(java.lang.String)
	 */
	
	@Transactional(readOnly = true)
	public C3PARUser getUserData(String soeId)  throws Exception{
		C3PARUser user = new C3PARUser();
		log.debug("Entered UserAdminImpl::getUserData() Method! Input ===>" + soeId);
		/*List usersList = null;
		c3parSession = new C3parSession();
		Long userId = null;
		C3parUsersEntity c3parUserEntity = null;
		
		try {
			c3parSession.getConnection();
			usersList = C3parUsersDAO.findBySsoId(soeId, c3parSession);
			if(usersList != null && usersList.size() >0 ){
				userId = (Long) usersList.get(0);
			}else{
				return null;
			}
			
			if(userId != null){
				c3parUserDao = new C3parUsersDAO(c3parSession);
				c3parUserEntity = c3parUserDao.get(userId);
				// Maps the entity object to local domain object understood by ALBPM
				user = UserAdminHelper.mapUserEntityToDO(c3parUserEntity);
			}
		} catch (Exception e) {
			log.error(e.getStackTrace().toString());
			throw e;
		}finally{
			
			if(c3parSession!=null){
				c3parSession.releaseConnection();
			}
		}*/		
		
		//Session session = getSession();
		
		Session session = null;
		try{
		session = getTXSession();
	    C3parUser usr= getC3parUserData(soeId,true, session);
	    if(usr != null && usr.getId() != null && usr.getId().longValue() > 0){
	    	user = convertC3PARUserToDO(usr);
	    }else{
			return null;
		}
		}finally{
			closeTXSession(session);
		}
		
		log.debug("Returned UserAdminImpl::getUserData() Method! Input ===>" + soeId);
		return user;
	}
	
	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.useradmin.IUserAdmin#getUserDTO(java.lang.String)
	 */
	@Transactional(readOnly = true)	
	public C3PARUserDTO getUserDTO(String soeId)  throws Exception{
		C3PARUserDTO userDTO=new C3PARUserDTO();
		C3PARUser user=getUserData(soeId);
		//userDTO=UserAdminHelper.convertC3PARUserToDTO(user);
		userDTO = convertC3PARUsersToDTO(user);
		return userDTO;
	}
	/*
	 * ALBPM passes the required details to activate a user. (IS_ACTIVE status is set to Y)
	 */
	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.useradmin.IUserAdmin#activateUser(java.lang.String, java.lang.String)
	 */
	public void activateUser(String requesterSOEId, String isaSOEId)  throws Exception{
		/*c3parSession = new C3parSession();
		Long userId = null;
		List usersList = null;
		C3parUsersEntity c3parUserEntity = null;
		try{
			c3parSession.getConnection();
			usersList = C3parUsersDAO.findBySsoId(requesterSOEId, c3parSession);
			
			if(usersList != null && usersList.size() >0 ){
				userId = (Long) usersList.get(0);
				log.debug("User Id " + requesterSOEId + " value is " + userId);
			}else{
				log.debug("User Id " + requesterSOEId + " Could not be activated");
				log.debug("User Id " + requesterSOEId + " ==> Unable to find entry in the database.");
			}
			
			if(userId != null){
				c3parUserDao = new C3parUsersDAO(c3parSession);
				c3parUserEntity = c3parUserDao.get(userId);
				
				// Update the values with details passed on by ALBPM side
				c3parUserEntity.setIsaApprover(isaSOEId);
				if(isaSOEId != null && !("".equals(isaSOEId))){
					c3parUserEntity.setIsaReviewedDate(new Date());
				}
				if(!("Y".equals(c3parUserEntity.getIsActive()))){
					c3parUserEntity.setActivatedDate(new Date());
				}
				c3parUserEntity.setIsActive("Y");
				c3parUserEntity.setWfStatus("Approved");
				c3parUserDao.update(c3parUserEntity);
				log.debug("User ===>> " + requesterSOEId + " activated by ISA ===>> "  + isaSOEId);
			}
			
			auditC3parUsersData(requesterSOEId);
			
		}catch(Exception e){
			log.error(e);
			throw e;
		}finally{
			
			if(c3parSession!=null){
				c3parSession.releaseConnection();
			}
		}*/
		//Session session = getSession();
		Session session = null;
		try{
		session = getTXSession();
		C3parUser usr= getC3parUserData(requesterSOEId,false, session);
		if(usr != null && usr.getId() != null && usr.getId().longValue() > 0){
			// Update the values with details passed on by ALBPM side
			usr.setIsaApprover(isaSOEId);
			
			if(isaSOEId != null && !("".equals(isaSOEId))){
				usr.setIsaReviewedDate(new Date());
			}
			if(!("Y".equals(usr.getActive()))){
				usr.setActivatedDate(new Date());
			}
			usr.setActive("Y");
			usr.setWfStatus("Approved");
			
			session.update(usr);
			log.debug("User ===>> " + requesterSOEId + " activated by ISA ===>> "  + isaSOEId);
		}else{
			log.debug("User Id " + requesterSOEId + " Could not be activated");
			log.info("User Id " + requesterSOEId + " ==> Unable to find entry in the database.");
		}
		
		auditC3parUsersData(requesterSOEId);
		}finally{
			closeTXSession(session);
		}
		
	}
	/*
	 * ALBPM passes the required details to update Sys Admin Approver user.
	 */
	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.useradmin.IUserAdmin#updateApprover(java.lang.String, java.lang.String, java.lang.String)
	 */
	public void updateApprover(String requesterSOEId, String approverSOEId, String role)  throws Exception{
		/*c3parSession = new C3parSession();
		Long userId = null;
		List usersList = null;
		C3parUsersEntity c3parUserEntity = null;
		try{
			c3parSession.getConnection();
			usersList = C3parUsersDAO.findBySsoId(requesterSOEId, c3parSession);
			
			if(usersList != null && usersList.size() >0 ){
				userId = (Long) usersList.get(0);
				log.debug("User Id " + requesterSOEId + " value is " + userId);
			}else{
				log.debug("User Id " + requesterSOEId + " Could not be activated");
				log.debug("User Id " + requesterSOEId + " ==> Unable to find entry in the database.");
			}
			
			if(userId != null){
				c3parUserDao = new C3parUsersDAO(c3parSession);
				c3parUserEntity = c3parUserDao.get(userId);			
				// Update the values with details passed on by ALBPM side
				if ("SysAdmin".equals(role)){
				c3parUserEntity.setSysadminApprover(approverSOEId);
				if(approverSOEId != null && !("".equals(approverSOEId))){
					c3parUserEntity.setSysadminReviewedDate(new Date());
				}
				} else if("ISA".equals(role)){
					c3parUserEntity.setIsaApprover(approverSOEId);
					if(approverSOEId != null && !("".equals(approverSOEId))){
						c3parUserEntity.setIsaReviewedDate(new Date());
					}
				}
				c3parUserDao.update(c3parUserEntity);
				log.debug("User ===>> " + requesterSOEId + " System Admin Approver is ===>> "  + approverSOEId);
			}
					
		}catch(Exception e){
			log.error(e);
			throw e;
		}finally{
			
			if(c3parSession!=null){
				c3parSession.releaseConnection();
			}
		}*/
		
		//Session session = getSession();
		Session session = null;
		try{
		session = getTXSession();
		C3parUser usr= getC3parUserData(requesterSOEId,false, session);
		if(usr != null && usr.getId() != null && usr.getId().longValue() > 0){
			// Update the values with details passed on by ALBPM side
			if ("SysAdmin".equals(role)){
				usr.setSysadminApprover(approverSOEId);
				if(approverSOEId != null && !("".equals(approverSOEId))){
					usr.setSysadminReviewedDate(new Date());
				}
			} else if("ISA".equals(role)){
				usr.setIsaApprover(approverSOEId);
				if(approverSOEId != null && !("".equals(approverSOEId))){
					usr.setIsaReviewedDate(new Date());
				}
			}
			
			session.update(usr);
			log.debug("User ===>> " + requesterSOEId + " System Admin Approver is ===>> "  + approverSOEId);
		}else{
			log.debug("User Id " + requesterSOEId + " Could not be activated");
			log.info("User Id " + requesterSOEId + " ==> Unable to find entry in the database.");
		}
		}
		finally{
			closeTXSession(session);
		}
		
	}
	/*
	 * List of users bulk uploaded by a particular ISA user
	 */
	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.useradmin.IUserAdmin#getBulkUploadUsers(java.lang.String)
	 */
	@Transactional(readOnly = true)
	public List getBulkUploadUsers(String isaSOEId)  throws Exception{
		List<C3PARUserDTO> bulkUploadUsersList = new ArrayList<C3PARUserDTO>();
		log.debug("Entered UserAdminImpl::getBulkUploadUsers method for ==> " + isaSOEId);
		
		/*c3parSession = new C3parSession();
		C3parUsersDAO c3parUsersDAO = null;
		List usersList = null;
		List entityList = null;
		C3parUsersEntity c3parUserEntity = null;
		try {
			c3parSession.getConnection();
			c3parUsersDAO = new C3parUsersDAO(c3parSession);
		//	usersList = c3parUsersDAO.findByRequestedBy(isaSOEId);
			usersList = UserAdminHelper.getUserIdsByRequestedBy(isaSOEId);
			log.debug("usersList size::"+usersList.size());
			for(int i=0;i<usersList.size();i=((i+900)<usersList.size()?(i+900):usersList.size())){
				List tempusersList = usersList.subList(i, ((i+900)<usersList.size()?(i+900):usersList.size()));
				log.debug("tempusersList size:: START:"+i+" END:"+(((i+900)<usersList.size()?(i+900):usersList.size()))+" SIZE:"+tempusersList.size());
				if(tempusersList != null && tempusersList.size() > 0){
					entityList = c3parUsersDAO.get(tempusersList, true);
					
					if(entityList != null && entityList.size() > 0 ){
						for(int iCounter=0; iCounter < entityList.size(); iCounter++){
							c3parUserEntity = (C3parUsersEntity)entityList.get(iCounter);
							
							if(c3parUserEntity != null && 
							((("P").equalsIgnoreCase(c3parUserEntity.getIsActive()) && ("Bulk_Upload").equalsIgnoreCase(c3parUserEntity.getWfStatus()))
											|| ("system_new_user").equalsIgnoreCase(c3parUserEntity.getWfStatus()) 
											|| ("system_update_user").equalsIgnoreCase(c3parUserEntity.getWfStatus()))){
								bulkUploadUsersList.add(UserAdminHelper.mapUserEntityToDTO(c3parUserEntity));
							}
						}						
					}
				}else{
					log.debug("There are no users Approved by ISA Approver ID ==> " + isaSOEId);
					return null;
				}
			}
		} catch (Exception e) {
			log.error(e);
			throw e;
		}finally{
			if(c3parSession!=null){
				c3parSession.releaseConnection();
			}
		}*/		
		//Session session = getSession();
		Session session = null;
		try{
		session = getTXSession();
		Criteria criteria = session.createCriteria(C3parUser.class);
	    criteria.add(Restrictions.eq("requestedBy", isaSOEId));

		List<C3parUser> usrlist = criteria.list();
		if(usrlist != null && usrlist.size() > 0){
			log.debug("UserAdminImpl :: getBulkUploadUsers :: usrlist.size ::"+usrlist.size());

			for(C3parUser usr:usrlist){
				if((("P").equalsIgnoreCase(usr.getActive()) && ("Bulk_Upload").equalsIgnoreCase(usr.getWfStatus()))
										|| ("system_new_user").equalsIgnoreCase(usr.getWfStatus()) 
										|| ("system_update_user").equalsIgnoreCase(usr.getWfStatus())){
					log.debug("UserAdminImpl :: getBulkUploadUsers :: user ssoid - "+usr.getSsoId());
					lazyInitialize(usr.getUserRoleList());
					lazyInitialize(usr.getUserHierarchyList());	
					bulkUploadUsersList.add(mapC3parUserToDTO(usr));
				}
			}
			
		}	
		}finally{
			closeTXSession(session);
		}
		log.info("Exiting UserAdminImpl::getBulkUploadUsers() method. Size of List ==> " + bulkUploadUsersList.size());
		return bulkUploadUsersList;
	}

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.useradmin.IUserAdmin#getISAEditUsers(java.lang.String)
	 */
	@Transactional(readOnly = true)
	public List getISAEditUsers(String isaSOEId)  throws Exception{
		log.debug("Entered UserAdminImpl::getISAEditUsers method for ==> " + isaSOEId);
		List bulkUploadUsersList = new ArrayList();
		/*c3parSession = new C3parSession();		
		C3parUsersDAO c3parUsersDAO = null;
		List usersList = null;
		List entityList = null;
		C3parUsersEntity c3parUserEntity = null;
		try {
			c3parSession.getConnection();
			c3parUsersDAO = new C3parUsersDAO(c3parSession);
		//	usersList = c3parUsersDAO.findByRequestedBy(isaSOEId);
			usersList = UserAdminHelper.getUserIdsByUpdatedBy(isaSOEId);
			log.debug("usersList size::"+usersList.size());
			for(int i=0;i<usersList.size();i=((i+900)<usersList.size()?(i+900):usersList.size())){
				List tempusersList = usersList.subList(i, ((i+900)<usersList.size()?(i+900):usersList.size()));
				log.debug("tempusersList size:: START:"+i+" END:"+(((i+900)<usersList.size()?(i+900):usersList.size()))+" SIZE:"+tempusersList.size());
				if(tempusersList != null && tempusersList.size() > 0){
					entityList = c3parUsersDAO.get(tempusersList, true);
					if(entityList != null && entityList.size() > 0 ){
						for(int iCounter=0; iCounter < entityList.size(); iCounter++){
							c3parUserEntity = (C3parUsersEntity)entityList.get(iCounter);
							if(c3parUserEntity != null && ("Pending").equalsIgnoreCase(c3parUserEntity.getWfStatus())
									&& (("Y").equalsIgnoreCase(c3parUserEntity.getIsActive()) || ("N").equalsIgnoreCase(c3parUserEntity.getIsActive()))){
								bulkUploadUsersList.add(UserAdminHelper.mapUserEntityToDTO(c3parUserEntity));
							}
						}
					}
				}else{
					log.debug("There are no users Updated by ISA Approver ID ==> " + isaSOEId);
					return null;
				}
			}
		} catch (Exception e) {
			log.error(e);
			throw e;
		}finally{
			if(c3parSession!=null){
				c3parSession.releaseConnection();
			}
		}*/
		Session session =null;
		try{
		session = getTXSession();
		//Session session = getSession();
		Criteria criteria = session.createCriteria(C3parUser.class);
	    criteria.add(Restrictions.eq("updatedUser", isaSOEId).ignoreCase());

		List<C3parUser> usrlist = criteria.list();
		if(usrlist != null && usrlist.size() > 0){
			log.debug("UserAdminImpl :: getBulkUploadUsers :: usrlist.size ::"+usrlist.size());

			for(C3parUser usr:usrlist){
				if(usr != null && ("Pending").equalsIgnoreCase(usr.getWfStatus())
						&& (("Y").equalsIgnoreCase(usr.getActive()) || ("N").equalsIgnoreCase(usr.getActive()))){
					log.debug("UserAdminImpl :: getBulkUploadUsers :: user ssoid - "+usr.getSsoId());
					lazyInitialize(usr.getUserRoleList());
					lazyInitialize(usr.getUserHierarchyList());	
					bulkUploadUsersList.add(mapC3parUserToDTO(usr));
				}
			}
			
		}		
		}finally{
			closeTXSession(session);
		}
		log.debug("Exiting UserAdminImpl::getISAEditUsers() method. Size of List ==> " + bulkUploadUsersList.size());
		return bulkUploadUsersList;
	}

	private void closeTXSession(Session session) {
		if (!TransactionSynchronizationManager.isActualTransactionActive()) {
			if (session != null) {
				log.debug("Closing non tx hibernate session");
				session.flush();
				// session.close();
				session.disconnect();
			}
		}
	}

	private Session getTXSession() {
		log.debug("Opening non tx hibernate session");
		Session session;
		if(!TransactionSynchronizationManager.isActualTransactionActive()){
			session=getSessionFactory().openSession();
		}else{
			 session =getSessionFactory().getCurrentSession();
		}
		return session;
	}
	
	/*
	 * Display manager view
	 */
	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.useradmin.IUserAdmin#getPendingUsers()
	 */
	/*public List getPendingUsers() throws Exception{
		List usersList = null;
		List entityList = new ArrayList();
		C3parUsersDAO c3parUsersDAO = null;
		log.debug("Entered UserAdminImpl::getPendingUsers method!");
		try {
			c3parSession.getConnection();
			usersList = C3parUsersDAO.findByIsActive("P", c3parSession);
			c3parUsersDAO = new C3parUsersDAO(c3parSession);
			
			if(usersList != null && usersList.size() > 0){
				entityList = c3parUsersDAO.get(usersList, true);
			}else{
				return null;
			}
		} catch (Exception e) {
			log.error(e);
			throw e;
		}finally{
			if(c3parSession!=null){
				c3parSession.releaseConnection();
			}
		}
		log.debug("Exiting UserAdminImpl::getPendingUsers method! Size of List ===> " + entityList.size());
		return entityList;
	}*/

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.useradmin.IUserAdmin#updateStatus(java.lang.String, java.lang.String, java.lang.String)
	 */
	public void updateStatus(String strSOEId, String strIsActive, String strWFStatus){
		log.debug("Entered UserAdminImpl::updateStatus() Method! Input ===>" + strSOEId);
		/*List usersList = null;
		c3parSession = new C3parSession();
		Long userId = null;
		C3parUsersEntity c3parUserEntity = null;
		
		try {
			c3parSession.getConnection();
			usersList = C3parUsersDAO.findBySsoId(strSOEId, c3parSession);
			if(usersList != null && usersList.size() >0 ){
				userId = (Long) usersList.get(0);
			}
			
			if(userId != null){
				c3parUserDao = new C3parUsersDAO(c3parSession);
				c3parUserEntity = c3parUserDao.get(userId);
				if(!("".equals(strIsActive))){
					c3parUserEntity.setIsActive(strIsActive);
				}
				if(!("".equals(strWFStatus))){
					c3parUserEntity.setWfStatus(strWFStatus);
				}
				c3parUserDao.update(c3parUserEntity);
				if(strWFStatus != null && ("Completed".equals(strWFStatus) || "Bulk_Uploaded".equals(strWFStatus)
						 || "sys_new_user".equals(strWFStatus) || "sys_update_user".equals(strWFStatus))){
					auditC3parUsersData(strSOEId);
				}
				log.debug("Status of User Id ==> " + strSOEId + " Updated succesfully");
			}
		} catch (Exception e) {
			log.error(e.getStackTrace().toString());
		}finally{
			
			if(c3parSession!=null){
				c3parSession.releaseConnection();
			}
		}*/
		Session session = null;
		try {
			session = getTXSession();
			C3parUser usr = getC3parUserData(strSOEId, false, session);
			if (usr != null && usr.getId() != null
					&& usr.getId().longValue() > 0) {
				if (!("".equals(strIsActive))) {
					usr.setActive(strIsActive);
				}
				if (!("".equals(strWFStatus))) {
					usr.setWfStatus(strWFStatus);
				}
				session.update(usr);
				if (strWFStatus != null
						&& ("Completed".equals(strWFStatus)
								|| "Bulk_Uploaded".equals(strWFStatus)
								|| "sys_new_user".equals(strWFStatus) || "sys_update_user"
									.equals(strWFStatus))) {
					auditC3parUsersData(strSOEId);
				}
				log.debug("Status of User Id ==> " + strSOEId
						+ " Updated succesfully");
			} else {
				log.info("User Id " + strSOEId
						+ " ==> Unable to find entry in the database.");
			}
		} catch (Exception e) {
			log.info("Error in UserAdminImpl::updateStatus()");
			log.error(e, e);
		} finally {
			closeTXSession(session);
		}

	}
	
	/**
	 * Audit c3par users data.
	 *
	 * @param ssoId the sso id
	 * @return the string
	 */
	private void auditC3parUsersData(String ssoId){
		/*Connection connection = null;
		CallableStatement cs = null;
		String retValue=null;
		try {
			connection = (new C3parSession()).getConnection();
			connection.setAutoCommit(false);
			cs = connection.prepareCall("{? = call insertUserAuditData(?)}");
	        cs.registerOutParameter(1, Types.VARCHAR);
	        cs.setString(2, ssoId);
	        cs.execute();
	        retValue = cs.getString(1);
	        if("true".equals(retValue)){
	        	connection.commit();
	        }
		} catch (Exception e) {
			log.error(e);
		} finally {
			try {
				cs.close();
				connection.close();
			} catch (Exception e) {
				log.error(e);
			}
		}
		return retValue;*/
		try{
			log.debug("UserAdminImpl :: auditC3parUsersData method starts...");
//			Session session = getSession();
		/*	Query query = session.createSQLQuery("{ call C3PAR.insertUserAuditData(?) }");
			query.setString(0, ssoId);
			query.executeUpdate();*/

	    	//session.getNamedQuery("userauditdata").setString(0, ssoId).list();

			//Commented for Audit Log Requirement
			/*Query q1 = session.createSQLQuery("{ call insertuseraudit(?) }");
			q1.setString(0, ssoId);
			q1.executeUpdate();*/
			
			log.debug("UserAdminImpl :: auditC3parUsersData method ends...");
		}catch(Exception e){
			log.info("Error in UserAdminImpl::auditC3parUsersData()");
			log.error(e,e);
		}
	}
	
	@Transactional(readOnly = true)	
	public boolean isGIDACMPReady() throws Exception {
		boolean isGIDACMPReady = true;
		
		/*UserAdminHelper userAdminHelper = new UserAdminHelper();
		 
		String ret = userAdminHelper.isGIDACMPReady();
		
		if (ret != null && ret.equalsIgnoreCase("Y")) {
			isGIDACMPReady = true;
		}*/
		
		return isGIDACMPReady;
	}

	public C3PARUser convertC3PARUserToDO(C3parUser user) {
		C3PARUser c3parUser = new C3PARUser();
		log.debug("UserAdminImpl::convertC3PARUserToDO() Method starts");
		try{
			c3parUser.setSsoId(user.getSsoId());
			c3parUser.setFirstName(user.getFirstName());
			c3parUser.setLastName(user.getLastName());
	
			if(user.getActive() == null || "N".equals(user.getActive())){
				c3parUser.setActive(false);
			} else if("Y".equals(user.getActive()) || "P".equals(user.getActive())){
				c3parUser.setActive(true);
			}		
			//userDTO.setComments(user.getComments());
			c3parUser.setDisplayName(user.getFirstName() +" "+ user.getLastName());
			//userDTO.setDisplayEntitlements(user.getDisplayEntitlements());
			//userDTO.setDisplayRoles(user.getDisplayRoles());
			c3parUser.setEmail(user.getEmail());
			c3parUser.setEntitlements((String[])getEntitlementList(user));
			c3parUser.setRoles((String[])getRoleList(user));
			//userDTO.setFax(user.getFax());
			c3parUser.setManagerApprover(user.getManagerApprover());
			c3parUser.setManagerReviewedDate(user.getMgrReviewedDate());
			//userDTO.setOrganizationUnit(user.getOrganizationUnit());
			c3parUser.setPassword(user.getPassword());
			c3parUser.setRequestedBy(user.getRequestedBy());
			c3parUser.setSysadminApprover(user.getSysadminApprover());
			c3parUser.setSysadminReviewedDate(user.getSysadminReviewedDate());
			//userDTO.setTelephone(user.getTelephone());
			c3parUser.setWfStatus(user.getWfStatus());
		}catch (Exception e){
			log.error(e, e);
		}
		log.debug("UserAdminImpl::convertC3PARUserToDO() Method ends");
		
		return c3parUser;
	}
	
	public C3PARUserDTO convertC3PARUsersToDTO(C3PARUser user) {
		log.debug("UserAdminImpl :: convertC3PARUsersToDTO method starts.....");
		C3PARUserDTO userDTO=new C3PARUserDTO();
		try{
			userDTO.setSsoId(user.getSsoId());
			userDTO.setFirstName(user.getFirstName());
			userDTO.setLastName(user.getLastName());
			userDTO.setActive(user.isActive());
			userDTO.setComments(user.getComments());
			userDTO.setDisplayName(user.getDisplayName());
			userDTO.setDisplayEntitlements(user.getDisplayEntitlements());
			userDTO.setDisplayRoles(user.getDisplayRoles());
			userDTO.setEmail(user.getEmail());
			userDTO.setEntitlements(user.getEntitlements());
			userDTO.setRoles(user.getRoles());
			userDTO.setFax(user.getFax());
			userDTO.setManagerApprover(user.getManagerApprover());
			userDTO.setManagerReviewedDate(user.getManagerReviewedDate());
			userDTO.setOrganizationUnit(user.getOrganizationUnit());
			userDTO.setPassword(user.getPassword());
			userDTO.setRequestedBy(user.getRequestedBy());
			userDTO.setSysadminApprover(user.getSysadminApprover());
			userDTO.setSysadminReviewedDate(user.getSysadminReviewedDate());
			userDTO.setTelephone(user.getTelephone());
			userDTO.setWfStatus(user.getWfStatus());
		}catch (Exception e){
			log.error(e, e);
		}
		log.debug("UserAdminImpl :: convertC3PARUsersToDTO method ends.....");
		
		return userDTO;		
	}
	
	
	/*
	 * To get the sector/region parametric roles for BPM
	 */
	/**
	 * 
	 * @param user
	 * @return
	 */
	private String[] getEntitlementList(C3parUser user){
		log.debug("UserAdminImpl :: getEntitlementList method starts.....");
		Set<String> region = new HashSet<String>();
		Set<String> sector = new HashSet<String>();
		if(user != null && user.getUserHierarchyList() != null && user.getUserHierarchyList().size() > 0){ 
			for(C3parUserHierarchyXref userxref:user.getUserHierarchyList()){
				region.add(userxref.getCitiHierarchyMaster().getRegion().getName());
				sector.add(userxref.getCitiHierarchyMaster().getSector().getName());
			}
		}
		
		
		/*
		 * If ICG is present, add CIB to the List.
		   If GCB is present, add GCG to the List.
		 */
		if (sector.contains("ICG")) {
			sector.add("CIB");
		}
		
		if (sector.contains("GCB")) {
			sector.add("GCG");
		}
		
		
		ArrayList<String> entAList = new ArrayList<String>();
		
		for (String sec : sector) {
			entAList.add(sec);
				/*
			     * New List : It should be ignored for Reg-Sector Combination:
				GLOBAL FUNCTIONS
				O&T
				LCL
				TREASURY
				GCB
				ICG
			 */
			if (!("GLOBAL FUNCTIONS".equalsIgnoreCase(sec) || "O&T".equalsIgnoreCase(sec) || "LCL".equalsIgnoreCase(sec)
					|| "TREASURY".equalsIgnoreCase(sec) || "GCB".equalsIgnoreCase(sec) || "ICG".equalsIgnoreCase(sec))) {
				for (String reg : region) {
					entAList.add(reg+"-"+sec);
				}
			}
		}
		
		log.debug("UserAdminImpl :: getEntitlementList method ends.2....");
		
		String entArray[] = new String[entAList.size()];
		entArray = entAList.toArray(entArray);

		return entArray;
	}
	
	private Object[] getRoleList(C3parUser user){
		log.debug("UserAdminImpl :: getRoleList method starts.....");
		HashSet<String> roleNames = new HashSet<String>();
		if(user != null && user.getUserRoleList() != null && user.getUserRoleList().size() > 0){
			for(C3parUserRoleXref rolexref:user.getUserRoleList()){
				roleNames.add(rolexref.getSecurityRole().getName());
			}
		}
		log.debug("UserAdminImpl::getBulkUploadUsers()::getRoleList()-"+roleNames);
		return roleNames.toArray(new String[0]);
	}
	
	public C3parUser getC3parUserData(String soeId, boolean loadreferences, Session session){
		log.debug("UserAdminImpl :: getC3parUserData method starts...");
		C3parUser usr = null;
		if(soeId != null){
		    if(session == null) {
		        session = getTXSession();
		    }
			Criteria criteria = session.createCriteria(C3parUser.class);
		    criteria.add(Restrictions.eq("ssoId", soeId).ignoreCase());
	
		    usr = (C3parUser)criteria.uniqueResult();
		    if(usr != null && loadreferences){
		    	log.debug("UserAdminImpl :: getC3parUserData::loadreferences");
		    	lazyInitialize(usr.getUserHierarchyList());
		    	lazyInitialize(usr.getUserRoleList());
		    }
			log.debug("UserAdminImpl :: getC3parUserData method ends...");
		}
	    return usr;
	}

	public C3PARUserDTO mapC3parUserToDTO(C3parUser c3parusr){
		C3PARUserDTO c3parUserDTO = new C3PARUserDTO();
		C3PARUser user=convertC3PARUserToDO(c3parusr);
		c3parUserDTO=convertC3PARUsersToDTO(user);
		return c3parUserDTO;
	}
	
}
