package com.citigroup.cgti.c3par.bpm.ejb.search.domain;

import java.io.Serializable;


/**
 * The Class AppsenseSearchAttributes.
 */
public class AppsenseSearchAttributes extends BaseSearchAttributes implements Serializable{

    /**
     * Serial Version Id.
     */
    private static final long serialVersionUID = 8449699279697192899L;

    /** The application name. */
    private String applicationName=null;

    /** The csi id. */
    private String csiId=null;

    /** The user soe id. */
    private String userSOEId=null;

    /** The policy name. */
    private String policyName=null;

    /** The instance name. */
    private String instanceName=null; 

    /**
     * Gets the application name.
     *
     * @return the application name
     */
    public String getApplicationName() {
	return applicationName;
    }

    public String getApplicationNameForQuery() {
	return validString(applicationName);
    }

    /**
     * Sets the application name.
     *
     * @param applicationName the new application name
     */
    public void setApplicationName(String applicationName) {
	this.applicationName = applicationName;
    }

    /**
     * Gets the csi id.
     *
     * @return the csi id
     */
    public String getCsiId() {
	return csiId;
    }

    public String getCsiIdForQuery() {
	return validString(csiId);
    }

    /**
     * Sets the csi id.
     *
     * @param csiId the new csi id
     */
    public void setCsiId(String csiId) {
	this.csiId = csiId;
    }

    /**
     * Gets the user soe id.
     *
     * @return the user soe id
     */
    public String getUserSOEId() {
	return userSOEId;
    }

    public String getUserSOEIdForQuery() {
	return validString(userSOEId);
    }

    /**
     * Sets the user soe id.
     *
     * @param userSOEId the new user soe id
     */
    public void setUserSOEId(String userSOEId) {
	this.userSOEId = userSOEId;
    }

    /**
     * Gets the policy name.
     *
     * @return the policy name
     */
    public String getPolicyName() {
	return policyName;
    }

    public String getPolicyNameForQuery() {
	return validString(policyName);
    }

    /**
     * Sets the policy name.
     *
     * @param policyName the new policy name
     */
    public void setPolicyName(String policyName) {
	this.policyName = policyName;
    }

    /**
     * Gets the instance name.
     *
     * @return the instance name
     */
    public String getInstanceName() {
	return instanceName;
    }

    public String getInstanceNameForQuery() {
	return validString(instanceName);
    }

    /**
     * Sets the instance name.
     *
     * @param instanceName the new instance name
     */
    public void setInstanceName(String instanceName) {
	this.instanceName = instanceName;
    }




}
