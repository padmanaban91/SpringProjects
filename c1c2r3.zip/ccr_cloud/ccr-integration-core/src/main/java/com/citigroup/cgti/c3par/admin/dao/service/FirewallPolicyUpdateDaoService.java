package com.citigroup.cgti.c3par.admin.dao.service;

import java.util.List;
import com.citigroup.cgti.c3par.common.domain.ApplicationInstance;
import com.citigroup.cgti.c3par.common.domain.FirewallLocation;
import com.citigroup.cgti.c3par.fw.domain.FireWallPolicyGroup;
import com.citigroup.cgti.c3par.fw.domain.FirewallPolicy;
import com.citigroup.cgti.c3par.fw.domain.FirewallRegion;

/**
 * 
 *
 * @author ac81662
 */

public interface FirewallPolicyUpdateDaoService {

    public List<FirewallPolicy> getPolicyList(String searchPolicyName) throws Exception;

    public FirewallRegion getFirewallRegion(String mgmtRegion) throws Exception;

    public FireWallPolicyGroup getFireWallPolicyGroup(String group) throws Exception;

    public ApplicationInstance getApplicationInstance(String applicationInstance) throws Exception;

    public Long savePolicy(FirewallPolicy firewallPolicy) throws Exception;

    public List<String> getFwLocationList() throws Exception;

    public List<String> getMgmtRegionList() throws Exception;

    public List<String> getGroupList() throws Exception;

    public List<String> getApplicationInstanceList() throws Exception;

    public FirewallLocation getFirewallLocation(String fwLocation) throws Exception;

    public boolean updateFirewallPolicy(FirewallPolicy firewallPolicy);

}
