package com.citigroup.cgti.c3par.appsense.domain;


import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.citigroup.cgti.c3par.domain.Base;



/**
 * The Class ConnectionIPMaster.
 */
@XmlRootElement
public class ConnectionIPMaster extends Base {	

    /** The user input type. */
    private String userInputType;

    /** The ip address. */
    private String ipAddress;

    /** The formatted ip. */
    private String formattedIP;                   
    //	private String natIPAddress ;               
    /** The host name. */
    private String hostName ;                     

    /** The resource type. */
    private Long resourceType ;                 

    /** The start ip address. */
    private String startIPAddress;               

    /** The formatted start ip. */
    private String formattedStartIP;            

    /** The end ip address. */
    private String endIPAddress;               

    /** The formatted end ip. */
    private String formattedEndIP;               

    /** The subnet. */
    private String subnet;                         

    /** The no of host. */
    private Long noOfHost;                     

    /** The broad cast address. */
    private String broadCastAddress;             

    /** The resource type old. */
    private String resourceTypeOld;             

    /** The share flag. */
    private String shareFlag;                    

    /** The delete flag. */
    private String deleteFlag;

    /** The is private ip. */
    private String isPrivateIP;

    /** The justification. */
    private String justification;

    /** The connection vip list. */
    private List connectionVIPList = new ArrayList();

    /** The network functional area. */
    private Long networkFunctionalArea;

    /** The relationship. */
    private Long relationship;

    /** The description. */
    private String description;

    /** The template flag. */
    private String templateFlag;

    /** The is any ip. */
    private String isAnyIp;



    /**
     * Instantiates a new connection ip master.
     */
   /* public ConnectionIPMaster() {

	//----------
	setTableName(PerformerTypes.CONN_IP_MASTER_TABEL);
	setSequenceName(PerformerTypes.CONN_IP_MASTER_SEQ);
	//----------
	addToDBMapping("ipAddress","ip_Address",1);
	addToDBMapping("formattedIP","formatted_IP",2);
	//		addToDBMapping("natIPAddress","nat_IP_Address");
	addToDBMapping("hostName","host_Name",3);
	addToDBMapping("resourceType","resource_Type",4);
	addToDBMapping("startIPAddress","start_IP_Address",5);
	addToDBMapping("formattedStartIP","formatted_Start_IP",6);
	addToDBMapping("endIPAddress","end_IP_Address",7);
	addToDBMapping("formattedEndIP","formatted_End_IP",8);
	addToDBMapping("subnet","subnet",9);
	addToDBMapping("noOfHost","no_Of_Host",10);
	addToDBMapping("broadCastAddress","BroadCast_Address",11);
	addToDBMapping("resourceTypeOld","resource_Type_Old",12);
	addToDBMapping("shareFlag","share_Flag",13);
	addToDBMapping("deleteFlag","delete_Flag",14);
	addToDBMapping("isPrivateIP","IS_PRIVATE_IP",15);
	addToDBMapping("justification","JUSTIFICATION_TEXT",16);
	addToDBMapping("networkFunctionalArea","NETWORK_FUNCT_AREA",17);
	addToDBMapping("relationship","RELATIONSHIP_ID",18);
	addToDBMapping("created_date","created_date",19);
	addToDBMapping("updated_date","updated_date",20);
	addToDBMapping("description","DESCRIPTION",21);
	addToDBMapping("templateFlag","TEMPLATE_FLAG",22);
	addToDBMapping("isAnyIp","IS_ANY_IP",23);
	//---------------------------------
	addToNonPersistanceList("userInputType");

	//--------------------------------
	addToChildList("connectionVIPList",new ConnectionVIPMaster());
	//--------------------------------
	addToDefaultValueMap("shareFlag", "F");
	addToDefaultValueMap("deleteFlag", "F");
	addToDefaultValueMap("templateFlag", "N");


    }
*/


    /**
     * Gets the formatted ip.
     *
     * @return Returns the formattedIP.
     */
    public String getFormattedIP() {
	return formattedIP;
    }

    /**
     * Sets the formatted ip.
     *
     * @param formattedIP The formattedIP to set.
     */
    public void setFormattedIP(String formattedIP) {
	this.formattedIP = formattedIP;
    }

    /**
     * Gets the formatted start ip.
     *
     * @return Returns the formattedStartIP.
     */
    public String getFormattedStartIP() {
	return formattedStartIP;
    }

    /**
     * Sets the formatted start ip.
     *
     * @param formattedStartIP The formattedStartIP to set.
     */
    public void setFormattedStartIP(String formattedStartIP) {
	this.formattedStartIP = formattedStartIP;
    }

    /**
     * Gets the broad cast address.
     *
     * @return the broad cast address
     */
    public String getBroadCastAddress() {
	return broadCastAddress;
    }

    /**
     * Sets the broad cast address.
     *
     * @param broadCastAddress the new broad cast address
     */
    public void setBroadCastAddress(String broadCastAddress) {
	this.broadCastAddress = broadCastAddress;
    }

    /**
     * Gets the delete flag.
     *
     * @return the delete flag
     */
    public String getDeleteFlag() {
	return deleteFlag;
    }

    /**
     * Sets the delete flag.
     *
     * @param deleteFlag the new delete flag
     */
    public void setDeleteFlag(String deleteFlag) {
	this.deleteFlag = deleteFlag;
    }

    /**
     * Gets the end ip address.
     *
     * @return the end ip address
     */
    public String getEndIPAddress() {
	return endIPAddress;
    }

    /**
     * Sets the end ip address.
     *
     * @param endIPAddress the new end ip address
     */
    public void setEndIPAddress(String endIPAddress) {
	this.endIPAddress = endIPAddress;
    }

    /**
     * Gets the formatted end ip.
     *
     * @return the formatted end ip
     */
    public String getFormattedEndIP() {
	return formattedEndIP;
    }

    /**
     * Sets the formatted end ip.
     *
     * @param formattedEndIP the new formatted end ip
     */
    public void setFormattedEndIP(String formattedEndIP) {
	this.formattedEndIP = formattedEndIP;
    }

    /**
     * Gets the host name.
     *
     * @return the host name
     */
    public String getHostName() {
	return hostName;
    }

    /**
     * Sets the host name.
     *
     * @param hostName the new host name
     */
    public void setHostName(String hostName) {
	this.hostName = hostName;
    }

    /**
     * Gets the ip address.
     *
     * @return the ip address
     */
    @XmlElement
    public String getIpAddress() {
	return ipAddress;
    }

    /**
     * Sets the ip address.
     *
     * @param ipAddress the new ip address
     */
    public void setIpAddress(String ipAddress) {
	this.ipAddress = ipAddress;
    }



    /**
     * Gets the no of host.
     *
     * @return Returns the natIPAddress.
     *//*
	public String getNatIPAddress() {
		return natIPAddress;
	}
     
    /**
     * Gets the resource type.
     *
     * @return the resource type
     */
    public Long getResourceType() {
	return resourceType;
    }

    /**
     * Sets the resource type.
     *
     * @param resourceType the new resource type
     */
    public void setResourceType(Long resourceType) {
	this.resourceType = resourceType;
    }

    /**
     * Gets the resource type old.
     *
     * @return the resource type old
     */
    public String getResourceTypeOld() {
	return resourceTypeOld;
    }

    public Long getNoOfHost() {
		return noOfHost;
	}

	public void setNoOfHost(Long noOfHost) {
		this.noOfHost = noOfHost;
	}

	/**
     * Sets the resource type old.
     *
     * @param resourceTypeOld the new resource type old
     */
    public void setResourceTypeOld(String resourceTypeOld) {
	this.resourceTypeOld = resourceTypeOld;
    }

    /**
     * Gets the share flag.
     *
     * @return the share flag
     */
    public String getShareFlag() {
	return shareFlag;
    }

    /**
     * Sets the share flag.
     *
     * @param shareFlag the new share flag
     */
    public void setShareFlag(String shareFlag) {
	this.shareFlag = shareFlag;
    }

    /**
     * Gets the start ip address.
     *
     * @return the start ip address
     */
    public String getStartIPAddress() {
	return startIPAddress;
    }           

    /**
     * Sets the start ip address.
     *
     * @param startIPAddress the new start ip address
     */
    public void setStartIPAddress(String startIPAddress) {
	this.startIPAddress = startIPAddress;
    }

    /**
     * Gets the subnet.
     *
     * @return the subnet
     */
    public String getSubnet() {
	return subnet;
    }

    /**
     * Sets the subnet.
     *
     * @param subnet the new subnet
     */
    public void setSubnet(String subnet) {
	this.subnet = subnet;
    }

    /**
     * Gets the user input type.
     *
     * @return the user input type
     */
    public String getUserInputType() {
	return userInputType;
    }

    /**
     * Sets the user input type.
     *
     * @param userInputType the new user input type
     */
    public void setUserInputType(String userInputType) {
	this.userInputType = userInputType;
    }



    /**
     * Gets the connection vip list.
     *
     * @return the connection vip list
     */
    public List getConnectionVIPList() {
	return connectionVIPList;
    }



    /**
     * Sets the connection vip list.
     *
     * @param connectionVIPList the new connection vip list
     */
    public void setConnectionVIPList(List connectionVIPList) {
	this.connectionVIPList = connectionVIPList;
    }



    /**
     * Gets the network functional area.
     *
     * @return the network functional area
     */
    public Long getNetworkFunctionalArea() {
	return networkFunctionalArea;
    }



    /**
     * Sets the network functional area.
     *
     * @param networkFunctionalArea the new network functional area
     */
    public void setNetworkFunctionalArea(Long networkFunctionalArea) {
	this.networkFunctionalArea = networkFunctionalArea;
    }



    /**
     * Gets the checks if is private ip.
     *
     * @return the checks if is private ip
     */
    public String getIsPrivateIP() {
	return isPrivateIP;
    }



    /**
     * Sets the checks if is private ip.
     *
     * @param isPrivateIP the new checks if is private ip
     */
    public void setIsPrivateIP(String isPrivateIP) {
	this.isPrivateIP = isPrivateIP;
    }



    /**
     * Gets the justification.
     *
     * @return the justification
     */
    public String getJustification() {
	return justification;
    }



    /**
     * Sets the justification.
     *
     * @param justification the new justification
     */
    public void setJustification(String justification) {
	this.justification = justification;
    }



    /**
     * Gets the relationship.
     *
     * @return the relationship
     */
    public Long getRelationship() {
	return relationship;
    }



    /**
     * Sets the relationship.
     *
     * @param relationship the new relationship
     */
    public void setRelationship(Long relationship) {
	this.relationship = relationship;
    }



    /**
     * Gets the description.
     *
     * @return the description
     */
    public String getDescription() {
	return description;
    }



    /**
     * Sets the description.
     *
     * @param description the new description
     */
    public void setDescription(String description) {
	this.description = description;
    }



    /**
     * Gets the template flag.
     *
     * @return the template flag
     */
    public String getTemplateFlag() {
	return templateFlag;
    }



    /**
     * Sets the template flag.
     *
     * @param templateFlag the new template flag
     */
    public void setTemplateFlag(String templateFlag) {
	this.templateFlag = templateFlag;
    }


    /**
     * Gets the checks if is any ip.
     *
     * @return the checks if is any ip
     */
    public String getIsAnyIp() {
	return isAnyIp;
    }



    /**
     * Sets the checks if is any ip.
     *
     * @param isAnyIp the new checks if is any ip
     */
    public void setIsAnyIp(String isAnyIp) {
	this.isAnyIp = isAnyIp;
    }


}
