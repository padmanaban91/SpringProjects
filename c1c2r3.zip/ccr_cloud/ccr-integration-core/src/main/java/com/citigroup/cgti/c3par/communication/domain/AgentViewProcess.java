package com.citigroup.cgti.c3par.communication.domain;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;
import com.citigroup.cgti.c3par.bpm.ejb.domain.TIProcessDTO;
import com.citigroup.cgti.c3par.common.domain.soc.persist.AdminServicePersistable;
import com.citigroup.cgti.c3par.communication.domain.service.EcmUserPreferenceDaoService;
import com.citigroup.cgti.c3par.communication.domain.soc.persist.AgentViewPersistable;

public class AgentViewProcess extends CMPReleasedMailGenerationProcess{

    @Autowired
    private AdminServicePersistable adminServicePersistable;

    private CMPRequest resolveITMessage;

    private List<CMPRequest> resolveITMessageList;
    private List<AgentView> agentViewDetailsList;
    private List<String> columnList;
    private Map<Long,String> map=new TreeMap<Long,String>();
    private Long allInProgress;

    private Long fw;

    private Long proxy;

    private Long ipReg;

    private Long term;

    private Long assist;
    
    private Long secAcl;
    
    private Long appsense;

    private Long comp;

    private Long canc;

    private Long agent;

    private Long avg;

    private String sectorAgent;

    private String servicenowURL;
    // pagination properties
    private int limit;
    private int rowCount;
    private int offset;

    private int pageNo;
    private String field;
    private int totalPages;

    private int recordStartCount;
    private int recordEndCount;
    private int totalRecords;

    private String orderBy;
    private String sortingColumnName;

    private String errorMessage;

    private String selectedColumnName;

    private String processName;

    private String sameColumnSelected;

    private TIProcessDTO tiProcessDTO;

    private List<String> viewColumnNamesList;
    
    private String connectionType;
    private String ecomType;
    
    private String filterColumn;
    
    private String filterValue;
    private String ssoId;
    private String viewId;
    private Long columnIndex;
    private String sortBy;
    private Long resultPerPage;
    public String getSsoId() {
        return ssoId;
    }

    public void setSsoId(String ssoId) {
        this.ssoId = ssoId;
    }

    public String getViewId() {
        return viewId;
    }

    public void setViewId(String viewId) {
        this.viewId = viewId;
    }
       
    public Long getColumnIndex() {
        return columnIndex;
    }

    public void setColumnIndex(Long columnIndex) {
        this.columnIndex = columnIndex;
    }

    public String getSortBy() {
        return sortBy;
    }

    public void setSortBy(String sortBy) {
        this.sortBy = sortBy;
    }
    public Long getResultPerPage() {
        return resultPerPage;
    }

    public void setResultPerPage(Long resultPerPage) {
        this.resultPerPage = resultPerPage;
    }

    public String getConnectionType() {
        return connectionType;
    }

    public void setConnectionType(String connectionType) {
        this.connectionType = connectionType;
    }
    

    public String getEcomType() {
        return ecomType;
    }

    public void setEcomType(String ecomType) {
        this.ecomType = ecomType;
    }

    public String getFilterColumn() {
        return filterColumn;
    }

    public void setFilterColumn(String filterColumn) {
        this.filterColumn = filterColumn;
    }

    public String getFilterValue() {
        return filterValue;
    }

    public void setFilterValue(String filterValue) {
        this.filterValue = filterValue;
    }

    public CMPRequest getResolveITMessage() {
        return resolveITMessage;
    }

    public void setResolveITMessage(CMPRequest resolveITMessage) {
        this.resolveITMessage = resolveITMessage;
    }

    public AgentViewPersistable getAgentViewPersistable() {
        return ccrBeanFactory.getAgentViewPersistable();
    }

    public AdminServicePersistable getAdminServicePersistable() {
        return adminServicePersistable;
    }

    public void setAdminServicePersistable(AdminServicePersistable adminServicePersistable) {
        this.adminServicePersistable = adminServicePersistable;
    }

    public List<CMPRequest> getResolveITMessageList() {
        return resolveITMessageList;
    }

    public void setResolveITMessageList(List<CMPRequest> resolveITMessageList) {
        this.resolveITMessageList = resolveITMessageList;
    }
    
    
    /*
     * public RFCService getRfc() { return rfc; }
     * 
     * public void setRfc(RFCService rfc) { this.rfc = rfc; }
     */

    public List<AgentView> getAgentViewDetailsList() {
        return agentViewDetailsList;
    }

    public void setAgentViewDetailsList(List<AgentView> agentViewDetailsList) {
        this.agentViewDetailsList = agentViewDetailsList;
    }

    public List<String> getColumnList() {
        return columnList;
    }

    public void setColumnList(List<String> columnList) {
        this.columnList = columnList;
    }
    

    public Map<Long, String> getMap() {
        return map;
    }

    public void setMap(Map<Long, String> map) {
        this.map = map;
    }

    public String getServicenowURL() {
        return servicenowURL;
    }

    public void setServicenowURL(String servicenowURL) {
        this.servicenowURL = servicenowURL;
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }

    public int getRowCount() {
        return rowCount;
    }

    public void setRowCount(int rowCount) {
        this.rowCount = rowCount;
    }

    public int getOffset() {
        return offset;
    }

    public void setOffset(int offset) {
        this.offset = offset;
    }

    public int getPageNo() {
        return pageNo;
    }

    public void setPageNo(int pageNo) {
        this.pageNo = pageNo;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public int getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(int totalPages) {
        this.totalPages = totalPages;
    }

    public Long getAvg() {
        return avg;
    }

    public void setAvg(Long avg) {
        this.avg = avg;
    }

    public int getRecordStartCount() {
        return recordStartCount;
    }

    public void setRecordStartCount(int recordStartCount) {
        this.recordStartCount = recordStartCount;
    }

    public int getRecordEndCount() {
        return recordEndCount;
    }

    public void setRecordEndCount(int recordEndCount) {
        this.recordEndCount = recordEndCount;
    }

    public int getTotalRecords() {
        return totalRecords;
    }

    public void setTotalRecords(int totalRecords) {
        this.totalRecords = totalRecords;
    }

    public Long getAgent() {
        return agent;
    }

    public void setAgent(Long agent) {
        this.agent = agent;
    }

    public String getOrderBy() {
        return orderBy;
    }

    public void setOrderBy(String orderBy) {
        this.orderBy = orderBy;
    }

    public String getSortingColumnName() {
        return sortingColumnName;
    }

    public void setSortingColumnName(String sortingColumnName) {
        this.sortingColumnName = sortingColumnName;
    }

    public Long getAllInProgress() {
        return allInProgress;
    }

    public void setAllInProgress(Long allInProgress) {
        this.allInProgress = allInProgress;
    }

    public Long getFw() {
        return fw;
    }

    public void setFw(Long fw) {
        this.fw = fw;
    }

    public Long getProxy() {
        return proxy;
    }

    public void setProxy(Long proxy) {
        this.proxy = proxy;
    }

    public Long getTerm() {
        return term;
    }

    public void setTerm(Long term) {
        this.term = term;
    }

    public Long getAssist() {
        return assist;
    }

    public void setAssist(Long assist) {
        this.assist = assist;
    }
    public Long getSecAcl() {
        return secAcl;
    }

    public void setSecAcl(Long secAcl) {
        this.secAcl = secAcl;
    }

    public Long getAppsense() {
        return appsense;
    }

    public void setAppsense(Long appsense) {
        this.appsense = appsense;
    }

    public Long getComp() {
        return comp;
    }

    public void setComp(Long comp) {
        this.comp = comp;
    }

    public Long getCanc() {
        return canc;
    }

    public void setCanc(Long canc) {
        this.canc = canc;
    }

    public Long getIpReg() {
        return ipReg;
    }

    public void setIpReg(Long ipReg) {
        this.ipReg = ipReg;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getSelectedColumnName() {
        return selectedColumnName;
    }

    public void setSelectedColumnName(String selectedColumnName) {
        this.selectedColumnName = selectedColumnName;
    }

    public String getProcessName() {
        return processName;
    }

    public void setProcessName(String processName) {
        this.processName = processName;
    }

    public String getSameColumnSelected() {
        return sameColumnSelected;
    }

    public void setSameColumnSelected(String sameColumnSelected) {
        this.sameColumnSelected = sameColumnSelected;
    }

    public TIProcessDTO getTiProcessDTO() {
        return tiProcessDTO;
    }

    public void setTiProcessDTO(TIProcessDTO tiProcessDTO) {
        this.tiProcessDTO = tiProcessDTO;
    }

    public String getSectorAgent() {
        return sectorAgent;
    }

    public void setSectorAgent(String sectorAgent) {
        this.sectorAgent = sectorAgent;
    }

    public List<CmpConnectionDetail> getProcessList(String ccrId) {
        return ccrBeanFactory.getAgentViewPersistable().getProcessList(ccrId);
    }

    public long insertProcess(TIProcessDTO tiProcessDTO) throws Exception {
        return ccrBeanFactory.getManageTIProcessImpl().insertProcess(tiProcessDTO);
    }

    public int updateCCRId(String cmpOrderId, Long tireqId) {
        return ccrBeanFactory.getAgentViewPersistable().updateCCRId(cmpOrderId, tireqId);
    }

    public int updateCmpId(String cmpOrderId, Long tireqId) {
        return ccrBeanFactory.getAgentViewPersistable().updateCmpId(cmpOrderId, tireqId);
    }

    public String getSnUrl() {
        return ccrBeanFactory.getRfc().getSnUrl();
    }

    public List<CMPRequest> getCmpReqData() {
        return ccrBeanFactory.getAgentViewPersistable().getCmpReqData(this);
    }

	public List<AgentView> getAgentViewDetails(boolean isExport) throws Exception {
		EcmUserPreferenceDaoService ecmUserPreferenceDaoService = ccrBeanFactory.getEcmUserPreferenceDaoService();
		EcmUserSetting ecmUserSetting = ecmUserPreferenceDaoService.getUseSetting(this.getSsoId(),
				ECMConstants.ECM_AGENT_VIEW);
		List<ColumnsSortOrderSettings> ecmColumnsOrderSettingsList = new ArrayList<ColumnsSortOrderSettings>();
		if (ecmUserSetting != null) {
			ecmColumnsOrderSettingsList = ecmUserPreferenceDaoService.getEcmColumnsOrderSetting(ecmUserSetting.getId());
		}
		return ccrBeanFactory.getAgentViewPersistable().getAgentViewDetails(this, isExport,
				ecmColumnsOrderSettingsList);
	}

	public List<CCRCMPXref> getCcrCmpXref(String orderItemId) {
		return ccrBeanFactory.getAgentViewPersistable().getCcrCmpXref(orderItemId);
	}

    public Long getUserId(String ssoId) {
        return ccrBeanFactory.getAdminServicePersistable().getUserId(ssoId);
    }

    public List<String> getViewColumnNamesList() {
        return viewColumnNamesList;
    }

    public void setViewColumnNamesList(List<String> viewColumnNamesList) {
        this.viewColumnNamesList = viewColumnNamesList;
    }

}
