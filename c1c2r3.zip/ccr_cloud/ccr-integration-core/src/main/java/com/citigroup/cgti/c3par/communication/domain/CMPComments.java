package com.citigroup.cgti.c3par.communication.domain;

import java.io.Serializable;
import java.util.Date;

import com.citigroup.cgti.c3par.common.domain.TIMailAudit;
import com.citigroup.cgti.c3par.domain.TIRequest;

/**
 * @author ky38518
 * 
 */
public class CMPComments implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;
    private Long cmpId;
    private Long tiRequestId;
    private Long mailAuditId;
    private Date createdDate;
    private String ecmComments;
    private String businessUserComments;
    private TIMailAudit tiMailAudit;
    
    private String businessJustificationReqInfo;

    private String businessJustificationBUResponse;

    private String citiGrpDataReqInfo;

    private String citiGrpDataBUResponse;

    private String customerDataReqInfo;

    private String customerDataBUResponse;

    private String connectionFreqencyReqInfo;

    private String connectionFreqencyBUResponse;

    private String gocCodeReqInfo;

    private String gocCodeBUResponse;

    private String typeOfEntityReqInfo;

    private String typeOfEntityBUResponse;

    private String directAccessReqInfo;

    private String directAccessBUResponse;

    private String reasonReqInfo;

    private String reasonBUResponse;

    private String urgencyReqInfo;

    private String urgencyBUResponse;

    private String affectedBusinessReqInfo;

    private String affectedBusinessBUResponse;

    private String reqSSOId;

    private String buSSOId;
    
    private Date updatedDate;
    
    private String regionReqInfo;

    private String regionBUResponse;

    private String sectorReqInfo;

    private String sectorBUResponse;

    private String businessUnitReqInfo;

    private String businessUnitBUResponse;

    private String companyNameReqInfo;

    private String companyNameBUResponse;

    private String tptContactNameReqInfo;

    private String tptContactNameBUResponse;

    private String caspSuppIdReqInfo;

    private String caspSuppIdBUResponse;

    private String tptContactTypeReqInfo;

    private String tptContactTypeBUResponse;

    private String caspDetailIdReqInfo;

    private String caspDetailIdBUResponse;

    private String tptContactPhoneReqInfo;

    private String tptContactPhoneBUResponse;

    private String tptContactEmailReqInfo;

    private String tptContactEmailBUResponse;

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }


    /**
     * @return the tiRequestId
     */
    public Long getTiRequestId() {
        return tiRequestId;
    }

    /**
     * @param tiRequestId
     *            the tiRequestId to set
     */
    public void setTiRequestId(Long tiRequestId) {
        this.tiRequestId = tiRequestId;
    }

    /**
     * @return the createdDate
     */
    public Date getCreatedDate() {
        return createdDate;
    }

    /**
     * @param createdDate
     *            the createdDate to set
     */
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }


    

    /**
     * @return the cmpId
     */
    public Long getCmpId() {
        return cmpId;
    }

    /**
     * @param cmpId the cmpId to set
     */
    public void setCmpId(Long cmpId) {
        this.cmpId = cmpId;
    }

    
    /**
     * @return the ecmComments
     */
    public String getEcmComments() {
        return ecmComments;
    }

    /**
     * @param ecmComments the ecmComments to set
     */
    public void setEcmComments(String ecmComments) {
        this.ecmComments = ecmComments;
    }

    /**
     * @return the businessUserComments
     */
    public String getBusinessUserComments() {
        return businessUserComments;
    }

    /**
     * @param businessUserComments the businessUserComments to set
     */
    public void setBusinessUserComments(String businessUserComments) {
        this.businessUserComments = businessUserComments;
    }

   
    /**
     * @return the mailAuditId
     */
    public Long getMailAuditId() {
        return mailAuditId;
    }

    /**
     * @param mailAuditId the mailAuditId to set
     */
    public void setMailAuditId(Long mailAuditId) {
        this.mailAuditId = mailAuditId;
    }

    /**
     * @return the tiMailAudit
     */
    public TIMailAudit getTiMailAudit() {
        return tiMailAudit;
    }

    /**
     * @param tiMailAudit the tiMailAudit to set
     */
    public void setTiMailAudit(TIMailAudit tiMailAudit) {
        this.tiMailAudit = tiMailAudit;
    }

    public String getBusinessJustificationReqInfo() {
        return businessJustificationReqInfo;
    }

    public void setBusinessJustificationReqInfo(String businessJustificationReqInfo) {
        this.businessJustificationReqInfo = businessJustificationReqInfo;
    }

    public String getBusinessJustificationBUResponse() {
        return businessJustificationBUResponse;
    }

    public void setBusinessJustificationBUResponse(String businessJustificationBUResponse) {
        this.businessJustificationBUResponse = businessJustificationBUResponse;
    }

    public String getCitiGrpDataReqInfo() {
        return citiGrpDataReqInfo;
    }

    public void setCitiGrpDataReqInfo(String citiGrpDataReqInfo) {
        this.citiGrpDataReqInfo = citiGrpDataReqInfo;
    }

    public String getCitiGrpDataBUResponse() {
        return citiGrpDataBUResponse;
    }

    public void setCitiGrpDataBUResponse(String citiGrpDataBUResponse) {
        this.citiGrpDataBUResponse = citiGrpDataBUResponse;
    }

    public String getCustomerDataReqInfo() {
        return customerDataReqInfo;
    }

    public void setCustomerDataReqInfo(String customerDataReqInfo) {
        this.customerDataReqInfo = customerDataReqInfo;
    }

    public String getCustomerDataBUResponse() {
        return customerDataBUResponse;
    }

    public void setCustomerDataBUResponse(String customerDataBUResponse) {
        this.customerDataBUResponse = customerDataBUResponse;
    }

    public String getConnectionFreqencyReqInfo() {
        return connectionFreqencyReqInfo;
    }

    public void setConnectionFreqencyReqInfo(String connectionFreqencyReqInfo) {
        this.connectionFreqencyReqInfo = connectionFreqencyReqInfo;
    }

    public String getConnectionFreqencyBUResponse() {
        return connectionFreqencyBUResponse;
    }

    public void setConnectionFreqencyBUResponse(String connectionFreqencyBUResponse) {
        this.connectionFreqencyBUResponse = connectionFreqencyBUResponse;
    }

    public String getGocCodeReqInfo() {
        return gocCodeReqInfo;
    }

    public void setGocCodeReqInfo(String gocCodeReqInfo) {
        this.gocCodeReqInfo = gocCodeReqInfo;
    }

    public String getGocCodeBUResponse() {
        return gocCodeBUResponse;
    }

    public void setGocCodeBUResponse(String gocCodeBUResponse) {
        this.gocCodeBUResponse = gocCodeBUResponse;
    }

    public String getTypeOfEntityReqInfo() {
        return typeOfEntityReqInfo;
    }

    public void setTypeOfEntityReqInfo(String typeOfEntityReqInfo) {
        this.typeOfEntityReqInfo = typeOfEntityReqInfo;
    }

    public String getTypeOfEntityBUResponse() {
        return typeOfEntityBUResponse;
    }

    public void setTypeOfEntityBUResponse(String typeOfEntityBUResponse) {
        this.typeOfEntityBUResponse = typeOfEntityBUResponse;
    }

    public String getDirectAccessReqInfo() {
        return directAccessReqInfo;
    }

    public void setDirectAccessReqInfo(String directAccessReqInfo) {
        this.directAccessReqInfo = directAccessReqInfo;
    }

    public String getDirectAccessBUResponse() {
        return directAccessBUResponse;
    }

    public void setDirectAccessBUResponse(String directAccessBUResponse) {
        this.directAccessBUResponse = directAccessBUResponse;
    }

    public String getReasonReqInfo() {
        return reasonReqInfo;
    }

    public void setReasonReqInfo(String reasonReqInfo) {
        this.reasonReqInfo = reasonReqInfo;
    }

    public String getReasonBUResponse() {
        return reasonBUResponse;
    }

    public void setReasonBUResponse(String reasonBUResponse) {
        this.reasonBUResponse = reasonBUResponse;
    }

    public String getUrgencyReqInfo() {
        return urgencyReqInfo;
    }

    public void setUrgencyReqInfo(String urgencyReqInfo) {
        this.urgencyReqInfo = urgencyReqInfo;
    }

    public String getUrgencyBUResponse() {
        return urgencyBUResponse;
    }

    public void setUrgencyBUResponse(String urgencyBUResponse) {
        this.urgencyBUResponse = urgencyBUResponse;
    }

    public String getAffectedBusinessReqInfo() {
        return affectedBusinessReqInfo;
    }

    public void setAffectedBusinessReqInfo(String affectedBusinessReqInfo) {
        this.affectedBusinessReqInfo = affectedBusinessReqInfo;
    }

    public String getAffectedBusinessBUResponse() {
        return affectedBusinessBUResponse;
    }

    public void setAffectedBusinessBUResponse(String affectedBusinessBUResponse) {
        this.affectedBusinessBUResponse = affectedBusinessBUResponse;
    }

    public String getReqSSOId() {
        return reqSSOId;
    }

    public void setReqSSOId(String reqSSOId) {
        this.reqSSOId = reqSSOId;
    }

    public String getBuSSOId() {
        return buSSOId;
    }

    public void setBuSSOId(String buSSOId) {
        this.buSSOId = buSSOId;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getRegionReqInfo() {
        return regionReqInfo;
    }

    public void setRegionReqInfo(String regionReqInfo) {
        this.regionReqInfo = regionReqInfo;
    }

    public String getRegionBUResponse() {
        return regionBUResponse;
    }

    public void setRegionBUResponse(String regionBUResponse) {
        this.regionBUResponse = regionBUResponse;
    }

    public String getSectorReqInfo() {
        return sectorReqInfo;
    }

    public void setSectorReqInfo(String sectorReqInfo) {
        this.sectorReqInfo = sectorReqInfo;
    }

    public String getSectorBUResponse() {
        return sectorBUResponse;
    }

    public void setSectorBUResponse(String sectorBUResponse) {
        this.sectorBUResponse = sectorBUResponse;
    }

    public String getBusinessUnitReqInfo() {
        return businessUnitReqInfo;
    }

    public void setBusinessUnitReqInfo(String businessUnitReqInfo) {
        this.businessUnitReqInfo = businessUnitReqInfo;
    }

    public String getBusinessUnitBUResponse() {
        return businessUnitBUResponse;
    }

    public void setBusinessUnitBUResponse(String businessUnitBUResponse) {
        this.businessUnitBUResponse = businessUnitBUResponse;
    }

    public String getCompanyNameReqInfo() {
        return companyNameReqInfo;
    }

    public void setCompanyNameReqInfo(String companyNameReqInfo) {
        this.companyNameReqInfo = companyNameReqInfo;
    }

    public String getCompanyNameBUResponse() {
        return companyNameBUResponse;
    }

    public void setCompanyNameBUResponse(String companyNameBUResponse) {
        this.companyNameBUResponse = companyNameBUResponse;
    }

    public String getTptContactNameReqInfo() {
        return tptContactNameReqInfo;
    }

    public void setTptContactNameReqInfo(String tptContactNameReqInfo) {
        this.tptContactNameReqInfo = tptContactNameReqInfo;
    }

    public String getTptContactNameBUResponse() {
        return tptContactNameBUResponse;
    }

    public void setTptContactNameBUResponse(String tptContactNameBUResponse) {
        this.tptContactNameBUResponse = tptContactNameBUResponse;
    }

    public String getCaspSuppIdReqInfo() {
        return caspSuppIdReqInfo;
    }

    public void setCaspSuppIdReqInfo(String caspSuppIdReqInfo) {
        this.caspSuppIdReqInfo = caspSuppIdReqInfo;
    }

    public String getCaspSuppIdBUResponse() {
        return caspSuppIdBUResponse;
    }

    public void setCaspSuppIdBUResponse(String caspSuppIdBUResponse) {
        this.caspSuppIdBUResponse = caspSuppIdBUResponse;
    }

    public String getTptContactTypeReqInfo() {
        return tptContactTypeReqInfo;
    }

    public void setTptContactTypeReqInfo(String tptContactTypeReqInfo) {
        this.tptContactTypeReqInfo = tptContactTypeReqInfo;
    }

    public String getTptContactTypeBUResponse() {
        return tptContactTypeBUResponse;
    }

    public void setTptContactTypeBUResponse(String tptContactTypeBUResponse) {
        this.tptContactTypeBUResponse = tptContactTypeBUResponse;
    }

    public String getCaspDetailIdReqInfo() {
        return caspDetailIdReqInfo;
    }

    public void setCaspDetailIdReqInfo(String caspDetailIdReqInfo) {
        this.caspDetailIdReqInfo = caspDetailIdReqInfo;
    }

    public String getCaspDetailIdBUResponse() {
        return caspDetailIdBUResponse;
    }

    public void setCaspDetailIdBUResponse(String caspDetailIdBUResponse) {
        this.caspDetailIdBUResponse = caspDetailIdBUResponse;
    }

    public String getTptContactPhoneReqInfo() {
        return tptContactPhoneReqInfo;
    }

    public void setTptContactPhoneReqInfo(String tptContactPhoneReqInfo) {
        this.tptContactPhoneReqInfo = tptContactPhoneReqInfo;
    }

    public String getTptContactPhoneBUResponse() {
        return tptContactPhoneBUResponse;
    }

    public void setTptContactPhoneBUResponse(String tptContactPhoneBUResponse) {
        this.tptContactPhoneBUResponse = tptContactPhoneBUResponse;
    }

    public String getTptContactEmailReqInfo() {
        return tptContactEmailReqInfo;
    }

    public void setTptContactEmailReqInfo(String tptContactEmailReqInfo) {
        this.tptContactEmailReqInfo = tptContactEmailReqInfo;
    }

    public String getTptContactEmailBUResponse() {
        return tptContactEmailBUResponse;
    }

    public void setTptContactEmailBUResponse(String tptContactEmailBUResponse) {
        this.tptContactEmailBUResponse = tptContactEmailBUResponse;
    }
   
}
