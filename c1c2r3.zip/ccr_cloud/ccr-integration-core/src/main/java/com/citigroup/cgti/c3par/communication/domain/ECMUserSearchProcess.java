package com.citigroup.cgti.c3par.communication.domain;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.communication.domain.soc.persist.EcmLeadViewPersistable;
import com.citigroup.cgti.c3par.communication.domain.soc.persist.EmailGenerationViewServicePersistable;
import com.citigroup.cgti.c3par.user.domain.C3parUser;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

public class ECMUserSearchProcess {
	
	
CCRBeanFactory ccrBeanFactory;
	
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}

	private List<Map<String,String>> cmpReqList;
	private String textFieldName;
	private String searchText;
	private String searchFrom;
	private String assignedUser;
	private List itemValueList; 
	private String orderId;
	private String orderItemId;
	private String status;
	private String step;
	private String availableDate;
	private String closedDate;
	private String orderByUser;
	private String orderBySoeID;
	private String orderForUser;
	private String orderForSoeID;
	private String assignedGroup;
	
	private String firstName;
	private String lastName;
	private String soeId;
	private Long userId;
	private String isLocked;
	private String comments;
	private List<String> ecmUsersList = null;  
	private List<String> ecmUsersoeIdList = null;
	
    public ECMUserSearchProcess(){
		
	}
	
	public ECMUserSearchProcess(String soeId,String lasName,String firstName, String isLocked, String comments){
		super();
		this.soeId = soeId;
		this.lastName = lasName;
		this.firstName = firstName;
		this.isLocked = isLocked;
		this.comments = comments;
	}
	
	
	
	/**
	 * @return the orderId
	 */
	public String getOrderId() {
		return orderId;
	}

	/**
	 * @param orderId the orderId to set
	 */
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	/**
	 * @return the orderItemId
	 */
	public String getOrderItemId() {
		return orderItemId;
	}

	/**
	 * @param orderItemId the orderItemId to set
	 */
	public void setOrderItemId(String orderItemId) {
		this.orderItemId = orderItemId;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the step
	 */
	public String getStep() {
		return step;
	}

	/**
	 * @param step the step to set
	 */
	public void setStep(String step) {
		this.step = step;
	}

	/**
	 * @return the availableDate
	 */
	public String getAvailableDate() {
		return availableDate;
	}

	/**
	 * @param availableDate the availableDate to set
	 */
	public void setAvailableDate(String availableDate) {
		this.availableDate = availableDate;
	}

	/**
	 * @return the closedDate
	 */
	public String getClosedDate() {
		return closedDate;
	}

	/**
	 * @param closedDate the closedDate to set
	 */
	public void setClosedDate(String closedDate) {
		this.closedDate = closedDate;
	}

	/**
	 * @return the orderByUser
	 */
	public String getOrderByUser() {
		return orderByUser;
	}

	/**
	 * @param orderByUser the orderByUser to set
	 */
	public void setOrderByUser(String orderByUser) {
		this.orderByUser = orderByUser;
	}

	/**
	 * @return the orderBySoeID
	 */
	public String getOrderBySoeID() {
		return orderBySoeID;
	}

	/**
	 * @param orderBySoeID the orderBySoeID to set
	 */
	public void setOrderBySoeID(String orderBySoeID) {
		this.orderBySoeID = orderBySoeID;
	}

	/**
	 * @return the orderForUser
	 */
	public String getOrderForUser() {
		return orderForUser;
	}

	/**
	 * @param orderForUser the orderForUser to set
	 */
	public void setOrderForUser(String orderForUser) {
		this.orderForUser = orderForUser;
	}

	/**
	 * @return the orderForSoeID
	 */
	public String getOrderForSoeID() {
		return orderForSoeID;
	}

	/**
	 * @param orderForSoeID the orderForSoeID to set
	 */
	public void setOrderForSoeID(String orderForSoeID) {
		this.orderForSoeID = orderForSoeID;
	}

	/**
	 * @return the assignedGroup
	 */
	public String getAssignedGroup() {
		return assignedGroup;
	}

	/**
	 * @param assignedGroup the assignedGroup to set
	 */
	public void setAssignedGroup(String assignedGroup) {
		this.assignedGroup = assignedGroup;
	}

	/**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the soeId
	 */
	public String getSoeId() {
		return soeId;
	}

	/**
	 * @param soeId the soeId to set
	 */
	public void setSoeId(String soeId) {
		this.soeId = soeId;
	}

	/**
	 * @return the userId
	 */
	public Long getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(Long userId) {
		this.userId = userId;
	}

	/**
	 * @return the isLocked
	 */
	public String getIsLocked() {
		return isLocked;
	}

	/**
	 * @param isLocked the isLocked to set
	 */
	public void setIsLocked(String isLocked) {
		this.isLocked = isLocked;
	}

	/**
	 * @return the comments
	 */
	public String getComments() {
		return comments;
	}

	/**
	 * @param comments the comments to set
	 */
	public void setComments(String comments) {
		this.comments = comments;
	}

	public List<Map<String, String>> getCmpReqList() {
		return cmpReqList;
	}

	public void setCmpReqList(List<Map<String, String>> cmpReqList) {
		this.cmpReqList = cmpReqList;
	}

	public String getTextFieldName() {
		return textFieldName;
	}

	public void setTextFieldName(String textFieldName) {
		this.textFieldName = textFieldName;
	}

	public String getSearchText() {
		return searchText;
	}

	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}

	public String getSearchFrom() {
		return searchFrom;
	}

	public void setSearchFrom(String searchFrom) {
		this.searchFrom = searchFrom;
	}
	
	

	/**
	 * @return the assignedUser
	 */
	public String getAssignedUser() {
		return assignedUser;
	}

	/**
	 * @param assignedUser the assignedUser to set
	 */
	public void setAssignedUser(String assignedUser) {
		this.assignedUser = assignedUser;
	}

	/**
	 * @return the itemValueList
	 */
	public List getItemValueList() {
		return itemValueList;
	}

	/**
	 * @param itemValueList the itemValueList to set
	 */
	public void setItemValueList(List itemValueList) {
		this.itemValueList = itemValueList;
	}

	/**
	 * @return the ecmUsersList
	 */
	public List<String> getEcmUsersList() {
		return ecmUsersList;
	}

	/**
	 * @param ecmUsersList the ecmUsersList to set
	 */
	public void setEcmUsersList(List<String> ecmUsersList) {
		this.ecmUsersList = ecmUsersList;
	}

	/**
	 * @return the ecmUsersoeIdList
	 */
	public List<String> getEcmUsersoeIdList() {
		return ecmUsersoeIdList;
	}

	/**
	 * @param ecmUsersoeIdList the ecmUsersoeIdList to set
	 */
	public void setEcmUsersoeIdList(List<String> ecmUsersoeIdList) {
		this.ecmUsersoeIdList = ecmUsersoeIdList;
	}

	/**
	 * @return the emailGenViewServicePersistable
	 */
	public EmailGenerationViewServicePersistable getEmailGenViewServicePersistable() {
		return ccrBeanFactory.getEmailGenViewServicePersistable();
	}


	
	public C3parUser getLoginAssignedUser(String ssoId) {
		return ccrBeanFactory.getEmailGenViewServicePersistable().getLoginAssignedUser(ssoId); 
	}	
	
	
	public List<ECMUserSearchProcess> selectEcmUsers(String searchUser,boolean isServiceDesk) {
		return ccrBeanFactory.getResolveITFieldPersistable().searchEcmUsers(searchUser,isServiceDesk);   
	}
	
	public List<EcmLeadQueue> getAgentListForSector(String soeId2) {
		return ccrBeanFactory.getResolveITFieldPersistable().getAgentListForSector(soeId2); 
	}
}
