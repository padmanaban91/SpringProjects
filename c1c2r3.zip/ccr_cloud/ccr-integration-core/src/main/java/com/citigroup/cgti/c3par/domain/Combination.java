package com.citigroup.cgti.c3par.domain;


/**
 * The Class Combination.
 */
public class Combination {

    /** The ip pair. */
    IpPair ipPair = new IpPair();

    /** The firewall name. */
    String firewallName;

    /** The firewall type. */
    String firewallType;

    /** The combination type. */
    String combinationType;

    /** The id. */
    private Long id;

    /**
     * Gets the id.
     *
     * @return the id
     */
    public Long getId() {
	return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
	this.id = id;
    }

    /**
     * Gets the firewall name.
     *
     * @return the firewall name
     */
    public String getFirewallName() {
	return firewallName;
    }

    /**
     * Sets the firewall name.
     *
     * @param firewallName the new firewall name
     */
    public void setFirewallName(String firewallName) {
	this.firewallName = firewallName;
    }

    /**
     * Gets the firewall type.
     *
     * @return the firewall type
     */
    public String getFirewallType() {
	return firewallType;
    }

    /**
     * Sets the firewall type.
     *
     * @param firewallType the new firewall type
     */
    public void setFirewallType(String firewallType) {
	this.firewallType = firewallType;
    }

    /**
     * Gets the ip pair.
     *
     * @return the ip pair
     */
    public IpPair getIpPair() {
	return ipPair;
    }

    /**
     * Sets the ip pair.
     *
     * @param ipPair the new ip pair
     */
    public void setIpPair(IpPair ipPair) {
	this.ipPair = ipPair;
    }

    /**
     * Gets the combination type.
     *
     * @return the combination type
     */
    public String getCombinationType() {
	return combinationType;
    }

    /**
     * Sets the combination type.
     *
     * @param combinationType the new combination type
     */
    public void setCombinationType(String combinationType) {
	this.combinationType = combinationType;
    }

}
