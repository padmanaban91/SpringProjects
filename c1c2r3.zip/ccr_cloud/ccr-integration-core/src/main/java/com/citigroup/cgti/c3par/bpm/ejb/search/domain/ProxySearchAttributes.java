package com.citigroup.cgti.c3par.bpm.ejb.search.domain;

import java.io.Serializable;


/**
 * The Class ProxySearchAttributes.
 */
public class ProxySearchAttributes extends BaseSearchAttributes implements Serializable{

    /**
     * Serial Version ID.
     */
    private static final long serialVersionUID = -7412840097064667713L;

    /** The prx change type. */
    private String prxChangeType=null;

    /** The region. */
    private String region=null;

    /** The instance name. */
    private String instanceName=null;

    /** The url. */
    private String url=null;

    /** The domain name. */
    private String domainName=null;

    /** The source ip address. */
    private String sourceIpAddress=null;

    /** The external ip address. */
    private String externalIpAddress=null;

    /** The source FQDN */
    private String sourceFQDN = null;
    
    /** The destination FQDN */
    private String destinationFQDN = null;
    
    /**
     * Gets the prx change type.
     * 
     * @return the prx change type
     */
    public String getPrxChangeType() {
	return prxChangeType;
    }

    public String getPrxChangeTypeForQuery() {
	return validString(prxChangeType);
    }

    /**
     * Sets the prx change type.
     *
     * @param prxChangeType the new prx change type
     */
    public void setPrxChangeType(String prxChangeType) {
	this.prxChangeType = prxChangeType;
    }

    /**
     * Gets the region.
     *
     * @return the region
     */
    public String getRegion() {
	return region;
    }

    public String getRegionForQuery() {
	return validString(region);
    }

    /**
     * Sets the region.
     *
     * @param region the new region
     */
    public void setRegion(String region) {
	this.region = region;
    }

    /**
     * Gets the instance name.
     *
     * @return the instance name
     */
    public String getInstanceName() {
	return instanceName;
    }

    public String getInstanceNameForQuery() {
	return validString(instanceName);
    }
    /**
     * Sets the instance name.
     *
     * @param instanceName the new instance name
     */
    public void setInstanceName(String instanceName) {
	this.instanceName = instanceName;
    }

    /**
     * Gets the url.
     *
     * @return the url
     */
    public String getUrl() {
	return url;
    }

    public String getUrlForQuery() {
	return validString(url);
    }

    /**
     * Sets the url.
     *
     * @param url the new url
     */
    public void setUrl(String url) {
	this.url = url;
    }

    /**
     * Gets the domain name.
     *
     * @return the domain name
     */
    public String getDomainName() {
	return domainName;
    }

    public String getDomainNameForQuery() {
	return validString(domainName);
    }

    /**
     * Sets the domain name.
     *
     * @param domainName the new domain name
     */
    public void setDomainName(String domainName) {
	this.domainName = domainName;
    }

    /**
     * Gets the source ip address.
     *
     * @return the source ip address
     */
    public String getSourceIpAddress() {
	return sourceIpAddress;
    }

    public String getSourceIpAddressForQuery() {
	return validString(sourceIpAddress);
    }

    /**
     * Sets the source ip address.
     *
     * @param sourceIpAddress the new source ip address
     */
    public void setSourceIpAddress(String sourceIpAddress) {
	this.sourceIpAddress = sourceIpAddress;
    }

    /**
     * Gets the external ip address.
     *
     * @return the external ip address
     */
    public String getExternalIpAddress() {
	return externalIpAddress;
    }

    public String getExternalIpAddressForQuery() {
	return validString(externalIpAddress);
    }

    /**
     * Sets the external ip address.
     *
     * @param externalIpAddress the new external ip address
     */
    public void setExternalIpAddress(String externalIpAddress) {
	this.externalIpAddress = externalIpAddress;
    }

    public String getSourceFQDN() {
        return sourceFQDN;
    }

    public void setSourceFQDN(String sourceFQDN) {
        this.sourceFQDN = sourceFQDN;
    }

    public String getDestinationFQDN() {
        return destinationFQDN;
    }

    public void setDestinationFQDN(String destinationFQDN) {
        this.destinationFQDN = destinationFQDN;
    }
}
