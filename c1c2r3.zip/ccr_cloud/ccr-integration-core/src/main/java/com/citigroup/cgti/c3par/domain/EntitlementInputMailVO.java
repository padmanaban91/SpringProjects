package com.citigroup.cgti.c3par.domain;


/**
 * The Class EntitlementInputMailVO.
 */
public class EntitlementInputMailVO extends BaseMailVO {
    // The below variable MAY or MAY NOT be present in the passed object (depends on the template requirement)

    /** The user. */
    private C3PARUser user;

    /**
     * Gets the user.
     *
     * @return the user
     */
    public C3PARUser getUser() {
	return user;
    }

    /**
     * Sets the user.
     *
     * @param user the new user
     */
    public void setUser(C3PARUser user) {
	this.user = user;
    }

}
