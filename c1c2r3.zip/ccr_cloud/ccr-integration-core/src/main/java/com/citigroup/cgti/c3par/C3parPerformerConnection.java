/*
 * Created on Mar 9, 2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.citigroup.cgti.c3par;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.jdbc.datasource.ConnectionHolder;
import org.springframework.jdbc.datasource.DataSourceUtils;

import com.citigroup.cgti.c3par.performer.util.PerformerConnection;
import com.citigroup.cgti.c3par.util.C3parProperties;


/**
 * The Class C3parPerformerConnection.
 *
 * @author gr61093
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 */
public class C3parPerformerConnection implements PerformerConnection {

    /** The holder. */
    private ConnectionHolder holder = null;

    /** The m_data source. */
    private DataSource m_dataSource = null;

    /** The log. */
    private final Logger log = Logger.getLogger(getClass().getName());

    /** The is hold reference. */
    private boolean isHoldReference;

    /**
     * Instantiates a new c3par performer connection.
     */
    public C3parPerformerConnection() {
    }

    /**
     * Instantiates a new c3par performer connection.
     *
     * @param isHoldReference the is hold reference
     */
    public C3parPerformerConnection(boolean isHoldReference) {
	this.isHoldReference = isHoldReference;
    }

    // ==================================================================================
    /**
     * Gets the connection.
     *
     * @return the connection
     */
    private Connection getConnection() {
	Connection connection = null;
	try {

	    if (null != m_dataSource) {
		connection = DataSourceUtils.getConnection(m_dataSource);
	    } else {
		InitialContext ctx = new InitialContext();
		DataSource source = (DataSource) ctx
		.lookup(C3parProperties.JDBC_DS);
		if (null != source) {
		    connection = source.getConnection();
		}
	    }
	    if (connection == null)
		throw new Exception("Failed to obtain a database connection");
	} catch (Exception e) {
	    log.error(e.getMessage(), e);
	    throw new RuntimeException(
		    "Failed to obtain a database connection", e);
	}
	return connection;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.performer.util.PerformerConnection#obtainConnection()
     */
    public Connection obtainConnection() {

	Connection connection = null;
	try {
	    if (isHoldReference) {
		if (holder == null) {
		    holder = new ConnectionHolder(getConnection());
		    log.debug("Creating new thread Local " + holder.toString());
		    connection = holder.getConnection();
		} else {
		    log.debug("Getting from thread Local " + holder.toString());
		    connection = holder.getConnection();
		    if(connection.isClosed()){
			holder = new ConnectionHolder(getConnection());
			log.debug("Coonection Closed getting new Connection for Connection holder " + holder.toString());
			connection = holder.getConnection();
		    }
		}
	    } else
		connection = getConnection();

	} catch (Exception e) {
	    log.error(e.getMessage(), e);
	    throw new RuntimeException(
		    "Failed to obtain a database connection", e);
	}

	return connection;
    }

    /**
     * Release connection.
     */
    public void releaseConnection() {
	try {
	    if (holder != null) {
		holder.getConnection().close();
	    }
	} catch (Exception xe) {

	}
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.performer.PerformerConnection#obtainConnection()
     */
    /*
     * public Connection obtainConnection() { Connection connection=null; //
     * if(connection==null){ try { Class.forName("oracle.jdbc.OracleDriver");
     * String url = "jdbc:oracle:thin:@namdsw1934:1521:CRDEVG"; connection =
     * DriverManager.getConnection(url,"gr61093","rythms123"); } catch
     * (Exception e) { log.error(e); } //} return connection; }
     */

    /**
     * Sets the data source.
     *
     * @param dataSource the new data source
     */
    public void setDataSource(DataSource dataSource) {
	m_dataSource = dataSource;
    }

}
