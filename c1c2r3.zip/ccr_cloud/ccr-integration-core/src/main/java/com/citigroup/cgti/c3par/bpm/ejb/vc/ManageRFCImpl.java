package com.citigroup.cgti.c3par.bpm.ejb.vc;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.nsroot.eur.servicesolutions.cate.integration.ArrayOfDataField;
import net.nsroot.eur.servicesolutions.cate.integration.ArrayOfDataFieldGroup;
import net.nsroot.eur.servicesolutions.cate.integration.ArrayOfString;
import net.nsroot.eur.servicesolutions.cate.integration.DataField;
import net.nsroot.eur.servicesolutions.cate.integration.DataFieldGroup;
import net.nsroot.eur.servicesolutions.cate.integration.DataForm;
import net.nsroot.eur.servicesolutions.cate.integration.FulfilmentItem;
import net.nsroot.eur.servicesolutions.cate.integration.FulfilmentSystem;
import net.nsroot.eur.servicesolutions.cate.integration.OrderSystem;
import net.nsroot.eur.servicesolutions.cate.integration.PurchaseOptionDescription;
import net.nsroot.eur.servicesolutions.cate.integration.PurchaseOptionDescriptionDocument;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.bpm.ejb.domain.ProcessRFCDTO;
import com.citigroup.cgti.c3par.bpm.ejb.domain.RFCRequestDTO;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.fw.domain.ServiceNowMessageLog;
import com.citigroup.cgti.c3par.fw.domain.ServiceNowMessageText;
import com.citigroup.cgti.c3par.fw.service.ServiceNowQueueSenderImpl;
import com.citigroup.cgti.c3par.snow.util.ServiceNowUserGroupUtil;
import com.citigroup.cgti.c3par.soa.vc.dao.RFCPersistable;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCDetail;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCDetailAnswer;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCRequest;
import com.citigroup.cgti.c3par.soa.vc.logic.RFCService;
import com.citigroup.cgti.c3par.soa.vc.util.RFCConstants;
import com.citigroup.cgti.c3par.soa.vc.util.RFCUtil;
/*import com.citigroup.cgti.cate.vc.VirtualChange_PortType_;
import com.tibco.www.schemas.CATEINT.Hub_VirtualChange.Schemas.vc.request.xsd.AddmodRecord;
import com.tibco.www.schemas.CATEINT.Hub_VirtualChange.Schemas.vc.request.xsd.GetRecord;
import com.tibco.www.schemas.CATEINT.Hub_VirtualChange.Schemas.vc.request.xsd.Param;*/
import com.citigroup.cgti.c3par.soa.vc.util.ServiceNowConstants;
import com.citigroup.cgti.c3par.util.StringUtil;


/**
 * The Class ManageRFCImpl.
 */
@SuppressWarnings( { "unchecked", "unused" })
public class ManageRFCImpl implements IManageRFC,ServiceNowConstants,RFCConstants {

	/** The rfc util. */
	RFCUtil rfcUtil = null;

	/** The rfc persistable. */
	RFCPersistable rfcPersistable = null;
	
	private ServiceNowUserGroupUtil snowUserGroupUtil;

	private RFCService rfc;
	
	/** The log. */
	protected Logger log = Logger.getLogger(this.getClass().getName());

	/**
	 * Gets the rfc util.
	 *
	 * @return the rfc util
	 */
	public RFCUtil getRfcUtil() {
		return rfcUtil;
	}

	/**
	 * Sets the rfc util.
	 *
	 * @param rfcUtil the new rfc util
	 */
	public void setRfcUtil(RFCUtil rfcUtil) {
		this.rfcUtil = rfcUtil;
	}

	/**
	 * Gets the rfc persistable.
	 *
	 * @return the rfc persistable
	 */
	public RFCPersistable getRfcPersistable() {
		return rfcPersistable;
	}

	/**
	 * Sets the rfc persistable.
	 *
	 * @param rfcPersistable the new rfc persistable
	 */
	public void setRfcPersistable(RFCPersistable rfcPersistable) {
		this.rfcPersistable = rfcPersistable;
	}
	
	public ServiceNowUserGroupUtil getSnowUserGroupUtil() {
		return snowUserGroupUtil;
	}

	public void setSnowUserGroupUtil(ServiceNowUserGroupUtil snowUserGroupUtil) {
		this.snowUserGroupUtil = snowUserGroupUtil;
	}

	public RFCService getRfc() {
		return rfc;
	}

	public void setRfc(RFCService rfc) {
		this.rfc = rfc;
	}

	/**
	 * Check rfc generation errors.
	 *
	 * @param rfcRequestDTO the rfc request dto
	 * @return the rFC request dto
	 */
	RFCRequestDTO checkRFCGenerationErrors(RFCRequestDTO rfcRequestDTO) {
		return rfcRequestDTO;
	}

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.vc.IManageRFC#postRFC(com.citigroup.cgti.c3par.bpm.ejb.domain.RFCRequestDTO)
	 */
	public RFCRequestDTO postRFC(RFCRequestDTO rfcReqDTO) {
		log.info("ManageRFCImpl  : postRFC :: Starts");
		String rfcFlag = null;
		try {
			rfcFlag = rfcUtil.getRFCPostFlag(rfcReqDTO.getId());
		} catch (Exception e1) {
			log.error(e1, e1);
		}
		/* commented Reason: HandleChangeException - Retry option to make work any number of times 
		 * without any backend update
		 * 
		if (rfcFlag != null && rfcFlag.trim().equalsIgnoreCase("Y"))
		{
			*/
			rfcUtil.updateRFCPostFlag(rfcReqDTO.getId(),"Y");// can be posted
			RFCRequest rfcRequest = new RFCRequest();
			Map secName = rfcUtil.getSectionName();
			List paramList = new ArrayList();
			List<RFCDetail> rfcDetailList = null;
			String errorMsg = "";
			Long rfcReqID = null;
			if (rfcReqDTO.getId() != null)
				rfcReqID = rfcReqDTO.getId();
			rfcReqDTO.setErrorCode(null);
			rfcReqDTO.setErrorMessage(null);
			String rfcPostFlag = null;
			if(rfcReqID!=null)
			{
				rfcPostFlag=rfcUtil.updateRFCPostFlag(rfcReqID,"Q");// post begin
			}
			log.info("rfcPostFlag::"+rfcPostFlag);
			if (rfcReqID != null && rfcReqID.longValue() != 0) {
				rfcRequest.setId(rfcReqID);
				rfcDetailList = new ArrayList();
				try {
					rfcDetailList.addAll(rfcPersistable.getRFCDetails(rfcRequest,SECTION_BASICINFO,RFC_REQ_TYPE_FIREWALL));
				} catch (Exception e) {
					errorMsg = errorMsg + rfcReqDTO.getErrorMessage();
				}
				try {
					rfcDetailList.addAll(rfcPersistable.getRFCDetails(rfcRequest,SECTION_NETWORKDATA,RFC_REQ_TYPE_FIREWALL));
				} catch (Exception e) {
					errorMsg = errorMsg + rfcReqDTO.getErrorMessage();
				}
				try {
					rfcDetailList.addAll(rfcPersistable.getRFCDetails(rfcRequest,SECTION_REASON,RFC_REQ_TYPE_FIREWALL));
				} catch (Exception e) {
					errorMsg = errorMsg + rfcReqDTO.getErrorMessage();
				}

				rfcDetailList = new ArrayList();
				try {
					rfcRequest.setDisplayType("post");
					rfcDetailList.addAll(rfcPersistable.getRFCDetails(rfcRequest,SECTION_DESCRIPTION,RFC_REQ_TYPE_FIREWALL));
				} catch (Exception e) {
					errorMsg = errorMsg + rfcReqDTO.getErrorMessage();
				}
				try {
					rfcDetailList.addAll(rfcPersistable.getRFCDetails(rfcRequest,SECTION_BACKOUTPLAN,RFC_REQ_TYPE_FIREWALL));
				} catch (Exception e) {
					errorMsg = errorMsg + rfcReqDTO.getErrorMessage();
				}
				try {
					rfcDetailList.addAll(rfcPersistable.getRFCDetails(rfcRequest,SECTION_TESTPLAN,RFC_REQ_TYPE_FIREWALL));
				} catch (Exception e) {
					errorMsg = errorMsg + rfcReqDTO.getErrorMessage();
				}
				try {
					rfcDetailList.addAll(rfcPersistable.getRFCDetails(rfcRequest,IMPLEMENTATIONPLAN,RFC_REQ_TYPE_FIREWALL));
				} catch (Exception e) {
					errorMsg = errorMsg + rfcReqDTO.getErrorMessage();
				}
				try {
					rfcDetailList.addAll(rfcPersistable.getRFCDetails(rfcRequest,SECTION_NETINFO,RFC_REQ_TYPE_FIREWALL));
				} catch (Exception e) {
					errorMsg = errorMsg + rfcReqDTO.getErrorMessage();

				}
				if (errorMsg != null && errorMsg != "") {
					rfcReqDTO.setErrorCode(RFCRequestDTO.ERRORCODE_POST_PREPARE);
					rfcReqDTO.setErrorMessage(errorMsg);
				}

			}

			if (rfcReqDTO.getErrorCode() == null) {
				rfcPostFlag=rfcUtil.updateRFCPostFlag(rfcReqID,"T");//post completed successfully
				createServiceNowRequest(rfcReqDTO, rfcRequest);
			}
			
			if(rfcReqDTO.getErrorCode() != null){
				int updInsert = 0;
				updInsert =rfcUtil.updateRFCError(rfcReqDTO);
				rfcUtil.updateRFCPostFlag(rfcReqID,"E");// Issue in posting
				if(updInsert > 0)
					log.info("Error codes and messages have been sucessfully logged");
			}
		log.info("ManageRFCImpl  : postRFC :: Ends");
		return rfcReqDTO;
	}

	/**
	 * Break long string.
	 *
	 * @param data the data
	 * @return the string
	 */
	private String breakLongString(String data) {
		String strdata = "";
		if (data != null && !data.trim().equals("") && data.length() > 72) {
			String strv[] = data.split("\n");

			for (String element : strv) {
				strdata = strdata + spliltNewLineValues(element) + "\n";
			}
		} else {
			return data;
		}
		return strdata;
	}

	/**
	 * Splilt new line values.
	 *
	 * @param data the data
	 * @return the string
	 */
	private String spliltNewLineValues(String data) {
		String finalResult = "";
		String temp1 = "";
		String temp2 = "";
		int brkData = 72;
		if (data != null) {
			if (!data.trim().equals("") && data.length() > brkData) {
				while (data.length() > brkData) {
					temp1 = data.substring(0, brkData - 1);
					if (temp1.indexOf(" ") != -1)
					{
						if (temp1.lastIndexOf(temp1.length() - 1) != ' ') {
							String temp4 = temp1.substring(0, temp1.lastIndexOf(" ")+1) + "\n";
							finalResult = finalResult + temp4;
							temp2 = temp1.substring(temp1.lastIndexOf(" ") + 1);
						}
					}
					data = temp2 + data.substring(brkData - 1);
					temp2 = "";
				}
				if (!data.trim().equals("") && data.length() > 0) {
					finalResult = finalResult + data;
				}
			} else {
				return data;
			}
		}
		return finalResult;
	}

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.vc.IManageRFC#checkRFCDataComplete(com.citigroup.cgti.c3par.bpm.ejb.domain.RFCRequestDTO)
	 */
	public RFCRequestDTO checkRFCDataComplete(RFCRequestDTO rfcReqDTO) {
		log.info("ManageRFCImpl::checkRFCDataComplete :: starts");
		List rfcDataError = new ArrayList();
		if (rfcReqDTO != null) {
			if ((rfcReqDTO.getErrorCode() == null)
					|| (rfcReqDTO.getErrorCode() != null && !rfcReqDTO
							.getErrorCode().equalsIgnoreCase(
									RFCRequestDTO.ERRORCODE_GENERATE))) {
				rfcReqDTO.setErrorCode(null);
				rfcReqDTO.setErrorMessage(null);
				Long rfcReqID = rfcReqDTO.getId();
				if (rfcReqID != null) {
				    
				}
				//call the error code
				if(rfcReqDTO.getErrorCode() != null){
					int updInsert = 0;
					updInsert =rfcUtil.updateRFCError(rfcReqDTO);
					if(updInsert > 0)
						log.info("Error codes and messages have been sucessfully logged");
				}
			}
		}
		log.info("ManageRFCImpl::checkRFCDataComplete :: Ends");
		return rfcReqDTO;

	}

	/**
	 * Replace param value.
	 *
	 * @param paramValue the param value
	 * @return the string
	 */
	private String replaceParamValue(String paramValue) {
		paramValue = paramValue.replaceAll("\\\\n", "\n");
		return paramValue;
	}

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.vc.IManageRFC#getRFCRequestList(com.citigroup.cgti.c3par.bpm.ejb.domain.ProcessRFCDTO)
	 */
	public ProcessRFCDTO getRFCRequestList(ProcessRFCDTO processRFCDTO) {
		log.info("ManageRFCImpl :: getRFCRequestList :Starts");
		List rfcRequestDTOList = new ArrayList();
		Object[] temp = null;
		boolean createTypeFlag=false;
		Long tiRequestId = processRFCDTO.getTiRequestId();
		if (tiRequestId != null) {
			Map rfcFlag = rfcUtil.getRFCFlag(tiRequestId);
			String bulkReq = (String) rfcFlag.get("BulkRequestFlag");
			String aclVariance = (String) rfcFlag.get("AclVarianceFlag");
			if ((bulkReq != null && !(bulkReq.trim().equals(""))
					&& bulkReq.equalsIgnoreCase("Y")) ||(aclVariance != null
							&& !(aclVariance.trim().equals("")) && aclVariance.trim().equalsIgnoreCase("Y")) ) {
				createTypeFlag=true;
			} else {
				Map rfcManualFlag = rfcUtil.getRFCReqManualFlag(tiRequestId);
				String createManualTypeFlag = "N";
				if (rfcManualFlag != null)
					createManualTypeFlag = (String) rfcManualFlag.get("MANUAL_TYPE");
				if (createManualTypeFlag != null
						&& createManualTypeFlag.equalsIgnoreCase("Y")) {
					createTypeFlag = true;
				}
			}
			List rfcRequestList = rfcPersistable.getRFCRequestList(tiRequestId,createTypeFlag,processRFCDTO.getConType());

			if (rfcRequestList != null && rfcRequestList.size() > 0) {
				for (int i = 0; i < rfcRequestList.size(); i++) {
					RFCRequestDTO rfcRequestDTO = new RFCRequestDTO();
					
					rfcRequestDTO.setTiRequestId(tiRequestId);
					rfcRequestDTO.setRfcType(processRFCDTO.getConType());
					
					temp = (Object[]) rfcRequestList.get(i);

					String createType = null;
					String conReqId = null;
					String versionNo = null;
					String errorCode = null;
					String errorMsg = null;
					String shortDescription = null;
					if (temp[4] != null) {
						createType = temp[4].toString();
						if (createType.equalsIgnoreCase(RFCRequestDTO.RFC_CREATE_TYPE_MANUAL)) {
							if (rfcFlag.get("CON_REQ_ID") != null)
								conReqId = (String) rfcFlag.get("CON_REQ_ID");
							if (rfcFlag.get("VERSION_NO") != null)
								versionNo = (String) rfcFlag.get("VERSION_NO");

							if (bulkReq != null && !(bulkReq.trim().equals(""))
									&& bulkReq.equalsIgnoreCase("Y")) {
								errorCode = RFCRequestDTO.ERRORCODE_POST_BULK;
								errorMsg = RFCRequestDTO.ERRORMSG_POST_BULK;
							} else if (aclVariance != null
									&& !(aclVariance.trim().equals("")) && aclVariance
									.trim().equalsIgnoreCase("Y")) {
								errorCode = RFCRequestDTO.ERRORCODE_POST_ACL;
								errorMsg = RFCRequestDTO.ERRORMSG_POST_ACL;
							}else {
								errorCode = RFCRequestDTO.ERRORCODE_POST_NOTAPPLICABLE;

							}
							if (conReqId != null && versionNo != null)
								shortDescription = conReqId + "." + versionNo;
							else
								shortDescription = "";
						} else {
							if (temp[5] != null)
								shortDescription = temp[5].toString();
							if (temp[3] != null) {
								errorCode = temp[3].toString();
								errorMsg = RFCRequestDTO.ERRORMSG_GENERATE;
							}

						}

					}
					if (temp[0] != null){
						rfcRequestDTO.setId(Long.valueOf(temp[0].toString()));
						if(errorCode!=null && !errorCode.trim().equalsIgnoreCase("")){
							Long tmpRfcId=Long.valueOf(temp[0].toString());
							String tmpLog=rfcUtil.getRFCERequestErrorLog(tmpRfcId);
							if(tmpLog!=null){
								errorMsg=tmpLog;
							}else{
								errorMsg=null;
							}
						}
					}
					if (temp[1] != null)
						rfcRequestDTO.setRfcStatus(temp[1].toString());
					else
						rfcRequestDTO.setRfcStatus("");
					if (shortDescription != null)
						rfcRequestDTO.setShortDescription(shortDescription);
					else
						rfcRequestDTO.setShortDescription("");
					if (temp[2] != null)
						rfcRequestDTO.setRfcId(temp[2].toString());
					if (errorCode != null) {
						rfcRequestDTO.setErrorCode(errorCode);
						rfcRequestDTO.setErrorMessage(errorMsg);
					}
					if (temp[4] != null)
						rfcRequestDTO.setCreateType(createType);

					rfcRequestDTOList.add(rfcRequestDTO);
				}

			} else {

				if (rfcFlag != null) {
					RFCRequestDTO rfcRequestDTO = new RFCRequestDTO();
					String conReqId = null;
					String versionNo = null;
					rfcRequestDTO.setTiRequestId(tiRequestId);
					if (rfcFlag.get("CON_REQ_ID") != null)
						conReqId = (String) rfcFlag.get("CON_REQ_ID");
					if (rfcFlag.get("VERSION_NO") != null)
						versionNo = (String) rfcFlag.get("VERSION_NO");

					if (bulkReq != null && !(bulkReq.trim().equals(""))
							&& bulkReq.equalsIgnoreCase("Y")) {
						rfcRequestDTO
						.setErrorCode(RFCRequestDTO.ERRORCODE_POST_BULK);
						rfcRequestDTO
						.setErrorMessage(RFCRequestDTO.ERRORMSG_POST_BULK);
					} else if (aclVariance != null
							&& !(aclVariance.trim().equals(""))
							&& aclVariance.trim().equalsIgnoreCase("Y")) {
						rfcRequestDTO
						.setErrorCode(RFCRequestDTO.ERRORCODE_POST_ACL);
						rfcRequestDTO
						.setErrorMessage(RFCRequestDTO.ERRORMSG_POST_ACL);
					} else {
						rfcRequestDTO
						.setErrorCode(RFCRequestDTO.ERRORCODE_POST_NOTAPPLICABLE);
						rfcRequestDTO
						.setErrorMessage("RFCRequest data is not  available for the connection Request id "
								+ conReqId
								+ " and the version no "
								+ versionNo);

					}
					String shortDesc = null;
					if (conReqId != null && versionNo != null)
						shortDesc = conReqId + "." + versionNo;
					else
						shortDesc = "";
					rfcRequestDTO.setShortDescription(shortDesc);
					rfcRequestDTOList.add(rfcRequestDTO);

				}
			}
			if (rfcRequestDTOList != null && rfcRequestDTOList.size() > 0)
				processRFCDTO.setRfcRequestDTOList(rfcRequestDTOList);

		}
		log.info("ManageRFCImpl :: getRFCRequestList :Ends");
		return processRFCDTO;

	}

	/**
	 * Rfc date update.
	 *
	 * @param rfcId the rfc id
	 * @return the string
	 */
	public String rfcDateUpdate(Long rfcId) {
		String dateCall = rfcUtil.updateRFCRequestDates(rfcId);
		return dateCall;
	}

	/**
	 * Rfc impl faf check.
	 *
	 * @param rfcId the rfc id
	 * @return the string
	 */
	public String rfcImplFAFCheck(Long rfcId){
		String fafStatus = "";
		try{
			rfcUtil.getFAFString(rfcId);
		}catch(Exception e){
			fafStatus = "failure";
		}
		return fafStatus;
	}

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.vc.IManageRFC#registerRFC(com.citigroup.cgti.c3par.bpm.ejb.domain.RFCRequestDTO)
	 */
	public RFCRequestDTO registerRFC(RFCRequestDTO rfcRequestDTO) {
		log.info("ManageRFCImpl::registerRFC :: starts");
		String status = null;
		try {

			log.info("registerRFC ::::: not calling getRFCRecord from VC ");
			rfcRequestDTO.setRfcStatus("DESIGN");
			status = rfcUtil.updateRFCRequestDetails("",
					rfcRequestDTO);
			log.info("registerRFC ::::: updated the table rfc_request  "+status);
			} catch (Exception ex) {
				 log.error(ex.getMessage(), ex);
				 rfcRequestDTO.setErrorCode(RFCRequestDTO.ERRORCODE_POST_WEBSERVICE);
				 rfcRequestDTO
				 .setErrorMessage("Exception occurred while handling VC Response");
			 }
			 if (rfcRequestDTO.getErrorCode() != null
					 && !(rfcRequestDTO.getErrorCode().trim().equalsIgnoreCase(""))) {
				 rfcUtil.updateRFCError(rfcRequestDTO);
			 }
			 log.info("ManageRFCImpl::registerRFC :: Ends");
			 return rfcRequestDTO;
	}

	/**
	 * Checks if is valid rfc.
	 *
	 * @param response the response
	 * @param rfcRequestDTO the rfc request dto
	 * @return true, if is valid rfc
	 * @throws Exception the exception
	 */
	private boolean isValidRFC(String response, RFCRequestDTO rfcRequestDTO)
	throws Exception {
		log.info("ManageRFCImpl::isValidRFC :: Starts");
		boolean isValidRFC = false;
		if (rfcRequestDTO != null) {
			Map processMap = rfcUtil.getRFCFlag(rfcRequestDTO.getTiRequestId());
			List xmlList = rfcUtil.xmlElements();
			if (xmlList != null) {
				Map rfcDetailMap = rfcUtil.updateRFCDetails(xmlList, response);
				if (rfcDetailMap.containsKey("BRIEF_DESCRIPTION") && processMap.containsKey("CON_REQ_ID") && processMap.containsKey("VERSION_NO")) {
					String briefDesc = null;
					String processId = null;
					if (processMap.get("CON_REQ_ID") != null && processMap.get("VERSION_NO") != null) {
						processId = processMap.get("CON_REQ_ID") + "."+ processMap.get("VERSION_NO");
					}
					if (rfcDetailMap.get("BRIEF_DESCRIPTION") != null) {
						briefDesc = rfcDetailMap.get("BRIEF_DESCRIPTION").toString();
					}
					if (briefDesc!=null && briefDesc.indexOf(processId) != -1) {
						isValidRFC = true;
					}else{
						isValidRFC=false;
					}

				}
			}
		}
		log.info("ManageRFCImpl::isValidRFC :: Ends");
		return isValidRFC;
	}

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.vc.IManageRFC#getPeopleRecord(java.lang.Long)
	 */
	public String getPeopleRecord(Long tiRequestId) {
		return "success";
	}

	public Map<String,String> getCabApproverCode(String groupid)throws Exception{
		log.info("Enter into ManageRFCImpl.getCabApproverCode:");
		String rfcErrorMessage = null;
		Map<String,String> groupDtlsMap = null ;
		Map<String,String> matchGroupDtlsMap = null;
		try {
			
			groupDtlsMap = snowUserGroupUtil.getUserGroup();
			matchGroupDtlsMap = new HashMap<String,String>();
			
			if (groupid != null && !groupid.trim().equalsIgnoreCase("*") && !groupDtlsMap.isEmpty()) {
				Set<String> keySet = groupDtlsMap.keySet();
				for (Iterator iterator = keySet.iterator(); iterator
						.hasNext();) {
					String key = (String) iterator.next();
					log.debug("key value" +key);
					if(key != null && !key.isEmpty()){
					if(key.contains(groupid.toUpperCase()) ){
						matchGroupDtlsMap.put(key,groupDtlsMap.get(key));
					}
					}
				}
			}else if(groupid.trim().equalsIgnoreCase("*")){
				matchGroupDtlsMap = groupDtlsMap;
			}
			if(matchGroupDtlsMap.isEmpty()){
				rfcErrorMessage = "Group Code is not existed.";
				matchGroupDtlsMap.put("ERRORMSG",rfcErrorMessage);
				log.info("ManageRFCImpl.getCabApproverCode:.rfcErrorMessage:: " + rfcErrorMessage);
			}

		} catch (Exception ex) {
			log.error("Exception Occurred while getting People Record "
					+ ex.getMessage());
			throw ex;
		}
	
		log.info("Exited from ManageRFCImpl.getCabApproverCode:");
		return matchGroupDtlsMap;
	}

	/* (non-Javadoc)
	 * @see com.citigroup.cgti.c3par.bpm.ejb.vc.IManageRFC#storeGenericRFC(java.lang.Long)
	 */
	public void storeGenericRFC(Long tiRequestId) {
		log.info("ManageRFCImpl::storeGenericRFC :: Starts");

		TIRequest tiRequest = new TIRequest();
		tiRequest.setId(tiRequestId);
		boolean  rfcRequestIdFlag = false;
		String createType = RFCRequestDTO.RFC_CREATE_TYPE_MANUAL;
		try {
			List rfcRequestList = getRFCRequest(tiRequest);
			if (rfcRequestList != null && rfcRequestList.size() > 0) {
				if (rfcRequestList.size() == 1) {
					RFCRequest rfcReq = (RFCRequest) rfcRequestList.get(0);
					String rfcType = rfcReq.getRfcRequestType();
					if (rfcType.equals(RFCRequestDTO.RFC_REQ_TYPE_GENERIC)) {
						rfcRequestIdFlag = storeManualRFC(tiRequest, RFC_REQ_TYPE_FIREWALL, createType);
					}
				} else if (rfcRequestList.size() > 1) {
					boolean rfcFirewallflag = false;
					String rfcType = null;
					for (int i = 0; i < rfcRequestList.size(); i++) {
						RFCRequest rfcReq = (RFCRequest) rfcRequestList.get(i);
						rfcReq.getRfcRequestType();
						if (rfcReq.getRfcRequestType() != null
								&& rfcReq.getRfcRequestType().equals(RFC_REQ_TYPE_FIREWALL)) {
							rfcFirewallflag = true;
						} else if (rfcReq.getRfcRequestType() != null
								&& rfcReq.getRfcRequestType().equals(RFCRequestDTO.RFC_REQ_TYPE_GENERIC)) {
							rfcType = rfcReq.getRfcRequestType();
						}
					}
					if (!rfcFirewallflag) {

						if (rfcType.equals(RFCRequestDTO.RFC_REQ_TYPE_GENERIC)) {
							rfcRequestIdFlag = storeManualRFC(tiRequest,RFC_REQ_TYPE_FIREWALL, createType);
						}
					}
				}
			} else {
				// store RFC request with generic
				rfcRequestIdFlag = storeManualRFC(tiRequest,
						RFCRequestDTO.RFC_REQ_TYPE_GENERIC, null);
				if (rfcRequestIdFlag) {
					boolean rfcReqId = storeManualRFC(tiRequest,
							RFC_REQ_TYPE_FIREWALL, createType);
				}
			}

		} catch (Exception ex) {
			log.error("Exception occurred while creating RFC request manually."
					+ ex.getMessage());
		}
		log.info("ManageRFCImpl::storeGenericRFC :: Ends ");
	}

	/**
	 * Store manual rfc.
	 *
	 * @param tiRequest the ti request
	 * @param rfcRequestType the rfc request type
	 * @param createType the create type
	 * @return true, if successful
	 */
	private boolean storeManualRFC(TIRequest tiRequest, String rfcRequestType,
			String createType) {
		log.info(" ManageRFCImpl : storeManualRFC()  :Starts ");
		boolean rfcRequestIdFlag=false;
		RFCRequest rfcRequest = new RFCRequest();
		rfcRequest.setTiRequest(tiRequest);
		rfcRequest.setRfcRequestType(rfcRequestType);
		if (createType != null) {
			rfcRequest.setCreate_type(createType);
			rfcRequest
			.setRfcErrorCode(RFCRequestDTO.ERRORCODE_POST_NOTAPPLICABLE);
		}
		rfcRequest.setCreated_date(new Date());
		RFCRequestDTO rfcRequestDTO=new RFCRequestDTO();
		rfcRequestDTO.setTiRequestId(tiRequest.getId());
		rfcRequestDTO.setErrorMessage("Unknown Exception Occurred");
		int count=rfcUtil.insertRFCError(rfcRequestDTO);
		if(count>0){
			rfcRequestIdFlag=true;
		}
		log.info(" ManageRFCImpl : storeManualRFC()  :Ends "+rfcRequestIdFlag);
		return rfcRequestIdFlag;

	}

	/**
	 * Gets the rFC request.
	 *
	 * @param tiRequest the ti request
	 * @return the rFC request
	 */
	public List getRFCRequest(TIRequest tiRequest) {
		return null;
	}
	private void  createServiceNowRequest(RFCRequestDTO rfcReqDTO, RFCRequest rfcRequest) {
		log.info("ManageRFCImpl :: createServiceNowRequest method starts");
		try{
			ServiceNowMessageLog snowMessageLog = new ServiceNowMessageLog();
			
			snowMessageLog.setId(rfcUtil.getSequenceNextVal(SEQ_SERVICENOW_MESSAGE_LOG));
			snowMessageLog.setTiRequestID(rfcReqDTO.getTiRequestId());
			snowMessageLog.setType(CHANGE_REQUEST_CODE);

			List<ServiceNowMessageText> snowMsgTextList = new ArrayList<ServiceNowMessageText>();
			ServiceNowMessageText snowMsgText = new ServiceNowMessageText();
			snowMsgText.setMessageType(MSG_TYPE_OUTBOUND);
			snowMsgTextList.add(snowMsgText);
			snowMessageLog.setServiceNowMessageText(snowMsgTextList);
			
			//snowMessageLog.save();
			//ServiceNowMessageLog newSNowMsgLog = snowMessageLog.findServiceNowMessageLogByID(snowMessageLog.getId());
			
			Long connectionID = rfcUtil.getConnectionRequestId(rfcReqDTO.getTiRequestId());
			ArrayList contactDetails = rfcUtil.getBusinessContactsDetails(connectionID,"'Requestor','DESIGN ENGINEER','Business_Tester'");
			ServiceNowQueueSenderImpl serviceNowQueueSenderImpl = new ServiceNowQueueSenderImpl();
			String serviceNowCreateRequest = null;

			log.info("ManageRFCImpl :: createServiceNowRequest :: getRfcType - "+rfcReqDTO.getRfcType());
			
			if(rfcReqDTO.getRfcType() != null && rfcReqDTO.getRfcType().equalsIgnoreCase("FW")){
				serviceNowCreateRequest = getServiceNowChangeRequestXml(rfcReqDTO, rfcRequest, snowMessageLog, contactDetails);			
			}else if(rfcReqDTO.getRfcType() != null && rfcReqDTO.getRfcType().equalsIgnoreCase("Proxy")){
				serviceNowCreateRequest = getServiceNowChgReqtXml4Proxy(rfcReqDTO, rfcRequest, snowMessageLog, contactDetails);
			}			
			if(rfcReqDTO.getErrorCode() == null && serviceNowCreateRequest != null){ //if the RequestXML preparation has error, dont post request to ServiceNow.
				rfcUtil.serviceNowMessageLogSave(snowMessageLog,serviceNowCreateRequest.getBytes());
				log.info("Sending Request to ServiceNow");
				serviceNowQueueSenderImpl.sendMesage(serviceNowCreateRequest);
				log.info("Updating RFCRequest ReqStatus as POSTED");
				rfcReqDTO.setRfcId("");
				rfcReqDTO.setRfcStatus("POSTED");
				rfcUtil.updateRFCRequestDetails("", rfcReqDTO);	
			}
		}catch(Exception ex){
			log.error(ex,ex);
			log.error("Error while Sending ServieNow ChangeRequest");
			rfcReqDTO.setErrorCode(RFCRequestDTO.ERRORCODE_POST_WEBSERVICE);
			rfcReqDTO.setErrorMessage(ex.getMessage());
		}
		log.info("ManageRFCImpl :: createServiceNowRequest method ends");
	}
	
	private String getServiceNowChangeRequestXml(RFCRequestDTO rfcReqDTO, RFCRequest rfcRequest, ServiceNowMessageLog SNMsgLog, ArrayList contactDetails) {
		log.info("ManageRFCImpl :: getServiceNowChangeRequestXml method starts");
		String temp = "";
		try{
			PurchaseOptionDescriptionDocument podDoc = PurchaseOptionDescriptionDocument.Factory.newInstance();			
			PurchaseOptionDescription pod = podDoc.addNewPurchaseOptionDescription();
            
			OrderSystem os = pod.addNewOrderSystem();
			os.setSystemID(SYSTEM_ID);
			StringBuffer mappingRef = new StringBuffer();
			mappingRef.append(rfcReqDTO.getId());
			mappingRef.append("-");			
			if(rfcRequest.getRfcLocationID() != null){
				mappingRef.append(rfcRequest.getRfcLocationID().getFwLocation());
			}else{
				mappingRef.append("");
			}
			mappingRef.append("-");
			mappingRef.append(rfcReqDTO.getTiRequestId());
			mappingRef.append("-");
			mappingRef.append(SNMsgLog.getId());
			os.setMappingReference(mappingRef.toString());
			
		    String installDate = rfcUtil.insertTimeDetails(rfcReqDTO.getTiRequestId(), rfcReqDTO.getId());			   
		    log.info("ManageRFCImpl :: installDate:-"+installDate);	
			
			FulfilmentSystem ffs = pod.addNewFulfilmentSystem();
			ffs.setSystemID(SERVICE_NOW);
			FulfilmentItem ffi = pod.addNewFulfilmentItem();
			ffi.setFulfilmentItemName(CR_CREATE);//ChangeRequestCreate,ChangeRequestUpdate
			DataForm df = ffi.addNewDataForm();
			df.setIsDetached(BOOLEAN_FALSE);
			ArrayOfDataFieldGroup dfgs= df.addNewDataFieldGroups();
			DataFieldGroup dfg = dfgs.addNewDataFieldGroup();
			dfg.setName(HEADER);
			
			String RequesterID = "", shortDescription = "", description = "", backoutPlan = "", testPlan = "", applicationInstance = "", expedited = ""
					, expedited_reason = "", utcStartDate = "", utcEndDate = "", countryCode = "", justification = ""
							,  backoutExecutionTime = "",postImplementationExecutionTime = "", backoutResponsibleGroup = "",postImplResponsibleGroup="", businessTester="";
			
			rfcRequest = rfc.getRFCDetails(rfcRequest,BASICINFO,RFC_REQ_TYPE_FIREWALL);			
			if(rfcRequest != null){	
				RequesterID = getRFCAnswer(rfcRequest.getSnowRequester(), true);
				shortDescription = getRFCAnswer(rfcRequest.getShortDescription(), false);	
				applicationInstance = getRFCAnswer(rfcRequest.getApplicationInstance(), true);				
				expedited = getRFCAnswer(rfcRequest.getExpideted(), true);
				expedited_reason = getRFCAnswer(rfcRequest.getExpidetedReason(), false);
				utcStartDate = getRFCAnswer(rfcRequest.getInstallStartDate(), true);
				utcEndDate = getRFCAnswer(rfcRequest.getInstallEndDate(), true);
				countryCode = getMultipleRFCDetailAnswerWithComma(rfcRequest.getCountryCode());
				justification = getRFCAnswer(rfcRequest.getJustification(), false);
				backoutExecutionTime = getRFCAnswer(rfcRequest.getBackoutExecutionTime(), true);
				postImplementationExecutionTime = getRFCAnswer(rfcRequest.getPostImplementationExecutionTime(), true);
				backoutResponsibleGroup = getRFCAnswer(rfcRequest.getBackoutResponsibleGroup(), true);
				postImplResponsibleGroup = getRFCAnswer(rfcRequest.getPostImplResponsibleGroup(), true);
				businessTester = getBusinessTester(contactDetails);

			}
			rfcRequest = rfc.getRFCDetails(rfcRequest,SECTION_DESCRIPTION,RFC_REQ_TYPE_FIREWALL);	
			if(rfcRequest != null){
				description = getRFCAnswer(rfcRequest.getDescription(), false);
			}
			rfcRequest = rfc.getRFCDetails(rfcRequest,SECTION_BACKOUTPLAN,RFC_REQ_TYPE_FIREWALL);	
			if(rfcRequest != null){
				backoutPlan = getRFCAnswer(rfcRequest.getBackoutPlan(), false);
			}
			rfcRequest = rfc.getRFCDetails(rfcRequest,SECTION_TESTPLAN,RFC_REQ_TYPE_FIREWALL);	
			if(rfcRequest != null){
				testPlan = getRFCAnswer(rfcRequest.getTestPlan(), false);
			}
			
			ArrayOfDataField dfs = dfg.addNewDataFields();

            DataField catdatafield = dfs.addNewDataField();
            catdatafield.setName(CATEGORY);
            ArrayOfString catdatastr = catdatafield.addNewValues();
            catdatastr.addValue("SECURITY/FIREWALL");
            
			DataField dfield2 = dfs.addNewDataField();
			dfield2.setName(TITLE);
			ArrayOfString str2 = dfield2.addNewValues();
			str2.addValue(shortDescription);

			DataField dfield3 = dfs.addNewDataField();
			dfield3.setName(PRIMARY_APP_INSTANCE);
			ArrayOfString str3 = dfield3.addNewValues();
			str3.addValue(applicationInstance);

			DataField dfield5 = dfs.addNewDataField();
			dfield5.setName(REQUESTOR);
			ArrayOfString str5 = dfield5.addNewValues();
			str5.addValue(RequesterID);

			DataField dfield7 = dfs.addNewDataField();
			dfield7.setName(JUSTIFICATION);
			ArrayOfString str7 = dfield7.addNewValues();
			str7.addValue(justification);
			
			DataField dfield6 = dfs.addNewDataField();
			dfield6.setName(DESCRIPTION);
			ArrayOfString str6 = dfield6.addNewValues();
			str6.addValue(description);

			DataFieldGroup dfg2 = dfgs.addNewDataFieldGroup();
			dfg2.setName(ADD_REQ_DETAILS);
			ArrayOfDataField dfs2 = dfg2.addNewDataFields();

			DataField dfield11 = dfs2.addNewDataField();
			dfield11.setName(CHANGE_CATALOG);
			ArrayOfString str11 = dfield11.addNewValues();
			String change_catalog = rfcUtil.getGenericLookUpValue(CHANGE_REQUEST_ID);
			str11.addValue(change_catalog); //UAT:- CTMP0000002707,CTMP0000003935 , DEV:- CTMP0000002701 
			
			DataField dfield14 = dfs2.addNewDataField();
			dfield14.setName(UTC_START_DATE);
			ArrayOfString str14 = dfield14.addNewValues();	
			str14.addValue(utcStartDate);
			
			DataField dfield15 = dfs2.addNewDataField();	
			dfield15.setName(UTC_END_DATE);
			ArrayOfString str15 = dfield15.addNewValues();	
			str15.addValue(utcEndDate);
			
			DataField dfield17 = dfs2.addNewDataField();
			dfield17.setName(IMPACTED_COUNTRIES);
			ArrayOfString str17 = dfield17.addNewValues();
			str17.addValue(countryCode);
			
			
			DataField dfield120 = dfs2.addNewDataField();
			dfield120.setName(BACKOUTPLAN);
			ArrayOfString str120 = dfield120.addNewValues();
			str120.addValue(backoutPlan);
			
			DataField dfield122 = dfs2.addNewDataField();
			dfield122.setName(EXPEDITED);
			ArrayOfString str122 = dfield122.addNewValues();
			// The Expedited value was forced to false due to requirement
			// https://otshare.nam.citi.net/sites/ECP/CCRDevelopment/Lists/PROD%20CHANGE%20REPORTING/Item/displayifs.aspx?ID=43
			str122.addValue("false");
			
			DataField dfield1123 = dfs2.addNewDataField();
			dfield1123.setName(EXPEDITED_REASON);
			ArrayOfString str1123 = dfield1123.addNewValues();
			// The Expedited value was forced to Not Applicable due to requirement
			// https://otshare.nam.citi.net/sites/ECP/CCRDevelopment/Lists/PROD%20CHANGE%20REPORTING/Item/displayifs.aspx?ID=43
			str1123.addValue("Not Applicable");
			
			DataFieldGroup dfg3 = dfgs.addNewDataFieldGroup();
			dfg3.setName(TEST_DETAILS);
			ArrayOfDataField dfs3 = dfg3.addNewDataFields();
			
			DataField dfield21 = dfs3.addNewDataField();
			dfield21.setName(POST_IMP_TEST_PLAN);
			ArrayOfString str21 = dfield21.addNewValues();
			str21.addValue(testPlan);
			
			DataField dfield18 = dfs3.addNewDataField();
			dfield18.setName(BACKOUT_EXECUTION_TIME);
			ArrayOfString str18 = dfield18.addNewValues();
			str18.addValue(backoutExecutionTime);
			
			DataField dfield19 = dfs3.addNewDataField();
			dfield19.setName(POST_IMPLEMENTATION_EXECUTION_TIME);
			ArrayOfString str19 = dfield19.addNewValues();
			str19.addValue(postImplementationExecutionTime);
			
			DataField dfield191 = dfs3.addNewDataField();
			dfield191.setName(BACKOUT_RESPONSIBLE_GROUP);
			ArrayOfString str191 = dfield191.addNewValues();
			str191.addValue(backoutResponsibleGroup);

			DataField dfield192 = dfs3.addNewDataField();
			dfield192.setName(POST_IMPL_RESPONSIBLE_GROUP);
			ArrayOfString str192 = dfield192.addNewValues();
			str192.addValue(postImplResponsibleGroup);
			
			if(!StringUtil.isNullorEmpty(businessTester)){
			    DataField dfield193 = dfs3.addNewDataField();
			    dfield193.setName(POST_IMPL_RESPONSIBLE_USER);
			    ArrayOfString str193 = dfield193.addNewValues();
			    str193.addValue(businessTester);
			}
			
			DataFieldGroup dfg4 = dfgs.addNewDataFieldGroup();
			dfg4.setName(AUDIT);
			ArrayOfDataField dfs4 = dfg4.addNewDataFields();
			
			int counter = 0;
			
			DataFieldGroup dfgArr[] = null;
			ArrayOfDataField arrDF[] = null;
			ArrayOfString arrStr[] = null;
			ArrayOfString arrStr2[] = null;
			
			DataField dataFld[] = null;
			DataField dataFld2[] = null;
			
			//Add Additional application details in ApplicationInstance
			if(rfcRequest.getSnowApplicationInstance() != null){
				log.info("ManageRFCImpl :: rfcRequest.getSnowApplicationInstance().."+rfcRequest.getSnowApplicationInstance());
				RFCDetail rfcDetail = rfcRequest.getSnowApplicationInstance();
				List<RFCDetailAnswer> rfcDtlAnswers = rfcDetail.getRfcDetailAnswerList();
				dfgArr = new DataFieldGroup[rfcDtlAnswers.size()];
				arrDF = new ArrayOfDataField[rfcDtlAnswers.size()];
				arrStr = new ArrayOfString[rfcDtlAnswers.size()];
				arrStr2 = new ArrayOfString[rfcDtlAnswers.size()];
				dataFld = new DataField[rfcDtlAnswers.size()];
				dataFld2 = new DataField[rfcDtlAnswers.size()];
				if(rfcDtlAnswers != null && rfcDtlAnswers.size() > 0){
					for(RFCDetailAnswer rfcAns:rfcDtlAnswers){
						snowAddAppInstance(dfgs, rfcAns, BOOLEAN_TRUE_STR,dfgArr[counter],arrDF[counter],arrStr[counter],arrStr2[counter],dataFld[counter],dataFld2[counter],APP_INSTANCE,NAME,IMPACTED);
						counter=counter+1;
					}
				}				
			}
			
			counter = 0;
			DataFieldGroup dfgArry[] = null;
			ArrayOfDataField arrDFy[] = null;
			ArrayOfString arrStry[] = null;
			ArrayOfString arrStr2y[] = null;
			DataField dataFldy[] = null;
			DataField dataFld2y[] = null;
			if(rfcRequest.getCSIApplicationInstance() != null){
				RFCDetail rfcDetail = rfcRequest.getCSIApplicationInstance();
				List<RFCDetailAnswer> rfcDtlAnswers = rfcDetail.getRfcDetailAnswerList();
				dfgArry = new DataFieldGroup[rfcDtlAnswers.size()];
				arrDFy = new ArrayOfDataField[rfcDtlAnswers.size()];
				arrStry = new ArrayOfString[rfcDtlAnswers.size()];
				arrStr2y = new ArrayOfString[rfcDtlAnswers.size()];
				dataFldy = new DataField[rfcDtlAnswers.size()];
				dataFld2y = new DataField[rfcDtlAnswers.size()];
				if(rfcDtlAnswers != null && rfcDtlAnswers.size() > 0){
					for(RFCDetailAnswer rfcAns:rfcDtlAnswers){
						snowAddAppInstance(dfgs, rfcAns, BOOLEAN_FALSE_STR,dfgArry[counter],arrDFy[counter],arrStry[counter],arrStr2y[counter],dataFldy[counter],dataFld2y[counter],APP_INSTANCE,NAME,IMPACTED);
						counter=counter+1;
					}
				}				
			}			

			counter = 0;
			DataFieldGroup dfgArra[] = null;
			ArrayOfDataField arrDFa[] = null;
			ArrayOfString arrStra[] = null;
			ArrayOfString arrStr2a[] = null;
			DataField dataFlda[] = null;
			DataField dataFld2a[] = null;
			if(rfcRequest.getSnowDeviceId() != null){
				RFCDetail rfcDetail = rfcRequest.getSnowDeviceId();
				List<RFCDetailAnswer> rfcDtlAnswers = rfcDetail.getRfcDetailAnswerList();
				dfgArra = new DataFieldGroup[rfcDtlAnswers.size()];
				arrDFa = new ArrayOfDataField[rfcDtlAnswers.size()];
				arrStra = new ArrayOfString[rfcDtlAnswers.size()];
				arrStr2a = new ArrayOfString[rfcDtlAnswers.size()];
				dataFlda = new DataField[rfcDtlAnswers.size()];
				dataFld2a = new DataField[rfcDtlAnswers.size()];
				if(rfcDtlAnswers != null && rfcDtlAnswers.size() > 0){
					for(RFCDetailAnswer rfcAns:rfcDtlAnswers){
						snowAddDeviceIds(dfgs, rfcAns, "NetInfo",dfgArra[counter],arrDFa[counter],arrStra[counter],arrStr2a[counter],dataFlda[counter],
								dataFld2a[counter],CONFIGITEM,SOURCE,ID);
						counter=counter+1;
					}
				}				
			}
			
			
			counter = 0;
			DataFieldGroup dfgArrz[] = null;
			ArrayOfDataField arrDFz[] = null;
			ArrayOfString arrStrz[] = null;
			ArrayOfString arrStr2z[] = null;
			DataField dataFldz[] = null;
			DataField dataFld2z[] = null;
			if(rfcRequest.getMultiCABAppCode() != null){
				RFCDetail rfcDetail = rfcRequest.getMultiCABAppCode();
				List<RFCDetailAnswer> rfcDtlAnswers = rfcDetail.getRfcDetailAnswerList();
				dfgArrz = new DataFieldGroup[rfcDtlAnswers.size()];
				arrDFz = new ArrayOfDataField[rfcDtlAnswers.size()];
				arrStrz = new ArrayOfString[rfcDtlAnswers.size()];
				arrStr2z = new ArrayOfString[rfcDtlAnswers.size()];
				dataFldz = new DataField[rfcDtlAnswers.size()];
				dataFld2z = new DataField[rfcDtlAnswers.size()];
				if(rfcDtlAnswers != null && rfcDtlAnswers.size() >= 1){
					for(RFCDetailAnswer rfcAns:rfcDtlAnswers){	
						snowAddAppInstance(dfgs, rfcAns, "Not Applicable",dfgArrz[counter],arrDFz[counter],arrStrz[counter],arrStr2z[counter],dataFldz[counter],dataFld2z[counter],
								GROUPAPPROVAL,ASSIGNMENT_GROUP,COMMENTS);
						counter=counter+1;
					}
				}				
			}			
			
			temp = podDoc.toString();
		}catch(Exception ex){
			log.error(ex,ex);
			log.error("ManageRFCImpl :: Error while Preparing RequestXML for ServieNow ChangeRequest");
			rfcReqDTO.setErrorCode(RFCRequestDTO.ERRORCODE_POST_WEBSERVICE);
			rfcReqDTO.setErrorMessage(ex.getMessage());
		}
		log.info("ManageRFCImpl :: getServiceNowChangeRequestXml method ends");
		return temp;		
	}
	
	
	private String getBusinessTester(List<HashMap<String, String>> contactDetails){
	    StringBuilder businessTester = new StringBuilder();
	    try{
            if(CollectionUtils.isNotEmpty(contactDetails)){
                for (int i=0; i < contactDetails.size(); i++){
                    HashMap<String, String> contact =(HashMap<String, String>)contactDetails.get(i);
                    if(contact != null){
                        if (BUSINESS_TESTER.equalsIgnoreCase((String)contact.get(ROLE_NAME))){
                            businessTester.append(contact.get(CONTACT_SSOID)).append(", ");
                        }else{
                            continue;
                        }
                    }
                }
            }
	    }catch(Exception e){
	        log.error(e.toString(), e);
	    }
	    log.info("Exiting : businessTester : "+businessTester.toString());
        return businessTester.toString();
	}
	
	private String getServiceNowChgReqtXml4Proxy(RFCRequestDTO rfcReqDTO, RFCRequest rfcRequest, ServiceNowMessageLog SNMsgLog, ArrayList contactDetails) {
		log.info("ManageRFCImpl :: getServiceNowChgReqtXml4Proxy method starts");
		String temp = "";
		try{
			PurchaseOptionDescriptionDocument podDoc = PurchaseOptionDescriptionDocument.Factory.newInstance();			
			PurchaseOptionDescription pod = podDoc.addNewPurchaseOptionDescription();
            
			OrderSystem os = pod.addNewOrderSystem();
			os.setSystemID(SYSTEM_ID);
			StringBuffer mappingRef = new StringBuffer();
			mappingRef.append(rfcReqDTO.getId());
			mappingRef.append("-");			
			if(rfcRequest.getRfcLocationID() != null){
				mappingRef.append(rfcRequest.getRfcLocationID().getFwLocation());
			}else{
				mappingRef.append("");
			}
			mappingRef.append("-");
			mappingRef.append(rfcReqDTO.getTiRequestId());
			mappingRef.append("-");
			mappingRef.append(SNMsgLog.getId());
			os.setMappingReference(mappingRef.toString());
			
		    String installDate = rfcUtil.insertTimeDetailsForProxy(rfcReqDTO.getTiRequestId(), rfcReqDTO.getId());			   
		    log.info("ManageRFCImpl :: getServiceNowChgReqtXml4Proxy:: installDate:-"+installDate);	
			
			FulfilmentSystem ffs = pod.addNewFulfilmentSystem();
			ffs.setSystemID(SERVICE_NOW);
			FulfilmentItem ffi = pod.addNewFulfilmentItem();
			ffi.setFulfilmentItemName(CR_CREATE);//ChangeRequestCreate,ChangeRequestUpdate
			DataForm df = ffi.addNewDataForm();

			df.setIsDetached(BOOLEAN_FALSE);
			ArrayOfDataFieldGroup dfgs= df.addNewDataFieldGroups();
			DataFieldGroup dfg = dfgs.addNewDataFieldGroup();
			dfg.setName(HEADER);
			
			String RequesterID = "", shortDescription = "", description = "", backoutPlan = "", testPlan = "", applicationInstance = "", expedited = ""
					, expedited_reason = "", utcStartDate = "", utcEndDate = "", countryCode = "", justification = "", pretestexcempt = "",pretestexcempt_testplan = ""
					,  backoutExecutionTime = "",postImplementationExecutionTime = "", backoutResponsibleGroup = "",postImplResponsibleGroup="", businessTester = "";
		
			rfcRequest = rfc.getRFCDetails(rfcRequest,BASICINFO,RFC_REQ_TYPE_PROXY);			
			if(rfcRequest != null){	
				RequesterID = getRFCAnswer(rfcRequest.getSnowRequester(), true);
				shortDescription = getRFCAnswer(rfcRequest.getShortDescription(), false);	
				applicationInstance = getRFCAnswer(rfcRequest.getApplicationInstance(), true);				
				expedited = getRFCAnswer(rfcRequest.getExpideted(), true);
				expedited_reason = getRFCAnswer(rfcRequest.getExpidetedReason(), false);
				utcStartDate = getRFCAnswer(rfcRequest.getInstallStartDate(), true);
				utcEndDate = getRFCAnswer(rfcRequest.getInstallEndDate(), true);
				countryCode = getMultipleRFCDetailAnswerWithComma(rfcRequest.getCountryCode());
				justification = getRFCAnswer(rfcRequest.getJustification(), false);
				backoutExecutionTime = getRFCAnswer(rfcRequest.getBackoutExecutionTime(), true);
				postImplementationExecutionTime = getRFCAnswer(rfcRequest.getPostImplementationExecutionTime(), true);
				backoutResponsibleGroup = getRFCAnswer(rfcRequest.getBackoutResponsibleGroup(), true);
				postImplResponsibleGroup = getRFCAnswer(rfcRequest.getPostImplResponsibleGroup(), true);
				businessTester = getBusinessTester(contactDetails);
			}
			rfcRequest = rfc.getRFCDetails(rfcRequest,SECTION_DESCRIPTION_PROXY,RFC_REQ_TYPE_PROXY);	
			if(rfcRequest != null){
				description = getRFCAnswer(rfcRequest.getDescription(), false);
			}
			rfcRequest = rfc.getRFCDetails(rfcRequest,SECTION_BACKOUTPLAN_PROXY,RFC_REQ_TYPE_PROXY);	
			if(rfcRequest != null){
				backoutPlan = getRFCAnswer(rfcRequest.getBackoutPlan(), false);
			}
			rfcRequest = rfc.getRFCDetails(rfcRequest,SECTION_TESTPLAN_PROXY,RFC_REQ_TYPE_PROXY);	
			if(rfcRequest != null){
				testPlan = getRFCAnswer(rfcRequest.getTestPlan(), false);
			}
			
			ArrayOfDataField dfs = dfg.addNewDataFields();

            DataField catdatafield = dfs.addNewDataField();
            catdatafield.setName(CATEGORY);
            ArrayOfString catdatastr = catdatafield.addNewValues();
            catdatastr.addValue("SECURITY/PROXY");
            
			DataField dfield2 = dfs.addNewDataField();
			dfield2.setName(TITLE);
			ArrayOfString str2 = dfield2.addNewValues();
			str2.addValue(shortDescription);

			DataField dfield3 = dfs.addNewDataField();
			dfield3.setName(PRIMARY_APP_INSTANCE);
			ArrayOfString str3 = dfield3.addNewValues();
			str3.addValue(applicationInstance);

			DataField dfield5 = dfs.addNewDataField();
			dfield5.setName(REQUESTOR);
			ArrayOfString str5 = dfield5.addNewValues();
			str5.addValue(RequesterID);

			DataField dfield7 = dfs.addNewDataField();
			dfield7.setName(JUSTIFICATION);
			ArrayOfString str7 = dfield7.addNewValues();
			str7.addValue(justification);
			
			DataField dfield6 = dfs.addNewDataField();
			dfield6.setName(DESCRIPTION);
			ArrayOfString str6 = dfield6.addNewValues();
			str6.addValue(description);

			DataFieldGroup dfg2 = dfgs.addNewDataFieldGroup();
			dfg2.setName(ADD_REQ_DETAILS);
			ArrayOfDataField dfs2 = dfg2.addNewDataFields();

			DataField dfield11 = dfs2.addNewDataField();
			dfield11.setName(CHANGE_CATALOG);
			ArrayOfString str11 = dfield11.addNewValues();
			String change_catalog = rfcUtil.getGenericLookUpValue(CHANGE_REQUEST_ID);
			str11.addValue(change_catalog); //UAT:- CTMP0000002707,CTMP0000003935 , DEV:- CTMP0000002701 
			
			DataField dfield14 = dfs2.addNewDataField();
			dfield14.setName(UTC_START_DATE);
			ArrayOfString str14 = dfield14.addNewValues();	
			str14.addValue(utcStartDate);
			
			DataField dfield15 = dfs2.addNewDataField();	
			dfield15.setName(UTC_END_DATE);
			ArrayOfString str15 = dfield15.addNewValues();	
			str15.addValue(utcEndDate);
			
			DataField dfield17 = dfs2.addNewDataField();
			dfield17.setName(IMPACTED_COUNTRIES);
			ArrayOfString str17 = dfield17.addNewValues();
			str17.addValue(countryCode);
			
			DataField dfield120 = dfs2.addNewDataField();
			dfield120.setName(BACKOUTPLAN);
			ArrayOfString str120 = dfield120.addNewValues();
			str120.addValue(backoutPlan);
			
			DataField dfield122 = dfs2.addNewDataField();
			dfield122.setName(EXPEDITED);
			ArrayOfString str122 = dfield122.addNewValues();
			// The Expedited value was forced to false due to requirement
			// https://otshare.nam.citi.net/sites/ECP/CCRDevelopment/Lists/PROD%20CHANGE%20REPORTING/Item/displayifs.aspx?ID=43
			str122.addValue("false");
			//str122.addValue(expedited);
			
			DataField dfield1123 = dfs2.addNewDataField();
			dfield1123.setName(EXPEDITED_REASON);
			ArrayOfString str1123 = dfield1123.addNewValues();
			// The Expedited value was forced to Not Applicable due to requirement
			// https://otshare.nam.citi.net/sites/ECP/CCRDevelopment/Lists/PROD%20CHANGE%20REPORTING/Item/displayifs.aspx?ID=43
			str1123.addValue("Not Applicable");
			//str1123.addValue(expedited_reason);
			
			DataFieldGroup dfg3 = dfgs.addNewDataFieldGroup();
			dfg3.setName(TEST_DETAILS);
			ArrayOfDataField dfs3 = dfg3.addNewDataFields();
			
			DataField dfield18 = dfs3.addNewDataField();
			dfield18.setName(BACKOUT_EXECUTION_TIME);
			ArrayOfString str18 = dfield18.addNewValues();
			str18.addValue(backoutExecutionTime);
			
			DataField dfield19 = dfs3.addNewDataField();
			dfield19.setName(POST_IMPLEMENTATION_EXECUTION_TIME);
			ArrayOfString str19 = dfield19.addNewValues();
			str19.addValue(postImplementationExecutionTime);
			
			DataField dfield191 = dfs3.addNewDataField();
			dfield191.setName(BACKOUT_RESPONSIBLE_GROUP);
			ArrayOfString str191 = dfield191.addNewValues();
			str191.addValue(backoutResponsibleGroup);
			
			DataField dfield192 = dfs3.addNewDataField();
			dfield192.setName(POST_IMPL_RESPONSIBLE_GROUP);
			ArrayOfString str192 = dfield192.addNewValues();
			str192.addValue(postImplResponsibleGroup);
			
			if(!StringUtil.isNullorEmpty(businessTester)){
			    DataField dfield193 = dfs3.addNewDataField();
			    dfield193.setName(POST_IMPL_RESPONSIBLE_USER);
			    ArrayOfString str193 = dfield193.addNewValues();
			    str193.addValue(businessTester);
			}
			
			DataField dfield21 = dfs3.addNewDataField();
			dfield21.setName(POST_IMP_TEST_PLAN);
			ArrayOfString str21 = dfield21.addNewValues();
			str21.addValue(testPlan);
			
			DataFieldGroup dfg4 = dfgs.addNewDataFieldGroup();
			dfg4.setName(AUDIT);
			ArrayOfDataField dfs4 = dfg4.addNewDataFields();
			
			int counter = 0;
			
			DataFieldGroup dfgArr[] = null;
			
			ArrayOfDataField arrDF[] = null;
			
			ArrayOfString arrStr[] = null;
			ArrayOfString arrStr2[] = null;
			
			DataField dataFld[] = null;
			DataField dataFld2[] = null;
			
			//Add Additional application details in ApplicationInstance
			if(rfcRequest.getSnowApplicationInstance() != null){
				log.info("ManageRFCImpl :: getServiceNowChgReqtXml4Proxy:: rfcRequest.getSnowApplicationInstance().."+rfcRequest.getSnowApplicationInstance());
				RFCDetail rfcDetail = rfcRequest.getSnowApplicationInstance();
				List<RFCDetailAnswer> rfcDtlAnswers = rfcDetail.getRfcDetailAnswerList();
				dfgArr = new DataFieldGroup[rfcDtlAnswers.size()];
				arrDF = new ArrayOfDataField[rfcDtlAnswers.size()];
				arrStr = new ArrayOfString[rfcDtlAnswers.size()];
				arrStr2 = new ArrayOfString[rfcDtlAnswers.size()];
				dataFld = new DataField[rfcDtlAnswers.size()];
				dataFld2 = new DataField[rfcDtlAnswers.size()];
				if(rfcDtlAnswers != null && rfcDtlAnswers.size() > 0){
					
					for(RFCDetailAnswer rfcAns:rfcDtlAnswers){
						snowAddAppInstance(dfgs, rfcAns, BOOLEAN_TRUE_STR,dfgArr[counter],arrDF[counter],arrStr[counter],arrStr2[counter],dataFld[counter],dataFld2[counter],APP_INSTANCE,NAME,IMPACTED);
						counter=counter+1;
					}
				}				
			}
			counter = 0;
			DataFieldGroup dfgArry[] = null;
			
			ArrayOfDataField arrDFy[] = null;
			
			ArrayOfString arrStry[] = null;
			ArrayOfString arrStr2y[] = null;
			
			DataField dataFldy[] = null;
			DataField dataFld2y[] = null;

			if(rfcRequest.getCSIApplicationInstance() != null){
				RFCDetail rfcDetail = rfcRequest.getCSIApplicationInstance();
				List<RFCDetailAnswer> rfcDtlAnswers = rfcDetail.getRfcDetailAnswerList();
				log.debug("ManageRFCImpl :: getServiceNowChgReqtXml4Proxy :: rfcDtlAnswers.size.."+rfcDtlAnswers.size());
				dfgArry = new DataFieldGroup[rfcDtlAnswers.size()];
				arrDFy = new ArrayOfDataField[rfcDtlAnswers.size()];
				arrStry = new ArrayOfString[rfcDtlAnswers.size()];
				arrStr2y = new ArrayOfString[rfcDtlAnswers.size()];
				dataFldy = new DataField[rfcDtlAnswers.size()];
				dataFld2y = new DataField[rfcDtlAnswers.size()];
				if(rfcDtlAnswers != null && rfcDtlAnswers.size() > 0){
					for(RFCDetailAnswer rfcAns:rfcDtlAnswers){
						snowAddAppInstance(dfgs, rfcAns, BOOLEAN_FALSE_STR,dfgArry[counter],arrDFy[counter],arrStry[counter],arrStr2y[counter],dataFldy[counter],dataFld2y[counter],APP_INSTANCE,NAME,IMPACTED);
						counter=counter+1;
					}
				}				
			}
			counter = 0;
			DataFieldGroup dfgArra[] = null;
			
			ArrayOfDataField arrDFa[] = null;
			
			ArrayOfString arrStra[] = null;
			ArrayOfString arrStr2a[] = null;
			
			DataField dataFlda[] = null;
			DataField dataFld2a[] = null;

			if(rfcRequest.getSnowDeviceId() != null){
				RFCDetail rfcDetail = rfcRequest.getSnowDeviceId();
				List<RFCDetailAnswer> rfcDtlAnswers = rfcDetail.getRfcDetailAnswerList();
				dfgArra = new DataFieldGroup[rfcDtlAnswers.size()];
				arrDFa = new ArrayOfDataField[rfcDtlAnswers.size()];
				arrStra = new ArrayOfString[rfcDtlAnswers.size()];
				arrStr2a = new ArrayOfString[rfcDtlAnswers.size()];
				dataFlda = new DataField[rfcDtlAnswers.size()];
				dataFld2a = new DataField[rfcDtlAnswers.size()];
				if(rfcDtlAnswers != null && rfcDtlAnswers.size() > 0){
					for(RFCDetailAnswer rfcAns:rfcDtlAnswers){
						snowAddDeviceIds(dfgs, rfcAns, "NetInfo_Name",dfgArra[counter],arrDFa[counter],arrStra[counter],arrStr2a[counter],dataFlda[counter],
								dataFld2a[counter],CONFIGITEM,SOURCE,ID);
						counter=counter+1;
					}
				}				
			}			
			counter = 0;
			DataFieldGroup dfgArrz[] = null;
			
			ArrayOfDataField arrDFz[] = null;
			
			ArrayOfString arrStrz[] = null;
			ArrayOfString arrStr2z[] = null;
			
			DataField dataFldz[] = null;
			DataField dataFld2z[] = null;
			
			if(rfcRequest.getMultiCABAppCode() != null){
				RFCDetail rfcDetail = rfcRequest.getMultiCABAppCode();
				
				List<RFCDetailAnswer> rfcDtlAnswers = rfcDetail.getRfcDetailAnswerList();
				
				dfgArrz = new DataFieldGroup[rfcDtlAnswers.size()];
				arrDFz = new ArrayOfDataField[rfcDtlAnswers.size()];
				arrStrz = new ArrayOfString[rfcDtlAnswers.size()];
				arrStr2z = new ArrayOfString[rfcDtlAnswers.size()];
				dataFldz = new DataField[rfcDtlAnswers.size()];
				dataFld2z = new DataField[rfcDtlAnswers.size()];
				if(rfcDtlAnswers != null && rfcDtlAnswers.size() >= 1){
					for(RFCDetailAnswer rfcAns:rfcDtlAnswers){	
						snowAddAppInstance(dfgs, rfcAns, "Not Applicable",dfgArrz[counter],arrDFz[counter],arrStrz[counter],arrStr2z[counter],dataFldz[counter],dataFld2z[counter],
								GROUPAPPROVAL,ASSIGNMENT_GROUP,COMMENTS);
						counter=counter+1;
					}
				}				
			}	
			temp = podDoc.toString();
		}catch(Exception ex){
			log.error(ex,ex);
			log.error("ManageRFCImpl :: getServiceNowChgReqtXml4Proxy:: Error while Preparing RequestXML for ServieNow ChangeRequest");
			rfcReqDTO.setErrorCode(RFCRequestDTO.ERRORCODE_POST_WEBSERVICE);
			rfcReqDTO.setErrorMessage(ex.getMessage());
		}
		log.info("ManageRFCImpl :: getServiceNowChgReqtXml4Proxy method ends");
		return temp;		
	}
	
	private String getRFCAnswer(RFCDetail rfcDetail, boolean isSingleAnswer)
    {
		String separator = System.getProperty( "line.separator" );
		String answer = "";
		if(isSingleAnswer == false && rfcDetail != null){
	    	List<RFCDetailAnswer> rda = rfcDetail.getRfcDetailAnswerList();
	    	answer=getMultipleRFCDetailAnswer(rda);
		}else if (isSingleAnswer == true && rfcDetail != null){
	    	List<RFCDetailAnswer> rda = rfcDetail.getRfcDetailAnswerList();
	    	RFCDetailAnswer rfcDetailAns = (RFCDetailAnswer) rda.get(0);
	    	answer = rfcDetailAns.getAnswer();
		}
		
		StringBuilder lines = new StringBuilder((answer.replaceAll("\\\\n", separator)).replaceAll("\n", separator));
		//log.info("value:-"+lines.toString());
		return lines.toString();
    }
	
	public String getMultipleRFCDetailAnswer(List<RFCDetailAnswer> rda)
	{
		StringBuffer question = new StringBuffer();
		for(RFCDetailAnswer rfcDetailAns:rda){
    		
    		if(rfcDetailAns.getTemplateKey()!=null)
			{
				question.append(rfcDetailAns.getTemplateKey().getPositionValue());
				question.append(". ");
				question.append(rfcDetailAns.getTemplateKey().getDescription());
				question.append("\\n");
			}else{
				question.append("");
			}
			question.append(rfcDetailAns.getAnswer());
			question.append("\\n");
			question.append("\\n");
    	}
		
		return question.toString();				
	}
	
	public String getMultipleRFCDetailAnswerWithComma(RFCDetail rfcDetail)
	{
		String str = "";		
		if(rfcDetail != null ){
			List<RFCDetailAnswer> rda = rfcDetail.getRfcDetailAnswerList();
			StringBuffer question = new StringBuffer();
			question.append("");
			for(RFCDetailAnswer rfcDetailAns:rda){
				question.append(rfcDetailAns.getAnswer());
				question.append(",");			
	    	}
			str = question.toString();
			if(str.indexOf(",")!=-1)
			{
				str = str.substring(0,str.lastIndexOf(","));
			}
		}
		return str;				
	}
	private void snowAddAppInstance(ArrayOfDataFieldGroup dfgs, RFCDetailAnswer rfcDetailsAns, String impacted,DataFieldGroup dfgArr,ArrayOfDataField arrDF,ArrayOfString arrStr,ArrayOfString arrStr2,DataField dfld,DataField dfld2,
			String att1,String att2,String att3){
		
		log.debug("ManageRFCImpl :: snowAddAppInstance :: appInstance :-"+rfcDetailsAns.getAnswer());
		dfgArr = dfgs.addNewDataFieldGroup();
		dfgArr.setName(att1);
		arrDF = dfgArr.addNewDataFields();
		
		
		dfld = arrDF.addNewDataField();
		dfld.setName(att2);
		arrStr = dfld.addNewValues();
		arrStr.addValue(rfcDetailsAns.getAnswer());
		//dfield41_2.setValues(str41_2);
		
		dfld2 = arrDF.addNewDataField();
		dfld2.setName(att3);
		arrStr2 = dfld2.addNewValues();
		arrStr2.addValue(impacted);
		//dfield41_app_2.setValues(str41_app_2);
	}
	
	private void snowAddDeviceIds(ArrayOfDataFieldGroup dfgs, RFCDetailAnswer rfcDetailsAns, String impacted,DataFieldGroup dfgArr,ArrayOfDataField arrDF,ArrayOfString arrStr,ArrayOfString arrStr2,DataField dfld,DataField dfld2,
			String att1,String att2,String att3){
		
		//log.info("appInstance:-"+rfcDetailsAns.getAnswer());
		dfgArr = dfgs.addNewDataFieldGroup();
		dfgArr.setName(att1);
		arrDF = dfgArr.addNewDataFields();
		
		
		dfld = arrDF.addNewDataField();
		dfld.setName(att2);
		arrStr = dfld.addNewValues();
		arrStr.addValue(impacted);
		//dfield41_2.setValues(str41_2);
		
		dfld2 = arrDF.addNewDataField();
		dfld2.setName(att3);
		arrStr2 = dfld2.addNewValues();
		arrStr2.addValue(rfcDetailsAns.getAnswer());
		//dfield41_app_2.setValues(str41_app_2);
	}

	@Override
	public Map getSchedulerValues() {
		return rfcUtil.getSchedulerValues();
		
		
	}

	@Override
	public void insertSNActivity(Long tiRequestId) {
		log.debug("insertSNActivity :"+tiRequestId);
		rfcUtil.insertSNActivity(tiRequestId);
		
	}

	@Override
	public void updateSNActivity(Long tiRequestId) {
		log.debug("updateSNActivity :"+tiRequestId);
		rfcUtil.updateSNActivity(tiRequestId);
		
	}
	
	@Override
	public void updateProcessInstanceId(Long tiRequestId,Long processInstanceId,String rfcType) {
		rfcUtil.updateProcessInstanceId(tiRequestId, processInstanceId,rfcType);		
	}

	@Override
	public String getServiceNowCRXml(RFCRequestDTO rfcReqDTO,
			RFCRequest rfcRequest, ServiceNowMessageLog SNMsgLog,
			ArrayList contactDetails) {
		// TODO Auto-generated method stub
		return getServiceNowChangeRequestXml(rfcReqDTO, rfcRequest, SNMsgLog, contactDetails);
	}
	
	@Override
	public boolean isChangeRequestsCreated(ProcessRFCDTO processRFCDTO) {
		boolean processRFCIncomplete=false;
		processRFCDTO=getRFCRequestList(processRFCDTO) ;
		List rfcRequestList=processRFCDTO.getRfcRequestDTOList();

        if (rfcRequestList != null && rfcRequestList.size() > 0) {
            for (int i = 0; i < rfcRequestList.size(); i++) {
                RFCRequestDTO rfcRequestDTO = (RFCRequestDTO) rfcRequestList.get(i);
                String rfcStatus = rfcRequestDTO.getRfcStatus();

                log.debug(" RFC Request ID:  " + rfcRequestDTO.getId() + "  RFC Request Status: " + rfcRequestDTO.getRfcStatus() + " RFC ID" + rfcRequestDTO.getRfcId() + " RFC ERRORCODE " + rfcRequestDTO.getErrorCode());

                if (rfcStatus == null || (rfcStatus != null && (rfcStatus.length() == 0) || (RFCRequestDTO.STATUS_GENERATED == rfcStatus))) {
                    processRFCIncomplete = true;

                    log.debug(" RFC Request Id : " + rfcRequestDTO.getId() + " is routed to HandleRFCException (" + processRFCIncomplete + ") as RFCSTatus is " + rfcRequestDTO.getRfcStatus());

                    break;
                }
            }

            if (! processRFCIncomplete) {
            	  for (int i = 0; i < rfcRequestList.size(); i++) {
                      RFCRequestDTO rfcRequestDTO = (RFCRequestDTO) rfcRequestList.get(i);
                    String rfcId = rfcRequestDTO.getRfcId();

                    log.debug(" RFC Request ID:  " + rfcRequestDTO.getId() + "  RFC Request Status: " + rfcRequestDTO.getRfcStatus() + " RFC ID" + rfcRequestDTO.getRfcId() + " RFC ERRORCODE " + rfcRequestDTO.getErrorCode());

                    if (rfcId == null || ((rfcId != null) && ("0" == rfcId))) {
                        processRFCIncomplete = true;

                        log.debug(" RFC Request Id : " + rfcRequestDTO.getId()+ " is routed to HandleRFCException (" + processRFCIncomplete + ") as RFCID is " + rfcId);

                        break;
                    }
                }
            }
        }
        else {
            log.debug("RFCDTO List is empty for tiRequestId " + processRFCDTO.getTiRequestId() + "routing to HandleRFCException");

            processRFCIncomplete = true;
        }

        // chk and see if rfcRequestIds are if present then for all rfzRequests ids there should be RFC with rfcstatus as design or review else send to excetion
       
       
   
		log.debug("isChangeRequests Not Created :"+processRFCDTO.getTiRequestId()+processRFCIncomplete);
		return processRFCIncomplete;
		
	}
}
