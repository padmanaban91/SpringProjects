package com.citigroup.cgti.c3par.domain;

import javax.xml.bind.annotation.XmlElement;

public class AuditTrailDetailEmailVO {
	
	private String lastSubmittedRole;
	private String comments;
	private String activityMode;
	@XmlElement
	public String getLastSubmittedRole() {
		return lastSubmittedRole;
	}
	public void setLastSubmittedRole(String lastSubmittedRole) {
		this.lastSubmittedRole = lastSubmittedRole;
	}
	@XmlElement
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	@XmlElement
	public String getActivityMode() {
		return activityMode;
	}
	public void setActivityMode(String activityMode) {
		this.activityMode = activityMode;
	}
	
	

}
