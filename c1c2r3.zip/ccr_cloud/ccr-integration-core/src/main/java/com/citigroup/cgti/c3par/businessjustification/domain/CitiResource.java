

/** CONFIDENTIAL  AND PROPRIETARY
 * Copyright @ 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is
 * strictly prohibited.
 */

package com.citigroup.cgti.c3par.businessjustification.domain;

import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.domain.Base;

/**
 * ne36745
 */
/**
 * The Class CitiResourceEntity.
 */
public class CitiResource extends Base
{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** The name. */
    private	String	name;

    /** The resourceid. */
    private	String	resourceid;

    /** The owner. */
    private	String	owner;

    /** The alternate type. */
    private	String	alternateType;

    /** The env description. */
    private	String	envDescription;

    /** The functionality description. */
    private	String	functionalityDescription;

    /** The ip address. */
    private	String	ipAddress;

    /** The url. */
    private	String	url;

    /** The dns name. */
    private	String	dnsName;

    /** The is registered in source. */
    private	Boolean	isRegisteredInSource;

    /** The cwhi id. */
    private	String	cwhiId;

    /** The ownerid. */
    private	String	ownerid;

    /** The prefered type. */
    private	String preferredType;

    /** The prefered type id. */
    private	Long	preferedTypeId;

    /** The criticality. */
    private	String	criticality;

    /** The criticality id. */
    private	Long	criticalityId;

    /** The classification. */
    private	String	classification;

    /** The classification id. */
    private	Long	classificationId;

    /** The access type. */
    private	String	accessType;

    /** The access type id. */
    private	Long	accessTypeId;
    
    /** The app manager full name. */
    private	String	appManagerFullName;

    /** The app manager geid. */
    private	String	appManagerGEID;

    /** The app manager email. */
    private	String	appManagerEmail;

    private String personalDataIndicator;

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the resourceid
	 */
	public String getResourceid() {
		return resourceid;
	}

	/**
	 * @param resourceid the resourceid to set
	 */
	public void setResourceid(String resourceid) {
		this.resourceid = resourceid;
	}

	/**
	 * @return the owner
	 */
	public String getOwner() {
		return owner;
	}

	/**
	 * @param owner the owner to set
	 */
	public void setOwner(String owner) {
		this.owner = owner;
	}

	/**
	 * @return the alternateType
	 */
	public String getAlternateType() {
		return alternateType;
	}

	/**
	 * @param alternateType the alternateType to set
	 */
	public void setAlternateType(String alternateType) {
		this.alternateType = alternateType;
	}

	/**
	 * @return the envDescription
	 */
	public String getEnvDescription() {
		return envDescription;
	}

	/**
	 * @param envDescription the envDescription to set
	 */
	public void setEnvDescription(String envDescription) {
		this.envDescription = envDescription;
	}

	/**
	 * @return the functionalityDescription
	 */
	public String getFunctionalityDescription() {
		return functionalityDescription;
	}

	/**
	 * @param functionalityDescription the functionalityDescription to set
	 */
	public void setFunctionalityDescription(String functionalityDescription) {
		this.functionalityDescription = functionalityDescription;
	}

	/**
	 * @return the ipAddress
	 */
	public String getIpAddress() {
		return ipAddress;
	}

	/**
	 * @param ipAddress the ipAddress to set
	 */
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * @return the dnsName
	 */
	public String getDnsName() {
		return dnsName;
	}

	/**
	 * @param dnsName the dnsName to set
	 */
	public void setDnsName(String dnsName) {
		this.dnsName = dnsName;
	}

	/**
	 * @return the isRegisteredInSource
	 */
	public Boolean getIsRegisteredInSource() {
		return isRegisteredInSource;
	}

	/**
	 * @param isRegisteredInSource the isRegisteredInSource to set
	 */
	public void setIsRegisteredInSource(Boolean isRegisteredInSource) {
		this.isRegisteredInSource = isRegisteredInSource;
	}

	/**
	 * @return the cwhiId
	 */
	public String getCwhiId() {
		return cwhiId;
	}

	/**
	 * @param cwhiId the cwhiId to set
	 */
	public void setCwhiId(String cwhiId) {
		this.cwhiId = cwhiId;
	}

	/**
	 * @return the ownerid
	 */
	public String getOwnerid() {
		return ownerid;
	}

	/**
	 * @param ownerid the ownerid to set
	 */
	public void setOwnerid(String ownerid) {
		this.ownerid = ownerid;
	}

	/**
	 * @return the preferredType
	 */
	public String getPreferredType() {
		return preferredType;
	}

	/**
	 * @param preferredType the preferredType to set
	 */
	public void setPreferredType(String preferredType) {
		this.preferredType = preferredType;
	}

	/**
	 * @return the preferedTypeId
	 */
	public Long getPreferedTypeId() {
		return preferedTypeId;
	}

	/**
	 * @param preferedTypeId the preferedTypeId to set
	 */
	public void setPreferedTypeId(Long preferedTypeId) {
		this.preferedTypeId = preferedTypeId;
	}

	/**
	 * @return the criticality
	 */
	public String getCriticality() {
		return criticality;
	}

	/**
	 * @param criticality the criticality to set
	 */
	public void setCriticality(String criticality) {
		this.criticality = criticality;
	}

	/**
	 * @return the criticalityId
	 */
	public Long getCriticalityId() {
		return criticalityId;
	}

	/**
	 * @param criticalityId the criticalityId to set
	 */
	public void setCriticalityId(Long criticalityId) {
		this.criticalityId = criticalityId;
	}

	/**
	 * @return the classification
	 */
	public String getClassification() {
		return classification;
	}

	/**
	 * @param classification the classification to set
	 */
	public void setClassification(String classification) {
		this.classification = classification;
	}

	/**
	 * @return the classificationId
	 */
	public Long getClassificationId() {
		return classificationId;
	}

	/**
	 * @param classificationId the classificationId to set
	 */
	public void setClassificationId(Long classificationId) {
		this.classificationId = classificationId;
	}

	/**
	 * @return the accessType
	 */
	public String getAccessType() {
		return accessType;
	}

	/**
	 * @param accessType the accessType to set
	 */
	public void setAccessType(String accessType) {
		this.accessType = accessType;
	}

	/**
	 * @return the accessTypeId
	 */
	public Long getAccessTypeId() {
		return accessTypeId;
	}

	/**
	 * @param accessTypeId the accessTypeId to set
	 */
	public void setAccessTypeId(Long accessTypeId) {
		this.accessTypeId = accessTypeId;
	}

	/**
	 * @return the appManagerFullName
	 */
	public String getAppManagerFullName() {
		return appManagerFullName;
	}

	/**
	 * @param appManagerFullName the appManagerFullName to set
	 */
	public void setAppManagerFullName(String appManagerFullName) {
		this.appManagerFullName = appManagerFullName;
	}

	/**
	 * @return the appManagerGEID
	 */
	public String getAppManagerGEID() {
		return appManagerGEID;
	}

	/**
	 * @param appManagerGEID the appManagerGEID to set
	 */
	public void setAppManagerGEID(String appManagerGEID) {
		this.appManagerGEID = appManagerGEID;
	}

	/**
	 * @return the appManagerEmail
	 */
	public String getAppManagerEmail() {
		return appManagerEmail;
	}

	/**
	 * @param appManagerEmail the appManagerEmail to set
	 */
	public void setAppManagerEmail(String appManagerEmail) {
		this.appManagerEmail = appManagerEmail;
	}

	/**
	 * @return the personalDataIndicator
	 */
	public String getPersonalDataIndicator() {
		return personalDataIndicator;
	}

	/**
	 * @param personalDataIndicator the personalDataIndicator to set
	 */
	public void setPersonalDataIndicator(String personalDataIndicator) {
		this.personalDataIndicator = personalDataIndicator;
	}

	


}
