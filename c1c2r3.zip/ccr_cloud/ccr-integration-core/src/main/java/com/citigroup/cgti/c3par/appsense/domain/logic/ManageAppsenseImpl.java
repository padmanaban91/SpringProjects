package com.citigroup.cgti.c3par.appsense.domain.logic;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.Exception.BusinessException;
import com.citigroup.cgti.c3par.appsense.domain.AppsenseAAFCombination;
import com.citigroup.cgti.c3par.appsense.domain.AppsenseADGroup;
import com.citigroup.cgti.c3par.appsense.domain.AppsenseApplication;
import com.citigroup.cgti.c3par.appsense.domain.AppsenseDTO;
import com.citigroup.cgti.c3par.appsense.domain.AppsensePortMaster;
import com.citigroup.cgti.c3par.appsense.domain.AppsenseUser;
import com.citigroup.cgti.c3par.appsense.domain.ConnectionIPMaster;
import com.citigroup.cgti.c3par.appsense.domain.ConnectionOstiaGroup;
import com.citigroup.cgti.c3par.appsense.domain.ManageAppsenseProcess;
import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.common.domain.GenericLookupDef;
import com.citigroup.cgti.c3par.configuation.CCRQueries;
import com.citigroup.cgti.c3par.connection.domain.logic.TechnicalArchitectureUtil;
import com.citigroup.cgti.c3par.domain.Application;
import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.fw.domain.Port;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
import com.citigroup.cgti.c3par.quality.score.dao.QualityScoreDaoService;
import com.citigroup.cgti.c3par.quality.score.service.CSIQualityScoreUpdateService;
import com.citigroup.cgti.c3par.webtier.helper.AppsenseUtil;
import com.citigroup.cgti.c3par.webtier.helper.Util;

/**
 * The Class ManageAppsenseImpl.
 */
@SuppressWarnings({ "unchecked", "unused" })
@Transactional
public class ManageAppsenseImpl extends BasePersistanceImpl implements ManageAppsensePersistable {

    /** The technical architecture util. */
    private TechnicalArchitectureUtil technicalArchitectureUtil;
    private CCRQueries ccrQueries;
    /** The LOGGER. */
    protected static Logger LOGGER = Logger.getLogger(ManageAppsenseImpl.class);
    // Below methods would be made private after JUnit testing

    public static final String CSI = "CSI";

    @Autowired
    CSIQualityScoreUpdateService csiQualityScoreUpdateService;

    @Autowired
    private QualityScoreDaoService qualityScoreDaoService;

    /**
     * Find application by csi id.
     * 
     * @param csiId
     *            the csi id
     * @return the application
     */
    private Application findApplicationByCsiId(long csiId) {
        Application app = null;
        LOGGER.debug("csiId:" + csiId);
        try {
            Criteria crit = getSession().createCriteria(Application.class);
            crit.add(Restrictions.eq("applicationID", Long.valueOf(csiId)));
            List apps = crit.list();
            if (apps.size() > 0) {
                for (Iterator it = apps.iterator(); it.hasNext();) {
                    app = (Application) it.next();
                    break;
                }
            }
        } catch (Exception e) {
            LOGGER.error("Exception in findApplicationByCsiId :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(" There was an exception while finding application with CSI Id:" + csiId);
        }
        return app;
    }

    /**
     * Find application by non csi name.
     * 
     * @param app
     *            the app
     * @return the application
     */
    private Application findApplicationByNonCsiName(Application app) {
        Application application = null;
        LOGGER.debug("Application Name:" + app.getApplicationName());
        try {
            Criteria crit = getSession().createCriteria(Application.class);
            crit.add(Restrictions.eq("applicationName", app.getApplicationName()));
            if (app.getFunction() != null)
                crit.add(Restrictions.eq("function", app.getFunction()));
            if (app.getAppOwnerFullName() != null)
                crit.add(Restrictions.eq("appOwnerFullName", app.getAppOwnerFullName()));
            if (app.getAppOwnerGEID() != null)
                crit.add(Restrictions.eq("appOwnerGEID", app.getAppOwnerGEID()));
            crit.add(Restrictions.eq("isBlackListed", "N"));
            crit.add(Restrictions.eq("isCSI", "N"));
            List apps = crit.list();
            if (apps.size() > 0) {
                for (Iterator it = apps.iterator(); it.hasNext();) {
                    application = (Application) it.next();
                    break;
                }
            }
        } catch (Exception e) {
            LOGGER.error("Exception in findApplicationByNonCsiName :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(" There was an exception while finding application with Name:"
                    + app.getApplicationName());
        }
        return application;
    }

    /**
     * Find black listed application by name.
     * 
     * @param appName
     *            the app name
     * @return the application
     */
    private Application findBlackListedApplicationByName(String appName) {
        Application app = null;
        LOGGER.debug("App Name:" + appName);
        try {
            Criteria crit = getSession().createCriteria(Application.class);
            crit.add(Restrictions.eq("applicationName", appName).ignoreCase());
            crit.add(Restrictions.eq("isBlackListed", "Y").ignoreCase());
            List apps = crit.list();
            if (apps.size() > 0) {
                for (Iterator it = apps.iterator(); it.hasNext();) {
                    app = (Application) it.next();
                    break;
                }
            }
        } catch (Exception e) {
            LOGGER.error("Exception in findBlackListedApplicationByName :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(" There was an exception while finding Blacklisted application with Name:"
                    + appName);
        }
        return app;
    }

    /**
     * Gets the appsense application list.
     * 
     * @param processId
     *            the process id
     * @param pageNum
     *            the page num
     * @param pageSize
     *            the page size
     * @return the appsense application list
     */
    private List getAppsenseApplicationList(Long processId, ManageAppsenseProcess manageAppsenseProcess) {
        List apsApps = null;
        LOGGER.debug("process Id:" + processId);
        try {
            Criteria crit = getSession().createCriteria(AppsenseApplication.class);
            TIProcess tiProcess = getTIProcessById(processId.longValue());
            crit.add(Restrictions.eq("tiProcess", tiProcess));
            crit.add(Restrictions.eq("recordType", "A"));
            int rowCount = getRowCount(crit);
            manageAppsenseProcess.setRowCount(rowCount);
            addPagination(crit, manageAppsenseProcess.getOffset(), manageAppsenseProcess.getLimit());
            apsApps = crit.list();
            Iterator appsAppsIter = apsApps.iterator();
            while (appsAppsIter.hasNext()) {
                AppsenseApplication temp = (AppsenseApplication) appsAppsIter.next();
                if (temp != null && temp.getApplication() != null && temp.getApplication().getApplicationName() != null
                        && "Y".equals(temp.getApplication().getIsBlackListed())) {
                    temp.getApplication().setApplicationName(
                            Util.toInitCaps(temp.getApplication().getApplicationName()));
                }
                if (temp.getApsPortMaster() != null && temp.getApsPortMaster().getId() != null) {
                    temp.setPortUnblock("Y");
                } else {
                    if (temp.getApsPortMaster() == null) {
                        temp.setApsPortMaster(new AppsensePortMaster());
                    }
                    temp.setPortUnblock("N");
                }
            }
        } catch (Exception e) {
            LOGGER.error("Exception in getAppsenseApplicationList :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(
                    " There was an exception while getting appsense application list for process id:" + processId);
        }
        return apsApps;
    }

    // Ostia Starts

    /**
     * Gets the appsense ostia application list.
     * 
     * @param processId
     *            the process id
     * @param pageNum
     *            the page num
     * @param pageSize
     *            the page size
     * @return the appsense ostia application list
     */
    private List getAppsenseOstiaApplicationList(Long processId, ManageAppsenseProcess manageAppsenseProcess) {
        List apsApps = null;
        LOGGER.debug("process Id:" + processId);
        try {
            Criteria crit = getSession().createCriteria(AppsenseApplication.class);
            TIProcess tiProcess = getTIProcessById(processId.longValue());
            crit.add(Restrictions.eq("tiProcess", tiProcess));
            crit.add(Restrictions.eq("recordType", "A"));
            crit.add(Restrictions.isNotNull("apsPortMaster"));
            int rowCount = getRowCount(crit);
            manageAppsenseProcess.setRowCount(rowCount);
            addPagination(crit, manageAppsenseProcess.getOffset(), manageAppsenseProcess.getLimit());
            apsApps = crit.list();
        } catch (Exception e) {
            LOGGER.error("Exception in getAppsenseOstiaApplicationList :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(
                    " There was an exception while getting appsense OStia application list for process id:" + processId);
        }
        return apsApps;
    }

    // Ostia Ends
    /**
     * Gets the total number.
     * 
     * @param processId
     *            the process id
     * @param recordType
     *            the record type
     * @return the total number
     */
    private int getTotalNumber(long processId, String recordType) {
        List apsApps = null;
        Long rowCount = Long.valueOf(0);
        LOGGER.debug("process Id:" + processId);
        try {
            Criteria crit;
            if ("A".equalsIgnoreCase(recordType)) {
                crit = getSession().createCriteria(AppsenseApplication.class);
            } else if ("U".equals(recordType)) {
                crit = getSession().createCriteria(AppsenseUser.class);
            } else {
                throw new ApplicationException(
                        " in getTotalNumber: The record type does not match with known types for process id:"
                                + processId + " Record Type:" + recordType);
            }
            TIProcess tiProcess = getTIProcessById(processId);
            crit.add(Restrictions.eq("tiProcess", tiProcess));
            crit.add(Restrictions.eq("recordType", recordType));
            crit.setProjection(Projections.rowCount());
            apsApps = crit.list();
            if (!apsApps.isEmpty()) {
                rowCount = (Long) apsApps.get(0);
            }
        } catch (Exception e) {
            LOGGER.error("Exception in getTotalNumber :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(" There was an exception while getting Total Number for process id:"
                    + processId + " Record Type:" + recordType);
        }
        return rowCount.intValue();
    }

    /**
     * Gets the aps ostia total number.
     * 
     * @param processId
     *            the process id
     * @param recordType
     *            the record type
     * @return the aps ostia total number
     */
    private int getApsOstiaTotalNumber(long processId, String recordType) {
        List apsApps = null;
        Integer rowCount = Integer.valueOf(0);
        LOGGER.debug("process Id:" + processId);
        try {
            Criteria crit;
            if ("A".equalsIgnoreCase(recordType)) {
                crit = getSession().createCriteria(AppsenseApplication.class);
            } else {
                throw new ApplicationException(
                        " in getApsOstiaTotalNumber: The record type does not match with known types for process id:"
                                + processId + " Record Type:" + recordType);
            }
            TIProcess tiProcess = getTIProcessById(processId);
            crit.add(Restrictions.eq("tiProcess", tiProcess));
            crit.add(Restrictions.eq("recordType", recordType));
            crit.add(Restrictions.isNotNull("apsPortMaster"));
            crit.setProjection(Projections.rowCount());
            apsApps = crit.list();
            if (!apsApps.isEmpty()) {
                rowCount = (Integer) apsApps.get(0);
            }
        } catch (Exception e) {
            LOGGER.error("Exception in getApsOstiaTotalNumber :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(
                    " There was an exception while getting Aps Ostia Total Number for process id:" + processId
                            + " Record Type:" + recordType);
        }
        return rowCount.intValue();
    }

    /**
     * Gets the appsense user list.
     * 
     * @param processId
     *            the process id
     * @param pageNum
     *            the page num
     * @param pageSize
     *            the page size
     * @return the appsense user list
     */
    private List getAppsenseUserList(Long processId, ManageAppsenseProcess manageAppsenseProcess) {
        List apsUsers = null;
        LOGGER.debug("process id:" + processId);
        try {
            Criteria crit = getSession().createCriteria(AppsenseUser.class);
            TIProcess tiProcess = getTIProcessById(processId.longValue());
            crit.add(Restrictions.eq("tiProcess", tiProcess));
            crit.add(Restrictions.eq("recordType", "U"));
            int rowCount = getRowCount(crit);
            manageAppsenseProcess.setRowCount(rowCount);
            addPagination(crit, manageAppsenseProcess.getOffset(), manageAppsenseProcess.getLimit());
            apsUsers = crit.list();
        } catch (Exception e) {
            LOGGER.error("Exception in getAppsenseUserList :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(" There was an exception while getting appsense users list for process id:"
                    + processId);
        }
        return apsUsers;
    }

    /**
     * Find citi contact by sso id.
     * 
     * @param ssoId
     *            the sso id
     * @return the citi contact
     */
    private CitiContact findCitiContactBySSOId(String ssoId) {
        CitiContact cc = null;
        LOGGER.debug("SSO Id:" + ssoId);
        try {
            if (ssoId != null) {
                Criteria crit = getSession().createCriteria(CitiContact.class);
                crit.add(Restrictions.eq("ssoId", ssoId.toLowerCase()).ignoreCase());
                List ccs = crit.list();
                if (ccs.size() > 0) {
                    for (Iterator it = ccs.iterator(); it.hasNext();) {
                        cc = (CitiContact) it.next();
                        break;
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error("Exception in findCitiContactBySSOId :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(" There was an exception while finding Citi Contact record by SSOId:"
                    + ssoId);
        }
        return cc;
    }

    /**
     * Find port lookup.
     * 
     * @param portNumber
     *            the port number
     * @param protocol
     *            the protocol
     * @param flowOfData
     *            the flow of data
     * @return the connection port look up
     */
    private Port findPortLookup(String portNumber, String protocol, String flowOfData) {
        Port cpl = null;
        try {
            if (portNumber != null && protocol != null && flowOfData != null) {

                Criteria maxId = getSession().createCriteria(Port.class).setProjection(Projections.max("id"))
                        .add(Restrictions.eq("portNumber", portNumber.toLowerCase()).ignoreCase())
                        .add(Restrictions.eq("protocol", protocol.toLowerCase()).ignoreCase())
                        .add(Restrictions.eq("flowOfData", flowOfData.toLowerCase()).ignoreCase());
                Long idValue = (Long) maxId.uniqueResult();

                Criteria crit = getSession().createCriteria(Port.class);
                crit.add(Restrictions.eq("portNumber", portNumber.toLowerCase()).ignoreCase());
                crit.add(Restrictions.eq("protocol", protocol.toLowerCase()).ignoreCase());
                crit.add(Restrictions.eq("flowOfData", flowOfData.toLowerCase()).ignoreCase());
                if (idValue != null) {
                    crit.add(Restrictions.eq("id", Long.valueOf(idValue)));
                }
                cpl = (Port) crit.uniqueResult();
            }
        } catch (Exception e) {
            LOGGER.error("Exception in findCitiContactBySSOId :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(" There was an exception while finding Port Lookup record ");
        }
        return cpl;
    }

    /**
     * Find ip master.
     * 
     * @param userInputType
     *            the user input type
     * @param ipAddress
     *            the ip address
     * @param startIpAddress
     *            the start ip address
     * @param subnet
     *            the subnet
     * @return the connection ip master
     */
    private ConnectionIPMaster findIPMaster(String userInputType, String ipAddress, String startIpAddress, String subnet) {
        ConnectionIPMaster cim = null;
        try {
            if (userInputType != null) {
                if (userInputType.equals("SINGLE")) {
                    Criteria maxId = getSession().createCriteria(ConnectionIPMaster.class)
                            .setProjection(Projections.max("id")).add(Restrictions.eq("ipAddress", ipAddress));
                    Long idValue = (Long) maxId.uniqueResult();
                    Criteria crit = getSession().createCriteria(ConnectionIPMaster.class);
                    crit.add(Restrictions.eq("ipAddress", ipAddress));
                    if (idValue != null) {
                        crit.add(Restrictions.eq("id", Long.valueOf(idValue)));
                    }
                    cim = (ConnectionIPMaster) crit.uniqueResult();
                } else if (userInputType.equals("SUBNET")) {
                    Criteria maxId = getSession().createCriteria(ConnectionIPMaster.class)
                            .setProjection(Projections.max("id"))
                            .add(Restrictions.eq("startIPAddress", startIpAddress))
                            .add(Restrictions.eq("subnet", subnet));
                    Long idValue = (Long) maxId.uniqueResult();

                    Criteria crit = getSession().createCriteria(ConnectionIPMaster.class);
                    crit.add(Restrictions.eq("startIPAddress", startIpAddress));
                    crit.add(Restrictions.eq("subnet", subnet));
                    if (idValue != null) {
                        crit.add(Restrictions.eq("id", Long.valueOf(idValue)));
                    }
                    cim = (ConnectionIPMaster) crit.uniqueResult();
                }
            } else if (ipAddress != null) {
                Criteria maxId = getSession().createCriteria(ConnectionIPMaster.class)
                        .setProjection(Projections.max("id")).add(Restrictions.eq("ipAddress", ipAddress));
                Long idValue = (Long) maxId.uniqueResult();
                Criteria crit = getSession().createCriteria(ConnectionIPMaster.class);
                crit.add(Restrictions.eq("ipAddress", ipAddress).ignoreCase());
                if (idValue != null) {
                    crit.add(Restrictions.eq("id", Long.valueOf(idValue)));
                }
                cim = (ConnectionIPMaster) crit.uniqueResult();
            }
        } catch (Exception e) {
            LOGGER.error("Exception in findIPMaster :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(" There was an exception while finding IP master record ");
        }
        return cim;
    }

    /**
     * Find ip master.
     * 
     * @param userInputType
     *            the user input type
     * @param ipAddress
     *            the ip address
     * @param startIpAddress
     *            the start ip address
     * @param subnet
     *            the subnet
     * @return the connection ip master
     */
    private ConnectionIPMaster findIPMaster(ConnectionIPMaster orgIPAddress) {
        Session session = getSession();
        ConnectionIPMaster cim = null;
        try {
            List<ConnectionIPMaster> ipAddress = null;
            if (("SUBNET").equals(orgIPAddress.getUserInputType())) {
                Criteria maxId = getSession().createCriteria(ConnectionIPMaster.class)
                        .setProjection(Projections.max("id"))
                        .add(Restrictions.eq("startIPAddress", orgIPAddress.getStartIPAddress()))
                        .add(Restrictions.eq("subnet", orgIPAddress.getSubnet()));
                Long idValue = (Long) maxId.uniqueResult();

                Criteria crit = getSession().createCriteria(ConnectionIPMaster.class);
                crit.add(Restrictions.eq("startIPAddress", orgIPAddress.getStartIPAddress()));
                crit.add(Restrictions.eq("subnet", orgIPAddress.getSubnet()));
                if (idValue != null) {
                    crit.add(Restrictions.eq("id", Long.valueOf(idValue)));
                }
                cim = (ConnectionIPMaster) crit.uniqueResult();
            } else {
                if (orgIPAddress.getIpAddress().indexOf("-") != -1) {
                    ipAddress = (List<ConnectionIPMaster>) session.createQuery(
                            "from ConnectionIPMaster ip where ip.formattedStartIP = '"
                                    + orgIPAddress.getFormattedStartIP() + "' and ip.formattedEndIP = '"
                                    + orgIPAddress.getFormattedEndIP() + "'").list();
                } else {
                    ipAddress = (List<ConnectionIPMaster>) session.createQuery(
                            "from ConnectionIPMaster ip where ip.formattedIP = '" + orgIPAddress.getFormattedIP()
                                    + "' ").list();
                }
                if (ipAddress != null && !ipAddress.isEmpty()) {
                    cim = ipAddress.get(0);
                }
            }

        } catch (Exception e) {
            LOGGER.error("Exception in findIPMaster :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(" There was an exception while finding IP master record ");
        }
        return cim;
    }

    /**
     * Find appsense port master.
     * 
     * @param ipMaster
     *            the ip master
     * @param portLookup
     *            the port lookup
     * @return the appsense port master
     */
    private AppsensePortMaster findAppsensePortMaster(ConnectionIPMaster ipMaster, Port portLookup) {
        AppsensePortMaster apm = null;
        try {
            Criteria maxId = getSession().createCriteria(AppsensePortMaster.class).setProjection(Projections.max("id"))
                    .add(Restrictions.eq("portLookUp", portLookup))
                    .add(Restrictions.eq("connectionIPMaster", ipMaster));
            Long idValue = (Long) maxId.uniqueResult();
            Criteria crit = getSession().createCriteria(AppsensePortMaster.class);
            crit.add(Restrictions.eq("portLookUp", portLookup));
            crit.add(Restrictions.eq("connectionIPMaster", ipMaster));
            if (idValue != null) {
                crit.add(Restrictions.eq("id", Long.valueOf(idValue)));
            }
            apm = (AppsensePortMaster) crit.uniqueResult();
        } catch (Exception e) {
            LOGGER.error("Exception in findAppsensePortMaster :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(" There was an exception while finding appsense port master record ");
        }
        return apm;
    }

    /**
     * Find appsense application.
     * 
     * @param apsApplication
     *            the aps application
     * @return the appsense application
     */
    private AppsenseApplication findAppsenseApplication(AppsenseApplication apsApplication) {
        AppsenseApplication aps = null;
        try {
            Criteria crit = getSession().createCriteria(AppsenseApplication.class);
            crit.add(Restrictions.eq("tiProcess", apsApplication.getTiProcess()));
            crit.add(Restrictions.eq("tiRequest", apsApplication.getTiRequest()));
            crit.add(Restrictions.eq("application", apsApplication.getApplication()));
            if (apsApplication.getApsPortMaster() != null)
                crit.add(Restrictions.eq("apsPortMaster", apsApplication.getApsPortMaster()));
            else
                crit.add(Restrictions.isNull("apsPortMaster"));
            crit.add(Restrictions.eq("recordType", "A"));
            aps = (AppsenseApplication) crit.uniqueResult();
        } catch (Exception e) {
            LOGGER.error("Exception in findAppsenseApplication :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(
                    " There was an exception while finding appsense Application record with Name:"
                            + apsApplication.getApplication().getApplicationName());
        }
        return aps;
    }

    /**
     * Find appsense user.
     * 
     * @param apsUser
     *            the aps user
     * @return the appsense user
     */
    private AppsenseUser findAppsenseUser(AppsenseUser apsUser) {
        AppsenseUser apu = null;
        try {
            Criteria crit = getSession().createCriteria(AppsenseUser.class);
            crit.add(Restrictions.eq("tiProcess", apsUser.getTiProcess()));
            crit.add(Restrictions.eq("tiRequest", apsUser.getTiRequest()));
            crit.add(Restrictions.eq("citiContact", apsUser.getCitiContact()));
            crit.add(Restrictions.eq("recordType", "U"));
            apu = (AppsenseUser) crit.uniqueResult();
        } catch (Exception e) {
            LOGGER.error("Exception in findAppsenseUser :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(" There was an exception while finding appsense User record with SSOID:"
                    + apsUser.getCitiContact().getSsoId());
        }
        return apu;
    }

    /**
     * Store appsense object.
     * 
     * @param base
     *            the base
     */
    private void storeAppsenseObject(Base base) {
        getSession().saveOrUpdate(base);
    }

    /**
     * Store application.
     * 
     * @param app
     *            the app
     * @return the application
     */
    private Application storeApplication(Application app) {
        Application application = null;
        try {
            if (app == null || !(app instanceof Application)) {
                throw new ApplicationException(
                        "The received object is either NULL or it is not of required type Application");
            }
            if (app != null) {
                LOGGER.info("ManageAppsenseImpl:storeApplication: Entering with App Name:" + app.getApplicationName());
                app.setApplicationName(app.getApplicationName().replace(",", "").trim());
                if ("Y".equalsIgnoreCase(app.getIsBlackListed())) {
                    application = findBlackListedApplicationByName(app.getApplicationName());
                } else if ("Y".equalsIgnoreCase(app.getIsCSI())) {
                    application = findApplicationByCsiId(app.getApplicationID().longValue());
                    if (application != null) {
                        application.setApplicationName(app.getApplicationName());
                        if (app.getFunction() != null)
                            application.setFunction(app.getFunction());
                        application.setAppOwnerEmail(app.getAppOwnerEmail());
                        application.setAppOwnerFullName(app.getAppOwnerFullName());
                        application.setAppOwnerGEID(app.getAppOwnerGEID());

                        if (app.getIsDevice() != null)
                            application.setIsDevice(app.getIsDevice());
                        if (app.getIsCSI() != null)
                            application.setIsCSI(app.getIsCSI());
                        if (app.getIsBlackListed() != null)
                            application.setIsBlackListed(app.getIsBlackListed());
                        if (app.getExeFileName() != null)
                            application.setExeFileName(app.getExeFileName());
                        if (app.getNetworkPath() != null)
                            application.setNetworkPath(app.getNetworkPath());
                        application.setIsDevice("N");
                        application = (Application) getSession().merge(application);
                    } else {
                        application = (Application) getSession().get(Application.class, getSession().save(app));
                    }
                } else {
                    application = findApplicationByNonCsiName(app);
                    if (application != null) {
                        LOGGER.info(application.getIsCSI()
                                + " Non csi application, check if this is application or device. The current value is "
                                + application.getIsDevice());
                        application = (Application) getSession().merge(application);
                    } else {
                        LOGGER.info(app.getIsCSI()
                                + " Non csi application, check if this is application or device. The current value is "
                                + app.getIsDevice());
                        application = (Application) getSession().get(Application.class, getSession().save(app));
                    }
                }
            }
            if (application == null) {
                throw new ApplicationException("There was a problem in storing the Application : "
                        + app.getApplicationName());
            }
        } catch (ApplicationException e) {
            LOGGER.error("ApplicationException in storeApplication :" + e);
            LOGGER.error(e.toString(), e);
            throw e;
        } catch (Exception e) {
            LOGGER.error("Exception in storeApplication :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(" There was an exception while storing Application record with Name:"
                    + app.getApplicationName());
        }
        return application;
    }

    /**
     * Store citi contact.
     * 
     * @param cc
     *            the cc
     * @return the citi contact
     */
    private CitiContact storeCitiContact(CitiContact cc) {
        CitiContact citiContact = null;
        try {
            if (cc == null || !(cc instanceof CitiContact)) {
                throw new ApplicationException(
                        "The received object is either NULL or it is not of required type CitiContact");
            }
            if (cc != null) {
                LOGGER.info("ManageAppsenseImpl:storeCitiContact: Entering with ssoId:" + cc.getSsoId());
                citiContact = findCitiContactBySSOId(cc.getSsoId());
                if (citiContact == null) {
                    citiContact = (CitiContact) getSession().get(CitiContact.class, getSession().save(cc));
                }
            }
            if (citiContact == null) {
                throw new ApplicationException("There was a problem in storing the Citi Contact : " + cc.getSsoId());
            }
        } catch (ApplicationException e) {
            LOGGER.error("ApplicationException in storeCitiContact :" + e);
            LOGGER.error(e.toString(), e);
            LOGGER.error(e, e);
            throw e;
        } catch (Exception e) {
            LOGGER.error("Exception in storeCitiContact :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(" There was an exception while storing Citi Contact record with SSOID:"
                    + cc.getSsoId());
        }
        return citiContact;
    }

    /**
     * Store appsense port master.
     * 
     * @param apsPortMaster
     *            the aps port master
     * @return the appsense port master
     */
    private AppsensePortMaster storeAppsensePortMaster(AppsensePortMaster apsPortMaster) {
        AppsensePortMaster appsensePortMaster = null;
        try {
            if (apsPortMaster == null || !(apsPortMaster instanceof AppsensePortMaster)) {
                throw new ApplicationException(
                        "The received object is either NULL or it is not of required type AppsensePortMaster");
            }
            ConnectionIPMaster ipMaster = storeIPMaster(apsPortMaster.getConnectionIPMaster());
            Port portLookup = storePortLookup(apsPortMaster.getPortLookUp());
            appsensePortMaster = findAppsensePortMaster(ipMaster, portLookup);
            if (appsensePortMaster == null) {
                apsPortMaster.setConnectionIPMaster(ipMaster);
                apsPortMaster.setPortLookUp(portLookup);
                apsPortMaster.setCreated_date(new Date());
                // apsPortMaster.setUpdated_date(new Date());
                if (apsPortMaster.getConOstiaGroup() != null && apsPortMaster.getConOstiaGroup().getId() == null) {
                    apsPortMaster.setConOstiaGroup(null);
                }
                appsensePortMaster = (AppsensePortMaster) getSession().get(AppsensePortMaster.class,
                        getSession().save(apsPortMaster));
            }
            if (appsensePortMaster == null) {
                throw new ApplicationException("There was a problem in storing the appsense Port master record");
            }
        } catch (ApplicationException e) {
            LOGGER.error("ApplicationException in storeAppsensePortMaster :" + e);
            LOGGER.error(e.toString(), e);
            throw e;
        } catch (Exception e) {
            LOGGER.error("Exception in storeAppsensePortMaster :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(" There was an exception while storing Aps port Master record");
        }
        return appsensePortMaster;
    }

    /**
     * Store ip master.
     * 
     * @param ipMaster
     *            the ip master
     * @return the connection ip master
     */
    private ConnectionIPMaster storeIPMaster(ConnectionIPMaster ipMaster) {
        LOGGER.info("ipMaster.getIpAddress() :" + ipMaster.getIpAddress());
        AppsenseUtil appsenseUtil = new AppsenseUtil();
        ipMaster = appsenseUtil.formatIPAddress(ipMaster);
        ConnectionIPMaster connectionIPMaster = null;
        try {
            connectionIPMaster = findIPMaster(ipMaster);
            if (connectionIPMaster == null) {
                ipMaster.setCreated_date(new Date());
                ipMaster.setTemplateFlag("N");
                connectionIPMaster = (ConnectionIPMaster) getSession().get(ConnectionIPMaster.class,
                        getSession().save(ipMaster));
            }
            if (connectionIPMaster == null) {
                throw new ApplicationException("There was a problem in storing the appsense IP master record");
            }
        } catch (ApplicationException e) {
            LOGGER.error("ApplicationException in storeIPMaster :" + e);
            LOGGER.error(e.toString(), e);
            throw e;
        } catch (Exception e) {
            LOGGER.error("Exception in storeIPMaster :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(" There was an exception while storing IP Master record for IP:"
                    + ipMaster.getIpAddress());
        }
        return connectionIPMaster;
    }

    /**
     * Store port lookup.
     * 
     * @param portLookup
     *            the port lookup
     * @return the connection port look up
     */
    private Port storePortLookup(Port portLookup) {
        Port Port = null;
        try {
            if (portLookup == null || !(portLookup instanceof Port)) {
                throw new ApplicationException("The received object is either NULL or it is not of required type Port");
            }
            if (portLookup.getPortNumber() == null || portLookup.getProtocol() == null) {
                throw new ApplicationException("Missing required attribute in Con Port Lookup object. Please verify.");
            }
            LOGGER.info("portLookup.getPortNumber() :" + portLookup.getPortNumber());
            if (portLookup.getFlowOfData() == null) {
                portLookup.setFlowOfData("Endpoint A -> Endpoint B");
            }
            portLookup.setCreated_date(new Date());
            // portLookup.setUpdated_date(new Date());
            portLookup.setIsRiskport("N");
            portLookup.setBiDirectional("N");
            Port = findPortLookup(portLookup.getPortNumber(), portLookup.getProtocol(), portLookup.getFlowOfData());
            if (Port == null) {
                Port = (Port) getSession().get(Port.class, getSession().save(portLookup));
            }
            if (Port == null) {
                throw new ApplicationException("There was a problem in storing the appsense Port Lookup record");
            }
        } catch (ApplicationException e) {
            LOGGER.error("ApplicationException in storePortLookup :" + e);
            LOGGER.error(e.toString(), e);
            throw e;
        } catch (Exception e) {
            LOGGER.error("Exception in storePortLookup :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(" There was an exception while storing port lookup record for :"
                    + portLookup.getPortNumber());
        }
        return Port;
    }

    /**
     * Delete all appsense applications.
     * 
     * @param apsProcess
     *            the aps process
     */
    private void deleteAllAppsenseApplications(AppsenseDTO apsProcess) {
        LOGGER.info("apsProcess.getId() :" + apsProcess.getId());
        StringBuffer nonSelectedAppApplication = new StringBuffer();
        String appsenseDeleteQuery = "delete AppsenseApplication ap where ap.tiProcess.id=? and ap.recordType=? ";
        int count = 0;
        try {
            if (!apsProcess.isSelectAll()) {
                throw new ApplicationException(
                        " The selectAll property in appsense process MUST be set to true if you want to delete all appsense applications in the appsense Process");
            }
            List<AppsenseApplication> appsenseApplicationList = apsProcess.getAppsenseApplicationList();
            Iterator<AppsenseApplication> appsenseApplicationListIter = appsenseApplicationList.iterator();
            AppsenseApplication appsenseApplication;
            while (appsenseApplicationListIter.hasNext()) {
                appsenseApplication = (AppsenseApplication) appsenseApplicationListIter.next();
                if (!appsenseApplication.isSelected()) {
                    if (count > 0)
                        nonSelectedAppApplication.append(",");
                    nonSelectedAppApplication.append(appsenseApplication.getId());
                    count++;
                }
                LOGGER.debug("ManageAppsenseImpl:deleteAllAppsenseApplications: Appsense Application Non deleted Application's ID:"
                        + nonSelectedAppApplication);

            }

            if (count > 0) {
                appsenseDeleteQuery = appsenseDeleteQuery + " and ap.id not in(" + nonSelectedAppApplication.toString()
                        + ")";
            }
            Query q = getSession().createQuery(appsenseDeleteQuery).setLong(0, apsProcess.getId().longValue())
                    .setString(1, "A");
            int noRecordsDeleted = q.executeUpdate();
            LOGGER.debug("ManageAppsenseImpl:deleteAllAppsenseApplications: Process Id: " + apsProcess.getId()
                    + " Deleted TOTAL no. of records:" + noRecordsDeleted);
        } catch (ApplicationException e) {
            LOGGER.error("ApplicationException in deleteAllAppsenseApplications :" + e);
            LOGGER.error(e.toString(), e);
            throw e;
        } catch (Exception e) {
            LOGGER.error("Exception in deleteAllAppsenseApplications :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(" There was an exception in deleteAllAppsenseApplications method:"
                    + apsProcess.getId());
        }
    }

    /**
     * Delete all appsense users.
     * 
     * @param apsProcess
     *            the aps process
     */
    private void deleteAllAppsenseUsers(AppsenseDTO apsProcess) {
        LOGGER.info("apsProcess.getId() :" + apsProcess.getId());
        StringBuffer nonSelectedAppUser = new StringBuffer();
        String appsenseDeleteQuery = "delete AppsenseUser au where au.tiProcess.id=? and au.recordType=? ";
        int count = 0;
        try {
            if (!apsProcess.isSelectAll()) {
                throw new ApplicationException(
                        " The selectAll property in appsense process MUST be set to true if you want to delete all appsense users in the appsense Process");
            }
            List<AppsenseUser> appsenseUserList = apsProcess.getAppsenseUserList();
            Iterator<AppsenseUser> appsenseUserListIter = appsenseUserList.iterator();
            AppsenseUser appsenseUser;
            while (appsenseUserListIter.hasNext()) {
                appsenseUser = (AppsenseUser) appsenseUserListIter.next();
                if (!appsenseUser.isSelected()) {
                    if (count > 0)
                        nonSelectedAppUser.append(",");
                    nonSelectedAppUser.append(appsenseUser.getId());
                    count++;
                }
                LOGGER.debug("nonSelectedAppUser :" + nonSelectedAppUser);

            }

            if (count > 0) {
                appsenseDeleteQuery = appsenseDeleteQuery + " and au.id not in(" + nonSelectedAppUser.toString() + ")";
            }

            Query q = getSession().createQuery(appsenseDeleteQuery).setLong(0, apsProcess.getId().longValue())
                    .setString(1, "U");
            int noRecordsDeleted = q.executeUpdate();
            LOGGER.debug("Process Id: " + apsProcess.getId() + " Deleted TOTAL no. of records:" + noRecordsDeleted);
        } catch (ApplicationException e) {
            LOGGER.error("ApplicationException in deleteAllAppsenseUsers :" + e);
            LOGGER.error(e.toString(), e);
            throw e;
        } catch (Exception e) {
            LOGGER.error("Exception in deleteAllAppsenseUsers :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(" There was an exception in deleteAllAppsenseUsers method:"
                    + apsProcess.getId());
        }
    }

    /**
     * Gets the technical architecture util.
     * 
     * @return the technical architecture util
     */
    public TechnicalArchitectureUtil getTechnicalArchitectureUtil() {
        return technicalArchitectureUtil;
    }

    /**
     * Sets the technical architecture util.
     * 
     * @param technicalArchitectureUtil
     *            the new technical architecture util
     */
    public void setTechnicalArchitectureUtil(TechnicalArchitectureUtil technicalArchitectureUtil) {
        this.technicalArchitectureUtil = technicalArchitectureUtil;
    }

    public CCRQueries getCcrQueries() {
        return ccrQueries;
    }

    public void setCcrQueries(CCRQueries ccrQueries) {
        this.ccrQueries = ccrQueries;
    }

    // ALL the methods above this line will be made private; ONLY Below methods
    // would be available for usage
    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.appsense.domain.logic.AppsensePersistable#
     * getAppsenseProcess(long)
     */
    @Override
    @Transactional(readOnly = true)
    public AppsenseDTO getAppsenseProcess(long processId) {
        LOGGER.info("Process id:" + processId);
        AppsenseDTO apsProcess = new AppsenseDTO();
        try {
            HashMap processData = (HashMap) technicalArchitectureUtil.getAppsenseProcessData(processId);
            apsProcess.setAppsensePolicyName((String) processData.get("POLICY_NAME"));
            apsProcess.setResourceType((String) processData.get("RESOURCE_TYPE"));
            if (processData.get("RELATIONSHIP_TYPE") != null) {
                apsProcess.setRelationshipType((String) processData.get("RELATIONSHIP_TYPE"));
            } else {
                apsProcess.setRelationshipType("THIRD_PARTY");
            }
            LOGGER.debug("Relationship Type :: " + apsProcess.getRelationshipType());
            apsProcess.setId(Long.valueOf(processId));
        } catch (ApplicationException e) {
            LOGGER.error("ApplicationException in getAppsenseProcess :" + e);
            LOGGER.error(e.toString(), e);
            throw e;
        } catch (Exception e) {
            LOGGER.error("Exception in getAppsenseProcess :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(" There was an exception while getting process with id:" + processId);
        }
        return apsProcess;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.appsense.domain.logic.AppsensePersistable#
     * loadAppsenseApplications
     * (com.citigroup.cgti.c3par.appsense.domain.AppsenseProcess, int)
     */
    @Override
    @Transactional(readOnly = true)
    public List loadAppsenseApplications(AppsenseDTO apsProcess, ManageAppsenseProcess manageAppsenseProcess) {
        List appList = getAppsenseApplicationList(apsProcess.getId(), manageAppsenseProcess);
        int totalRecords = getTotalNumber(apsProcess.getId().longValue(), "A");
        apsProcess.setTotalAppsenseApps(totalRecords);
        apsProcess.setAppsenseApplicationList(appList);
        return appList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.appsense.domain.logic.AppsensePersistable#
     * loadAppsenseApplications
     * (com.citigroup.cgti.c3par.appsense.domain.AppsenseProcess, int, int)
     */
    @Override
    @Transactional(readOnly = true)
    public List loadAppsenseApplications(AppsenseDTO apsProcess, int pageNum, int pageSize) {
        List appsList = apsProcess.getAppsenseApplicationList();
        List<AppsenseApplication> returnList = null;
        if (appsList != null && appsList.size() > ((pageNum - 1) * pageSize)) {
            if (appsList.size() > (pageNum * pageSize)) {
                returnList = appsList.subList(((pageNum - 1) * pageSize), pageNum * pageSize);
            } else {
                returnList = appsList.subList(((pageNum - 1) * pageSize), appsList.size());
            }
            for (AppsenseApplication appsenseApplication : returnList) {
                appsenseApplication.setAlreadyAccessed(true);
            }
        } else {
            // returnList=getAppsenseApplicationList(apsProcess.getId(),pageNum,pageSize);
            appsList.addAll(returnList);
            apsProcess.setAppsenseApplicationList(appsList);
        }
        return returnList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.appsense.domain.logic.AppsensePersistable#
     * loadAppsenseOstiaApplications
     * (com.citigroup.cgti.c3par.appsense.domain.AppsenseProcess, int, int)
     */
    @Override
    @Transactional(readOnly = true)
    public List loadAppsenseOstiaApplications(AppsenseDTO apsProcess, ManageAppsenseProcess manageAppsenseProcess) {
        List<AppsenseApplication> returnList = null;
        returnList = getAppsenseOstiaApplicationList(apsProcess.getId(), manageAppsenseProcess);
        return returnList;
    }

    // Ostia Ends
    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.appsense.domain.logic.AppsensePersistable#
     * loadAppsenseUsers
     * (com.citigroup.cgti.c3par.appsense.domain.AppsenseProcess, int)
     */
    @Override
    @Transactional(readOnly = true)
    public List loadAppsenseUsers(AppsenseDTO apsProcess, ManageAppsenseProcess manageAppsenseProcess) {
        List userList = getAppsenseUserList(apsProcess.getId(), manageAppsenseProcess);
        return userList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.appsense.domain.logic.AppsensePersistable#
     * storeAppsenseApplication
     * (com.citigroup.cgti.c3par.appsense.domain.AppsenseApplication)
     */
    @Override
    public void storeAppsenseApplication(AppsenseApplication appsenseApplication) {
        if (appsenseApplication == null || !(appsenseApplication instanceof AppsenseApplication)) {
            throw new ApplicationException("The received object is not of required type AppsenseApplication");
        }
        if (appsenseApplication.getTiProcess() == null || appsenseApplication.getTiProcess().getId() == null) {
            throw new ApplicationException("The TIProcess object MUST be initialized inside AppsenseApplication object");
        }
        if (appsenseApplication.getTiRequest() == null || appsenseApplication.getTiRequest().getId() == null) {
            throw new ApplicationException("The TiRequest object MUST be initialized inside AppsenseApplication object");
        }
        try {
            Long id = null;
            if (appsenseApplication != null) {
                if (appsenseApplication.getApplication() != null) {
                    LOGGER.info("ApplicationName() :" + appsenseApplication.getApplication().getApplicationName());
                    Application application = storeApplication(appsenseApplication.getApplication());
                    appsenseApplication.setApplication(application);
                    appsenseApplication.setCreated_date(new Date());
                    if (appsenseApplication.getPortUnblock() != null
                            && "Y".equalsIgnoreCase(appsenseApplication.getPortUnblock())) {
                        AppsensePortMaster portMaster = appsenseApplication.getApsPortMaster();
                        if (portMaster.getConnectionIPMaster() != null
                                && "MULTIPLE".equals(portMaster.getConnectionIPMaster().getUserInputType())) {
                            String startIP = portMaster.getConnectionIPMaster().getStartIPAddress();
                            String endIP = portMaster.getConnectionIPMaster().getEndIPAddress();
                            String singleIP = startIP + "-" + endIP;
                            AppsensePortMaster temp = new AppsensePortMaster();
                            ConnectionIPMaster tempIPMaster = new ConnectionIPMaster();
                            tempIPMaster.setUserInputType("SINGLE");
                            tempIPMaster.setIpAddress(singleIP);
                            temp.setConnectionIPMaster(tempIPMaster);
                            temp.setPortLookUp(portMaster.getPortLookUp());
                            temp.setConOstiaGroup(portMaster.getConOstiaGroup());
                            AppsensePortMaster apsPortMaster = storeAppsensePortMaster(temp);
                            appsenseApplication.setApsPortMaster(apsPortMaster);
                            AppsenseApplication existingApp = findAppsenseApplication(appsenseApplication);
                            if (existingApp != null) {
                                throw new ApplicationException("Duplicates not Allowed!");
                            } else {
                                id = (Long) getSession().save(appsenseApplication);
                            }
                            getSession().flush();
                            getSession().clear();
                            LOGGER.info("Successfully Stored the AppsenseApplication object with id:" + id);
                        } else {
                            AppsensePortMaster apsPortMaster = storeAppsensePortMaster(portMaster);
                            appsenseApplication.setApsPortMaster(apsPortMaster);
                            AppsenseApplication existingApp = findAppsenseApplication(appsenseApplication);
                            if (existingApp != null) {
                                throw new ApplicationException("Duplicates not Allowed!");
                            } else {
                                id = (Long) getSession().save(appsenseApplication);
                            }
                            LOGGER.info("Successfully Stored the AppsenseApplication object with id:" + id);
                        }
                    } else {
                        appsenseApplication.setApsPortMaster(null);
                        AppsenseApplication existingApp = findAppsenseApplication(appsenseApplication);
                        if (existingApp != null) {
                            throw new ApplicationException("Duplicates not Allowed!");
                        } else {
                            id = (Long) getSession().save(appsenseApplication);
                        }
                        LOGGER.info("Successfully Stored the AppsenseApplication object with id:" + id);
                    }
                } else {
                    throw new ApplicationException(
                            "The AppsenseApplication object MUST contain Application object. It can not be NULL.");
                }
            }
        } catch (ApplicationException e) {
            LOGGER.error("ApplicationException in storeAppsenseApplication :" + e);
            LOGGER.error(e.toString(), e);
            throw e;
        } catch (Exception e) {
            LOGGER.error("Exception in storeAppsenseApplication :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(" There was an exception while storing Appsense Application Record:"
                    + appsenseApplication.getApplication().getApplicationName());
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.appsense.domain.logic.AppsensePersistable#
     * storeAppsenseUser(com.citigroup.cgti.c3par.appsense.domain.AppsenseUser)
     */
    @Override
    public void storeAppsenseUser(AppsenseUser appsenseUser) {
        if (appsenseUser == null || !(appsenseUser instanceof AppsenseUser)) {
            throw new ApplicationException("The received object is not of required type AppsenseUser");
        }
        if (appsenseUser.getTiProcess() == null || appsenseUser.getTiProcess().getId() == null) {
            throw new ApplicationException("The TIProcess object MUST be initialized inside AppsenseUser object");
        }
        if (appsenseUser.getTiRequest() == null || appsenseUser.getTiRequest().getId() == null) {
            throw new ApplicationException("The TiRequest object MUST be initialized inside AppsenseUser object");
        }
        try {
            Long id = null;
            if (appsenseUser != null) {
                if (appsenseUser.getCitiContact() != null) {
                    LOGGER.info("appsenseUser.getCitiContact().getSsoId() :" + appsenseUser.getCitiContact().getSsoId());
                    CitiContact cc = storeCitiContact(appsenseUser.getCitiContact());
                    appsenseUser.setCitiContact(cc);
                    appsenseUser.setCreated_date(new Date());
                    AppsenseUser existingUsr = findAppsenseUser(appsenseUser);
                    if (existingUsr != null) {
                        throw new ApplicationException("Duplicates not Allowed!");
                    } else {
                        if (appsenseUser.getDevAccess() != null && appsenseUser.getPrdAccess() != null) {
                            if (appsenseUser.getDevAccess().equalsIgnoreCase("N")
                                    && appsenseUser.getPrdAccess().equalsIgnoreCase("N")) {
                                throw new ApplicationException(
                                        "The AppsenseUser Dev Access and Prd Access cannot have No Access Value");
                            } else {
                                id = (Long) getSession().save(appsenseUser);
                            }
                        }
                    }
                    LOGGER.info("Successfully Stored the AppsenseApplication object with id:" + id);
                } else {
                    throw new ApplicationException(
                            "The AppsenseUser object MUST contain CitiContact object. It can not be NULL.");
                }
            }

        } catch (ApplicationException e) {
            LOGGER.error("ApplicationException in storeAppsenseUser :" + e);
            LOGGER.error(e.toString(), e);
            throw e;
        } catch (Exception e) {
            LOGGER.error("Exception in storeAppsenseUser :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(" There was an exception while storing Appsense User Record:"
                    + appsenseUser.getCitiContact().getSsoId());
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.appsense.domain.logic.AppsensePersistable#
     * deleteAppsenseApplication
     * (com.citigroup.cgti.c3par.appsense.domain.AppsenseProcess)
     */
    @Override
    public void deleteAppsenseApplication(AppsenseDTO apsProcess) {
        LOGGER.info("PolicyName :" + apsProcess.getAppsensePolicyName());
        try {
            List<AppsenseApplication> appsenseAppList = apsProcess.getAppsenseApplicationList();
            Boolean isComboAlreadyExists = false;
            Boolean isApplicationDecommissioned = false;
            Long qualityScoreId = 0l;

            if (appsenseAppList != null && appsenseAppList.size() > 0) {
                for (AppsenseApplication app : appsenseAppList) {
                    if (app.isSelected()) {
                        app = (AppsenseApplication) getSession().get(AppsenseApplication.class, app.getId());
                        if (app != null && app.getTiProcess() != null && app.getTiProcess().getId() != null
                                && app != null && app.getApplication() != null
                                && app.getApplication().getApplicationID() != null) {
                            isComboAlreadyExists = false;
                            isApplicationDecommissioned = false;
                            isComboAlreadyExists = csiQualityScoreUpdateService.checkIfComboAlreadyExists(app
                                    .getTiProcess().getId(), String.valueOf(app.getApplication().getApplicationID()),
                                    "APPSENSE");
                            isApplicationDecommissioned = csiQualityScoreUpdateService
                                    .checkIfApplicationIsDecommissioned(String.valueOf(app.getApplication()
                                            .getApplicationID()));
                            if (isComboAlreadyExists && isApplicationDecommissioned) {
                                qualityScoreId = csiQualityScoreUpdateService.getCSIQualityScore(app.getTiProcess()
                                        .getId(), String.valueOf(app.getApplication().getApplicationID()), "APPSENSE");
                                qualityScoreDaoService.updateQualityScore(qualityScoreId);
                            }
                        }
                    }
                }
            }

            if (appsenseAppList != null && appsenseAppList.size() > 0) {
                for (AppsenseApplication app : appsenseAppList) {
                    if (app.isSelected()) {
                        app = (AppsenseApplication) getSession().get(AppsenseApplication.class, app.getId());
                        getSession().delete(app);
                    }
                }
            }
        } catch (ApplicationException e) {
            LOGGER.error("ApplicationException in deleteAppsenseApplication :" + e);
            LOGGER.error(e.toString(), e);
            throw e;
        } catch (Exception e) {
            LOGGER.error("Exception in deleteAppsenseApplication :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(" There was an exception while deleting Appsense Application Record:"
                    + apsProcess.getAppsensePolicyName());
        }
        LOGGER.info("ManageAppsenseImpl:deleteAppsenseApplication: Exiting with Policy:"
                + apsProcess.getAppsensePolicyName());
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.appsense.domain.logic.AppsensePersistable#
     * deleteAppsenseUser
     * (com.citigroup.cgti.c3par.appsense.domain.AppsenseProcess)
     */
    @Override
    public void deleteAppsenseUser(AppsenseDTO apsProcess) {
        LOGGER.info("PolicyName :" + apsProcess.getAppsensePolicyName());
        try {
            List<AppsenseUser> appsenseUserList = apsProcess.getAppsenseUserList();

            if (appsenseUserList != null && appsenseUserList.size() > 0) {
                for (AppsenseUser appsenseUser : appsenseUserList) {
                    if (appsenseUser.isSelected()) {
                        appsenseUser = (AppsenseUser) getSession().get(AppsenseUser.class, appsenseUser.getId());
                        getSession().delete(appsenseUser);
                    }
                }
            }

        } catch (ApplicationException e) {
            LOGGER.error("ApplicationException in deleteAppsenseUser :" + e);
            LOGGER.error(e.toString(), e);
            throw e;
        } catch (Exception e) {
            LOGGER.error("Exception in deleteAppsenseUser :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(" There was an exception while deleting Appsense User Record:"
                    + apsProcess.getAppsensePolicyName());
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.appsense.domain.logic.AppsensePersistable#
     * getApsNonNetworkCombination(java.lang.Long, java.lang.Long,
     * java.lang.Long, java.lang.Long)
     */
    @Override
    @Transactional(readOnly = true)
    public AppsenseAAFCombination getApsNonNetworkCombination(Long processID, Long versionID, Long combType,
            Long fafType) {
        AppsenseAAFCombination apsAAFComb = new AppsenseAAFCombination();
        apsAAFComb.setNonNetworkApps(getApsNonNetworkCombFilter(processID, versionID, combType, fafType));
        apsAAFComb.setCombinationType(combType);
        apsAAFComb.setFafType(fafType);
        return apsAAFComb;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.appsense.domain.logic.AppsensePersistable#
     * getApsUserCombination(java.lang.Long, java.lang.Long, java.lang.Long,
     * java.lang.Long)
     */
    @Override
    @Transactional(readOnly = true)
    public AppsenseAAFCombination getApsUserCombination(Long processID, Long versionID, Long combType, Long fafType) {
        AppsenseAAFCombination apsAAFComb = new AppsenseAAFCombination();
        apsAAFComb.setApsUsers(getApsUserCombFilter(processID, versionID, combType, fafType));
        apsAAFComb.setCombinationType(combType);
        apsAAFComb.setFafType(fafType);
        return apsAAFComb;
    }

    /**
     * Gets the aps non network comb filter.
     * 
     * @param processID
     *            the process id
     * @param versionID
     *            the version id
     * @param combType
     *            the comb type
     * @param fafType
     *            the faf type
     * @return the aps non network comb filter
     */
    private List getApsNonNetworkCombFilter(Long processID, Long versionID, Long combType, Long fafType) {
        List nonNetworkApps = new ArrayList();
        List nonNetworkAppsList = new ArrayList();
        AppsenseAAFCombination appsAAFComb = new AppsenseAAFCombination();
        try {
            Query q = getSession()
                    .createQuery(
                            "select distinct application from  AppsenseAAFCombination as aih left join aih.apsApplication as application"
                                    + " where aih.processId=? and aih.combinationType=? and aih.fafType=1 and aih.versionId =?")
                    .setLong(0, processID.longValue()).setLong(1, combType.longValue())
                    .setLong(2, versionID.longValue());
            nonNetworkApps = q.list();
            if (nonNetworkApps != null && nonNetworkApps.size() > 0) {
                appsAAFComb.setNonNetworkApps(nonNetworkApps);
                appsAAFComb.setCombinationType(combType);
                appsAAFComb.setFafType(fafType);
                LOGGER.info("Non Network Apps::: " + nonNetworkApps.size());
            } else {
                LOGGER.info("No Records Found");
            }
        } catch (Exception e) {
            LOGGER.error("Exception in getApsNonNetworkCombFilter :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(" There was an exception while finding Appsense Combination details");
        }
        nonNetworkAppsList.add(appsAAFComb);
        return nonNetworkAppsList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.appsense.domain.logic.AppsensePersistable#
     * getApsNetworkCombFilter(java.lang.Long, java.lang.Long, java.lang.Long,
     * java.lang.Long)
     */
    @Override
    @Transactional(readOnly = true)
    public List getApsNetworkCombFilter(Long processID, Long versionID, Long combType, Long fafType) {
        List networkApps = new ArrayList();
        AppsenseAAFCombination appsAAFComb = null;
        List applIds = new ArrayList();
        List combineList = new ArrayList();
        Query q = null;

        try {
            q = getSession()
                    .createQuery(
                            "select distinct application from  AppsenseAAFCombination as aih left join aih.apsApplication as application"
                                    + " where aih.processId=? and aih.combinationType=? and aih.fafType=2 and aih.versionId =?")
                    .setLong(0, processID.longValue()).setLong(1, combType.longValue())
                    .setLong(2, versionID.longValue());
            applIds = q.list();
            if (applIds != null && applIds.size() > 0) {
                int networkCount = 1;
                Iterator appsAppsIter = applIds.iterator();
                while (appsAppsIter.hasNext()) {
                    appsAAFComb = new AppsenseAAFCombination();
                    Application appl = (Application) appsAppsIter.next();
                    appsAAFComb.setApsApplication(appl);
                    appsAAFComb.setNetworkDetailCount(networkCount);
                    if (appl.getId() != null) {
                        q = getSession()
                                .createQuery(
                                        "select distinct appsensePortMaster from AppsenseAAFCombination as aih left join "
                                                + " aih.apsPortMaster as appsensePortMaster "
                                                + " where aih.processId=? and aih.combinationType=? and aih.fafType=2 and "
                                                + " aih.versionId =? and aih.apsApplication=?")
                                .setLong(0, processID.longValue()).setLong(1, combType.longValue())
                                .setLong(2, versionID.longValue()).setLong(3, appl.getId().longValue());
                        networkApps = q.list();
                    }
                    if (networkApps.size() > 0) {
                        LOGGER.info("networkApps:: " + networkApps.size());
                        appsAAFComb.setApsPorts(networkApps);
                    }
                    appsAAFComb.setCombinationType(combType);
                    appsAAFComb.setFafType(fafType);
                    combineList.add(appsAAFComb);
                    networkCount++;
                }

            } else {
                LOGGER.info("No Records Found");
                appsAAFComb = new AppsenseAAFCombination();
                appsAAFComb.setCombinationType(combType);
                appsAAFComb.setFafType(fafType);
                combineList.add(appsAAFComb);
            }
        } catch (Exception e) {
            LOGGER.error("Exception in getApsNetworkCombFilter :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException("There was an exception while finding appsense combination details");
        }
        return combineList;
    }

    /**
     * Gets the aps user comb filter.
     * 
     * @param processID
     *            the process id
     * @param versionID
     *            the version id
     * @param combType
     *            the comb type
     * @param fafType
     *            the faf type
     * @return the aps user comb filter
     */

    private List getApsUserCombFilter(Long processID, Long versionID, Long combType, Long fafType) {
        List dataList = new ArrayList();
        List apsUserList = new ArrayList();
        List apsCitiContactList = new ArrayList();
        AppsenseAAFCombination appsAAFComb = new AppsenseAAFCombination();
        try {
            Query q = getSession()
                    .createQuery(
                            "select distinct citiContact,aih.devAccess,aih.prdAccess,aih.crossEnvironmentAccess,aih.localFolderAccess from AppsenseAAFCombination as aih left join aih.citiContact as citiContact"
                                    + " where aih.processId=? and aih.combinationType=? and aih.fafType=3 and aih.versionId =?")
                    .setLong(0, processID.longValue()).setLong(1, combType.longValue())
                    .setLong(2, versionID.longValue());
            dataList = q.list();
            if (dataList != null && dataList.size() > 0) {
                LOGGER.info("Size :: " + dataList.size());
                for (int i = 0; i < dataList.size(); i++) {
                    Object[] obj = (Object[]) dataList.get(i);
                    if (obj != null) {
                        CitiContact citiContactUser = new CitiContact();
                        citiContactUser = (CitiContact) obj[0];
                        citiContactUser.setDevAccess((String) obj[1]);
                        citiContactUser.setPrdAccess((String) obj[2]);
                        citiContactUser.setCrossEnvironmentAccess((String) obj[3]);
                        citiContactUser.setLocalFolderAccess((String) obj[4]);
                        apsCitiContactList.add(citiContactUser);
                    }
                }
                appsAAFComb.setApsUsers(apsCitiContactList);
                appsAAFComb.setFafType(fafType);
                appsAAFComb.setCombinationType(combType);
            } else {
                LOGGER.info("No Records Found");
            }
        } catch (Exception e) {
            LOGGER.error("Exception in getApsUserCombFilter :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException("There was an exception while finding appsense combination details");
        }
        apsUserList.add(appsAAFComb);
        return apsUserList;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.appsense.domain.logic.AppsensePersistable#
     * getAppsenseOstiaPortList
     * (com.citigroup.cgti.c3par.appsense.domain.AppsenseProcess)
     */
    @Override
    @Transactional(readOnly = true)
    public List getAppsenseOstiaPortList(AppsenseDTO apsProcess) {
        List ostiaPortlist = new ArrayList();
        try {
            Criteria crit = getSession().createCriteria(AppsenseApplication.class);
            crit.createAlias("apsPortMaster", "apsPortMaster");
            TIProcess tiProcess = getTIProcessById(apsProcess.getId().longValue());
            crit.add(Restrictions.eq("tiProcess", tiProcess));
            crit.add(Restrictions.eq("recordType", "A"));
            crit.add(Restrictions.isNotNull("apsPortMaster"));
            crit.add(Restrictions.isNull("apsPortMaster.conOstiaGroup"));
            ostiaPortlist = crit.list();
        } catch (Exception e) {
            LOGGER.error("Exception in getAppsenseOstiaPortList :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(" There was an exception while getting application list ");
        }
        return ostiaPortlist;
    }

    // Added for 3908

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.appsense.domain.logic.AppsensePersistable#
     * storeAppsADGroup
     * (com.citigroup.cgti.c3par.appsense.domain.AppsenseADGroup)
     */
    @Override
    public AppsenseADGroup storeAppsADGroup(AppsenseADGroup appsenseADGroup) {
        if (appsenseADGroup == null || !(appsenseADGroup instanceof AppsenseADGroup)) {
            throw new ApplicationException("The received object is not of required type Appsense AD Group Name");
        }
        Long id = null;
        try {
            if (appsenseADGroup != null) {
                appsenseADGroup.setIsNew("Y");
                appsenseADGroup.setCreated_date(new Date());
                id = (Long) getSession().save(appsenseADGroup);
                LOGGER.info("Successfully Stored the Appsense AD Group Name object with id:" + id);
                appsenseADGroup.setId(id);
            } else {
                throw new ApplicationException(
                        "The AppsenseUser object MUST contain Appsense AD Group Name. It can not be NULL.");
            }
        } catch (ApplicationException e) {
            LOGGER.error("ApplicationException in storeAppsADGroup :" + e);
            LOGGER.error(e.toString(), e);
            throw e;
        } catch (Exception e) {
            LOGGER.error("Exception in storeAppsADGroup :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(" There was an exception while storing Appsense User Record:"
                    + appsenseADGroup.getName());
        }
        return appsenseADGroup;
    }

    /*
     * (non-Javadoc)
     * 
     * @see com.citigroup.cgti.c3par.appsense.domain.logic.AppsensePersistable#
     * updateAppsADGroup
     * (com.citigroup.cgti.c3par.appsense.domain.AppsenseADGroup)
     */
    @Override
    public AppsenseADGroup updateAppsADGroup(AppsenseADGroup appsenseADGroup) {
        if (appsenseADGroup == null || !(appsenseADGroup instanceof AppsenseADGroup)) {
            throw new ApplicationException("The received object is not of required type Appsense AD Group Name");
        }
        try {
            if (appsenseADGroup != null && appsenseADGroup.getName() != null) {
                String adGroupUpdateQuery = null;
                Query q = null;
                if (appsenseADGroup.getId() != null && appsenseADGroup.getName() != null) {
                    /*
                     * appsenseADGroup.setUpdated_date(new Date());
                     * getSession().update(appsenseADGroup);
                     */
                    adGroupUpdateQuery = " update AppsenseADGroup set name=?,updated_date=?,policy_name=?,policy_id=? where id= ?";
                    q = getSession().createQuery(adGroupUpdateQuery).setString(0, appsenseADGroup.getName())
                            .setDate(1, new Date()).setString(2, appsenseADGroup.getPolicyName())
                            .setString(3, appsenseADGroup.getPolicyID())
                            .setLong(4, appsenseADGroup.getId().longValue());
                }
                int noRecordsUpdated = q.executeUpdate();
                LOGGER.info("No of records inserted successfully:: " + noRecordsUpdated);
                // appsenseADGroup.setUpdated_date(new Date());
                // this.getSession().saveOrUpdate(appsenseADGroup);
            } else {
                throw new ApplicationException(
                        "The AppsenseUser object MUST contain Appsense AD Group Name. It can not be NULL.");
            }
        } catch (ApplicationException e) {
            LOGGER.error("ApplicationException in updateAppsADGroup :" + e);
            LOGGER.error(e.toString(), e);
            throw e;
        } catch (Exception e) {
            LOGGER.error("Exception in updateAppsADGroup :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException(" There was an exception while storing Appsense User Record:"
                    + appsenseADGroup.getName());
        }
        return appsenseADGroup;
    }

    public AppsenseDTO addOstiaAnswers(AppsenseDTO apsProcess, Long groupId) {
        Session session = getSession();
        try {
            List<AppsenseApplication> apsList = new ArrayList<AppsenseApplication>();

            List<Long> apsPortList = new ArrayList<Long>();
            List<AppsenseApplication> appsenseApplicationList = apsProcess.getAppsenseApplicationList();

            if (appsenseApplicationList != null && appsenseApplicationList.size() > 0) {

                for (AppsenseApplication appsenseApplication : appsenseApplicationList) {
                    appsenseApplication = (AppsenseApplication) getSession().get(AppsenseApplication.class,
                            appsenseApplication.getId());
                    apsList.add(appsenseApplication);
                    AppsensePortMaster apsPortMaster = appsenseApplication.getApsPortMaster();
                    if (apsPortMaster.getId() != null) {
                        apsPortList.add(apsPortMaster.getId());
                    }

                }
            }

            SQLQuery sqlQuery = session.createSQLQuery("UPDATE C3PAR.APS_PORT_MASTER SET OSTIA_GROUP_ID=" + groupId
                    + " WHERE ID IN(" + AppsenseUtil.listToString(apsPortList, false) + ")");
            LOGGER.debug("UPDATE C3PAR.APS_PORT_MASTER Query::" + sqlQuery);
            sqlQuery.executeUpdate();

        } catch (Exception e) {
            LOGGER.error("Exception in addOstiaAnswers :" + e);
            LOGGER.error(e.toString(), e);
            if (e instanceof BusinessException) {
                throw new BusinessException(e.getMessage());
            } else {
                throw new ApplicationException(e.getMessage());
            }
        }
        return apsProcess;

    }

    @Override
    @Transactional(readOnly = true)
    public ConnectionOstiaGroup getOstiaGroup(Long ostiaGroupId) {
        ConnectionOstiaGroup ostiaGroup = null;
        Session session = getSession();

        try {
            ostiaGroup = (ConnectionOstiaGroup) getSession().createQuery("from ConnectionOstiaGroup os where os.id=?")
                    .setLong(0, ostiaGroupId).uniqueResult();
        } catch (Exception e) {
            LOGGER.error("Exception in getOstiaGroup :" + e);
            LOGGER.error(e.toString(), e);
            throw new ApplicationException("Ostia Group with group id " + ostiaGroupId.toString() + " not found");
        }
        return ostiaGroup;

    }

    @Override
    public AppsenseDTO updateOstiaGroup(AppsenseDTO appsenseProcess, ConnectionOstiaGroup conOstiaGroup) {
        LOGGER.debug("updateOstiaGroup::: " + conOstiaGroup);
        Session session = getSession();
        try {
            session.update(conOstiaGroup);
            LOGGER.debug("Status of conOstiaGroup :" + conOstiaGroup.getStatus());
        } catch (Exception e) {
            LOGGER.error("Exception in updateOstiaGroup :" + e);
            LOGGER.error(e.toString(), e);
            if (e instanceof BusinessException) {
                throw new BusinessException(e.getMessage());
            } else {
                throw new ApplicationException(e.getMessage());
            }
        }
        return appsenseProcess;
    }

    @Override
    @Transactional(readOnly = true)
    public List<GenericLookup> getDeviceTypes() {
        Session session = getSession();
        List<GenericLookup> list = (List<GenericLookup>) session.createQuery(
                "from com.citigroup.cgti.c3par.common.domain.GenericLookup gen where gen.isDeleted = 'N' and gen.genericLookupDef.id="
                        + getDefinitionId("Operating System")).list();

        return list;

    }

    private Long getDefinitionId(String defName) {
        Session session = getSession();
        GenericLookupDef res = (GenericLookupDef) session.createQuery(
                "from GenericLookupDef def where upper(def.name)=upper('" + defName + "')").uniqueResult();

        return res.getId();

    }

    @Override
    public Long saveConOstiaGroup(ConnectionOstiaGroup conOstiaGroup) {
        Long id = conOstiaGroup.getId();
        try {
            if (conOstiaGroup != null && conOstiaGroup.getId() != null) {
                conOstiaGroup.setUpdated_date(new Date());
                getHibernateTemplate().update(conOstiaGroup);
            } else {
                conOstiaGroup.setCreated_date(new Date());
                conOstiaGroup.setUpdated_date(new Date());
                id = (Long) getHibernateTemplate().save(conOstiaGroup);
            }
            LOGGER.info("id " + id);
        } catch (HibernateException e) {
            LOGGER.error("HibernateException in saveConOstiaGroup :" + e);
            LOGGER.error(e.toString(), e);
        }

        return id;

    }

}
