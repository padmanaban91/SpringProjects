package com.citigroup.cgti.c3par.bpm.ejb.search;

 
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Restrictions;
import org.hibernate.type.IntegerType;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.hibernate.type.TimestampType;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementSetter;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.bpm.ejb.domain.LookupDTO;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.ApplicationSearchAttributes;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.AppsenseSearchAttributes;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.BaseSearchAttributes;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.ConIPAddressSearchAttributes;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.ConIPDetailsSearchAttributes;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.ConIPPairFWSearchAttributes;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.ConIPPortSearchAttributes;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.GeneralSearchAttributes;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.IPRegDetSearchAttributes;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.OpeImpInputSearchAttributes;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.Process;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.ProxySearchAttributes;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.SearchByContactAttributes;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.SearchMyConnectionsProcess;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.SecAclSearchAttributes;
import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.communication.domain.ECMConstants;
import com.citigroup.cgti.c3par.configuation.CCRQueries;
import com.citigroup.cgti.c3par.configuation.QueryConstants;
import com.citigroup.cgti.c3par.persistance.BasePersistanceImpl;
import com.citigroup.cgti.c3par.proxy.domain.ProxyInstance;
import com.citigroup.cgti.c3par.util.C3parStaticNames;
import com.citigroup.cgti.c3par.util.StringUtil;
import com.mentisys.dao.DatabaseException;


/**
 * The Class SearchProcessesImpl.
 */
@SuppressWarnings("rawtypes")
@Transactional
public class SearchProcessesImpl extends BasePersistanceImpl implements ISearchProcess {
 
   

	/** The log. */
	private Logger log = Logger.getLogger(SearchProcessesImpl.class);
	
	private JdbcTemplate jdbcTemplate;
	private CCRQueries ccrQueries;
	
	private  final SimpleDateFormat formater = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss aa");
	private  final SimpleDateFormat formater1 = new SimpleDateFormat("MM/dd/yyyy");
	
	private static String querySelect;
	private static String myTaskquerySelectStart;
	private static String myTaskquerySelectEnd;
	
	public static final String LISTTYPE_ROLE="role";
	public static final String LISTTYPE_TASK="task";
	public static final String LISTTYPE_SECTOR="sector";
	public static final String LISTTYPE_REGION="region";
	  
	
/*	private BulkACVMessageSender bulkACVMessageSender;

	public BulkACVMessageSender getBulkACVMessageSender() {
		return bulkACVMessageSender;
	}

	public void setBulkACVMessageSender(BulkACVMessageSender bulkACVMessageSender) {
		this.bulkACVMessageSender = bulkACVMessageSender;
	}
 
	/**
	 * Run query.
	 *
	 * @param condition the condition
	 * @param groupByClause the group by clause
	 * @param orderByClause the order by clause
	 * @param pageNum the page num
	 * @param pageSize the page size
	 * @return the list
	 * @throws DatabaseException the database exception
	 */
	private List runQuery(String condition,String groupByClause, String orderByClause,int pageNum, int pageSize) throws DatabaseException {
		return queryWithPagination(condition,groupByClause, orderByClause, false, pageNum, pageSize);
	}
	
	private List runGeneralSearchQuery(Object attrbs,int pageNum, int pageSize, int recCnt) throws DatabaseException {
		return queryWithPaginationGlobalSearch(attrbs,pageNum, pageSize,recCnt);
	}
	
	private List runGeneralSearchApplicationQuery(Object attrbs,int pageNum, int pageSize, int recCnt) throws DatabaseException {
		return queryWithPaginationGlobalApplicationSearch(attrbs,pageNum, pageSize,recCnt);
	}
	
	private List runGeneralSearchIpFwPrPcQuery(Object attrbs,int pageNum, int pageSize, int recCnt) throws DatabaseException {
		return queryWithPaginationGlobalIpFwPrPcSearch(attrbs,pageNum, pageSize,recCnt);
	}
	
	private List runGeneralSearchIpFwPrPcQuery_Terminated(Object attrbs,int pageNum, int pageSize, int recCnt) throws DatabaseException {
        return queryWithPaginationGlobalIpFwPrPc_Terminated_Search(attrbs,pageNum, pageSize,recCnt);
	}
	private List runGeneralSearchIpQuery(Object attrbs,int pageNum, int pageSize, int recCnt) throws DatabaseException {
		return queryWithPaginationGlobalIpSearch(attrbs,pageNum, pageSize,recCnt);
	}
	
	private List runGeneralSearchCnRgScPcAppQuery(Object attrbs,int pageNum, int pageSize, int recCnt) throws DatabaseException {
		return queryWithPaginationGlobalCnRgScPcAppSearch(attrbs,pageNum, pageSize,recCnt);
	}
	
	private List runGeneralSearchPolicyQuery(Object attrbs,int pageNum, int pageSize, int recCnt) throws DatabaseException {
		return queryWithPaginationGlobalPolicySearch(attrbs,pageNum, pageSize,recCnt);
	}
	
	private List runGeneralSearchPortQuery(Object attrbs,int pageNum, int pageSize, int recCnt) throws DatabaseException {
		return queryWithPaginationGlobalPortSearch(attrbs,pageNum, pageSize,recCnt);
	}
	
	private List runGeneralSearchOpeImpQuery(Object attrbs,int pageNum, int pageSize, int recCnt) throws DatabaseException {
		return queryWithPaginationGlobalOpeImpSearch(attrbs,pageNum, pageSize,recCnt);
	}
	
	private List runGeneralSearchAppsenseQuery(Object attrbs,int pageNum, int pageSize, int recCnt) throws DatabaseException {
		return queryWithPaginationGlobalAppsenseSearch(attrbs,pageNum, pageSize,recCnt);
	}
	
	private List runGeneralSearchProxyQuery(Object attrbs,int pageNum, int pageSize, int recCnt) throws DatabaseException {
		return queryWithPaginationGlobalProxySearch(attrbs,pageNum, pageSize,recCnt);
	}
	
	//Added for 47403 starts
	//Search by sec acl name and device name 
	private List runGeneralSearchSecAclQuery(Object attrbs,int pageNum, int pageSize, int recCnt) throws DatabaseException {
		return queryWithPaginationGlobalSecAclSearch(attrbs,pageNum, pageSize,recCnt);
	}
	//Added for 47403 ends


	 private int getRowCount(String queryString, GeneralSearchAttributes attrs) {
	    Session session = getSession();
		int rowCount = 0;
		SQLQuery sqlquery = session.createSQLQuery("select count(*) as count from ("+queryString+")");
		
		int i = 0;
		
		String name ="";
		
		String soeId = attrs.getRequesterSOEId().toUpperCase();
		if(!(attrs.getProcessName()==null || attrs.getProcessName().isEmpty())){
			name=attrs.getProcessName();
			name=name.replaceAll("\\*", "%");
			log.debug("name" +name );
		}
		
		sqlquery.setParameter(i++, soeId);
		if (attrs.getTaskCodeForQuery() != null) {
			 sqlquery.setParameter(i++, attrs.getTaskCodeForQuery().longValue());
		}
		if (attrs.getRoleForQuery() != null) {
			sqlquery.setParameter(i++, attrs.getRoleForQuery().longValue());
		}
		if (attrs.getRegionForQuery() != null) {
			sqlquery.setParameter(i++, attrs.getRegionForQuery().longValue());
		}
		if (attrs.getSectorForQuery() != null) {
			sqlquery.setParameter(i++, attrs.getSectorForQuery().longValue());
		}
		if (attrs.getProcessName() != null && !attrs.getProcessName().isEmpty()) {
			sqlquery.setParameter(i++, name);
		}
		sqlquery.setParameter(i++, attrs.getActualRequestor());
		sqlquery.setParameter(i++, attrs.getActualRequestor());
		
		sqlquery.addScalar("count", IntegerType.INSTANCE);
		Integer count = (Integer)sqlquery.uniqueResult();
		rowCount = count.intValue();
		return rowCount;
    }
	
	public  List<Process> getMyConnections(SearchMyConnectionsProcess searchMyConnectionsProcess) throws Exception {
		Session session = getSession();
		List<Process> list = new ArrayList<Process>();
		String name = "";
		GeneralSearchAttributes attrs = searchMyConnectionsProcess.getGeneralSearchAttributes();
		
		 StringBuffer qry = new StringBuffer();
		
		 qry.append("SELECT DISTINCT X.CCR_ID,X.NAME,X.CURRENT_ACTIVITY,X.SCHEDULE_DATE, "); 
		 qry.append("X.BPM_INSTANCE_ID,X.ALBPM_ACTIVITY_ID,X.TASK_CODE,X.PHASE,X.ID,X.TI_PROCESS,X.DISPLAY_NAME, "); 
		 qry.append("X.START_DATE_DELTA,X.ACTIVITY_TRIAL_ID,X.ROLE_NAME,X.REGION,X.SECTOR, "); 
		 qry.append("DECODE(X.LOCKEDBY,NULL,DECODE(X.TASK_CODE,'ver_sow', NVL(USR_EI.COMB_EXISTS,'NO'),'NO'), "); 
		 qry.append("DECODE(USR_EI.USER_ID,X.LOCKEDBY,DECODE(X.CURRENT_ACTIVITY,'Annual Connectivity Verification', NVL(USR_EI.COMB_EXISTS,'NO'),'NO'),'NO')) USER_ACCESS, "); 
		 qry.append("COMPLETING_ROLE, "); 
		 qry.append("SUBSTR(BPM_INSTANCE_ID,1,INSTR(BPM_INSTANCE_ID,'@')-2)|| "); 
		 qry.append("DECODE(COMPLETING_ROLE,'PROJECT COORDINATOR',THID+1,'ISO',THID+2,'SYSTEM ADMINISTRATOR',THID+3,'BUSINESS USER',THID+4,THID)||'@citi' BULKACV_INSTANCE, "); 
		 qry.append("DECODE(COMPLETING_ROLE,'PROJECT COORDINATOR','VerifySOW4','TECHNICAL COORDINATOR','VerifySOW','ISO','VerifySOW2', "); 
		 qry.append("'SYSTEM ADMINISTRATOR','VerifySOW3','BUSINESS USER','BUVerifySOW','VerifySOW') BULKACV_ACTIVITY "); 
		 qry.append("FROM "); 
		 qry.append("( "); 
		 qry.append("SELECT TP.ID  AS CCR_ID, "); 
		 qry.append("TP.PROCESS_NAME        AS NAME , "); 
		 qry.append("TTT.TASK               AS CURRENT_ACTIVITY, "); 
		 qry.append("TP.ACTIVATION_EXP_DATE AS SCHEDULE_DATE, "); 
		 qry.append("T.BPM_INSTANCE_ID, "); 
		 qry.append("TTT.ALBPM_ACTIVITY_ID , "); 
		 qry.append("TTT.TASK_CODE, "); 
		 qry.append("DECODE(REQTY.REQUEST_TYPE,'CREATE','PLANNING',REQTY.REQUEST_TYPE) PHASE, "); 
		 qry.append("TR.ID, "); 
		 qry.append("TPT.PROCESS_TYPE AS TI_PROCESS, "); 
		 qry.append("RR.DISPLAY_NAME, "); 
		 qry.append("ROUND(TO_NUMBER(SYSDATE-TRUNC(T.ACTIVITY_STARTDATE))) START_DATE_DELTA, "); 
		 qry.append("T.ID ACTIVITY_TRIAL_ID, "); 
		 qry.append("RR.NAME ROLE_NAME, "); 
		 qry.append("SR.ID SECURITY_ROLE_ID , "); 
		 qry.append("RN.ID REGION_ID, SR.ID SECT_ID, (select listagg(rg.NAME,',') within group (order by rg.NAME) "); 
		 qry.append("from region rg, citi_hierarchy_master ch, rel_citi_hierarchy_xref rx, relationship rp "); 
		 qry.append("where rp.id = rx.relationship_id and rx.citi_hierarchy_master_id = ch.id and rg.id = ch.region_id and rp.id = r.id) AS REGION, SR.NAME AS SECTOR, "); 
		 qry.append("CITIMASTER.ID REG_SEC, T.LOCKEDBY, GL.VALUE1 SECURITY_ROLE_NAME, "); 
		 qry.append("SUBSTR(T.BPM_INSTANCE_ID,INSTR(T.BPM_INSTANCE_ID,'/',-1)+1,(INSTR(T.BPM_INSTANCE_ID,'@')-1-INSTR(T.BPM_INSTANCE_ID,'/',-1))) THID "); 
		 qry.append("FROM "); 
		 qry.append("( "); 
		 qry.append("SELECT CRCCX.REQUEST_ID,CRCCX.CITI_CONTACT_ID,CRCCX.ROLE_ID FROM "); 
		 qry.append("CON_REQ_CITI_CONTACT_XREF CRCCX WHERE CRCCX.PRIMARY_CONTACT='Y' AND CRCCX.NOTIFY_CONTACT='Y' "); 
		 qry.append("UNION "); 
		 qry.append("SELECT CRCCX.REQUEST_ID,CRCCX.CITI_CONTACT_ID,CRCCX.ROLE_ID FROM "); 
		 qry.append("CON_REQ_CIT_RQCON_XREF CRCCX WHERE CRCCX.PRIMARY_CONTACT='Y' AND CRCCX.NOTIFY_CONTACT='Y' "); 
		 qry.append(")CONTACT "); 
		 qry.append("JOIN (SELECT ID,SSO_ID FROM CITI_CONTACT)CC ON CC.ID=CONTACT.CITI_CONTACT_ID AND UPPER(CC.SSO_ID)= UPPER(?) "); 
		 qry.append("JOIN (SELECT ID,DISPLAY_NAME,SECURITY_ROLE_ID,NAME FROM ROLE)RR ON RR.ID=CONTACT.ROLE_ID "); 
		 qry.append("JOIN (SELECT PLANNING_ID,TI_REQUEST_ID FROM TI_REQUEST_PLANNING_XREF) TRPX ON TRPX.PLANNING_ID=CONTACT.REQUEST_ID "); 
		 qry.append("JOIN TI_REQUEST TR ON TRPX.TI_REQUEST_ID=TR.ID "); 
		 qry.append("JOIN TI_PROCESS TP ON TP.ID=TR.PROCESS_ID AND TP.VERSION_NUMBER=TR.VERSION_NUMBER AND TP.IS_DELETED         = 'N' "); 
		 qry.append("JOIN TI_PROCESS_TYPE TPT ON TP.PROCESS_TYPE_ID=TPT.ID "); 
		 qry.append("JOIN TI_ACTIVITY_TRAIL T ON T.TI_REQUEST_ID=TR.ID AND T.ACTIVITY_STATUS    IN ('SCHEDULED') "); 
		 qry.append("JOIN TI_TASK_TYPE TTT ON TTT.ID=T.ACTIVITY_ID "); 
		 qry.append("JOIN GENERIC_LOOKUP G ON G.ID=TR.PRIORITY_ID "); 
		 qry.append("JOIN TI_REQUEST_TYPE REQTY ON TR.TI_REQUEST_TYPE_ID = REQTY.ID "); 
		 qry.append("JOIN RELATIONSHIP R ON R.ID=TP.RELATIONSHIP_ID "); 
		 qry.append("JOIN REL_CITI_HIERARCHY_XREF EI ON R.ID=EI.RELATIONSHIP_ID "); 
		 qry.append("JOIN CITI_HIERARCHY_MASTER CITIMASTER ON CITIMASTER.ID=EI.CITI_HIERARCHY_MASTER_ID "); 
		 qry.append("JOIN REGION RN ON CITIMASTER.REGION_ID=RN.ID "); 
		 qry.append("JOIN SECTOR SR ON CITIMASTER.SECTOR_ID=SR.ID "); 
		 qry.append("LEFT JOIN SECURITY_ROLE SR ON SR.ID=RR.SECURITY_ROLE_ID "); 
		 qry.append("JOIN GENERIC_LOOKUP_DEFS GLD ON GLD.NAME='BULK_ACV_ROLES' "); 
		 qry.append("LEFT JOIN SECURITY_ROLE SER ON RR.SECURITY_ROLE_ID=SER.ID "); 
		 qry.append("LEFT JOIN GENERIC_LOOKUP GL ON GL.DEFINITION_ID=GLD.ID AND SER.NAME=GL.VALUE1 AND GL.DELETED='N' "); 
		 boolean whereClause = false;
		 if (attrs.getTaskCodeForQuery() != null) {
			 qry.append("WHERE "); 
			 whereClause = true;
			 qry.append("(TTT.ID = ?) "); 
		 }
		 if ("lessThan7".equals(attrs.getTimeInActivityForQuery())) {
			 if (whereClause) {
				 qry.append(" AND "); 
			 } else {
				 qry.append(" WHERE "); 
				 whereClause = true;
			 }
			 qry.append(" (ROUND(TO_NUMBER(SYSDATE - ACTIVITY_STARTDATE))<7) ");
		 }
		 if ("lessThan30".equals(attrs.getTimeInActivityForQuery())) {
			 if (whereClause) {
				 qry.append(" AND "); 
			 } else {
				 qry.append(" WHERE "); 
				 whereClause = true;
			 }
			 qry.append(" (ROUND(TO_NUMBER(SYSDATE - ACTIVITY_STARTDATE))<30) ");
		 }
		 if ("greaterThan60".equals(attrs.getTimeInActivityForQuery())) {
			 if (whereClause) {
				 qry.append(" AND "); 
			 } else {
				 qry.append(" WHERE "); 
				 whereClause = true;
			 }
			 qry.append(" (ROUND(TO_NUMBER(SYSDATE - ACTIVITY_STARTDATE))>60) ");
		 }
		 if ("between30And60".equals(attrs.getTimeInActivityForQuery())) {
			 if (whereClause) {
				 qry.append(" AND "); 
			 } else {
				 qry.append(" WHERE "); 
				 whereClause = true;
			 }
			 qry.append(" (ROUND(TO_NUMBER(SYSDATE - ACTIVITY_STARTDATE)) BETWEEN 30 AND 60) "); 
		 }
		 if (attrs.getRoleForQuery() != null) {
			 if (whereClause) {
				 qry.append(" AND "); 
			 } else {
				 qry.append(" WHERE "); 
				 whereClause = true;
			 }
			 qry.append(" (RR.ID = ?) ");
		 }
		 if (attrs.getRegionForQuery() != null) {
			 if (whereClause) {
				 qry.append(" AND "); 
			 } else {
				 qry.append(" WHERE "); 
				 whereClause = true;
			 }
			 qry.append(" (RN.ID = ?) ");
		 }
		 if (attrs.getSectorForQuery() != null) {
			 if (whereClause) {
				 qry.append(" AND "); 
			 } else {
				 qry.append(" WHERE "); 
				 whereClause = true;
			 }
			 qry.append(" (SR.ID = ?) "); 
		 }
		 if (attrs.getProcessName() != null && !attrs.getProcessName().isEmpty()) {
			 if (whereClause) {
				 qry.append(" AND "); 
			 } else {
				 qry.append(" WHERE "); 
				 whereClause = true;
			 }
			 qry.append(" (UPPER(TP.PROCESS_NAME) like UPPER(?)) ");
		 }
		 
		 qry.append(")X "); 
		 qry.append("LEFT JOIN "); 
		 qry.append("(SELECT "); 
		 qry.append("'Yes' COMB_EXISTS, "); 
		 qry.append("SR.ID SECURITY_ROLE_ID , "); 
		 qry.append("CITIMASTER.ID,CU.ID USER_ID, "); 
		 qry.append("CITIMASTER.region_id regid, "); 
		 qry.append("citimaster.sector_id secid "); 
		 qry.append("FROM C3PAR_USERS CU "); 
		 qry.append("JOIN USER_CITI_HIERARCHY_XREF UEX ON CU.ID=UEX.USER_ID "); 
		 qry.append("JOIN CITI_HIERARCHY_MASTER CITIMASTER ON CITIMASTER.ID=UEX.CITI_HIERARCHY_MASTER_ID "); 
		 qry.append("JOIN C3PAR_USER_ROLE_XREF CURX ON CURX.USER_ID=CU.ID "); 
		 qry.append("JOIN SECURITY_ROLE SR ON SR.ID=CURX.ROLE_ID "); 
		 qry.append("JOIN GENERIC_LOOKUP_DEFS GLD ON GLD.NAME='BULK_ACV_ROLES' "); 
		 qry.append("JOIN GENERIC_LOOKUP GL ON GL.DEFINITION_ID=GLD.ID AND SR.NAME=GL.VALUE1 AND GL.DELETED='N' "); 
		 qry.append("WHERE UPPER(CU.SSO_ID)  = UPPER(?) "); 
		 qry.append(")USR_EI ON X.REGION_ID= USR_EI.regid and X.sect_id = usr_ei.secid "); 
		 qry.append("LEFT JOIN "); 
		 qry.append("( "); 
		 qry.append("SELECT Y.DISPLAY_NAME COMPLETING_ROLE FROM ( "); 
		 qry.append("SELECT X.DISPLAY_NAME "); 
		 qry.append("FROM ( "); 
		 qry.append("SELECT DISTINCT SR.DISPLAY_NAME "); 
		 qry.append("FROM C3PAR_USERS CU "); 
		 qry.append("JOIN C3PAR_USER_ROLE_XREF CURX ON CURX.USER_ID=CU.ID "); 
		 qry.append("JOIN SECURITY_ROLE SR ON SR.ID=CURX.ROLE_ID "); 
		 qry.append("JOIN GENERIC_LOOKUP_DEFS GLD ON GLD.NAME='BULK_ACV_ROLES' "); 
		 qry.append("JOIN GENERIC_LOOKUP GL ON GL.DEFINITION_ID=GLD.ID AND SR.NAME=GL.VALUE1 AND GL.DELETED='N' "); 
		 qry.append("WHERE UPPER(CU.SSO_ID)  = UPPER(?) "); 
		 qry.append("ORDER BY "); 
		 qry.append("DECODE(SR.DISPLAY_NAME,'SYSTEM ADMINISTRATOR',1,'TECHNICAL COORDINATOR',2,'PROJECT COORDINATOR',3,'ISO',4, "); 
		 qry.append("'BUSINESS USER',5,6) "); 
		 qry.append(")X WHERE ROWNUM<=1)Y "); 
		 qry.append(") ON 1 = 1 "); 
		 qry.append("ORDER BY 1 DESC");
		
		try {
			String soeId = attrs.getRequesterSOEId().toUpperCase();
			if(!(attrs.getProcessName()==null || attrs.getProcessName().isEmpty())){
				name=attrs.getProcessName();
				name=name.replaceAll("\\*", "%");
			}
			
			SQLQuery sqlquery = session.createSQLQuery(qry.toString());
			
			int i = 0;
			
			sqlquery.setParameter(i++, soeId);
			if (attrs.getTaskCodeForQuery() != null) {
				 sqlquery.setParameter(i++, attrs.getTaskCodeForQuery().longValue());
			}
			if (attrs.getRoleForQuery() != null) {
				sqlquery.setParameter(i++, attrs.getRoleForQuery().longValue());
			}
			if (attrs.getRegionForQuery() != null) {
				sqlquery.setParameter(i++, attrs.getRegionForQuery().longValue());
			}
			if (attrs.getSectorForQuery() != null) {
				sqlquery.setParameter(i++, attrs.getSectorForQuery().longValue());
			}
			if (attrs.getProcessName() != null && !attrs.getProcessName().isEmpty()) {
				sqlquery.setParameter(i++, name);
			}
			sqlquery.setParameter(i++, attrs.getActualRequestor());
			sqlquery.setParameter(i++, attrs.getActualRequestor());
			
			sqlquery.addScalar("CCR_ID", LongType.INSTANCE);
			sqlquery.addScalar("NAME", StringType.INSTANCE);
			sqlquery.addScalar("CURRENT_ACTIVITY", StringType.INSTANCE);
			sqlquery.addScalar("SCHEDULE_DATE", TimestampType.INSTANCE);
			sqlquery.addScalar("BPM_INSTANCE_ID", StringType.INSTANCE);
			sqlquery.addScalar("ALBPM_ACTIVITY_ID", StringType.INSTANCE);
			sqlquery.addScalar("TASK_CODE", StringType.INSTANCE);
			sqlquery.addScalar("PHASE", StringType.INSTANCE);
			sqlquery.addScalar("ID", LongType.INSTANCE);
			sqlquery.addScalar("TI_PROCESS", StringType.INSTANCE);
			sqlquery.addScalar("DISPLAY_NAME", StringType.INSTANCE);
			sqlquery.addScalar("START_DATE_DELTA", LongType.INSTANCE);
			sqlquery.addScalar("ACTIVITY_TRIAL_ID", LongType.INSTANCE);
			sqlquery.addScalar("ROLE_NAME", StringType.INSTANCE);
			sqlquery.addScalar("REGION", StringType.INSTANCE);
			sqlquery.addScalar("SECTOR", StringType.INSTANCE);
			sqlquery.addScalar("USER_ACCESS", StringType.INSTANCE);
			sqlquery.addScalar("COMPLETING_ROLE", StringType.INSTANCE);
			sqlquery.addScalar("BULKACV_INSTANCE", StringType.INSTANCE);
			sqlquery.addScalar("BULKACV_ACTIVITY", StringType.INSTANCE);
			
			if (!searchMyConnectionsProcess.isExport()) {
				int rowCount = getRowCount(qry.toString(), attrs);
				searchMyConnectionsProcess.setRowCount(rowCount);
				addPagination(sqlquery, searchMyConnectionsProcess.getOffset(), searchMyConnectionsProcess.getLimit());
			}
			log.debug("Query -- "+sqlquery.toString());
			
			List<Object[]> rows = sqlquery.list();
			
			
			Process processObj = null;
			if(rows != null){
				for (Object[] obj : rows) {
					processObj = new Process();
					processObj.setId((Long)obj[0]);
					processObj.setDisplay_id(String.valueOf((Long)obj[0]));
					processObj.setName((String)obj[1]);
					processObj.setTaskName((String)obj[2]);
					
					if(obj[3]!= null){
						try {
						processObj.setLockedDate(formater1.format(obj[3]));
						} catch (Exception e) {log.error(e, e);}
					}
					processObj.setBmpInstanceId((String)obj[4]);
					processObj.setBpmActivityId((String)obj[5]);
					processObj.setTaskCode((String)obj[6]);
					processObj.setPhase((String)obj[7]);
					processObj.setTirequestid((Long)obj[8]);
					processObj.setTiProcess((String)obj[9]);
					processObj.setRole((String)obj[10]);
					processObj.setTimeInActivity((Long)obj[11]);
					processObj.setActivityTrialId((Long)obj[12]);
					processObj.setRoleName((String)obj[13]);
					processObj.setRegion((String)obj[14]);
					processObj.setSector((String)obj[15]);
					processObj.setUserAccess((String)obj[16]);
					processObj.setSubmissionRole((String)obj[17]);
					processObj.setBulkACVInstance((String)obj[18]);
					processObj.setBulkACVActivity((String)obj[19]);
					list.add(processObj);
				}
			}
			
			
		} catch (Exception e) {
			log.error(e.toString(),e);
			throw new DatabaseException("Could not run query = ", e);
		} 
		return list;
	}
	
	
	/**
	 * Query with pagination.
	 *
	 * @param condition the condition
	 * @param groupByClause the group by clause
	 * @param orderByClause the order by clause
	 * @param loadRefs the load refs
	 * @param pageNum the page num
	 * @param pageSize the page size
	 * @return the list
	 * @throws DatabaseException the database exception
	 */
	@SuppressWarnings("unchecked")
	private List queryWithPagination(String condition,String groupByClause, String orderByClause, boolean loadRefs,
			int pageNum, int pageSize) throws DatabaseException {
		if (pageNum == 0)
			throw new RuntimeException("Page Number should start at 1");
		ArrayList list = new ArrayList();
		String queryToExecute;
 
		int recCnt=getCount(condition,groupByClause, orderByClause);
		StringBuilder sb = new StringBuilder();

		if(recCnt>pageSize){
			sb.append("select *  from ( select a.*, rownum rnum from ( ");
		}
		sb.append(getQuerySelectString());
		String where = condition;
		if (!"".equals(where)) {
			sb.append(where);
		}
		if (!"".equals(groupByClause))
			sb.append(" GROUP BY " + groupByClause);
		if (!"".equals(orderByClause))
			sb.append(" ORDER BY " + orderByClause);
		if(recCnt>pageSize){
			sb.append(" ) a where rownum <= ");
			sb.append((pageNum * pageSize));
			sb.append(" ) where rnum >= ");
			log.debug("recCnt%pageSize = " + recCnt%pageSize);
			int maxPageNo = recCnt / 10;
			if (recCnt % pageSize > 0) {
				maxPageNo++;
			}
			if(pageNum< maxPageNo)
				sb.append((pageNum * pageSize) - pageSize + 1);
			else
				sb.append((pageNum * pageSize) - pageSize + 1);
				
				
		}
		queryToExecute = sb.toString();
		log.debug("Sql is :- " + queryToExecute);
	 
		Object obj = null;
	 
		try {
			 
			SqlRowSet rs  =  jdbcTemplate.queryForRowSet(queryToExecute);
			for (; rs.next(); list.add(obj)) {
				obj = createModel(rs);
			}
		} catch (Exception e) {
			log.error("Exception during query :- " + e.toString());
			log.error(e.toString(), e);
			throw new DatabaseException("Could not run query = " + queryToExecute, e);
		}  

		return list;
	}
	
	
	private List<Object> queryWithPaginationGlobalSearch(Object attrsObj,int pageNum, int pageSize, int recCnt) throws DatabaseException {
		if (pageNum == 0)
			throw new RuntimeException("Page Number should start at 1");
		
		SqlRowSet rs  = null;
		SqlRowSet rs1  = null;
		Object obj = null;
		List<Object> list = new ArrayList<Object>();
		int rowNo = 0;
		int rNo = 0 ;

		String queryToExecute = ccrQueries.getQueryByName(QueryConstants.QUERY_GENERAL_SEARCH);
		String queryToExecuteForRequesterBusinessOnwerContact = ccrQueries.getQueryByName(QueryConstants.QUERY_GENERAL_SEARCH_REQUESTER_BUSINESS_OWNER);
		if(recCnt>pageSize){
			queryToExecute = ccrQueries.getQueryByName(QueryConstants.QUERY_GENERAL_SEARCH_WITH_PAGINATION);
			queryToExecuteForRequesterBusinessOnwerContact = ccrQueries.getQueryByName(QueryConstants.QUERY_GENERAL_SEARCH_WITH_PAGINATION_REQUESTER_BUSINESS_OWNER);
			rowNo = (pageNum * pageSize);
			rNo =(pageNum * pageSize) - pageSize + 1;
		}
		try {
		    BaseSearchAttributes attrs = (BaseSearchAttributes) attrsObj;
		    queryToExecute = queryToExecute.replace(":RELTYPE", getRelationShipType(attrs.getThirdpartyNames()));
		    queryToExecuteForRequesterBusinessOnwerContact = queryToExecuteForRequesterBusinessOnwerContact.replace(":RELTYPE", getRelationShipType(attrs.getThirdpartyNames()));
			if(recCnt>pageSize){
				rs = getResultSetGeneralSearchWithPagination(queryToExecute,attrsObj,rowNo,rNo,QueryConstants.QUERY_TO_EXECUTE);
				rs1 = getResultSetGeneralSearchWithPagination(queryToExecuteForRequesterBusinessOnwerContact,attrsObj,rowNo,rNo,QueryConstants.QUERY_TO_EXECUTE_FOR_REQUESTER_BUSINESS_OWNER);
			}else{
				rs = getResultSetGeneralSearch(queryToExecute,attrsObj,QueryConstants.QUERY_TO_EXECUTE);
				rs1 = getResultSetGeneralSearch(queryToExecuteForRequesterBusinessOnwerContact,attrsObj,QueryConstants.QUERY_TO_EXECUTE_FOR_REQUESTER_BUSINESS_OWNER);
			}
			
			for (; rs.next(); list.add(obj)) {
				obj = createModel(rs);
			}
			if(rs1 != null) {
			    for (; rs1.next(); list.add(obj)) {
	                obj = createModel(rs1);
	            }    
			}
		} catch (Exception e) {
			log.error("Exception during query :- " + e);
			throw new DatabaseException("Could not run query = " + queryToExecute, e);
		}  

		return list;
	}
	
	
	private List<Object> queryWithPaginationGlobalApplicationSearch(Object attrsObj,int pageNum, int pageSize, int recCnt) throws DatabaseException {
		if (pageNum == 0)
			throw new RuntimeException("Page Number should start at 1");
		
		SqlRowSet rs  = null;
		Object obj = null;
		List<Object> list = new ArrayList<Object>();
		int rowNo = 0;
		int rNo = 0 ;

		String queryToExecute = ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_APPLICATION);
		if(recCnt>pageSize){
			queryToExecute = ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_APPLICATION_WITH_PAGINATION);
			rowNo = (pageNum * pageSize);
			rNo =(pageNum * pageSize) - pageSize + 1;
		}
		try {
		    BaseSearchAttributes attrs = (BaseSearchAttributes) attrsObj;
            queryToExecute = queryToExecute.replace(":RELTYPE", getRelationShipType(attrs.getThirdpartyNames()));
			if(recCnt>pageSize){
				rs  =  getResultSetApplicationGeneralSearchWithPagination(queryToExecute,attrsObj,rowNo,rNo);
			}else{
				rs  =  getResultSetApplicationGeneralSearch(queryToExecute,attrsObj);
			}
			
			for (; rs.next(); list.add(obj)) {
				obj = createModel(rs);
			}
		} catch (Exception e) {
			log.error("Exception during query :- " + e);
			throw new DatabaseException("Could not run query = " + queryToExecute, e);
		}  

		return list;
	}
	
	private List<Object> queryWithPaginationGlobalIpFwPrPcSearch(Object attrsObj,int pageNum, int pageSize, int recCnt) throws DatabaseException {
		if (pageNum == 0)
			throw new RuntimeException("Page Number should start at 1");
		
		SqlRowSet rs  = null;
		Object obj = null;
		List<Object> list = new ArrayList<Object>();
		int rowNo = 0;
		int rNo = 0 ;

		String queryToExecute = ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_IP_PORT_POLICY);
 
		if(recCnt>pageSize){
			queryToExecute = ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_IP_PORT_POLICY_WITH_PAGINATION);
			rowNo = (pageNum * pageSize);
			rNo =(pageNum * pageSize) - pageSize + 1;
		}
		try {
		    BaseSearchAttributes attrs = (BaseSearchAttributes) attrsObj;

            queryToExecute = queryToExecute.replace(":RELTYPE", getRelationShipType(attrs.getThirdpartyNames()));
			if(recCnt>pageSize){
				rs  =  getResultSetIpFwPrPcGeneralSearchWithPagination(queryToExecute,attrsObj,rowNo,rNo);
			}else{
				rs  =  getResultSetIpFwPrPcGeneralSearch(queryToExecute,attrsObj);
			}
			
			for (; rs.next(); list.add(obj)) {
				obj = createModel(rs);
			}
		} catch (Exception e) {
			log.error("Exception during query :- " + e);
			throw new DatabaseException("Could not run query = " + queryToExecute, e);
		}  

		return list;
	}
	
	//newly added.
	private List<Object> queryWithPaginationGlobalIpFwPrPc_Terminated_Search(Object attrsObj,int pageNum, int pageSize, int recCnt) throws DatabaseException {
        if (pageNum == 0)
            throw new RuntimeException("Page Number should start at 1");
        
        SqlRowSet rs  = null;
        Object obj = null;
        List<Object> list = new ArrayList<Object>();
        int rowNo = 0;
        int rNo = 0 ;

        String queryToExecute = ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_IP_PORT_POLICY_TERMINATED);
 
        if(recCnt>pageSize){
            queryToExecute = ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_IP_PORT_POLICY_TERMINATED_WITH_PAGINATION);
            rowNo = (pageNum * pageSize);
            rNo =(pageNum * pageSize) - pageSize + 1;
        }
        try {
            BaseSearchAttributes attrs = (BaseSearchAttributes) attrsObj;

            queryToExecute = queryToExecute.replace(":RELTYPE", getRelationShipType(attrs.getThirdpartyNames()));
            if(recCnt>pageSize){
                rs  =  getResultSetIpFwPrPcGeneralSearchWithPagination(queryToExecute,attrsObj,rowNo,rNo);
            }else{
                rs  =  getResultSetIpFwPrPcGeneralSearch(queryToExecute,attrsObj);
            }
            
            for (; rs.next(); list.add(obj)) {
                obj = createModel(rs);
            }
        } catch (Exception e) {
            log.error("Exception during query :- " + e);
            throw new DatabaseException("Could not run query = " + queryToExecute, e);
        }  

        return list;
    }
    
	
	
	private List<Object> queryWithPaginationGlobalIpSearch(Object attrsObj,int pageNum, int pageSize, int recCnt) throws DatabaseException {
		if (pageNum == 0)
			throw new RuntimeException("Page Number should start at 1");
		
		SqlRowSet rs  = null;
		Object obj = null;
		List<Object> list = new ArrayList<Object>();
		int rowNo = 0;
		int rNo = 0 ;

		String queryToExecute = ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_IP);
 
		if(recCnt>pageSize){
			queryToExecute = ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_IP_WITH_PAGINATION);
			rowNo = (pageNum * pageSize);
			rNo =(pageNum * pageSize) - pageSize + 1;
		}
		try {
			if(recCnt>pageSize){
				rs  =  getResultSetIpGeneralSearchWithPagination(queryToExecute,attrsObj,rowNo,rNo);
			}else{
				rs  =  getResultSetIpGeneralSearch(queryToExecute,attrsObj);
			}
			
			for (; rs.next(); list.add(obj)) {
				obj = createModel(rs);
			}
		} catch (Exception e) {
			log.error("Exception during query :- " + e);
			throw new DatabaseException("Could not run query = " + queryToExecute, e);
		}  

		return list;
	}
	
	
	private List<Object> queryWithPaginationGlobalCnRgScPcAppSearch(Object attrsObj,int pageNum, int pageSize, int recCnt) throws DatabaseException {
		if (pageNum == 0)
			throw new RuntimeException("Page Number should start at 1");
		
		SqlRowSet rs  = null;
		Object obj = null;
		List<Object> list = new ArrayList<Object>();
		int rowNo = 0;
		int rNo = 0 ;

		String queryToExecute = ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_CONTACT_PC_RG_SCT_APP);
 
		if(recCnt>pageSize){
			queryToExecute = ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_CONTACT_PC_RG_SCT_APP_WITH_PAGINATION);
			rowNo = (pageNum * pageSize);
			rNo =(pageNum * pageSize) - pageSize + 1;
		}
		try {
		    BaseSearchAttributes attrs = (BaseSearchAttributes) attrsObj;

            queryToExecute = queryToExecute.replace(":RELTYPE", getRelationShipType(attrs.getThirdpartyNames()));
			if(recCnt>pageSize){
				rs  =  getResultSetCnRgScPcAppGeneralSearchWithPagination(queryToExecute,attrsObj,rowNo,rNo);
			}else{
				rs  =  getResultSetCnRgScPcAppGeneralSearch(queryToExecute,attrsObj);
			}
			
			for (; rs.next(); list.add(obj)) {
				obj = createModel(rs);
			}
		} catch (Exception e) {
			log.error("Exception during query :- " + e);
			throw new DatabaseException("Could not run query = " + queryToExecute, e);
		}  
		return list;
	}
	
	
	private List<Object> queryWithPaginationGlobalPolicySearch(Object attrsObj,int pageNum, int pageSize, int recCnt) throws DatabaseException {
		if (pageNum == 0){
			throw new RuntimeException("Page Number should start at 1");
		}
		SqlRowSet rs  = null;
		Object obj = null;
		List<Object> list = new ArrayList<Object>();
		int rowNo = 0;
		int rNo = 0 ;

		String queryToExecute = ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_POLICY);
		if(recCnt>pageSize){
			queryToExecute = ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_POLICY_WITH_PAGINATION);
			rowNo = (pageNum * pageSize);
			rNo =(pageNum * pageSize) - pageSize + 1;
		}
		try {
			if(recCnt>pageSize){
				rs  =  getResultSetPolicyGeneralSearchWithPagination(queryToExecute,attrsObj,rowNo,rNo);
			}else{
				rs  =  getResultSetPolicyGeneralSearch(queryToExecute,attrsObj);
			}
			
			for (; rs.next(); list.add(obj)) {
				obj = createModel(rs);
			}
		} catch (Exception e) {
			log.error("Exception during query :- " + e);
			throw new DatabaseException("Could not run query = " + queryToExecute, e);
		}  

		return list;
	}
	
	private List<Object> queryWithPaginationGlobalPortSearch(Object attrsObj,int pageNum, int pageSize, int recCnt) throws DatabaseException {
		if (pageNum == 0){
			throw new RuntimeException("Page Number should start at 1");
		}
		SqlRowSet rs  = null;
		Object obj = null;
		List<Object> list = new ArrayList<Object>();
		int rowNo = 0;
		int rNo = 0 ;

		String queryToExecute = ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_PORT);
		if(recCnt>pageSize){
			queryToExecute = ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_PORT_WITH_PAGINATION);
			rowNo = (pageNum * pageSize);
			rNo =(pageNum * pageSize) - pageSize + 1;
		}
		try {
			if(recCnt>pageSize){
				rs  =  getResultSetPortGeneralSearchWithPagination(queryToExecute,attrsObj,rowNo,rNo);
			}else{
				rs  =  getResultSetPortGeneralSearch(queryToExecute,attrsObj);
			}
			
			for (; rs.next(); list.add(obj)) {
				obj = createModel(rs);
			}
		} catch (Exception e) {
			log.error("Exception during query :- " + e);
			throw new DatabaseException("Could not run query = " + queryToExecute, e);
		}  

		return list;
	}
	
	private List<Object> queryWithPaginationGlobalOpeImpSearch(Object attrsObj,int pageNum, int pageSize, int recCnt) throws DatabaseException {
		if (pageNum == 0){
			throw new RuntimeException("Page Number should start at 1");
		}
		SqlRowSet rs  = null;
		Object obj = null;
		List<Object> list = new ArrayList<Object>();
		int rowNo = 0;
		int rNo = 0 ;

		String queryToExecute = ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_OPEIMP);
		if(recCnt>pageSize){
			queryToExecute = ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_OPEIMP_WITH_PAGINATION);
			rowNo = (pageNum * pageSize);
			rNo =(pageNum * pageSize) - pageSize + 1;
		}
		try {
			if(recCnt>pageSize){
				rs  =  getResultSetOpeImpGeneralSearchWithPagination(queryToExecute,attrsObj,rowNo,rNo);
			}else{
				rs  =  getResultSetOpeImpGeneralSearch(queryToExecute,attrsObj);
			}
			
			for (; rs.next(); list.add(obj)) {
				obj = createModel(rs);
			}
		} catch (Exception e) {
			log.error("Exception during query :- " + e);
			throw new DatabaseException("Could not run query = " + queryToExecute, e);
		}  

		return list;
	}
	
	private List<Object> queryWithPaginationGlobalAppsenseSearch(Object attrsObj,int pageNum, int pageSize, int recCnt) throws DatabaseException {
		if (pageNum == 0){
			throw new RuntimeException("Page Number should start at 1");
		}
		SqlRowSet rs  = null;
		Object obj = null;
		List<Object> list = new ArrayList<Object>();
		int rowNo = 0;
		int rNo = 0 ;

		String queryToExecute = ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_APPSENSE);
		if(recCnt>pageSize){
			queryToExecute = ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_APPSENSE_WITH_PAGINATION);
			rowNo = (pageNum * pageSize);
			rNo =(pageNum * pageSize) - pageSize + 1;
		}
		try {
			if(recCnt>pageSize){
				rs  =  getResultSetAppsenseGeneralSearchWithPagination(queryToExecute,attrsObj,rowNo,rNo);
			}else{
				rs  =  getResultSetAppsenseGeneralSearch(queryToExecute,attrsObj);
			}
			
			for (; rs.next(); list.add(obj)) {
				obj = createModel(rs);
			}
		} catch (Exception e) {
			log.error("Exception during query :- " + e);
			throw new DatabaseException("Could not run query = " + queryToExecute, e);
		}  

		return list;
	}
	
	private List<Object> queryWithPaginationGlobalProxySearch(Object attrsObj,int pageNum, int pageSize, int recCnt) throws DatabaseException {
		if (pageNum == 0){
			throw new RuntimeException("Page Number should start at 1");
		}
		SqlRowSet rs  = null;
		Object obj = null;
		List<Object> list = new ArrayList<Object>();
		int rowNo = 0;
		int rNo = 0 ;

		String queryToExecute = ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_PROXY);
		if(recCnt>pageSize){
			queryToExecute = ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_PROXY_WITH_PAGINATION);
			rowNo = (pageNum * pageSize);
			rNo =(pageNum * pageSize) - pageSize + 1;
		}
		try {
			if(recCnt>pageSize){
				rs  =  getResultSetProxyGeneralSearchWithPagination(queryToExecute,attrsObj,rowNo,rNo);
			}else{
				rs  =  getResultSetProxyGeneralSearch(queryToExecute,attrsObj);
			}
			
			for (; rs.next(); list.add(obj)) {
				obj = createModel(rs);
			}
		} catch (Exception e) {
			log.error("Exception during query :- " + e);
			throw new DatabaseException("Could not run query = " + queryToExecute, e);
		}  

		return list;
	}
	
	private List<Object> queryWithPaginationGlobalSecAclSearch(Object attrsObj,int pageNum, int pageSize, int recCnt) throws DatabaseException {
		if (pageNum == 0){
			throw new RuntimeException("Page Number should start at 1");
		}
		SqlRowSet rs  = null;
		Object obj = null;
		List<Object> list = new ArrayList<Object>();
		int rowNo = 0;
		int rNo = 0 ;

		String queryToExecute = ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_SEC_ACL);
		if(recCnt>pageSize){
			queryToExecute = ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_SEC_ACL_WITH_PAGINATION);
			rowNo = (pageNum * pageSize);
			rNo =(pageNum * pageSize) - pageSize + 1;
		}
		try {
			if(recCnt>pageSize){
				rs  =  getResultSetSecAclGeneralSearchWithPagination(queryToExecute,attrsObj,rowNo,rNo);
			}else{
				rs  =  getResultSetSecAclGeneralSearch(queryToExecute,attrsObj);
			}
			
			for (; rs.next(); list.add(obj)) {
				obj = createModel(rs);
			}
		} catch (Exception e) {
			log.error("Exception during query :- " + e);
			throw new DatabaseException("Could not run query = " + queryToExecute, e);
		}  

		return list;
	}
	//Added for task 47403 ends
	
	
	/**
	 * Gets the count.
	 *
	 * @param condition the condition
	 * @param groupByClause the group by clause
	 * @param orderByClause the order by clause
	 * @return the count
	 * @throws DatabaseException the database exception
	 */
	private int  getCount(String condition,String groupByClause, String orderByClause) throws DatabaseException {
		String queryToExecute;
	 
		int cnt=0;
		StringBuilder sb = new StringBuilder();
		sb.append("select count(*) cnt  from ( ");
		sb.append(getQuerySelectString());
		String where = condition;
		if (!"".equals(where)) {
			//sb.append(" WHERE ");
			sb.append(where);
		}
		String groupBy = groupByClause;
		if (!"".equals(groupBy))
			sb.append(" GROUP BY " + groupBy);
		String orderBy = orderByClause;
		if (!"".equals(orderBy))
			sb.append(" ORDER BY " + orderBy);

		sb.append(" ) a ");
		queryToExecute = sb.toString();
		log.debug("Sql is :- " + queryToExecute);
		 
	 
		try {
			SqlRowSet rs  =  jdbcTemplate.queryForRowSet(queryToExecute);
			if(rs.next()) {
				cnt= rs.getInt(1);
			}
			if(cnt==11)
				cnt=10;
			 
		 
		} catch (Exception e) {
			throw new DatabaseException("Could not run query = " + queryToExecute, e);
		}  

		return cnt;
	}
	
	private int  getGlobalSearchCount() throws DatabaseException {
		String queryToExecute = QueryConstants.QUERY_COUNT_GLOBAL_SEARCH;
		
		int cnt=0;
		try {
			SqlRowSet  rs = jdbcTemplate.queryForRowSet(ccrQueries.getQueryByName(queryToExecute));
			if(rs.next()) {
				cnt= rs.getInt(1);
			}
			if(cnt==11)
				cnt=10;
			 
		 
		} catch (Exception e) {
			throw new DatabaseException("Could not run query = " + queryToExecute, e);
		}  

		return cnt;
	}
	
	
	private int  getGeneralSearchQueryCount(Object attrsObj) throws DatabaseException {
		String queryToExecute;
		String queryToExecuteForRequesterBusinessOnwerContact;
	 
		int cnt=0;
		queryToExecute = ccrQueries.getQueryByName(QueryConstants.QUERY_COUNT_GENERAL_SEARCH);
		queryToExecuteForRequesterBusinessOnwerContact = ccrQueries.getQueryByName(QueryConstants.QUERY_COUNT_GENERAL_SEARCH_REQUESTER_BUSINESS_OWNER); 
		BaseSearchAttributes attrs = (BaseSearchAttributes) attrsObj;

        try {
            queryToExecute = queryToExecute.replace(":RELTYPE", getRelationShipType(attrs.getThirdpartyNames()));
            queryToExecuteForRequesterBusinessOnwerContact = queryToExecuteForRequesterBusinessOnwerContact.replace(":RELTYPE", getRelationShipType(attrs.getThirdpartyNames()));
			SqlRowSet rs  =  getResultSetGeneralSearch(queryToExecute,attrsObj,QueryConstants.QUERY_TO_EXECUTE);
			SqlRowSet rs1  =  getResultSetGeneralSearch(queryToExecuteForRequesterBusinessOnwerContact,attrsObj,QueryConstants.QUERY_TO_EXECUTE_FOR_REQUESTER_BUSINESS_OWNER);
			if(rs.next()) {
				cnt= rs.getInt(1);
			}
			if(rs1 != null) {
			    if(rs1.next()) {
	                cnt= cnt + rs1.getInt(1);
	            }    
			}
			if(cnt==11){
				cnt=10;
			}
		 
		} catch (Exception e) {
			throw new DatabaseException("Could not run query = " + queryToExecute, e);
		}  

		return cnt;
	}
	
	private int  getGeneralSearchApplicationQueryCount(Object attrsObj) throws DatabaseException {
		String queryToExecute;
		int cnt=0;
		queryToExecute =ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_APPLICATION_COUNT);
		try {
		    BaseSearchAttributes attrs = (BaseSearchAttributes) attrsObj;
            queryToExecute = queryToExecute.replace(":RELTYPE", getRelationShipType(attrs.getThirdpartyNames()));
			SqlRowSet rs  =  getResultSetApplicationGeneralSearch(queryToExecute,attrsObj);
			if(rs.next()) {
				cnt= rs.getInt(1);
			}
			if(cnt==11)
				cnt=10;
		} catch (Exception e) {
			throw new DatabaseException("Could not run query = " + queryToExecute, e);
		}  

		return cnt;
	}
	
	
	private int  getGeneralSearchIpFwPrPcQueryCount(Object attrsObj) throws DatabaseException {
		String queryToExecute;
		int cnt=0;
		queryToExecute =ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_IP_PORT_POLICY_COUNT);
		try {
		    BaseSearchAttributes attrs = (BaseSearchAttributes) attrsObj;

            queryToExecute = queryToExecute.replace(":RELTYPE", getRelationShipType(attrs.getThirdpartyNames()));


			SqlRowSet rs  =  getResultSetIpFwPrPcGeneralSearch(queryToExecute,attrsObj);
			if(rs.next()) {
				cnt= rs.getInt(1);
			}
			if(cnt==11){
				cnt=10;
			}
		} catch (Exception e) {
			throw new DatabaseException("Could not run query = " + queryToExecute, e);
		}  
		return cnt;
	}
	
	//newly added
		private int  getGeneralSearchIpFwPrPcQueryCount_TerminatedIds(Object attrsObj) throws DatabaseException {
	        String queryToExecute;
	        int cnt=0;
	        queryToExecute =ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_IP_PORT_POLICY_TERMINATED_COUNT);
	        try {
	            BaseSearchAttributes attrs = (BaseSearchAttributes) attrsObj;

	            queryToExecute = queryToExecute.replace(":RELTYPE", getRelationShipType(attrs.getThirdpartyNames()));


	            SqlRowSet rs  =  getResultSetIpFwPrPcGeneralSearch(queryToExecute,attrsObj);
	            if(rs.next()) {
	                cnt= rs.getInt(1);
	            }
	            if(cnt==11){
	                cnt=10;
	            }
	        } catch (Exception e) {
	            throw new DatabaseException("Could not run query = " + queryToExecute, e);
	        }  
	        return cnt;
	    }
	
	private int  getGeneralSearchIpQueryCount(Object attrsObj) throws DatabaseException {
		String queryToExecute;
		int cnt=0;
		queryToExecute =ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_IP_COUNT);
		try {
		    BaseSearchAttributes attrs = (BaseSearchAttributes) attrsObj;

            queryToExecute = queryToExecute.replace(":RELTYPE", getRelationShipType(attrs.getThirdpartyNames()));
			SqlRowSet rs  =  getResultSetIpGeneralSearch(queryToExecute,attrsObj);
			if(rs.next()) {
				cnt= rs.getInt(1);
			}
			if(cnt==11){
				cnt=10;
			}
		} catch (Exception e) {
			throw new DatabaseException("Could not run query = " + queryToExecute, e);
		}  

		return cnt;
	}
	
	
	private int  getGeneralSearchCnRgScPcAppQueryCount(Object attrsObj) throws DatabaseException {
		String queryToExecute;
		int cnt=0;
		queryToExecute =ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_CONTACT_PC_RG_SCT_APP_COUNT);
		try {
		    BaseSearchAttributes attrs = (BaseSearchAttributes) attrsObj;

            queryToExecute = queryToExecute.replace(":RELTYPE", getRelationShipType(attrs.getThirdpartyNames()));
			SqlRowSet rs  =  getResultSetCnRgScPcAppGeneralSearch(queryToExecute,attrsObj);
			if(rs.next()) {
				cnt= rs.getInt(1);
			}
			if(cnt==11){
				cnt=10;
			}
		} catch (Exception e) {
			throw new DatabaseException("Could not run query = " + queryToExecute, e);
		}  

		return cnt;
	}
	
	//Added for 47403 starts
	//Search by sec acl name and device name 
	private int  getGeneralSearchSecAclQueryCount(Object attrsObj) throws DatabaseException {
		String queryToExecute;
		int cnt=0;
		queryToExecute =ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_SEC_ACL_COUNT);
		try {
			SqlRowSet rs  =  getResultSetSecAclGeneralSearch(queryToExecute,attrsObj);
			if(rs.next()) {
				cnt= rs.getInt(1);
			}
			if(cnt==11){
				cnt=10;
			}
			log.debug("row size for acl" +cnt);
		} catch (Exception e) {
			throw new DatabaseException("Could not run query = " + queryToExecute, e);
		}  

		return cnt;
	}
	//Added for  47403 ends
	
	private int  getGeneralSearchPolicyQueryCount(Object attrsObj) throws DatabaseException {
		String queryToExecute;
		int cnt=0;
		queryToExecute =ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_POLICY_COUNT);
		try {
			SqlRowSet rs  =  getResultSetPolicyGeneralSearch(queryToExecute,attrsObj);
			if(rs.next()) {
				cnt= rs.getInt(1);
			}
			if(cnt==11){
				cnt=10;
			}
		} catch (Exception e) {
			throw new DatabaseException("Could not run query = " + queryToExecute, e);
		}  

		return cnt;
	}
	
	private int  getGeneralSearchPortQueryCount(Object attrsObj) throws DatabaseException {
		String queryToExecute;
		int cnt=0;
		queryToExecute =ccrQueries.getQueryByName(QueryConstants.COUNT_GENERAL_SEARCH_PORT);
		try {
			SqlRowSet rs  =  getResultSetPortGeneralSearch(queryToExecute,attrsObj);
			if(rs.next()) {
				cnt= rs.getInt(1);
			}
			if(cnt==11){
				cnt=10;
			}
		} catch (Exception e) {
			throw new DatabaseException("Could not run query = " + queryToExecute, e);
		}  

		return cnt;
	}
	
	private int  getGeneralSearchOpeImpQueryCount(Object attrsObj) throws DatabaseException {
		String queryToExecute;
		int cnt=0;
		queryToExecute =ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_OPEIMP_COUNT);
		try {
			SqlRowSet rs  =  getResultSetOpeImpGeneralSearch(queryToExecute,attrsObj);
			if(rs.next()) {
				cnt= rs.getInt(1);
			}
			if(cnt==11){
				cnt=10;
			}
		} catch (Exception e) {
			throw new DatabaseException("Could not run query = " + queryToExecute, e);
		}  

		return cnt;
	}
	
	private int  getGeneralSearchAppsenseQueryCount(Object attrsObj) throws DatabaseException {
		String queryToExecute;
		int cnt=0;
		queryToExecute =ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_APPSENSE_COUNT);
		try {
			SqlRowSet rs  =  getResultSetAppsenseGeneralSearch(queryToExecute,attrsObj);
			if(rs.next()) {
				cnt= rs.getInt(1);
			}
			if(cnt==11){
				cnt=10;
			}
		} catch (Exception e) {
			throw new DatabaseException("Could not run query = " + queryToExecute, e);
		}  

		return cnt;
	}
	
	private int  getGeneralSearchProxyQueryCount(Object attrsObj) throws DatabaseException {
		String queryToExecute;
		int cnt=0;
		queryToExecute =ccrQueries.getQueryByName(QueryConstants.GENERAL_SEARCH_PROXY_COUNT);
		try {
			SqlRowSet rs  =  getResultSetProxyGeneralSearch(queryToExecute,attrsObj);
			if(rs.next()) {
				cnt= rs.getInt(1);
			}
			if(cnt==11){
				cnt=10;
			}
		} catch (Exception e) {
			throw new DatabaseException("Could not run query = " + queryToExecute, e);
		}  

		return cnt;
	}
	
	
	
	private SqlRowSet getResultSetApplicationGeneralSearch(String queryToExecute,Object attrsObj)
	{
		ApplicationSearchAttributes attrs = (ApplicationSearchAttributes) attrsObj;
		return
		jdbcTemplate.queryForRowSet(queryToExecute,
				new Object[]{
								attrs.getCsiIdForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getCsiIdForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getCsiIdForQuery(),
								attrs.getApplicationNameForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getApplicationNameForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getApplicationNameForQuery(),
								attrs.getDeviceModelForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getDeviceModelForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getDeviceModelForQuery()
							});
	}
	
	private SqlRowSet getResultSetApplicationGeneralSearchWithPagination(String queryToExecute,Object attrsObj,int rowNo, int rNo)
	{
		ApplicationSearchAttributes attrs = (ApplicationSearchAttributes) attrsObj;
		return
		jdbcTemplate.queryForRowSet(queryToExecute,
				new Object[]{
								attrs.getCsiIdForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getCsiIdForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getCsiIdForQuery(),
								attrs.getApplicationNameForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getApplicationNameForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getApplicationNameForQuery(),
								attrs.getDeviceModelForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getDeviceModelForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getDeviceModelForQuery(),
								rowNo,
								rNo
							});
	}
	
	private SqlRowSet getResultSetIpFwPrPcGeneralSearch(String queryToExecute,Object attrsObj)
	{
		ConIPDetailsSearchAttributes attrs = (ConIPDetailsSearchAttributes) attrsObj;
		Object[] values= new Object[]{			
				(attrs.getFirewallForQuery()==null && attrs.getFirewallNameForQuery()==null)?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
				(attrs.getFirewallForQuery()==null && attrs.getFirewallNameForQuery()==null)?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
				(attrs.getSourceIpAddressForQuery()==null && attrs.getSourceNatIPForQuery()==null)?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
				(attrs.getDestIpAddressForQuery()==null && attrs.getDestNatIPForQuery()==null)?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
				(attrs.getSourceIpAddressForQuery()==null && attrs.getSourceNatIPForQuery()==null)?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
				(attrs.getDestIpAddressForQuery()==null && attrs.getDestNatIPForQuery()==null)?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
				(attrs.getPortForQuery()==null && attrs.getProtocolForQuery()==null)?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
				(attrs.getPortForQuery()==null && attrs.getProtocolForQuery()==null)?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
				attrs.getFirewallNameForQuery()==null?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,				
				attrs.getFirewallGroupForQuery()==null?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
				attrs.getFirewallGroupForQuery()==null?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
				attrs.getGroupNameForQuery() == null?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
				attrs.getGroupNameForQuery() == null?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
				attrs.getFirewallForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
				attrs.getFirewallForQuery()==null?QueryConstants.QUERY_STRING_EXCLUDE:attrs.getFirewallForQuery(),
				attrs.getFirewallNameForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
				attrs.getFirewallNameForQuery()==null?QueryConstants.QUERY_STRING_EXCLUDE:attrs.getFirewallNameForQuery().toUpperCase(),
				attrs.getSourceIpAddressForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
				attrs.getSourceIpAddressForQuery()==null?QueryConstants.QUERY_STRING_EXCLUDE:attrs.getSourceIpAddressForQuery().toUpperCase(),
				attrs.getSourceNatIPForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
				attrs.getSourceNatIPForQuery()==null?QueryConstants.QUERY_STRING_EXCLUDE:attrs.getSourceNatIPForQuery().toUpperCase(),
				attrs.getDestIpAddressForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
				attrs.getDestIpAddressForQuery()==null?QueryConstants.QUERY_STRING_EXCLUDE:attrs.getDestIpAddressForQuery().toUpperCase(),
				attrs.getDestNatIPForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
				attrs.getDestNatIPForQuery()==null?QueryConstants.QUERY_STRING_EXCLUDE:attrs.getDestNatIPForQuery().toUpperCase(),
				attrs.getPortForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
				attrs.getPortForQuery()==null?QueryConstants.QUERY_STRING_EXCLUDE:attrs.getPortForQuery().toUpperCase(),
				attrs.getProtocolForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
				attrs.getProtocolForQuery()==null?QueryConstants.QUERY_STRING_EXCLUDE:attrs.getProtocolForQuery().toUpperCase(),
				attrs.getFirewallGroupForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
				attrs.getFirewallGroupForQuery()==null?QueryConstants.QUERY_STRING_EXCLUDE:attrs.getFirewallGroupForQuery().toUpperCase(),
				attrs.getGroupNameForQuery() == null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
				attrs.getGroupNameForQuery() == null?QueryConstants.QUERY_STRING_EXCLUDE:attrs.getGroupNameForQuery().toUpperCase(),
				attrs.getGroupNameForQuery() == null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
				attrs.getGroupNameForQuery() == null?QueryConstants.QUERY_STRING_EXCLUDE:attrs.getGroupNameForQuery().toUpperCase()
			};
		return
		jdbcTemplate.queryForRowSet(queryToExecute,values
		);
	}
	
	private SqlRowSet getResultSetIpFwPrPcGeneralSearchWithPagination(String queryToExecute,Object attrsObj,int rowNo, int rNo)
	{
		ConIPDetailsSearchAttributes attrs = (ConIPDetailsSearchAttributes) attrsObj;
		return
		jdbcTemplate.queryForRowSet(queryToExecute,
				new Object[]{
				(attrs.getFirewallForQuery()==null && attrs.getFirewallNameForQuery()==null)?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
						(attrs.getFirewallForQuery()==null && attrs.getFirewallNameForQuery()==null)?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
						(attrs.getSourceIpAddressForQuery()==null && attrs.getSourceNatIPForQuery()==null)?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
						(attrs.getDestIpAddressForQuery()==null && attrs.getDestNatIPForQuery()==null)?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
						(attrs.getSourceIpAddressForQuery()==null && attrs.getSourceNatIPForQuery()==null)?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
						(attrs.getDestIpAddressForQuery()==null && attrs.getDestNatIPForQuery()==null)?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
						(attrs.getPortForQuery()==null && attrs.getProtocolForQuery()==null)?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
						(attrs.getPortForQuery()==null && attrs.getProtocolForQuery()==null)?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
						attrs.getFirewallNameForQuery()==null?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,				
						attrs.getFirewallGroupForQuery()==null?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
						attrs.getFirewallGroupForQuery()==null?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
						attrs.getGroupNameForQuery() == null?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
						attrs.getGroupNameForQuery() == null?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
						attrs.getFirewallForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
						attrs.getFirewallForQuery()==null?QueryConstants.QUERY_STRING_EXCLUDE:attrs.getFirewallForQuery(),
						attrs.getFirewallNameForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
						attrs.getFirewallNameForQuery()==null?QueryConstants.QUERY_STRING_EXCLUDE:attrs.getFirewallNameForQuery().toUpperCase(),
						attrs.getSourceIpAddressForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
						attrs.getSourceIpAddressForQuery()==null?QueryConstants.QUERY_STRING_EXCLUDE:attrs.getSourceIpAddressForQuery().toUpperCase(),
						attrs.getSourceNatIPForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
						attrs.getSourceNatIPForQuery()==null?QueryConstants.QUERY_STRING_EXCLUDE:attrs.getSourceNatIPForQuery().toUpperCase(),
						attrs.getDestIpAddressForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
						attrs.getDestIpAddressForQuery()==null?QueryConstants.QUERY_STRING_EXCLUDE:attrs.getDestIpAddressForQuery().toUpperCase(),
						attrs.getDestNatIPForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
						attrs.getDestNatIPForQuery()==null?QueryConstants.QUERY_STRING_EXCLUDE:attrs.getDestNatIPForQuery().toUpperCase(),
						attrs.getPortForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
						attrs.getPortForQuery()==null?QueryConstants.QUERY_STRING_EXCLUDE:attrs.getPortForQuery().toUpperCase(),
						attrs.getProtocolForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
						attrs.getProtocolForQuery()==null?QueryConstants.QUERY_STRING_EXCLUDE:attrs.getProtocolForQuery().toUpperCase(),
						attrs.getFirewallGroupForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
						attrs.getFirewallGroupForQuery()==null?QueryConstants.QUERY_STRING_EXCLUDE:attrs.getFirewallGroupForQuery().toUpperCase(),	
						attrs.getGroupNameForQuery() == null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
						attrs.getGroupNameForQuery() == null?QueryConstants.QUERY_STRING_EXCLUDE:attrs.getGroupNameForQuery().toUpperCase(),
						attrs.getGroupNameForQuery() == null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
				        attrs.getGroupNameForQuery() == null?QueryConstants.QUERY_STRING_EXCLUDE:attrs.getGroupNameForQuery().toUpperCase(),
								rowNo,
								rNo
							});
	}
	
	private SqlRowSet getResultSetIpGeneralSearch(String queryToExecute,Object attrsObj)
	{
		ConIPAddressSearchAttributes attrs = (ConIPAddressSearchAttributes) attrsObj;
		return
		jdbcTemplate.queryForRowSet(queryToExecute,
				new Object[]{
								attrs.getIpAddressForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getIpAddressForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getIpAddressForQuery(),
								attrs.getNatIPForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getNatIPForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getNatIPForQuery(),
								attrs.getIpAddressForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getIpAddressForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getIpAddressForQuery(),
								attrs.getNatIPForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getNatIPForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getNatIPForQuery()
							});
	}
	
	private SqlRowSet getResultSetIpGeneralSearchWithPagination(String queryToExecute,Object attrsObj,int rowNo, int rNo)
	{
		ConIPAddressSearchAttributes attrs = (ConIPAddressSearchAttributes) attrsObj;
		return
		jdbcTemplate.queryForRowSet(queryToExecute,
				new Object[]{
								attrs.getIpAddressForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getIpAddressForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getIpAddressForQuery(),
								attrs.getNatIPForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getNatIPForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getNatIPForQuery(),
								attrs.getIpAddressForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getIpAddressForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getIpAddressForQuery(),
								attrs.getNatIPForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getNatIPForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getNatIPForQuery(),
								rowNo,
								rNo
							});
	}
	
	
	private SqlRowSet getResultSetCnRgScPcAppGeneralSearch(String queryToExecute,Object attrsObj)
	{
		SearchByContactAttributes attrs = (SearchByContactAttributes) attrsObj;
		return
		jdbcTemplate.queryForRowSet(queryToExecute,
				new Object[]{
								(attrs.getContactForQuery()==null && attrs.getContactRoleForQuery()==null)?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
								(attrs.getContactForQuery()==null && attrs.getContactRoleForQuery()==null)?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
								(attrs.getRegionForQuery()==null && attrs.getSectorForQuery()==null)?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
								attrs.getRegionForQuery()==null?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
								attrs.getSectorForQuery()==null?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
								(attrs.getCsiApplicationForQuery()==null && attrs.getFwDeviceForQuery()==null)?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
								attrs.getCsiApplicationForQuery()==null?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
								attrs.getCsiApplicationForQuery()==null?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
								attrs.getFwDeviceForQuery()==null?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
								attrs.getFwDeviceForQuery()==null?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,										
								attrs.getContactForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getContactForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getContactForQuery().toUpperCase(),
								attrs.getContactRoleForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getContactRoleForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getContactRoleForQuery(),
								attrs.getRegionForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getRegionForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getRegionForQuery().longValue(),
								attrs.getSectorForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getSectorForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getSectorForQuery().longValue(),
								attrs.getCsiApplicationForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getCsiApplicationForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getCsiApplicationForQuery().longValue(),
								attrs.getFwDeviceForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getFwDeviceForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getFwDeviceForQuery().toUpperCase()
							});
	}
	
	private SqlRowSet getResultSetCnRgScPcAppGeneralSearchWithPagination(String queryToExecute,Object attrsObj,int rowNo, int rNo)
	{
		SearchByContactAttributes attrs = (SearchByContactAttributes) attrsObj;
		return
		jdbcTemplate.queryForRowSet(queryToExecute,
				new Object[]{
								(attrs.getContactForQuery()==null && attrs.getContactRoleForQuery()==null)?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
								(attrs.getContactForQuery()==null && attrs.getContactRoleForQuery()==null)?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
								(attrs.getRegionForQuery()==null && attrs.getSectorForQuery()==null)?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
								attrs.getRegionForQuery()==null?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
								attrs.getSectorForQuery()==null?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
								(attrs.getCsiApplicationForQuery()==null && attrs.getFwDeviceForQuery()==null)?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
								attrs.getCsiApplicationForQuery()==null?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
								attrs.getCsiApplicationForQuery()==null?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
								attrs.getFwDeviceForQuery()==null?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
								attrs.getFwDeviceForQuery()==null?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,										
								attrs.getContactForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getContactForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getContactForQuery().toUpperCase(),
								attrs.getContactRoleForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getContactRoleForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getContactRoleForQuery(),
								attrs.getRegionForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getRegionForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getRegionForQuery().longValue(),
								attrs.getSectorForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getSectorForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getSectorForQuery().longValue(),
								attrs.getCsiApplicationForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getCsiApplicationForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getCsiApplicationForQuery().longValue(),
								attrs.getFwDeviceForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getFwDeviceForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getFwDeviceForQuery().toUpperCase(),
								rowNo,
								rNo
							});
	}
	
	private SqlRowSet getResultSetPolicyGeneralSearch(String queryToExecute,Object attrsObj)
	{
		ConIPPairFWSearchAttributes attrs = (ConIPPairFWSearchAttributes) attrsObj;
		return
		jdbcTemplate.queryForRowSet(queryToExecute,
				new Object[]{
								attrs.getFirewallForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getFirewallForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getFirewallForQuery()
							});
	}
	
	private SqlRowSet getResultSetPolicyGeneralSearchWithPagination(String queryToExecute,Object attrsObj,int rowNo, int rNo)
	{
		ConIPPairFWSearchAttributes attrs = (ConIPPairFWSearchAttributes) attrsObj;
		return
		jdbcTemplate.queryForRowSet(queryToExecute,
				new Object[]{
								attrs.getFirewallForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getFirewallForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getFirewallForQuery(),
								rowNo,
								rNo
							});
	}
	
	private SqlRowSet getResultSetPortGeneralSearch(String queryToExecute,Object attrsObj)
	{
		ConIPPortSearchAttributes attrs = (ConIPPortSearchAttributes) attrsObj;
		return
		jdbcTemplate.queryForRowSet(queryToExecute,
				new Object[]{
								attrs.getPortForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getPortForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getPortForQuery(),
								attrs.getProtocolForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getProtocolForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getProtocolForQuery()										
							});
	}
	
	private SqlRowSet getResultSetPortGeneralSearchWithPagination(String queryToExecute,Object attrsObj,int rowNo, int rNo)
	{
		ConIPPortSearchAttributes attrs = (ConIPPortSearchAttributes) attrsObj;
		return
		jdbcTemplate.queryForRowSet(queryToExecute,
				new Object[]{
								attrs.getPortForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getPortForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getPortForQuery(),
								attrs.getProtocolForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getProtocolForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getProtocolForQuery(),
								rowNo,
								rNo
							});
	}
	
	private SqlRowSet getResultSetOpeImpGeneralSearch(String queryToExecute,Object attrsObj)
	{
		OpeImpInputSearchAttributes attrs = (OpeImpInputSearchAttributes) attrsObj;
		return
		jdbcTemplate.queryForRowSet(queryToExecute,
				new Object[]{
								attrs.getTpaswgRejectedFromDateForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getTpaswgRejectedFromDateForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getTpaswgRejectedFromDateForQuery(),
								attrs.getTpaswgRejectedToDateForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getTpaswgRejectedToDateForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getTpaswgRejectedToDateForQuery(),
								attrs.getTpaswgReviewFromDateForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getTpaswgReviewFromDateForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getTpaswgReviewFromDateForQuery(),
								attrs.getTpaswgReviewToDateForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getTpaswgReviewToDateForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getTpaswgReviewToDateForQuery(),
								attrs.getTpaswgTempAppFromDateForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getTpaswgTempAppFromDateForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getTpaswgTempAppFromDateForQuery(),
								attrs.getTpaswgTempAppToDateForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getTpaswgTempAppToDateForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getTpaswgTempAppToDateForQuery(),
								attrs.getTpaswgReviewStatusForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getTpaswgReviewStatusForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getTpaswgReviewStatusForQuery(),
								attrs.getTpaswgReviewTypeForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getTpaswgReviewTypeForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getTpaswgReviewTypeForQuery()	
							});
	}
	
	private SqlRowSet getResultSetOpeImpGeneralSearchWithPagination(String queryToExecute,Object attrsObj,int rowNo, int rNo)
	{
		OpeImpInputSearchAttributes attrs = (OpeImpInputSearchAttributes) attrsObj;
		return
		jdbcTemplate.queryForRowSet(queryToExecute,
				new Object[]{
				attrs.getTpaswgRejectedFromDateForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getTpaswgRejectedFromDateForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getTpaswgRejectedFromDateForQuery(),
								attrs.getTpaswgRejectedToDateForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getTpaswgRejectedToDateForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getTpaswgRejectedToDateForQuery(),
								attrs.getTpaswgReviewFromDateForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getTpaswgReviewFromDateForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getTpaswgReviewFromDateForQuery(),
								attrs.getTpaswgReviewToDateForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getTpaswgReviewToDateForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getTpaswgReviewToDateForQuery(),
								attrs.getTpaswgTempAppFromDateForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getTpaswgTempAppFromDateForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getTpaswgTempAppFromDateForQuery(),
								attrs.getTpaswgTempAppToDateForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getTpaswgTempAppToDateForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getTpaswgTempAppToDateForQuery(),
								attrs.getTpaswgReviewStatusForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getTpaswgReviewStatusForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getTpaswgReviewStatusForQuery(),
								attrs.getTpaswgReviewTypeForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getTpaswgReviewTypeForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getTpaswgReviewTypeForQuery(),
								rowNo,
								rNo
							});
	}
	
	private SqlRowSet getResultSetAppsenseGeneralSearch(String queryToExecute,Object attrsObj)
	{
		AppsenseSearchAttributes attrs = (AppsenseSearchAttributes) attrsObj;
		proxyInstanceCheck(attrs);
		return
		jdbcTemplate.queryForRowSet(queryToExecute,
				new Object[]{
								attrs.getApplicationNameForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getApplicationNameForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getApplicationNameForQuery(),
								attrs.getCsiIdForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getCsiIdForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getCsiIdForQuery(),
								attrs.getPolicyNameForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getPolicyNameForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getPolicyNameForQuery(),
								attrs.getUserSOEIdForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getUserSOEIdForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getUserSOEIdForQuery(),
								attrs.getInstanceNameForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getInstanceNameForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getInstanceNameForQuery()
							});
	}
	
	private SqlRowSet getResultSetAppsenseGeneralSearchWithPagination(String queryToExecute,Object attrsObj,int rowNo, int rNo)
	{
		AppsenseSearchAttributes attrs = (AppsenseSearchAttributes) attrsObj;
		proxyInstanceCheck(attrs);
		return
		jdbcTemplate.queryForRowSet(queryToExecute,
				new Object[]{
								attrs.getApplicationNameForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getApplicationNameForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getApplicationNameForQuery(),
								attrs.getCsiIdForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getCsiIdForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getCsiIdForQuery(),
								attrs.getPolicyNameForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getPolicyNameForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getPolicyNameForQuery(),
								attrs.getUserSOEIdForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getUserSOEIdForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getUserSOEIdForQuery(),
								attrs.getInstanceNameForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getInstanceNameForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getInstanceNameForQuery(),
								rowNo,
								rNo
							});
	}
	
    @Transactional(readOnly = true)
    private void proxyInstanceCheck(AppsenseSearchAttributes attrs) {
        if (attrs.getInstanceNameForQuery() != null && !attrs.getInstanceNameForQuery().isEmpty()) {
            String instance = attrs.getInstanceNameForQuery();
            Long proxyId = Long.valueOf(instance);
            Session session = getSession();
            ProxyInstance proxy = (ProxyInstance) session.get(ProxyInstance.class, proxyId);
            if (proxy != null && proxy.getName() != null && !proxy.getName().isEmpty() && proxy.getName().equalsIgnoreCase("--Select Proxy--")) {
                attrs.setInstanceName("");
            }
        }

    }
	
	private SqlRowSet getResultSetProxyGeneralSearch(String queryToExecute,Object attrsObj)
	{
		ProxySearchAttributes attrs = (ProxySearchAttributes) attrsObj;
		String url= null;
		if(attrs.getUrlForQuery()!=null){
			url=attrs.getUrl();
			url=url.replaceAll("%", "~%");
			url=url.replaceAll("&", "&%");
		}
		return
		jdbcTemplate.queryForRowSet(queryToExecute,
				new Object[]{
								attrs.getPrxChangeTypeForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getPrxChangeTypeForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getPrxChangeTypeForQuery(),
								attrs.getRegionForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getRegionForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getRegionForQuery(),
								attrs.getInstanceNameForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getInstanceNameForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getInstanceNameForQuery(),
								attrs.getSourceIpAddressForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getSourceIpAddressForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getSourceIpAddressForQuery(),
								attrs.getExternalIpAddressForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getExternalIpAddressForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getExternalIpAddressForQuery(),
								StringUtil.isNullorEmpty(attrs.getSourceFQDN())?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								StringUtil.isNullorEmpty(attrs.getSourceFQDN())?QueryConstants.QUERY_INCLUDE:attrs.getSourceFQDN(),
								StringUtil.isNullorEmpty(attrs.getDestinationFQDN())?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								StringUtil.isNullorEmpty(attrs.getDestinationFQDN())?QueryConstants.QUERY_INCLUDE:attrs.getDestinationFQDN(),
								attrs.getDomainNameForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getDomainNameForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getDomainNameForQuery(),
								url==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								url==null?QueryConstants.QUERY_INCLUDE:url
							});
	}
	
	private SqlRowSet getResultSetProxyGeneralSearchWithPagination(String queryToExecute,Object attrsObj,int rowNo, int rNo)
	{
		ProxySearchAttributes attrs = (ProxySearchAttributes) attrsObj;
		String url= null;
		if(attrs.getUrlForQuery()!=null){
			url=attrs.getUrl();
			url=url.replaceAll("%", "~%");
			url=url.replaceAll("&", "&%");
		}
		return
		jdbcTemplate.queryForRowSet(queryToExecute,
				new Object[]{
								attrs.getPrxChangeTypeForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getPrxChangeTypeForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getPrxChangeTypeForQuery(),
								attrs.getRegionForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getRegionForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getRegionForQuery(),
								attrs.getInstanceNameForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getInstanceNameForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getInstanceNameForQuery(),
								attrs.getSourceIpAddressForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getSourceIpAddressForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getSourceIpAddressForQuery(),
								attrs.getExternalIpAddressForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getExternalIpAddressForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getExternalIpAddressForQuery(),
								StringUtil.isNullorEmpty(attrs.getSourceFQDN())?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								StringUtil.isNullorEmpty(attrs.getSourceFQDN())?QueryConstants.QUERY_INCLUDE:attrs.getSourceFQDN(),
								StringUtil.isNullorEmpty(attrs.getDestinationFQDN())?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								StringUtil.isNullorEmpty(attrs.getDestinationFQDN())?QueryConstants.QUERY_INCLUDE:attrs.getDestinationFQDN(),
								attrs.getDomainNameForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								attrs.getDomainNameForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getDomainNameForQuery(),
								url==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								url==null?QueryConstants.QUERY_INCLUDE:url,
								rowNo,
								rNo
							});
	}
	
	private SqlRowSet getResultSetGeneralSearch(String queryToExecute,Object attrsObj, String queryType)
	{
		GeneralSearchAttributes attrs = (GeneralSearchAttributes) attrsObj;
		String version = null;
		String procId = null;
		if(queryType.equalsIgnoreCase(QueryConstants.QUERY_TO_EXECUTE_FOR_REQUESTER_BUSINESS_OWNER)) {
		    if(StringUtil.isNullorEmpty(attrs.getBusinessOwnerSOEId())) {
		        return null;
		    }
		}
		if(attrs.getProcessIdForQuery()!=null){
			procId = attrs.getProcessIdForQuery();
			if(procId.indexOf(".")>-1){
				procId = procId.substring(0,procId.indexOf("."));
			}
		}
		if(attrs.getVersionNoForQuery()!=null){
			version = attrs.getVersionNoForQuery();
			if(version.indexOf(".")>-1){
				version = version.substring(0,version.indexOf("."));
			}
		}
        String gocCode = getGocCode(attrs.getGocCodeForQuery());
        String cmpReqIdForQuery = attrs.getCMPIDforQuery();
        if (cmpReqIdForQuery != null && cmpReqIdForQuery.length() >= 4) {

            cmpReqIdForQuery = cmpReqIdForQuery + "%";
        }

		return
		jdbcTemplate.queryForRowSet(queryToExecute,
				new Object[]{
							attrs.getDataClassificationForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							attrs.getDataClassificationForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getDataClassificationForQuery().longValue(),
							attrs.getThirdPartyForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							attrs.getThirdPartyForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getThirdPartyForQuery(),							
							attrs.getBusinessUnitForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							attrs.getBusinessUnitForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getBusinessUnitForQuery(),
							attrs.getSectorForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							attrs.getSectorForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getSectorForQuery().longValue(),		
							attrs.getRegionForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							attrs.getRegionForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getRegionForQuery().longValue(),
							attrs.getRequesterSOEIdForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							attrs.getRequesterSOEIdForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getRequesterSOEIdForQuery(),
							StringUtil.isNullorEmpty(attrs.getBusinessOwnerSOEId())?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							StringUtil.isNullorEmpty(attrs.getBusinessOwnerSOEId())?QueryConstants.QUERY_INCLUDE:attrs.getBusinessOwnerSOEId().toUpperCase(),
							StringUtil.isNullorEmpty(attrs.getBusinessOwnerSOEId())?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							StringUtil.isNullorEmpty(attrs.getBusinessOwnerSOEId())?QueryConstants.QUERY_INCLUDE:QueryConstants.BUSINESS_OWNER_ROLE_ID,        
							attrs.getPriorityForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							attrs.getPriorityForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getPriorityForQuery().longValue(),
							attrs.getTaskCodeForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							attrs.getTaskCodeForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getTaskCodeForQuery().longValue(),							
							attrs.getRelationshipNameForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							attrs.getRelationshipNameForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getRelationshipNameForQuery(),
							attrs.getRelationshipIdForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							attrs.getRelationshipIdForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getRelationshipIdForQuery(),		
							attrs.getProcessNameForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							attrs.getProcessNameForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getProcessNameForQuery(),
                                cmpReqIdForQuery == null ? QueryConstants.QUERY_INCLUDE : QueryConstants.QUERY_EXCLUDE,
                                cmpReqIdForQuery == null ? QueryConstants.QUERY_INCLUDE : cmpReqIdForQuery,
							attrs.getServiceNowIDForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							attrs.getServiceNowIDForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getServiceNowIDForQuery(),
							attrs.getCaspIDForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							attrs.getCaspIDForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getCaspID(),	
							attrs.getCaspDetailIDForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							attrs.getCaspDetailIDForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getCaspDetailID(),	
							gocCode==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							gocCode==null?QueryConstants.QUERY_INCLUDE:gocCode,
							attrs.getNotesForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
				            attrs.getNotesForQuery()==null?QueryConstants.QUERY_INCLUDE:"%"+attrs.getNotesForQuery()+"%",
				            attrs.getTagForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
				            attrs.getTagForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getTagForQuery(),
							procId==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							procId==null?QueryConstants.QUERY_INCLUDE:procId,
							version==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							version==null?QueryConstants.QUERY_INCLUDE:version
						});
		
		
	}
	
	private SqlRowSet getResultSetGeneralSearchWithPagination(String queryToExecute,Object attrsObj,int rowNo, int rNo, String queryType)
	{
		GeneralSearchAttributes attrs = (GeneralSearchAttributes) attrsObj;
		String version = null;
		String procId = null;
		if(queryType.equalsIgnoreCase(QueryConstants.QUERY_TO_EXECUTE_FOR_REQUESTER_BUSINESS_OWNER)) {
            if(StringUtil.isNullorEmpty(attrs.getBusinessOwnerSOEId())) {
                return null;
            }
        }
		if(attrs.getProcessIdForQuery()!=null){
			procId = attrs.getProcessIdForQuery();
			if(procId.indexOf(".")>-1){
				procId = procId.substring(0,procId.indexOf("."));
			}
		}
		if(attrs.getVersionNoForQuery()!=null){
			version = attrs.getVersionNoForQuery();
			if(version.indexOf(".")>-1){
				version = version.substring(0,version.indexOf("."));
			}
		}
		String gocCode = getGocCode(attrs.getGocCodeForQuery());
		   String cmpReqIdForQuery = attrs.getCMPIDforQuery();
	        if(cmpReqIdForQuery!=null && cmpReqIdForQuery.length()>=4){
	            cmpReqIdForQuery=cmpReqIdForQuery+"%";
	        }
	        

		return
		jdbcTemplate.queryForRowSet(queryToExecute,
				new Object[]{
							attrs.getDataClassificationForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							attrs.getDataClassificationForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getDataClassificationForQuery().longValue(),
							attrs.getThirdPartyForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							attrs.getThirdPartyForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getThirdPartyForQuery(),							
							attrs.getBusinessUnitForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							attrs.getBusinessUnitForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getBusinessUnitForQuery(),
							attrs.getSectorForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							attrs.getSectorForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getSectorForQuery().longValue(),		
							attrs.getRegionForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							attrs.getRegionForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getRegionForQuery().longValue(),
							attrs.getRequesterSOEIdForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							attrs.getRequesterSOEIdForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getRequesterSOEIdForQuery(),
							StringUtil.isNullorEmpty(attrs.getBusinessOwnerSOEId())?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							StringUtil.isNullorEmpty(attrs.getBusinessOwnerSOEId())?QueryConstants.QUERY_INCLUDE:attrs.getBusinessOwnerSOEId().toUpperCase(),
							StringUtil.isNullorEmpty(attrs.getBusinessOwnerSOEId())?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							StringUtil.isNullorEmpty(attrs.getBusinessOwnerSOEId())?QueryConstants.QUERY_INCLUDE:QueryConstants.BUSINESS_OWNER_ROLE_ID,
							attrs.getPriorityForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							attrs.getPriorityForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getPriorityForQuery().longValue(),
							attrs.getTaskCodeForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							attrs.getTaskCodeForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getTaskCodeForQuery().longValue(),							
							attrs.getRelationshipNameForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							attrs.getRelationshipNameForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getRelationshipNameForQuery(),
							attrs.getRelationshipIdForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							attrs.getRelationshipIdForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getRelationshipIdForQuery(),		
							attrs.getProcessNameForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							attrs.getProcessNameForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getProcessNameForQuery(),
                                cmpReqIdForQuery == null ? QueryConstants.QUERY_INCLUDE : QueryConstants.QUERY_EXCLUDE,
                                cmpReqIdForQuery == null ? QueryConstants.QUERY_INCLUDE : cmpReqIdForQuery,
                                 attrs.getServiceNowIDForQuery()==null ? QueryConstants.QUERY_INCLUDE : QueryConstants.QUERY_EXCLUDE,
							attrs.getServiceNowIDForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getServiceNowIDForQuery(),
							attrs.getCaspIDForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							attrs.getCaspIDForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getCaspID(),	
							attrs.getCaspDetailIDForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							attrs.getCaspDetailIDForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getCaspDetailID(),	
							gocCode==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							gocCode==null?QueryConstants.QUERY_INCLUDE:gocCode,
							attrs.getNotesForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
				            attrs.getNotesForQuery()==null?QueryConstants.QUERY_INCLUDE:"%"+attrs.getNotesForQuery()+"%",
				            attrs.getTagForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
				            attrs.getTagForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getTagForQuery(),
							procId==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							procId==null?QueryConstants.QUERY_INCLUDE:procId,
							version==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
							version==null?QueryConstants.QUERY_INCLUDE:version,
							rowNo,
							rNo
						});
		
	}
	
	private String getGocCode(String gocCode) {
	    gocCode = StringUtil.trim(gocCode);
        if (!StringUtil.isNullorEmpty(gocCode)) {
            if (gocCode.contains(ECMConstants.WILD_CARD_ASTERISK)) {
                if (gocCode.startsWith(ECMConstants.WILD_CARD_ASTERISK)
                        && !(gocCode.endsWith(ECMConstants.WILD_CARD_ASTERISK))) {
                    gocCode = "%" + gocCode;
                } else if (gocCode.endsWith(ECMConstants.WILD_CARD_ASTERISK)
                        && !(gocCode.startsWith(ECMConstants.WILD_CARD_ASTERISK))) {
                    gocCode = gocCode + "%";
                } else if (gocCode.startsWith(ECMConstants.WILD_CARD_ASTERISK)
                        && gocCode.endsWith(ECMConstants.WILD_CARD_ASTERISK)) {
                    gocCode = "%" + gocCode + "%";
                }
                gocCode = gocCode.replace(ECMConstants.WILD_CARD_ASTERISK, ECMConstants.EMPTY_STRING);
            }
        }
        return gocCode;
    }

    //Added for 47403 starts
	//Search by sec acl name and device name 
	private SqlRowSet getResultSetSecAclGeneralSearch(String queryToExecute,Object attrsObj)
	{
		SecAclSearchAttributes attrs = (SecAclSearchAttributes) attrsObj;
		String name= null , device = null, n1 = null, d1 = null;
		if(!(attrs.getAclName()==null || attrs.getAclName().isEmpty())){
			name=attrs.getAclName();
			name=name.replaceAll("\\*", "%");
			log.debug("name : " +name +n1);
		}
		if(!(attrs.getAclDevice()==null || attrs.getAclDevice().isEmpty())){
			device=attrs.getAclDevice();
			device=device.replaceAll("\\*", "%");
			log.debug("device : " +device +d1);
		}
		
		return
		jdbcTemplate.queryForRowSet(queryToExecute,
				new Object[]{
								(attrs.getAclName()==null || attrs.getAclName().isEmpty())?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								(attrs.getAclName()==null || attrs.getAclName().isEmpty())?QueryConstants.QUERY_INCLUDE:name,
								(attrs.getAclDevice()==null || attrs.getAclDevice().isEmpty())?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								(attrs.getAclDevice()==null || attrs.getAclDevice().isEmpty())?QueryConstants.QUERY_INCLUDE:device
							});
	}
	
	private SqlRowSet getResultSetSecAclGeneralSearchWithPagination(String queryToExecute,Object attrsObj,int rowNo, int rNo)
	{
		SecAclSearchAttributes attrs = (SecAclSearchAttributes) attrsObj;
		String name= null , device = null;
		if(!(attrs.getAclName()==null || attrs.getAclName().isEmpty())){
			name=attrs.getAclName();
			name=name.replaceAll("\\*", "%");
			log.debug("name : " +name);
		}
		if(!(attrs.getAclDevice()==null || attrs.getAclDevice().isEmpty())){
			device=attrs.getAclDevice();
			device=device.replaceAll("\\*", "%");
			log.debug("device : " +device);
		}
		
		return
		jdbcTemplate.queryForRowSet(queryToExecute, 
				new Object[]{
								(attrs.getAclName()==null || attrs.getAclName().isEmpty())?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								(attrs.getAclName()==null || attrs.getAclName().isEmpty())?QueryConstants.QUERY_INCLUDE:name,
								(attrs.getAclDevice()==null || attrs.getAclDevice().isEmpty())?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
								(attrs.getAclDevice()==null || attrs.getAclDevice().isEmpty())?QueryConstants.QUERY_INCLUDE:device,
								rowNo,
								rNo
							});
	}
	
	//Added for 47403 ends
	/**
	 * Gets the count.
	 *
	 * @param condition the condition
	 * @param groupByClause the group by clause
	 * @param orderByClause the order by clause
	 * @return the count
	 * @throws DatabaseException the database exception
	 */
	private int  getMyTasksCount(String lockedby) throws DatabaseException {

		int cnt=0;
		String queryToExecute = ccrQueries.getQueryByName(QueryConstants.MY_LOCKED_TASKS_COUNT);
		try {
			 
			SqlRowSet rs  =  jdbcTemplate.queryForRowSet(queryToExecute,new Object[]{lockedby});
			if(rs.next()) {
				cnt= rs.getInt(1);
			}
			if(cnt==11)
				cnt=10;
		} catch (Exception e) {
			throw new DatabaseException("Could not run query = " + queryToExecute, e);
		} 
		return cnt;
	}
	
	
	public int getSearchRecordCount(Object attrs, int pageSize, int pageNum) throws Exception {
		String condition = "";
		condition =getConditions(attrs);
		int resultCount = getCount(condition, "", "");
		return resultCount;
	}
	
	public int getGeneralSearchRecordCount(Object attrs) throws Exception {
		return getGeneralSearchQueryCount(attrs);
	}
	
	public int getGeneralSearchApplicationRecordCount(Object attrs) throws Exception {
		return getGeneralSearchApplicationQueryCount(attrs);
	}
	
	public int getGeneralSearchIpFwPrPcRecordCount(Object attrs) throws Exception {
		return getGeneralSearchIpFwPrPcQueryCount(attrs);
	}
	
	public int getGeneralSearchIpFwPrPcRecordTerminatedCount(Object attrs) throws Exception {
        return getGeneralSearchIpFwPrPcQueryCount_TerminatedIds(attrs);
    }
    
	public int getGeneralSearchIpRecordCount(Object attrs) throws Exception {
		return getGeneralSearchIpQueryCount(attrs);
	}
	
	public int getGeneralSearchCnRgScPcAppRecordCount(Object attrs) throws Exception {
		return getGeneralSearchCnRgScPcAppQueryCount(attrs);
	}
	
	public int getGeneralSearchPolicyRecordCount(Object attrs) throws Exception {
		return getGeneralSearchPolicyQueryCount(attrs);
	}
	
	public int getGeneralSearchPortRecordCount(Object attrs) throws Exception {
		return getGeneralSearchPortQueryCount(attrs);
	}
	
	public int getGeneralSearchOpeImpRecordCount(Object attrs) throws Exception {
		return getGeneralSearchOpeImpQueryCount(attrs);
	}
	
	public int getGeneralSearchAppsenseRecordCount(Object attrs) throws Exception {
		return getGeneralSearchAppsenseQueryCount(attrs);
	}
	
	public int getGeneralSearchProxyRecordCount(Object attrs) throws Exception {
		return getGeneralSearchProxyQueryCount(attrs);
	}
	
	//Added for 47403 starts
	//Search by sec acl name and device name 
	public int getGeneralSearchSecAclRecordCount(Object attrs) throws Exception {
		return getGeneralSearchSecAclQueryCount(attrs);
	}
	//Added for 47403 ends
	
	
	public List getSearchResult(Object attrs, int pageSize, int pageNum) throws Exception{
		String condition = "";
		condition =getConditions(attrs);
		log.debug("condition........ : " +condition.toString()); 
		List result = runQuery(condition.toString(), "", "id DESC", pageNum, pageSize);
		return result;
	}
	
	
	public List getGeneralSearchRecord(Object attrs, int pageSize, int pageNum, int recCnt) throws Exception{
		return runGeneralSearchQuery(attrs,pageNum, pageSize,recCnt);
	}
	
	public List getGeneralSearchApplicationResult(Object attrs, int pageSize, int pageNum, int recCnt) throws Exception{
		return runGeneralSearchApplicationQuery(attrs,pageNum, pageSize,recCnt);
	}
	
	public List getGeneralSearchIpFwPrPcResult(Object attrs, int pageSize, int pageNum, int recCnt) throws Exception{
		return runGeneralSearchIpFwPrPcQuery(attrs,pageNum, pageSize,recCnt);
	}
	//newly added.
	public List getGeneralSearchIpFwPrPc_Terminated_Result(Object attrs, int pageSize, int pageNum, int recCnt) throws Exception{
        return runGeneralSearchIpFwPrPcQuery_Terminated(attrs,pageNum, pageSize,recCnt);
    }
	
	public List getGeneralSearchIpResult(Object attrs, int pageSize, int pageNum, int recCnt) throws Exception{
		return runGeneralSearchIpQuery(attrs,pageNum, pageSize,recCnt);
	}
	
	public List getGeneralSearchCnRgScPcAppResult(Object attrs, int pageSize, int pageNum, int recCnt) throws Exception{
		return runGeneralSearchCnRgScPcAppQuery(attrs,pageNum, pageSize,recCnt);
	}
	
	public List getGeneralSearchPolicyResult(Object attrs, int pageSize, int pageNum, int recCnt) throws Exception{
		return runGeneralSearchPolicyQuery(attrs,pageNum, pageSize,recCnt);
	}
	
	public List getGeneralSearchPortResult(Object attrs, int pageSize, int pageNum, int recCnt) throws Exception{
		return runGeneralSearchPortQuery(attrs,pageNum, pageSize,recCnt);
	}
	
	public List getGeneralSearchOpeImpResult(Object attrs, int pageSize, int pageNum, int recCnt) throws Exception{
		return runGeneralSearchOpeImpQuery(attrs,pageNum, pageSize,recCnt);
	}
	
	public List getGeneralSearchAppsenseResult(Object attrs, int pageSize, int pageNum, int recCnt) throws Exception{
		return runGeneralSearchAppsenseQuery(attrs,pageNum, pageSize,recCnt);
	}
	
	public List getGeneralSearchProxyResult(Object attrs, int pageSize, int pageNum, int recCnt) throws Exception{
		return runGeneralSearchProxyQuery(attrs,pageNum, pageSize,recCnt);
	}
	
	//Added for 47403 starts
	//Search by sec acl name and device name 
	public List getGeneralSearchSecAclResult(Object attrs, int pageSize, int pageNum, int recCnt) throws Exception{
		return runGeneralSearchSecAclQuery(attrs,pageNum, pageSize,recCnt);
	}
	//Added for 47403 ends
	
	public int getMyTaskRecordCount(String ssoid, int pageSize, int pageNum)
			throws Exception {
		String queryToExecute = ccrQueries.getQueryByName(QueryConstants.QUERY_COUNT_MY_TASK);
 
		int cnt = 0;
		log.debug("getMyTaskRecordCount:Sql is :- " + queryToExecute);
 
		try {
			SqlRowSet rs  =  jdbcTemplate.queryForRowSet(queryToExecute,new Object[]{ssoid});
			if (rs.next())  
				cnt = rs.getInt(1);
			 
			if (cnt == 11){
				cnt = 10;
			}
		} catch (Exception e) {
			log.error(e,e);
			throw new DatabaseException("Could not run query: "+ queryToExecute, e);
		}  
		return cnt;
	}
	
		
	public int getMyTaskContactRecordCount(Object attrsObj, int pageSize, int pageNum)
		throws Exception {
		String queryToExecute=ccrQueries.getQueryByName(QueryConstants.QUERY_COUNT_MY_TASK_CONTACT);
	 
		int cnt = 0;
		String name ="";
		GeneralSearchAttributes attrs = new GeneralSearchAttributes();
		if(attrsObj instanceof GeneralSearchAttributes){
		attrs = (GeneralSearchAttributes) attrsObj;
		}
		log.debug("getMyTaskRecordCount:Sql is :- " + queryToExecute);
		 
 
		try {
			String soeId = attrs.getRequesterSOEId().toUpperCase();
			if(!(attrs.getProcessName()==null || attrs.getProcessName().isEmpty())){
				name=attrs.getProcessName();
				name=name.replaceAll("\\*", "%");
				log.debug("name" +name );
			}
			SqlRowSet rs  =  jdbcTemplate.queryForRowSet(queryToExecute,
					new Object[] {
					soeId,
					attrs.getTaskCodeForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
					attrs.getTaskCodeForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getTaskCodeForQuery().longValue(),
					"lessThan7".equals(attrs.getTimeInActivityForQuery())?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
					"lessThan30".equals(attrs.getTimeInActivityForQuery())?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
					"greaterThan60".equals(attrs.getTimeInActivityForQuery())?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
					"between30And60".equals(attrs.getTimeInActivityForQuery())?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
					attrs.getRoleForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
					attrs.getRoleForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getRoleForQuery().longValue(),
					attrs.getRegionForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
					attrs.getRegionForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getRegionForQuery().longValue(),
					attrs.getSectorForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
					attrs.getSectorForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getSectorForQuery().longValue(),
					(attrs.getProcessName()==null || attrs.getProcessName().isEmpty())?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
					(attrs.getProcessName()==null || attrs.getProcessName().isEmpty())?QueryConstants.QUERY_INCLUDE:name,
					soeId,
					attrs.getTaskCodeForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
					attrs.getTaskCodeForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getTaskCodeForQuery().longValue(),
					"lessThan7".equals(attrs.getTimeInActivityForQuery())?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
					"lessThan30".equals(attrs.getTimeInActivityForQuery())?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
					"greaterThan60".equals(attrs.getTimeInActivityForQuery())?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
					"between30And60".equals(attrs.getTimeInActivityForQuery())?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
					attrs.getRoleForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
					attrs.getRoleForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getRoleForQuery().longValue(),
					attrs.getRegionForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
					attrs.getRegionForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getRegionForQuery().longValue(),
					attrs.getSectorForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
					attrs.getSectorForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getSectorForQuery().longValue(),
					(attrs.getProcessName()==null || attrs.getProcessName().isEmpty())?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
					(attrs.getProcessName()==null || attrs.getProcessName().isEmpty())?QueryConstants.QUERY_INCLUDE:name});
			
	
			if (rs.next()) {
				cnt = rs.getInt(1);
			}
			if (cnt == 11){
				cnt = 10;
			}
			log.debug("Record Count:cnt:"+cnt);
		 
		} catch (Exception e) {
			log.error(e.toString(),e);
			throw new DatabaseException("Could not run query = "+ queryToExecute, e);
		}  
		
		return cnt;
	}
	
		 
	public  List<Object> getMyTaskSearchResult(String lockedby, int pageSize, int pageNum)
			throws Exception {
		List<Object> list = new ArrayList<Object>();
		if (pageNum == 0)
			throw new RuntimeException("Page Number should start at 1");
		
		int rowNum = 0;
		int rNum = 0;

		String queryToExecute;
		SqlRowSet rs  = null;
		Object obj = null;
	 
		int recCnt = getMyTasksCount(lockedby);
		
		if (recCnt > pageSize){
			rowNum = (pageNum * pageSize);
			rNum = (pageNum * pageSize) - pageSize + 1;
			queryToExecute = ccrQueries.getQueryByName(QueryConstants.MY_LOCKED_TASKS_WITH_PAGINATION);
		}else{
			queryToExecute = ccrQueries.getQueryByName(QueryConstants.MY_LOCKED_TASKS);
		}
		 
		try {
			if (recCnt > pageSize) {
				rs  =  jdbcTemplate.queryForRowSet(queryToExecute, new Object[]{lockedby,rowNum,rNum});
			}else{
				rs  =  jdbcTemplate.queryForRowSet(queryToExecute, new Object[]{lockedby});
			}
			
			for (;rs.next(); list.add(obj)){ 
				obj = createMyTasksModel(rs);
			}
		} catch (Exception e) {
			log.error("Exception during query :- " + e);
			throw new DatabaseException("Could not run query: "	+ queryToExecute, e);
		}  
		return list;
	}
	
	public  List<Object> getMyContactTaskSearchResult(Object attrsObj, int pageSize, int pageNum, int recCnt) throws Exception {
		List<Object> list = new ArrayList<Object>();
		if (pageNum == 0){
			throw new RuntimeException("Page Number should start at 1");
		}
		int rowNum = 0;
		int rNum = 0;
		
		if (recCnt > pageSize) {
			rowNum = (pageNum * pageSize);
			rNum = (pageNum * pageSize) - pageSize + 1;
		}
		SqlRowSet rs  = null;
		Object obj = null;
	 
		try {
			if (recCnt > pageSize) {
				rs  = getContactSearchForMyContactWithPagination(attrsObj,rowNum,rNum);
			}else{
				rs  = getContactSearchForMyContact(attrsObj);
			}
	
			for (; rs.next(); list.add(obj)) {
				obj = createMyContactTasksModel(rs);
			}
		} catch (Exception e) {
			log.error("Exception during query :- " + e);
			throw new DatabaseException("Exception = ", e);
		}  
		return list;
	}
	
	private  SqlRowSet getContactSearchForMyContact(Object attrsObj) throws Exception {
		SqlRowSet rs  = null;
		String name = "";
		if(attrsObj instanceof GeneralSearchAttributes){
			GeneralSearchAttributes attrs = (GeneralSearchAttributes)attrsObj;
			String queryToExecute = ccrQueries.getQueryByName(QueryConstants.GET_MYTASK_WITH_ENTITLEMENT);
			try {
				String soeId = attrs.getRequesterSOEId().toUpperCase();
				if(!(attrs.getProcessName()==null || attrs.getProcessName().isEmpty())){
					name=attrs.getProcessName();
					name=name.replaceAll("\\*", "%");
					log.debug("name" +name );
				}
				rs  =  jdbcTemplate.queryForRowSet(queryToExecute,
						new Object[] {
										soeId,
										attrs.getTaskCodeForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
										attrs.getTaskCodeForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getTaskCodeForQuery().longValue(),
										"lessThan7".equals(attrs.getTimeInActivityForQuery())?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
										"lessThan30".equals(attrs.getTimeInActivityForQuery())?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
										"greaterThan60".equals(attrs.getTimeInActivityForQuery())?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
										"between30And60".equals(attrs.getTimeInActivityForQuery())?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,									attrs.getRoleForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
										attrs.getRoleForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getRoleForQuery().longValue(),
										attrs.getRegionForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
										attrs.getRegionForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getRegionForQuery().longValue(),
										attrs.getSectorForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
										attrs.getSectorForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getSectorForQuery().longValue(),
										(attrs.getProcessName()==null || attrs.getProcessName().isEmpty())?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
										(attrs.getProcessName()==null || attrs.getProcessName().isEmpty())?QueryConstants.QUERY_INCLUDE:name,
										attrs.getActualRequestor(),
										attrs.getActualRequestor()
								});
		
			} catch (Exception e) {
				log.error(e,e);
				throw new DatabaseException("Could not run query = "+ queryToExecute, e);
			} 
		}
		return rs;
	}
	
	private  SqlRowSet getContactSearchForMyContactWithPagination(Object attrsObj, int rowNumber, int rNum) throws Exception {
		SqlRowSet rs  = null;
		String name ="";
		if(attrsObj instanceof GeneralSearchAttributes)
		{
		GeneralSearchAttributes attrs = (GeneralSearchAttributes)attrsObj;
		String queryToExecute = ccrQueries.getQueryByName(QueryConstants.GET_MYTASK_WITH_ENTITLEMENT_PAGINATION);
		try {
			String soeId = attrs.getRequesterSOEId().toUpperCase();
			if(!(attrs.getProcessName()==null || attrs.getProcessName().isEmpty())){
				name=attrs.getProcessName();
				name=name.replaceAll("\\*", "%");
				log.debug("name" +name );
			}
			rs  =  jdbcTemplate.queryForRowSet(queryToExecute,
					new Object[] {
									soeId,
									attrs.getTaskCodeForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
									attrs.getTaskCodeForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getTaskCodeForQuery().longValue(),
									"lessThan7".equals(attrs.getTimeInActivityForQuery())?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
									"lessThan30".equals(attrs.getTimeInActivityForQuery())?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
									"greaterThan60".equals(attrs.getTimeInActivityForQuery())?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
									"between30And60".equals(attrs.getTimeInActivityForQuery())?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
									attrs.getRoleForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
									attrs.getRoleForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getRoleForQuery().longValue(),
									attrs.getRegionForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
									attrs.getRegionForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getRegionForQuery().longValue(),
									attrs.getSectorForQuery()==null?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
									attrs.getSectorForQuery()==null?QueryConstants.QUERY_INCLUDE:attrs.getSectorForQuery().longValue(),
									(attrs.getProcessName()==null || attrs.getProcessName().isEmpty())?QueryConstants.QUERY_INCLUDE:QueryConstants.QUERY_EXCLUDE,
									(attrs.getProcessName()==null || attrs.getProcessName().isEmpty())?QueryConstants.QUERY_INCLUDE:name,
									attrs.getActualRequestor(),
									attrs.getActualRequestor(),
									rowNumber,
									rNum
							});
	
		} catch (Exception e) {
			log.error(e,e);
			throw new DatabaseException("Could not run query = "+ queryToExecute, e);
		} 
		}
		return rs;
	}
	

	public  List<LookupDTO> getMyTaskContactPageDropdownList(Object attrsObj, String type)throws Exception {
		LookupDTO obj = null;
		List<LookupDTO> objList = new ArrayList<LookupDTO>();
		String queryToExecute = "";
		GeneralSearchAttributes attrs = new GeneralSearchAttributes();
		if(attrsObj instanceof GeneralSearchAttributes){
			attrs = (GeneralSearchAttributes) attrsObj;
		}
		
		if(LISTTYPE_ROLE.equals(type) ){
			queryToExecute = ccrQueries.getQueryByName(QueryConstants.GET_ROLE_DETAILS_IN_MYTASK);
	  	}else if (LISTTYPE_TASK.equals(type)){
	  		queryToExecute = ccrQueries.getQueryByName(QueryConstants.GET_TASK_DETAILS_IN_MYTASK);
	  		
	  	}else if(LISTTYPE_REGION.equals(type)){
	  		queryToExecute = ccrQueries.getQueryByName(QueryConstants.GET_REGION_DETAILS_IN_MYTASK);
	  	}else{
	  		queryToExecute = ccrQueries.getQueryByName(QueryConstants.GET_SECTOR_DETAILS_IN_MYTASK);
	  	}
	  	try {
			String	soeId = attrs.getRequesterSOEId().toUpperCase();
			SqlRowSet rs  =  jdbcTemplate.queryForRowSet(queryToExecute,
					new Object[] {
									soeId,
									LISTTYPE_SECTOR.equals(type) && attrs.getRegionForQuery()!=null?QueryConstants.QUERY_EXCLUDE:QueryConstants.QUERY_INCLUDE,
									LISTTYPE_SECTOR.equals(type) && attrs.getRegionForQuery()!=null?attrs.getRegionForQuery().longValue():QueryConstants.QUERY_INCLUDE,
								 });

			 for (; rs.next(); objList.add(obj)){ 
	    		obj = new LookupDTO(rs.getLong(1),rs.getString(2),null);
			 }
	  	} catch (Exception e) {
		 	log.error("Exception during query :- " + e);
		 	throw new DatabaseException("Could not run query = " + queryToExecute, e);
	  	}
	 
		log.debug("Size of Value Object List is "+ objList.size());

		return objList;
	}
	
	

	/**
	 * Gets the query select string.
	 *
	 * @return the query select string
	 */
	private String getQuerySelectString() {
		querySelect = ccrQueries.getQueryByName(QueryConstants.QUERY_TASK_STRING);
		log.info("querySelect:-"+querySelect);
		return querySelect;
	}
	
 
	
	/**
	 * Gets the query select string.
	 *
	 * @return the query select string
	 */
	private String getMyTaskQuerySelect(String ssoid) {
		return ccrQueries.getQueryByName(QueryConstants.QUERY_TASK_SELECT).replace("@SSO_ID@",ssoid.trim());
	}
	
	
	/**
	 * Creates the model.
	 *
	 * @param rs the rs
	 * @return the object
	 * @throws DatabaseException the database exception
	 * @throws SQLException the sQL exception
	 */
	private Object createModel(SqlRowSet rs) throws DatabaseException {
		Process processObj = new Process();
		processObj.setId(Long.valueOf(rs.getLong(1)));
		processObj.setVersion_number(Long.valueOf(rs.getLong(2)));
		processObj.setDisplay_id(rs.getString(3));
		processObj.setName(rs.getString(4));
		processObj.setStatus(rs.getString(5));
		processObj.setPhase(rs.getString(6));
		processObj.setType(rs.getString(7));
		processObj.setTiProcess(rs.getString(8));
		processObj.setRole(rs.getString(9));
		processObj.setPriority(rs.getString(10));
		processObj.setParticipant(rs.getString(11));
		processObj.setTirequestid(Long.valueOf(rs.getLong(12)));
		processObj.setBmpInstanceId(rs.getString(13));
		processObj.setBpmActivityId(rs.getString(14));
		processObj.setTaskName(rs.getString(15));
		processObj.setBpmProcessName(rs.getString(16));
		processObj.setTaskCode(rs.getString(17));
		return processObj;
	}
	
	/**
	 * Creates the model.
	 *
	 * @param rs the rs
	 * @return the object
	 * @throws DatabaseException the database exception
	 * @throws SQLException the sQL exception
	 */
	private Object createMyTasksModel(SqlRowSet rs) throws DatabaseException {
		Process processObj = new Process();
		processObj.setDisplay_id(rs.getString(1));
		processObj.setName(rs.getString(2));
		processObj.setTirequestid(Long.valueOf(rs.getLong(3)));
		processObj.setBmpInstanceId(rs.getString(4));
		processObj.setBpmActivityId(rs.getString(5));
		processObj.setTaskName(rs.getString(6));
		processObj.setActivityCode(rs.getString(7));
		
		if(rs.getTimestamp(8)!= null){
			processObj.setLockedDate(formater.format(rs.getTimestamp(8)));
		}
		processObj.setId(rs.getLong(9));
		processObj.setActivityId(rs.getLong(10));

		return processObj;
	}
	
	 
	private Object createMyContactTasksModel(SqlRowSet rs) throws DatabaseException {
		Process processObj = new Process();
		processObj.setId(rs.getLong(1));
		processObj.setDisplay_id(rs.getString(1));
		processObj.setName(rs.getString(2));
		processObj.setTaskName(rs.getString(3));
		
		if(rs.getTimestamp(4)!= null){
			processObj.setLockedDate(formater1.format(rs.getTimestamp(4)));
		}
		processObj.setBmpInstanceId(rs.getString(5));
		processObj.setBpmActivityId(rs.getString(6));
		processObj.setTaskCode(rs.getString(7));
		processObj.setPhase(rs.getString(8));
		processObj.setTirequestid(rs.getLong(9));
		processObj.setTiProcess(rs.getString(10));
		processObj.setRole(rs.getString(11));
		processObj.setTimeInActivity(rs.getLong(12));
		processObj.setActivityTrialId(rs.getLong(13));
		processObj.setRoleName(rs.getString(14));
		processObj.setRegion(rs.getString(15));
		processObj.setSector(rs.getString(16));
		processObj.setUserAccess(rs.getString("user_access"));
		processObj.setSubmissionRole(rs.getString("completing_role"));
		processObj.setBulkACVInstance(rs.getString("bulkACV_instance"));
		processObj.setBulkACVActivity(rs.getString("bulkACV_activity"));
		log.debug("Id:"+rs.getLong(1)+"Name"+rs.getString(2)+"Task"+rs.getString(3)+"gg"
				+rs.getString(6)+"BpmInsID"+rs.getString(7)+"BpmActID"+rs.getString(8)+"Task Code"+rs.getString(9)+"Phase"+rs.getString(10)+"Tiprocess"
				+rs.getString(12));
		return processObj;
	}
	
	/**
	 * Gets the conditions.
	 *
	 * @param attrsObj the attrs obj
	 * @return the conditions
	 */
	private String getConditions(Object attrsObj){
		StringBuilder condition = new StringBuilder("");
		if (attrsObj instanceof ApplicationSearchAttributes) {
			condition.append("and proc.process_type_id =1 ");
			ApplicationSearchAttributes attrs = (ApplicationSearchAttributes) attrsObj;
			if(attrs!=null){
				if(attrs.getCsiIdForQuery()!=null || attrs.getApplicationNameForQuery()!=null || attrs.getDeviceModelForQuery()!=null){
					condition.append("and proc.id in( " +
							"SELECT distinct tireq.process_id FROM "+
							"c3par.ti_request tireq "+
							"JOIN c3par.con_fw_rule rule ON tireq.id = rule.ti_request_id "+
							"JOIN c3par.con_fw_rule_source_ip sip ON rule.id = sip.rule_id "+
							"JOIN c3par.CON_IP_MASTER ip ON sip.ip_id = ip.id "+
							"JOIN c3par.con_fw_rule_application capp ON capp.rule_id = rule.id AND capp.ip_id = ip.id "+
							"JOIN c3par.ti_application tiapp ON tiapp.id = capp.application_id "+
							"WHERE "+
							"sip.deleted_ti_request_id is null ");
					// Application CSI
					if(attrs.getCsiIdForQuery()!=null){
						condition.append("  and tiapp.is_csi='Y'  and tiapp.application_id like '" + attrs.getCsiIdForQuery()+"' " );
					}
					// Application name
					if(attrs.getApplicationNameForQuery()!=null){
						condition.append("and upper(tiapp.application_name) like upper('" +attrs.getApplicationNameForQuery()+ "') ");
					}
					// Device Model
					if(attrs.getDeviceModelForQuery()!=null){
						condition.append("and upper(tiapp.device_model) like upper('" +attrs.getDeviceModelForQuery()+ "') ");
					}
					condition.append(" union "+
							"SELECT distinct tireq.process_id FROM "+
							"c3par.ti_request tireq "+
							"JOIN c3par.con_fw_rule rule ON tireq.id = rule.ti_request_id "+
							"JOIN c3par.con_fw_rule_destination_ip sip ON rule.id = sip.rule_id "+
							"JOIN c3par.CON_IP_MASTER ip ON sip.ip_id = ip.id "+
							"JOIN c3par.con_fw_rule_application capp ON capp.rule_id = rule.id AND capp.ip_id = ip.id "+
							"JOIN c3par.ti_application tiapp ON tiapp.id = capp.application_id "+
							"WHERE "+
							"sip.deleted_ti_request_id is null ");
					// Application CSI
					if(attrs.getCsiIdForQuery()!=null){
						condition.append("  and tiapp.is_csi='Y'  and tiapp.application_id like '" + attrs.getCsiIdForQuery()+"' " );
					}
					// Application name
					if(attrs.getApplicationNameForQuery()!=null){
						condition.append("and upper(tiapp.application_name) like upper('" +attrs.getApplicationNameForQuery()+ "') ");
					}
					// Device Model
					if(attrs.getDeviceModelForQuery()!=null){
						condition.append("and upper(tiapp.device_model) like upper('" +attrs.getDeviceModelForQuery()+ "') ");
					}
					condition.append(")");	
				}
			}			
		}
		if (attrsObj instanceof ConIPDetailsSearchAttributes) {			
			condition.append("and proc.process_type_id =1 ");
			ConIPDetailsSearchAttributes attrs = (ConIPDetailsSearchAttributes) attrsObj;
			if(attrs!=null){
					if(attrs.getFirewallForQuery()!=null || attrs.getFirewallNameForQuery()!=null || attrs.getSourceIpAddressForQuery()!=null || attrs.getSourceNatIPForQuery()!=null || attrs.getDestIpAddressForQuery()!=null || attrs.getDestNatIPForQuery()!=null || attrs.getPortForQuery()!=null || attrs.getProtocolForQuery()!=null ){  
					
					condition.append("and proc.id in("+
							"select tireq.process_id from "+
							"c3par.ti_request tireq " +
							"join c3par.con_fw_rule rule on tireq.id = rule.ti_request_id "+
							"JOIN c3par.con_fw_rule_policy rule_pc ON rule.id = rule_pc.rule_id "+
							"JOIN c3par.con_fw_policy pol ON rule_pc.policy_id = pol.id "+
							"join c3par.con_fw_rule_source_ip sip on rule.id = sip.rule_id " +
							"join c3par.con_fw_rule_destination_ip dip on rule.id = dip.rule_id " +
							"join con_ip_master sipm ON sip.ip_id = sipm.id " +
							"join con_ip_master dipm ON dip.ip_id = dipm.id " +
							"join c3par.con_fw_rule_port prt ON rule.id = prt.rule_id " +
							"join con_port_lookup port  ON prt.PORT_id = port.id " +
							"join con_firewall fwName on fwName.policy_id = pol.id "); 
					
							if(attrs.getFirewallForQuery()!= null){
							condition.append("where rule_pc.deleted_ti_request_id is null " +
							" and upper(pol.policy_name) like upper('" +attrs.getFirewallForQuery()+ "')");
							}
					//fw name
					if(attrs.getFirewallNameForQuery()!= null){
						condition.append("and upper(fwName.FIREWALL_NAME) like upper ('" +attrs.getFirewallNameForQuery() + " ' )");
					}
					//source 
					if(attrs.getSourceIpAddressForQuery()!=null || attrs.getSourceNatIPForQuery()!=null ){
					condition.append("and sip.deleted_ti_request_id is null ");
					
					
					//ip address
					if(attrs.getSourceIpAddressForQuery()!=null){
						condition.append("and sipm.ip_address like '" +attrs.getSourceIpAddressForQuery()+ "' ");
					}
					// NAT IP ADDRESS
					if(attrs.getSourceNatIPForQuery()!=null){
						condition.append("and sipm.nat_ip_address like '" +attrs.getSourceNatIPForQuery()+ "' ");
					}
					}
					
					//Destination
					if(attrs.getDestIpAddressForQuery()!=null || attrs.getDestNatIPForQuery()!=null) {
						condition.append("and dip.deleted_ti_request_id is null ");
						
						//Destination IP
						if(attrs.getDestIpAddressForQuery()!=null){
							condition.append("and dipm.ip_address like '" +attrs.getDestIpAddressForQuery()+ "' ");
						}
						
						//Destination Nat IP
						if(attrs.getDestNatIPForQuery()!=null){
							condition.append("and dipm.nat_ip_address like '" +attrs.getDestNatIPForQuery()+ "' ");
						}
						
					}
					if(attrs.getPortForQuery()!=null || attrs.getProtocolForQuery()!=null ){
						condition.append("and prt.deleted_ti_request_id is null ");
					
						// port
						if(attrs.getPortForQuery()!=null){
							condition.append("and port.port_number = '"+attrs.getPortForQuery()+"' ");
						}
						//protocol
						if(attrs.getProtocolForQuery()!=null){
							condition.append("and upper(port.protocol) like upper('" + attrs.getProtocolForQuery() +"') ");
						
					}
					}
						condition.append(") ");
						log.debug("Connection IP Details check : " +condition.toString());
					}
			}		
		}
		if(attrsObj instanceof SearchByContactAttributes){
			condition.append("and proc.process_type_id =1 ");
			SearchByContactAttributes attrs = (SearchByContactAttributes) attrsObj;
			if(attrs!=null){
				//contact/soeid
				if(attrs.getContactForQuery()!=null){
					condition.append(" and proc.id in( " +
							"SELECT TIR.PROCESS_ID "+
							"FROM  "+
							"TI_REQUEST TIR  "+
							"JOIN ti_request_planning_xref trpx ON TRPX.TI_REQUEST_ID=TIR.ID "+
							"JOIN C3PAR.CON_REQ_CITI_CONTACT_XREF CRCCX ON TRPX.PLANNING_ID=CRCCX.REQUEST_ID "+
							"JOIN CITI_CONTACT CC ON CRCCX.CITI_CONTACT_ID=CC.ID "+
							"WHERE "+
							"UPPER(CC.SSO_ID)=UPPER('"+attrs.getContactForQuery()+"') "+
							"UNION ALL "+
							"SELECT TIR.PROCESS_ID "+
							"FROM  "+
							"TI_REQUEST TIR  "+
							"JOIN ti_request_planning_xref trpx ON TRPX.TI_REQUEST_ID=TIR.ID "+
							"JOIN C3PAR.con_req_cit_rqcon_xref CRCCX ON TRPX.PLANNING_ID=CRCCX.REQUEST_ID "+
							"JOIN CITI_CONTACT CC ON CRCCX.CITI_CONTACT_ID=CC.ID "+
							"WHERE "+
							"UPPER(CC.SSO_ID)=UPPER('"+attrs.getContactForQuery()+"') " +
									") ");
					
				
					//Region
					if(attrs.getRegionForQuery()!=null){
						condition.append("and proc.relationship_id IN (" +
								"SELECT r.id FROM "+
								"c3par.relationship r "+
								"JOIN c3par.ent_inst ei ON r.ENT_INSTANCE_ID=ei.id "+
								"JOIN c3par.ent_data ed2 ON ei.id=ed2.entitlement_instance_id "+
								"JOIN c3par.region r1 ON ed2.data=r1.id "+
								"WHERE "+
								"ed2.entitlement_node_id=1 "+
								"and r1.id="+attrs.getRegionForQuery().longValue()+
								") ");			
											
					}
					//Sector
					if(attrs.getSectorForQuery()!=null){
								condition.append("and proc.relationship_id IN (" +
										"SELECT r.id FROM "+
										"c3par.relationship r "+
										"JOIN c3par.ent_inst ei ON r.ENT_INSTANCE_ID=ei.id "+
										"JOIN c3par.ent_data ed2 ON ei.id=ed2.entitlement_instance_id "+
										"JOIN c3par.sector s1 ON ed2.data=s1.id "+
										"WHERE "+
										"ed2.entitlement_node_id=2 "+
										"and s1.id=" +attrs.getSectorForQuery().longValue()+ 
										") ");				
										
					}
					//CSI Application
					if(attrs.getCsiApplicationForQuery()!=null){
						condition.append(" and proc.id in( " +
								"SELECT tireq.process_id FROM "+
								"c3par.ti_request tireq "+
								"JOIN c3par.con_fw_rule rule ON tireq.id = rule.ti_request_id "+
								"JOIN c3par.con_fw_rule_application capp ON capp.rule_id = rule.id "+
								"JOIN c3par.ti_application tiapp ON tiapp.id = capp.application_id "+
								"WHERE "+
								"capp.deleted_ti_request_id is null "+
								"and tiapp.is_csi='Y' and tiapp.application_id = "+attrs.getCsiApplicationForQuery().longValue()+" )" );
								
					}
					//Firewall Policy
					if(attrs.getFwDeviceForQuery()!=null){
						condition.append(" and proc.id in( " +
								"SELECT tireq.process_id FROM "+
								"c3par.ti_request tireq "+
								"JOIN c3par.con_fw_rule rule ON tireq.id = rule.ti_request_id "+
								"JOIN c3par.con_fw_rule_policy rule_pc ON rule.id = rule_pc.rule_id "+
								"JOIN c3par.con_fw_policy pol ON rule_pc.policy_id = pol.id "+
								"WHERE "+
								"rule_pc.deleted_ti_request_id is null "+
								"and upper(pol.policy_name) like upper('"+attrs.getFwDeviceForQuery()+"')" +
								") ");
						
					}
					
				}
				
			}
		}
		if (attrsObj instanceof ConIPPairFWSearchAttributes) {
			condition.append("and proc.process_type_id =1 ");
			ConIPPairFWSearchAttributes attrs = (ConIPPairFWSearchAttributes) attrsObj;
			if(attrs!=null){
				if(attrs.getIpPairForQuery()!=null || attrs.getFirewallForQuery()!=null){
					condition.append("and proc.id in(" +
							"SELECT distinct tireq.process_id FROM "+
							"c3par.ti_request tireq "+
							"JOIN c3par.con_fw_rule rule ON tireq.id = rule.ti_request_id "+
							"JOIN c3par.con_fw_rule_policy rule_pc ON rule.id = rule_pc.rule_id "+
							"JOIN c3par.con_fw_policy pol ON rule_pc.policy_id = pol.id "+
							"WHERE "+
							"rule_pc.deleted_ti_request_id is null "+
							"and upper(pol.policy_name) like upper('" +attrs.getFirewallForQuery()+ "')" +
									") ");

				}
			}

		}		
		if (attrsObj instanceof ConIPAddressSearchAttributes) {
			condition.append("and proc.process_type_id =1 ");
			ConIPAddressSearchAttributes attrs = (ConIPAddressSearchAttributes) attrsObj;
			if(attrs!=null){
				if(attrs.getIpAddressForQuery()!=null || attrs.getNatIPForQuery()!=null || attrs.getVirtualIPForQuery()!=null || attrs.getVirtualNATIPForQuery()!=null){
					condition.append("and proc.id in (" +
							"SELECT tireq.process_id FROM "+
							"c3par.ti_request tireq "+
							"JOIN c3par.con_fw_rule rule ON tireq.id = rule.ti_request_id "+
							"JOIN c3par.con_fw_rule_source_ip sip ON rule.id = sip.rule_id "+
							"JOIN c3par.CON_IP_MASTER ip ON sip.ip_id = ip.id "+
							"WHERE "+
							"sip.deleted_ti_request_id is null ");
					//ip address
					if(attrs.getIpAddressForQuery()!=null){
						condition.append("and ip.ip_address like '" +attrs.getIpAddressForQuery()+ "' ");
					}
					// NAT IP ADDRESS
					if(attrs.getNatIPForQuery()!=null){
						condition.append("and sip.nat like '" +attrs.getNatIPForQuery()+ "' ");
					}
					
					condition.append(" union all "+
							"SELECT tireq.process_id FROM "+
							"c3par.ti_request tireq "+
							"JOIN c3par.con_fw_rule rule ON tireq.id = rule.ti_request_id "+
							"JOIN c3par.con_fw_rule_destination_ip sip ON rule.id = sip.rule_id "+
							"JOIN c3par.CON_IP_MASTER ip ON sip.ip_id = ip.id "+
							"WHERE "+
							"sip.deleted_ti_request_id is null ");
					//ip address
					if(attrs.getIpAddressForQuery()!=null){
						condition.append("and ip.ip_address like '" +attrs.getIpAddressForQuery()+ "' ");
					}
					// NAT IP ADDRESS
					if(attrs.getNatIPForQuery()!=null){
						condition.append("and sip.nat like '" +attrs.getNatIPForQuery()+ "' ");
					}
					
					condition.append(") ");
				}
			}
		}
		if (attrsObj instanceof ConIPPortSearchAttributes) {
			condition.append("and proc.process_type_id =1 ");
			ConIPPortSearchAttributes attrs = (ConIPPortSearchAttributes) attrsObj;
			if(attrs!=null){
				if(attrs.getPortForQuery()!=null || attrs.getProtocolForQuery()!=null || attrs.getIpPairForQuery()!=null){
					
					condition.append("and proc.id in( "+
							"SELECT distinct tireq.process_id FROM "+
							"c3par.ti_request tireq "+
							"JOIN c3par.con_fw_rule rule ON tireq.id = rule.ti_request_id "+
							"JOIN c3par.con_fw_rule_port prt ON rule.id = prt.rule_id "+
							"JOIN c3par.con_port_lookup port ON prt.PORT_id = port.id "+
							"WHERE "+
							"prt.deleted_ti_request_id is null ");
				
					// port
					if(attrs.getPortForQuery()!=null){
						condition.append("and port.port_number = '"+attrs.getPortForQuery()+"' ");
					}
					//protocol
					if(attrs.getProtocolForQuery()!=null){
						condition.append("and upper(port.protocol) like upper('" + attrs.getProtocolForQuery() +"') ");
					}
					//ip pair
					condition.append(")");
				}
				
			}
		}
		if (attrsObj instanceof GeneralSearchAttributes) {
			GeneralSearchAttributes attrs = (GeneralSearchAttributes) attrsObj;
			if(attrs!=null){
				// Data Classification
				if(attrs.getDataClassificationForQuery()!=null){
					condition.append("and proc.relationship_id in(" +
							"SELECT rel.id FROM "+
							"c3par.relationship rel "+
							"JOIN c3par.co_lookup_data l ON l.id = rel.lookup_id "+
							"WHERE "+
							"l.classification_id ="+attrs.getDataClassificationForQuery().longValue()+
							") ");				
				}
				// Third Party
				if(attrs.getThirdPartyForQuery()!=null){
					condition.append("and proc.relationship_id IN (" +
							"SELECT r.id FROM "+
							"c3par.relationship r "+
							"JOIN c3par.third_party tp ON r.THIRD_PARTY_ID = tp.ID "+
							"WHERE "+
							"r.relationship_type ='THIRD_PARTY' "+
							"and upper(tp.name) like upper('" +attrs.getThirdPartyForQuery()+ "')" +
							") ");						
				}
				// BU
				if(attrs.getBusinessUnitForQuery()!=null){
					condition.append("and proc.relationship_id IN (" +
							"SELECT r.id FROM "+
							"c3par.relationship r "+
							"JOIN BUSINESS_UNIT bu ON r.business_unit_id=bu.id "+
							"WHERE "+
							"upper(bu.BUSINESS_NAME) like upper('"+ attrs.getBusinessUnitForQuery()+"')" +
							") ");								
				}
				// Sector
				if(attrs.getSectorForQuery()!=null){
					condition.append("and proc.relationship_id IN (" +
							"SELECT r.id FROM "+
							"c3par.relationship r "+
							"JOIN c3par.ent_inst ei ON r.ENT_INSTANCE_ID=ei.id "+
							"JOIN c3par.ent_data ed2 ON ei.id=ed2.entitlement_instance_id "+
							"JOIN c3par.sector s1 ON ed2.data=s1.id "+
							"WHERE "+
							"ed2.entitlement_node_id=2 "+
							"and s1.id=" +attrs.getSectorForQuery().longValue()+ 
							") ");				
				}	
		
				//Region
				if(attrs.getRegionForQuery()!=null){
					condition.append("and proc.relationship_id IN (" +
							"SELECT r.id FROM "+
							"c3par.relationship r "+
							"JOIN c3par.ent_inst ei ON r.ENT_INSTANCE_ID=ei.id "+
							"JOIN c3par.ent_data ed2 ON ei.id=ed2.entitlement_instance_id "+
							"JOIN c3par.region r1 ON ed2.data=r1.id "+
							"WHERE "+
							"ed2.entitlement_node_id=1 "+
							"and r1.id="+attrs.getRegionForQuery().longValue()+
							") ");			
				}
				//Requester SOEID
				if(attrs.getRequesterSOEIdForQuery()!=null){
					condition.append(" and req.USER_ID in (" +
							"select id " +
							"from c3par.C3PAR_USERS a " +
							"where a.sso_id in ('"+attrs.getRequesterSOEIdForQuery()+"') " +
							")  ");					
				}
				//Priority
				if(attrs.getPriorityForQuery()!=null){
					condition.append("and req.PRIORITY_ID = "+attrs.getPriorityForQuery().longValue()+" ");				
				}
				//Task Code
				if(attrs.getTaskCodeForQuery()!=null){
					condition.append(" and t.activity_id = " + attrs.getTaskCodeForQuery().longValue() + " ");
				}
				// relationship name
				if(attrs.getRelationshipNameForQuery()!=null){
					condition.append("and proc.relationship_id IN (select r.id from c3par.relationship r " +
							"where upper(r.name) like upper('"+ attrs.getRelationshipNameForQuery() +"')) ");				
				}
				// relationship id
				if(attrs.getRelationshipIdForQuery()!=null){
					condition.append("and proc.relationship_id like '" +  attrs.getRelationshipIdForQuery() + "' ");
				}
				// process name
				if(attrs.getProcessNameForQuery()!=null){
					condition.append("and upper(proc.process_name) like upper('"+attrs.getProcessNameForQuery()+"') ");
				}
				//CMP ID
				if(attrs.getCMPIDforQuery()!= null){
					condition.append("and upper(req.CMP_ID) like upper('"+attrs.getCMPIDforQuery()+"')");				
				}
				
				//Service Now ID
				if(attrs.getServiceNowIDForQuery()!=null){
					condition.append("and upper(req.SERVICE_NOW_ID) like upper('"+attrs.getServiceNowIDForQuery()+"')");
							 
				}
				
				if(attrs.getCaspIDForQuery()!=null){
					condition.append("and proc.relationship_id IN (" +
							"SELECT r.id FROM "+
							"c3par.relationship r "+
							"JOIN c3par.third_party thp ON thp.id=r.third_party_id "+
							"WHERE "+
							"thp.casp_id="+attrs.getCaspID()+
							") ");
							 
				}
				
				if(attrs.getCaspDetailIDForQuery()!=null){
					condition.append("and proc.relationship_id IN (" +
							"SELECT r.id FROM "+
							"c3par.relationship r "+
							"JOIN c3par.third_party thp ON thp.id=r.third_party_id "+
							"WHERE "+
							"thp.detail_id="+attrs.getCaspDetailID()+
							") ");
							 
				}
				
				
				if(attrs.getProcessIdForQuery()!=null){
					String procId = attrs.getProcessIdForQuery();
					if(procId.indexOf(".")>-1){
						procId = procId.substring(0,procId.indexOf("."));
					}
					condition.append("and proc.id like '" + procId+ "' ");
				}
				if(attrs.getVersionNoForQuery()!=null){
					String version = attrs.getVersionNoForQuery();
					if(version.indexOf(".")>-1){
						version = version.substring(0,version.indexOf("."));
					}
					condition.append("and proc.version_number like '" + version+ "' ");
				}
				
			}
		}
		if (attrsObj instanceof OpeImpInputSearchAttributes) {
			//condition.append("and proc.process_type_id =1 ");
			OpeImpInputSearchAttributes attrs = (OpeImpInputSearchAttributes) attrsObj;
			if(attrs!=null){
				if(attrs.getTpaswgRejectedFromDateForQuery()!=null || attrs.getTpaswgRejectedToDateForQuery()!=null){
					if(attrs.getTpaswgRejectedFromDateForQuery()!=null && !attrs.getTpaswgRejectedFromDateForQuery().equals("")){
						condition.append("and TO_DATE('" +attrs.getTpaswgRejectedFromDateForQuery()+ "','MM/DD/YYYY') <= req.tpwapp_rejected_date ");
		                
					}
					if(attrs.getTpaswgRejectedToDateForQuery()!=null && !attrs.getTpaswgRejectedToDateForQuery().equals("")){
						condition.append("and  TO_DATE('" +attrs.getTpaswgRejectedToDateForQuery()+ "','MM/DD/YYYY') >= req.tpwapp_rejected_date ");
					}
					
				}
				if(attrs.getTpaswgReviewFromDateForQuery()!=null || attrs.getTpaswgReviewToDateForQuery()!=null){
					
					if(attrs.getTpaswgReviewFromDateForQuery()!=null && !attrs.getTpaswgReviewFromDateForQuery().equals("")){
						condition.append("and TO_DATE('" +attrs.getTpaswgReviewFromDateForQuery()+ "','MM/DD/YYYY') <= req.tpwapp_review_date ");	
					}
					if(attrs.getTpaswgReviewToDateForQuery()!=null && !attrs.getTpaswgReviewFromDateForQuery().equals("")){
						condition.append("and  TO_DATE('" +attrs.getTpaswgReviewToDateForQuery()+ "','MM/DD/YYYY') >= req.tpwapp_review_date ");
					}
				}
				
				if(attrs.getTpaswgTempAppFromDateForQuery()!=null || attrs.getTpaswgTempAppToDateForQuery()!=null){
					
					if(attrs.getTpaswgTempAppFromDateForQuery()!=null && !attrs.getTpaswgTempAppFromDateForQuery().equals("")){
						condition.append("and TO_DATE('" +attrs.getTpaswgTempAppFromDateForQuery()+ "','MM/DD/YYYY') <= req.TPWAPP_TEMP_APP_DATE ");	
					}
					if(attrs.getTpaswgTempAppToDateForQuery()!=null && !attrs.getTpaswgTempAppToDateForQuery().equals("")){
						condition.append("and  TO_DATE('" +attrs.getTpaswgTempAppToDateForQuery()+ "','MM/DD/YYYY') >= req.TPWAPP_TEMP_APP_DATE ");
					}
				}
				if(attrs.getTpaswgReviewStatusForQuery()!=null){
					condition.append("and req.tpwapp_review_status = '"+attrs.getTpaswgReviewStatusForQuery()+"' ");
				}
				if(attrs.getTpaswgReviewTypeForQuery()!=null){
					condition.append("and req.tpwapp_review_type = '"+attrs.getTpaswgReviewTypeForQuery()+"' ");
				}
			}
		}
		if (attrsObj instanceof IPRegDetSearchAttributes) {
			IPRegDetSearchAttributes attrs = (IPRegDetSearchAttributes) attrsObj;
			condition.append("and proc.process_type_id =2 ");
			if(attrs!=null){
				if(attrs.getIpAddressForQuery()!=null || attrs.getAclForQuery()!=null){
					condition.append("and proc.id in( " +
							"select distinct ip_reg.process_id " +
							"from c3par.ip_reg_detail ip_reg_det, c3par.ip_registration ip_reg " +
							"where ip_reg_det.ip_registration_id=ip_reg.id ");
							if(attrs.getIpAddressForQuery()!=null && !attrs.getIpAddressForQuery().equals("")){
								condition.append("and (ip_reg_det.DESTINATION_IP like '"+attrs.getIpAddressForQuery()+"' " +
								"or ip_reg_det.DESTINATION_END_IP like '"+attrs.getIpAddressForQuery()+"') " );
							}
							if(attrs.getAclForQuery()!=null && !attrs.getAclForQuery().equals("")){
								condition.append("and upper(ip_reg_det.source_acl) like upper('"+attrs.getAclForQuery()+"')");
							}
							condition.append(")");
				}
				if(attrs.getPortForQuery()!=null || attrs.getProtocolForQuery()!=null){
					condition.append("and proc.id in( " +
							"select distinct ip_reg.process_id " +
							"from c3par.ip_reg_detail ip_reg_det, c3par.ip_registration ip_reg " +
							",c3par.IPREGDESTINATIONPORTS ip_reg_ports " );
					if(attrs.getProtocolForQuery()!=null){
						condition.append(",c3par.IPREGDETAIL_PROTOCOL_XREF protocol_xref " );
					}
					
					condition.append("where ip_reg_det.ip_registration_id=ip_reg.id " +
							"and ip_reg_det.id = ip_reg_ports.ip_regdetail_id " );
					
					if(attrs.getPortForQuery()!=null){
						long port =0;
						String sPort = null;
						try{
							port = Long.parseLong(attrs.getPortForQuery());
						}catch(Exception ex){
							sPort = attrs.getPortForQuery()+"";							
						}
						if(sPort!=null){
							condition.append("and ip_reg_ports.start_port is not null " +
									" and (ip_reg_ports.start_port like '"+sPort+"' OR ip_reg_ports.end_port like '"+sPort+"') ");

						}
						if(port!=0){
							condition.append("and ip_reg_ports.start_port is not null " +
									" and "+port+">=to_number(nvl(ip_reg_ports.start_port,0)) " +
									"and "+port+"<=to_number(nvl(ip_reg_ports.end_port,10000) ) ");
						}
					}
					if(attrs.getProtocolForQuery()!=null){
						condition.append("and protocol_xref.ip_reg_destination_ports_id = ip_reg_ports.id " +
							"and protocol_xref.protocol_id in (select id from c3par.generic_lookup lk where upper(lk.value1) like upper('" + attrs.getProtocolForQuery() + "')) ");
					}
					
					condition.append(")");
				}
			}
		}
		
		if (attrsObj instanceof AppsenseSearchAttributes) {
			AppsenseSearchAttributes attrs = (AppsenseSearchAttributes) attrsObj;
			condition.append("and proc.process_type_id =1 ");
			if(attrs!=null){
					if(attrs.getApplicationNameForQuery()!=null || attrs.getCsiIdForQuery()!=null){
						condition.append(" and proc.id  in ( select distinct c.process_id from c3par.aps_appsense_policy c ,"+
								"ti_application a where c.application_id = a.id ");
					}
					// Application name
					if(attrs.getApplicationNameForQuery()!=null){
						condition.append(" and  upper(a.application_name) like upper('%" +attrs.getApplicationNameForQuery()+ "%') ");
					}
					
					if(attrs.getCsiIdForQuery()!=null){
						condition.append("  and a.is_csi='Y'  and a.application_id like '%" + attrs.getCsiIdForQuery()+"%' " );
					}
					if(attrs.getApplicationNameForQuery()!=null || attrs.getCsiIdForQuery()!=null){
					condition.append(")");
					}
					if(attrs.getPolicyNameForQuery()!=null){
						condition.append(" and proc.id in (select distinct policy.PROCESS_ID from  relationship rel," +
								"aps_appsense_policy policy where proc.relationship_id= rel.id and rel.name like '%" + attrs.getPolicyNameForQuery()+"%' )");
					}
					
					if(attrs.getUserSOEIdForQuery()!=null){
						condition.append(" and proc.id in(select distinct c.process_id from c3par.aps_appsense_policy c ,"+
								" citi_contact con where c.CITI_CONTACT_ID=con.id and "+
								"upper(con.SSO_ID)=upper('" +attrs.getUserSOEIdForQuery()+ "'))");
					}
					 if(attrs.getInstanceNameForQuery()!=null){
						 condition.append(" and proc.id in(select prx.process_id from prx_proxy_filter prx where PROXY_INST_MST_ID = '"+attrs.getInstanceNameForQuery()+"')");
					 }
						
				}
			}
		
		//Proxy Search Starts		
		if (attrsObj instanceof ProxySearchAttributes) {
			ProxySearchAttributes attrs = (ProxySearchAttributes) attrsObj;
			condition.append("and proc.process_type_id =1 ");
			if(attrs!=null){
					if(attrs.getPrxChangeTypeForQuery()!=null){
						condition.append(" and proc.id in ( select distinct process_id  from prx_proxy_filter prxfilter,prx_instance_master insMaster  " +
								"where insMaster.id=prxfilter.PROXY_INST_MST_ID  and upper(insMaster.RECORD_TYPE)=upper('" +attrs.getPrxChangeTypeForQuery()+ "')");
					}					
					// Application CSI
					if(attrs.getRegionForQuery()!=null){
						condition.append(" and  upper(insMaster.region)=upper('" + attrs.getRegionForQuery()+"' )" );
					}
					if(attrs.getInstanceNameForQuery()!=null && !attrs.getInstanceNameForQuery().trim().equals("")){
					condition.append(" and  insMaster.id = "+attrs.getInstanceNameForQuery());
					}
					if(attrs.getSourceIpAddressForQuery()!=null){
						condition.append(" and prxfilter.SOURCE_IP like( '%" + attrs.getSourceIpAddressForQuery()+"%' )");
					}
					if(attrs.getExternalIpAddressForQuery()!=null){
						condition.append(" and prxfilter.EXTERNAL_IP like( '%" + attrs.getExternalIpAddressForQuery()+"%' )");
					}
					if(attrs.getDomainNameForQuery()!=null){
						condition.append(" and prxfilter.DOMAIN_NAME like( '%" + attrs.getDomainNameForQuery()+"%' )");
					}
					if(attrs.getUrlForQuery()!=null){
						String url=attrs.getUrl();
						url=url.replaceAll("%", "~%");
						log.debug("Replace % url  --- "+url);
						url=url.replaceAll("&", "&%");
						log.debug("Replace & url  --- "+url);
						condition.append(" and prxfilter.url like ('%"+url+"%')");
						condition.append(" escape '~'");
						
					}
					if(attrs.getPrxChangeTypeForQuery()!=null){  
					condition.append(")"); 
					}
						
				}
			}
		
		return condition.toString();
	}

    @SuppressWarnings("unchecked")
	public List getAllRolesList() throws Exception{
    	List objList = new ArrayList();
    	LookupDTO obj = null;
		String queryToExecute = "select id,display_name from c3par.role"; 
		try {
			SqlRowSet rs  =  jdbcTemplate.queryForRowSet(queryToExecute);
			for (; rs.next(); objList.add(obj)) 
		    		obj = new LookupDTO(rs.getLong(1),rs.getString(2),null);
		}
	  	 catch (Exception e) {
  		 	log.error("Exception during query :- " + e);
  		 	throw new DatabaseException("Could not run query = " + queryToExecute, e);
	  	 }

		return objList;
    }
    
    public CitiContact getBusinessOwnerDetails(final Long tiRequestId,String relationType){
		log.info("Entering SearchProcessesImpl getBusinessOwnerDetails.");
		log.debug("Relation Type for Connection: "+relationType);
		StringBuilder query = new StringBuilder();
		query.append(" SELECT DISTINCT 			         ");
		query.append("   upper(cc.first_name),            ");
		query.append("   upper(cc.last_name),                    ");
		query.append("   cc.goc_code,                     ");
		query.append("   cc.man_segment_id,               ");
		query.append("   cc.dsmt_region_name,             ");
		query.append("   cc.dsmt_sector_name,             ");
		query.append("   cc.dsmt_business_unit_name,      ");
		query.append("   cc.sso_id					      ");
		query.append(" FROM ti_process tp                 ");
		query.append(" JOIN ti_request tr                 ");
		query.append(" ON tp.id=tr.process_id             ");
		query.append(" JOIN ti_request_planning_xref trpx ");
		query.append(" ON trpx.ti_request_id=tr.id        ");
		query.append(" JOIN planning p                    ");
		query.append(" ON p.id=trpx.planning_id           ");
		//For Target/Requester Contacts check
		if(C3parStaticNames.THIRD_PARTY.equals(relationType) || C3parStaticNames.TEMPLATE_OBJ.equals(relationType) ||
				C3parStaticNames.IP_TEMPLATE.equals(relationType) || C3parStaticNames.PORT_TEMPLATE.equals(relationType) || 
				"TARGET".equalsIgnoreCase(relationType) ){
			query.append(" JOIN CON_REQ_CITI_CONTACT_XREF cr  "); //For TargetContact Screen
		} else if(C3parStaticNames.U_TURN.equals(relationType) || C3parStaticNames.CITI_CON.equals(relationType) ||
				"REQUESTER".equalsIgnoreCase(relationType) ){
			query.append(" JOIN CON_REQ_CIT_RQCON_XREF cr  "); //For RequesterContact Screen
		} else {
			query.append(" JOIN CON_REQ_CITI_CONTACT_XREF cr  "); //To avoid exception, how ever data will not available.
		}
		query.append(" ON cr.request_id=p.id              ");
		query.append(" JOIN citi_contact cc               ");
		query.append(" ON cc.id=cr.citi_contact_id        ");
		query.append(" JOIN role r                        ");
		query.append(" ON cr.role_id = r.id               ");
		query.append(" WHERE r.name  = 'Business_Owner'   ");
		query.append(" AND cr.primary_contact = 'Y'    	  ");
		query.append(" AND tr.id     =?           	      ");
		log.debug("tiRequestId  :: "+tiRequestId);
		CitiContact citiContact=null;
		try {
			 citiContact =jdbcTemplate.query(query.toString(),
					new PreparedStatementSetter() {
						@Override
						public void setValues(PreparedStatement preparedStatement) throws
						SQLException {
							preparedStatement.setLong(1, tiRequestId);
						}
					}, 
					new ResultSetExtractor<CitiContact>() {
						@Override
						public CitiContact extractData(ResultSet resultSet) throws SQLException,
						DataAccessException {
							log.info("Before if condition ");
							if (resultSet.next()) {
								CitiContact citiContact = new CitiContact();
								log.info("**first name**** "+resultSet.getString(1)+" last name "+resultSet.getString(2)+ "  ssoId" +resultSet.getString(8));
								citiContact.setFirstName(resultSet.getString(1));
								citiContact.setLastName(resultSet.getString(2));
								citiContact.setGocCode(resultSet.getString(3));
								citiContact.setManSegmentId(resultSet.getString(4));
								citiContact.setDsmtRegionName(resultSet.getString(5));
								citiContact.setDsmtSectorName(resultSet.getString(6));
								citiContact.setDsmtBusinessUnitName(resultSet.getString(7));
								citiContact.setSsoId(resultSet.getString(8));
								return citiContact; 
							}
							log.info("inside the else condition ");
							return new CitiContact();
						}
					});
			if(citiContact==null){
				log.debug("No Records Found...");
			}
		} catch (DataAccessException e) {
			log.error("Exception in SearchProcessesImpl getBusinessOwnerDetails.",e);
		}
		log.info("Exiting SearchProcessesImpl getBusinessOwnerDetails.");
		return citiContact;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public CCRQueries getCcrQueries() {
		return ccrQueries;
	}

	public void setCcrQueries(CCRQueries ccrQueries) {
		this.ccrQueries = ccrQueries;
	}
	public List<Object> getScheduledProcessByAcitivityCode(String activityCode,int pageSize,String auditStatus ) throws DatabaseException {
		List<Object> list = new ArrayList<Object>();
		try{
		String queryToExecute = "SELECT  DISTINCT "+
	"PROC.ID AS ID,PROC.VERSION_NUMBER AS VERSION_NUMBER, "+
	"PROC.ID ||'.'|| PROC.VERSION_NUMBER AS DISPLAY_ID , "+
	"PROCESS_NAME AS NAME,T.ACTIVITY_TYPE AS STATUS, "+
	"CASE WHEN REQTY.REQUEST_TYPE = 'Create' THEN 'Planning' "+
	"WHEN REQTY.REQUEST_TYPE = 'Maintain' THEN 'Maintenance' "+
	"WHEN UPPER(REQTY.REQUEST_TYPE) = 'ACV' THEN 'ACV' "+
	"WHEN REQTY.REQUEST_TYPE = 'ManageContacts' THEN 'Maintain Contacts' "+
	"WHEN REQTY.REQUEST_TYPE = 'Temp Approval Expiration' THEN 'Temp Approval Expiration' "+
	"WHEN REQTY.REQUEST_TYPE = 'Terminate' THEN 'Termination' END AS PHASE, "+
	"T.ACTIVITY_MODE AS TYPE, "+
	"CASE WHEN PROC.PROCESS_TYPE_ID = 1 THEN 'Connection' "+
	"WHEN PROC.PROCESS_TYPE_ID = 2 THEN 'IPRegistration' END AS TI_PROCESS, "+
	"CASE WHEN t.activity_type= 'PROVIDEINFO' THEN role_info.name "+
	"ELSE  role_app.name END as role,g_l.value1 as priority,lockedby_user.sso_id, "+
	"req.id req_id, t.bpm_instance_id,task_type.albpm_activity_id , task_type.task , tpt.BPM_PROCESS_NAME,task_type.task_code "+
	"FROM "+
	"C3PAR.TI_PROCESS PROC "+
	"JOIN  C3PAR.TI_PROCESS_TYPE TPT ON PROC.PROCESS_TYPE_ID=TPT.ID "+
	"JOIN C3PAR.TI_REQUEST REQ ON PROC.ID = REQ.PROCESS_ID AND PROC.VERSION_NUMBER=REQ.VERSION_NUMBER "+
	"JOIN C3PAR.TI_REQUEST_TYPE REQTY ON REQ.TI_REQUEST_TYPE_ID = REQTY.ID "+
	"JOIN C3PAR.TI_ACTIVITY_TRAIL T ON REQ.ID=T.TI_REQUEST_ID "+
	"LEFT JOIN C3PAR.ROLE  ROLE_APP ON ROLE_APP.ID = T.USER_ROLE_ID "+
	"LEFT JOIN C3PAR.ROLE  ROLE_INFO ON ROLE_INFO.ID = T.INFOUSER_ROLE_ID "+
	"JOIN C3PAR.TI_TASK_TYPE TASK_TYPE ON TASK_TYPE.ID = T.ACTIVITY_ID "+
	"JOIN C3PAR.GENERIC_LOOKUP G_L ON G_L.ID = REQ.PRIORITY_ID "+
	"LEFT JOIN C3PAR.C3PAR_USERS LOCKEDBY_USER ON LOCKEDBY_USER.ID=T.LOCKEDBY "+
	"JOIN C3PAR.RELATIONSHIP REL ON REL.ID=PROC.RELATIONSHIP_ID "+
	"JOIN REL_CITI_HIERARCHY_XREF RELXREF ON REL.ID=RELXREF.RELATIONSHIP_ID "+
	"JOIN CITI_HIERARCHY_MASTER CITIMASTER ON CITIMASTER.ID=RELXREF.CITI_HIERARCHY_MASTER_ID "+
	"LEFT JOIN C3PAR.CO_LOOKUP_DATA L ON L.ID = REL.LOOKUP_ID "+
	"LEFT JOIN C3PAR.THIRD_PARTY THP ON REL.THIRD_PARTY_ID = THP.ID AND REL.RELATIONSHIP_TYPE ='THIRD_PARTY' "+
	"LEFT JOIN BUSINESS_UNIT BU ON CITIMASTER.BU_ID=BU.ID "+
	"LEFT JOIN ( "+
	"SELECT R.ID RELID,S1.ID SECID FROM "+
	"C3PAR.RELATIONSHIP R "+
	"JOIN REL_CITI_HIERARCHY_XREF RELXREF ON R.ID=RELXREF.RELATIONSHIP_ID "+
	"JOIN CITI_HIERARCHY_MASTER CITIMASTER ON CITIMASTER.ID=RELXREF.CITI_HIERARCHY_MASTER_ID "+
	"JOIN SECTOR S1 ON CITIMASTER.SECTOR_ID=S1.ID "+
	")SECT ON SECT.RELID=REL.ID "+
	"LEFT JOIN ( "+
	"SELECT R.ID RELID, R1.ID REGID FROM "+
	"C3PAR.RELATIONSHIP R "+
	"JOIN REL_CITI_HIERARCHY_XREF RELXREF ON R.ID=RELXREF.RELATIONSHIP_ID "+
	"JOIN CITI_HIERARCHY_MASTER CITIMASTER ON CITIMASTER.ID=RELXREF.CITI_HIERARCHY_MASTER_ID "+
	"JOIN REGION R1 ON CITIMASTER.REGION_ID=R1.ID "+
	")REG ON REG.RELID=REL.ID "+
	"LEFT JOIN C3PAR_USERS REQ_SSO ON REQ_SSO.ID=REQ.USER_ID "+
	"WHERE "+
	"PROC.IS_DELETED = 'N' AND "+
  "T.ACTIVITY_STATUS IN(?)  ";
		SqlRowSet rs  =null;
		if(StringUtil.isNullorEmpty(activityCode)){
		 rs  = jdbcTemplate.queryForRowSet(queryToExecute,
				new Object[]{auditStatus});
		}else{
			queryToExecute=queryToExecute+" AND upper(task_type.task_code) = UPPER(?)";
			 rs  = jdbcTemplate.queryForRowSet(queryToExecute,
					new Object[]{auditStatus,activityCode});
		}
		Object obj = null;
		for (; rs.next(); list.add(obj)) {
			obj = createModel(rs);
		}
		} catch (Exception e) {
			log.error("Exception during query :- " + e);
		}  
		log.debug("List Size  Sorting : "+list.size());
		return list;
	}
	 private String getRelationShipType(String[] relationShipType) {

	        String queryForName = "";
	        if (relationShipType != null) {

	            for (int count = 0; count < relationShipType.length; count++) {
	                if (count == relationShipType.length - 1) {
	                    queryForName = queryForName + "'" + relationShipType[count] + "'";
	                } else {
	                    queryForName = queryForName + "'" + relationShipType[count] + "',";
	                }
	            }
	        } else {
	            queryForName = "'THIRD_PARTY','CITI_CON','U_TURN','IP_TEMPLATE','PORT_TEMPLATE','TEMPLATE'";
	        }
	        return queryForName;
	    }

		@Override
		public String getRequestorSoeIdForConnectionInfo(Long processId, String relationshipType) throws Exception {
			String requesterSOEID = "";
			List<String> resultList = new ArrayList<String>();
			String queryToExecute = "";
			try {
				if (relationshipType.equalsIgnoreCase("THIRD_PARTY")
		                || relationshipType.equalsIgnoreCase(C3parStaticNames.TEMPLATE_OBJ)
		                || relationshipType.equalsIgnoreCase(C3parStaticNames.IP_TEMPLATE)
		                || relationshipType.equalsIgnoreCase(C3parStaticNames.PORT_TEMPLATE)) {
					 queryToExecute = QueryConstants.CON_INFO_REQUESTER_TARGETCONTACT;
				} else if (relationshipType.equalsIgnoreCase("CITI_CON") || relationshipType.equalsIgnoreCase("U_TURN")) {
					 queryToExecute = QueryConstants.CON_INFO_REQUESTER_REQCONTACT;
				}
				
				Object[] params = { processId };
				resultList = jdbcTemplate.query(queryToExecute, params, new RowMapper<String>() {
					public String mapRow(ResultSet rs, int rowNum) throws SQLException {
						return rs.getString("sso_id");
					}
				});
				if (CollectionUtils.isNotEmpty(resultList)) {
					requesterSOEID = resultList.get(0);
				}
			} catch (Exception e) {
				log.error("Exception during query :- " + e);
			}
			return requesterSOEID;
		}
}
