package com.citigroup.cgti.c3par.communication.domain.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Property;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.communication.domain.EcmColumn;
import com.citigroup.cgti.c3par.communication.domain.ColumnsSortOrderSettings;
import com.citigroup.cgti.c3par.communication.domain.EcmUserPreference;
import com.citigroup.cgti.c3par.communication.domain.EcmUserSetting;
import com.citigroup.cgti.c3par.communication.domain.EcmViewColumn;
import com.citigroup.cgti.c3par.communication.domain.service.EcmUserPreferenceDaoService;
import com.citigroup.cgti.c3par.configuation.QueryConstants;

/**
 * DAO service class for the ECM User preference.
 * 
 * @author sd26547
 */

@Repository
@Transactional
public class EcmUserPreferenceDaoServiceImpl implements EcmUserPreferenceDaoService {

	private static Logger LOGGER = Logger.getLogger(EcmUserPreferenceDaoServiceImpl.class);
	private static final String ECMVIEWCOLUMN = "ecmViewColumn";
	private static final String ECMUSERPREFERENCE = "ecmUserPreference";
	private static final String N = "N";
	@Autowired
	private SessionFactory sessionFactory;

	/**
	 * This method is to get the ECM user's preference for the column and view.
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public List<EcmUserPreference> getEcmUserPreference(String ssoId, String viewId) throws ApplicationException {
		LOGGER.info("Entering with ssoId : " + ssoId + " :viewId :" + viewId);
		try {
			DetachedCriteria subQuery = DetachedCriteria.forClass(EcmViewColumn.class, ECMVIEWCOLUMN);
			subQuery.createAlias("ecmViewColumn.ecmView", "ecmView");
			subQuery.add(Restrictions.eq("ecmView.viewName", viewId));
			subQuery.setProjection(Projections.property("ecmViewColumn.id"));
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(EcmUserPreference.class);
			criteria.createCriteria("c3parUser", "user", JoinType.INNER_JOIN);
			criteria.add(Restrictions.eq("user.ssoId", ssoId));
			criteria.add(Restrictions.eq("deleteFlag", N));
			criteria.addOrder(Order.asc("id"));
			criteria.add(Property.forName("ecmViewColumn").in(subQuery));
			List<EcmUserPreference> userList = criteria.list();
			return userList;
		} catch (Exception e) {
			LOGGER.error("Exception occurred while getting getEcmUserPreference : " + e.toString());
			throw new ApplicationException("Exception has occurred :: getEcmUserPreference() ", e);

		}

	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public List<EcmViewColumn> unselectedColumn(String ssoId, String viewId, boolean isSelected) throws Exception {
		LOGGER.info("Entering ssoId :: " + ssoId + " :viewId ::" + viewId);
		try {
			DetachedCriteria subQuery = DetachedCriteria.forClass(EcmUserPreference.class, ECMUSERPREFERENCE);
			subQuery.createAlias("ecmUserPreference.c3parUser", "c3parUser");
			subQuery.add(Restrictions.eq("c3parUser.ssoId", ssoId));
			subQuery.createAlias("ecmUserPreference.ecmViewColumn", "ecmViewColumn");
			subQuery.setProjection(Projections.property("ecmViewColumn.id"));
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(EcmViewColumn.class, ECMVIEWCOLUMN);
			criteria.createAlias("ecmViewColumn.ecmView", "ecmView");
			criteria.add(Restrictions.eq("ecmView.viewName", viewId));
			criteria.add(Restrictions.eq("ecmViewColumn.deleteFlag", N));
			if (isSelected) {
				criteria.add(Property.forName("ecmViewColumn.id").in(subQuery));
			} else {
				criteria.add(Property.forName("ecmViewColumn.id").notIn(subQuery));
			}
			criteria.addOrder(Order.asc("ecmViewColumn.id"));
			List<EcmViewColumn> unselectedList = criteria.list();
			return unselectedList;
		} catch (Exception e) {
			LOGGER.error("Exception occurred while getting unselectedColumn : " + e.toString());
			throw new ApplicationException("Exception has occurred :: unselectedColumn() ", e);
		}

	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public List<EcmViewColumn> getEcmViewColumn(String viewId) throws Exception {
		LOGGER.info("Entering with viewId :" + viewId);
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(EcmViewColumn.class, ECMVIEWCOLUMN);
            criteria.createAlias("ecmViewColumn.ecmView", "ecmView");
            criteria.add(Restrictions.eq("ecmView.viewName", viewId));
            criteria.add(Restrictions.eq("ecmViewColumn.deleteFlag", N));
            criteria.addOrder(Order.asc("ecmViewColumn.columnOrder"));
			List<EcmViewColumn> viewolumnList = criteria.list();
			return viewolumnList;
		} catch (Exception e) {
			LOGGER.error("Exception occurred while getting getEcmViewColumn : " + e.toString());
			throw new ApplicationException("Exception has occurred :: getEcmViewColumn() ", e);
		}

	}

	@Override
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public EcmUserPreference saveEcmUserPreference(String ssoId) {
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<EcmColumn> getColumnDetails(String viewId) throws Exception {
		try {
			List<EcmColumn> ecmColumnList=new ArrayList<>();
			Session session= sessionFactory.getCurrentSession();
			List<EcmViewColumn> resultList=session.createQuery(QueryConstants.GET_COLUMN_DETAILS)
					.setString("viewName", viewId).list();
			if(!CollectionUtils.isEmpty(resultList)){
				for(EcmViewColumn ecmColumnView:resultList){
					EcmColumn ecmColumn=(EcmColumn)session.load(EcmColumn.class, ecmColumnView.getColumnId());
					ecmColumnList.add(ecmColumn);
				}
				
			}
			return ecmColumnList;
		} catch (Exception e) {
			LOGGER.error("Exception occurred while getting getColumnDetails : " + e.toString());
			throw new ApplicationException("Exception has occurred :: getColumnDetails() ", e);
		}
		

	}

	@SuppressWarnings("unchecked")
	@Override
	public boolean saveOrDeleteEcmUserPreference(EcmUserPreference ecmUserPreference, boolean isSelected)
			throws Exception {
		try {
			Session session = sessionFactory.getCurrentSession();
			List<EcmUserPreference> resultList = session.createQuery(QueryConstants.GET_ECMUSER_PREFERENCE)
					.setLong("viewColumnId", ecmUserPreference.getViewColumnId())
					.setLong("userId", ecmUserPreference.getUserId()).list();
			if (CollectionUtils.isEmpty(resultList) && isSelected) {
				session.save(ecmUserPreference);
			} else if (!CollectionUtils.isEmpty(resultList) && !isSelected) {
				session.delete(resultList.get(0));
			}
		} catch (Exception e) {
			LOGGER.error("Exception occurred while getEcmUserPreference : " + e.toString());
			throw new ApplicationException("Exception has occurred :: getEcmUserPreference() ", e);
		}
		return false;
	}
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	public EcmViewColumn getEcmViewColumn(Long viewId, Long columnId) throws Exception {
		try {
			Session session = sessionFactory.getCurrentSession();
			List<EcmViewColumn> resultList = session.createQuery(QueryConstants.GET_ECM_VIEW_COLUMN)
					.setLong("viewId", viewId).setLong("columnId", columnId).list();
			if (!CollectionUtils.isEmpty(resultList))
				return resultList.get(0);
		} catch (Exception e) {
			LOGGER.error("Exception occurred while User is getEcmViewColumn : " + e.toString());
			throw new ApplicationException("Exception has occurred :: getEcmViewColumn() ", e);
		}
		return null;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	public EcmUserSetting getUseSetting(String userId, String viewId) throws Exception {
		try {
			Session session = sessionFactory.getCurrentSession();
			List<EcmUserSetting> resultList = session.createQuery(QueryConstants.GET_USER_SETTING)
					.setString("ssoId", userId).setString("viewName", viewId).list();
			if (!CollectionUtils.isEmpty(resultList))
				return resultList.get(0);
		} catch (Exception e) {
			LOGGER.error("Exception occurred while User is getUseSetting : " + e.toString());
			throw new ApplicationException("Exception has occurred :: getEcmUserPreference() ", e);
		}
		return null;

	}

	@Override
	public Long saveOrUpdateSetting(EcmUserSetting ecmUserSetting) throws Exception {
		sessionFactory.getCurrentSession().saveOrUpdate(ecmUserSetting);
		return ecmUserSetting.getId();
	}
	
	@Override
	public Long saveOrUpdateSetting(ColumnsSortOrderSettings ecmColumnsOrderSettings) throws Exception {
		LOGGER.debug("saveOrUpdateSetting method starts");
		try {
			sessionFactory.getCurrentSession().saveOrUpdate(ecmColumnsOrderSettings);
			return ecmColumnsOrderSettings.getId();
		} catch (Exception e) {
			LOGGER.error("Exception occurred while User is saveOrUpdateSetting : " + e.toString());
			throw new ApplicationException("Exception has occurred :: saveOrUpdateSetting() ", e);
		}
	}
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	public List<ColumnsSortOrderSettings> getEcmColumnsOrderSetting(Long ecmUserSettingId) throws Exception {
		LOGGER.debug("getEcmColumnsOrderSetting method starts");
		try {
			List<ColumnsSortOrderSettings> resultList = new ArrayList<ColumnsSortOrderSettings>();
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(ColumnsSortOrderSettings.class);
			criteria.add(Restrictions.eq("ecmUserSettingId", ecmUserSettingId));
			criteria.addOrder(Order.asc("ecmColumnIdOrder"));
			resultList = criteria.list();
			return resultList;
		} catch (Exception e) {
			LOGGER.error("Exception occurred while User is getEcmColumnsOrderSetting : " + e.toString());
			throw new ApplicationException("Exception has occurred :: getEcmColumnsOrderSetting() ", e);
		}
	}

	@SuppressWarnings({ "unchecked" })
	@Override
	public void deleteEcmColumnsOrderSettingIfPresent(Long ecmUserSettingId, Long ecmColumnIdOrder) throws Exception{
		LOGGER.debug("deleteEcmColumnsOrderSettingIfPresent method starts");
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(ColumnsSortOrderSettings.class);
			criteria.add(Restrictions.eq("ecmUserSettingId", ecmUserSettingId));
			criteria.add(Restrictions.eq("ecmColumnIdOrder", ecmColumnIdOrder));
			List<ColumnsSortOrderSettings> resultList = criteria.list();
			if (CollectionUtils.isNotEmpty(resultList)) {
				ColumnsSortOrderSettings ecmColumnsOrderSettings = (ColumnsSortOrderSettings) session
						.load(ColumnsSortOrderSettings.class, resultList.get(0).getId());
				session.delete(ecmColumnsOrderSettings);
			}
		} catch (Exception e) {
			LOGGER.error("Exception occurred while User is deleteEcmColumnsOrderSettingIfPresent : " + e.toString());
			throw new ApplicationException("Exception has occurred :: deleteEcmColumnsOrderSettingIfPresent() ", e);
		}
	}

	@Override
	@Transactional(readOnly = true)
	public ColumnsSortOrderSettings getEcmFirstColumnOrderSetting(Long ecmUserSettingId) throws Exception {
		LOGGER.debug("getEcmFirstColumnOrderSetting method starts");
		try {
			Session session = sessionFactory.getCurrentSession();
			Criteria criteria = session.createCriteria(ColumnsSortOrderSettings.class);
			criteria.add(Restrictions.eq("ecmUserSettingId", ecmUserSettingId));
			criteria.add(Restrictions.eq("ecmColumnIdOrder", 1L));
			ColumnsSortOrderSettings ecmColumnsOrderSettings = (ColumnsSortOrderSettings) criteria.uniqueResult();
			return ecmColumnsOrderSettings;
		} catch (Exception e) {
			LOGGER.error("Exception occurred while User is getEcmFirstColumnOrderSetting : " + e.toString());
			throw new ApplicationException("Exception has occurred :: getEcmFirstColumnOrderSetting() ", e);
		}
	}
}
