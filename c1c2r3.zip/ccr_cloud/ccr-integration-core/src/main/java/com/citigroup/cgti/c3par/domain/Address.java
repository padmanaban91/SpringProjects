package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;


/**
 * The Class Address.
 */
public class Address extends Base implements Serializable{

    /** The address1. */
    private String address1;

    /** The address2. */
    private String address2;

    /** The city. */
    private String city;

    /** The state. */
    private String state;

    /** The zip code. */
    private String zipCode;

    /** The country. */
    private String country;

    /**
     * Gets the address1.
     *
     * @return the address1
     */
    public String getAddress1() {
	return address1;
    }

    /**
     * Sets the address1.
     *
     * @param address1 the new address1
     */
    public void setAddress1(String address1) {
	this.address1 = address1;
    }

    /**
     * Gets the address2.
     *
     * @return the address2
     */
    public String getAddress2() {
	return address2;
    }

    /**
     * Sets the address2.
     *
     * @param address2 the new address2
     */
    public void setAddress2(String address2) {
	this.address2 = address2;
    }

    /**
     * Gets the city.
     *
     * @return the city
     */
    public String getCity() {
	return city;
    }

    /**
     * Sets the city.
     *
     * @param city the new city
     */
    public void setCity(String city) {
	this.city = city;
    }

    /**
     * Gets the country.
     *
     * @return the country
     */
    public String getCountry() {
	return country;
    }

    /**
     * Sets the country.
     *
     * @param country the new country
     */
    public void setCountry(String country) {
	this.country = country;
    }

    /**
     * Gets the state.
     *
     * @return the state
     */
    public String getState() {
	return state;
    }

    /**
     * Sets the state.
     *
     * @param state the new state
     */
    public void setState(String state) {
	this.state = state;
    }

    /**
     * Gets the zip code.
     *
     * @return the zip code
     */
    public String getZipCode() {
	return zipCode;
    }

    /**
     * Sets the zip code.
     *
     * @param zipCode the new zip code
     */
    public void setZipCode(String zipCode) {
	this.zipCode = zipCode;
    }

}
