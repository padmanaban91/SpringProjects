package com.citigroup.cgti.c3par.connection.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;


/**
 * The Class ConnectionFWPolicyMaster.
 */
public class ConnectionFWPolicyMaster extends PerformerPagerDO {



    /** The firewall policy name. */
    private String firewallPolicyName;

    /** The firewall type. */
    private String firewallType;

    /** The firewall mgmt region. */
    private ConnectionFWMgmtRegion firewallMgmtRegion = new ConnectionFWMgmtRegion();

    /** The firewall location. */
    private ConnectionFWLocation firewallLocation = new ConnectionFWLocation();

    /** The cp firewall list. */
    private List cpFirewallList;

    /** The delete flag. */
    private String deleteFlag;

    /** The created_date. */
    private Date created_date;

    /** The updated_date. */
    private Date updated_date;

    /** The connection fw zone master list. */
    private List connectionFWZoneMasterList;

    /** The is zoned. */
    private String isZoned;

    /**
     * Instantiates a new connection fw policy master.
     */
    public ConnectionFWPolicyMaster() {
	setTableName(PerformerTypes.CON_FW_POLICY_MASTER);
	setSequenceName(PerformerTypes.CON_FW_POLICY_MASTER_SEQ);
	// ----------
	addToDBMapping("firewallPolicyName", "FW_POLICY_NAME",1);
	addToDBMapping("firewallType", "FW_TYPE",2);
	addToDBMapping("firewallMgmtRegion", "FW_MGMT_REGION_ID",3);
	addToDBMapping("deleteFlag", "DELETE_FLAG",4);
	addToDBMapping("created_date", "CREATED_DATE",5);
	addToDBMapping("updated_date", "UPDATED_DATE",6);
	addToDBMapping("firewallLocation", "FW_LOCATION_ID",7);
	addToDBMapping("isZoned", "IS_ZONED",8);
	// -------------
	addToChildList("cpFirewallList", new ConnectionCPFirewall());
	addToChildList("connectionFWZoneMasterList",new ConnectionFWZoneMaster());
	addToNonCompositionList("firewallMgmtRegion");
	addToNonCompositionList("firewallLocation");
	// -------------
	addToDefaultValueMap("deleteFlag", "F");
	// -------------

    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.domain.Base#getCreated_date()
     */
    public Date getCreated_date() {
	return created_date;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.domain.Base#setCreated_date(java.util.Date)
     */
    public void setCreated_date(Date created_date) {
	this.created_date = created_date;
    }

    /**
     * Gets the delete flag.
     *
     * @return the delete flag
     */
    public String getDeleteFlag() {
	return deleteFlag;
    }

    /**
     * Sets the delete flag.
     *
     * @param deleteFlag the new delete flag
     */
    public void setDeleteFlag(String deleteFlag) {
	this.deleteFlag = deleteFlag;
    }

    /**
     * Gets the firewall mgmt region.
     *
     * @return the firewall mgmt region
     */
    public ConnectionFWMgmtRegion getFirewallMgmtRegion() {
	return firewallMgmtRegion;
    }

    /**
     * Sets the firewall mgmt region.
     *
     * @param firewallMgmtRegion the new firewall mgmt region
     */
    public void setFirewallMgmtRegion(ConnectionFWMgmtRegion firewallMgmtRegion) {
	this.firewallMgmtRegion = firewallMgmtRegion;
    }

    /**
     * Gets the firewall policy name.
     *
     * @return the firewall policy name
     */
    public String getFirewallPolicyName() {
	return firewallPolicyName;
    }

    /**
     * Sets the firewall policy name.
     *
     * @param firewallPolicyName the new firewall policy name
     */
    public void setFirewallPolicyName(String firewallPolicyName) {
	this.firewallPolicyName = firewallPolicyName;
    }

    /**
     * Gets the firewall type.
     *
     * @return the firewall type
     */
    public String getFirewallType() {
	return firewallType;
    }

    /**
     * Sets the firewall type.
     *
     * @param firewallType the new firewall type
     */
    public void setFirewallType(String firewallType) {
	this.firewallType = firewallType;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.domain.Base#getUpdated_date()
     */
    public Date getUpdated_date() {
	return updated_date;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.domain.Base#setUpdated_date(java.util.Date)
     */
    public void setUpdated_date(Date updated_date) {
	this.updated_date = updated_date;
    }

    /**
     * Gets the cp firewall list.
     *
     * @return the cp firewall list
     */
    public List getCpFirewallList() {
	return cpFirewallList;
    }

    /**
     * Sets the cp firewall list.
     *
     * @param cpFirewallList the new cp firewall list
     */
    public void setCpFirewallList(List cpFirewallList) {
	this.cpFirewallList = cpFirewallList;
    }

    /**
     * Gets the firewall location.
     *
     * @return the firewall location
     */
    public ConnectionFWLocation getFirewallLocation() {
	return firewallLocation;
    }

    /**
     * Sets the firewall location.
     *
     * @param firewallLocation the new firewall location
     */
    public void setFirewallLocation(ConnectionFWLocation firewallLocation) {
	this.firewallLocation = firewallLocation;
    }

    /**
     * Gets the connection fw zone master list.
     *
     * @return the connection fw zone master list
     */
    public List getConnectionFWZoneMasterList() {
	return connectionFWZoneMasterList;
    }

    /**
     * Sets the connection fw zone master list.
     *
     * @param connectionFWZoneMasterList the new connection fw zone master list
     */
    public void setConnectionFWZoneMasterList(List connectionFWZoneMasterList) {
	this.connectionFWZoneMasterList = connectionFWZoneMasterList;
    }

    /**
     * Gets the checks if is zoned.
     *
     * @return the checks if is zoned
     */
    public String getIsZoned() {
	return isZoned;
    }

    /**
     * Sets the checks if is zoned.
     *
     * @param isZoned the new checks if is zoned
     */
    public void setIsZoned(String isZoned) {
	this.isZoned = isZoned;
    }

    /**
     * Constructs a <code>String</code> with all attributes
     * in name = value format.
     *
     * @return a <code>String</code> representation 
     * of this object.
     */
    public String toString()
    {
	final String TAB = "    ";

	StringBuffer retValue = new StringBuffer();

	retValue.append("ConnectionFWPolicyMaster ( ")
	.append(super.toString()).append(TAB)
	.append("cpFirewallList = ").append(this.cpFirewallList).append(TAB)
	.append("created_date = ").append(this.created_date).append(TAB)
	.append("deleteFlag = ").append(this.deleteFlag).append(TAB)
	.append("firewallMgmtRegion = ").append(this.firewallMgmtRegion).append(TAB)
	.append("firewallPolicyName = ").append(this.firewallPolicyName).append(TAB)
	.append("firewallType = ").append(this.firewallType).append(TAB)
	.append("updated_date = ").append(this.updated_date).append(TAB)
	.append("firewallLocation = ").append(this.firewallLocation).append(TAB)
	.append(" )");

	return retValue.toString();
    }



}
