/**
 * 
 */
package com.citigroup.cgti.c3par.communication.domain.soc.persist;

import java.util.List;

import com.citigroup.cgti.c3par.communication.domain.CMPRequest;
import com.citigroup.cgti.c3par.communication.domain.CmpConnectionDetail;
import com.citigroup.cgti.c3par.communication.domain.ECMUserSearchProcess;
import com.citigroup.cgti.c3par.communication.domain.ColumnsSortOrderSettings;
import com.citigroup.cgti.c3par.communication.domain.EcmLeadQueue;
import com.citigroup.cgti.c3par.communication.domain.EcmLeadViewProcess;
import com.citigroup.cgti.c3par.communication.domain.LeadView;
import com.citigroup.cgti.c3par.persistance.Persistable;
import com.citigroup.cgti.c3par.relationship.domain.DsmtSgmntSector;
import com.citigroup.cgti.c3par.relationship.domain.Sector;

/**
 * @author eg41091
 * 
 * 
 */
public interface EcmLeadViewPersistable extends Persistable {

    public List<CMPRequest> selectLeadDetails(EcmLeadViewProcess ecmLeadViewProcess, String sectorId);

    public List<EcmLeadViewProcess> selectEcmUsers(String searchUser);

    public boolean updateAssignedEcmUser(String cmpReqId, String AssignTo, Long sloDays, String userId,
            String leadComments);

    public List<EcmLeadQueue> getAgentListForSector(String soeId2);

    public void addAgentToDoNotAssign(EcmLeadViewProcess ecmLeadViewProcess);

    public void addCTIAgentToDoNotAssign(EcmLeadViewProcess ecmLeadViewProcess);

    public void addICGAgentToDoNotAssign(EcmLeadViewProcess ecmLeadViewProcess);

    public List<CmpConnectionDetail> getProcessList(String ccrId);

    public String getdateForHeader();

    public CMPRequest getCMPRequestDetails(String cmpReqId);

    public List<ECMUserSearchProcess> searchEcmUsers(String searchUser,boolean isServiceDesk);

    public boolean checkValidUser(String ssoid);

    public List<String> getCMPSectorList();

    public List<String> getSupportTeamUsersList(String soeIds);

    public List<Sector> getProjectSectorList();

    public boolean updateAssignedEcmUser(String cmpReqId, String AssignTo, Long sloDays, String userId,
            String leadComments, String projectSector);

    public List<DsmtSgmntSector> getDsmtSgmntSectorList();

    List<LeadView> selectLeadViewDetails(EcmLeadViewProcess ecmLeadViewProcess, String sectorId);

	public List<LeadView> selectLeadViewDetails(EcmLeadViewProcess ecmLeadViewProcess, boolean isExport,
			List<ColumnsSortOrderSettings> ecmColumnsOrderSettingsList);

    public EcmLeadViewProcess getCTITeamQueueList(EcmLeadViewProcess ecmLeadViewProcess);

    public EcmLeadViewProcess getICGTeamQueueList(EcmLeadViewProcess ecmLeadViewProcess);

    public String getHeaderStringForTeamQueue();

    public void saveAgentToDoNotAssign(String agentId, String comments, boolean isSelected, String leadId);

    public EcmLeadViewProcess getECMTeamNames(EcmLeadViewProcess ecmLeadViewProcess);

	public List<DsmtSgmntSector> getDsmtSgmntSectorList(String regionName);
}
