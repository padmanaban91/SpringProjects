package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@SuppressWarnings("serial")
@XmlRootElement
public class ACVSummaryEmailUserVO   implements Serializable {
	    // Attributes
	    /** The sso id. */
	    private	String	ssoId;

	    /** The first name. */
	    private	String	firstName;

	    /** The last name. */
	    private	String	lastName;

	    /** The email. */
	    private	String	email;
	    
	    private String processIdVal;

	    /** The CCR ID  & Roles. */
	    private List<ConnectionRole> connRoles = new ArrayList<ConnectionRole> ();
	    
	    

	    public static class ConnectionRole {
	    	   
	      	private String ccr_id;
	 	   
	    	private String role;
	    	
	    	private String connName;
	    	
	    	public ConnectionRole () {}
	    	public ConnectionRole(String ccrIdVal, String roleVal,String connectionName) {
				ccr_id = ccrIdVal;
				role = roleVal;
				connName = connectionName;
			 }
			 
	    	   
	    	   @XmlElement
	    		public String getCcr_id() {
	    			return ccr_id;
	    		}
	    		public void setCcr_id(String ccr_id) {
	    			this.ccr_id = ccr_id;
	    		}
	    		
	    		@XmlElement
	    		public String getRole() {
	    			return role;
	    		}
	    		public void setRole(String role) {
	    			this.role = role;
	    		}
	    		
	    		@XmlElement
				public String getConnName() {
					return connName;
				}
				public void setConnName(String connName) {
					this.connName = connName;
				}
	    		
	    		
	          }
	    
	    
	    public ACVSummaryEmailUserVO () {}
	    
 	    public ACVSummaryEmailUserVO (String ssoIdVal,String firstNameVal,String lastNameVal,String emailVal,String ccrId,String role,String connectionName) {
	    	ssoId = ssoIdVal;
	    	firstName = firstNameVal;
	    	lastName = lastNameVal;
	    	email = emailVal;
	    	connRoles.add(new ConnectionRole (ccrId,role,connectionName));
	    }
	    
	  
 	   @XmlElement
		public String getSsoId() {
			return ssoId;
		}

		public void setSsoId(String ssoId) {
			this.ssoId = ssoId;
		}

		 @XmlElement
		public String getFirstName() {
			return firstName;
		}

		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		
		@XmlElement
		public String getLastName() {
			return lastName;
		}

		public void setLastName(String lastName) {
			this.lastName = lastName;
		}

		 @XmlElement
		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}
 	
		public String getProcessIdVal() {
			return processIdVal;
		}

		public void setProcessIdVal(String processIdVal) {
			this.processIdVal = processIdVal;
		}

		 @XmlElement
		public List<ConnectionRole> getConnRoles() {
			return connRoles;
		}

		public void setConnRoles(List<ConnectionRole> connRoles) {
			this.connRoles = connRoles;
		}

	 
}
