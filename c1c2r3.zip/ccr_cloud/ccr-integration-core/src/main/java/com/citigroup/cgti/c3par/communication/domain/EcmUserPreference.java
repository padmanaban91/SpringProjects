package com.citigroup.cgti.c3par.communication.domain;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.citigroup.cgti.c3par.user.domain.C3parUser;

public class EcmUserPreference extends EcmBaseEntity{
  
	/**
	 * 
	 */
	private static final long serialVersionUID = 154542515761L;
	private Long id;
    private C3parUser c3parUser;
    private EcmViewColumn ecmViewColumn;
    private String sortByColumn;
    private String sortOrder;
    private Long resultsPerPage;
    private Long userId;
    private Long viewColumnId;
    

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public C3parUser getC3parUser() {
        return c3parUser;
    }

    public void setC3parUser(C3parUser c3parUser) {
        this.c3parUser = c3parUser;
    }

    public EcmViewColumn getEcmViewColumn() {
        return ecmViewColumn;
    }

    public void setEcmViewColumn(EcmViewColumn ecmViewColumn) {
        this.ecmViewColumn = ecmViewColumn;
    }

    public String getSortByColumn() {
        return sortByColumn;
    }

    public void setSortByColumn(String sortByColumn) {
        this.sortByColumn = sortByColumn;
    }

    public String getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(String sortOrder) {
        this.sortOrder = sortOrder;
    }

    public Long getResultsPerPage() {
        return resultsPerPage;
    }

    public void setResultsPerPage(Long resultsPerPage) {
        this.resultsPerPage = resultsPerPage;
    }
    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getViewColumnId() {
        return viewColumnId;
    }

    public void setViewColumnId(Long viewColumnId) {
        this.viewColumnId = viewColumnId;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

}
