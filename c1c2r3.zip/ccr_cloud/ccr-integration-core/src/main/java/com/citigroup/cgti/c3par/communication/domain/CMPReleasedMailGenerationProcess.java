package com.citigroup.cgti.c3par.communication.domain;

import java.util.List;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;
import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.ccrcmpmapping.service.CCRCMPMappingService;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;

public class CMPReleasedMailGenerationProcess {

	protected CCRBeanFactory ccrBeanFactory;
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}
	
	protected String chooseEmail;
	protected String activeCcrId;
	protected String orderItemId;
	protected String taskName;
	protected String ecmRole;


	public String getChooseEmail() {
		return chooseEmail;
	}

	public void setChooseEmail(String chooseEmail) {
		this.chooseEmail = chooseEmail;
	}
	
	public String getOrderItemId() {
		return orderItemId;
	}

	public void setOrderItemId(String orderItemId) {
		this.orderItemId = orderItemId;
	}

	public String getActiveCcrId() {
		return activeCcrId;
	}

	public void setActiveCcrId(String activeCcrId) {
		this.activeCcrId = activeCcrId;
	}

	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getEcmRole() {
		return ecmRole;
	}
	public void setEcmRole(String ecmRole) {
		this.ecmRole = ecmRole;
	}

	public CitiContact getAgentDetails(String ssoId) {
        return ccrBeanFactory.getEmailGenViewServicePersistable().getAgentDetails(ssoId);
    }
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void updateAddNoteDetails(CMPRequestNotes cmpRequestNotes) {
	      ccrBeanFactory.getEmailGenViewServicePersistable().updateAddNoteDetails(cmpRequestNotes);
	}

	public void sendEmailGenerationView(String chooseEmail, CmpRequestDTO commEmail) {
        ccrBeanFactory.getiMailModule().sendEcmEmailViewGeneration(chooseEmail, commEmail);
    }

	public List<GenericLookup> loadGenericLookupByName(String name) {
        return ccrBeanFactory.getCommonServicePersistable().getGenericLookupByName(name);
    }
	
	public CitiContact getCitiContactByGEId(String geId) {
        return ccrBeanFactory.getCmpRequestPersistable().getuserIdForgGeid(geId);
    }
	
	public List<Map<String, String>> getChangeRequestDetails(Long conReqId) {
	        return ccrBeanFactory.getEmailGenViewServicePersistable().getChangeRequestDetails(conReqId);
	}
	
	public CMPRequest getCMPRequestDetails(String cmpReqId) {
        return ccrBeanFactory.getEmailGenViewServicePersistable().getCMPRequestDetails(cmpReqId);
    }
	
	public List<GenericLookup> loadGenericLookupData(List<String> names) {
        return ccrBeanFactory.getCommonServicePersistable().getGenericLookupData(names);
    }
	
	public boolean isWaitingforBusinessReply(Long cmpId, String activityCode, Long tiRequestId) {
        return ccrBeanFactory.getEmailGenViewServicePersistable().isWaitingforBusinessReply(cmpId, activityCode, tiRequestId);
    }

	public Map<String, String> getOrderItemIdStatusMap(String tiRequestId) throws Exception {
        return ccrBeanFactory.getCcrCMPMappingDAOService().getOrderItemIdStatusMap(tiRequestId);
    }
	
	public void sendCMPHoldReleasedEmail(CCRCMPMappingService ccrCMPMappingService,	String agentSsoId) {
		ccrBeanFactory.getEmailGenViewServicePersistable().sendCMPHoldReleasedEmail(this, ccrCMPMappingService, agentSsoId);
	}
}