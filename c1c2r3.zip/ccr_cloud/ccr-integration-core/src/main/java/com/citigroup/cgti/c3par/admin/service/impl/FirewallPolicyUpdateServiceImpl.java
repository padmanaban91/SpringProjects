package com.citigroup.cgti.c3par.admin.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.citigroup.cgti.c3par.admin.dao.service.FirewallPolicyUpdateDaoService;
import com.citigroup.cgti.c3par.admin.domain.FirewallPolicyDTO;
import com.citigroup.cgti.c3par.admin.service.FirewallPolicyUpdateService;
import com.citigroup.cgti.c3par.common.domain.ApplicationInstance;
import com.citigroup.cgti.c3par.common.domain.FirewallLocation;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.fw.domain.FireWallPolicyGroup;
import com.citigroup.cgti.c3par.fw.domain.FirewallPolicy;
import com.citigroup.cgti.c3par.fw.domain.FirewallRegion;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;
import com.citigroup.cgti.c3par.util.StringUtil;

/**
 * 
 *
 * @author ac81662
 */

/* Service Class for Manage Policy functionality */
@Service
public class FirewallPolicyUpdateServiceImpl implements FirewallPolicyUpdateService {

    private static final Logger log = Logger.getLogger(FirewallPolicyUpdateServiceImpl.class.getName());

    @Autowired
    CCRBeanFactory ccrBeanFactory;

    @Autowired
    private FirewallPolicyUpdateDaoService firewallPolicyUpdateDaoService;

    public FirewallPolicyUpdateDaoService getFirewallPolicyUpdateDaoService() {
        return firewallPolicyUpdateDaoService;
    }

    public void setFirewallPolicyUpdateDaoService(FirewallPolicyUpdateDaoService firewallPolicyUpdateDaoService) {
        this.firewallPolicyUpdateDaoService = firewallPolicyUpdateDaoService;
    }

    /* Search Policy service method */
    @Override
    public List<FirewallPolicyDTO> getPolicyList(String searchPolicyName) throws Exception {
        log.info("getPolicyList service method starts");
        List<FirewallPolicy> firewallPolicyList = new ArrayList<FirewallPolicy>();
        List<FirewallPolicyDTO> firewallPolicyDTOList = new ArrayList<FirewallPolicyDTO>();
        try {
            firewallPolicyList = firewallPolicyUpdateDaoService.getPolicyList(searchPolicyName);
            for (FirewallPolicy firewallPolicy : firewallPolicyList) {
                FirewallPolicyDTO firewallPolicyDTO = new FirewallPolicyDTO();
                firewallPolicyDTO.setPolicyId(firewallPolicy.getId());
                firewallPolicyDTO.setPolicyName(firewallPolicy.getName());
                firewallPolicyDTO.setFwType(firewallPolicy.getFwType());
                firewallPolicyDTO.setDeleteFlag(firewallPolicy.getDeleteFlag());
                if (firewallPolicy.getFirewallRegion() != null) {
                    firewallPolicyDTO.setMgmtRegion(firewallPolicy.getFirewallRegion().getRegion());
                }
                firewallPolicyDTO.setIsZoned(firewallPolicy.getIsZoned());
                if (firewallPolicy.getFireWallPolicyGroup() != null) {
                    firewallPolicyDTO.setGroup(firewallPolicy.getFireWallPolicyGroup().getName());
                }
                firewallPolicyDTO.setDeleteFlag(firewallPolicy.getDeleteFlag());
                if (firewallPolicy.getFirewallLocation() != null) {
                    firewallPolicyDTO.setFwLocation(firewallPolicy.getFirewallLocation().getFwLocation());
                }
                if (firewallPolicy.getApplicationInstance() != null) {
                    firewallPolicyDTO.setApplicationInstance(firewallPolicy.getApplicationInstance().getName());
                }
                firewallPolicyDTO.setComments(firewallPolicy.getComments());
                firewallPolicyDTO.setCreatedDate(firewallPolicy.getCreated_date());
                firewallPolicyDTO.setUpdatedDate(firewallPolicy.getUpdated_date());
                firewallPolicyDTOList.add(firewallPolicyDTO);
            }
        } catch (Exception e) {
            log.error("Exception in service method while searching Policies " + e.toString());
            log.error(e, e);
        }
        log.info("getPolicyList service method ends");
        return firewallPolicyDTOList;
    }

    /* Save policy service method */
    @Override
    public Long savePolicy(FirewallPolicyDTO firewallPolicyDto) throws Exception {
        log.info("savePolicy service method starts");
        FirewallPolicy firewallPolicy = new FirewallPolicy();
        Long newPolicyId = 0L;
        try {
            firewallPolicy.setName(firewallPolicyDto.getPolicyName());
            firewallPolicy.setFwType(firewallPolicyDto.getFwType());
            FirewallRegion firewallRegion = new FirewallRegion();
            if (firewallPolicyDto.getMgmtRegion() != null && !firewallPolicyDto.getMgmtRegion().equalsIgnoreCase("")) {
                firewallRegion = firewallPolicyUpdateDaoService.getFirewallRegion(firewallPolicyDto.getMgmtRegion());
            } else {
                firewallRegion = null;
            }
            firewallPolicy.setFirewallRegion(firewallRegion);
            if (!firewallPolicyDto.getIsZoned().equalsIgnoreCase("")) {
                firewallPolicy.setIsZoned(firewallPolicyDto.getIsZoned().toUpperCase());
            }
            firewallPolicy.setDeleteFlag("N");
            FireWallPolicyGroup fireWallPolicyGroup = new FireWallPolicyGroup();
            if (firewallPolicyDto.getGroup() != null && !firewallPolicyDto.getGroup().equalsIgnoreCase("")) {
                fireWallPolicyGroup = firewallPolicyUpdateDaoService
                        .getFireWallPolicyGroup(firewallPolicyDto.getGroup());
            } else {
                fireWallPolicyGroup = null;
            }
            firewallPolicy.setFireWallPolicyGroup(fireWallPolicyGroup);
            firewallPolicy.setCreated_date(new Date());
            ApplicationInstance applicationInstance = new ApplicationInstance();
            if (firewallPolicyDto.getApplicationInstance() != null
                    && !firewallPolicyDto.getApplicationInstance().equalsIgnoreCase("")) {
                applicationInstance = firewallPolicyUpdateDaoService
                        .getApplicationInstance(firewallPolicyDto.getApplicationInstance());
            } else {
                applicationInstance = null;
            }
            firewallPolicy.setApplicationInstance(applicationInstance);
            FirewallLocation firewallLocation = new FirewallLocation();
            if (firewallPolicyDto.getFwLocation() != null && !firewallPolicyDto.getFwLocation().equalsIgnoreCase("")) {
                firewallLocation = firewallPolicyUpdateDaoService
                        .getFirewallLocation(firewallPolicyDto.getFwLocation());
            } else {
                firewallLocation = null;
            }
            firewallPolicy.setFirewallLocation(firewallLocation);
            newPolicyId = firewallPolicyUpdateDaoService.savePolicy(firewallPolicy);
        } catch (Exception e) {
            log.error("Exception in service method while saving Policy" + e.toString());
            log.error(e, e);
        }
        log.info("savePolicy service method ends");
        return newPolicyId;
    }

    @Override
    public List<String> getFwLocationList() throws Exception {
        return firewallPolicyUpdateDaoService.getFwLocationList();
    }

    @Override
    public List<String> getMgmtRegionList() throws Exception {
        return firewallPolicyUpdateDaoService.getMgmtRegionList();
    }

    @Override
    public List<String> getGroupList() throws Exception {
        return firewallPolicyUpdateDaoService.getGroupList();
    }

    @Override
    public List<String> getApplicationInstanceList() throws Exception {
        return firewallPolicyUpdateDaoService.getApplicationInstanceList();
    }

    /* Delete policy service method */
    @Override
    public void deleteFirewallPolicy(FirewallPolicyDTO firewallPolicyDto) {
        log.info("deleteFirewallPolicy service method starts");
        FirewallPolicy firewallPolicy = new FirewallPolicy();
        try {
            firewallPolicy.setId(firewallPolicyDto.getPolicyId());
            firewallPolicy.setName(firewallPolicyDto.getPolicyName());
            firewallPolicy.setFwType(firewallPolicyDto.getFwType());
            FirewallRegion firewallRegion = new FirewallRegion();
            if (firewallPolicyDto.getMgmtRegion() != null && !firewallPolicyDto.getMgmtRegion().equalsIgnoreCase("")) {
                firewallRegion = firewallPolicyUpdateDaoService.getFirewallRegion(firewallPolicyDto.getMgmtRegion());
            } else {
                firewallRegion.setId(0L);
            }
            firewallPolicy.setFirewallRegion(firewallRegion);
            if (!firewallPolicyDto.getIsZoned().equalsIgnoreCase("")) {
                firewallPolicy.setIsZoned(firewallPolicyDto.getIsZoned());
            }
            firewallPolicy.setDeleteFlag("Y");
            FireWallPolicyGroup fireWallPolicyGroup = new FireWallPolicyGroup();
            if (firewallPolicyDto.getGroup() != null && !firewallPolicyDto.getGroup().equalsIgnoreCase("")) {
                fireWallPolicyGroup = firewallPolicyUpdateDaoService
                        .getFireWallPolicyGroup(firewallPolicyDto.getGroup());
            } else {
                fireWallPolicyGroup.setId(0L);
            }
            firewallPolicy.setFireWallPolicyGroup(fireWallPolicyGroup);
            firewallPolicy.setUpdated_date(new Date());
            ApplicationInstance applicationInstance = new ApplicationInstance();
            if (firewallPolicyDto.getApplicationInstance() != null
                    && !firewallPolicyDto.getApplicationInstance().equalsIgnoreCase("")) {
                applicationInstance = firewallPolicyUpdateDaoService
                        .getApplicationInstance(firewallPolicyDto.getApplicationInstance());
            } else {
                applicationInstance.setId(0L);
            }
            firewallPolicy.setApplicationInstance(applicationInstance);
            FirewallLocation firewallLocation = new FirewallLocation();
            if (firewallPolicyDto.getFwLocation() != null && !firewallPolicyDto.getFwLocation().equalsIgnoreCase("")) {
                firewallLocation = firewallPolicyUpdateDaoService
                        .getFirewallLocation(firewallPolicyDto.getFwLocation());
            } else {
                firewallLocation.setId(0L);
            }
            firewallPolicy.setFirewallLocation(firewallLocation);
            firewallPolicy.setComments(firewallPolicyDto.getComments());
            firewallPolicyUpdateDaoService.updateFirewallPolicy(firewallPolicy);
        } catch (Exception e) {
            log.error("Exception in service method while deleting Policy " + e.toString());
            log.error(e, e);
        }
        log.info("deleteFirewallPolicy service method ends");

    }

    /* Update policy service method */
    @Override
    public boolean updateFirewallPolicy(FirewallPolicyDTO firewallPolicyDto) {
        log.info("updateFirewallPolicy service method starts");
        boolean success = true;
        FirewallPolicy firewallPolicy = new FirewallPolicy();
        try {
            firewallPolicy.setId(firewallPolicyDto.getPolicyId());
            firewallPolicy.setName(firewallPolicyDto.getPolicyName());
            firewallPolicy.setFwType(firewallPolicyDto.getFwType());
            FirewallRegion firewallRegion = new FirewallRegion();
            if (firewallPolicyDto.getMgmtRegion() != null && !firewallPolicyDto.getMgmtRegion().equalsIgnoreCase("")) {
                firewallRegion = firewallPolicyUpdateDaoService.getFirewallRegion(firewallPolicyDto.getMgmtRegion());
            } else {
                firewallRegion.setId(0L);
            }
            firewallPolicy.setFirewallRegion(firewallRegion);
            if (!StringUtil.isNullorEmpty(firewallPolicyDto.getIsZoned())) {
                firewallPolicy.setIsZoned(firewallPolicyDto.getIsZoned().toUpperCase());
            }
            firewallPolicy.setDeleteFlag(firewallPolicyDto.getDeleteFlag());
            FireWallPolicyGroup fireWallPolicyGroup = new FireWallPolicyGroup();
            if (firewallPolicyDto.getGroup() != null && !firewallPolicyDto.getGroup().equalsIgnoreCase("")) {
                fireWallPolicyGroup = firewallPolicyUpdateDaoService
                        .getFireWallPolicyGroup(firewallPolicyDto.getGroup());
            } else {
                fireWallPolicyGroup.setId(0L);
            }
            firewallPolicy.setFireWallPolicyGroup(fireWallPolicyGroup);
            firewallPolicy.setUpdated_date(new Date());
            ApplicationInstance applicationInstance = new ApplicationInstance();
            if (firewallPolicyDto.getApplicationInstance() != null
                    && !firewallPolicyDto.getApplicationInstance().equalsIgnoreCase("")) {
                applicationInstance = firewallPolicyUpdateDaoService
                        .getApplicationInstance(firewallPolicyDto.getApplicationInstance());
            } else {
                applicationInstance.setId(0L);
            }
            firewallPolicy.setApplicationInstance(applicationInstance);
            FirewallLocation firewallLocation = new FirewallLocation();
            if (firewallPolicyDto.getFwLocation() != null && !firewallPolicyDto.getFwLocation().equalsIgnoreCase("")) {
                firewallLocation = firewallPolicyUpdateDaoService
                        .getFirewallLocation(firewallPolicyDto.getFwLocation());
            } else {
                firewallLocation.setId(0L);
            }
            firewallPolicy.setFirewallLocation(firewallLocation);
            firewallPolicy.setComments(firewallPolicyDto.getComments());
            success = firewallPolicyUpdateDaoService.updateFirewallPolicy(firewallPolicy);
        } catch (Exception e) {
            success = false;
            log.error("Exception in service method while updating Policy " + e.toString());
            log.error(e, e);
        }
        log.info("updateFirewallPolicy service method ends");
        return success;

    }

    @Override
    public List<GenericLookup> getFwTypeList() throws Exception {
        return ccrBeanFactory.getCommonServicePersistable().getFirewallTypes();
    }
}
