


/** CONFIDENTIAL  AND PROPRIETARY
 * Copyright @ 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is
 * strictly prohibited.
 */

package com.citigroup.cgti.c3par.dao;

import java.io.Serializable;
import java.sql.*;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.model.*;
import com.citigroup.cgti.c3par.dao.lookup.*;
import com.mentisys.model.*;
import com.mentisys.dao.*;
import com.mentisys.dao.query.*;
import com.mentisys.dao.audit.*;


// Reference imports

// Entity name = TIProcessDAO
// Table name = TI_PROCESS
// Superclass = <none>
// Subclasses = <none>

/**
 * The Class TIProcessDAO.
 */
public class TIProcessDAO
extends DatabaseAccessObject
implements Serializable
{

    /** The Constant TABLE. */
    public static final String	TABLE = "TI_PROCESS";

    /** The custom sequence. */
    private String customSequence;

    /** The database sequence. */
    private String databaseSequence;

    /** The log. */
    private static Logger log = Logger.getLogger(TIProcessDAO.class);

    /** The Constant ENTITY_NAME. */
    public static final String	ENTITY_NAME = "TIProcess";

    /** The Constant COLUMN_ID. */
    public static final String	COLUMN_ID = "ID";

    // Column names
    /** The Constant COLUMN_PROCESSNAME. */
    public static final String	COLUMN_PROCESSNAME = "PROCESS_NAME";

    /** The Constant COLUMN_PROCESSNAME_LEN. */
    public static final int		COLUMN_PROCESSNAME_LEN = 100;

    /** The Constant COLUMN_CREATEDATE. */
    public static final String	COLUMN_CREATEDATE = "CREATE_DATE";

    /** The Constant COLUMN_UPDATEDATE. */
    public static final String	COLUMN_UPDATEDATE = "UPDATE_DATE";

    /** The Constant COLUMN_PROCESSTERMINATEREASON. */
    public static final String	COLUMN_PROCESSTERMINATEREASON = "PROCESS_TERMINATE_REASON";

    /** The Constant COLUMN_PROCESSTERMINATEREASON_LEN. */
    public static final int		COLUMN_PROCESSTERMINATEREASON_LEN = 1000;

    /** The Constant COLUMN_PROCESSUPDATEREASON. */
    public static final String	COLUMN_PROCESSUPDATEREASON = "PROCESS_UPDATE_REASON";

    /** The Constant COLUMN_PROCESSUPDATEREASON_LEN. */
    public static final int		COLUMN_PROCESSUPDATEREASON_LEN = 1000;

    /** The Constant COLUMN_VERSIONNUMBER. */
    public static final String	COLUMN_VERSIONNUMBER = "VERSION_NUMBER";

    /** The Constant COLUMN_ISHIGHRISK. */
    public static final String	COLUMN_ISHIGHRISK = "IS_HIGH_RISK";

    /** The Constant COLUMN_ISHIGHRISK_LEN. */
    public static final int		COLUMN_ISHIGHRISK_LEN = 1;

    /** The Constant COLUMN_ISBROADACCESS. */
    public static final String	COLUMN_ISBROADACCESS = "IS_BROAD_ACCESS";

    /** The Constant COLUMN_ISBROADACCESS_LEN. */
    public static final int		COLUMN_ISBROADACCESS_LEN = 1;

    /** The Constant COLUMN_ISDELETED. */
    public static final String	COLUMN_ISDELETED = "IS_DELETED";

    /** The Constant COLUMN_ISDELETED_LEN. */
    public static final int		COLUMN_ISDELETED_LEN = 1;

    /** The Constant COLUMN_PROCESSACTIVITYMODE. */
    public static final String	COLUMN_PROCESSACTIVITYMODE = "PROCESS_ACTIVITY_MODE";

    /** The Constant COLUMN_PROCESSACTIVITYMODE_LEN. */
    public static final int		COLUMN_PROCESSACTIVITYMODE_LEN = 30;
    // Column names of references
    /** The Constant COLUMN_PROCESSTYPE_ID. */
    public static final String	COLUMN_PROCESSTYPE_ID = "PROCESS_TYPE_ID";

    /** The Constant COLUMN_ENTITLEMENTINSTANCE_ID. */
    public static final String	COLUMN_ENTITLEMENTINSTANCE_ID = "ENTITLEMENT_INSTANCE_ID";

    /** The Constant COLUMN_RELATIONSHIP_ID. */
    public static final String	COLUMN_RELATIONSHIP_ID = "RELATIONSHIP_ID";

    /** The Constant COLUMN_PROCESSSTATUS_ID. */
    public static final String	COLUMN_PROCESSSTATUS_ID = "PROCESS_STATUS_ID";

    // DAO Queries
    /** The SELEC t_ i d_ stmt. */
    private static String SELECT_ID_STMT = "SELECT "  + COLUMN_ID + " FROM " + TIProcessDAO.TABLE;

    /** The SELEC t_ stmt. */
    private static String SELECT_STMT = "SELECT "  + COLUMN_ID
    + ", " + COLUMN_PROCESSNAME
    + ", " + COLUMN_CREATEDATE
    + ", " + COLUMN_UPDATEDATE
    + ", " + COLUMN_PROCESSTERMINATEREASON
    + ", " + COLUMN_PROCESSUPDATEREASON
    + ", " + COLUMN_VERSIONNUMBER
    + ", " + COLUMN_ISHIGHRISK
    + ", " + COLUMN_ISBROADACCESS
    + ", " + COLUMN_ISDELETED
    + ", " + COLUMN_PROCESSACTIVITYMODE
    + ", " + COLUMN_PROCESSTYPE_ID
    + ", " + COLUMN_ENTITLEMENTINSTANCE_ID
    + ", " + COLUMN_RELATIONSHIP_ID
    + ", " + COLUMN_PROCESSSTATUS_ID
    + " FROM " + TIProcessDAO.TABLE;

    /** The SELEC t_ b y_ i d_ stmt. */
    private static String SELECT_BY_ID_STMT = TIProcessDAO.SELECT_STMT + " WHERE " + COLUMN_ID + " = ?";

    /** The UPDAT e_ b y_ i d_ stmt. */
    private static String UPDATE_BY_ID_STMT = "UPDATE " + TIProcessDAO.TABLE + " SET "
    + COLUMN_PROCESSNAME + " = ? "
    + ", " + COLUMN_CREATEDATE + " = ? "
    + ", " + COLUMN_UPDATEDATE + " = ? "
    + ", " + COLUMN_PROCESSTERMINATEREASON + " = ? "
    + ", " + COLUMN_PROCESSUPDATEREASON + " = ? "
    + ", " + COLUMN_VERSIONNUMBER + " = ? "
    + ", " + COLUMN_ISHIGHRISK + " = ? "
    + ", " + COLUMN_ISBROADACCESS + " = ? "
    + ", " + COLUMN_ISDELETED + " = ? "
    + ", " + COLUMN_PROCESSACTIVITYMODE + " = ? "
    + ", " + COLUMN_PROCESSTYPE_ID + " = ? "
    + ", " + COLUMN_ENTITLEMENTINSTANCE_ID + " = ? "
    + ", " + COLUMN_RELATIONSHIP_ID + " = ? "
    + ", " + COLUMN_PROCESSSTATUS_ID + " = ? "
    + " WHERE " + COLUMN_ID + " = ?";

    /** The INSER t_ stmt. */
    private static String INSERT_STMT = "INSERT INTO " + TIProcessDAO.TABLE
    + "(" + COLUMN_ID
    + ", " + COLUMN_PROCESSNAME 
    + ", " + COLUMN_CREATEDATE 
    + ", " + COLUMN_UPDATEDATE 
    + ", " + COLUMN_PROCESSTERMINATEREASON 
    + ", " + COLUMN_PROCESSUPDATEREASON 
    + ", " + COLUMN_VERSIONNUMBER 
    + ", " + COLUMN_ISHIGHRISK 
    + ", " + COLUMN_ISBROADACCESS 
    + ", " + COLUMN_ISDELETED 
    + ", " + COLUMN_PROCESSACTIVITYMODE 
    + ", " + COLUMN_PROCESSTYPE_ID
    + ", " + COLUMN_ENTITLEMENTINSTANCE_ID
    + ", " + COLUMN_RELATIONSHIP_ID
    + ", " + COLUMN_PROCESSSTATUS_ID
    + ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    /** The DELET e_ stmt. */
    private static String DELETE_STMT = "DELETE FROM " + TIProcessDAO.TABLE + " WHERE ID = ?";

    /** The Constant SELECT_C3PARPROCESSROLEXREF_REFERENCE_IDS_STMT. */
    private static final String SELECT_C3PARPROCESSROLEXREF_REFERENCE_IDS_STMT = "SELECT " + C3parProcessRoleXrefDAO.COLUMN_ID + " FROM " + C3parProcessRoleXrefDAO.TABLE + " WHERE " + C3parProcessRoleXrefDAO.COLUMN_PROCESS_ID + " = ?";

    /** The Constant SELECT_TIREQUEST_REFERENCE_IDS_STMT. */
    private static final String SELECT_TIREQUEST_REFERENCE_IDS_STMT = "SELECT " + TIRequestDAO.COLUMN_ID + " FROM " + TIRequestDAO.TABLE + " WHERE " + TIRequestDAO.COLUMN_PROCESS_ID + " = ?";


    //======================================================================
    /**
     * Simple factory method.
     *
     * @param session the session
     * @return the tI process dao
     */
    public static TIProcessDAO createInstance(DatabaseSession session)
    {
	return new TIProcessDAO(session);
    }

    // Contructors
    //======================================================================
    /**
     * Instantiates a new tI process dao.
     *
     * @param session the session
     */
    public TIProcessDAO(DatabaseSession session)
    {
	super(session);
	log.debug("Creating TIProcessDAO (" + s_CreateCount + ")");
    }

    //Sequence Generator
    /**
     * Sets the custom sequence.
     *
     * @param customSequence the new custom sequence
     */
    public void setCustomSequence(String customSequence){

	this.customSequence=customSequence;
    }

    //Sequence Generator
    /**
     * Sets the database sequence.
     *
     * @param databaseSequence the new database sequence
     */
    public void setDatabaseSequence(String databaseSequence){

	this.databaseSequence=databaseSequence;
    }


    // Insert
    //======================================================================
    /**
     * Insert an entity into the database.
     *
     * @param entity The TIProcessEntity to insert
     * @return The id that was assigned to the entity
     * @throws DatabaseException the database exception
     */
    public Long insert(TIProcessEntity entity) throws DatabaseException
    {
	return insert(entity, null, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long insert(TIProcessEntity entity, boolean reset) throws DatabaseException
    {
	return insert(entity, null, reset);
    }

    //======================================================================
    /**
     * Insert an entity into the database.
     *
     * @param entity The TIProcessEntity to insert
     * @param archiver The archiver object used for tracking changes to the entity
     * @return The id that was assigned to the entity
     * @throws DatabaseException the database exception
     */
    public Long insert(TIProcessEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	return insert(entity, archiver, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param archiver the archiver
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long insert(TIProcessEntity entity, AuditArchiver archiver, boolean reset) throws DatabaseException
    {
	log.debug("Inserting TIProcessEntity");
	DatabaseSession session = getSession();

	if(primaryKeyExists(entity, false, session))
	    throw new DatabaseException("Could not insert '" + TIProcessDAO.ENTITY_NAME + "' with id = " + entity.getId() + " due to unique key constraint violation", null);

	Connection connection = null;

	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    // Update FOREIGN_KEY references for which we are the OWNER

	    // Generate a new id
	    long id=-1;
	    if(customSequence !=null)
		id = KeyGenerator.getInstance().getNextKey(session, customSequence);
	    else if(databaseSequence != null){
		try{
		    st=connection.prepareStatement("Select "+databaseSequence+".nextval from dual");
		    rs = st.executeQuery();
		    if (rs.next())
		    {
			id=rs.getLong(1);
		    }
		}finally{
		    try{
			if(rs!=null)rs.close();
			if(st!=null)st.close();
		    }catch(Exception xe){}

		}
	    }
	    else
		id = KeyGenerator.getInstance().getNextKey(session, TIProcessDAO.ENTITY_NAME);
	    entity.setId(Long.valueOf(id));
	    int position = 1;
	    st = connection.prepareStatement(INSERT_STMT);
	    setLongToStatement(st, position++, entity.getId());

	    // Attributes
	    position = setStringToStatement(st, position, entity.getProcessName(), COLUMN_PROCESSNAME_LEN);
	    position = setDateToStatement(st, position, entity.getCreateDate());
	    position = setDateToStatement(st, position, entity.getUpdateDate());
	    position = setStringToStatement(st, position, entity.getProcessTerminateReason(), COLUMN_PROCESSTERMINATEREASON_LEN);
	    position = setStringToStatement(st, position, entity.getProcessUpdateReason(), COLUMN_PROCESSUPDATEREASON_LEN);
	    position = setIntegerToStatement(st, position, entity.getVersionNumber());
	    position = setStringToStatement(st, position, entity.getIsHighRisk(), COLUMN_ISHIGHRISK_LEN);
	    position = setStringToStatement(st, position, entity.getIsBroadAccess(), COLUMN_ISBROADACCESS_LEN);
	    position = setStringToStatement(st, position, entity.getIsDeleted(), COLUMN_ISDELETED_LEN);
	    position = setStringToStatement(st, position, entity.getProcessActivityMode(), COLUMN_PROCESSACTIVITYMODE_LEN);

	    // Association references
	    position = updateReferences(st, entity, position);

	    st.executeUpdate();
	    entity.setPrimaryKey(Long.valueOf(id));

	    // Update FOREIGN_KEY references for which we are the OWNER
	    updateC3parProcessRoleXrefReferences((TIProcessEntity) entity);
	    updateTIRequestReferences((TIProcessEntity) entity);
	    if (archiver != null)
	    {
		archiver.storeSnapshotAuditLogForEntity(entity, "create");
	    }
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not insert '" + TIProcessDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return entity.getPrimaryKey();
    }

    //======================================================================
    /**
     * Update the state of an entity. If the entity doesn't exist in the database it gets automatically added.
     *
     * @param entity The TIProcessEntity to update.
     * @return The Id of the entity. If the entity had to be inserted this is the id assigned to it.
     * @throws DatabaseException the database exception
     */
    public Long update(TIProcessEntity entity) throws DatabaseException
    {
	return update(entity, null, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(TIProcessEntity entity, boolean reset) throws DatabaseException
    {
	return update(entity, null, reset);
    }

    //======================================================================
    /**
     * Update the state of an entity. If the entity doesn't exist in the database it gets automatically added.
     *
     * @param entity The TIProcessEntity to update
     * @param archiver The archiver object used for tracking changes to the entity
     * @return The Id of the entity. If the entity had to be inserted this is the id assigned to it.
     * @throws DatabaseException the database exception
     */
    public Long update(TIProcessEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	return update(entity, archiver, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param archiver the archiver
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(TIProcessEntity entity, AuditArchiver archiver, boolean reset) throws DatabaseException
    {
	if (entity.getPrimaryKey() == null)
	{
	    // Not created yet
	    return insert(entity, archiver, reset);
	}
	if (!entity.isModified())
	{
	    return entity.getPrimaryKey();
	}
	log.debug("Updating TIProcessEntity [" + entity.getId() + "]");
	DatabaseSession session = getSession();

	if(primaryKeyExists(entity, true, session))
	    throw new DatabaseException("Could not update '" + TIProcessDAO.ENTITY_NAME + "' with id = " + entity.getId() + " due to unique key constraint violation", null);

	Connection		connection = null;
	PreparedStatement st = null;
	ResultSet 		rs = null;

	try
	{
	    connection = session.getConnection();
	    // Update FOREIGN_KEY references for which we are the OWNER

	    int position = 1;
	    st = connection.prepareStatement(UPDATE_BY_ID_STMT);

	    // Attributes
	    position = setStringToStatement(st, position, entity.getProcessName(), COLUMN_PROCESSNAME_LEN);
	    position = setDateToStatement(st, position, entity.getCreateDate());
	    position = setDateToStatement(st, position, entity.getUpdateDate());
	    position = setStringToStatement(st, position, entity.getProcessTerminateReason(), COLUMN_PROCESSTERMINATEREASON_LEN);
	    position = setStringToStatement(st, position, entity.getProcessUpdateReason(), COLUMN_PROCESSUPDATEREASON_LEN);
	    position = setIntegerToStatement(st, position, entity.getVersionNumber());
	    position = setStringToStatement(st, position, entity.getIsHighRisk(), COLUMN_ISHIGHRISK_LEN);
	    position = setStringToStatement(st, position, entity.getIsBroadAccess(), COLUMN_ISBROADACCESS_LEN);
	    position = setStringToStatement(st, position, entity.getIsDeleted(), COLUMN_ISDELETED_LEN);
	    position = setStringToStatement(st, position, entity.getProcessActivityMode(), COLUMN_PROCESSACTIVITYMODE_LEN);

	    // Association references
	    position = updateReferences(st, entity, position);

	    // where
	    setLongToStatement(st, position++, entity.getPrimaryKey());

	    st.executeUpdate();

	    // Update FOREIGN_KEY references for which we are the OWNER
	    updateC3parProcessRoleXrefReferences((TIProcessEntity) entity);
	    updateTIRequestReferences((TIProcessEntity) entity);
	    if (archiver != null)
	    {
		archiver.storeAuditLogForEntity(entity, "update");
	    }
	    if (reset)
	    {
		session.addToResetList(entity);
	    }
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not update '" + TIProcessDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return entity.getPrimaryKey();
    }

    //======================================================================
    /**
     * Get the entity determined by the id. This method automatically loads all references maintained by the entity.
     *
     * @param id A Long identifying the entity to get.
     * @return The entity or null if no entity with that id exists.
     * @throws DatabaseException the database exception
     */
    public TIProcessEntity get(Long id) throws DatabaseException
    {
	return get(id, true);
    }

    //======================================================================
    /**
     * Get the entity determined by the id.
     *
     * @param id A Long identifying the entity to get.
     * @param load_refs A boolean that determines wether to load all the entities references. True to load, false to defer loading until later.
     * @return The entity or null if no entity with that id exists.
     * @throws DatabaseException the database exception
     */
    public TIProcessEntity get(Long id, boolean load_refs) throws DatabaseException
    {
	Long id_to_get = id;
	TIProcessEntity obj = (TIProcessEntity) getSession().getObjectFromSession(ENTITY_NAME, id_to_get);
	log.debug("Getting TIProcessEntity with id = " + id_to_get); 
	if(obj != null)
	{
	    log.debug(">>> TIProcessEntity >>> already LOADED !!!"); 
	}

	if(obj == null)
	{
	    DatabaseSession session = getSession();
	    Connection connection = null;

	    PreparedStatement st = null;
	    ResultSet rs = null;

	    try
	    {
		connection = session.getConnection();
		//				st = session.getPreparedStatement(SELECT_BY_ID_STMT);
		st = connection.prepareStatement(SELECT_BY_ID_STMT);
		setLongToStatement(st, 1, id_to_get);
		rs = st.executeQuery();

		if (rs.next())
		{
		    obj = (TIProcessEntity) createEntity(rs);
		}
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not load " + TIProcessDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	}

	if (obj != null && load_refs)
	{
	    try
	    {
		// Load the associated objects
		loadReferences(obj);
		obj.setModified(false);
	    }
	    catch (DatabaseException e)
	    {
	    	log.error(e,e);
		throw new DatabaseException("Failed to load references of " + TIProcessDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	}
	log.debug("DONE Getting TIProcessEntity with id = " + id_to_get); 

	return obj;
    }


    //======================================================================
    /**
     * Retrieve the entities indicated by the list argument provided.
     *
     * @param id_list list of entity ids to load
     * @param load_refs Flag that determines wether the references should be loaded as part of the operation
     * @return A List of all the entities loaded.
     * @throws DatabaseException the database exception
     */
    public List get(List id_list, boolean load_refs) throws DatabaseException
    {
	List 	entity_list = new ArrayList(16);
	if(id_list != null && id_list.size() > 0)
	{
	    DatabaseSession 	session = getSession();
	    Connection 			connection = null;
	    Statement 			st = null;
	    ResultSet 			rs = null;
	    TIProcessEntity 		entity = null;

	    try
	    {
		StringBuffer statement = new StringBuffer(SELECT_STMT + " WHERE " + COLUMN_ID + " IN (");

		Long only = null;
		long count = 0;
		Iterator iter = id_list.iterator();
		while(iter.hasNext())
		{
		    Long id = (Long)iter.next();
		    entity = (TIProcessEntity) getSession().getObjectFromSession(ENTITY_NAME, id);
		    if(entity != null)
		    {
			if(load_refs)
			{
			    loadReferences(entity);
			}
			entity_list.add(entity);
		    }
		    else // add the the id to the statement
		    {
			if(count++ > 0)
			{
			    statement.append(",");					
			}
			statement.append(id.toString());					
			only = id;
		    }
		}

		// check if we need to explicitly load any entities
		if(count == 1)
		{
		    entity_list.add(get(only, load_refs));					
		}
		else if(count > 1)
		{
		    statement.append(")");	// Close the statenemt's IN clause					
		    log.debug("DAO.get(List): executing statement. Count = (" + count + ") --> " + statement.toString());
		    connection = session.getConnection();
		    //					st = connection.prepareStatement(statement.toString());
		    //					rs = st.executeQuery();
		    st = connection.createStatement();
		    rs = st.executeQuery(statement.toString());

		    while(rs.next())
		    {
			entity = (TIProcessEntity) createEntity(rs);
			if(load_refs)
			{
			    loadReferences(entity);
			    entity.setModified(false);
			}
			entity_list.add(entity);					
		    }
		}
	    }
	    catch(SQLException e)
	    {
		throw new DatabaseException("Failed to load all entities of type " + TIProcessDAO.ENTITY_NAME + ".", e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		if(connection != null)
		{
		    session.releaseConnection();
		}
	    }
	}

	return entity_list;	
    }

    //======================================================================
    /**
     * Retrieve all entities.
     *
     * @param load_refs Flag that determines wether the references should be loaded as part of the operation
     * @return The list of all entities of type TIProcessEntity
     * @throws DatabaseException the database exception
     */
    public List getAll(boolean load_refs) throws DatabaseException
    {
	List 				entity_list = query(new Condition(), load_refs);
	/*
		DatabaseSession 	session = getSession();
		Connection 			connection = null;
		Statement 	st = null;
		ResultSet 			rs = null;
		TIProcessEntity 		entity = null;

		try
		{
			String select_stmt = "SELECT * FROM TI_PROCESS";
			connection = session.getConnection();

			st = connection.createStatement();
			rs = st.executeQuery(select_stmt.toString());

			while(rs.next())
			{
				entity = (TIProcessEntity) createEntity(rs);
				if(load_refs)
				{
					loadReferences(entity);
					entity.setModified(false);
				}
				entity_list.add(entity);					
			}
		}
		catch(SQLException e)
		{
			throw new DatabaseException("Failed to load all entities of type " + TIProcessDAO.ENTITY_NAME + ".", e);
		}
		finally
		{
			closeResultSet(rs);
			closeStatement(st);
			session.releaseConnection();
		}
	 */
	return entity_list;	
    }	

    //======================================================================
    /**
     * Retrieve the IDs of all entities.
     *
     * @return A list of IDs of all the entities of type TIProcessEntity
     * @throws DatabaseException the database exception
     */
    public List getAllIds() throws DatabaseException
    {
	return queryForId(new Condition());
    }

    //======================================================================
    /**
     * Checks wether the entity with the given ID already exists in the database.
     *
     * @param id The id of the entity to test.
     * @return A boolean that indicates exsitence (true) or lack thereof (false)
     * @throws DatabaseException the database exception
     */
    public boolean exists(String id) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;

	PreparedStatement st = null;
	ResultSet rs = null;
	boolean exists = false;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_BY_ID_STMT);
	    st.setString(1, id);
	    rs = st.executeQuery();
	    exists = rs.next();
	}
	catch (SQLException e)
	{
	    throw new DatabaseException("Could not verify existence of '" + TIProcessDAO.ENTITY_NAME + "' with id = "
		    + id, e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

	return exists;
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param id The id of the entity to be deleted from the database.
     * @throws DatabaseException the database exception
     */
    public void delete(Long id) throws DatabaseException
    {
	if(id != null)
	{
	    TIProcessEntity entity = get(id, false);
	    delete(entity, null);
	}
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param id The id of the entity to be deleted from the database.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(Long id, AuditArchiver archiver) throws DatabaseException
    {
	if(id != null)
	{
	    TIProcessEntity entity = get(id, false);
	    delete(entity, archiver);
	}
    }

    //======================================================================
    /**
     * Delete a list of entities from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity_ids A list of Long objects providing the ids of the entities to be deleted.
     * @throws DatabaseException the database exception
     */
    public void delete(List entity_ids) throws DatabaseException
    {
	delete(entity_ids, null);
    }

    //======================================================================
    /**
     * Delete a list of entities from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity_ids A list of Long objects providing the ids of the entities to be deleted.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(List entity_ids, AuditArchiver archiver) throws DatabaseException
    {
	if(entity_ids != null)
	{
	    Iterator iter = entity_ids.iterator();
	    while(iter.hasNext())
	    {
		Long id = (Long)iter.next();		
		delete(id, archiver);
	    }
	}
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity The entity to be deleted from the database.
     * @throws DatabaseException the database exception
     */
    public void delete(TIProcessEntity entity) throws DatabaseException
    {
	delete(entity, null);
    }

    //======================================================================
    /**
     * Delete an entity from the database. Deletion encompasses all composition entities associated with the entity to be deleted.
     *
     * @param entity The entity to be deleted from the database.
     * @param archiver The archiver to use to track audit information
     * @throws DatabaseException the database exception
     */
    public void delete(TIProcessEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	if(entity != null && entity.getId() != null)
	{
	    DatabaseSession session = getSession();
	    Connection connection = null;

	    if (archiver != null)
	    {
		archiver.storeSnapshotAuditLogForEntity(entity, "delete");
	    }


	    // Clear all associations and remove all compositions
	    deleteManyAssociations(entity);

	    // Delete ourself
	    PreparedStatement st = null;
	    ResultSet rs = null;

	    try
	    {
		connection = session.getConnection();
		// Generate a new id
		int position = 1;
		st = connection.prepareStatement(DELETE_STMT);
		position = setLongToStatement(st, position, entity.getPrimaryKey());

		st.execute();

		// COMPOSITION Delete ONE objects...

		entity.setPrimaryKey(null);
	    }
	    catch (SQLException e)
	    {
		throw new DatabaseException("Could not delete '" + TIProcessDAO.ENTITY_NAME + "' with id = "
			+ entity.getId(), e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	}
    }

    //======================================================================
    /**
     * Delete many associations.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    protected void deleteManyAssociations(TIProcessEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;

	try
	{
	    connection = session.getConnection();

	    // Go through the many association list and delete any entities that exist in it.
	    C3parProcessRoleXrefDAO c3parProcessRoleXrefDAO = getC3parProcessRoleXrefDAO();
	    List original_c3parProcessRoleXref_ids = entity.getOriginalC3parProcessRoleXrefIds();
	    Iterator c3parProcessRoleXrefIt = entity.getC3parProcessRoleXref().getDeletedList().iterator();
	    while (c3parProcessRoleXrefIt.hasNext())
	    {
		C3parProcessRoleXrefEntity o = (C3parProcessRoleXrefEntity)c3parProcessRoleXrefIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_c3parProcessRoleXref_ids.remove(id);
		}
		c3parProcessRoleXrefDAO.delete(o);
	    }

	    c3parProcessRoleXrefIt = entity.getC3parProcessRoleXref().iterator();
	    while (c3parProcessRoleXrefIt.hasNext())
	    {
		C3parProcessRoleXrefEntity o = (C3parProcessRoleXrefEntity)c3parProcessRoleXrefIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_c3parProcessRoleXref_ids.remove(id);
		}
		c3parProcessRoleXrefDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    c3parProcessRoleXrefDAO.delete(original_c3parProcessRoleXref_ids);

	    // Go through the many association list and delete any entities that exist in it.
	    TIRequestDAO tIRequestDAO = getTIRequestDAO();
	    List original_tIRequest_ids = entity.getOriginalTIRequestIds();
	    Iterator tIRequestIt = entity.getTIRequest().getDeletedList().iterator();
	    while (tIRequestIt.hasNext())
	    {
		TIRequestEntity o = (TIRequestEntity)tIRequestIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_tIRequest_ids.remove(id);
		}
		tIRequestDAO.delete(o);
	    }

	    tIRequestIt = entity.getTIRequest().iterator();
	    while (tIRequestIt.hasNext())
	    {
		TIRequestEntity o = (TIRequestEntity)tIRequestIt.next();
		Long id = o.getId();
		if(id != null)
		{
		    original_tIRequest_ids.remove(id);
		}
		tIRequestDAO.delete(o);
	    }

	    // take care of any remaining ones that aren't existing as entity instances in the many association list.
	    tIRequestDAO.delete(original_tIRequest_ids);
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to perform association clean up during delete of'" + TIProcessDAO.ENTITY_NAME + "' with id = "
		    + entity.getId(), e);
	}
	finally
	{
	    session.releaseConnection();
	}

    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#buildEntity(java.sql.ResultSet, com.mentisys.model.Entity)
     */
    protected void buildEntity(ResultSet rs, Entity obj) throws DatabaseException
    {
	TIProcessEntity entity = (TIProcessEntity) obj;
	try
	{
	    // TODO: Figure a better way of dealing with the absence of any attribute
	    dummyExceptionTosser(false);

	    int index = 1;

	    //			entity.setProcessName(getStringFromResultSet(rs, COLUMN_PROCESSNAME));
	    entity.setProcessName(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalProcessName(entity.getProcessName());
	    //			entity.setCreateDate(getDateFromResultSet(rs, COLUMN_CREATEDATE));
	    entity.setCreateDate(getDateFromResultSetIndexed(rs, ++index));
	    entity.setOriginalCreateDate(entity.getCreateDate());
	    //			entity.setUpdateDate(getDateFromResultSet(rs, COLUMN_UPDATEDATE));
	    entity.setUpdateDate(getDateFromResultSetIndexed(rs, ++index));
	    entity.setOriginalUpdateDate(entity.getUpdateDate());
	    //			entity.setProcessTerminateReason(getStringFromResultSet(rs, COLUMN_PROCESSTERMINATEREASON));
	    entity.setProcessTerminateReason(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalProcessTerminateReason(entity.getProcessTerminateReason());
	    //			entity.setProcessUpdateReason(getStringFromResultSet(rs, COLUMN_PROCESSUPDATEREASON));
	    entity.setProcessUpdateReason(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalProcessUpdateReason(entity.getProcessUpdateReason());
	    //			entity.setVersionNumber(getIntegerFromResultSet(rs, COLUMN_VERSIONNUMBER));
	    entity.setVersionNumber(getIntegerFromResultSetIndexed(rs, ++index));
	    entity.setOriginalVersionNumber(entity.getVersionNumber());
	    //			entity.setIsHighRisk(getStringFromResultSet(rs, COLUMN_ISHIGHRISK));
	    entity.setIsHighRisk(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalIsHighRisk(entity.getIsHighRisk());
	    //			entity.setIsBroadAccess(getStringFromResultSet(rs, COLUMN_ISBROADACCESS));
	    entity.setIsBroadAccess(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalIsBroadAccess(entity.getIsBroadAccess());
	    //			entity.setIsDeleted(getStringFromResultSet(rs, COLUMN_ISDELETED));
	    entity.setIsDeleted(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalIsDeleted(entity.getIsDeleted());
	    //			entity.setProcessActivityMode(getStringFromResultSet(rs, COLUMN_PROCESSACTIVITYMODE));
	    entity.setProcessActivityMode(getStringFromResultSetIndexed(rs, ++index));
	    entity.setOriginalProcessActivityMode(entity.getProcessActivityMode());

	    // Single References
	    //			entity.setProcessTypeId(getLongFromResultSet(rs, COLUMN_PROCESSTYPE_ID));
	    entity.setProcessTypeId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalProcessTypeId(entity.getProcessTypeId());
	    //			entity.setEntitlementInstanceId(getLongFromResultSet(rs, COLUMN_ENTITLEMENTINSTANCE_ID));
	    entity.setEntitlementInstanceId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalEntitlementInstanceId(entity.getEntitlementInstanceId());
	    //			entity.setRelationshipId(getLongFromResultSet(rs, COLUMN_RELATIONSHIP_ID));
	    entity.setRelationshipId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalRelationshipId(entity.getRelationshipId());
	    //			entity.setProcessStatusId(getLongFromResultSet(rs, COLUMN_PROCESSSTATUS_ID));
	    entity.setProcessStatusId(getLongFromResultSetIndexed(rs, ++index));
	    entity.setOriginalProcessStatusId(entity.getProcessStatusId());

	    // Load multi reference Ids
	    loadReferenceIds(entity);

	    obj.setModified(false);
	}
	catch (DatabaseException e)
	{
	    throw new DatabaseException("Cannot build database entity object from result set", e);
	}
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#createEntity(java.sql.ResultSet)
     */
    protected Entity createEntity(ResultSet rs) throws DatabaseException
    {
	TIProcessEntity entity = null;
	try
	{
	    // get the ID of the entity we're to create, and check if that is already held in the session. Thereby allowing us to
	    // bypass the creation altogether and reuse the one in existence.			
	    Long _id = getLongFromResultSet(rs, COLUMN_ID);
	    entity = (TIProcessEntity) getSession().getObjectFromSession(ENTITY_NAME, _id);
	    if (entity == null)
	    {        
		entity = new TIProcessEntity(_id);
		buildEntity(rs, entity);
		getSession().addObjectToSession(entity, ENTITY_NAME, _id);
	    }
	}
	catch (DatabaseException e)
	{
	    throw new DatabaseException("Cannot create database entity object from result set", e);
	}
	return entity;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.AccessObject#getQuerySelectString()
     */
    protected String getQuerySelectString()
    {
	return SELECT_STMT;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#getQuerySelectIdString()
     */
    protected String getQuerySelectIdString()
    {
	return SELECT_ID_STMT;
    }

    //======================================================================
    /**
     * Load the IDs of the external references for the entity.
     *
     * @param obj The entity for which to load the IDs of its references
     * @throws DatabaseException the database exception
     */
    public void loadReferenceIds(Entity obj) throws DatabaseException
    {
	TIProcessEntity entity = (TIProcessEntity)obj;
	loadC3parProcessRoleXrefReferenceIds(entity);
	loadTIRequestReferenceIds(entity);
    }

    //======================================================================
    /**
     * Load the external references for the entity.
     *
     * @param obj The entity for which to load its references
     * @throws DatabaseException the database exception
     */
    public void loadReferences(Entity obj) throws DatabaseException
    {
	if (obj.isReferencesLoaded())
	{
	    log.debug("TITaskTypeDAO.loadReferences(): References for TIProcessEntity [" + obj.getId() + "] already loaded");
	    return;
	}
	log.debug("TITaskTypeDAO.loadReferences(): Loading references for TIProcessEntity [" + obj.getId() + "].");
	obj.setReferencesLoaded(true);
	try
	{
	    TIProcessEntity entity = (TIProcessEntity)obj;

	    loadC3parProcessRoleXrefReferences(entity);

	    Long processTypeId = entity.getProcessTypeId();
	    if (processTypeId != null)
	    {
		//			TIProcessTypeDAO processTypeDAO = new TIProcessTypeDAO(getSession());
		TIProcessTypeDAO processTypeDAO = getProcessTypeDAO();
		entity.setProcessType((TIProcessTypeEntity)processTypeDAO.get(processTypeId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalProcessType(entity.getProcessType());
	    }

	    loadTIRequestReferences(entity);

	   /* Long entitlementInstanceId = entity.getEntitlementInstanceId();
	    if (entitlementInstanceId != null)
	    {
		//			EntitlementInstanceDAO entitlementInstanceDAO = new EntitlementInstanceDAO(getSession());
		EntitlementInstanceDAO entitlementInstanceDAO = getEntitlementInstanceDAO();
		entity.setEntitlementInstance((EntitlementInstanceEntity)entitlementInstanceDAO.get(entitlementInstanceId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalEntitlementInstance(entity.getEntitlementInstance());
	    }
*/
	    Long relationshipId = entity.getRelationshipId();
	    if (relationshipId != null)
	    {
		//			RelationshipDAO relationshipDAO = new RelationshipDAO(getSession());
		RelationshipDAO relationshipDAO = getRelationshipDAO();
		entity.setRelationship((RelationshipEntity)relationshipDAO.get(relationshipId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalRelationship(entity.getRelationship());
	    }

	    Long processStatusId = entity.getProcessStatusId();
	    if (processStatusId != null)
	    {
		//			TITaskTypeDAO processStatusDAO = new TITaskTypeDAO(getSession());
		TITaskTypeDAO processStatusDAO = getProcessStatusDAO();
		entity.setProcessStatus((TITaskTypeEntity)processStatusDAO.get(processStatusId));
		// Initialize the original (loaded) reference to the same object
		entity.setOriginalProcessStatus(entity.getProcessStatus());
	    }

	}
	catch(Exception e)
	{
		log.error(e,e);
	    obj.setReferencesLoaded(false);
	    throw new DatabaseException("Failed to load references for TIProcessEntity [" + obj.getId() + "].", e);
	}
    }

    //======================================================================
    /**
     * Load process type with id.
     *
     * @param id the id
     * @return the tI process type entity
     * @throws DatabaseException the database exception
     */
    public TIProcessTypeEntity loadProcessTypeWithId(Long id) throws DatabaseException
    {
	TIProcessTypeEntity entity = null;
	if (id != null)
	{
	    //			TIProcessTypeDAO processTypeDAO = new TIProcessTypeDAO(getSession());
	    TIProcessTypeDAO processTypeDAO = getProcessTypeDAO();
	    entity = (TIProcessTypeEntity)processTypeDAO.get(id);
	}
	return entity;
    }
    //======================================================================
    /**
     * Load entitlement instance with id.
     *
     * @param id the id
     * @return the entitlement instance entity
     * @throws DatabaseException the database exception
     */
    public EntitlementInstanceEntity loadEntitlementInstanceWithId(Long id) throws DatabaseException
    {
	EntitlementInstanceEntity entity = null;
	if (id != null)
	{
	    //			EntitlementInstanceDAO entitlementInstanceDAO = new EntitlementInstanceDAO(getSession());
	    EntitlementInstanceDAO entitlementInstanceDAO = getEntitlementInstanceDAO();
	    entity = (EntitlementInstanceEntity)entitlementInstanceDAO.get(id);
	}
	return entity;
    }
    //======================================================================
    /**
     * Load relationship with id.
     *
     * @param id the id
     * @return the relationship entity
     * @throws DatabaseException the database exception
     */
    public RelationshipEntity loadRelationshipWithId(Long id) throws DatabaseException
    {
	RelationshipEntity entity = null;
	if (id != null)
	{
	    //			RelationshipDAO relationshipDAO = new RelationshipDAO(getSession());
	    RelationshipDAO relationshipDAO = getRelationshipDAO();
	    entity = (RelationshipEntity)relationshipDAO.get(id);
	}
	return entity;
    }
    //======================================================================
    /**
     * Load process status with id.
     *
     * @param id the id
     * @return the tI task type entity
     * @throws DatabaseException the database exception
     */
    public TITaskTypeEntity loadProcessStatusWithId(Long id) throws DatabaseException
    {
	TITaskTypeEntity entity = null;
	if (id != null)
	{
	    //			TITaskTypeDAO processStatusDAO = new TITaskTypeDAO(getSession());
	    TITaskTypeDAO processStatusDAO = getProcessStatusDAO();
	    entity = (TITaskTypeEntity)processStatusDAO.get(id);
	}
	return entity;
    }

    //======================================================================
    /* (non-Javadoc)
     * @see com.mentisys.dao.DatabaseAccessObject#updateReferences(java.sql.PreparedStatement, com.mentisys.model.Entity, int)
     */
    protected int updateReferences(PreparedStatement st, Entity obj, int position)
    throws DatabaseException, SQLException
    {
	TIProcessEntity entity = (TIProcessEntity) obj;

	setLongToStatement(st, position++, entity.getProcessType() != null ? entity.getProcessType().getId() : entity.getProcessTypeId());
	setLongToStatement(st, position++, entity.getEntitlementInstance() != null ? entity.getEntitlementInstance().getId() : entity.getEntitlementInstanceId());
	setLongToStatement(st, position++, entity.getRelationship() != null ? entity.getRelationship().getId() : entity.getRelationshipId());
	setLongToStatement(st, position++, entity.getProcessStatus() != null ? entity.getProcessStatus().getId() : entity.getProcessStatusId());

	return position;
    }

    // Many Composition 'C3parProcessRoleXref' helpers 'process'
    //======================================================================
    /**
     * Loads all the C3parProcessRoleXref references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadC3parProcessRoleXrefReferences(TIProcessEntity entity) throws DatabaseException
    {
	loadC3parProcessRoleXrefReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the C3parProcessRoleXref references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadC3parProcessRoleXrefReferences(TIProcessEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading C3parProcessRoleXref references for TIProcessEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getC3parProcessRoleXref();
	    List id_list = entity.getOriginalC3parProcessRoleXrefIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		C3parProcessRoleXrefDAO dao = getC3parProcessRoleXrefDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		C3parProcessRoleXrefDAO dao = getC3parProcessRoleXrefDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading C3parProcessRoleXref references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load C3parProcessRoleXref References for TIProcessEntity [" + entity.getId() + "].", e);
	}


	//		entity.setC3parProcessRoleXref(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the C3parProcessRoleXref references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadC3parProcessRoleXrefReferenceIds(TIProcessEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_C3PARPROCESSROLEXREF_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalC3parProcessRoleXrefIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load C3parProcessRoleXref Reference IDs from TIProcessEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update c3par process role xref references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateC3parProcessRoleXrefReferences(TIProcessEntity entity) throws DatabaseException
    {
	ManyAssociationList c3parProcessRoleXref = entity.getC3parProcessRoleXref();
	C3parProcessRoleXrefDAO dao = getC3parProcessRoleXrefDAO();

	Iterator itDeleted = c3parProcessRoleXref.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    C3parProcessRoleXrefEntity e = (C3parProcessRoleXrefEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = c3parProcessRoleXref.iterator();
	while (it.hasNext())
	{
	    C3parProcessRoleXrefEntity e = (C3parProcessRoleXrefEntity) it.next();
	    e.setProcess(entity);
	    dao.update(e, false);
	}
    }
    // Single non-composition 'processType' helpers 'TIProcess' does not need helper
    // Many Composition 'TIRequest' helpers 'process'
    //======================================================================
    /**
     * Loads all the TIRequest references into the entity. This method will load all references recursively.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void loadTIRequestReferences(TIProcessEntity entity) throws DatabaseException
    {
	loadTIRequestReferences(entity, true); 
    }

    //======================================================================
    /**
     * Loads all the TIRequest references into the entity.
     *
     * @param entity The entity for which to load its references.
     * @param load_refs A boolean flag wether to load references recursively.
     * @throws DatabaseException the database exception
     */
    public void loadTIRequestReferences(TIProcessEntity entity, boolean load_refs) throws DatabaseException
    {
	try
	{
	    log.debug("Loading TIRequest references for TIProcessEntity [" + entity.getPrimaryKey() + "].");
	    ManyAssociationList entity_list = entity.getTIRequest();
	    List id_list = entity.getOriginalTIRequestIds();

	    // if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
	    if(id_list.size() == 1)
	    {
		TIRequestDAO dao = getTIRequestDAO();
		entity_list.getList().add(dao.get((Long)id_list.get(0), load_refs));

	    }
	    else if(id_list.size() > 1)
	    {
		TIRequestDAO dao = getTIRequestDAO();
		entity_list.getList().addAll(dao.get(id_list, load_refs));

		//				Iterator iter = dao.get(id_list, load_refs).iterator();
		//				while(iter.hasNext())
		//				{
		//					entity_list.getList().add((Entity)iter.next());
		//				}
	    }
	    log.debug("Finished loading TIRequest references. Count = " + entity_list.size());
	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load TIRequest References for TIProcessEntity [" + entity.getId() + "].", e);
	}


	//		entity.setTIRequest(entity_list);
    }

    //======================================================================
    /**
     * Load the IDs of the TIRequest references.
     *
     * @param entity The entity for which to load the reference IDs
     * @throws DatabaseException the database exception
     */
    public void loadTIRequestReferenceIds(TIProcessEntity entity) throws DatabaseException
    {
	DatabaseSession session = getSession();
	Connection connection = null;
	PreparedStatement st = null;
	ResultSet rs = null;

	try
	{
	    connection = session.getConnection();
	    st = connection.prepareStatement(SELECT_TIREQUEST_REFERENCE_IDS_STMT);
	    setLongToStatement(st, 1, entity.getPrimaryKey());

	    rs = st.executeQuery();

	    // Build a list of IDs from the result set
	    List id_list = new ArrayList(16);
	    while(rs.next())
	    {
		id_list.add(Long.valueOf(rs.getLong(1)));
	    }

	    entity.setOriginalTIRequestIds(id_list);	

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failed to load TIRequest Reference IDs from TIProcessEntity", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}

    }

    //======================================================================
    /**
     * Update ti request references.
     *
     * @param entity the entity
     * @throws DatabaseException the database exception
     */
    public void updateTIRequestReferences(TIProcessEntity entity) throws DatabaseException
    {
	ManyAssociationList tIRequest = entity.getTIRequest();
	TIRequestDAO dao = getTIRequestDAO();

	Iterator itDeleted = tIRequest.getDeletedList().iterator();
	while (itDeleted.hasNext())
	{
	    TIRequestEntity e = (TIRequestEntity) itDeleted.next();
	    dao.delete(e);
	    e.setPrimaryKey(null);
	}

	Iterator it = tIRequest.iterator();
	while (it.hasNext())
	{
	    TIRequestEntity e = (TIRequestEntity) it.next();
	    e.setProcess(entity);
	    dao.update(e, false);
	}
    }
    // Single non-composition 'entitlementInstance' helpers 'TIProcess' does not need helper
    // Single non-composition 'relationship' helpers 'TIProcess' does not need helper
    // Single non-composition 'processStatus' helpers 'TIProcess' does not need helper

    // Reference DAO caching methods	
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A C3parProcessRoleXrefDAO object 
     */
    protected C3parProcessRoleXrefDAO getC3parProcessRoleXrefDAO()
    {
	C3parProcessRoleXrefDAO dao = (C3parProcessRoleXrefDAO)getSession().getDAO("C3parProcessRoleXref");  
	if(dao == null)
	{
	    dao = new C3parProcessRoleXrefDAO(getSession());  		
	    getSession().putDAO("C3parProcessRoleXref", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A TIProcessTypeDAO object 
     */
    protected TIProcessTypeDAO getProcessTypeDAO()
    {
	TIProcessTypeDAO dao = (TIProcessTypeDAO)getSession().getDAO("TIProcessType");  
	if(dao == null)
	{
	    dao = new TIProcessTypeDAO(getSession());  		
	    getSession().putDAO("TIProcessType", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A TIRequestDAO object 
     */
    protected TIRequestDAO getTIRequestDAO()
    {
	TIRequestDAO dao = (TIRequestDAO)getSession().getDAO("TIRequest");  
	if(dao == null)
	{
	    dao = new TIRequestDAO(getSession());  		
	    getSession().putDAO("TIRequest", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A EntitlementInstanceDAO object 
     */
    protected EntitlementInstanceDAO getEntitlementInstanceDAO()
    {
	EntitlementInstanceDAO dao = (EntitlementInstanceDAO)getSession().getDAO("EntitlementInstance");  
	if(dao == null)
	{
	    dao = new EntitlementInstanceDAO(getSession());  		
	    getSession().putDAO("EntitlementInstance", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A RelationshipDAO object 
     */
    protected RelationshipDAO getRelationshipDAO()
    {
	RelationshipDAO dao = (RelationshipDAO)getSession().getDAO("Relationship");  
	if(dao == null)
	{
	    dao = new RelationshipDAO(getSession());  		
	    getSession().putDAO("Relationship", dao);
	}		
	return dao;
    }
    //======================================================================
    /**
     *	Retrieves a DAO from the session if one already got created and was stored in the session object.
     *	Will create one and store in the session object if one isn't available.
     *
     *	@return A TITaskTypeDAO object 
     */
    protected TITaskTypeDAO getProcessStatusDAO()
    {
	TITaskTypeDAO dao = (TITaskTypeDAO)getSession().getDAO("TITaskType");  
	if(dao == null)
	{
	    dao = new TITaskTypeDAO(getSession());  		
	    getSession().putDAO("TITaskType", dao);
	}		
	return dao;
    }

    //=====================================================================
    // Query helpers: 
    //=====================================================================

    //=====================================================================
    /**
     * Find all entities where the property [ProcessName] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByProcessName(String value) throws DatabaseException
    {
	return findByProcessName(value, getSession());
    }

    /**
     * Find by process name.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByProcessName(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIProcessDAO.TABLE + " WHERE " + COLUMN_PROCESSNAME + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [CreateDate] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByCreateDate(Date value) throws DatabaseException
    {
	return findByCreateDate(value, getSession());
    }

    /**
     * Find by create date.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByCreateDate(Date value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIProcessDAO.TABLE + " WHERE " + COLUMN_CREATEDATE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [UpdateDate] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByUpdateDate(Date value) throws DatabaseException
    {
	return findByUpdateDate(value, getSession());
    }

    /**
     * Find by update date.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByUpdateDate(Date value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIProcessDAO.TABLE + " WHERE " + COLUMN_UPDATEDATE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [ProcessTerminateReason] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByProcessTerminateReason(String value) throws DatabaseException
    {
	return findByProcessTerminateReason(value, getSession());
    }

    /**
     * Find by process terminate reason.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByProcessTerminateReason(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIProcessDAO.TABLE + " WHERE " + COLUMN_PROCESSTERMINATEREASON + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [ProcessUpdateReason] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByProcessUpdateReason(String value) throws DatabaseException
    {
	return findByProcessUpdateReason(value, getSession());
    }

    /**
     * Find by process update reason.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByProcessUpdateReason(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIProcessDAO.TABLE + " WHERE " + COLUMN_PROCESSUPDATEREASON + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [VersionNumber] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByVersionNumber(Integer value) throws DatabaseException
    {
	return findByVersionNumber(value, getSession());
    }

    /**
     * Find by version number.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByVersionNumber(Integer value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIProcessDAO.TABLE + " WHERE " + COLUMN_VERSIONNUMBER + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [IsHighRisk] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByIsHighRisk(String value) throws DatabaseException
    {
	return findByIsHighRisk(value, getSession());
    }

    /**
     * Find by is high risk.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByIsHighRisk(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIProcessDAO.TABLE + " WHERE " + COLUMN_ISHIGHRISK + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [IsBroadAccess] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByIsBroadAccess(String value) throws DatabaseException
    {
	return findByIsBroadAccess(value, getSession());
    }

    /**
     * Find by is broad access.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByIsBroadAccess(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIProcessDAO.TABLE + " WHERE " + COLUMN_ISBROADACCESS + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [IsDeleted] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByIsDeleted(String value) throws DatabaseException
    {
	return findByIsDeleted(value, getSession());
    }

    /**
     * Find by is deleted.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByIsDeleted(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIProcessDAO.TABLE + " WHERE " + COLUMN_ISDELETED + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }
    //=====================================================================
    /**
     * Find all entities where the property [ProcessActivityMode] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByProcessActivityMode(String value) throws DatabaseException
    {
	return findByProcessActivityMode(value, getSession());
    }

    /**
     * Find by process activity mode.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByProcessActivityMode(String value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIProcessDAO.TABLE + " WHERE " + COLUMN_PROCESSACTIVITYMODE + " = '" + value.toString() + "'";
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [ProcessType] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByProcessType(Long value) throws DatabaseException
    {
	return findByProcessType(value, getSession());
    }

    /**
     * Find by process type.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByProcessType(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIProcessDAO.TABLE + " WHERE " + COLUMN_PROCESSTYPE_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [EntitlementInstance] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByEntitlementInstance(Long value) throws DatabaseException
    {
	return findByEntitlementInstance(value, getSession());
    }

    /**
     * Find by entitlement instance.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByEntitlementInstance(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIProcessDAO.TABLE + " WHERE " + COLUMN_ENTITLEMENTINSTANCE_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [Relationship] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByRelationship(Long value) throws DatabaseException
    {
	return findByRelationship(value, getSession());
    }

    /**
     * Find by relationship.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByRelationship(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIProcessDAO.TABLE + " WHERE " + COLUMN_RELATIONSHIP_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find all entities where the property [ProcessStatus] is equal to the value provided.
     *
     * @param value the value
     * @return the list
     * @throws DatabaseException the database exception
     */
    public List findByProcessStatus(Long value) throws DatabaseException
    {
	return findByProcessStatus(value, getSession());
    }

    /**
     * Find by process status.
     *
     * @param value the value
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static public List findByProcessStatus(Long value, DatabaseSession session) throws DatabaseException
    {
	String sel_stmt = "SELECT " + COLUMN_ID + " FROM " + TIProcessDAO.TABLE + " WHERE " + COLUMN_PROCESSSTATUS_ID + " = " + value.toString();
	return findEntitiesByPropertyHelper(sel_stmt, session);
    }

    //=====================================================================
    /**
     * Find entities by property helper.
     *
     * @param sel_stmt the sel_stmt
     * @param session the session
     * @return the list
     * @throws DatabaseException the database exception
     */
    static protected List findEntitiesByPropertyHelper(String sel_stmt, DatabaseSession session) throws DatabaseException
    {
	List entities = null;
	Connection connection = null;
	Statement st = null;
	ResultSet rs = null;

	log.debug(sel_stmt);

	try
	{
	    connection = session.getConnection();
	    st = connection.createStatement();
	    rs = st.executeQuery(sel_stmt);

	    List found_entities = new ArrayList();		
	    while(rs.next())
	    {
		found_entities.add(Long.valueOf(rs.getLong(1)));			
	    }

	    if(found_entities.size() > 0)
	    {
		entities = found_entities;
	    }

	}
	catch(Exception e)
	{
	    throw new DatabaseException("Failure to find entities by ProcessStatus", e);
	}
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    if(connection != null)
	    {
		session.releaseConnection();
	    }
	}

	return entities;
    }


    //=====================================================================
    /**
     * Dummy exception tosser.
     *
     * @param flag the flag
     * @throws DatabaseException the database exception
     */
    protected void dummyExceptionTosser(boolean flag) throws DatabaseException
    {
	if(flag)
	{
	    throw new DatabaseException("This exception should never be thrown....", new Exception("Another dummy"));
	}
    }

    /**
     * Primary key exists.
     *
     * @param entity the entity
     * @param update the update
     * @param session the session
     * @return true, if successful
     * @throws DatabaseException the database exception
     */
    private boolean primaryKeyExists(TIProcessEntity entity, boolean update, DatabaseSession session) 
    throws DatabaseException {

	boolean exists = false;

	return exists;
    }
}
