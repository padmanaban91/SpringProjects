package com.citigroup.cgti.c3par.bpm.ejb.search;

import java.util.List;

import com.citigroup.cgti.c3par.bpm.ejb.domain.LookupDTO;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.Process;
import com.citigroup.cgti.c3par.bpm.ejb.search.domain.SearchMyConnectionsProcess;
import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.persistance.Persistable;
import com.mentisys.dao.DatabaseException;


/**
 * The Interface ISearchProcess.
 */
public interface ISearchProcess  extends Persistable  {
	
	/**
	 * Gets the search result.
	 *
	 * @param attrs the attrs
	 * @param pageSize the page size
	 * @param pageNum the page num
	 * @return the search result
	 * @throws Exception the exception
	 */
	public List getSearchResult(Object attrs, int pageSize, int pageNum) throws Exception;
	
	/**
	 * Gets the search record count.
	 *
	 * @param attrs the attrs
	 * @param pageSize the page size
	 * @param pageNum the page num
	 * @return the search record count
	 * @throws Exception the exception
	 */
	public int getSearchRecordCount(Object attrs, int pageSize, int pageNum) throws Exception;
	
	List<Process> getMyConnections(SearchMyConnectionsProcess searchMyConnectionsProcess)  throws Exception;
	
	List<LookupDTO> getMyTaskContactPageDropdownList(Object attrsObj, String type)throws Exception;
	
	List getAllRolesList() throws Exception;
	
	public CitiContact getBusinessOwnerDetails(final Long tiRequestId,String relationType);
	
	public int getMyTaskContactRecordCount(Object attrsObj, int pageSize, int pageNum) throws Exception;
	public int getMyTaskRecordCount(String ssoid, int pageSize, int pageNum) throws Exception;
	public int getGeneralSearchRecordCount(Object attrs) throws Exception;
	
	public int getGeneralSearchApplicationRecordCount(Object attrs) throws Exception ;
	public int getGeneralSearchIpFwPrPcRecordCount(Object attrs) throws Exception ;
	public int getGeneralSearchIpFwPrPcRecordTerminatedCount(Object attrs) throws Exception ;
	public int getGeneralSearchIpRecordCount(Object attrs) throws Exception ;
	public int getGeneralSearchCnRgScPcAppRecordCount(Object attrs) throws Exception ;
	public int getGeneralSearchPolicyRecordCount(Object attrs) throws Exception ;
	public int getGeneralSearchPortRecordCount(Object attrs) throws Exception ;
	public int getGeneralSearchOpeImpRecordCount(Object attrs) throws Exception ;
	public int getGeneralSearchAppsenseRecordCount(Object attrs) throws Exception ;
	public int getGeneralSearchProxyRecordCount(Object attrs) throws Exception ;
	public int getGeneralSearchSecAclRecordCount(Object attrs) throws Exception ;
	
	public  List<Object> getMyTaskSearchResult(String lockedby, int pageSize, int pageNum) throws Exception;
	public  List<Object> getMyContactTaskSearchResult(Object attrsObj, int pageSize, int pageNum, int recCnt) throws Exception ;
	public List getGeneralSearchRecord(Object attrs, int pageSize, int pageNum, int recCnt) throws Exception;
	public List getGeneralSearchApplicationResult(Object attrs, int pageSize, int pageNum, int recCnt) throws Exception;
	public List getGeneralSearchIpFwPrPcResult(Object attrs, int pageSize, int pageNum, int recCnt) throws Exception;
	public List getGeneralSearchIpResult(Object attrs, int pageSize, int pageNum, int recCnt) throws Exception;
	public List getGeneralSearchCnRgScPcAppResult(Object attrs, int pageSize, int pageNum, int recCnt) throws Exception;
	public List getGeneralSearchPolicyResult(Object attrs, int pageSize, int pageNum, int recCnt) throws Exception;
	public List getGeneralSearchPortResult(Object attrs, int pageSize, int pageNum, int recCnt) throws Exception;
	public List getGeneralSearchOpeImpResult(Object attrs, int pageSize, int pageNum, int recCnt) throws Exception;
	public List getGeneralSearchAppsenseResult(Object attrs, int pageSize, int pageNum, int recCnt) throws Exception;
	public List getGeneralSearchProxyResult(Object attrs, int pageSize, int pageNum, int recCnt) throws Exception;
	public List getGeneralSearchSecAclResult(Object attrs, int pageSize, int pageNum, int recCnt) throws Exception;
	
	public List<Object> getScheduledProcessByAcitivityCode(String activityCode,int pageSize,String status) throws DatabaseException ;
	
	public static final String LISTTYPE_ROLE="role";
	public static final String LISTTYPE_TASK="task";
	public static final String LISTTYPE_SECTOR="sector";
	public static final String LISTTYPE_REGION="region";
	public String getRequestorSoeIdForConnectionInfo(Long processId, String relationshipType) throws Exception;
	
	
	
	public List getGeneralSearchIpFwPrPc_Terminated_Result(Object attrs, int pageSize, int pageNum, int recCnt) throws Exception;
	
	
}
