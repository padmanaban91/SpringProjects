package com.citigroup.cgti.c3par.common.domain;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import com.citigroup.cgti.c3par.domain.Base;


/**
 * The Class GenericLookup.
 */
public class GenericLookup extends Base implements Serializable, Comparable<GenericLookup>{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** The definition id. */
    private Long definitionId;

    /** The value1. */
    private String value1;

    /** The value2. */
    private String value2;

    /** The is deleted. */
    private String isDeleted;
    
    
  

 
    private GenericLookupDef  genericLookupDef;

    /**
     * Gets the definition id.
     *
     * @return the definition id
     */
    public Long getDefinitionId() {
	return definitionId;
    }

    /**
     * Sets the definition id.
     *
     * @param definitionId the new definition id
     */
    public void setDefinitionId(Long definitionId) {
	this.definitionId = definitionId;
    }



    /**
     * Gets the value1.
     *
     * @return the value1
     */
    public String getValue1() {
	return value1;
    }

    /**
     * Sets the value1.
     *
     * @param value1 the new value1
     */
    public void setValue1(String value1) {
	this.value1 = value1;
    }

    /**
     * Gets the value2.
     *
     * @return the value2
     */
    public String getValue2() {
	return value2;
    }

    /**
     * Sets the value2.
     *
     * @param value2 the new value2
     */
    public void setValue2(String value2) {
	this.value2 = value2;
    }

    /**
     * Gets the checks if is deleted.
     *
     * @return the isDeleted
     */
    public String getIsDeleted() {
	return isDeleted;
    }

    public GenericLookupDef getGenericLookupDef() {
		return genericLookupDef;
	}

	public void setGenericLookupDef(GenericLookupDef genericLookupDef) {
		this.genericLookupDef = genericLookupDef;
	}

	/**
     * Sets the checks if is deleted.
     *
     * @param isDeleted the isDeleted to set
     */
    public void setIsDeleted(String isDeleted) {
	this.isDeleted = isDeleted;
    }

    @Override
    public int compareTo(GenericLookup o) {
        return this.value1.compareTo(o.value1);
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        GenericLookup other = (GenericLookup) obj;
        if (getId() == null) {
            if (other.getId() != null)
                return false;
        } else if (!getId().equals(other.getId()))
            return false;
        return true;
    }
    
    
}
