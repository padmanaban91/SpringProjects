/**
 * 
 */
package com.citigroup.cgti.c3par.common.domain;

/**
 * @author ka58098
 *
 */
public interface AdminUserEntitlementService {

	void sendMailToHelpdesk(Long userId);
}
