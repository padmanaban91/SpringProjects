package com.citigroup.cgti.c3par.admin.dao.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.admin.dao.service.ManageTagsDao;
import com.citigroup.cgti.c3par.admin.domain.CCRTags;
import com.citigroup.cgti.c3par.admin.domain.ManageMoreInfoTagDTO;
import com.citigroup.cgti.c3par.common.domain.TIRequestTags;

/**
 * @author ac81662
 *
 */
@Repository
@Transactional
public class ManageTagsDaoImpl implements ManageTagsDao {

    private static final Logger log = Logger.getLogger(ManageTagsDaoImpl.class.getName());

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public boolean addTag(ManageMoreInfoTagDTO manageMoreInfoTag) throws Exception {
        log.debug("ManageTagsDaoImpl :: addTag starts");
        Session session = sessionFactory.getCurrentSession();
        CCRTags ccrTags = new CCRTags();
        boolean successFlag = true;
        try {
            ccrTags.setTags(manageMoreInfoTag.getTag());
            ccrTags.setCreatedDate(new Date());
            ccrTags.setModifiedDate(new Date());
            ccrTags.setIsDeleted("N");
            session.save(ccrTags);
        } catch (Exception e) {
            successFlag = false;
            log.error("Exception in ManageTagsDaoImpl :: addTag " + e.toString());
            log.error(e, e);
            throw new ApplicationException("Exception has occurred :: addTag() ", e);
        }
        return successFlag;
    }

    @SuppressWarnings("unchecked")
    @Override
    @Transactional(readOnly = true)
    public List<ManageMoreInfoTagDTO> getTagsList() throws Exception {
        log.debug("ManageTagsDaoImpl :: getTagsList starts");
        List<ManageMoreInfoTagDTO> manageMoreInfoTagDTOList = new ArrayList<ManageMoreInfoTagDTO>();
        List<CCRTags> ccrTagsList = new ArrayList<CCRTags>();
        try {
            Session session = sessionFactory.getCurrentSession();
            Criteria criteria = session.createCriteria(CCRTags.class);
            criteria.add(Restrictions.eq("isDeleted", "N"));
            criteria.addOrder(Order.asc("tags").ignoreCase());
            ccrTagsList = (List<CCRTags>) criteria.list();
            if (CollectionUtils.isNotEmpty(ccrTagsList)) {
                for (CCRTags ccrTag : ccrTagsList) {
                    ManageMoreInfoTagDTO manageMoreInfoTagDTO = new ManageMoreInfoTagDTO();
                    manageMoreInfoTagDTO.setSelected(false);
                    manageMoreInfoTagDTO.setTag(ccrTag.getTags());
                    manageMoreInfoTagDTO.setTagId(ccrTag.getId());
                    manageMoreInfoTagDTOList.add(manageMoreInfoTagDTO);
                }
            }
        } catch (Exception e) {
            log.error("Exception in ManageTagsDaoImpl :: getTagsList " + e.toString());
            log.error(e, e);
            throw new ApplicationException("Exception has occurred :: getTagsList() ", e);
        }
        return manageMoreInfoTagDTOList;
    }

    @SuppressWarnings("unchecked")
    @Override
    public void getEditTagDetails(ManageMoreInfoTagDTO manageMoreInfoTag) throws Exception {
        log.debug("ManageTagsDaoImpl :: getEditTagDetails starts");
        List<CCRTags> ccrTagsList = new ArrayList<CCRTags>();
        try {
            Session session = sessionFactory.getCurrentSession();
            Criteria criteria = session.createCriteria(CCRTags.class);
            criteria.add(Restrictions.eq("id", manageMoreInfoTag.getTagId()));
            ccrTagsList = (List<CCRTags>) criteria.list();
            if (CollectionUtils.isNotEmpty(ccrTagsList)) {
                for (CCRTags ccrTag : ccrTagsList) {
                    manageMoreInfoTag.setTag(ccrTag.getTags());
                    break;
                }
            }
        } catch (Exception e) {
            log.error("Exception in ManageTagsDaoImpl :: getEditTagDetails " + e.toString());
            log.error(e, e);
            throw new ApplicationException("Exception has occurred :: getEditTagDetails() ", e);
        }
    }

    @Override
    public boolean updateTag(final ManageMoreInfoTagDTO manageMoreInfoTag) throws Exception {
        log.debug("ManageTagsDaoImpl :: updateTag starts");
        boolean successFlag = true;
        try {
            Session session = sessionFactory.getCurrentSession();
            CCRTags ccrTags = (CCRTags) session.load(CCRTags.class, manageMoreInfoTag.getTagId());
            ccrTags.setTags(manageMoreInfoTag.getTag());
            ccrTags.setModifiedDate(new Date());
            session.update(ccrTags);
        } catch (Exception e) {
            successFlag = false;
            log.error("Exception in ManageTagsDaoImpl :: updateTag " + e.toString());
            log.error(e, e);
            throw new ApplicationException("Exception has occurred :: updateTag() ", e);
        }
        return successFlag;
    }

    @Override
    public Boolean deleteTag(final Long tagId) throws Exception {
        log.debug("ManageTagsDaoImpl :: deleteTag starts");
        Boolean successFlag = true;
        try {
            Session session = sessionFactory.getCurrentSession();
            CCRTags ccrTags = (CCRTags) session.load(CCRTags.class, tagId);
            ccrTags.setIsDeleted("Y");
            session.update(ccrTags);
        } catch (Exception e) {
            successFlag = false;
            log.error("Exception in ManageTagsDaoImpl :: deleteTag " + e.toString());
            log.error(e, e);
            throw new ApplicationException("Exception has occurred :: deleteTag() ", e);
        }
        return successFlag;
    }

    @SuppressWarnings("unchecked")
    @Override
    @Transactional(readOnly = true)
    public boolean checkDuplicateTag(ManageMoreInfoTagDTO manageMoreInfoTag) throws Exception {
        log.debug("ManageTagsDaoImpl :: checkDuplicateTag starts");
        boolean duplicateFlag = false;
        List<CCRTags> ccrTagsList = new ArrayList<CCRTags>();
        try {
            Session session = sessionFactory.getCurrentSession();
            Criteria criteria = session.createCriteria(CCRTags.class);
            criteria.add(Restrictions.eq("tags", manageMoreInfoTag.getTag()));
            criteria.add(Restrictions.eq("isDeleted", "N"));
            ccrTagsList = (List<CCRTags>) criteria.list();
            if (CollectionUtils.isNotEmpty(ccrTagsList)) {
                duplicateFlag = true;
            }
        } catch (Exception e) {
            log.error("Exception in ManageTagsDaoImpl :: checkDuplicateTag " + e.toString());
            log.error(e, e);
            throw new ApplicationException("Exception has occurred :: checkDuplicateTag() ", e);
        }
        return duplicateFlag;
    }

    @SuppressWarnings("unchecked")
    @Override
    @Transactional(readOnly = true)
    public List<CCRTags> getAllTags() throws Exception {
        log.debug("ManageTagsDaoImpl :: getAllTags starts");
        List<CCRTags> ccrTagsList = new ArrayList<CCRTags>();
        try {
            Session session = sessionFactory.getCurrentSession();
            Criteria criteria = session.createCriteria(CCRTags.class);
            criteria.add(Restrictions.eq("isDeleted", "N"));
            criteria.addOrder(Order.asc("tags").ignoreCase());
            ccrTagsList = (List<CCRTags>) criteria.list();
        } catch (Exception e) {
            log.error("Exception in ManageTagsDaoImpl :: getAllTags " + e.toString());
            log.error(e, e);
            throw new ApplicationException("Exception has occurred :: getAllTags() ", e);
        }
        return ccrTagsList;
    }

    @SuppressWarnings("unchecked")
    @Override
    @Transactional(readOnly = true)
    public CCRTags getCCrTag(Long ccrId) throws Exception {
        log.debug("ManageTagsDaoImpl :: getCCrTag starts");
        CCRTags ccrTags = new CCRTags();
        List<CCRTags> ccrTagsList = new ArrayList<CCRTags>();
        try {
            Session session = sessionFactory.getCurrentSession();
            Criteria criteria = session.createCriteria(CCRTags.class);
            criteria.add(Restrictions.eq("id", ccrId));
            ccrTagsList = (List<CCRTags>) criteria.list();
            if (CollectionUtils.isNotEmpty(ccrTagsList)) {
                ccrTags = ccrTagsList.get(0);
            }
        } catch (Exception e) {
            log.error("Exception in ManageTagsDaoImpl :: getCCrTag " + e.toString());
            log.error(e, e);
            throw new ApplicationException("Exception has occurred :: getCCrTag() ", e);
        }
        return ccrTags;
    }

    @SuppressWarnings("unchecked")
    @Override
    @Transactional(readOnly = true)
    public List<CCRTags> getAllTagsList() throws Exception {
        log.debug("ManageTagsDaoImpl :: getAllTagsList starts");
        List<Long> tiRequestTagIdsList = new ArrayList<Long>();
        List<CCRTags> ccrTagsList = new ArrayList<CCRTags>();
        try {
            Session session = sessionFactory.getCurrentSession();
            Criteria criteria = session.createCriteria(TIRequestTags.class);
            criteria = criteria.setProjection(
                    Projections.projectionList().add(Projections.distinct(Projections.property("tagId"))));
            tiRequestTagIdsList = (List<Long>) criteria.list();
            if (CollectionUtils.isNotEmpty(tiRequestTagIdsList) && tiRequestTagIdsList.size() <= 1000) {
                criteria = session.createCriteria(CCRTags.class);
                criteria.add(Restrictions.in("id", tiRequestTagIdsList));
                criteria.addOrder(Order.asc("tags").ignoreCase());
                ccrTagsList = (List<CCRTags>) criteria.list();
            }
        } catch (Exception e) {
            log.error("Exception in ManageTagsDaoImpl :: getAllTagsList " + e.toString());
            log.error(e, e);
            throw new ApplicationException("Exception has occurred ManageTagsDaoImpl :: getAllTagsList() ", e);
        }
        return ccrTagsList;
    }
}
