package com.citigroup.cgti.c3par.communication.domain;

import org.apache.commons.lang.builder.ToStringBuilder;

public class EcmView extends  EcmBaseEntity {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1956584568L;
	private Long id;
    private String viewName;
    private String displayName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getViewName() {
        return viewName;
    }

    public void setViewName(String viewName) {
        this.viewName = viewName;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }
    
    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

}
