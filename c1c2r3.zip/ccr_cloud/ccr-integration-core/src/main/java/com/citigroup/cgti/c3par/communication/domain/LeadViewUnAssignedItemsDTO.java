/**
 * 
 */
package com.citigroup.cgti.c3par.communication.domain;

import java.io.Serializable;
import java.util.Date;

/**
 * @author ky38518
 * 
 */
public class LeadViewUnAssignedItemsDTO implements Serializable {

    private static final long serialVersionUID = 16456545L;

    private String ccrId;
    private String ccrIdValues;
    private String ccrIdWithVerNo;
    private Date updateAssignedUserDate;
    private String ecmSector;
    private String checkTiId;
    private String taskCodeColor;
    private String taskName;
    private String sloStatus;
    private String slo;
    private String requestTypeVal;
    private String chgId;
    private String chgDate;
    private String requestorName;
    private String dateAssigned;
    private String currentStatus;
    private String orderByUser;
    private String orderForUser;
    private String orderId;
    private String orderItemId;
    private String requestUrgency;
    private String region;
    private String assignTo;
    private String assign;
    private String assignComments;
    private String cmpId;
    
    private String requestType;

    /**
     * @return the ccrId
     */
    public String getCcrId() {
        return ccrId;
    }

    /**
     * @param ccrId
     *            the ccrId to set
     */
    public void setCcrId(String ccrId) {
        this.ccrId = ccrId;
    }

    /**
     * @return the ccrIdValues
     */
    public String getCcrIdValues() {
        return ccrIdValues;
    }

    /**
     * @param ccrIdValues
     *            the ccrIdValues to set
     */
    public void setCcrIdValues(String ccrIdValues) {
        this.ccrIdValues = ccrIdValues;
    }

    /**
     * @return the ccrIdWithVerNo
     */
    public String getCcrIdWithVerNo() {
        return ccrIdWithVerNo;
    }

    /**
     * @param ccrIdWithVerNo
     *            the ccrIdWithVerNo to set
     */
    public void setCcrIdWithVerNo(String ccrIdWithVerNo) {
        this.ccrIdWithVerNo = ccrIdWithVerNo;
    }

    /**
     * @return the updateAssignedUserDate
     */
    public Date getUpdateAssignedUserDate() {
        return updateAssignedUserDate;
    }

    /**
     * @param updateAssignedUserDate
     *            the updateAssignedUserDate to set
     */
    public void setUpdateAssignedUserDate(Date updateAssignedUserDate) {
        this.updateAssignedUserDate = updateAssignedUserDate;
    }

    /**
     * @return the ecmSector
     */
    public String getEcmSector() {
        return ecmSector;
    }

    /**
     * @param ecmSector
     *            the ecmSector to set
     */
    public void setEcmSector(String ecmSector) {
        this.ecmSector = ecmSector;
    }

    /**
     * @return the checkTiId
     */
    public String getCheckTiId() {
        return checkTiId;
    }

    /**
     * @param checkTiId
     *            the checkTiId to set
     */
    public void setCheckTiId(String checkTiId) {
        this.checkTiId = checkTiId;
    }

    /**
     * @return the taskCodeColor
     */
    public String getTaskCodeColor() {
        return taskCodeColor;
    }

    /**
     * @param taskCodeColor
     *            the taskCodeColor to set
     */
    public void setTaskCodeColor(String taskCodeColor) {
        this.taskCodeColor = taskCodeColor;
    }

    /**
     * @return the taskName
     */
    public String getTaskName() {
        return taskName;
    }

    /**
     * @param taskName
     *            the taskName to set
     */
    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    /**
     * @return the sloStatus
     */
    public String getSloStatus() {
        return sloStatus;
    }

    /**
     * @param sloStatus
     *            the sloStatus to set
     */
    public void setSloStatus(String sloStatus) {
        this.sloStatus = sloStatus;
    }

    /**
     * @return the slo
     */
    public String getSlo() {
        return slo;
    }

    /**
     * @param slo
     *            the slo to set
     */
    public void setSlo(String slo) {
        this.slo = slo;
    }

    /**
     * @return the requestTypeVal
     */
    public String getRequestTypeVal() {
        return requestTypeVal;
    }

    /**
     * @param requestTypeVal
     *            the requestTypeVal to set
     */
    public void setRequestTypeVal(String requestTypeVal) {
        this.requestTypeVal = requestTypeVal;
    }

    /**
     * @return the chgId
     */
    public String getChgId() {
        return chgId;
    }

    /**
     * @param chgId
     *            the chgId to set
     */
    public void setChgId(String chgId) {
        this.chgId = chgId;
    }

    /**
     * @return the chgDate
     */
    public String getChgDate() {
        return chgDate;
    }

    /**
     * @param chgDate
     *            the chgDate to set
     */
    public void setChgDate(String chgDate) {
        this.chgDate = chgDate;
    }

    /**
     * @return the requestorName
     */
    public String getRequestorName() {
        return requestorName;
    }

    /**
     * @param requestorName
     *            the requestorName to set
     */
    public void setRequestorName(String requestorName) {
        this.requestorName = requestorName;
    }

    /**
     * @return the dateAssigned
     */
    public String getDateAssigned() {
        return dateAssigned;
    }

    /**
     * @param dateAssigned
     *            the dateAssigned to set
     */
    public void setDateAssigned(String dateAssigned) {
        this.dateAssigned = dateAssigned;
    }

    /**
     * @return the currentStatus
     */
    public String getCurrentStatus() {
        return currentStatus;
    }

    /**
     * @param currentStatus
     *            the currentStatus to set
     */
    public void setCurrentStatus(String currentStatus) {
        this.currentStatus = currentStatus;
    }

    /**
     * @return the orderByUser
     */
    public String getOrderByUser() {
        return orderByUser;
    }

    /**
     * @param orderByUser
     *            the orderByUser to set
     */
    public void setOrderByUser(String orderByUser) {
        this.orderByUser = orderByUser;
    }

    /**
     * @return the orderForUser
     */
    public String getOrderForUser() {
        return orderForUser;
    }

    /**
     * @param orderForUser
     *            the orderForUser to set
     */
    public void setOrderForUser(String orderForUser) {
        this.orderForUser = orderForUser;
    }

    /**
     * @return the orderId
     */
    public String getOrderId() {
        return orderId;
    }

    /**
     * @param orderId
     *            the orderId to set
     */
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    /**
     * @return the orderItemId
     */
    public String getOrderItemId() {
        return orderItemId;
    }

    /**
     * @param orderItemId
     *            the orderItemId to set
     */
    public void setOrderItemId(String orderItemId) {
        this.orderItemId = orderItemId;
    }

    /**
     * @return the requestUrgency
     */
    public String getRequestUrgency() {
        return requestUrgency;
    }

    /**
     * @param requestUrgency
     *            the requestUrgency to set
     */
    public void setRequestUrgency(String requestUrgency) {
        this.requestUrgency = requestUrgency;
    }

    /**
     * @return the region
     */
    public String getRegion() {
        return region;
    }

    /**
     * @param region
     *            the region to set
     */
    public void setRegion(String region) {
        this.region = region;
    }

    /**
     * @return the assignTo
     */
    public String getAssignTo() {
        return assignTo;
    }

    /**
     * @param assignTo
     *            the assignTo to set
     */
    public void setAssignTo(String assignTo) {
        this.assignTo = assignTo;
    }

    /**
     * @return the assign
     */
    public String getAssign() {
        return assign;
    }

    /**
     * @param assign
     *            the assign to set
     */
    public void setAssign(String assign) {
        this.assign = assign;
    }

    /**
     * @return the assignComments
     */
    public String getAssignComments() {
        return assignComments;
    }

    /**
     * @param assignComments
     *            the assignComments to set
     */
    public void setAssignComments(String assignComments) {
        this.assignComments = assignComments;
    }
    /**
     * @return the CmpId
     */
    public String getCmpId() {
        return cmpId;
    }
    /**
     * @param assignComments
     *            the cmpId to set
     */
    public void setCmpId(String cmpId) {
        this.cmpId = cmpId;
    }

    /**
     * @return requestType
     */
    public String getRequestType() {
        return requestType;
    }

    /**
     * @param requestType
     */
    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }
    
    

}
