package com.citigroup.cgti.c3par.connection.domain;

import java.util.Date;

import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;



/**
 * The Class ConnectionVIPMaster.
 */
public class ConnectionVIPMaster extends PerformerPagerDO {

    /** The virtual ip. */
    private String virtualIp;        

    /** The formatted virtual ip. */
    private String formattedVirtualIp;
    //    private String natIp;
    /** The share flag. */
    private String shareFlag;

    /** The delete flag. */
    private String deleteFlag;

    /** The created_date. */
    private Date created_date;

    /** The updated_date. */
    private Date updated_date;



    /**
     * Instantiates a new connection vip master.
     */
    public ConnectionVIPMaster() {
	//---------------------
	setTableName(PerformerTypes.CONN_VIRTUAL_IP_MASTER_TABEL);
	setSequenceName(PerformerTypes.CONN_VIRTUAL_IP_MASTER_SEQ);
	//---------------------
	addToDBMapping("virtualIp","virtual_ip",1);
	addToDBMapping("formattedVirtualIp","formatted_virtual_ip",2);
	//		addToDBMapping("natIp","nat_ip");
	addToDBMapping("shareFlag","share_flag",3);
	addToDBMapping("deleteFlag","delete_flag",4);
	addToDBMapping("created_date","created_date",5);
	addToDBMapping("updated_date","updated_date",6);
	//----------------------
	addToParentsMap("com.citigroup.cgti.c3par.connection.domain.ConnectionIPMaster" , "ip_id");
	//----------------------
	addToDefaultValueMap("shareFlag", "F");
	addToDefaultValueMap("deleteFlag", "F");

    }




    /**
     * Gets the delete flag.
     *
     * @return the delete flag
     */
    public String getDeleteFlag() {
	return deleteFlag;
    }

    /**
     * Sets the delete flag.
     *
     * @param deleteFlag the new delete flag
     */
    public void setDeleteFlag(String deleteFlag) {
	this.deleteFlag = deleteFlag;
    }

    /**
     * Gets the formatted virtual ip.
     *
     * @return the formatted virtual ip
     */
    public String getFormattedVirtualIp() {
	return formattedVirtualIp;
    }

    /**
     * Sets the formatted virtual ip.
     *
     * @param formattedVirtualIp the new formatted virtual ip
     */
    public void setFormattedVirtualIp(String formattedVirtualIp) {
	this.formattedVirtualIp = formattedVirtualIp;
    }
    /*public String getNatIp() {
		return natIp;
	}*/
    /*public void setNatIp(String natIp) {
		this.natIp = natIp;
	}*/
    /**
     * Gets the share flag.
     *
     * @return the share flag
     */
    public String getShareFlag() {
	return shareFlag;
    }

    /**
     * Sets the share flag.
     *
     * @param shareFlag the new share flag
     */
    public void setShareFlag(String shareFlag) {
	this.shareFlag = shareFlag;
    }

    /**
     * Gets the virtual ip.
     *
     * @return the virtual ip
     */
    public String getVirtualIp() {
	return virtualIp;
    }

    /**
     * Sets the virtual ip.
     *
     * @param virtualIp the new virtual ip
     */
    public void setVirtualIp(String virtualIp) {
	this.virtualIp = virtualIp;
    }


    /**
     * Gets the created_date.
     *
     * @return Returns the created_date.
     */
    public Date getCreated_date() {
	return created_date;
    }

    /**
     * Sets the created_date.
     *
     * @param created_date The created_date to set.
     */
    public void setCreated_date(Date created_date) {
	this.created_date = created_date;
    }

    /**
     * Gets the updated_date.
     *
     * @return Returns the updated_date.
     */
    public Date getUpdated_date() {
	return updated_date;
    }

    /**
     * Sets the updated_date.
     *
     * @param updated_date The updated_date to set.
     */
    public void setUpdated_date(Date updated_date) {
	this.updated_date = updated_date;
    }
}
