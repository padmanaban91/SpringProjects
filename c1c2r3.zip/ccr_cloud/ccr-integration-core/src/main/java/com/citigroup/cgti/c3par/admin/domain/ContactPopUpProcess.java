/*
 * 
 */
package com.citigroup.cgti.c3par.admin.domain;

import java.io.Serializable;
import java.util.Map;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.relationship.domain.Location;
import com.citigroup.cgti.c3par.relationship.domain.ThirdPartyContact;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

/**
 * The Class ContactPopUpProcess
 */
public class ContactPopUpProcess extends Base implements Serializable {

	
	private ThirdPartyContact tpContact;
	
	private Location tpLocation;
	
	private Long selectedThirdParty;
	
	private Map<Long,String> country;

	private Map<Long,String> region;
	
	private String selectedId;
	
   CCRBeanFactory ccrBeanFactory;
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		if(appContext!=null && appContext.containsBean("cCRBeanFactory")){
			ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
		}else{
			System.out.println("appContext is null");
		}
		
	}
	
	public ThirdPartyContact getTpContact() {
		return tpContact;
	}

	public void setTpContact(ThirdPartyContact tpContact) {
		this.tpContact = tpContact;
	}

	public Location getTpLocation() {
		return tpLocation;
	}

	public void setTpLocation(Location tpLocation) {
		this.tpLocation = tpLocation;
	}

	public Long getSelectedThirdParty() {
		return selectedThirdParty;
	}

	public void setSelectedThirdParty(Long selectedThirdParty) {
		this.selectedThirdParty = selectedThirdParty;
	}
	

	public Map<Long, String> getCountry() {
		return country;
	}

	public void setCountry(Map<Long, String> country) {
		this.country = country;
	}

	public Map<Long, String> getRegion() {
		return region;
	}

	public void setRegion(Map<Long, String> region) {
		this.region = region;
	}
	
	public String getSelectedId() {
		return selectedId;
	}

	public void setSelectedId(String selectedId) {
		this.selectedId = selectedId;
	}

	
	public Map<Long,String> getListOfRegions() {
		return ccrBeanFactory.getThirdPartyPersistable().getListOfRegions();
	}
	
	
	public Map<Long, String> getListofCountries() {
		return ccrBeanFactory.getThirdPartyPersistable().getListofCountries();
	}
	
	
	public ThirdPartyContact getThirdPartyForId(Long id) {
		return ccrBeanFactory.getThirdPartyPersistable().getThirdPartyForId(id);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void saveThirdPartyContact() {
		ccrBeanFactory.getThirdPartyPersistable().saveThirdPartyContact(this);
		
	}


}
