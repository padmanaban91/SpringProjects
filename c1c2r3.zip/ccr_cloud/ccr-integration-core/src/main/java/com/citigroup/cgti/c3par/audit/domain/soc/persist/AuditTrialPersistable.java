package com.citigroup.cgti.c3par.audit.domain.soc.persist;

import java.util.List;

import com.citigroup.cgti.c3par.audit.domain.AuditTrailProcess;
import com.citigroup.cgti.c3par.bpm.ejb.rel.domain.RelationshipDTO;
import com.citigroup.cgti.c3par.common.domain.AuditLog;
import com.citigroup.cgti.c3par.common.domain.ContactDetailsDTO;
import com.citigroup.cgti.c3par.common.domain.TIMailAudit;
import com.citigroup.cgti.c3par.common.domain.TIMailAuditAttachments;
import com.citigroup.cgti.c3par.common.domain.TIMailAuditResponse;
import com.citigroup.cgti.c3par.communication.domain.TIMailAuditAttachmentsDTO;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.persistance.Persistable;
import com.citigroup.cgti.c3par.relationship.domain.ThirdParty;

public interface AuditTrialPersistable extends Persistable {

	public TIProcess getAuditTrail(TIProcess tiProcess);

	List<TIMailAudit> getEMailAuditTrailList(AuditTrailProcess auditTrailProcess);

	TIMailAudit getEMailAuditTrail(AuditTrailProcess auditTrailProcess);

	TIMailAuditResponse getResponseEMailAuditTrail(
			AuditTrailProcess auditTrailProcess);

	List<AuditLog> getAdminChangeDetails(Long processID);

	List<ContactDetailsDTO> getContactsDetails(Long contactID,
			String objectName, String entry);

	List<RelationshipDTO> getRelationshipDetails(Long relationID);
	
	public List<ThirdParty> getThirdPartyList(Long thirdPartyId);

	public List<TIMailAuditAttachments> getEmailAuditTrailAttachments(AuditTrailProcess auditTrailProcess);

    public TIMailAuditAttachmentsDTO getDocumentForDownload(Long fileContentID);

    public AuditLog findAuditLogById(Long id);
    
    public TIMailAuditAttachments getEmailAuditTrailAttachmentDetails(
			TIMailAuditAttachments mailAttachment);
	
	public List<String> getCMPAttachmentsFileNames(String cmpOrderItemId);

    public List<ContactDetailsDTO> getCmpContactsDetails(Long contactID);
}
