package com.citigroup.cgti.c3par.admin.service.impl;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citigroup.cgti.c3par.admin.dao.service.ManageTagsDao;
import com.citigroup.cgti.c3par.admin.domain.ManageMoreInfoTagDTO;
import com.citigroup.cgti.c3par.admin.service.ManageTagsService;

/**
 * @author ac81662
 *
 */
@Service
public class ManageTagsServiceImpl implements ManageTagsService {

    private static final Logger log = Logger.getLogger(ManageTagsServiceImpl.class.getName());

    @Autowired
    private ManageTagsDao manageTagsDao;

    @Override
    public boolean addTag(ManageMoreInfoTagDTO manageMoreInfoTag) throws Exception {
        return manageTagsDao.addTag(manageMoreInfoTag);
    }

    @Override
    public List<ManageMoreInfoTagDTO> getTagsList() throws Exception {
        return manageTagsDao.getTagsList();
    }

    @Override
    public void getEditTagDetails(ManageMoreInfoTagDTO manageMoreInfoTag) throws Exception {
        manageTagsDao.getEditTagDetails(manageMoreInfoTag);
    }

    @Override
    public boolean updateTag(ManageMoreInfoTagDTO manageMoreInfoTag) throws Exception {
        return manageTagsDao.updateTag(manageMoreInfoTag);
    }

    @Override
    public Boolean deleteTag(Long tagID) throws Exception {
        return manageTagsDao.deleteTag(tagID);
    }

    @Override
    public boolean checkDuplicateTag(ManageMoreInfoTagDTO manageMoreInfoTag) throws Exception {
        return manageTagsDao.checkDuplicateTag(manageMoreInfoTag);
    }

}
