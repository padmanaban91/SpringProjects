/**
 * 
 */
package com.citigroup.cgti.c3par.businessjustification.domain.soc.persist;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.citigroup.cgti.c3par.businessjustification.domain.BusinessJustificationProcess;
import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;
import com.citigroup.cgti.c3par.businessjustification.domain.ConReqCitiContactXref;
import com.citigroup.cgti.c3par.businessjustification.domain.ConReqCitiReqConXref;
import com.citigroup.cgti.c3par.businessjustification.domain.ConReqTPContactXref;
import com.citigroup.cgti.c3par.businessjustification.domain.DistributionListDTO;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.common.domain.HistoryContact;
import com.citigroup.cgti.c3par.communication.domain.CopyFromCmpDTO;
import com.citigroup.cgti.c3par.domain.ConnectionRequest;
import com.citigroup.cgti.c3par.domain.Role;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.persistance.Persistable;

/**
 * @author pc79439
 * 
 */
public interface BusinessJustificationServicePersistable extends Persistable {

	List<GenericLookup> getGenericLookupDropDown(String defName);

	void updateConnectionBasicInfoBySA(String connectionName, String oldConnectionName, Long tiRequestId, String soeId);

	void updateConnectionBasicInfo(Long tiRequestID, Long priority, String donotimpl, String vtTicketNo, Date date);

	void updateBusinessCaseInfo(TIRequest tirequest, ConnectionRequest conreq, String[] virtualConReason);

	List<ConReqCitiReqConXref> getRequesterContactsList(Long planningId);

	List<ConReqCitiContactXref> getTargetContactsList(Long planningId);

	DistributionListDTO searchDistributionList(DistributionListDTO distributionListDTO);

	List<Role> getRoles();

	List<Long> saveConReqCitiContactXref(Long planningId, CitiContact citiContact, String[] roleIds);

	List<Long> saveConReqCitiContactXref(Long planningId, Long citiContactId, String[] roleIds);

	List<Long> saveCmpRequestContactXref(Long cmpId, Long citiContactId, String[] rolesIds);

	boolean isValidateThridPartyConts(Long relId, String relType, Long reqTpId, Long tarTpId);

	void updateConReqCitiContactXref(List<ConReqCitiContactXref> citiContactXrefs,Long planningId);

	void deleteConReqCitiContactXref(String[] conIds);

	List<Long> saveConReqCitiReqContactXref(Long planningId, CitiContact citiContact, String[] roleIds);

	List<Long> saveConReqCitiReqContactXref(Long planningId, Long citiContactId, String[] roleIds);

	void updateConReqCitiReqContactXref(List<ConReqCitiReqConXref> citiContactXrefs,Long planningId);

	void deleteConReqCitiReqContactXref(String[] conIds);

	Long getTiRequestForVersion(Integer version, Long processId);

	List<ConReqTPContactXref> getRequesterTPContactsList(Long planningId);

	List<ConReqTPContactXref> getTargetTPContactsList(Long planningId);

	void deleteContactsBySA(List<HistoryContact> historyContacts, Long tiRequestId, String soeId, String requestFrom);

	void addContactsBySA(List<HistoryContact> historyContacts, Long tiRequestId, String soeId, String requestFrom);

	void updateContactsBySA(Map<Integer, HistoryContact> newHistoryContacts,
			Map<Integer, HistoryContact> oldHistoryContacts, Long tiRequestId, String soeId, String requestFrom);

	void updateBusinessCaseBySA(Long relationshipId, Long oldRelationshipId, Long tiRequestId, String soeId);

	void copyContactsFromRelationship(Long tiRequestId);

	String getConnectionBusinessJustification(Long processId, Long tiRequestId);

	CitiContact getGDWDataBySSOId(String ssoId);

	CitiContact getBusinessOwnerDetails(Long tiRequestId, String relationType);

	CopyFromCmpDTO getCmpDetailsForCopy(BusinessJustificationProcess busjusProcess, String screenName,
			CopyFromCmpDTO copyFromCmpDTO, String relationshipType) throws Exception;

	List<String> getCmpRequestList(BusinessJustificationProcess businessJustificationProcess) throws Exception;

	public void updateBusinessCaseInfoByAdmin(TIRequest tirequest, ConnectionRequest conreq,
			String businessJustification, String soeId);
}
