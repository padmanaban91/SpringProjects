package com.citigroup.cgti.c3par.bpm.ejb.search.domain;

import java.io.Serializable;

/*import com.citigroup.cgti.c3par.domain.Name;*/


/**
 * The Class Process.
 */
public class Process implements Serializable{

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 5521405911696136036L;

    /** The id. */
    private Long id;

    /** The name. */
    private String name;

    /** The display_id. */
    private String display_id;

    /** The version_number. */
    private Long version_number;

    /** The status. */
    private String status;

    /** The phase. */
    private String phase;

    /** The type. */
    private String type;

    /** The ti process. */
    private String tiProcess;

    /** The role. */
    private String role;

    /** The priority. */
    private String priority;

    /** The participant. */
    private String participant;

    /** The bpm activity id. */
    private String bpmActivityId;

    /** The bmp instance id. */
    private String bmpInstanceId;

    /** The tirequestid. */
    private Long tirequestid;

    /** The task name. */
    private String taskName;
    
    private String taskCode;

    /** The bpm process name. */
    private String bpmProcessName;
    
    /**process locked date */
    private String lockedDate;
    
    /** process activity_code (or) task_code*/
    private String activityCode;
    
    private Long timeInActivity;
    
    private Long activityTrialId;
    
    private Long activityId;
    
    private String roleName;
    
    private String region; 
    
    private String sector;
    
    private String userAccess;
    
    private String submissionRole;
    
    private String bulkACVInstance;
    
    private String bulkACVActivity;  
    

	public String getSector() {
		return sector;
	}

	public void setSector(String sector) {
		this.sector = sector;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	/**
     * get Activity Locked date
     * @return
     */
    public String getLockedDate() {
		return lockedDate;
	}

    public String getTaskCode() {
		return taskCode;
	}

	public void setTaskCode(String taskCode) {
		this.taskCode = taskCode;
	}

	/**
     * set Activity locked date
     * @param lockedDate
     */
	public void setLockedDate(String lockedDate) {
		this.lockedDate = lockedDate;
	}

	/**
	 * get process current Activity code
	 * @return
	 */
	public String getActivityCode() {
		return activityCode;
	}

	/**
	 * set process current Activity code.
	 * @param activityCode
	 */
	public void setActivityCode(String activityCode) {
		this.activityCode = activityCode;
	}

	/**
     * Gets the task name.
     *
     * @return the task name
     */
    public String getTaskName() {
	return taskName;
    }

    /**
     * Sets the task name.
     *
     * @param taskName the new task name
     */
    public void setTaskName(String taskName) {
	this.taskName = taskName;
    }

    /**
     * Gets the participant.
     *
     * @return the participant
     */
    public String getParticipant() {
	return participant;
    }

    /**
     * Sets the participant.
     *
     * @param participant the new participant
     */
    public void setParticipant(String participant) {
	this.participant = participant;
    }

    /**
     * Gets the phase.
     *
     * @return the phase
     */
    public String getPhase() {
	return phase;
    }

    /**
     * Sets the phase.
     *
     * @param phase the new phase
     */
    public void setPhase(String phase) {
	this.phase = phase;
    }

    /**
     * Gets the priority.
     *
     * @return the priority
     */
    public String getPriority() {
	return priority;
    }

    /**
     * Sets the priority.
     *
     * @param priority the new priority
     */
    public void setPriority(String priority) {
	this.priority = priority;
    }

    /**
     * Gets the role.
     *
     * @return the role
     */
    public String getRole() {
	return role;
    }

    /**
     * Sets the role.
     *
     * @param role the new role
     */
    public void setRole(String role) {
	this.role = role;
    }

    /**
     * Gets the ti process.
     *
     * @return the ti process
     */
    public String getTiProcess() {
	return tiProcess;
    }

    /**
     * Sets the ti process.
     *
     * @param tiProcess the new ti process
     */
    public void setTiProcess(String tiProcess) {
	this.tiProcess = tiProcess;
    }

    /**
     * Gets the type.
     *
     * @return the type
     */
    public String getType() {
	return type;
    }

    /**
     * Sets the type.
     *
     * @param type the new type
     */
    public void setType(String type) {
	this.type = type;
    }

    /**
     * Gets the display_id.
     *
     * @return the display_id
     */
    public String getDisplay_id() {
	return display_id;
    }

    /**
     * Sets the display_id.
     *
     * @param display_id the new display_id
     */
    public void setDisplay_id(String display_id) {
	this.display_id = display_id;
    }

    /**
     * Gets the version_number.
     *
     * @return the version_number
     */
    public Long getVersion_number() {
	return version_number;
    }

    /**
     * Sets the version_number.
     *
     * @param version_number the new version_number
     */
    public void setVersion_number(Long version_number) {
	this.version_number = version_number;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
	return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
	this.status = status;
    }

    /**
     * Gets the bmp instance id.
     *
     * @return the bmp instance id
     */
    public String getBmpInstanceId() {
	return bmpInstanceId;
    }

    /**
     * Sets the bmp instance id.
     *
     * @param bmpInstanceId the new bmp instance id
     */
    public void setBmpInstanceId(String bmpInstanceId) {
	this.bmpInstanceId = bmpInstanceId;
    }

    /**
     * Gets the bpm activity id.
     *
     * @return the bpm activity id
     */
    public String getBpmActivityId() {
	return bpmActivityId;
    }

    /**
     * Sets the bpm activity id.
     *
     * @param bpmActivityId the new bpm activity id
     */
    public void setBpmActivityId(String bpmActivityId) {
	this.bpmActivityId = bpmActivityId;
    }

    /**
     * Gets the tirequestid.
     *
     * @return the tirequestid
     */
    public Long getTirequestid() {
	return tirequestid;
    }

    /**
     * Sets the tirequestid.
     *
     * @param tirequestid the new tirequestid
     */
    public void setTirequestid(Long tirequestid) {
	this.tirequestid = tirequestid;
    }

    /**
     * Gets the bpm process name.
     *
     * @return the bpm process name
     */
    public String getBpmProcessName() {
	return bpmProcessName;
    }

    /**
     * Sets the bpm process name.
     *
     * @param bpmProcessName the new bpm process name
     */
    public void setBpmProcessName(String bpmProcessName) {
	this.bpmProcessName = bpmProcessName;
    }

    /**
     * Gets the id.
     *
     * @return the id
     */
    public Long getId() {
	return id;
    }

    /**
     * Sets the id.
     *
     * @param id the new id
     */
    public void setId(Long id) {
	this.id = id;
    }

    /**
     * Gets the name.
     *
     * @return the name
     */
    public String getName() {
	return name;
    }

    /**
     * Sets the name.
     *
     * @param name the new name
     */
    public void setName(String name) {
	this.name = name;
    }

	public void setTimeInActivity(Long timeInActivity) {
		this.timeInActivity = timeInActivity;
	}

	public Long getTimeInActivity() {
		return timeInActivity;
	}

	public Long getActivityTrialId() {
		return activityTrialId;
	}

	public void setActivityTrialId(Long activityTrialId) {
		this.activityTrialId = activityTrialId;
	}

	
	/**
	 * @return the activityId
	 */
	public Long getActivityId() {
		return activityId;
	}

	/**
	 * @param activityId the activityId to set
	 */
	public void setActivityId(Long activityId) {
		this.activityId = activityId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getUserAccess() {
		return userAccess;
	}

	public void setUserAccess(String userAccess) {
		this.userAccess = userAccess;
	}

	public String getSubmissionRole() {
		return submissionRole;
	}

	public void setSubmissionRole(String submissionRole) {
		this.submissionRole = submissionRole;
	}

	public String getBulkACVInstance() {
		return bulkACVInstance;
	}

	public void setBulkACVInstance(String bulkACVInstance) {
		this.bulkACVInstance = bulkACVInstance;
	}

	public String getBulkACVActivity() {
		return bulkACVActivity;
	}

	public void setBulkACVActivity(String bulkACVActivity) {
		this.bulkACVActivity = bulkACVActivity;
	}
    
    
}
