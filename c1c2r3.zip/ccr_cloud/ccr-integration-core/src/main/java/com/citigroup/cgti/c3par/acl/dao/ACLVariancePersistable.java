package com.citigroup.cgti.c3par.acl.dao;

import com.citigroup.cgti.c3par.acl.domain.ACLVariance;
import com.citigroup.cgti.c3par.domain.TIProcess;
import com.citigroup.cgti.c3par.persistance.Persistable;

public interface ACLVariancePersistable extends Persistable {

	public ACLVariance getACLVarianceData(TIProcess tiProcess);

	public ACLVariance getACLVariance(TIProcess tiProcess);

	public void storeACLVariance(ACLVariance aclVariance);

	public void deleteACLVariance(ACLVariance aclVariance);

	public void updateACLVariance(ACLVariance aclVariance);

}
