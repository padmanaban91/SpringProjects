package com.citigroup.cgti.c3par.configuation;

public class QueryConstants {

    public static final String WILDCARD_CHARACTER = "*";
    public static final String QUERY_TASK_SELECT = "getMyTaskQuerySelect";
    public static final String QUERY_TASK_STRING = "getQuerySelectString";
    public static final String QUERY_COUNT_GLOBAL_SEARCH = "getQuerySelectStringCount";
    public static final String QUERY_PROCESS_DATA = "getProcessData";
    public static final String QUERY_RFC_INFOMAN = "getInfomanRFC";
    public static final String QUERY_IS_BULK_REQUEST = "getBulkRequestFlag";
    public static final String QUERY_SOW_PROCESS_DATA = "getSowNumberProcessData";
    public static final String QUERY_COUNT_MY_TASK = "getMyTaskCount";
    public static final String QUERY_COUNT_MY_TASK_CONTACT = "getMyTaskContactWithEntitlementCount";
    public static final String QUERY_COUNT_GENERAL_SEARCH = "getGeneralSearchAttributesCount";
    public static final String QUERY_COUNT_GENERAL_SEARCH_REQUESTER_BUSINESS_OWNER = "getGeneralSearchAttributesCountForRequesterBusinessOwner";
    public static final String QUERY_GENERAL_SEARCH = "getGeneralSearchAttributes";
    public static final String QUERY_GENERAL_SEARCH_REQUESTER_BUSINESS_OWNER = "getGeneralSearchAttributesForRequesterBusinessOwner";
    public static final String QUERY_GENERAL_SEARCH_WITH_PAGINATION = "getGeneralSearchAttributesWithPagination";
    public static final String QUERY_GENERAL_SEARCH_WITH_PAGINATION_REQUESTER_BUSINESS_OWNER = "getGeneralSearchAttributesWithPaginationForRequesterBusinessOwner";
    public static final String GET_MYTASK_WITH_ENTITLEMENT = "GET_MYTASK_WITH_ENTITLEMENT";
    public static final String GET_MYTASK_WITH_ENTITLEMENT_PAGINATION = "GET_MYTASK_WITH_ENTITLEMENT_PAGINATION";
    public static final String GET_TASK_DETAILS_IN_MYTASK = "GET_TASK_DETAILS_IN_MYTASK";
    public static final String GET_ROLE_DETAILS_IN_MYTASK = "GET_ROLE_DETAILS_IN_MYTASK";
    public static final String GET_REGION_DETAILS_IN_MYTASK = "GET_REGION_DETAILS_IN_MYTASK";
    public static final String GET_SECTOR_DETAILS_IN_MYTASK = "GET_SECTOR_DETAILS_IN_MYTASK";
    public static final String VERIFY_SOW_ROLE_NAME = "VERIFY_SOW_ROLE_NAME";
    public static final String UPDATE_VERIFY_SOW_ROLE_IN_AUDIT_TRAIL = "UPDATE_VERIFY_SOW_ROLE_IN_AUDIT_TRAIL";

    public static final String MY_LOCKED_TASKS = "MY_LOCKED_TASKS";
    public static final String MY_LOCKED_TASKS_WITH_PAGINATION = "MY_LOCKED_TASKS_WITH_PAGINATION";
    public static final String MY_LOCKED_TASKS_COUNT = "MY_LOCKED_TASKS_COUNT";

    public static final String GENERAL_SEARCH_APPLICATION = "GENERAL_SEARCH_APPLICATION";
    public static final String GENERAL_SEARCH_APPLICATION_WITH_PAGINATION = "GENERAL_SEARCH_APPLICATION_WITH_PAGINATION";
    public static final String GENERAL_SEARCH_APPLICATION_COUNT = "GENERAL_SEARCH_APPLICATION_COUNT";

    public static final String GENERAL_SEARCH_IP_PORT_POLICY = "GENERAL_SEARCH_IP_PORT_POLICY";
    public static final String GENERAL_SEARCH_IP_PORT_POLICY_TERMINATED= "GENERAL_SEARCH_IP_PORT_POLICY_TERMINATED";
    public static final String GENERAL_SEARCH_IP_PORT_POLICY_WITH_PAGINATION = "GENERAL_SEARCH_IP_PORT_POLICY_WITH_PAGINATION";
    public static final String GENERAL_SEARCH_IP_PORT_POLICY_TERMINATED_WITH_PAGINATION = "GENERAL_SEARCH_IP_PORT_POLICY_TERMINATED_WITH_PAGINATION";
    public static final String GENERAL_SEARCH_IP_PORT_POLICY_COUNT = "GENERAL_SEARCH_IP_PORT_POLICY_COUNT";
    public static final String GENERAL_SEARCH_IP_PORT_POLICY_TERMINATED_COUNT = "GENERAL_SEARCH_IP_PORT_POLICY_TERMINATED_COUNT";

    public static final String GENERAL_SEARCH_IP = "GENERAL_SEARCH_IP";
    public static final String GENERAL_SEARCH_IP_WITH_PAGINATION = "GENERAL_SEARCH_IP_WITH_PAGINATION";
    public static final String GENERAL_SEARCH_IP_COUNT = "GENERAL_SEARCH_IP_COUNT";

    public static final String GENERAL_SEARCH_CONTACT_PC_RG_SCT_APP = "GENERAL_SEARCH_CONTACT_PC_RG_SCT_APP";
    public static final String GENERAL_SEARCH_CONTACT_PC_RG_SCT_APP_WITH_PAGINATION = "GENERAL_SEARCH_CONTACT_PC_RG_SCT_APP_WITH_PAGINATION";
    public static final String GENERAL_SEARCH_CONTACT_PC_RG_SCT_APP_COUNT = "GENERAL_SEARCH_CONTACT_PC_RG_SCT_APP_COUNT";

    public static final String GENERAL_SEARCH_POLICY = "GENERAL_SEARCH_POLICY";
    public static final String GENERAL_SEARCH_POLICY_WITH_PAGINATION = "GENERAL_SEARCH_POLICY_WITH_PAGINATION";
    public static final String GENERAL_SEARCH_POLICY_COUNT = "GENERAL_SEARCH_POLICY_COUNT";

    public static final String GENERAL_SEARCH_PORT = "GENERAL_SEARCH_PORT";
    public static final String GENERAL_SEARCH_PORT_WITH_PAGINATION = "GENERAL_SEARCH_PORT_WITH_PAGINATION";
    public static final String COUNT_GENERAL_SEARCH_PORT = "COUNT_GENERAL_SEARCH_PORT";

    public static final String GENERAL_SEARCH_OPEIMP = "GENERAL_SEARCH_OPEIMP";
    public static final String GENERAL_SEARCH_OPEIMP_WITH_PAGINATION = "GENERAL_SEARCH_OPEIMP_WITH_PAGINATION";
    public static final String GENERAL_SEARCH_OPEIMP_COUNT = "GENERAL_SEARCH_OPEIMP_COUNT";

    public static final String GENERAL_SEARCH_APPSENSE = "GENERAL_SEARCH_APPSENSE";
    public static final String GENERAL_SEARCH_APPSENSE_WITH_PAGINATION = "GENERAL_SEARCH_APPSENSE_WITH_PAGINATION";
    public static final String GENERAL_SEARCH_APPSENSE_COUNT = "GENERAL_SEARCH_APPSENSE_COUNT";

    public static final String GENERAL_SEARCH_PROXY = "GENERAL_SEARCH_PROXY";
    public static final String GENERAL_SEARCH_PROXY_WITH_PAGINATION = "GENERAL_SEARCH_PROXY_WITH_PAGINATION";
    public static final String GENERAL_SEARCH_PROXY_COUNT = "GENERAL_SEARCH_PROXY_COUNT";

    public static final String GET_ACV_RECORDS_FOR_MIGRATION = "GET_ACV_RECORDS_FOR_MIGRATION";
    public static final String IS_TEMPLATE_CONNECTION_ABORTED = "IS_TEMPLATE_CONNECTION_ABORTED";

    public static final int QUERY_EXCLUDE = 0;
    public static final int QUERY_INCLUDE = 1;
    public static final String QUERY_STRING_EXCLUDE = "DUMMY";

    public static final String NONTHIRDPARTYACVCONNECTIONS = "NONTHIRDPARTYACVCONNECTIONS";
    public static final String EMAILCONTACTSFORCONNECTIONID = "EMAILCONTACTSFORCONNECTIONID";

    public static final String VIEW_TEMPLATES = "VIEW_TEMPLATES";
    public static final String COUNT_VIEW_TEMPLATES = "COUNT_VIEW_TEMPLATES";
    public static final String GET_TEMPLATE_CONNECTION="GET_TEMPLATE_CONNECTION";

    // ADDED TO FETCH THE LAST NON-ACV, NON-MANAGE CONTACT, NON-ABORTED TI
    // REQUEST ID.
    // THIS IS REQUIRED TO FIX THE ABORTED RULE ISSUE.
    public static final String PREVIOUS_NON_DELETED_TI_REQUEST_QUERY = "PREVIOUS_NON_DELETED_TI_REQUEST_QUERY";
    // Ideally this and the above query need to be the same but since it is
    // being added at the last minute of 10.7 migration
    // it is being seperated out as the remaing test cases have been thoroughly
    // tested. (see additional documentation in the rtc item)
    public static final String PREVIOUS_NON_DELETED_TI_REQUEST_QUERY_VER2 = "PREVIOUS_NON_DELETED_TI_REQUEST_QUERY_VER2";

    // Access form Query Constants
    public static final String ACCESSFORM_GETAPPLICATIONDETAILS_IPREG = "ACCESSFORM_GETAPPLICATIONDETAILS_IPREG";
    public static final String ACCESSFORM_GETAPPLICATIONDETAILS_FW = "ACCESSFORM_GETAPPLICATIONDETAILS_FW";
    public static final String ACCESSFORM_GETAPPLICATIONDETAILS_HISTORYTABLE_IPREG = "ACCESSFORM_GETAPPLICATIONDETAILS_HISTORYTABLE_IPREG";
    public static final String ACCESSFORM_GETAPPLICATIONDETAILS_HISTORYTABLE_FW = "ACCESSFORM_GETAPPLICATIONDETAILS_HISTORYTABLE_FW";

    public static final String ACCESSFORM_GETCABAPPROVERLIST = "ACCESSFORM_GETCABAPPROVERLIST";
    public static final String ACCESSFORM_GETSECACLAPPLICATIONDETAILS = "ACCESSFORM_GETSECACLAPPLICATIONDETAILS";

    public static final String ACCESSFORM_ISAPPSENSEHIGHRISK = "ACCESSFORM_ISAPPSENSEHIGHRISK";
    public static final String ACCESSFORM_ISPROXYHIGHRISK = "ACCESSFORM_ISPROXYHIGHRISK";
    public static final String ACCESSFORM_GETAPPSENSE_PROXY_IMPL = "ACCESSFORM_GETAPPSENSE_PROXY_IMPL";
    public static final String ACCESSFORM_GETPROXY_APPLICATION_DETAILS = "ACCESSFORM_GETPROXY_APPLICATION_DETAILS";

    public static final String ACCESSFORM_AAFIMPLINFO = "ACCESSFORM_AAFIMPLINFO";
    public static final String ACCESSFORM_PAFIMPLINFO = "ACCESSFORM_PAFIMPLINFO";
    public static final String ACCESSFORM_FAFIMPLINFO = "ACCESSFORM_FAFIMPLINFO";
    public static final String ACCESSFORM_IPFAFIMPLINFO = "ACCESSFORM_IPFAFIMPLINFO";
    public static final String ACCESSFORM_ACLIMPLINFO = "ACCESSFORM_ACLIMPLINFO";

    public static final String GENERAL_SEARCH_SEC_ACL = "GENERAL_SEARCH_SEC_ACL";
    public static final String GENERAL_SEARCH_SEC_ACL_WITH_PAGINATION = "GENERAL_SEARCH_SEC_ACL_WITH_PAGINATION";
    public static final String GENERAL_SEARCH_SEC_ACL_COUNT = "GENERAL_SEARCH_SEC_ACL_COUNT";

    public static final String FAF_CHECK_QUERY = "FAF_CHECK_QUERY";
    public static final String PAF_CHECK_QUERY = "PAF_CHECK_QUERY";
    public static final String IP_REG_CHECK_QUERY = "IP_REG_CHECK_QUERY";

    public static final String STATUS_LIST = "SELECT tistatus.status statusName FROM ti_status_type tistatus";
    public static final String PRIORITY_LIST = "SELECT lookup.value1 priority FROM generic_lookup lookup WHERE definition_id=(SELECT id FROM generic_lookup_defs WHERE name='Process Priority') order by lookup.value1";
    public static final String PROCESS_LIST = "SELECT processtype.process_type process FROM ti_process_type processtype order by processtype.process_type";
    public static final String MODE_LIST = "SELECT distinct tipro.process_activity_mode modename FROM ti_process tipro order by tipro.process_activity_mode";
    public static final String PHASE_LIST = "SELECT tireqtype.request_type phaseName FROM c3par.ti_request_type tireqtype order by tireqtype.request_type";
    public static final String VIEW_NAME_LIST = "select inboxview.GROUPVIEW_BY, inboxview.view_name,inboxview.view_code from inbox_view inboxview where inboxview.id in(select inboxRoleRef.INBOX_VIEW_ID from inboxview_role_ref inboxRoleRef  "
            + "where inboxRoleRef.security_Role_Id in(select role_id from c3par_user_role_xref where user_id=:userId) and inboxRoleRef.DELETE_FLAG='N')  and inboxview.delete_Flag='N' GROUP BY  inboxview.view_name,inboxview.view_code, inboxview.GROUPVIEW_BY  "
            + "union  select inboxview.GROUPVIEW_BY, inboxview.view_name,inboxview.view_code from inbox_view inboxview where inboxview.GROUPVIEW_BY=2 and inboxview.delete_Flag='N' "
            + "union select customview.groupview_by,customview.view_name,customview.view_code from inbox_custom_view customview where customview.user_id=:userId and customview.DELETE_FLAG='N'";
    public static final String VIEW_NAME = "from InboxView where viewCode =:viewCode and deleteFlag='N'";
    public static final String CUSTOM_VIEW_NAME = "from InboxCustomView customView where customView.viewCode=:viewCode and customView.userId=:userId and customView.deletedFlag='N'";
    public static final String DELETE_CUSTOM_VIEW = "UPDATE InboxCustomView SET deletedFlag='Y' where viewCode=:viewCode";
    public static final String CUSTOMVIEW_BYUSERID = "from InboxCustomView where userId=:userId and deletedFlag='N' order by updatedDate desc LIMIT 1";
    public static final String CHECK_ADMIN = "from C3parUserRoleXref userRoleXref where userRoleXref.userId=:userId and userRoleXref.roleId =(select securityRole.id from SecurityRole securityRole where securityRole.name='C3PARSYSTEMADMIN')";
    public static final String IS_ENTITLED_ADMIN = "from C3parUserRoleXref userRoleXref where userRoleXref.userId=:userId and userRoleXref.roleId not in(select securityRole.id from SecurityRole securityRole where securityRole.name in('C3PARSYSTEMADMIN','C3PARUSER','Entitlement Requester'))";
    public static final String ROLE_SECTOR_LIST = "from UserRoleSectorView where userId=:userId";
    public static final String UPDATE_ADMIN_SUPPORT = "UPDATE ccr_task_ref set activity_name='admin_support' where id=:id";
    public static final String ASSIGN = "UPDATE ccr_task_ref SET task_participant=:taskparticipant where id=:id";
    public static final String UNASSIGN = "UPDATE ccr_task_ref SET task_participant=null where id=:id";
    public static final String ROLE_LIST = "select securityRole.name from SecurityRole securityRole where securityRole.id in(select userRoleXref.roleId from C3parUserRoleXref userRoleXref where userRoleXref.userId=:userId)";
    public static final String GETSTARTDATE = "from TIActivityTrail aTrail where aTrail.tiRequestId =:tiRequestId and aTrail.activityStatus='PROVIDEINFO'";
    public static final String GETSTARTDATE_BYID = "from TIActivityTrail aTrail where aTrail.id=:id";
    // public static final String SECTOR_LIST="select distinct
    // hierarchyMaster.sectorId from CitiHierarchyMaster hierarchyMaster where
    // hierarchyMaster.id in(select hierarchyXref.hierarchyMasterId from
    // C3parUserHierarchyXref hierarchyXref where hierarchyXref.userId
    // =:userId)";
    public static final String SECTOR_LIST = "select distinct hierarchymaster.sector_id sector from citi_hierarchy_master hierarchyMaster where hierarchymaster.id in(select hierarchyxref.citi_hierarchy_master_id from user_citi_hierarchy_xref hierarchyXref where hierarchyxref.user_id =:userId)";
    public static final String CHECK_BJ = "from TIActivityTrail aTrail where aTrail.tiRequestId=:tiRequestId and (aTrail.activityStage='DC' or aTrail.activityStage=null) and (aTrail.userId=:userId or aTrail.userId is null) and aTrail.activityId=12";
    public static final String TASK_CODE = "select ttt.taskCode from TITaskType ttt where ttt.id=(select tat.activityId from TIActivityTrail tat where tat.id =:activityTrailId)";
    public static final String EXP_MESSAGE = "select ERROR_MESSAGE_TEXT from CCR_TASK_REF where Activity_name =:acitvityName and connection_id =:connectionId";
    public static final String ACTIVITY_NAMES = "select distinct task from TITaskType order by task asc";

    // Export Rules
    public static final String EXPORTRULES_GETAPPLICATIONDETAILS_IPREG = "EXPORTRULES_GETAPPLICATIONDETAILS_IPREG";
    public static final String EXPORTRULES_GETAPPLICATIONDETAILS_FW = "EXPORTRULES_GETAPPLICATIONDETAILS_FW";

    public static final String GET_CITI_CONTACT_BY_USER_ID = "from CitiContact citiContact where upper(citiContact.ssoId)=(select upper(ssoId) from C3parUser c3parUser where c3parUser.id=:id)";
    public static final String GET_AGENT_DETAILS = "from AgentView agentView where upper(agentView.status)=upper('In Progress') and agentView.tiRequestId is not null and agentView.assignedUser is not null";
    public static final String RELATIONSHIP_ID = "select relationship_id relId from ti_process where id=(select process_id from ti_request where id=:tiRequestId)";
    public static final String BREACH_NOTIFICATION = "select TEMPLATE_ID from TI_MAIL_AUDIT where cmp_id =:cmpId and ti_request_id=:tiRequestId and TEMPLATE_ID=:templateId";
    public static final String CHECK_VERSION = "select count(id) as count from ti_process where id=(select process_id from ti_request where id=:tiRequestId) and version_number>1";
    public static final String CON_FW_RULE = "select count(id) as count from con_fw_rule where ti_request_id=:tiRequestId and status<>'DELETE'";
    public static final String PROXY_FILTER = "select count(id) as count from prx_proxy_filter where process_id=(select process_id from ti_request where id=:tiRequestId)";
    public static final String ACL_VARIANCE = "select count(id) as count from acl_variance WHERE ti_request_id=:tiRequestId";
    public static final String APS_APPSENSE = "select count(id) as count from aps_appsense_policy  where ti_request_id=:tiRequestId";
    public static final String CONNECTION_NAME = "select ti_pro.id id, ti_pro.process_name processName  from ti_process ti_pro where id=(select process_id from ti_request where  id=:tiRequestId)";
    public static final String UPDATE_CONNECTION_NAME = "Update TIProcess set processName=:processName where id=:id";
    public static final String UPDATE_RELATIONSHIP_STATUS = "Update Relationship set status=:status where id=:id ";
    public static final String UPDATE_RESOURCE_TYPE = "update Relationship set TARGET_RESOURCE_TYPE_ID =:targetResourceTypeId,REQUESTER_RESOURCE_TYPE_ID =:sourceResourceTypeId where ID =:id";
    public static final String TP_CONTACTS = "SELECT * FROM REL_TP_CONT_XREF CONT WHERE CONT.RELATIONSHIP_ID =:RELID";
    public static final String UTURN_TP_CONTACTS = "select * from rel_tp_cont_xref tpcon, tp_contact con where tpcon.relationship_id =:RELID and con.id=tpcon.tp_contact_id and con.thirdparty_id=:TPID";
    public static final String TP_LOCATION = "SELECT * FROM REL_TP_LOC_XREF LOC WHERE LOC.RELATIONSHIP_ID =:RELID";
    public static final String REL_CITI_LOCs = "select * from REL_REQ_CITI_LOC_XREF where relationship_id =:RELID";
    public static final String TI_REQUEST = "from TIRequest where id=:planningId";
    public static final String GET_TIREQUESTID = "select MAX(ti_request_id) tiRequestId from ti_request_planning_xref where planning_id=:planningId";
    public static final String GET_ROLE_LIST = "select distinct role.name from con_req_cit_rqcon_xref creq join role on creq.role_id=role.id union select distinct role.name from con_req_citi_contact_xref ctp join role on ctp.role_id=role.id";
    public static final String GET_ROLE_ID = "select id from role where name=:roleName";
    public static final String GET_CITICONTXREF = "SELECT distinct  b_conxref.* "
            + "FROM ti_request_planning_xref a_xref, ti_request_planning_xref b_xref, ti_request a_req, ti_request b_req, con_req_citi_contact_xref a_conxref, con_req_citi_contact_xref b_conxref "
            + "WHERE a_conxref.citi_contact_id=(select id from citi_contact where upper(sso_id)=upper(:ssoId)) AND a_conxref.role_id =:roleId AND a_conxref.request_id  =a_xref.planning_id AND a_xref.ti_request_id =a_req.id AND b_req.id = (SELECT MAX(id) FROM ti_request WHERE process_id=a_req.process_id ) AND b_xref.ti_request_id =b_req.id AND b_xref.planning_id =b_conxref.request_id "
            + "AND b_conxref.citi_contact_id=(select id from citi_contact where upper(sso_id)=upper(:ssoId)) AND b_conxref.role_id =:roleId";
    public static final String GET_CITIREQCONTXREF = "SELECT distinct  b_conxref.* "
            + "FROM ti_request_planning_xref a_xref, ti_request_planning_xref b_xref, ti_request a_req, ti_request b_req, con_req_cit_rqcon_xref a_conxref, con_req_cit_rqcon_xref b_conxref "
            + "WHERE a_conxref.citi_contact_id=(select id from citi_contact where upper(sso_id)=upper(:ssoId)) AND a_conxref.role_id =:roleId AND a_conxref.request_id  =a_xref.planning_id AND a_xref.ti_request_id =a_req.id AND b_req.id = (SELECT MAX(id) FROM ti_request "
            + "WHERE process_id=a_req.process_id ) AND b_xref.ti_request_id =b_req.id AND b_xref.planning_id =b_conxref.request_id AND b_conxref.citi_contact_id=(select id from citi_contact where upper(sso_id)=upper(:ssoId)) AND b_conxref.role_id =:roleId";
    public static final String UPDATE_ADMIN_SUPPORT_ACT = "UPDATE ccr_task_ref set activity_name='admin_support' where task_id=:ccrTaskRefId";
    /*
     * public static final String GET_COLUMN_DETAILS =
     * "FROM EcmColumn ecmcolumn WHERE ecmcolumn.id IN (SELECT viewcolumn.columnId FROM EcmViewColumn viewcolumn WHERE  viewcolumn.viewId=(select ecmview.id from EcmView ecmview "
     * +
     * "where ecmview.viewName=:viewName)  and viewcolumn.deleteFlag='N'  )  and ecmcolumn.deleteFlag='N' and ecmcolumn.isSortable='Y' order by ecmcolumn.columnOrder asc"
     * ;
     */public static final String GET_COLUMN_DETAILS = "From EcmViewColumn ecmViewColumn where ecmViewColumn.viewId=(select ecmview.id from EcmView ecmview where ecmview.viewName=:viewName)  and ecmViewColumn.deleteFlag='N' and ecmViewColumn.isSortable='Y' order by ecmViewColumn.columnOrder asc";

    public static final String GET_ECMUSER_PREFERENCE = "From EcmUserPreference ecmUserPreference  where ecmUserPreference.userId=:userId and ecmUserPreference.viewColumnId=:viewColumnId and ecmUserPreference.deleteFlag='N'";
    public static final String GET_USER_SETTING = "from EcmUserSetting userSetting where userSetting.userId=(select id from C3parUser c3paruser where upper(c3paruser.ssoId)=upper(:ssoId)) and userSetting.viewId=(select id from EcmView ecmView where ecmView.viewName=:viewName)";
    public static final String GET_ECM_VIEW_COLUMN = "from EcmViewColumn ecmViewColumn where ecmViewColumn.viewId=:viewId and ecmViewColumn.columnId=:columnId";
    public static final String SEARCH_DL = "from CitiContact citiContact where upper(citiContact.firstName) like upper(:searchContent) and citiContact.ssoId like '%DL'";
    public static final String CMP_ROLE = "from CMPRole role where role.isactive='Y' order by role.displayName asc";
    public static final String GET_CITI_CONTACT_BYID = "from CitiContact where id = ?";
    public static final String CCR_ROLE = "from Role role where role.name in('Manager','Business_Owner','Business_Tester','Director','BISO','PROJECT COORDINATOR','RELATIONSHIP MANAGER','Requestor','TECHNICAL CONTACT') and role.citi='Y' order by role.displayName asc";
    public static final String CMP_CON_XREF = "insert into CMP_REQUEST_CON_XREF(id,cmp_id,role_id,citi_contact_id) values(SEQ_CMP_REQUEST_CON_XREF.nextval,:cmpId,:roleId,:citiContactId)";
    public static final String CHECK_CMPCON_XREF = "select id from CMP_REQUEST_CON_XREF where cmp_id=:cmpId and role_id=:roleId and citi_contact_id=:citiContactId";
    
    public static final String GET_COMPLETED_CMP_LIST_BY_AGENT="select cmprequest.ID , cmprequest.ORDER_ITEM_ID from Cmp_Request cmprequest where cmprequest.Assigned_User =:agent and upper(cmprequest.status) = 'COMPLETED' and extract(year from CLOSED_DATE)=extract(year from sysdate) ";
    public static final String GET_COUNT_BY_CMP_TYPE="select count(TYPE_OF_CONN_INVOLVED) CONNTYPE,TYPE_OF_CONN_INVOLVED  from cmp_request where type_of_conn_involved is not null and Assigned_User =:agent and status = 'In Progress' ";
    public static final String GET_CMP_STATUS_COUNT="select count(status) sta , status from Cmp_Request where status is not null and upper(status)=upper('In Progress') and Assigned_User =:agent ";
    public static final String GET_CMP_COMPLETED_STATUS_COUNT="select count(status) sta , status from Cmp_Request where status is not null and upper(status)='COMPLETED' and extract(year from CLOSED_DATE)=extract (YEAR from sysdate) and Assigned_User =:agent ";
    public static final String GET_CMP_CANCELLED_STATUS_COUNT="select count(status) sta , status from Cmp_Request where status is not null and upper(status)='CANCELLED' and extract(year from UPDATED_DATE)=extract (YEAR from sysdate) and Assigned_User =:agent";
    public static final String GET_CMP_REQ_TYPE_COUNT="select count(Request_Type) REQTYP, Request_Type from Cmp_Request where Request_Type is not null and status='In Progress' and Assigned_User =:agent ";

    public static final String ACV_REQUEST_DEADLINE_DAYS = "ACVREQUESTDEADLINEDAYS";
    public static final String INTERNAL_SCHEDULED_ACV_IDS = "INTERNALSCHEDULEDACVIDS";
    public static final String TIREQUESTID_FOR_INTERNAL_ACV = "TIREQUESTIDFORINTERNALACV";
    public static final String TASKID_FOR_INTERNAL_ACV = "TASKIDFORINTERNALACV";
    public static final String PROCESS_INTERNAL_ACV = "PROCESSINTERNALACV";
    public static final String PROCESS_IDS_FOR_ACV = "PROCESSIDSFORACV";
    public static final String TEMP_APPROVAL_IDS = "TEMPAPPROVALIDS";

    public static final String VIRA_CSI_BATCH_JOB_QUERY = "VIRA_CSI_BATCH_JOB_QUERY";
    public static final String VIRA_CSI_IP_DETAILS_PAGE_QUERY = "VIRA_CSI_IP_DETAILS_PAGE_QUERY";

    // Queries added for Admin module
    public static final String ADMIN_MANAGE_BPM_NEW_ACTIVITY_DROPDOWN = "ADMIN_MANAGE_BPM_NEW_ACTIVITY_DROPDOWN";
    // Queries added for Convergence workflow (for multiple products)
    public static final String ALL_PRODUCTS_IMPLEMENTED = "ALL_PRODUCTS_IMPLEMENTED";
    public static final String HOW_MANY_PRODUCTS_REJECTED_IN_IMPL = "HOW_MANY_PRODUCTS_REJECTED_IN_IMPL";
    public static final String IS_WAITING_ECM_USER_REPLAY="select count(act.id) cnt from  ti_activity_trail act, ti_task_type task  where act.activity_id = task.id and act.activity_status in(:status)  and act.cmp_id = :cmpId  and task.task_code =:taskCode";
    public static final String CASP_MIGRATION="SELECT KEY_VALUE  FROM SERVER_CONSTANTS WHERE KEY_NAME='CASP_MIGRATION_START' AND KEY_ENV =(select KEY_VALUE from SERVER_CONSTANTS where KEY_NAME= 'ENVIRONMENT')";
    public static final String CASP_MIGRATION_MAIL_FLAG="SELECT KEY_VALUE  FROM SERVER_CONSTANTS WHERE KEY_NAME='CASP_MIGRATION_MAIL_FLAG' AND KEY_ENV =(select KEY_VALUE from SERVER_CONSTANTS where KEY_NAME= 'ENVIRONMENT')";
    public static final String GET_TR_LIST_BY_CASP="GET_TR_LIST_BY_CASP";
    public static final String CASP_DETAILS="SELECT supplier.supplier_id as supplierId,supplierDetail.detail_id as detailId,supplier.status_desc as supplierStatusDesc,supplierdetail.status_desc as detailerStatusDesc FROM VIRACASP.d_supplier supplier,VIRACASP.d_supplier_detail supplierDetail WHERE supplier.supplier_id= supplierdetail.supplier_id and supplier.supplier_id in(:caspIds) and supplierDetail.detail_id in(:detailIds)  order by supplier.supplier_id,supplierDetail.detail_id asc";
    public static final String CASP_DETAILS_BY_ID="SELECT supplier.status_desc AS supplierStatusDesc, supplierdetail.status_desc AS detailerStatusDesc FROM VIRACASP.d_supplier supplier,  VIRACASP.d_supplier_detail supplierDetail WHERE supplier.supplier_id= supplierdetail.supplier_id AND supplier.supplier_id  =:supplierId and supplierDetail.detail_id =:detailId";
    public static final String THIRD_PARTY_DETAILS="from com.citigroup.cgti.c3par.relationship.domain.ThirdParty thirdParty where thirdParty.caspId=:caspId and thirdParty.detailId=:detailId";
    public static final String GET_THIRD_PARTY_DETAILS="GET_THIRD_PARTY_DETAILS";
    public static final String SELECT_QUALITY_SCORE_BY_CASP=" from QualityScore qualityScore where qualityScore.processId=(select tireq.tiProcess.id from TIRequest tireq where tireq.id=:tiRequestId) and qualityScore.qparamId=(select quaMaster.id from QualityParameterMaster quaMaster where quaMaster.parameterName=:paramName) and qualityScore.status='FOUND'";
    public static final String SELECT_QUALITY_SCORE_BY_CONTACT_ROLE=" from QualityScore qualityScore where qualityScore.processId=:processId and qualityScore.qparamId=(select quaMaster.id from QualityParameterMaster quaMaster where quaMaster.parameterName=:paramName) and qualityScore.refId=:refId and qualityScore.status='FOUND'";
    public static final String ACCESS_FORM_RES_COUNT = "SELECT COUNT(TAT.ID) FROM ti_activity_trail TAT,  cmp_request CMP,  ccr_cmp_xref CMPXREF WHERE TAT.activity_id =  (SELECT id FROM ti_task_type WHERE task_code='awaiting_paf_faf_verify_resp' )  AND CMPXREF.TI_REQUEST_ID    =? AND CMPXREF.cmp_order_item_id=CMP.ORDER_ITEM_ID AND CMP.ID=TAT.CMP_ID ORDER BY TAT.id DESC";
    public static final String ACCESS_FORM_REQ_COUNT = "SELECT COUNT(TAT.ID) FROM ti_activity_trail TAT,  cmp_request CMP,  ccr_cmp_xref CMPXREF WHERE TAT.activity_id =  (SELECT id FROM ti_task_type WHERE task_code='awaiting_paf_faf_verify' ) AND TAT.activity_status  ='STARTED' AND CMPXREF.TI_REQUEST_ID    =? AND CMPXREF.cmp_order_item_id=CMP.ORDER_ITEM_ID AND CMP.ID=TAT.CMP_ID ORDER BY TAT.id DESC";
    public static final String GET_CMP_DATA="select * from Resolve_IT_Notify_Log RIT, cmp_request CMP where RIT.CMP_REQUEST_ID=CMP.id and CMP.order_item_id = :cmpOrderItemId";
    public static final String UPDATE_DIRECTOR="UPDATE CMPRequest  set directorApprover=:approverName where orderItemId=:orderItemId";
    public static final String GET_EMER_QUESTIONAIRES="from EmerBuscritQuestionaries where orderItemId=:orderItemId";
    public static final String UPDATE_USER_COMMENTS="Update CMPComments cmpComments set cmpComments.businessUserComments=:businessUserComments where cmpComments.id=:id";
    // Added for RTC 83099
    public static final String TASKID_FOR_INCEXP = "TASKIDFORINCEXP";
    public static final String TASKID_FOR_RECEXP_OR_TMPEXP = "TASKIDFORRECEXPORTMPEXP";

    public static final String GET_EMAIL_TEMPLATE_LIST = "GETEMAILTEMPLATELIST";

    public static final String GET_COUNT_OF_URGENCY_MAIL_SENT = "GETCOUNTOFURGENCYMAILSENT";

    public static final String GET_EMER_EMAIL_TEMPLATE_LIST = "GETEMEREMAILTEMPLATELIST";

    public static final String GET_EmerBuscritQuestionaries = "from EmerBuscritQuestionaries emerBuscritQuestionaries where emerBuscritQuestionaries.orderItemId =:orderItemId";

    public static final String GET_CITI_CONTACT = "FROM CitiContact where ssoId=:ssoID";

    public static final String GET_CITI_CONTACT_LIKE = "FROM CitiContact where ssoId like :ssoID order by id desc";

    public static final String INSERT_TI_MAIL_AUDIT_ATTACHMENTS = "INSERT INTO C3PAR.TI_MAIL_AUDIT_ATTACHMENTS(ID,TI_Mail_Audit_ID,FILE_NAME,DOC_MIME_TYPE,FILE_CONTENT,CREATED_DATE,CREATED_BY) VALUES(?, ?, ?, ?, ?, SYSDATE, ?)";

    public static final String SEQ_TI_MAIL_AUDIT_ATTACHMENTS = "SEQ_TI_MAIL_AUDIT_ATTACHMENTS";

    public static final String GET_AVAILABLE_TEMPLATE_IDS = "GETAVAILABLETEMPLATEIDS";

    public static final String GET_TEMPLATE_LIST = "GETTEMPLATELIST";
    public static final String GET_CMP_DIRECTOR_MAIL_COUNT = "GETCMPDIRECTORMAILCOUNT";
    public static final String GET_DIRECTOR_MAIL_TEMPLATE_LIST = "GETDIRECTORMAILTEMPLATELIST";

    public static final String DIRECTOR_MAIL_TEMPLATE = "DIRECTOR_MAIL_TEMPLATE";

    public static final String EMER_BUSCRIT_MAIL_TEMPLATE = "EMER_BUSCRIT_MAIL_TEMPLATE";

    public static final String BUSINESS_OWNER_ROLE_ID = "32";

    public static final String QUERY_TO_EXECUTE = "queryToExecute";

    public static final String QUERY_TO_EXECUTE_FOR_REQUESTER_BUSINESS_OWNER = "queryToExecuteForRequesterBusinessOnwerContact";

    public static final String UPDATE_CMP_CCR_XREF = "update CCR_CMP_XREF set ACCESS_FORM_REMAINDER_DATE = sysdate where CMP_ORDER_ITEM_ID =?  AND TI_REQUEST_ID =?";
    public static final String UPDATE_CMP_REQUEST = "update CMP_REQUEST set ACCESS_FORM_REMAINDER_DATE = sysdate where ORDER_ITEM_ID =?";
    public static final String ACCESS_FORM_REMAINDER_QUERY = "ACCESS_FORM_REMAINDER_QUERY";
    public static final String PC_PROVIDE_REMAINDER_QUERY = "PC_PROVIDE_REMAINDER_QUERY";
    public static final String IP_TEMPLATE_BY_TIREQUEST_AND_NWZONE = "IP_TEMPLATE_BY_TIREQUEST_AND_NWZONE";

    public static final String GET_TODAY_PRODUCTS = "SELECT TYPE_OF_CONN_INVOLVED, COUNT(*) CNT FROM CMP_REQUEST LEFT JOIN CCR_CMP_XREF CCRXREF on CMP_REQUEST.ORDER_ITEM_ID = CCRXREF.CMP_ORDER_ITEM_ID LEFT JOIN TI_REQUEST ON CCRXREF.TI_REQUEST_ID = TI_REQUEST.ID WHERE AVAILABLE_DATE > trunc(SYSDATE) and AVAILABLE_DATE < trunc(SYSDATE+1) GROUP BY TYPE_OF_CONN_INVOLVED";
    public static final String GET_TODAY_PRIORITY = "SELECT REQUEST_URGENCY, COUNT(*) CNT FROM CMP_REQUEST LEFT JOIN CCR_CMP_XREF CCRXREF on CMP_REQUEST.ORDER_ITEM_ID = CCRXREF.CMP_ORDER_ITEM_ID LEFT JOIN TI_REQUEST ON CCRXREF.TI_REQUEST_ID = TI_REQUEST.ID WHERE AVAILABLE_DATE > trunc(SYSDATE) and AVAILABLE_DATE < trunc(SYSDATE+1) GROUP BY REQUEST_URGENCY";
    public static final String GET_TODAY_PROVIDE_INFO = "SELECT TI_TASK_TYPE.TASK TASK, COUNT(*) CNT FROM TI_ACTIVITY_TRAIL  JOIN TI_TASK_TYPE ON TI_ACTIVITY_TRAIL.ACTIVITY_ID = TI_TASK_TYPE.ID  WHERE TI_ACTIVITY_TRAIL.ACTIVITY_STATUS = 'SCHEDULED' AND TI_ACTIVITY_TRAIL.ACTIVITY_ID = (SELECT ID FROM TI_TASK_TYPE WHERE TI_TASK_TYPE.TASK_CODE = 'pro_inf')  "
            + "AND TI_ACTIVITY_TRAIL.ACTIVITY_STARTDATE > TRUNC(SYSDATE) AND TI_ACTIVITY_TRAIL.ACTIVITY_STARTDATE < TRUNC(SYSDATE+1)  GROUP BY TI_TASK_TYPE.TASK "
            + "UNION SELECT TI_ACTIVITY_TRAIL.ACTIVITY_STATUS TASK, COUNT(*) CNT FROM TI_ACTIVITY_TRAIL  WHERE TI_ACTIVITY_TRAIL.ACTIVITY_STATUS = 'REJECTED'  AND (TI_ACTIVITY_TRAIL.ACTIVITY_ENDDATE > TRUNC(SYSDATE) AND TI_ACTIVITY_TRAIL.ACTIVITY_ENDDATE < TRUNC(SYSDATE+1))  GROUP BY TI_ACTIVITY_TRAIL.ACTIVITY_STATUS";

    public static final String GET_PRODUCT_RECORDS = "SELECT TI_REQUEST.VERSION_NUMBER VERSION, CMP_REQUEST.ORDER_ITEM_ID CMP_ID, TI_REQUEST.PROCESS_ID CCR_ID, CMP_REQUEST.TYPE_OF_CONN_INVOLVED REQUEST_TYPE, CMP_REQUEST.REQUEST_URGENCY Urgency FROM CMP_REQUEST LEFT "
            + "JOIN CCR_CMP_XREF CCRXREF on CMP_REQUEST.ORDER_ITEM_ID = CCRXREF.CMP_ORDER_ITEM_ID LEFT JOIN TI_REQUEST ON CCRXREF.TI_REQUEST_ID = TI_REQUEST.ID WHERE AVAILABLE_DATE > trunc(SYSDATE) and AVAILABLE_DATE < trunc(SYSDATE+1) AND TYPE_OF_CONN_INVOLVED=?";

    public static final String GET_PRIORITY_RECORDS = "SELECT TI_REQUEST.VERSION_NUMBER VERSION, CMP_REQUEST.ORDER_ITEM_ID CMP_ID, TI_REQUEST.PROCESS_ID CCR_ID, CMP_REQUEST.TYPE_OF_CONN_INVOLVED REQUEST_TYPE, CMP_REQUEST.REQUEST_URGENCY,TI_REQUEST.PROCESS_ID FROM CMP_REQUEST LEFT JOIN CCR_CMP_XREF CCRXREF on CMP_REQUEST.ORDER_ITEM_ID = CCRXREF.CMP_ORDER_ITEM_ID LEFT JOIN "
            + "TI_REQUEST ON CCRXREF.TI_REQUEST_ID = TI_REQUEST.ID WHERE AVAILABLE_DATE > trunc(SYSDATE) and AVAILABLE_DATE < trunc(SYSDATE+1) AND REQUEST_URGENCY=?";

    public static final String GET_PC_PROVIDE_RECORDS = "SELECT TI_REQUEST.VERSION_NUMBER VERSION, TI_REQUEST.PROCESS_ID CCR_ID, TI_TASK_TYPE.TASK STATUS FROM TI_ACTIVITY_TRAIL  JOIN TI_TASK_TYPE ON TI_ACTIVITY_TRAIL.ACTIVITY_ID = TI_TASK_TYPE.ID  JOIN TI_REQUEST ON TI_ACTIVITY_TRAIL.TI_REQUEST_ID = TI_REQUEST.ID WHERE TI_ACTIVITY_TRAIL.ACTIVITY_STATUS = 'SCHEDULED' AND "
            + "TI_ACTIVITY_TRAIL.ACTIVITY_ID = (SELECT ID FROM TI_TASK_TYPE WHERE TI_TASK_TYPE.TASK_CODE = 'pro_inf')  AND TI_ACTIVITY_TRAIL.ACTIVITY_STARTDATE > TRUNC(SYSDATE) AND TI_ACTIVITY_TRAIL.ACTIVITY_STARTDATE < TRUNC(SYSDATE+1)";

    public static final String GET_REJECTED_RECORDS = "SELECT TI_REQUEST.VERSION_NUMBER VERSION, TI_REQUEST.PROCESS_ID CCR_ID, TI_ACTIVITY_TRAIL.ACTIVITY_STATUS STATUS FROM TI_ACTIVITY_TRAIL  JOIN TI_REQUEST ON TI_ACTIVITY_TRAIL.TI_REQUEST_ID = TI_REQUEST.ID WHERE TI_ACTIVITY_TRAIL.ACTIVITY_STATUS = 'REJECTED'  "
            + "AND (TI_ACTIVITY_TRAIL.ACTIVITY_ENDDATE > trunc(sysdate) AND TI_ACTIVITY_TRAIL.ACTIVITY_ENDDATE < trunc(sysdate+1))";

    public static final String GET_COGNOS_URL="SELECT KEY_VALUE FROM SERVER_CONSTANTS WHERE KEY_NAME='COGNOS_URL' AND KEY_ENV=(select KEY_VALUE from SERVER_CONSTANTS where KEY_NAME= 'ENVIRONMENT')";
    public static final String UPDATE_COMPLETED_STATUS_AWAITING_PAF_FAF_VERIFY = " UPDATE TI_ACTIVITY_TRAIL SET ACTIVITY_ENDDATE = SYSDATE, ACTIVITY_STATUS = 'COMPLETED' WHERE ID IN (SELECT ACTTRIAL.ID FROM TI_ACTIVITY_TRAIL ACTTRIAL, TI_TASK_TYPE TTT WHERE ACTTRIAL.ACTIVITY_ID = TTT.ID AND ACTTRIAL.ACTIVITY_STATUS = 'STARTED' AND TTT.TASK_CODE = ? AND ACTTRIAL.CMP_ID = ? AND ACTTRIAL.TI_REQUEST_ID = ? ) ";

    public static final String UPDATE_COMPLETED_STATUS_RESP = " UPDATE TI_ACTIVITY_TRAIL SET ACTIVITY_ENDDATE = SYSDATE, ACTIVITY_STATUS = 'COMPLETED' WHERE ID IN (SELECT ACTTRIAL.ID FROM TI_ACTIVITY_TRAIL ACTTRIAL, TI_TASK_TYPE TTT WHERE ACTTRIAL.ACTIVITY_ID = TTT.ID AND ACTTRIAL.ACTIVITY_STATUS = 'STARTED' AND TTT.TASK_CODE = ? AND ACTTRIAL.CMP_ID = ? ) ";

    public static final String UPDATE_COMPLETED_STATUS_ON_HOLD_OR_CANCEL_CMP = " UPDATE TI_ACTIVITY_TRAIL SET ACTIVITY_ENDDATE = SYSDATE, ACTIVITY_STATUS = 'COMPLETED' WHERE ID IN (SELECT ACTTRIAL.ID FROM TI_ACTIVITY_TRAIL ACTTRIAL, TI_TASK_TYPE TTT WHERE ACTTRIAL.ACTIVITY_ID = TTT.ID AND ACTTRIAL.ACTIVITY_STATUS = 'STARTED' AND ACTTRIAL.CMP_ID = ? ) ";

    public static final String UPDATE_COMPLETED_STATUS_ON_HOLD_RELEASED = " UPDATE TI_ACTIVITY_TRAIL SET ACTIVITY_ENDDATE = SYSDATE, ACTIVITY_STATUS = 'COMPLETED' WHERE ID IN (SELECT ACTTRIAL.ID FROM TI_ACTIVITY_TRAIL ACTTRIAL WHERE ACTTRIAL.ACTIVITY_STATUS = 'STARTED' AND ACTTRIAL.ACTIVITY_ID IN (SELECT ID FROM TI_TASK_TYPE TT WHERE UPPER(TT.TASK_CODE) = 'REQ_ON_HOLD') AND ACTTRIAL.CMP_ID = ?) ";

    public static final String UPDATE_COMPLETED_STATUS_OTHER_ACTIVITIES = " UPDATE TI_ACTIVITY_TRAIL SET ACTIVITY_ENDDATE = SYSDATE, ACTIVITY_STATUS = 'COMPLETED' WHERE ID IN (SELECT ACTTRIAL.ID FROM TI_ACTIVITY_TRAIL ACTTRIAL WHERE ACTTRIAL.ACTIVITY_STATUS = 'STARTED' AND ACTTRIAL.ACTIVITY_ID NOT IN (SELECT ID FROM TI_TASK_TYPE TT WHERE UPPER(TT.TASK_CODE) IN ('AWAITING_ADDITIONAL_INFO', 'AWAITING_PAF_FAF_VERIFY','AWAITING_ASSIST_TERM_LOG','AWAITING_ADDITIONAL_INFO_ASSIGN','CMP_REASSIGN_USER','CMP_ASSIGN_USER', 'AWAITING_ADDITIONAL_INFO_RESP','AWAITING_PAF_FAF_VERIFY_RESP','AWAITING_ASSIST_TERM_LOG_RESP','AWAITING_ADDITIONAL_INFO_ASSIGN_RESP','BUS_JUS_ECM_START','REQ_ON_HOLD')) AND ACTTRIAL.CMP_ID = ?)  ";

    public static final String INSERT_CMP_CANCEL_REQUEST = " INSERT INTO C3PAR.TI_ACTIVITY_TRAIL (ID,ACTIVITY_ID,ACTIVITY_TYPE,ACTIVITY_STATUS,USER_ID,ACTIVITY_STARTDATE,ACTIVITY_ENDDATE,ACTIVITY_MODE,CMP_ID) VALUES (C3PAR.SEQ_TI_ACTIVITY_TRAIL.NEXTVAL,(SELECT ID FROM C3PAR.TI_TASK_TYPE WHERE TASK_CODE = ?),(SELECT TASK FROM C3PAR.TI_TASK_TYPE WHERE TASK_CODE = ?),?,(SELECT ID FROM C3PAR.C3PAR_USERS WHERE UPPER(SSO_ID) = ?),SYSDATE,SYSDATE,?,?)  ";

    public static final String UPDATE_COMPLETED_CMP_STATUS = " UPDATE CMP_REQUEST SET STATUS='COMPLETED',CLOSED_DATE=SYSDATE WHERE ID=?  ";

    public static final String INSERT_AWAITING_PAF_FAF_VERIFY = " INSERT INTO C3PAR.TI_ACTIVITY_TRAIL (ID,TI_REQUEST_ID,ACTIVITY_ID,ACTIVITY_TYPE,ACTIVITY_STATUS,USER_ID,ACTIVITY_STARTDATE,ACTIVITY_MODE,CMP_ID) VALUES (C3PAR.SEQ_TI_ACTIVITY_TRAIL.NEXTVAL,?,(SELECT ID FROM C3PAR.TI_TASK_TYPE WHERE TASK_CODE = ?),(SELECT TASK FROM C3PAR.TI_TASK_TYPE WHERE TASK_CODE = ?),?,(SELECT ID FROM C3PAR.C3PAR_USERS WHERE UPPER(SSO_ID) = ?),SYSDATE,?,?)  ";
    
    public static final String INSERT_OTHER_ACTIVITIES = " INSERT INTO C3PAR.TI_ACTIVITY_TRAIL (ID,ACTIVITY_ID,ACTIVITY_TYPE,ACTIVITY_STATUS,USER_ID,ACTIVITY_STARTDATE,ACTIVITY_MODE,CMP_ID) VALUES (C3PAR.SEQ_TI_ACTIVITY_TRAIL.NEXTVAL,(SELECT ID FROM C3PAR.TI_TASK_TYPE WHERE TASK_CODE = ?),(SELECT TASK FROM C3PAR.TI_TASK_TYPE WHERE TASK_CODE = ?),?,(SELECT ID FROM C3PAR.C3PAR_USERS WHERE UPPER(SSO_ID) = ?),SYSDATE,?,?)  ";

    public static final String GET_COUNT_AWAITING_PAF_FAF_VERIFY = " SELECT COUNT(*) CNT FROM  TI_ACTIVITY_TRAIL ACT, TI_TASK_TYPE TASK WHERE ACT.ACTIVITY_ID = TASK.ID AND TASK.TASK_TIMER_ACTIVITY = ? AND ACT.ACTIVITY_STATUS = 'STARTED'  AND ACT.CMP_ID = ? AND ACT.TI_REQUEST_ID=? AND EXISTS (SELECT 1 FROM TI_TASK_TYPE TTT WHERE TTT.TASK_TIMER_ACTIVITY = ? AND TTT.TASK_CODE = ?) ";

    public static final String GET_COUNT_OTHER_ACTIVITIES = " SELECT COUNT(*) CNT FROM  TI_ACTIVITY_TRAIL ACT, TI_TASK_TYPE TASK WHERE ACT.ACTIVITY_ID = TASK.ID AND TASK.TASK_TIMER_ACTIVITY = ? AND ACT.ACTIVITY_STATUS = 'STARTED'  AND ACT.CMP_ID = ? AND EXISTS (SELECT 1 FROM TI_TASK_TYPE TTT WHERE TTT.TASK_TIMER_ACTIVITY = ? AND TTT.TASK_CODE = ?) ";

    public static final String IS_TERMINATE_PHASE = "select tir.request_type from TI_REQUEST ti,ti_request_type tir where ti.id = ?  and ti.ti_request_type_id =tir.id";

    public static final String VALIDATE_USERID_FOR_ACV = "VALIDATEUSERIDFORACV";

    public static final String VIEW_DOCUMENT = "SELECT  docc.DOCUMENT_NAME, docc.CONTENT as CONTENT,tidoc.DOC_MIME_TYPE, tidoc.DOC_TYPE FROM  document_content docc,ti_doc_meta_data tidoc,ti_request tireq WHERE docc.id = tidoc.doc_content_id AND tidoc.connection_id = tireq.process_id AND tidoc.doc_type in (:docType) AND tireq.id=:tiRequestId";

    public static final String GET_IDS_OF_7DAYS_ACV_ACT_EXP = "GET_IDS_OF_7DAYS_ACV_ACT_EXP";

    public static final String GET_IDS_OF_30DAYS_ACV_ACT_EXP = "GET_IDS_OF_30DAYS_ACV_ACT_EXP";
    public static final String UPDATE_COMPLETED_STATUS_CMP_RE_OPEN = " UPDATE TI_ACTIVITY_TRAIL SET ACTIVITY_ENDDATE = SYSDATE, ACTIVITY_STATUS = 'COMPLETED' WHERE ID IN (SELECT ACTTRIAL.ID FROM TI_ACTIVITY_TRAIL ACTTRIAL WHERE ACTTRIAL.ACTIVITY_STATUS = 'STARTED' AND ACTTRIAL.ACTIVITY_ID NOT IN (SELECT ID FROM TI_TASK_TYPE TT WHERE UPPER(TT.TASK_CODE) IN ('AWAITING_ADDITIONAL_INFO', 'AWAITING_PAF_FAF_VERIFY','AWAITING_ASSIST_TERM_LOG','AWAITING_ADDITIONAL_INFO_ASSIGN','CMP_REASSIGN_USER','CMP_ASSIGN_USER', 'AWAITING_ADDITIONAL_INFO_RESP','AWAITING_PAF_FAF_VERIFY_RESP','AWAITING_ASSIST_TERM_LOG_RESP','AWAITING_ADDITIONAL_INFO_ASSIGN_RESP','BUS_JUS_ECM_START','REQ_ON_HOLD','AWAITING_ECM_INPUT')) AND ACTTRIAL.CMP_ID = ?)  ";

    public static final String GET_IDS_OF_7DAYS_TEMPAPP_ACT_EXP = "GET_IDS_OF_7DAYS_TEMPAPP_ACT_EXP";

    public static final String GET_IDS_OF_30DAYS_TEMPAPP_ACT_EXP = "GET_IDS_OF_30DAYS_TEMPAPP_ACT_EXP";

    public static final String GET_ID_OF_PROCESS_PRIORITY = "GET_ID_OF_PROCESS_PRIORITY";
    public static final String SLO_BREACH_QUERY = "SLO_BREACH_QUERY";
    public static final String ACCES_FORM_VERIFICATION="ACCES_FORM_VERIFICATION";
    public static final String IS_FIREWALL_AF=" from FafFireflowTicket flowTicket where flowTicket.tiRequest.id =:tiRequestId";
    public static final String IS_GROUP_NAME_EXISTING = "select distinct 'DEST_IP' group_name from con_fw_rule fwrule where fwrule.DEST_IP_GROUP_NAME_ID in (SELECT id FROM ip_group_name WHERE IP_GROUP_NAME =:destGroupName)  union"
            + " select distinct 'SRC_IP' group_name from con_fw_rule fwrule where fwrule.SRC_IP_GROUP_NAME_ID in (SELECT id FROM ip_group_name WHERE IP_GROUP_NAME =:srcGroupName)  union "
            + " select distinct 'PORT' group_name from con_fw_rule fwrule where fwrule.PORT_GROUP_NAME_ID in (SELECT id FROM port_group_name WHERE PORT_GROUP_NAME =:portGroupName) ";

    public static final String IS_GROUP_NAME_BY_RULE_ID = "select distinct 'DEST_IP' group_name from con_fw_rule fwrule where fwrule.DEST_IP_GROUP_NAME_ID in (SELECT id FROM ip_group_name WHERE IP_GROUP_NAME =:destGroupName) and  fwrule.ID != :ruleId union"
            + " select distinct  'SRC_IP' group_name from con_fw_rule fwrule where fwrule.SRC_IP_GROUP_NAME_ID in (SELECT id FROM ip_group_name WHERE IP_GROUP_NAME =:srcGroupName) and  fwrule.ID != :ruleId   union "
            + " select distinct 'PORT' group_name from con_fw_rule fwrule where fwrule.PORT_GROUP_NAME_ID in (SELECT id FROM port_group_name WHERE PORT_GROUP_NAME =:portGroupName) and  fwrule.ID != :ruleId ";
    
    public static final String PORT_GROUP_NAME="from PortsGroupName where portGroupName=:portGroupName";
    public static final String IPs_GROUP_NAME="from IpsGroupName where ipGroupName=:ipGroupName";
    public static final String CHECK_GROUP_NAME="select id from ti_activity_trail where ti_request_id =:tiRequestId and activity_status='SCHEDULED' and activity_id in(select id from ti_task_type where task_code in('bus_jus','otrm_app'))";
    public static final String UPDATE_COMPLETED_STATUS_AWAITING_PC_PROVIDE_INFO = " UPDATE TI_ACTIVITY_TRAIL SET ACTIVITY_ENDDATE = SYSDATE, ACTIVITY_STATUS = 'COMPLETED' WHERE ID IN (SELECT ACTTRIAL.ID FROM TI_ACTIVITY_TRAIL ACTTRIAL, TI_TASK_TYPE TTT WHERE ACTTRIAL.ACTIVITY_ID = TTT.ID AND ACTTRIAL.ACTIVITY_STATUS = 'STARTED' AND TTT.TASK_CODE = ? AND ACTTRIAL.CMP_ID = ? AND ACTTRIAL.TI_REQUEST_ID = ? ) ";

    public static final String INSERT_AWAITING_PC_PROVIDE_INFO = " INSERT INTO C3PAR.TI_ACTIVITY_TRAIL (ID,TI_REQUEST_ID,ACTIVITY_ID,ACTIVITY_TYPE,ACTIVITY_STATUS,USER_ID,ACTIVITY_STARTDATE,ACTIVITY_MODE,CMP_ID) VALUES (C3PAR.SEQ_TI_ACTIVITY_TRAIL.NEXTVAL,?,(SELECT ID FROM C3PAR.TI_TASK_TYPE WHERE TASK_CODE = ?),(SELECT TASK FROM C3PAR.TI_TASK_TYPE WHERE TASK_CODE = ?),?,(SELECT ID FROM C3PAR.C3PAR_USERS WHERE UPPER(SSO_ID) = ?),SYSDATE,?,?)  ";

    public static final String COMPLETE_PC_PRO_ECM_ACTIVITY = " UPDATE TI_ACTIVITY_TRAIL SET ACTIVITY_STATUS = 'COMPLETED', ACTIVITY_ENDDATE = SYSDATE WHERE TI_REQUEST_ID = ? AND ACTIVITY_ID = (SELECT ID FROM TI_TASK_TYPE WHERE TI_TASK_TYPE.TASK_CODE = 'pro_inf_ecm' AND ROWNUM =1) AND ACTIVITY_STATUS = 'STARTED' AND ACTIVITY_ENDDATE IS NULL ";

    public static final String CHECK_PC_PRO_INFO_COMPLETING = " SELECT TI_REQUEST_ID FROM TI_ACTIVITY_TRAIL WHERE ID = ? AND ACTIVITY_ENDDATE IS NULL AND ACTIVITY_ID = (SELECT ID FROM TI_TASK_TYPE WHERE TI_TASK_TYPE.TASK_CODE = 'pro_inf') ";

    public static final String GET_IDS_OF_30DAYS_PRIOR_TEMPAPP_EXP = "GET_IDS_OF_30DAYS_PRIOR_TEMPAPP_EXP";

    public static final String GET_IDS_OF_14DAYS_PRIOR_TEMPAPP_EXP = "GET_IDS_OF_14DAYS_PRIOR_TEMPAPP_EXP";
    public static final String GET_TASKID_OF_ONBEHALFOFUSER = "GET_TASKID_OF_ONBEHALFOFUSER";
    
    public static final String GET_CURRENT_PHASE = "GET_CURRENT_PHASE_QUERY";

    public static final String CHECK_IS_DELETE = "CHECK_IS_DELETE_QUERY";
    public static final String UPDATE_MGR_COMPLETED_CMP_STATUS = "UPDATE CMP_REQUEST SET STATUS='COMPLETED',CLOSED_DATE=SYSDATE,IS_MANAGER_COMPLETED='Y',MANAGER_COMPLETED_REASON=? WHERE ID=?  ";
    public static final String GET_FIREWALL_RULE_APPLICATION = "SELECT APPLICATION_ID FROM CON_FW_RULE_APPLICATION WHERE TI_REQUEST_ID IN (SELECT ID FROM TI_REQUEST WHERE PROCESS_ID = ?) AND IP_ID= ? AND DELETED_TI_REQUEST_ID IS NULL ORDER BY TI_REQUEST_ID DESC";
    public static final String SERVICE_NOW_CHANGE_AND_BY_PASS_FLAG_FOR_IP_REG = "SERVICE_NOW_CHANGE_AND_BY_PASS_FLAG_FOR_IP_REG";
    public static final String SERVICE_NOW_CHANGE_AND_BY_PASS_FLAG = "SERVICE_NOW_CHANGE_AND_BY_PASS_FLAG";
	
    public static final String GET_ACV_PENDING_TASK_COUNT = "GET_ACV_PENDING_TASK_COUNT";

    public static final String ACV_LOG_EXP_DEADLINE_DAYS = "ACV_LOG_EXP_DEADLINE_DAYS";

    public static final String GET_ACV_LOG_SCHEDULED_TASK_COUNT = "GET_ACV_LOG_SCHEDULED_TASK_COUNT";

    public static final String GET_TASKID_FOR_ACV_LOG_ACTIVITY = "GET_TASKID_FOR_ACV_LOG_ACTIVITY";

    public static final String GET_SCHEDULED_PROCESS_IDS = "GET_SCHEDULED_PROCESS_IDS";

    public static final String GET_TASK_DETAILS = "SELECT CTR.ID AS id, CTR.TASK_ID AS taskId, CTR.TI_REQUEST_ID AS tiReqId, CTR.ACTIVITY_NAME AS activityName, CTR.ACTIVITY_STATUS AS activityStatus, CTR.TASK_PARTICIPANT AS taskParticipant, CTR.CONNECTION_ID AS connectionId, CTR.TI_AUDITTRAIL_ID AS auditTrailId, CTR.ACTIVITY_STAGE AS activityStage, CTR.BPM_VERSION AS bpmVersion FROM CCR_TASK_REF CTR JOIN TI_ACTIVITY_TRAIL TAT "
            + "ON TAT.ID = CTR.TI_AUDITTRAIL_ID JOIN TI_TASK_TYPE TTT ON TTT.ID = TAT.ACTIVITY_ID WHERE TTT.TASK IN ('Annual Connectivity Verification','TempApproval Expiration') AND TAT.TI_REQUEST_ID = CTR.TI_REQUEST_ID AND TAT.ACTIVITY_STATUS = 'SCHEDULED' AND TTT.TASK_CODE = :activityCode AND TAT.ACTIVITY_STARTDATE BETWEEN TO_DATE('09-07-2016','DD-MM-YYYY') AND SYSDATE "
            + "AND DECODE(CTR.ACTIVITY_NAME,'ISOAnnualConnectivityVerification','ver_sow','VerifySOW2','ver_sow','tmp_exp') = TTT.TASK_CODE AND CTR.ACTIVITY_STATUS IN ('Ready','Reserved') AND CTR.CONNECTION_ID=:conId ";
    
    public static final String GET_CLOUD_PROVIDERS = "SELECT GL.* FROM GENERIC_LOOKUP GL WHERE  DEFINITION_ID = (SELECT ID FROM GENERIC_LOOKUP_DEFS WHERE UPPER(NAME)='CLOUD_IAAS_CLOUD_PROVIDERS')";
    
    public static final String DUPLICATE_RULES_QUERY = "DUPLICATE_RULES_QUERY";
    
    public static final String GET_CONTACT_DETAIL = "select contact.EMAIL as TOLIST, contact.FIRST_NAME||contact.Last_NAME as NAMELIST from CON_REQ_CIT_RQCON_XREF conxref,citi_contact contact, role rol "
            + "where conxref.REQUEST_ID=:planningId and conxref.citi_contact_id=contact.id and conxref.role_id=rol.id and rol.name in('Business_Owner','BISO') and conxref.primary_contact='Y' and conxref.notify_contact='Y' "
            + "union  select contact.EMAIL as toList, contact.FIRST_NAME||contact.Last_NAME as name  from CON_REQ_CITI_CONTACT_XREF conxref,citi_contact contact, role rol "
            + "where conxref.REQUEST_ID=:planningId and conxref.citi_contact_id=contact.id and conxref.role_id=rol.id and rol.name in('Business_Owner','BISO') and conxref.primary_contact='Y' and conxref.notify_contact='Y'";

    public static final String GET_ACV_SCHEDULED_TASK_COUNT = "GET_ACV_SCHEDULED_TASK_COUNT";
    public static final String SELECT_REQ_TI_DOC_META_DATA_DISPLAY = "SELECT TD.DOC_TYPE FROM TI_DOC_META_DATA TD, TI_REQUEST TR, "
            + "  (SELECT MAX(ID) MID FROM TI_DOC_META_DATA WHERE TI_REQUEST_ID =?  and DOC_CONTENT_ID is not null GROUP BY DOC_TYPE, CONNECTION_ID) A "
            + " WHERE A.MID = TD.ID AND TR.ID = td.ti_request_id and TD.DOC_CONTENT_ID is not null and  TR.PRIORITY_ID in( select id from GENERIC_LOOKUP where value1 in ('BUSCRIT','EMER') )"
            + " union SELECT  TD.DOC_TYPE FROM TI_DOC_META_DATA TD, CMP_DOC_META_DATA CMPDOC,TI_REQUEST TR, "
            + " (SELECT MAX(ID) MID FROM TI_DOC_META_DATA WHERE TI_REQUEST_ID =? GROUP BY DOC_TYPE, CONNECTION_ID) A "
            + " WHERE A.MID = TD.ID AND TR.ID = td.ti_request_id and TD.CMP_META_DATA_ID=CMPDOC.ID and  TR.PRIORITY_ID in( select id from GENERIC_LOOKUP where value1 in ('BUSCRIT','EMER') )";
    
    public static final String PC_PROVIDE_ROLE = "select CC.FIRST_NAME, CC.LAST_NAME, CC.SSO_ID, CC.EMAIL, CR.NAME from CMP_REQUEST_CON_XREF CX join CITI_CONTACT CC on CC.ID = CX.CITI_CONTACT_ID join CMP_ROLE CR on CR.ID = CX.ROLE_ID where CX.CMP_ID = ";
    public static final String PC_PROVIDE_CITI_CONTACT = "SELECT FIRST_NAME,LAST_NAME,EMAIL,PHONE,SSO_ID FROM C3PAR.CITI_CONTACT WHERE UPPER(SSO_ID) = UPPER((SELECT SSO_ID FROM C3PAR.C3PAR_USERS WHERE ID =";
    
    public static final String IS_STARTING_FLAG="SELECT KEY_VALUE  FROM SERVER_CONSTANTS WHERE KEY_NAME =:jobName AND KEY_ENV =(select KEY_VALUE from SERVER_CONSTANTS where KEY_NAME= 'ENVIRONMENT')";
    public static final String GET_QUALITY_PARAMETER_MASTER="from QualityParameterMaster where  parameterName =:paramName";
    public static final String UPDATE_QUALITY_SCORE="update QualityScore set status=:status, resolvedDate=:resolvedDate where id=:id";
    public static final String GET_QUALITY_SCORE="from QualityScore qualityScore where qualityScore.processId=:processId and upper(qualityScore.status)='FOUND' and qualityScore.refId=:refId";
    
    public static final String GET_COUNT_OF_TEMP_APP_IN_PREV_PHASE = "GET_COUNT_OF_TEMP_APP_IN_PREV_PHASE";
    
    public static final String GET_TASK_CODE_OF_PREVIOUS_ACTIVITY = "GET_TASK_CODE_OF_PREVIOUS_ACTIVITY";
    
    public static final String GET_COUNT_OF_GIS_MANDATED_IN_PREV_PHASE = "GET_COUNT_OF_GIS_MANDATED_IN_PREV_PHASE";
    
    public static final String GET_TASK_DETAILS_FOR_ACV_MAIL_APPROVAL = "GET_TASK_DETAILS_FOR_ACV_MAIL_APPROVAL";

    public static final String ACV_MAIL_APPROVAL_COMPLETION_CHECK_QUERY = "ACV_MAIL_APPROVAL_COMPLETION_CHECK_QUERY";
    
    public static final String TI_REQUEST_IDS_OF_ACV = "TI_REQUEST_IDS_OF_ACV";

    public static final String INSERT_ACV_PRO_ACTIVE_COMPLETION_COMMENTS = "INSERT_ACV_PRO_ACTIVE_COMPLETION_COMMENTS";
    
    public static final String CURRENT_CYCLE_TECH_COORDINATOR_DETAILS = "CURRENT_CYCLE_TECH_COORDINATOR_DETAILS";
    
    public static final String ORIGINAL_TECH_COORDINATOR_DETAILS = "ORIGINAL_TECH_COORDINATOR_DETAILS";
    
    public static final String CON_INFO_REQUESTER_TARGETCONTACT = "SELECT SSO_ID FROM CITI_CONTACT WHERE ID = (SELECT CITI_CONTACT_ID FROM CON_REQ_CITI_CONTACT_XREF WHERE ROLE_ID=28 AND REQUEST_ID=(SELECT PLANNING_ID FROM TI_REQUEST_PLANNING_XREF WHERE TI_REQUEST_PLANNING_XREF.TI_REQUEST_ID=(SELECT MAX(ID) FROM TI_REQUEST WHERE TI_REQUEST.PROCESS_ID=?))AND CON_REQ_CITI_CONTACT_XREF.PRIMARY_CONTACT='Y')";
    
    public static final String CON_INFO_REQUESTER_REQCONTACT = "SELECT SSO_ID FROM CITI_CONTACT WHERE ID = (SELECT CITI_CONTACT_ID FROM CON_REQ_CIT_RQCON_XREF WHERE ROLE_ID=28 AND REQUEST_ID=(SELECT PLANNING_ID FROM TI_REQUEST_PLANNING_XREF WHERE TI_REQUEST_PLANNING_XREF.TI_REQUEST_ID=(SELECT MAX(ID) FROM TI_REQUEST WHERE TI_REQUEST.PROCESS_ID=?))AND CON_REQ_CIT_RQCON_XREF.PRIMARY_CONTACT='Y')";
    
    public static final String GET_REQUEST_VALIDATION_DEADLINE = "GET_REQUEST_VALIDATION_DEADLINE";
    
    public static final String GET_REQ_VAL_PENDING_TASK_COUNT = "GET_REQ_VAL_PENDING_TASK_COUNT";
    
    public static final String TASKID_FOR_REQUEST_VALIDATION = "TASKID_FOR_REQUEST_VALIDATION";
    
    public static final String CHECK_CART_DOCUMENT = " SELECT A.ID FROM TI_DOC_META_DATA A,TI_REQUEST B WHERE B.ID=A.TI_REQUEST_ID AND A.DOC_TYPE in('CART Approval') AND A.TI_REQUEST_ID= ? ";
    
    public static final String CHECK_CARTDOCUMENT_LIST = "select NAME from RESOURCETYPE where upper(name) like upper('Cloud%')";
    
    public static final String UPDATE_CMP_ATTACHMENT = "from CmpDocumentContent cmpContent where cmpContent.cmpDocumentMetaData.cmpOrderItemId=:cmpOrderItemId and cmpContent.cmpDocumentMetaData.fileName=:fileName";
    
    public static final String MAIL_ATTACHMENTS = "from TIMailAuditAttachments auditattachments where auditattachments.tiMailAudit.id = ?)";
    
    public static final String MAIL_ATTACHMENT_DETAILS = "from TIMailAuditAttachments auditattachments where auditattachments.id = ?";
    
    public static final String CMP_DOCUMENTS = "select file_name from cmp_doc_meta_data where cmp_order_item_id=:cmpOrderItemId and deleted_flag='N'";
    
    public static final String QUALITY_SCORE_REPORT_QUERY = "QUALITY_SCORE_REPORT_QUERY";
    
    public static final String GET_CSI_DECOMISSIONED_APP_DTLS = "GET_CSI_DECOMISSIONED_APP_DTLS";
    
    public static final String GET_RARE_DTLS = "GET_RARE_DTLS";
    
    public static final String GET_CSI_QUALITY_SCORE="from QualityScore qualityScore where qualityScore.processId=:processId and upper(qualityScore.status)='FOUND' and qualityScore.refId=:refId and qualityScore.refId2=:refId2";
    public static final String GET_RARE_QUALITY_SCORE="from QualityScore qualityScore where qualityScore.processId=:processId and upper(qualityScore.status)='FOUND' and qualityScore.refId=:refId";
    public static final String FIND_DECOMMISNED_POLICY = "FIND_DECOMMISNED_POLICY";
    public static final String CCR_FW_POLICY_STATUS = "CCR_FW_POLICY_STATUS";
    public static final String FIND_CCR_FTP_RULES = "FIND_CCR_FTP_RULES";
    public static final String CCR_FTP_RULES_STATUS = "CCR_FTP_RULES_STATUS";
    
    public static final String GET_QUALITY_SCORE_DETAILS="from QualityScore qualityScore where qualityScore.processId=:processId and upper(qualityScore.status)='FOUND' and qualityScore.refId=:refId";
    
    public static final String GET_IP_DETAILS_OF_SCHEDULED_ACVS = "GET_IP_DETAILS_OF_SCHEDULED_ACVS";
    
    public static final String GET_EXISTING_IP_DETAILS_OF_SCHEDULED_ACVS = "GET_EXISTING_IP_DETAILS_OF_SCHEDULED_ACVS";
    
    public static final String GET_COUNT_OF_APPID_LINKED_WITH_CCR = "GET_COUNT_OF_APPID_LINKED_WITH_CCR";
    
    public static final String GET_EXISTING_CCRIDS_WITH_DECOMISSIONED_APPIDS = "GET_EXISTING_CCRIDS_WITH_DECOMISSIONED_APPIDS";
    
    public static final String CURRENT_CYCLE_TARGET_TECH_COORDINATOR_DETAILS = "CURRENT_CYCLE_TARGET_TECH_COORDINATOR_DETAILS";
    
    public static final String ORIGINAL_TARGET_TECH_COORDINATOR_DETAILS = "ORIGINAL_TARGET_TECH_COORDINATOR_DETAILS";
    
    public static final String GET_PREVIOUS_ACTIVITY = "GET_PREVIOUS_ACTIVITY";
   
    public static final String GET_IP_DETAILS_FOR_CCR_ID = "GET_IP_DETAILS_FOR_CCR_ID";
   
    public static final String OVERLAP_RULES_QUERY = "OVERLAP_RULES_QUERY";
    public static final String GET_TEMPLATE_CONNECTIONS="GET_TEMPLATE_CONNS";
    public static final String GET_HIS_FIREWALL_RULE="from HistoryFireWallRule hisFirewallRule where hisFirewallRule.tiRequest.id=:tiRequestId";
        
    public static final String UPDATE_FQDN_FOR_NSLOOKUP = "UPDATE_FQDN_FOR_NSLOOKUP";
    
    public static final String DELETE_EXISTING_QUALITY_SCORE = "DELETE_EXISTING_QUALITY_SCORE";
    
    public static final String GET_VALID_TI_REQUEST_IDS_OF_CCRID = "GET_VALID_TI_REQUEST_IDS_OF_CCRID";
    
    public static final String GET_SEC_ACL_TECHNICAL_DETAILS = "GET_SEC_ACL_TECHNICAL_DETAILS";
}
