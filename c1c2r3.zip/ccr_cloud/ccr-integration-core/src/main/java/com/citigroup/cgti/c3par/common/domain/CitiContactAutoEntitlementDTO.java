/**
 * 
 */
package com.citigroup.cgti.c3par.common.domain;

import java.io.Serializable;

/**
 * @author ka58098
 *
 */
public class CitiContactAutoEntitlementDTO implements Serializable{
	private static final long serialVersionUID = 1654584658L;
	private Long planningId;
	private Long processId;
	private Long relationshipId;
	private Long tiRequestId;
	private Long citiContactId;
	private String userSsoId;
	private String firstName;
	private String lastName;
	private String email;
	private String phone;
	private String connectionName;
	private String roleName;
	private String businessJustification;
	private String region;
	private String businessUnit;
	public Long getPlanningId() {
		return planningId;
	}
	public void setPlanningId(Long planningId) {
		this.planningId = planningId;
	}
	public Long getProcessId() {
		return processId;
	}
	public void setProcessId(Long processId) {
		this.processId = processId;
	}
	public Long getRelationshipId() {
		return relationshipId;
	}
	public void setRelationshipId(Long relationshipId) {
		this.relationshipId = relationshipId;
	}
	public Long getTiRequestId() {
		return tiRequestId;
	}
	public void setTiRequestId(Long tiRequestId) {
		this.tiRequestId = tiRequestId;
	}
	public Long getCitiContactId() {
		return citiContactId;
	}
	public void setCitiContactId(Long citiContactId) {
		this.citiContactId = citiContactId;
	}
	public String getUserSsoId() {
		return userSsoId;
	}
	public void setUserSsoId(String userSsoId) {
		this.userSsoId = userSsoId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getConnectionName() {
		return connectionName;
	}
	public void setConnectionName(String connectionName) {
		this.connectionName = connectionName;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public String getBusinessJustification() {
		return businessJustification;
	}
	public void setBusinessJustification(String businessJustification) {
		this.businessJustification = businessJustification;
	}
	public String getRegion() {
		return region;
	}
	public void setRegion(String region) {
		this.region = region;
	}
	public String getBusinessUnit() {
		return businessUnit;
	}
	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}
	
	
}
