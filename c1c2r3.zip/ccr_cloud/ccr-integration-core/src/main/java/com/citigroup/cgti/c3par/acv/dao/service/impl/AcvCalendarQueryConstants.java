package com.citigroup.cgti.c3par.acv.dao.service.impl;


/**
 * @author ky38518
 * 
 */
public interface AcvCalendarQueryConstants {

    public static final String ACV_MONTHLY_PENDING_COUNT = "ACVMONTHLYPENDINGCOUNT";
    public static final String ACV_MONTHLY_SCH_COUNT = "ACVMONTHLYSCHCOUNT";
    public static final String ACV_MONTHLY_CCR_CONNECTIONS = "ACVMONTHLYCCRCONNECTIONS";
    public static final String ACV_YEARLY_CCR_CONNECTIONS = "ACVYEARLYCCRCONNECTIONS";
    public static final String ACV_MIN_YEAR = "ACVMINYEAR";
    public static final String USER_ROLE_DETAILS_FOR_ACV = "USERROLEDETAILSFORACV";
    public static final String UPDATE_AUDIT_DETAILS_FOR_ACV = "UPDATEAUDITDETAILSFORACV";
    public static final String USER_ELIGIBLITY_FOR_ACV = "USERELIGIBLITYFORACV";
    public static final String FETCH_ACV_INSTANCE_ID = "FETCHACVINSTANCEID";
    public static final String ACV_ASSIGNED_ROLE_DETAILS = "ACVASSIGNEDROLEDETAILS";
    public static final String ACV_MONTHLY_CCR_WITH_ROLEID = "ACVMONTHLYCCRWITHROLEID";
    public static final String ACV_ASSIGNEDROLE_DTLS_FOR_YEAR = "ACVASSIGNEDROLEDTLSFORYEAR";
    public static final String ACV_YEARLY_CCR_WITH_ROLEID = "ACVYEARLYCCRWITHROLEID";
    public static final String ASSIGNEDROLE_FOR_ACV_CALENDAR = "ASSIGNEDROLEFORACVCALENDAR";
    public static final String CCR_ENTITLEMENT_CMP_PRODUCT_URL = "CCR_ENTITLEMENT_CMP_PRODUCT_URL";
    public static final String ENVIRONMENT = "ENVIRONMENT";
    public static final String ACTIVE_CONNECTION_CHECK = "ACTIVE_CONNECTION_CHECK";
    public static final String ACV_SCHEDULED_CHECK = "ACV_SCHEDULED_CHECK";

}
