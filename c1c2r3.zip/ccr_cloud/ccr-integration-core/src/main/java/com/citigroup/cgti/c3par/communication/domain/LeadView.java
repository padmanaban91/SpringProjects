/**
 * 
 */
package com.citigroup.cgti.c3par.communication.domain;

import java.util.Date;
import java.util.List;

/**
 * @author pa89021
 *
 */
public class LeadView extends BaseView {

    /**
     * 
     */
    private static final long serialVersionUID = 18764566L;
    private String ecmSector;
    private String region;
    private List<CMPRequestContactXref> cmpRequestContactXrefs;
    private Date availableDate;
    private Long assignedUser;
    private String additionalInformationComment;
    
    /**
     * @return ecmSector
     */
    public String getEcmSector() {
        return ecmSector;
    }

    /**
     * @param ecmSector
     */
    public void setEcmSector(String ecmSector) {
        this.ecmSector = ecmSector;
    }

    /**
     * @return region
     */
    public String getRegion() {
        return region;
    }

    /**
     * @param region
     */
    public void setRegion(String region) {
        this.region = region;
    }

    public List<CMPRequestContactXref> getCmpRequestContactXrefs() {
        return cmpRequestContactXrefs;
    }

    public void setCmpRequestContactXrefs(List<CMPRequestContactXref> cmpRequestContactXrefs) {
        this.cmpRequestContactXrefs = cmpRequestContactXrefs;
    }

    public Date getAvailableDate() {
        return availableDate;
    }

    public void setAvailableDate(Date availableDate) {
        this.availableDate = availableDate;
    }

    public Long getAssignedUser() {
        return assignedUser;
    }

    public void setAssignedUser(Long assignedUser) {
        this.assignedUser = assignedUser;
    }

	public String getAdditionalInformationComment() {
		return additionalInformationComment;
	}

	public void setAdditionalInformationComment(String additionalInformationComment) {
		this.additionalInformationComment = additionalInformationComment;
	}
    
    

}
