package com.citigroup.cgti.c3par.admin.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.common.domain.ProxyDeviceName;
import com.citigroup.cgti.c3par.common.domain.ProxyLocation;
import com.citigroup.cgti.c3par.communication.domain.ECMConstants;
import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

public class ProxyDeviceNameProcess {
	
CCRBeanFactory ccrBeanFactory;
	
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}

	private ProxyDeviceName proxyDeviceName;

    private List<ProxyDeviceName> proxyDeviceNameList;
    
    private List<ProxyLocation> proxyLocationList;
    
    private Long selectedId;
    
    private List<GenericLookup> countries;
    

    public List<GenericLookup> getCountries() {
		return countries;
	}

	public void setCountries(List<GenericLookup> countries) {
		this.countries = countries;
	}

	/**
	 * @return the proxyLocationList
	 */
	public List<ProxyLocation> getProxyLocationList() {
		return proxyLocationList;
	}

	/**
	 * @param proxyLocationList the proxyLocationList to set
	 */
	public void setProxyLocationList(List<ProxyLocation> proxyLocationList) {
		this.proxyLocationList = proxyLocationList;
	}

	/**
	 * @return the selectedId
	 */
	public Long getSelectedId() {
		return selectedId;
	}

	/**
	 * @param selectedId the selectedId to set
	 */
	public void setSelectedId(Long selectedId) {
		this.selectedId = selectedId;
	}

	/**
	 * @return the proxyDeviceName
	 */
	public ProxyDeviceName getProxyDeviceName() {
		return proxyDeviceName;
	}

	/**
	 * @param proxyDeviceName the proxyDeviceName to set
	 */
	public void setProxyDeviceName(ProxyDeviceName proxyDeviceName) {
		this.proxyDeviceName = proxyDeviceName;
	}

	

	/**
	 * @return the proxyDeviceNameList
	 */
	public List<ProxyDeviceName> getProxyDeviceNameList() {
		return proxyDeviceNameList;
	}

	/**
	 * @param proxyDeviceNameList the proxyDeviceNameList to set
	 */
	public void setProxyDeviceNameList(List<ProxyDeviceName> proxyDeviceNameList) {
		this.proxyDeviceNameList = proxyDeviceNameList;
	}

	
    public List<ProxyLocation> getProxyLocations(){
    	return ccrBeanFactory.getResourceTypePersistable().getProxyLocations();
	 }
	
	
    public List<ProxyDeviceName> getProxyDeviceNames() {
    	return ccrBeanFactory.getResourceTypePersistable().getProxyDeviceNames();
	 }
	
	
    public ProxyDeviceName loadProxyDeviceName(Long id) {
    	return ccrBeanFactory.getResourceTypePersistable().loadProxyDeviceName(id);
	 }
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
    public void deleteProxyDeviceName(Long id) {
		ccrBeanFactory.getResourceTypePersistable().deleteProxyDeviceName(id);
	 }
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public boolean updateProxyDeviceName(ProxyDeviceName proxyDeviceName) {
		return ccrBeanFactory.getResourceTypePersistable().updateProxyDeviceName(proxyDeviceName);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public List<GenericLookup> getAllCountries() {
		return ccrBeanFactory.getCommonServicePersistable().getGenericLookupByName(ECMConstants.GENERIC_LOOKUP_COUNTRY);
	}
	
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public List<GenericLookup> getGenericLookupCountryCode(Long id) {
		return ccrBeanFactory.getCommonServicePersistable().getListLookupDataById(id);
	}

}
