/**
 * 
 */
package com.citigroup.cgti.c3par.common.domain;

import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.transform.Transformers;
import org.hibernate.type.LongType;
import org.hibernate.type.StringType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.citigroup.cgti.c3par.bpm.ejb.mailmodule.IMailModule;
import com.citigroup.cgti.c3par.configuation.CCRQueries;

/**
 * @author ka58098
 *
 */
@Service
@Transactional
public class AdminUserEntitlementServiceImpl implements AdminUserEntitlementService {
	private static final Logger LOGGER = Logger.getLogger(AdminUserEntitlementServiceImpl.class);
	@Autowired
	private SessionFactory sessionFactory;
	@Autowired
	private CCRQueries ccrQueries;
	@Autowired
	private IMailModule mailModuleImpl;
	
	private static final String GET_CITI_CONTACT_USER_DETAILS="GET_CITI_CONTACT_USER_DETAILS";
	private static final String PROCESS_ID = "processId";
	private static final String CONNECTION_NAME="connectionName";
	private static final String USER_SSO_ID = "userSsoId";
	private static final String FIRST_NAME = "firstName";
	private static final String LAST_NAME = "lastName";
	private static final String EMAIL = "email";
	private static final String PHONE = "phone";
	private static final String ROLE_NAME="roleName";
	private static final String USER_ID="userId";
	private static final String BUSINESS_JUS="businessJustification";
	private static final String TEMPLATE_ID="SEND_MAIL_HELPDESK_REMOVE_CONTACT";

	@Override
	public void sendMailToHelpdesk(Long userId) {
		Session session = sessionFactory.getCurrentSession();
		SQLQuery sqlQuery = session.createSQLQuery(ccrQueries.getQueryByName(GET_CITI_CONTACT_USER_DETAILS));
		sqlQuery.setLong(USER_ID, userId);
		sqlQuery.addScalar(PROCESS_ID, LongType.INSTANCE);
		sqlQuery.addScalar(CONNECTION_NAME, StringType.INSTANCE);
		sqlQuery.addScalar(USER_SSO_ID, StringType.INSTANCE);
		sqlQuery.addScalar(FIRST_NAME, StringType.INSTANCE);
		sqlQuery.addScalar(LAST_NAME, StringType.INSTANCE);
		sqlQuery.addScalar(EMAIL, StringType.INSTANCE);
		sqlQuery.addScalar(PHONE, StringType.INSTANCE);
		sqlQuery.addScalar(ROLE_NAME, StringType.INSTANCE);
		sqlQuery.addScalar(BUSINESS_JUS, StringType.INSTANCE);
		sqlQuery.setResultTransformer(Transformers.aliasToBean(CitiContactAutoEntitlementDTO.class));
		List<CitiContactAutoEntitlementDTO> resultList=sqlQuery.list();
		if(!CollectionUtils.isEmpty(resultList)){
			mailModuleImpl.sendMailToHelpdesk(TEMPLATE_ID, resultList);
		}
	
	}

}
