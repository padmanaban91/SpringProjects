package com.citigroup.cgti.c3par.connection.domain;

import java.io.Serializable;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.citigroup.cgti.c3par.C3parSessionFactory;
import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.connection.domain.logic.TechnicalArchitectureUtil;
import com.citigroup.cgti.c3par.domain.Relationship;
import com.citigroup.cgti.c3par.domain.ResourceType;
import com.citigroup.cgti.c3par.performer.PerformerFactory;
import com.citigroup.cgti.c3par.performer.dao.PerformerDAO;
import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;
import com.citigroup.cgti.c3par.performer.dao.PerformerUtil;
import com.citigroup.cgti.c3par.performer.util.PerformerConnection;
import com.citigroup.cgti.c3par.performer.util.PerformerException;
import com.citigroup.cgti.c3par.performer.util.PerformerFilter;
import com.citigroup.cgti.c3par.util.C3parStaticNames;


/**
 * The Class ConnectionProcess.
 */
public class ConnectionProcess extends PerformerPagerDO implements Serializable {

    /** The maintenance request. */
    private ConnectionRequest maintenanceRequest= new ConnectionRequest();

    /** The org connection request. */
    private ConnectionRequest orgConnectionRequest= new ConnectionRequest();

    /** The connection ip xref list. */
    private List connectionIPXrefList= new ArrayList();

    /** The connection ip pair xref list. */
    private List connectionIPPairXrefList= new ArrayList();
    //	02/13/08 to be commented it after implementing 3.3 connectionFWPolicy
    /** The connection firewall xref list. */
    private List connectionFirewallXrefList= new ArrayList();
    // end comment
    /** The connection fw policy xref list. */
    private List connectionFWPolicyXrefList = new ArrayList();

    /** The relationship. */
    private Relationship relationship = new Relationship();	

    /** The requester resource type. */
    private ResourceType requesterResourceType = new ResourceType();

    /** The target resource type. */
    private ResourceType targetResourceType = new ResourceType();

    /** The common pair xref. */
    private ConnectionIPPairXref commonPairXref = new ConnectionIPPairXref();



    /**
     * Instantiates a new connection process.
     */
    public ConnectionProcess() {
	addToNonPersistanceList("maintenanceRequest");
	addToNonPersistanceList("orgConnectionRequest");
	addToNonPersistanceList("commonPairXref");

	setTableName("con_req");
	setSequenceName("con_req_seq");
	addToChildList("connectionIPXrefList",new ConnectionIPXref());
	addToChildList("connectionIPPairXrefList",new ConnectionIPPairXref());
	//03/13/08 to be commented it after implementing 3.3 connectionFWPolicy
	addToChildList("connectionFirewallXrefList",new ConnectionFirewallXref());
	//	End Comment 
	addToChildList("connectionFWPolicyXrefList",new ConnectionFWPolicyXref());
	addToDBMapping("relationship","RELATIONSHIP_ID",1);
	addToDBMapping("requesterResourceType","SOURCE_RESOURCE_TYPE",2);
	addToDBMapping("targetResourceType","TARGET_RESOURCE_TYPE",3); 

    }

    /**
     * Gets the relationship.
     *
     * @return the relationship
     */
    public Relationship getRelationship() {
	return relationship;
    }


    /**
     * Sets the relationship.
     *
     * @param relationship the new relationship
     */
    public void setRelationship(Relationship relationship) {
	this.relationship = relationship;
    }

    /**
     * Gets the maintenance request.
     *
     * @return the maintenance request
     */
    public ConnectionRequest getMaintenanceRequest() {
	return maintenanceRequest;
    }

    /**
     * Sets the maintenance request.
     *
     * @param connectionRequest the new maintenance request
     */
    public void setMaintenanceRequest(ConnectionRequest connectionRequest) {
	this.maintenanceRequest = connectionRequest;
    }

    /**
     * Gets the connection firewall xref list.
     *
     * @return the connection firewall xref list
     */
    public List getConnectionFirewallXrefList() {
	return connectionFirewallXrefList;
    }

    /**
     * Sets the connection firewall xref list.
     *
     * @param connectionFirewallList the new connection firewall xref list
     */
    public void setConnectionFirewallXrefList(List connectionFirewallList) {
	this.connectionFirewallXrefList = connectionFirewallList;
    }

    /**
     * Gets the org connection request.
     *
     * @return the org connection request
     */
    public ConnectionRequest getOrgConnectionRequest() {
	return orgConnectionRequest;
    }

    /**
     * Sets the org connection request.
     *
     * @param orgConnectionRequest the new org connection request
     */
    public void setOrgConnectionRequest(ConnectionRequest orgConnectionRequest) {
	this.orgConnectionRequest = orgConnectionRequest;
    }

    /**
     * Gets the connection ip xref list.
     *
     * @return the connection ip xref list
     */
    public List getConnectionIPXrefList() {
	return connectionIPXrefList;
    }

    /**
     * Sets the connection ip xref list.
     *
     * @param connectionIPXrefList the new connection ip xref list
     */
    public void setConnectionIPXrefList(List connectionIPXrefList) {
	this.connectionIPXrefList = connectionIPXrefList;
    }

    /**
     * Gets the connection ip pair xref list.
     *
     * @return the connection ip pair xref list
     */
    public List getConnectionIPPairXrefList() {
	return connectionIPPairXrefList;
    }

    /**
     * Sets the connection ip pair xref list.
     *
     * @param connectionIPPairXrefList the new connection ip pair xref list
     */
    public void setConnectionIPPairXrefList(List connectionIPPairXrefList) {
	this.connectionIPPairXrefList = connectionIPPairXrefList;
    }


    /**
     * Gets the requester resource type.
     *
     * @return Returns the requesterResourceType.
     */
    public ResourceType getRequesterResourceType() {
	return requesterResourceType;
    }

    /**
     * Sets the requester resource type.
     *
     * @param requesterResourceType The requesterResourceType to set.
     */
    public void setRequesterResourceType(ResourceType requesterResourceType) {
	this.requesterResourceType = requesterResourceType;
    }

    /**
     * Gets the target resource type.
     *
     * @return Returns the targetResourceType.
     */
    public ResourceType getTargetResourceType() {
	return targetResourceType;
    }

    /**
     * Sets the target resource type.
     *
     * @param targetResourceType The targetResourceType to set.
     */
    public void setTargetResourceType(ResourceType targetResourceType) {
	this.targetResourceType = targetResourceType;
    }
    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.performer.pager.PerformerPager#next(java.lang.String, int, java.util.List)
     */
    public List next(String attribute, int pageSize, List filters)
    throws PerformerException {
	if(attribute.equals("connectionPortXrefList")){
	    throw new ApplicationException("Invalid Request");
	}else{
	    return super.next(attribute, pageSize, filters);
	}

    }


    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.performer.pager.PerformerPager#flush(java.lang.String)
     */
    public void flush(String attribute) throws PerformerException {
	if(attribute.equals("connectionPortXrefList")){
	    //((ConnectionIPPairXref)this.getConnectionIPPairXrefList().get(0)).flush("connectionPortXrefList");
	    commonPairXref = new ConnectionIPPairXref();
	}else{
	    super.flush(attribute);
	}
    }

    /**
     * Previous pair list on ostia page.
     *
     * @param pageSize the page size
     * @return the list
     * @throws PerformerException the performer exception
     */
    public List previousPairListOnOstiaPage(int pageSize)	throws PerformerException {
	//		if(!attribute.equals("connectionIPPairXrefList")){
	//			return super.previous(attribute, pageSize);
	//		
	//		}else{
	Connection connection = null;
	PerformerDAO dao = null;
	try {
	    PerformerConnection performerConnection = C3parSessionFactory.getPerformerSession();
	    connection = performerConnection.obtainConnection();
	    dao = PerformerFactory.getPerformer(performerConnection);
	}catch (Exception e) {
	    e.printStackTrace();
	    throw new ApplicationException("Error while creating PerformerConnection");
	} finally {
	    try {
		if (connection != null) connection.close();
	    }catch(Exception e) {
		e.printStackTrace();
	    }
	}
	List allData = super.previous("connectionIPPairXrefList", pageSize);

	List allIpPairIds = new ArrayList();
	if(allData!=null && allData.size()>0){
	    Iterator iter = allData.iterator();
	    while (iter.hasNext()) {
		ConnectionIPPairXref connectionIPPairXref = (ConnectionIPPairXref) iter.next();
		allIpPairIds.add(connectionIPPairXref.getConnectionIPPairMaster().getId());
	    }
	    List data = TechnicalArchitectureUtil.checkPairStatus(allIpPairIds, dao);


	    Iterator iterAllData = allData.iterator();
	    while (iterAllData.hasNext()) {
		ConnectionIPPairXref connectionIPPairXref = (ConnectionIPPairXref) iterAllData.next();
		connectionIPPairXref.setStatus("COMPLETE");
		if(data.contains(connectionIPPairXref.getConnectionIPPairMaster().getId())){	
		    connectionIPPairXref.setStatus("INCOMPLETE");
		}
	    }
	    return allData;
	}else{
	    return null;
	}
	//		}

    }

    /**
     * Previous pair list on ostia page.
     *
     * @param pageSize the page size
     * @param ipPairOstiaFilters the ip pair ostia filters
     * @return the list
     * @throws PerformerException the performer exception
     */
    public List previousPairListOnOstiaPage(int pageSize,List ipPairOstiaFilters)	throws PerformerException {

	Connection connection = null;
	PerformerDAO dao = null;
	HashMap hspFilters = new HashMap() ;
	String ipPairAddress = "";
	String ipPairStatus = "" ;
	try {
	    PerformerConnection performerConnection = C3parSessionFactory.getPerformerSession();
	    connection = performerConnection.obtainConnection();
	    dao = PerformerFactory.getPerformer(performerConnection);
	}catch (Exception e) {
	    e.printStackTrace();
	    throw new ApplicationException("Error while creating PerformerConnection");
	} finally {
	    try {
		if (connection != null) connection.close();
	    }catch(Exception e) {
		e.printStackTrace();
	    }
	}


	if (ipPairOstiaFilters != null){
	    int SIZE = ipPairOstiaFilters.size() ;
	    for (int i=0;i<SIZE;i++){
		hspFilters= (HashMap)ipPairOstiaFilters.get(i);
		if (hspFilters.containsKey("FILTER_IPPAIR")){
		    ipPairAddress=(String)hspFilters.get("FILTER_IPPAIR");
		}
		if (hspFilters.containsKey("FILTER_IPPAIR_STATUS")){
		    ipPairStatus=(String)hspFilters.get("FILTER_IPPAIR_STATUS");
		}
	    }
	}

	StringBuffer sbQry = new StringBuffer();
	sbQry.append("FROM CON_IP_PAIR_XREF, CON_PORT_XREF, CON_RISKPORT_OSTIA,CON_IP_PAIR_MASTER ");
	sbQry.append(" WHERE ");
	sbQry.append(" (CON_RISKPORT_OSTIA.PORT_ID = CON_PORT_XREF.PORT_ID) ");
	sbQry.append(" AND (CON_PORT_XREF.IP_PAIR_XREF_ID = CON_IP_PAIR_XREF.ID) ");
	sbQry.append(" AND (CON_IP_PAIR_MASTER.ID = CON_IP_PAIR_XREF.IP_PAIR_ID)");

	if (ipPairAddress != null && !"".equalsIgnoreCase(ipPairAddress)){
	    sbQry.append(" AND CON_IP_PAIR_MASTER.DISPLAY_TEXT LIKE '");
	    sbQry.append(getFilterText(ipPairAddress));
	    sbQry.append("'");
	}
	if (ipPairStatus != null && !"".equalsIgnoreCase(ipPairStatus) && !"--Select--".equalsIgnoreCase(ipPairStatus)){
	    sbQry.append(" AND ( CON_IP_PAIR_XREF.STATUS LIKE '");
	    sbQry.append(ipPairStatus);
	    sbQry.append("' ) ");
	}

	List allData = super.previous("connectionIPPairXrefList", pageSize, true, sbQry.toString(), false, false);

	if(allData!=null && allData.size()>0){
	    return allData;
	}else{
	    return null;
	}
    }

    /**
     * Next pair list on ostia page.
     *
     * @param pageSize the page size
     * @return the list
     * @throws PerformerException the performer exception
     */
    public List nextPairListOnOstiaPage(int pageSize)	throws PerformerException {
	//		if(!attribute.equals("connectionIPPairXrefList")){
	//			return super.next(attribute, pageSize);
	//		
	//		}else{
	Connection connection = null;
	PerformerDAO dao = null;
	try {
	    PerformerConnection performerConnection = C3parSessionFactory.getPerformerSession();
	    connection = performerConnection.obtainConnection();
	    dao = PerformerFactory.getPerformer(performerConnection);
	}catch (Exception e) {
	    e.printStackTrace();
	    throw new ApplicationException("Error while creating PerformerConnection");
	} finally {
	    try {
		if (connection != null) connection.close();
	    }catch(Exception e) {
		e.printStackTrace();
	    }
	}
	String sql = " FROM con_ip_pair_xref, con_port_xref, con_riskport_ostia " +
	"WHERE con_riskport_ostia.port_id = con_port_xref.port_id AND " +
	"con_port_xref.ip_pair_xref_id = con_ip_pair_xref.id ";

	List allData = super.next("connectionIPPairXrefList", pageSize, true, sql, false, false);
	List pairWithRiskPort = new ArrayList();
	List newData = new ArrayList();
	List allIpPairIds = new ArrayList();
	Iterator iter = null;
	if(allData!=null && allData.size()>0){
	    //				iter = allData.iterator();
	    //				while (iter.hasNext()) {
	    //					ConnectionIPPairXref connectionIPPairXref = (ConnectionIPPairXref) iter.next();
	    //					if(TechnicalArchitectureUtil.doesPairHaveRiskPort(connectionIPPairXref, dao)){
	    //						pairWithRiskPort.add(connectionIPPairXref);
	    ////						allIpPairIds.add(connectionIPPairXref.getConnectionIPPairMaster().getId());
	    //					}
	    //				}
	    //				
	    ////				if(pairWithRiskPort.size()<pageSize){
	    ////					newData = nextPairListOnOstiaPage(pageSize-pairWithRiskPort.size());
	    ////				}
	    //					
	    //				if(newData!=null && newData.size()>0){
	    //					iter = newData.iterator();
	    //					while (iter.hasNext()) {
	    //						ConnectionIPPairXref connectionIPPairXref = (ConnectionIPPairXref) iter.next();
	    //						if(TechnicalArchitectureUtil.doesPairHaveRiskPort(connectionIPPairXref.getConnectionPortXrefList())){
	    //							pairWithRiskPort.add(connectionIPPairXref);
	    ////							allIpPairIds.add(connectionIPPairXref.getConnectionIPPairMaster().getId());
	    //						}
	    //					}
	    //				}
	    //				
	    //				if(pairWithRiskPort!=null && pairWithRiskPort.size()>0){
	    //					iter = pairWithRiskPort.iterator();
	    //					while (iter.hasNext()) {
	    //						ConnectionIPPairXref connectionIPPairXref = (ConnectionIPPairXref) iter.next();
	    //						allIpPairIds.add(connectionIPPairXref.getConnectionIPPairMaster().getId());
	    //					}
	    //				}
	    //				
	    //				List data = TechnicalArchitectureUtil.checkPairStatus(allIpPairIds, dao);
	    //				
	    //				
	    //				Iterator iterAllData = pairWithRiskPort.iterator();
	    //				while (iterAllData.hasNext()) {
	    //					ConnectionIPPairXref connectionIPPairXref = (ConnectionIPPairXref) iterAllData.next();
	    //					connectionIPPairXref.setStatus("COMPLETE");
	    //					if(data.contains(connectionIPPairXref.getConnectionIPPairMaster().getId())){	
	    //						connectionIPPairXref.setStatus("INCOMPLETE");
	    //					}
	    //				}
	    //				return pairWithRiskPort;
	    return allData;
	}else{
	    return null;
	}
	//		}

    }

    /**
     * Next pair list on ostia page.
     *
     * @param pageSize the page size
     * @param ipPairOstiaFilters the ip pair ostia filters
     * @return the list
     * @throws PerformerException the performer exception
     */
    public List nextPairListOnOstiaPage(int pageSize,List ipPairOstiaFilters)	throws PerformerException {

	Connection connection = null;
	PerformerDAO dao = null;
	HashMap hspFilters = new HashMap() ;
	String ipPairAddress = "";
	String ipPairStatus = "" ;
	try {
	    PerformerConnection performerConnection = C3parSessionFactory.getPerformerSession();
	    connection = performerConnection.obtainConnection();
	    dao = PerformerFactory.getPerformer(performerConnection);
	}catch (Exception e) {
	    e.printStackTrace();
	    throw new ApplicationException("Error while creating PerformerConnection");
	} finally {
	    try {
		if (connection != null) connection.close();
	    }catch(Exception e) {
		e.printStackTrace();
	    }
	}

	if (ipPairOstiaFilters != null){
	    int SIZE = ipPairOstiaFilters.size() ;
	    for (int i=0;i<SIZE;i++){
		hspFilters= (HashMap)ipPairOstiaFilters.get(i);
		if (hspFilters.containsKey("FILTER_IPPAIR")){
		    ipPairAddress=(String)hspFilters.get("FILTER_IPPAIR");
		}
		if (hspFilters.containsKey("FILTER_IPPAIR_STATUS")){
		    ipPairStatus=(String)hspFilters.get("FILTER_IPPAIR_STATUS");
		}
	    }
	}

	StringBuffer sbQry = new StringBuffer();
	sbQry.append("FROM CON_IP_PAIR_XREF, CON_PORT_XREF, CON_RISKPORT_OSTIA,CON_IP_PAIR_MASTER ");
	sbQry.append(" WHERE ");
	sbQry.append(" (CON_RISKPORT_OSTIA.PORT_ID = CON_PORT_XREF.PORT_ID) ");
	sbQry.append(" AND (CON_PORT_XREF.IP_PAIR_XREF_ID = CON_IP_PAIR_XREF.ID) ");
	sbQry.append(" AND (CON_IP_PAIR_MASTER.ID = CON_IP_PAIR_XREF.IP_PAIR_ID)");

	if (ipPairAddress != null && !"".equalsIgnoreCase(ipPairAddress)){
	    sbQry.append(" AND CON_IP_PAIR_MASTER.DISPLAY_TEXT LIKE '");
	    sbQry.append(getFilterText(ipPairAddress));
	    sbQry.append("'");
	}
	if (ipPairStatus != null && !"".equalsIgnoreCase(ipPairStatus) && !"--Select--".equalsIgnoreCase(ipPairStatus)){
	    sbQry.append(" AND ( CON_IP_PAIR_XREF.STATUS LIKE '");
	    sbQry.append(ipPairStatus);
	    sbQry.append("' ) ");
	}

	List allData = super.next("connectionIPPairXrefList", pageSize, true, sbQry.toString(), false, false);

	if(allData!=null && allData.size()>0){
	    return allData;
	}else{
	    return null;
	}
    }

    /**
     * Next.
     *
     * @param attribute the attribute
     * @param pageSize the page size
     * @param pairFilters the pair filters
     * @param filtersMap the filters map
     * @param areYouOnOstiaPage the are you on ostia page
     * @return the list
     * @throws PerformerException the performer exception
     */
    public List next(String attribute, int pageSize, Map pairFilters, Map filtersMap, boolean areYouOnOstiaPage) throws PerformerException {
	if(attribute.equals("connectionPortXrefList")){
	    return paginatePort(pageSize, pairFilters, filtersMap, true, areYouOnOstiaPage);
	}else if(attribute.equals("connectionFWRuleXrefList")){
	    return paginateFirewall(pageSize, pairFilters, filtersMap, true);
	}else{
	    return null;
	}
    }


    /**
     * Previous.
     *
     * @param attribute the attribute
     * @param pageSize the page size
     * @param pairFilters the pair filters
     * @param filterMap the filter map
     * @param areYouOnOstiaPage the are you on ostia page
     * @return the list
     * @throws PerformerException the performer exception
     */
    public List previous(String attribute, int pageSize, Map pairFilters, Map filterMap, boolean areYouOnOstiaPage) throws PerformerException {
	if(attribute.equals("connectionPortXrefList")){
	    return paginatePort(pageSize, pairFilters, filterMap, false, areYouOnOstiaPage);
	}else if(attribute.equals("connectionFWRuleXrefList")){

	    return paginateFirewall(pageSize, pairFilters, filterMap, false);
	}else{
	    return null;
	}
    }

    /**
     * Paginate port.
     *
     * @param pageSize the page size
     * @param pairFilters the pair filters
     * @param portFiltersMap the port filters map
     * @param isNext the is next
     * @param areYouOnOstiaPage the are you on ostia page
     * @return the list
     * @throws PerformerException the performer exception
     */
    private List paginatePort(int pageSize, Map pairFilters, Map portFiltersMap, boolean isNext, boolean areYouOnOstiaPage) throws PerformerException {
	StringBuffer sql = null;

	if(areYouOnOstiaPage){
	    sql = new StringBuffer(TechnicalArchitectureUtil.getCommonPortsQueryStringOnOstiaPage(this,  pairFilters,portFiltersMap));
	}else{
	    sql = new StringBuffer(TechnicalArchitectureUtil.getCommonPortsQueryString(this,  pairFilters,portFiltersMap));
	}

	String parentSQL = "SELECT ID FROM CON_IP_PAIR_XREF WHERE CONNECTION_REQUEST_ID = "+this.getId();
	if(isNext){
	    if (areYouOnOstiaPage) {
		return (commonPairXref).nextWithMultipleParent("connectionPortXrefList", pageSize, true, sql.toString(), parentSQL, true);
	    } else {
		return (commonPairXref).nextWithMultipleParent("connectionPortXrefList", pageSize, true, sql.toString(), parentSQL, false);
	    }
	}else{
	    if (areYouOnOstiaPage) {
		return (commonPairXref).previousWithMultipleParent("connectionPortXrefList", pageSize, true, sql.toString(), parentSQL, true);
	    } else {
		return (commonPairXref).previousWithMultipleParent("connectionPortXrefList", pageSize, true, sql.toString(), parentSQL, false);
	    }
	}
    }

    /**
     * Paginate firewall.
     *
     * @param pageSize the page size
     * @param pairFilters the pair filters
     * @param firewallFiltersMap the firewall filters map
     * @param isNext the is next
     * @return the list
     * @throws PerformerException the performer exception
     */
    public List paginateFirewall(int pageSize, Map pairFilters, Map firewallFiltersMap, boolean isNext) throws PerformerException {
	StringBuffer sql = null;

	sql = new StringBuffer(TechnicalArchitectureUtil.getFirewallQueryString(this,  pairFilters,firewallFiltersMap));

	String parentSQL = "SELECT ID FROM CON_IP_PAIR_XREF WHERE CONNECTION_REQUEST_ID = "+this.getId();

	if(isNext){

	    return (commonPairXref).nextWithMultipleParent("connectionFWRuleXrefList", pageSize,true ,sql.toString(), parentSQL, false);

	}else{

	    return (commonPairXref).previousWithMultipleParent("connectionFWRuleXrefList", pageSize,true, sql.toString(), parentSQL, false);

	}
    }






    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.performer.pager.PerformerPager#getRecordCount(java.lang.String, java.util.Map)
     */
    /**
     * Gets the record count.
     *
     * @param attribute the attribute
     * @param areYouOnOstiaPage the are you on ostia page
     * @param pairFiltersMap the pair filters map
     * @param filtersMap the filters map
     * @return the record count
     * @throws PerformerException the performer exception
     */
    public long getRecordCount(String attribute, boolean areYouOnOstiaPage, Map pairFiltersMap, Map filtersMap) throws PerformerException {
	if(attribute.equals("connectionPortXrefList")){

	    StringBuffer sql = new StringBuffer("SELECT COUNT(distinct port_id) ");
	    if(areYouOnOstiaPage){
		sql.append(TechnicalArchitectureUtil.getCommonPortsQueryStringOnOstiaPage(this,  null, filtersMap));
	    }else{
		sql.append(TechnicalArchitectureUtil.getCommonPortsQueryString(this,  null, filtersMap));
	    }
	    return super.getRecordCount(sql.toString());
	}else if(attribute.equals("connectionFWRuleXrefList")) {
	    StringBuffer sql = new StringBuffer("SELECT COUNT(distinct ID) ");
	    sql.append(TechnicalArchitectureUtil.getFirewallQueryString(this,  null, filtersMap));

	    return super.getRecordCount(sql.toString());
	}else{
	    return 0;
	}

    }


    /**
     * Gets the filter text.
     *
     * @param filterText the filter text
     * @return the filter text
     */
    private String getFilterText(String filterText) {
	filterText = filterText.replaceAll("\\*", "%").trim();
	return filterText;
    }

    /**
     * Gets the connection fw policy xref list.
     *
     * @return the connection fw policy xref list
     */
    public List getConnectionFWPolicyXrefList() {
	return connectionFWPolicyXrefList;
    }

    /**
     * Sets the connection fw policy xref list.
     *
     * @param connectionFWPolicyXrefList the new connection fw policy xref list
     */
    public void setConnectionFWPolicyXrefList(List connectionFWPolicyXrefList) {
	this.connectionFWPolicyXrefList = connectionFWPolicyXrefList;
    }

    /**
     * Gets the common pair xref.
     *
     * @return the common pair xref
     */
    public ConnectionIPPairXref getCommonPairXref() {
	return commonPairXref;
    }

    /**
     * Sets the common pair xref.
     *
     * @param commonPairXref the new common pair xref
     */
    public void setCommonPairXref(ConnectionIPPairXref commonPairXref) {
	this.commonPairXref = commonPairXref;
    }




}
