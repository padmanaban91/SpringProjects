package com.citigroup.cgti.c3par.acv.service.impl;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.citi.cgti.c3par.acv.domain.AcvCalendarDTO;
import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.acv.dao.service.AcvCalendarDaoService;
import com.citigroup.cgti.c3par.acv.service.AcvCalendarService;
import com.citigroup.cgti.c3par.bpm.ejb.domain.ActivityDataDTO;
import com.citigroup.cgti.c3par.bpm.ejb.domain.TIProcessDTO;
import com.citigroup.cgti.c3par.bpm.ejb.manageactivity.ManageActivityImpl;
import com.citigroup.cgti.c3par.bpm.ejb.manageprocess.ManageTIProcessImpl;
import com.citigroup.cgti.c3par.businessjustification.domain.BusinessJustificationProcess;
import com.citigroup.cgti.c3par.comments.domain.SubmitActivityProcess;
import com.citigroup.cgti.c3par.comments.domain.TiRequestComments;
import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.persist.comments.SubmitActivityPersistable;
import com.citigroup.cgti.c3par.webtier.helper.Util;
import com.mentisys.bfc.util.DocumentHelper;

/**
 * @author ky38518
 * 
 */
@Service
public class AcvCalendarServiceImpl implements AcvCalendarService {

    private Logger log = Logger.getLogger(this.getClass().getName());

    @Autowired
    private AcvCalendarDaoService acvCalendarDaoService;

    @Autowired
    ManageTIProcessImpl manageTIProcessImpl;

    @Autowired
    ManageActivityImpl manageActivityImpl;

    @Autowired
    Util util_helper;

    @Autowired
    private SubmitActivityPersistable submitActivityPersistable;

    public AcvCalendarDaoService getAcvCalendarDaoService() {
        return acvCalendarDaoService;
    }

    public void setAcvCalendarDaoService(AcvCalendarDaoService acvCalendarDaoService) {
        this.acvCalendarDaoService = acvCalendarDaoService;
    }

    @Override
    public Map<String, Integer> getMonthlyAcvConCntDetails(AcvCalendarDTO acvCalendarDto) throws ApplicationException {
        return acvCalendarDaoService.getMonthlyAcvConCntDetails(acvCalendarDto);
    }

    @Override
    public List<AcvCalendarDTO> getAcvConnectionsMonthlyDetails(AcvCalendarDTO acvCalendarDto)
            throws ApplicationException {
        return acvCalendarDaoService.getAcvConnectionsMonthlyDetails(acvCalendarDto);
    }

    @Override
    public List<AcvCalendarDTO> getAcvConnectionsyearlyDetails(AcvCalendarDTO acvCalendarDto)
            throws ApplicationException {
        return acvCalendarDaoService.getAcvConnectionsyearlyDetails(acvCalendarDto);
    }

    @Override
    public List<String> getAcvYearList() throws ApplicationException {
        // TODO Auto-generated method stub
        return acvCalendarDaoService.getAcvYearList();
    }

    public List<GenericLookup> getACVExtensionOptions() {
        return submitActivityPersistable.getACVExtensionOptions();

    }

    @Override
    public Map<String, String> getAcvInstanceId(Long tiRequestId, String ssoId) throws Exception {
        return acvCalendarDaoService.getAcvInstanceId(tiRequestId, ssoId);
    }

    @Override
    public void updateACVFlag(Long tiRequestId, String sow_number, String instanceId,
            SubmitActivityProcess submitActivityProcess) throws Exception {
        try {
            log.info("updateRoleId : tiRequestId : " + tiRequestId + ", sow_number : " + sow_number + ", instanceId : "
                    + instanceId);
            submitActivityProcess.verifySOWUpdate(tiRequestId, "Y", sow_number);
            manageTIProcessImpl.updateBPMInstanceId(tiRequestId, instanceId);
            log.info("updateACVFlag : Completed");
        } catch (Exception Ex) {
            log.error("Exception Occured in updateACVFlag : " + Ex, Ex);
        }
    }

    @Override
    public void updateACVCalanderComments(Long tiRequestId, String comments, String actualRole, String requesterSOEId,
            SubmitActivityProcess submitActivityProcess) throws Exception {
        TiRequestComments tiReqComments = null;
        TIRequest tiRequest = null;
        try {
            log.info("updateRoleId : tiRequestId : " + tiRequestId + ", comments : " + comments + ", actualRole : "
                    + actualRole + ", requesterSOEId : " + requesterSOEId);
            tiReqComments = new TiRequestComments();
            tiRequest = new TIRequest();
            tiRequest.setId((tiRequestId));
            tiReqComments.setTiRequest(tiRequest);
            tiReqComments.setComments(comments);
            tiReqComments.setRoleName(actualRole);
            tiReqComments.setApproverSoeID(requesterSOEId);
            submitActivityProcess.addComments(tiReqComments, "A", "save");
            log.info("updateACVCalanderComments : Completed");
        } catch (Exception Ex) {
            log.error("Exception Occured in updateACVCalanderComments : " + Ex, Ex);
        }
    }

    @Override
    public void updateRoleId(Long activityTrialId, String actualRole, SubmitActivityProcess submitActivityProcess)
            throws Exception {
        try {
            log.info("updateRoleId : activityTrialId : " + activityTrialId + ", actualRole : " + actualRole);
            util_helper.updateRoleId(activityTrialId, actualRole);
            log.info("updateRoleId : Completed");
        } catch (Exception Ex) {
            log.error("Exception Occured in updateRoleId : " + Ex, Ex);
        }
    }

    @Override
    public long acvProActiveComplete(Long processId, String userId, int extensionValue, String extendedDate)
            throws Exception {
        TIProcessDTO objprocessDTO = null;
        ActivityDataDTO activityDataDto = null;
        ActivityDataDTO activityDataDTO1 = null;
        long tiRequestId = 0;
        long auditTrailId = 0;
        try {
            log.info("acvProActiveComplete : processId : " + processId + ", userId : " + userId);
            objprocessDTO = new TIProcessDTO();
            activityDataDto = new ActivityDataDTO();
            activityDataDto.setActivityCode("ver_sow");
            activityDataDto.setActivityStage(ActivityDataDTO.STAGE_APPROVAL);
            activityDataDto.setActivityType(ActivityDataDTO.TYPE_APPROVAL);
            activityDataDto.setActivityStatus(ActivityDataDTO.STATUS_SCHEDULED);
            activityDataDTO1 = new ActivityDataDTO();
            activityDataDTO1.setActivityCode("Active");
            activityDataDTO1.setActivityStage(ActivityDataDTO.STAGE_APPROVAL);
            activityDataDTO1.setActivityType(ActivityDataDTO.TYPE_APPROVAL);
            activityDataDTO1.setActivityStatus(ActivityDataDTO.STATUS_COMPLETED);
            objprocessDTO.setId(processId);
            tiRequestId = manageTIProcessImpl.createACV(objprocessDTO);
            log.debug("tiRequestId: " + tiRequestId);
            auditTrailId = manageActivityImpl.logActivity(activityDataDto, tiRequestId, null);
            log.debug("auditTrailId: " + auditTrailId);
            manageActivityImpl.completeActivity(auditTrailId, userId, ActivityDataDTO.STATUS_COMPLETED);
            manageActivityImpl.logActivity(activityDataDTO1, tiRequestId, null);
            manageTIProcessImpl.extendExpiration(processId, extensionValue, extendedDate);
            log.info("acvProActiveComplete : Completed");
        } catch (Exception Ex) {
            log.error("Exception Occured in acvProActiveComplete : " + Ex, Ex);
        }
        return tiRequestId;
    }

    @Override
    public boolean isUserEligibleForACV(String ssoId) throws Exception {
        return acvCalendarDaoService.isUserEligibleForACV(ssoId);
    }

    @Override
    public int updateAuditDetails(String ssoId, long tiRequestId) throws Exception {
        return acvCalendarDaoService.updateAuditDetails(ssoId, tiRequestId);
    }

    @Override
    public String getRoleNameForUser(String ssoId) throws Exception {
        return acvCalendarDaoService.getRoleNameForUser(ssoId);
    }

    @Override
    public String getCcrEntitilementCMPProductURL() throws ApplicationException {
        return acvCalendarDaoService.getCcrEntitilementCMPProductURL();

    }
    
    @Override
    public boolean isConnectionActive(long processId) throws Exception {
        return acvCalendarDaoService.isConnectionActive(processId);
    }

    @Override
    public boolean isACVScheduled(long processId) throws Exception {
        return acvCalendarDaoService.isACVScheduled(processId);
    }

	@Override
	public void uploadDocumentForTiRequest(String processId, String tirequestId, MultipartFile file, String userId)
			throws Exception {
		try {
			String docType = "Bulk ACV Approval Evidence Document";
			String activityName = new Util().getCurrentActivitybyTiRequestId(tirequestId, null, null).getActivityName();
			String fileName = file.getOriginalFilename();
			TIRequest tirequest = new BusinessJustificationProcess().getTIRequestDetails(Long.parseLong(tirequestId));
			DocumentHelper.uploadDocumentForTiRequest(docType, processId, tirequestId, activityName, file.getBytes(),
					fileName, file.getContentType(), userId, tirequest.getVersionNumber().intValue());
		} catch (Exception e) {
			log.error("Exception Occured in AcvCalendarServiceImpl.uploadDocumentForTiRequest : " + e, e);
		}
	}

}
