


/** CONFIDENTIAL  AND PROPRIETARY
 * Copyright @ 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is
 * strictly prohibited.
 */

package com.citigroup.cgti.c3par.dao;

import java.io.Serializable;
import java.sql.*;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.model.*;
import com.citigroup.cgti.c3par.dao.lookup.*;
import com.mentisys.model.*;
import com.mentisys.dao.*;
import com.mentisys.dao.query.*;
import com.mentisys.dao.audit.*;


// Reference imports

// Entity name = RelCitiHierXrefDAO
// Table name = RelCitiHierXrefDAO
// Superclass = <none>
// Subclasses = <none>

/**
 * The Class RelationshipDAO.
 */
public class RelCitiHierXrefDAO
extends DatabaseAccessObject
implements Serializable
{

    public RelCitiHierXrefDAO(DatabaseSession session) {
		super(session);
		// TODO Auto-generated constructor stub
	}

	/** The Constant TABLE. */
    public static final String	TABLE = "REL_CITI_HIERARCHY_XREF";

    /** The custom sequence. */
    private String customSequence;

    /** The database sequence. */
    private String databaseSequence;

    /** The log. */
    private static Logger log = Logger.getLogger(RelCitiHierXrefDAO.class);

    /** The Constant ENTITY_NAME. */
    public static final String	ENTITY_NAME = "RelCitiHierXref";

    /** The Constant COLUMN_ID. */
    public static final String	COLUMN_ID = "ID";

    // Column names
    /** The Constant COLUMN_NAME. */
    public static final String	COLUMN_RELATIONSHIP_ID = "RELATIONSHIP_ID";

    /** The Constant COLUMN_PURPOSE. */
    public static final String	COLUMN_CITI_HIERARCHY_MASTER_ID = "CITI_HIERARCHY_MASTER_ID";
    
    private static String SELECT_STMT = "SELECT "  + COLUMN_ID
    + ", " + COLUMN_RELATIONSHIP_ID
    + ", " + COLUMN_CITI_HIERARCHY_MASTER_ID
    + " FROM " + RelCitiHierXrefDAO.TABLE;
    
    private static String SELECT_BY_ID_STMT = RelCitiHierXrefDAO.SELECT_STMT + " WHERE " + COLUMN_ID + " = ?";
    
    
    private static final String SELECT_CITI_HIER_MASTER_IDS_STMT = "SELECT " + CitiHierMasterDAO.COLUMN_ID + " FROM " + CitiHierMasterDAO.TABLE + ","+ RelCitiHierXrefDAO.TABLE + " WHERE " +RelCitiHierXrefDAO.COLUMN_CITI_HIERARCHY_MASTER_ID+ " = " +CitiHierMasterDAO.COLUMN_ID + "AND " +RelCitiHierXrefDAO.COLUMN_CITI_HIERARCHY_MASTER_ID + " = ?";
    
   
    
	@Override
	protected void buildEntity(ResultSet rs, Entity obj)
			throws DatabaseException {
		RelCitiHierXrefEntity entity = (RelCitiHierXrefEntity) obj;
		try
		{
		    // TODO: Figure a better way of dealing with the absence of any attribute
		    dummyExceptionTosser(false);

		    int index = 1;

		    entity.setRelationshipId(getLongFromResultSetIndexed(rs, ++index));
		    entity.setCitiHierarchyMasterId(getLongFromResultSetIndexed(rs, ++index));
		    entity.getCitiHierMasterIds().add(entity.getCitiHierarchyMasterId());

		    obj.setModified(false);
		}
		catch (DatabaseException e)
		{	
			log.error(e,e);
		    throw new DatabaseException("Cannot build database entity object from result set", e);
		}
		
	}
	
	    protected void dummyExceptionTosser(boolean flag) throws DatabaseException
	    {
		if(flag)
		{
		    throw new DatabaseException("This exception should never be thrown....", new Exception("Another dummy"));
		}
	    }
	
	@Override
	protected Entity createEntity(ResultSet rs) throws DatabaseException {
			RelCitiHierXrefEntity entity = null;
			try
			{
				log.debug("changes");
			    // get the ID of the entity we're to create, and check if that is already held in the session. Thereby allowing us to
			    // bypass the creation altogether and reuse the one in existence.			
			    Long _id = getLongFromResultSet(rs, COLUMN_ID);
			    entity = (RelCitiHierXrefEntity) getSession().getObjectFromSession(ENTITY_NAME, _id);
			    if (entity == null)
			    {        
				entity = new RelCitiHierXrefEntity(_id);
				buildEntity(rs, entity);
				getSession().addObjectToSession(entity, ENTITY_NAME, _id);
			    }
			}
			catch (DatabaseException e)
			{
				log.error(e,e);
			    throw new DatabaseException("Cannot create database entity object from result set", e);
			}
			return entity;
	}

	@Override
	protected void loadReferences(Entity obj) throws DatabaseException {
		if (obj.isReferencesLoaded())
		{
		    log.debug("RelCitiHierXrefDAO.loadReferences(): References for RelCitiHierXrefEntity [" + obj.getId() + "] already loaded");
		    return;
		}
		log.debug("RelCitiHierXrefDAO.loadReferences(): Loading references for RelCitiHierXrefEntity [" + obj.getId() + "].");
		obj.setReferencesLoaded(true);
		try
		{
		    RelCitiHierXrefEntity entity = (RelCitiHierXrefEntity)obj;

		   loadCitiHierMasterReferences(entity);

		}
		catch(Exception e)
		{
		    obj.setReferencesLoaded(false);
		    throw new DatabaseException("Failed to load references for RelCitiHierXrefEntity [" + obj.getId() + "].", e);
		}

	}

	@Override
	protected int updateReferences(PreparedStatement arg0, Entity arg1, int arg2)
			throws DatabaseException, SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	protected String getQuerySelectString() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	public RelCitiHierXrefEntity get(Long id, boolean load_refs) throws DatabaseException
    {
	Long id_to_get = id;
	RelCitiHierXrefEntity obj = (RelCitiHierXrefEntity) getSession().getObjectFromSession(ENTITY_NAME, id_to_get);
	log.debug("Getting RelCitiHierXrefEntity with id = " + id_to_get); 
	log.debug("into re hier xref");
	if(obj != null)
	{
	    log.debug(">>> RelCitiHierXrefEntity >>> already LOADED !!!"); 
	}

	if(obj == null)
	{
	    DatabaseSession session = getSession();
	    Connection connection = null;

	    PreparedStatement st = null;
	    ResultSet rs = null;

	    try
	    {
		connection = session.getConnection();
		//				st = session.getPreparedStatement(SELECT_BY_ID_STMT);
		log.debug("query" +SELECT_BY_ID_STMT);
		st = connection.prepareStatement(SELECT_BY_ID_STMT);
		setLongToStatement(st, 1, id_to_get);
		rs = st.executeQuery();
		
	
		if (rs.next())
		{
		    obj = (RelCitiHierXrefEntity) createEntity(rs);
		}
	    }
	    catch (SQLException e)
	    {
	    	log.error(e, e);
		throw new DatabaseException("Could not load " + RelCitiHierXrefDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	    finally
	    {
		closeResultSet(rs);
		closeStatement(st);
		session.releaseConnection();
	    }
	}

	if (obj != null && load_refs)
	{
	    try
	    {
		// Load the associated objects
	    	log.debug("obj is available");
		loadReferences(obj);
		obj.setModified(false);
	    }
	    catch (DatabaseException e)
	    {
	    	log.error(e,e);
		throw new DatabaseException("Failed to load references of " + RelCitiHierXrefDAO.ENTITY_NAME + " with id = " + id_to_get, e);
	    }
	}
	log.debug("DONE Getting RelCitiHierXrefEntity with id = " + id_to_get); 

	return obj;
    }
	
    public void loadCitiHierMasterReferences(RelCitiHierXrefEntity entity) throws DatabaseException
	{
    	loadCitiHierMasterReferences(entity, true); 
	}
    
    protected CitiHierMasterDAO getCitiHierMasterDAO()
    {
    	CitiHierMasterDAO dao = (CitiHierMasterDAO)getSession().getDAO("CitiHierMaster");  
	if(dao == null)
	{
	    dao = new CitiHierMasterDAO(getSession());  		
	    getSession().putDAO("CitiHierMaster", dao);
	}		
	return dao;
    }
    
	 
	public void loadCitiHierMasterReferences(RelCitiHierXrefEntity entity, boolean load_refs) throws DatabaseException
	{
	try
		{
		log.debug("Loading RelCitiHierXref references for RelCitiHierXrefEntity [" + entity.getPrimaryKey() + "].");
		List id_list = entity.getCitiHierMasterIds();
		log.debug("lists" +id_list.size());
		
		// if there's only one, use the single entity get() method. Otherwise use the one that operates of a list
		if(id_list.size() == 1)
		{
			CitiHierMasterDAO dao = getCitiHierMasterDAO();
			entity.setCitiHierMaster((dao.get((Long)id_list.get(0), load_refs)));
		}
		}
		catch(Exception e)
		{
			log.error(e,e);
		    throw new DatabaseException("Failed to load RelCitiHierXref References for RelCitiHierXrefEntity [" + entity.getId() + "].", e);
		}


		//		entity.setEntitlementData(entity_list);
	    }
	
	 public List get(List id_list, boolean load_refs) throws DatabaseException
	    {
		List 	entity_list = new ArrayList(16);
		if(id_list != null && id_list.size() > 0)
		{
		    DatabaseSession 	session = getSession();
		    Connection 			connection = null;
		    Statement 			st = null;
		    ResultSet 			rs = null;
		    RelCitiHierXrefEntity 		entity = null;

		    try
		    {
			StringBuffer statement = new StringBuffer(SELECT_STMT + " WHERE " + COLUMN_ID + " IN (");

			Long only = null;
			long count = 0;
			Iterator iter = id_list.iterator();
			while(iter.hasNext())
			{
			    Long id = (Long)iter.next();
			    entity = (RelCitiHierXrefEntity) getSession().getObjectFromSession(ENTITY_NAME, id);
			    if(entity != null)
			    {
				if(load_refs)
				{
				    loadReferences(entity);
				}
				entity_list.add(entity);
			    }
			    else // add the the id to the statement
			    {
				if(count++ > 0)
				{
				    statement.append(",");					
				}
				statement.append(id.toString());					
				only = id;
			    }
			}

			// check if we need to explicitly load any entities
			if(count == 1)
			{
			    entity_list.add(get(only, load_refs));					
			}
			else if(count > 1)
			{
			    statement.append(")");	// Close the statenemt's IN clause					
			    log.debug("DAO.get(List): executing statement. Count = (" + count + ") --> " + statement.toString());
			    connection = session.getConnection();
			    //					st = connection.prepareStatement(statement.toString());
			    //					rs = st.executeQuery();
			    st = connection.createStatement();
			    rs = st.executeQuery(statement.toString());

			    while(rs.next())
			    {
				entity = (RelCitiHierXrefEntity) createEntity(rs);
				if(load_refs)
				{
				    loadReferences(entity);
				    entity.setModified(false);
				}
				entity_list.add(entity);
			    }
				log.debug("entity listsize"  +entity_list.size());
			}
		    }
		    catch(SQLException e)
		    {
		    	log.error(e,e);
			throw new DatabaseException("Failed to load all entities of type " + RelCitiHierXrefDAO.ENTITY_NAME + ".", e);
		    }
		    finally
		    {
			closeResultSet(rs);
			closeStatement(st);
			if(connection != null)
			{
			    session.releaseConnection();
			}
		    }
		}

		return entity_list;	
	    }
	 
   
}
