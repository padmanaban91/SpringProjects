/**
 * 
 */
package com.citigroup.cgti.c3par.admin.domain;

import java.io.Serializable;
import java.util.Date;

import com.citigroup.cgti.c3par.common.domain.ProxyLocation;

/**
 * @author ka58098
 *
 */
public class ProxyFreeze implements Serializable {

    private static final long serialVersionUID = 6455684651L;

    private Long id;
    private ProxyLocation proxyLocation;
    private Date freezeStartDate;
    private Date freezeEndDate;
    private String comments;
    private Date createdDate;
    private Date updatedDate;
    private String updatedBy;
    private String createdBy;
    private String proxyCountry;
    private String proxyType;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public ProxyLocation getProxyLocation() {
        return proxyLocation;
    }

    public void setProxyLocation(ProxyLocation proxyLocation) {
        this.proxyLocation = proxyLocation;
    }

    public Date getFreezeStartDate() {
        return freezeStartDate;
    }

    public void setFreezeStartDate(Date freezeStartDate) {
        this.freezeStartDate = freezeStartDate;
    }

    public Date getFreezeEndDate() {
        return freezeEndDate;
    }

    public void setFreezeEndDate(Date freezeEndDate) {
        this.freezeEndDate = freezeEndDate;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getProxyCountry() {
        return proxyCountry;
    }

    public void setProxyCountry(String proxyCountry) {
        this.proxyCountry = proxyCountry;
    }

    public String getProxyType() {
        return proxyType;
    }

    public void setProxyType(String proxyType) {
        this.proxyType = proxyType;
    }

}
