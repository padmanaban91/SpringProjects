/**
 * 
 */
package com.citigroup.cgti.c3par.admin.domain.soc.persist;

import java.util.List;

import com.citigroup.cgti.c3par.admin.domain.DoNotSendMailList;
import com.citigroup.cgti.c3par.admin.domain.DonotSendMailProcess;
import com.citigroup.cgti.c3par.persistance.Persistable;


/**
 * @author pc79439
 * 
 */
public interface DonotSendMailServicePersistable extends Persistable {
	
	//get DoNotSendEmailList
	public List<DoNotSendMailList> getDoNotSendEmailList(DonotSendMailProcess donotsendmailprocess);
	//save DoNotSendEmailList 
	public void saveDoNotSendEmailList(String soeId);
	//Delete DoNotSendEmailList
	public void deleteDoNotSendEmailList(List<String> soeId);
	
}
