package com.citigroup.cgti.c3par.ccrcmpmapping.dao.service.impl;

import java.util.Arrays;
import java.util.List;

/**
 * @author ky38518
 * 
 */
public interface CCRCMPMappingConstants {

    public static final String CMP_ORDERITEMID_WITH_SEARCHSTRING = "CMPORDERITEMIDWITHSEARCHSTRING";
    public static final String CMP_ORDERITEMID_SEARCH = "CMPORDERITEMIDSEARCH";
    public static final String CCR_TASK_STATUS = "CCR_TASK_STATUS";
    public static final String[] ACTIVE_ACV_STAUS = { "Active", "ISO Annual Connectivity Verification - Internal",
        "ISO Annual Connectivity Verification - External",
        "TC Annual Connectivity Verification - Internal",
        "PC Annual Connectivity Verification - Internal",
        "BU Annual Connectivity Verification - Internal",
        "Admin Annual Connectivity Verification - Internal",
        "TC Annual Connectivity Verification - External",
        "PC Annual Connectivity Verification - External",
        "BU Annual Connectivity Verification - External",
        "Admin Annual Connectivity Verification - External",
        "Annual Connectivity Verification"
};
    public static final String REJECTED_CCR_STATUS = "Rejected";
    public static final String ABORTED="Aborted";
    public static final String ERR_MSG_INVALID_CCR = "Please enter valid ccr id";
    public static final String ERR_MSG_INVALID_CCR_STATUS = "Please verify CCR details and try again";
    public static final String ERR_MSG_REJECTED_CCR_STATUS = "Warning: The current CCR Id which you linked is rejected one.";
    public static final String ERR_MSG_ABORTED_CCR_STATUS="Warning: The current CCR Id which you linked is aborted one.";
    public static final String CMP_ORDERITEMS_FOR_TI_REQUESTID = "CMPORDERITEMSFORTIREQUESTID";
    public static final String TI_REQUEST_ID = "select id from TI_REQUEST where process_id=:processId and VERSION_NUMBER=:versionNo";
    public static final String GET_COMPLETED_USER_DETAILS = "GETCOMPLETEDUSERDETAILS";
    public static final String GET_CMPID_FOR_MAPPED_CCR = "GETCMPIDFORAMAPPEDCCR";
    public static final String GET_CMP_BLOB_CONTENT_IN_STRING = "GETCMPBLOBCONTENTINSTRING";
    public static final String UPDATE_COMPLETED_STATUS_FOR_CMP = "UPDATECOMPLETEDSTATUSFORCMP";
    public static final String GET_MAPPED_CMPIDS_FOR_CCR = "GETMAPPEDCMPIDSFORCCR";
    public static final String GET_TASKDESCRIPTION_FOR_ACTIVITY = "GETTASKDESCRIPTIONFORACTIVITY";
    public static final String CMP_ORDERITEMID_SEARCH_IN_CLAUSE = "CMPORDERITEMIDSEARCHINCLAUSE";
    public static final String GET_AUDIT_TRIAL = "GETAUDITTRIAL";
    public static final String GET_MAPPEDCMPIDS_FOR_TIREQUESTID = "GETMAPPEDCMPIDSFORTIREQUESTID";
    public static final String INSERT_ECM_ACTIVITYTRAIL = "INSERTECMACTIVITYTRAIL";
    public static final String GET_ACTIVITYTRAIL_FOR_MAPPEDCMPIDS = "GETACTIVITYTRAILFORMAPPEDCMPIDS";
    public static final String COMPLETE_ECM_ACTIVITYTRAIL = "COMPLETEECMACTIVITYTRAIL";
    public static final String CLASSIFICATION = "Classification";
    public static final String CONNECTION_ESTIMATE = "CONNECTION_ESTIMATE";
    public static final String AFFECTED_BUSINESS = "AFFECTED_BUSINESS";
    public static final String CMP_ENTITY = "CMP_ENTITY";
    public static final String REASON_B2B = "REASON_B2B";
    public static final String TIREQUEST_DIRECTOR_APPROVAL_CMP="TIREQUEST_DIRECTOR_APPROVAL_CMP";
    public static final String DIRECTOR_APPROVAL = "Director Approval";
    public static final String DIRECTOR_APPROVAL_RECEIVED="director_approval_received";
    public static final String DIRECTOR_REJECTION_RECEIVED="director_rejection_received";
    public static final String THIRD_PARTY = "3rd Party";
    public static final String NON_THIRD_PARTY = "Non 3rd Party";
    public static final String cmpOnHoldStatus = "CMP Request on Hold";
    public static final String QUICK_SEARCH_BY_CCR = "QUICK_SEARCH_BY_CCR";
    
    //Query to fetch the rejected ccr ids linked to a given cmp . 
    public static final String CCR_REJECTED_IDS_LINKED_TO_CMP = "CCR_REJECTED_IDS_LINKED_TO_CMP";
    public static final String[] MGR_COMPLETE_STATUS = { "Logging Queue", "Terminated", "Aborted", "PC Logging Queue",
            "TC Logging Queue" };
    
    public static final List<String> CMP_ADD_INFORMATION_COLUMN_LIST = Arrays.asList(new String[] { "BUS_JUS",
            "CIT_GRP_DATA", "CUSTOMER_DATA", "CONNECTIVITY_FREQUENCY", "GOC_CODE", "TYPE_OF_ENTITY", "DIRECT_ACCESS",
            "REASON", "URGENCY", "AFFECTED_BUSINESS", "REGION", "SECTOR", "BUSINESS_UNIT", "COMPANY_NAME",
            "TPT_CONTACT_NAME", "CASP_SUPP_ID", "TPT_CONTACT_TYPE", "CASP_DETAIL_ID", "TPT_CONTACT_PHONE",
            "TPT_CONTACT_EMAIL" });
    
    public static final String GET_ECM_REQUEST_INFO = "GET_ECM_REQUEST_INFO";
    
    public static final String UPDATE_USER_COMMENTS="UPDATE_USER_COMMENTS";
    
    public static final String GET_SECTOR_NAME="GET_SECTOR_NAME";
    
    public static final String GET_BUSINESS_UNIT_NAME="GET_BUSINESS_UNIT_NAME";
    public static final String GET_CMPID_FOR_TIREQUESTID = "GET_CMPID_FOR_TIREQUESTID";
    
}
