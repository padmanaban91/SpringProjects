package com.citigroup.cgti.c3par.bpm.ejb.domain;

import java.io.Serializable;


/**
 * The Class LookupDTO.
 */
public class LookupDTO implements Serializable {

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = 5178605931718464988L;

    /** The name. */
    private String name;

    /** The id. */
    private long id;

    /** The status. */
    private String status;

    public LookupDTO (){}
    
    
    public LookupDTO(String name) {
		super();
		this.name = name;
	}

	public LookupDTO( long id,String name,String status) {
		super();
		this.name = name;
		this.id = id;
		this.status = status;
	}


	/**
     * Sets the name.
     *
     * @param name the new name
     */
    public void setName(String name) {
	this.name = name;
    }

    /**
     * Gets the name.
     *
     * @return the name
     */
    public String getName() {
	return this.name;
    }

    /**
     * Sets the value.
     *
     * @param id the new value
     */
    public void setValue(long id) {
	this.id = id;
    }

    /**
     * Gets the value.
     *
     * @return the value
     */
    public long getValue() {
	return this.id;
    }

    /**
     * Gets the status.
     *
     * @return the status
     */
    public String getStatus() {
	return status;
    }

    /**
     * Sets the status.
     *
     * @param status the new status
     */
    public void setStatus(String status) {
	this.status = status;
    }
}
