package com.citigroup.cgti.c3par.dao;


import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.model.ConnectionCitiContactXrefEntity;
import com.citigroup.cgti.c3par.model.ConnectionCitiReqContactXrefEntity;
import com.citigroup.cgti.c3par.model.ConnectionEntity;
import com.citigroup.cgti.c3par.model.ConnectionExtEntity;
import com.citigroup.cgti.c3par.model.ConnectionFacilitiesAffectedXrefEntity;
import com.citigroup.cgti.c3par.model.ConnectionProjectJustificationXrefEntity;
import com.citigroup.cgti.c3par.model.ConnectionRequestExtEntity;
import com.citigroup.cgti.c3par.model.ConnectionResourceXrefEntity;
import com.citigroup.cgti.c3par.model.ConnectionTPContactXrefEntity;
import com.citigroup.cgti.c3par.model.ConnectionTPServiceXrefEntity;
import com.citigroup.cgti.c3par.model.FirewallDetailsEntity;
import com.citigroup.cgti.c3par.model.MaterialBillEntity;
import com.mentisys.dao.DatabaseException;
import com.mentisys.dao.DatabaseSession;
import com.mentisys.dao.audit.AuditArchiver;
import com.mentisys.model.ManyAssociationList;

public class ConnectionExtDAO extends ConnectionDAO
implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	 //======================================================================
    /**
     * Simple factory method.
     *
     * @param session the session
     * @return the connection dao
     */
    public static ConnectionExtDAO createInstance(DatabaseSession session)
    {
	return new ConnectionExtDAO(session);
    }
	
	public ConnectionExtDAO(DatabaseSession session) {
		super(session);
		// TODO Auto-generated constructor stub
	}
	
	public static final String SEQ_CONNECTION_VIRTUAL_CONN_REASON ="SEQ_CONN_VIRTUAL_CONN_REASON";
	
	public static final String VIRTUAL_CONN_REASON = "CONNECTION_VIRTUAL_CONN_REASON";
	
	 /** The Constant COLUMN_ID. */
    public static final String	CON_REQ_ID = "CON_REQ_ID";
    
    public static final String	ID = "ID";
    
    public static final String GENERIC_LOOKUP_ID = "GENERIC_LOOKUP_ID";
	
	/** The Update con_req table */
    private static String INSERT_CONNECTION_VIRTUAL_CONN_REASON_TABLE = "INSERT INTO " +ConnectionExtDAO.VIRTUAL_CONN_REASON
    + "(" + ID 
    + ", " + CON_REQ_ID
    + ", " + GENERIC_LOOKUP_ID
    + ") VALUES (?, ?, ?)";
	
	 public static final String	COLUMN_CONN_FOR_CUST_CLIENT = "CONN_FOR_CUST_CLIENT";
	 public static final String	COLUMN_DIRECT_ACCESSBY_THIRDPRT = "DIRECT_ACCESSBY_THIRDPRT";
     public static final String	COLUMN_CAB_APPR_GRP_CODE = "CAB_APPR_GRP_CODE";
     public static final String	COLUMN_REASON_FOR_VIRTU_CONN = "REASON_FOR_VIRTU_CONN";
     /** The connectivity estimate. */
     public static final String COLUMN_CONN_ESTIMATE="connectivity_estimate";
     public static final String COLUMN_DET_INFORMATION="detailed_information";
   
     public static final String	COLUMN_SEMI_ANNUAL_ENTITL_REVIEW = "SEMI_ANNUAL_ENTITL_REVIEW";
     public static final String	COLUMN_TP_TRAINING_AWARNESS_PRG = "TP_TRAINING_AWARNESS_PRG";
     public static final String	COLUMN_EXPORT_LICENSE_CORDINATOR ="EXPORT_LICENSE_CORDINATOR_NEW";
	
    /** The Update con_req table */
    private static String UPDATE_BY_CONNECTION_TABLE = "UPDATE  "+ConnectionDAO.TABLE+  " SET "
    + " " + COLUMN_CONN_FOR_CUST_CLIENT + " = ? "
    + "," + COLUMN_CAB_APPR_GRP_CODE + " = ? "
    + "," + COLUMN_DIRECT_ACCESSBY_THIRDPRT + " = ? "
    +","+ COLUMN_SEMI_ANNUAL_ENTITL_REVIEW + " = ? "
    +","+ COLUMN_TP_TRAINING_AWARNESS_PRG + " = ? "
    +","+ COLUMN_EXPORT_LICENSE_CORDINATOR + " = ? "
    +","+ COLUMN_CONN_ESTIMATE + " = ? "
    //COLUMN_DET_INFORMATION
    +","+ COLUMN_DET_INFORMATION + " = ? "
    
    + " WHERE " + COLUMN_ID + " = ? ";
    
    /** The SELEC t_ stmt. */
    private static String SELECT_CONNECTION_STMT = "SELECT "  + COLUMN_CONN_FOR_CUST_CLIENT
    +","+ COLUMN_CAB_APPR_GRP_CODE 
    +","+ COLUMN_DIRECT_ACCESSBY_THIRDPRT 
    +","+ COLUMN_SEMI_ANNUAL_ENTITL_REVIEW 
    +","+ COLUMN_TP_TRAINING_AWARNESS_PRG 
    + "," + COLUMN_EXPORT_LICENSE_CORDINATOR 
    + "," + COLUMN_CONN_ESTIMATE
    //COLUMN_DET_INFORMATION
    + "," + COLUMN_DET_INFORMATION
   
    /*+","+ COLUMN_REASON_FOR_VIRTU_CONN */
    /*+","+ COLUMN_CURR_BUS_JUSTFICATION*/
    + " FROM " + ConnectionExtDAO.TABLE;
    
    /** Select Query. */
    private static String SEL_CONNECTION_CONN_FOR_CUST_CLIENT = ConnectionExtDAO.SELECT_CONNECTION_STMT +" WHERE " + COLUMN_ID + " = ? ";
    
    private static String SELECT_CONNECTION_VIRTUAL_CONN_REASON ="SELECT  "+ GENERIC_LOOKUP_ID + " FROM " +VIRTUAL_CONN_REASON 
    +" WHERE "+CON_REQ_ID+" = ?";
    

	private static final Logger log = Logger.getLogger(ConnectionExtDAO.class);
	
	//======================================================================
    /**
     * Get the entity determined by the id. This method automatically loads all references maintained by the entity.
     *
     * @param id A Long identifying the entity to get.
     * @return The entity or null if no entity with that id exists.
     * @throws DatabaseException the database exception
     */
    public ConnectionExtEntity get(Long id) throws DatabaseException
    {
	return get(id, true);
    }
    
  //======================================================================
    /**
     * Get the entity determined by the id.
     *
     * @param id A Long identifying the entity to get.
     * @param load_refs A boolean that determines wether to load all the entities references. True to load, false to defer loading until later.
     * @return The entity or null if no entity with that id exists.
     * @throws DatabaseException the database exception
     */
    public ConnectionExtEntity get(Long id, boolean load_refs) throws DatabaseException
    {
	Long id_to_get = id;
	
	ConnectionEntity entity = super.get(id_to_get,true);
	
	ConnectionExtEntity extEntity = null;
	
	if (entity instanceof ConnectionExtEntity) {
		log.debug("ConnectionExtDAO.get():exteEntity:entity instanceof ConnectionExtEntity");
	    extEntity = (ConnectionExtEntity) entity;
	}
	if(extEntity == null && entity != null){
		
		extEntity = new ConnectionExtEntity();
		entity.copy(extEntity);
		extEntity.setLookupId(entity.getLookupId());
		extEntity.setRelationshipId(entity.getRelationshipId());
		extEntity.setNetConId(entity.getNetConId());
		extEntity.setOriginalCitiContactsIds(entity.getOriginalCitiContactsIds());
		extEntity.setNetCon(entity.getNetCon());
		extEntity.setRelationship(entity.getRelationship());
		extEntity.setLookup(entity.getLookup());
		extEntity.setOriginalCitiReqContactsIds(entity.getOriginalCitiReqContactsIds());
		extEntity.setOriginalCitiContactsIds(entity.getOriginalCitiContactsIds());
		
		extEntity.setTpContacts(entity.getTpContacts());
		extEntity.setProjectJustifications(entity.getProjectJustifications());
		extEntity.setFacilitiesAffected(entity.getFacilitiesAffected());
		extEntity.setCitiContacts(entity.getCitiContacts());
		extEntity.setResources(entity.getResources());
		extEntity.setServices(entity.getServices());
		extEntity.setMaterialBills(entity.getMaterialBills());
		extEntity.setFirewalls(entity.getFirewalls());
		extEntity.setCitiReqContacts(entity.getCitiReqContacts());
	}

	log.debug("ConnectionExtDAO.get():exteEntity:"+extEntity);
	
	DatabaseSession session = getSession();
	Connection connection = null;

	PreparedStatement st = null;
	ResultSet rs = null;
	connection = session.getConnection();
	
	try
	{	
	    st = connection.prepareStatement(SEL_CONNECTION_CONN_FOR_CUST_CLIENT);
	    setLongToStatement(st, 1, id_to_get);
	    log.debug("SEL_CON_REQ_CONN_FOR_CUST_CLIENT:"+SEL_CONNECTION_CONN_FOR_CUST_CLIENT +"ConnID::"+id_to_get);
	    rs = st.executeQuery();

	    if (rs.next())
		{
		    log.debug("CONN_FOR_CUST_CLIENT from Result rs.getString(1)::"+rs.getString(COLUMN_CONN_FOR_CUST_CLIENT));
		    String connForCustORClient = rs.getString(COLUMN_CONN_FOR_CUST_CLIENT);
		    if(connForCustORClient != null && !connForCustORClient.equals("")){
		    	extEntity.setConnForCustORClient(connForCustORClient.trim());
		    }
		    
		    log.debug("COLUMN_CAB_APPR_GRP_CODE from Result rs.getString(2)::"+rs.getString(COLUMN_CAB_APPR_GRP_CODE));
		    extEntity.setCabApprGrpCode(rs.getString(COLUMN_CAB_APPR_GRP_CODE));
		    
		    String direct_Accessby_Thirdprt = rs.getString(COLUMN_DIRECT_ACCESSBY_THIRDPRT);
		    log.debug("COLUMN_DIRECT_ACCESSBY_THIRDPRT from Result rs.getString(3)::"+direct_Accessby_Thirdprt);
		    if(direct_Accessby_Thirdprt != null && !direct_Accessby_Thirdprt.equals("")){
		    	extEntity.setDirectAccessByThirdPrt(direct_Accessby_Thirdprt.trim());
		    }
		    
		    log.debug("COLUMN_SEMI_ANNUAL_ENTITL_REVIEW from Result rs.getString(4)::"+rs.getString(COLUMN_SEMI_ANNUAL_ENTITL_REVIEW));
		    String semi_annual_entitl_review = rs.getString(COLUMN_SEMI_ANNUAL_ENTITL_REVIEW);
		    if(semi_annual_entitl_review != null && !semi_annual_entitl_review.equals("")){
		    	extEntity.setSemiAnnualEntitlReview(semi_annual_entitl_review.trim());
		    }
		    
		    log.debug("COLUMN_TP_TRAINING_AWARNESS_PRG from Result rs.getString(5)::"+rs.getString(COLUMN_TP_TRAINING_AWARNESS_PRG));
		    String tp_training_awarness_prg = rs.getString(COLUMN_TP_TRAINING_AWARNESS_PRG);
		    if(tp_training_awarness_prg != null && !tp_training_awarness_prg.equals("")){
		    	extEntity.setTpTrainingAwarnessPrg(tp_training_awarness_prg.trim());
		    }
		    
		    log.debug("COLUMN_EXPORT_LICENSE_CORDINATOR from Result rs.getString(6)::"+rs.getString(COLUMN_EXPORT_LICENSE_CORDINATOR));
		    String export_license_cordinator = rs.getString(COLUMN_EXPORT_LICENSE_CORDINATOR);
		    if(export_license_cordinator != null && !export_license_cordinator.equals("")){
		    	extEntity.setExportLicenseCordinatorNew(export_license_cordinator.trim());
		    }
		    
		    String connEstimate = rs.getString(COLUMN_CONN_ESTIMATE);
		    log.debug("COLUMN_CONN_ESTIMATE from Result rs.getString(7)::"+connEstimate);
		    if(connEstimate != null && !connEstimate.equals("")){
		    	extEntity.setConnEstimate(connEstimate.trim());
		    }
		    //COLUMN_DET_INFORMATION
		    
		    String detInformation = rs.getString(COLUMN_DET_INFORMATION);
		    log.debug("COLUMN_DET_INFORMATION from Result rs.getString(8)::"+detInformation);
		    if(detInformation != null && !detInformation.equals("")){
		    	extEntity.setDetInformation(detInformation.trim());
		    }
		    
		 }
	}
	catch (SQLException e)
	{
		log.error(e,e);
	    throw new DatabaseException("Could not load " + ConnectionExtDAO.TABLE +"."+COLUMN_CONN_FOR_CUST_CLIENT +" with id = " + id_to_get, e);
	}
	try{
		
		st = null; rs = null;
	    st = connection.prepareStatement(SELECT_CONNECTION_VIRTUAL_CONN_REASON);
	    setLongToStatement(st, 1, id_to_get);
	    log.debug("SELECT_VIRTUAL_CONN_REASON:"+SELECT_CONNECTION_VIRTUAL_CONN_REASON +"ConnID::"+id_to_get);
	    rs = st.executeQuery();
	    List<Long> reasonList =new ArrayList<Long>();
	    while (rs.next())
		{
		    log.debug("VIRTUAL_CONN_REASON from Result rs.getLong(1)::"+rs.getLong(1));
		    reasonList.add(Long.valueOf(rs.getLong(1)));
		}
	    if(reasonList.size() > 0){
	    	Long longarray[] = new Long[reasonList.size()];
	    	reasonList.toArray(longarray);
	    	log.debug("VIRTUAL_CONN_REASON reasonList::"+reasonList);
	    	extEntity.setReasonForVirtuConn(longarray);
	    }
	}
	catch (SQLException e)
	{
		log.error(e,e);
	    throw new DatabaseException("Could not load "+VIRTUAL_CONN_REASON+" with id = " + id_to_get, e);
	}
	
	finally
	{
	    closeResultSet(rs);
	    closeStatement(st);
	    session.releaseConnection();
	}
	
	return extEntity;
	
    }
	//======================================================================
    /**
     * Update the state of an entity. If the entity doesn't exist in the database it gets automatically added.
     *
     * @param entity The ConnectionEntity to update.
     * @return The Id of the entity. If the entity had to be inserted this is the id assigned to it.
     * @throws DatabaseException the database exception
     */
    public Long update(ConnectionEntity entity) throws DatabaseException
    {
	return update(entity, null, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(ConnectionEntity entity, boolean reset) throws DatabaseException
    {
	return update(entity, null, reset);
    }

    //======================================================================
    /**
     * Update the state of an entity. If the entity doesn't exist in the database it gets automatically added.
     *
     * @param entity The ConnectionEntity to update
     * @param archiver The archiver object used for tracking changes to the entity
     * @return The Id of the entity. If the entity had to be inserted this is the id assigned to it.
     * @throws DatabaseException the database exception
     */
    public Long update(ConnectionEntity entity, AuditArchiver archiver) throws DatabaseException
    {
	return update(entity, archiver, true);
    }

    //======================================================================
    /**
     * For internal use only.
     *
     * @param entity the entity
     * @param archiver the archiver
     * @param reset the reset
     * @return the long
     * @throws DatabaseException the database exception
     */
    public Long update(ConnectionEntity entity, AuditArchiver archiver, boolean reset) throws DatabaseException
    {
    	Long primaryId  = super.update(entity, archiver, true);
    	
    	if (entity instanceof ConnectionExtEntity) {
    		log.debug("ConnectionExtDAO.update():entity isntance of ConnectionExtEntity");
    		ConnectionExtEntity extEntity = (ConnectionExtEntity) entity;
    		DatabaseSession session = getSession();
    		
    		if(primaryId.longValue() == 0)
    			throw new DatabaseException("Could not insert Connectin with id = " + primaryId + " due to unique key constraint violation", null);
    		
    		Connection connection = null;
    	    PreparedStatement st = null;
    	    ResultSet rs = null;

    	    log.debug("ConnectionExtDAO.update() :- " + primaryId);
    	    try
    	    {
	    	    log.debug("ConnectionExtEntity.update()");
	    		connection = session.getConnection();
	    		st = connection.prepareStatement(UPDATE_BY_CONNECTION_TABLE);
	    		setStringToStatement(st, 1, extEntity.getConnForCustORClient(),COLUMN_CONN_FOR_CUST_LEN);
	    		setStringToStatement(st, 2, extEntity.getCabApprGrpCode(), COLUMN_RATIONALE_LEN);
	    		setStringToStatement(st, 3, extEntity.getDirectAccessByThirdPrt(),COLUMN_DIRECT_ACCESS_LEN);
	    		setStringToStatement(st, 4, extEntity.getSemiAnnualEntitlReview(),COLUMN_SEMI_ANNUAL_LEN);
	    		setStringToStatement(st, 5, extEntity.getTpTrainingAwarnessPrg(),COLUMN_TP_TRAINING_LEN);
	    		setStringToStatement(st, 6, extEntity.getExportLicenseCordinatorNew(),COLUMN_EXPORT_LICENCE_LEN);
	    		setStringToStatement(st, 7, extEntity.getConnEstimate(),COLUMN_CONN_ESTIMATE_LEN);
	    		setStringToStatement(st, 8, extEntity.getDetInformation(),COLUMN_DET_INFORMATION_LEN);
	    		setLongToStatement(st, 9, primaryId.longValue());
	    		st.executeUpdate();
    	    }
    	    catch (SQLException e)
    	    {
    		throw new DatabaseException("Could not insert '" + ConnectionDAO.ENTITY_NAME + "' with id = "
    			+ primaryId, e);
    	    }
	    	try
		    {
		    	PreparedStatement stmt = null;
			    ResultSet rsOne = null;
			    log.debug("ConnectionRequestExtEntity.update() :: INSERTING VIRTUAL_CONN_REASON::"+extEntity.getReasonForVirtuConn());
			    if(extEntity.getReasonForVirtuConn() != null){
				    log.debug("ConnectionRequestExtEntity.insert() ::LENGTH OF REASON FOR VIRTU::"+extEntity.getReasonForVirtuConn().length);
				    for(int i=0;i<extEntity.getReasonForVirtuConn().length;i++){
				    	Long virtual_id = null;
				    	try{
					    	stmt=connection.prepareStatement("Select "+SEQ_CONNECTION_VIRTUAL_CONN_REASON+".nextval from dual");
						    rsOne = stmt.executeQuery();
						    if (rsOne.next())
						    {
						     virtual_id=rsOne.getLong(1);
						    }
				    	}
					    catch (SQLException e)
					    {
						throw new DatabaseException("Could not get value form sequence  '" + SEQ_CONNECTION_VIRTUAL_CONN_REASON, e);
					    }
						st = connection.prepareStatement(INSERT_CONNECTION_VIRTUAL_CONN_REASON_TABLE);
						log.debug("INSERT_VIRTUAL_CONN_REASON_TABLE::"+INSERT_CONNECTION_VIRTUAL_CONN_REASON_TABLE);
						st.setLong(1,virtual_id.longValue());
						st.setLong(2, primaryId.longValue());
						st.setLong(3,extEntity.getReasonForVirtuConn()[i].longValue());
						st.executeUpdate();
				    }
			   	}
		    }
		    catch (SQLException e)
		    {
			throw new DatabaseException("Could not insert  '" + ConnectionExtDAO.VIRTUAL_CONN_REASON + "' with id = "
				+ primaryId, e);
		    }
		    finally
		    {
			closeResultSet(rs);
			closeStatement(st);
			session.releaseConnection();
		    }
		    log.debug("PlaningTable.update() :: End");
    	}
    	return primaryId;
    }
}
