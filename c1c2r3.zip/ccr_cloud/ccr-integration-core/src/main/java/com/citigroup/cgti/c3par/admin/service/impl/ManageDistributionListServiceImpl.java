package com.citigroup.cgti.c3par.admin.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.admin.dao.service.ManageDistributionListDao;
import com.citigroup.cgti.c3par.admin.domain.ManageDLDTO;
import com.citigroup.cgti.c3par.admin.service.ManageDistributionListService;
import com.citigroup.cgti.c3par.businessjustification.domain.CitiContact;

/**
 * Service class to perform interaction with DAO layer for Managing DL 
 * @author ac81662
 *
 */
@Service
public class ManageDistributionListServiceImpl implements ManageDistributionListService {

    private static final Logger log = Logger.getLogger(ManageDistributionListServiceImpl.class.getName());

    @Autowired
    ManageDistributionListDao manageDistributionListDao;

    public ManageDistributionListDao getManageDistributionListDao() {
        return manageDistributionListDao;
    }

    public void setManageDistributionListDao(ManageDistributionListDao manageDistributionListDao) {
        this.manageDistributionListDao = manageDistributionListDao;
    }

   
    /**        
     * This method is used to create DL record in Database.
     * @param manageDLDTO
     * @return
     * @throws Exception
     */
    @Override
    public Long addDL(ManageDLDTO manageDLDTO) throws Exception {
        log.info("ManageDistributionListServiceImpl.addDL starts");
        String firstName = "";
        String lastName = "";
        String displayName = manageDLDTO.getDisplayName();
        if(displayName != null) {
            if (displayName.length() > 100) {
                firstName = displayName.substring(0, 99);
                lastName = displayName.substring(100, displayName.length());
            } else {
                firstName = displayName;
            }
        }
        CitiContact citiContact = new CitiContact();
        citiContact.setFirstName(firstName);
        citiContact.setLastName(lastName);
        citiContact.setEmail(manageDLDTO.getEmailAddress());
        citiContact.setEmployeeType("C");
        citiContact.setEmployeeStatus("A");
        log.info("ManageDistributionListServiceImpl.addDL ends");
        return manageDistributionListDao.addDL(citiContact);
    }

    /**
     * Service method to save DL using Citi Contact domain
     * @param manageDLDTO
     * @return
     * @throws Exception
     */
    @Override
    public boolean saveDL(ManageDLDTO manageDLDTO) throws Exception {
        log.info("ManageDistributionListServiceImpl.saveDL starts");
        CitiContact citiContact = new CitiContact();
        convertDtoToDomain(manageDLDTO, citiContact);
        log.info("ManageDistributionListServiceImpl.saveDL ends");
        return manageDistributionListDao.saveDL(citiContact);
    }

    /**
     * Method to copy ManageDL Dto properties to Citi Contact properties 
     * @param manageDLDTO
     * @param citiContact
     */
    private void convertDtoToDomain(ManageDLDTO manageDLDTO, CitiContact citiContact) throws Exception {
        try {
            String firstName = "";
            String lastName = "";
            String displayName = manageDLDTO.getDisplayName();
            if(displayName != null){
                if (displayName.length() > 100) {
                    firstName = displayName.substring(0, 99);
                    lastName = displayName.substring(100, displayName.length());
                } else {
                    firstName = displayName;
                }
            }
            citiContact.setFirstName(firstName);
            citiContact.setLastName(lastName);
            citiContact.setEmail(manageDLDTO.getEmailAddress());
            citiContact.setEmployeeType("C");
            citiContact.setEmployeeStatus("A");
            citiContact.setSsoId(manageDLDTO.getSsoId());
        } catch (Exception e) {
            log.error("Exception while convertDtoToDomain " + e.toString());
            log.error(e, e);
            throw new ApplicationException("Exception in convertDtoToDomain ", e);
        }
    }

    /**
     * Service method to get list of DL from Database.
     * @return
     * @throws Exception
     */
    @Override
    public List<ManageDLDTO> getManageDLList() throws Exception {
        log.info("ManageDistributionListServiceImpl.getManageDLList starts");
        List<CitiContact> citiContactList = new ArrayList<CitiContact>();
        List<ManageDLDTO> manageDLDTOList = new ArrayList<ManageDLDTO>();
        citiContactList = manageDistributionListDao.getManageDLList();
        for (CitiContact citiContact : citiContactList) {
            ManageDLDTO manageDLDTO = new ManageDLDTO();
            String lastName = (citiContact.getLastName() != null) ? citiContact.getLastName() : "";
            manageDLDTO.setDisplayName(citiContact.getFirstName() + lastName);
            manageDLDTO.setEmailAddress(citiContact.getEmail());
            manageDLDTO.setSsoId(citiContact.getSsoId());
            manageDLDTOList.add(manageDLDTO);
        }
        log.info("ManageDistributionListServiceImpl.getManageDLList ends");
        return manageDLDTOList;
    }

    /**
     * Service method to delete DLs from Database
     * @param manageDLDTO
     * @return
     * @throws Exception
     */
    @Override
    public boolean deleteDL(ManageDLDTO manageDLDTO) throws Exception {
        log.info("ManageDistributionListServiceImpl.deleteDL starts");
        CitiContact citiContact = new CitiContact();
        convertDtoToDomain(manageDLDTO, citiContact);
        log.info("ManageDistributionListServiceImpl.deleteDL ends");
        return manageDistributionListDao.deleteDL(citiContact);
    }
}
