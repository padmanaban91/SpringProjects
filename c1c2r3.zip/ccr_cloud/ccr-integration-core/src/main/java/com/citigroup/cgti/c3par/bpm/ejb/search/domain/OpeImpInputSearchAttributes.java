package com.citigroup.cgti.c3par.bpm.ejb.search.domain;

import java.io.Serializable;


/**
 * The Class OpeImpInputSearchAttributes.
 */
public class OpeImpInputSearchAttributes extends BaseSearchAttributes implements Serializable{

    /** The Constant serialVersionUID. */
    private static final long serialVersionUID = -555601390722946129L;



    /** The tpaswg review type. */
    private String tpaswgReviewType = null;//lookup

    /** The tpaswg review status. */
    private String tpaswgReviewStatus = null;//lookup

    /** The tpaswg review from date. */
    private String tpaswgReviewFromDate = null;

    /** The tpaswg review to date. */
    private String tpaswgReviewToDate = null;

    /** The tpaswg rejected from date. */
    private String tpaswgRejectedFromDate = null;

    /** The tpaswg rejected to date. */
    private String tpaswgRejectedToDate = null;

    /** The tpaswg temp app from date. */
    private String tpaswgTempAppFromDate = null;

    /** The tpaswg temp app to date. */
    private String tpaswgTempAppToDate = null;

    /**
     * Gets the tpaswg rejected from date.
     *
     * @return the tpaswg rejected from date
     */
    public String getTpaswgRejectedFromDate() {
	return tpaswgRejectedFromDate;
    }

    public String getTpaswgRejectedFromDateForQuery() {
	return validString(tpaswgRejectedFromDate);
    }

    /**
     * Sets the tpaswg rejected from date.
     *
     * @param tpaswgRejectedFromDate the new tpaswg rejected from date
     */
    public void setTpaswgRejectedFromDate(String tpaswgRejectedFromDate) {
	this.tpaswgRejectedFromDate = tpaswgRejectedFromDate;
    }

    /**
     * Gets the tpaswg rejected to date.
     *
     * @return the tpaswg rejected to date
     */
    public String getTpaswgRejectedToDate() {
	return tpaswgRejectedToDate;
    }

    public String getTpaswgRejectedToDateForQuery() {
	return validString(tpaswgRejectedToDate);
    }

    /**
     * Sets the tpaswg rejected to date.
     *
     * @param tpaswgRejectedToDate the new tpaswg rejected to date
     */
    public void setTpaswgRejectedToDate(String tpaswgRejectedToDate) {
	this.tpaswgRejectedToDate = tpaswgRejectedToDate;
    }

    /**
     * Gets the tpaswg review from date.
     *
     * @return the tpaswg review from date
     */
    public String getTpaswgReviewFromDate() {
	return tpaswgReviewFromDate;
    }

    public String getTpaswgReviewFromDateForQuery() {
	return validString(tpaswgReviewFromDate);
    }

    /**
     * Sets the tpaswg review from date.
     *
     * @param tpaswgReviewFromDate the new tpaswg review from date
     */
    public void setTpaswgReviewFromDate(String tpaswgReviewFromDate) {
	this.tpaswgReviewFromDate = tpaswgReviewFromDate;
    }

    /**
     * Gets the tpaswg review to date.
     *
     * @return the tpaswg review to date
     */
    public String getTpaswgReviewToDate() {
	return tpaswgReviewToDate;
    }

    public String getTpaswgReviewToDateForQuery() {
	return validString(tpaswgReviewToDate);
    }

    /**
     * Sets the tpaswg review to date.
     *
     * @param tpaswgReviewToDate the new tpaswg review to date
     */
    public void setTpaswgReviewToDate(String tpaswgReviewToDate) {
	this.tpaswgReviewToDate = tpaswgReviewToDate;
    }

    /**
     * Gets the tpaswg review status.
     *
     * @return the tpaswg review status
     */
    public String getTpaswgReviewStatus() {
	return tpaswgReviewStatus;
    }

    public String getTpaswgReviewStatusForQuery() {
	return validString(tpaswgReviewStatus);
    }

    /**
     * Sets the tpaswg review status.
     *
     * @param tpaswgReviewStatus the new tpaswg review status
     */
    public void setTpaswgReviewStatus(String tpaswgReviewStatus) {
	this.tpaswgReviewStatus = tpaswgReviewStatus;
    }

    /**
     * Gets the tpaswg review type.
     *
     * @return the tpaswg review type
     */
    public String getTpaswgReviewType() {
	return tpaswgReviewType;
    }

    public String getTpaswgReviewTypeForQuery() {
	return validString(tpaswgReviewType);
    }

    /**
     * Sets the tpaswg review type.
     *
     * @param tpaswgReviewType the new tpaswg review type
     */
    public void setTpaswgReviewType(String tpaswgReviewType) {
	this.tpaswgReviewType = tpaswgReviewType;
    }

    /**
     * Gets the tpaswg temp app from date.
     *
     * @return the tpaswg temp app from date
     */
    public String getTpaswgTempAppFromDate() {
	return tpaswgTempAppFromDate;
    }

    public String getTpaswgTempAppFromDateForQuery() {
	return validString(tpaswgTempAppFromDate);
    }
    /**
     * Sets the tpaswg temp app from date.
     *
     * @param tpaswgTempAppFromDate the new tpaswg temp app from date
     */
    public void setTpaswgTempAppFromDate(String tpaswgTempAppFromDate) {
	this.tpaswgTempAppFromDate = tpaswgTempAppFromDate;
    }

    /**
     * Gets the tpaswg temp app to date.
     *
     * @return the tpaswg temp app to date
     */
    public String getTpaswgTempAppToDate() {
	return tpaswgTempAppToDate;
    }

    public String getTpaswgTempAppToDateForQuery() {
	return validString(tpaswgTempAppToDate);
    }

    /**
     * Sets the tpaswg temp app to date.
     *
     * @param tpaswgTempAppToDate the new tpaswg temp app to date
     */
    public void setTpaswgTempAppToDate(String tpaswgTempAppToDate) {
	this.tpaswgTempAppToDate = tpaswgTempAppToDate;
    }

}
