package com.citigroup.cgti.c3par.communication.domain;

import com.citigroup.cgti.c3par.domain.Base;
import com.citigroup.cgti.c3par.user.domain.C3parUser;

public class EcmQueueUsers extends Base{
	
	private EcmQueue ecmQueue;
	
	private C3parUser c3parUser;

	public EcmQueue getEcmQueue() {
		return ecmQueue;
	}

	public void setEcmQueue(EcmQueue ecmQueue) {
		this.ecmQueue = ecmQueue;
	}

	public C3parUser getC3parUser() {
		return c3parUser;
	}

	public void setC3parUser(C3parUser c3parUser) {
		this.c3parUser = c3parUser;
	}
	

}
