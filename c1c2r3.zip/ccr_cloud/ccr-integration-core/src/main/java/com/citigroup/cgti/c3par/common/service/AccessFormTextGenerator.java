package com.citigroup.cgti.c3par.common.service;


import java.io.StringReader;
import java.io.StringWriter;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.jdbc.support.JdbcUtils;
import org.springframework.jdbc.support.lob.LobHandler;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import com.citigroup.cgti.c3par.appsense.domain.AppsenseAAFCombination;
import com.citigroup.cgti.c3par.appsense.domain.AppsenseADGroup;
import com.citigroup.cgti.c3par.appsense.domain.logic.ManageAppsensePersistable;
import com.citigroup.cgti.c3par.bpm.ejb.rel.domain.RelationshipDTO;
import com.citigroup.cgti.c3par.ccrcmpmapping.dao.service.impl.CCRCMPMappingConstants;
import com.citigroup.cgti.c3par.common.domain.AccessFormText;
import com.citigroup.cgti.c3par.configuation.CCRQueries;
import com.citigroup.cgti.c3par.configuation.QueryConstants;
import com.citigroup.cgti.c3par.domain.ActivityData;
import com.citigroup.cgti.c3par.domain.Application;
import com.citigroup.cgti.c3par.domain.Person;
import com.citigroup.cgti.c3par.domain.Role;
import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.domain.accessform.AAFAccessForm;
import com.citigroup.cgti.c3par.domain.accessform.ACLTechnicalDetails;
import com.citigroup.cgti.c3par.domain.accessform.AccessFormXsl;
import com.citigroup.cgti.c3par.domain.accessform.FafAccessForm;
import com.citigroup.cgti.c3par.domain.accessform.PafAccessForm;
import com.citigroup.cgti.c3par.fw.domain.FAFRequest;
import com.citigroup.cgti.c3par.fw.domain.FafFirewallRule;
import com.citigroup.cgti.c3par.fw.domain.FafFirewallRuleDestinationIP;
import com.citigroup.cgti.c3par.fw.domain.FafFirewallRulePolicy;
import com.citigroup.cgti.c3par.fw.domain.FafFirewallRulePort;
import com.citigroup.cgti.c3par.fw.domain.FafFirewallRuleSourceIP;
import com.citigroup.cgti.c3par.fw.domain.FireWallRuleIP;
import com.citigroup.cgti.c3par.fw.domain.FireWallRulePort;
import com.citigroup.cgti.c3par.fw.domain.Firewall;
import com.citigroup.cgti.c3par.fw.domain.FirewallRulesExport;
import com.citigroup.cgti.c3par.fw.service.FirewallRulesExportService;
import com.citigroup.cgti.c3par.model.PlanningEntity;
import com.citigroup.cgti.c3par.proxy.domain.ProxyInstance;
import com.citigroup.cgti.c3par.proxy.domain.ProxyPAFCombination;
import com.citigroup.cgti.c3par.proxy.domain.logic.ProxyPersistable;
import com.citigroup.cgti.c3par.soa.vc.domain.RFCRequest;
import com.citigroup.cgti.c3par.util.C3parStaticNames;
import com.citigroup.cgti.c3par.util.CCRUtil;
import com.citigroup.cgti.c3par.util.StringUtil;
import com.citigroup.cgti.c3par.webtier.helper.Util;


public class AccessFormTextGenerator implements AccessFormText {
    private static Logger log = Logger.getLogger(AccessFormTextGenerator.class);
    
    private static final String AAF_REQUEST_TYPE = "AAF";

    private static final String PAF_REQUEST_TYPE = "PAF";
    
    private static final String FAF_REQUEST_TYPE = "FAF";
    
    private static final String IPFAF_REQUEST_TYPE = "IPFAF";
    
    private static final String ACL_REQUEST_TYPE = "ACL";
        
    private CCRQueries ccrQueries;
    
    private JdbcTemplate jdbcTemplate;
    
    private ProxyPersistable proxyPersistable;
    
    private ManageAppsensePersistable appsensePersistable;
    
//    private CommonServicePersistable commonServicePersistable;
    
    private DataSource  dataSource;
    
    public LobHandler lobHandler;
    
    private static final SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
    
    private static final String YES = "Y";
    
    private static final String NO = "N";
    private static final String IMPL = "Impl";
    private static final String IS_FAF = "is_faf";
    private static final String IS_PROXY = "is_proxy";
    private static final String IP_REGISTRATION = "ip_registration";
    private static final String FAF = "FAF-";
    private static final String EXT_TXT = ".txt";
    private static final String IP = "IP-";
    private static final String PAF = "PAF-";
    
    @Autowired
    FirewallRulesExportService firewallRulesExportService;
 
    
    
    
    public LobHandler getLobHandler() {
        return lobHandler;
    }

    public void setLobHandler(LobHandler lobHandler) {
        this.lobHandler = lobHandler;
    }


    public DataSource getDataSource() {
        return dataSource;
    }

    public void setDataSource(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    /**
     * @return the jdbcTemplate
     */
    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    /**
     * @param jdbcTemplate the jdbcTemplate to set
     */
    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public ProxyPersistable getProxyPersistable() {
        return proxyPersistable;
    }

    public void setProxyPersistable(ProxyPersistable proxyPersistable) {
        this.proxyPersistable = proxyPersistable;
    }   
    
    public ManageAppsensePersistable getAppsensePersistable() {
        return appsensePersistable;
    }

    public void setAppsensePersistable(ManageAppsensePersistable appsensePersistable) {
        this.appsensePersistable = appsensePersistable;
    }
    
   /* public CommonServicePersistable getCommonServicePersistable() {
        return commonServicePersistable;
    }

    public void setCommonServicePersistable(CommonServicePersistable commonServicePersistable) {
        this.commonServicePersistable = commonServicePersistable;
    }*/
    
    public CCRQueries getCcrQueries() {
        return ccrQueries;
    }

    public void setCcrQueries(CCRQueries ccrQueries) {
        this.ccrQueries = ccrQueries;
    }

    /**
     * This method attaches attachment for all products
     * @param tiRequestID
     * @param connectionRequestId
     * @param versionID
     * @return
     * 
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW, timeout=1200)
    public HashMap<String, String> getAttachments(Long tiRequestID, Long connectionRequestId, Long versionID, String isACV) {
        log.debug("Tranasation is Active : "+TransactionSynchronizationManager.isActualTransactionActive());
        boolean isFAF = false;
        boolean isProxy = false;
        boolean isAppsense = false;
        boolean isAcl = false;
        boolean isIpReg = false;
        
        SqlRowSet rs = getJdbcTemplate().queryForRowSet("select is_faf, is_proxy, is_appsense, is_acl_variance, ip_registration from ti_request_risk_flags " 
                +" WHERE ti_request_id in (select id from ti_request where process_id=? and version_number= "
                +" (select max(version_number) from ti_request where process_id=? and ti_request_type_id not in "
                +" (select id from ti_request_type where request_type in ('ACV','ManageContacts','Temp Approval Expiration')) and is_deleted = 'N' ) and is_deleted = 'N')", connectionRequestId, connectionRequestId);
        
        if (rs.next()) {
            if (YES.equalsIgnoreCase(rs.getString("is_faf"))) {
                isFAF = true;
            }
            if (YES.equalsIgnoreCase(rs.getString("is_proxy"))) {
                isProxy = true;
            }
            if (YES.equalsIgnoreCase(rs.getString("is_appsense"))) {
                isAppsense = true;
            }
            if (YES.equalsIgnoreCase(rs.getString("is_acl_variance"))) {
                isAcl = true;
            }
            if (YES.equalsIgnoreCase(rs.getString("ip_registration"))) {
                isIpReg = true;
            }
        }
        
        HashMap<String, String> attachments = new HashMap<String, String>();
        //Added for task 43752-starts
        if(YES.equalsIgnoreCase(isACV)){
            log.debug("into isACV block"); 
            //For Firewall
            if (isFAF) {
                List<TIRequest> fw = getAllTiRequest(connectionRequestId, NO, "All");
                StringBuilder faf = new StringBuilder();
                for (TIRequest i :fw){
                    log.debug("req id" +i.getId());
                    faf.append(getFirewallAccessFormText(i.getId(), connectionRequestId, Long.valueOf(i.getVersionNumber())));
                }
                attachments.put("FAF-"+connectionRequestId+".txt", faf.toString()); 
            }
            //For IP
            if (isIpReg) {
            List<TIRequest> ip = getAllTiRequest(connectionRequestId, YES, "All");
            StringBuilder ipfaf = new StringBuilder();
            for (TIRequest a :ip){
                log.debug("req id" +a.getId());
                ipfaf.append(getIPRegistrationAccessFormText(a.getId(), connectionRequestId, Long.valueOf(a.getVersionNumber())));
            }
            attachments.put("IP-"+connectionRequestId+".txt", ipfaf.toString());
            }
            if (isAppsense) {
                List<TIRequest> ip = getAllTiRequestForPAF(connectionRequestId);
                StringBuilder ipfaf = new StringBuilder();
                for (TIRequest a :ip){
                    log.debug("req id" +a.getId());
                    ipfaf.append(getAppsenseAccessFormText(a.getId(), connectionRequestId, Long.valueOf(a.getVersionNumber())));
                }
                attachments.put("AAF-"+connectionRequestId+".txt", ipfaf.toString());
                }
            if (isAcl) {
                List<TIRequest> ip = getAllTiRequestForPAF(connectionRequestId);
                StringBuilder ipfaf = new StringBuilder();
                for (TIRequest a :ip){
                    log.debug("req id" +a.getId());
                    ipfaf.append(getSECACLAccessFormText(a.getId(), connectionRequestId, Long.valueOf(a.getVersionNumber())));
                }
                attachments.put("ACL-"+connectionRequestId+".txt", ipfaf.toString());
                }
            if (isProxy) {
                List<TIRequest> ip = getAllTiRequestForPAF(connectionRequestId);
                StringBuilder ipfaf = new StringBuilder();
                for (TIRequest a :ip){
                    log.debug("req id" +a.getId());
                    ipfaf.append(getProxyAccessFormText(a.getId(), connectionRequestId, Long.valueOf(a.getVersionNumber())));
                }
                attachments.put("PAF-"+connectionRequestId+".txt", ipfaf.toString());
                }
            
        } else {
            //Added for task 43752-Ends
            if (isFAF) {
                    attachments.put("FAF-"+connectionRequestId+"."+versionID+".txt", getFirewallAccessFormText(tiRequestID, connectionRequestId, versionID));
            }
            if (isProxy) {
                attachments.put("PAF-"+connectionRequestId+"."+versionID+".txt", getProxyAccessFormText(tiRequestID, connectionRequestId, versionID));
            }
            if (isAppsense) {
                attachments.put("AAF-"+connectionRequestId+"."+versionID+".txt", getAppsenseAccessFormText(tiRequestID, connectionRequestId, versionID));
            }
            if (isAcl) {
                attachments.put("SECACL-"+connectionRequestId+"."+versionID+".txt", getSECACLAccessFormText(tiRequestID, connectionRequestId, versionID));      
            }
            if (isIpReg) {
                attachments.put("IP-"+connectionRequestId+"."+versionID+".txt", getIPRegistrationAccessFormText(tiRequestID, connectionRequestId, versionID));
            }
        }
        return attachments; 
    }
    
    
    /**
     * This method attaches attachment for all products
     * @param tiRequestID
     * @param connectionRequestId
     * @param versionID
     * @return
     * 
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW, timeout=1200)
     public HashMap<String, byte[]> getFileAttachments(Long tiRequestID, Long connectionRequestId, Long versionID,
            String isACV) {
        log.debug("Tranasation is Active : " + TransactionSynchronizationManager.isActualTransactionActive());
        boolean isFAF = false;
        boolean isProxy = false;
        boolean isAppsense = false;
        boolean isAcl = false;
        boolean isIpReg = false;

        SqlRowSet rs = getJdbcTemplate()
                .queryForRowSet(
                        "select is_faf, is_proxy, is_appsense, is_acl_variance, ip_registration from ti_request_risk_flags "
                                + " WHERE ti_request_id in (select id from ti_request where process_id=? and version_number= "
                                + " (select max(version_number) from ti_request where process_id=? and ti_request_type_id not in "
                                + " (select id from ti_request_type where request_type in ('ACV','ManageContacts')) and is_deleted = 'N' ) and is_deleted = 'N')",
                        connectionRequestId, connectionRequestId);

        if (rs.next()) {
            if (YES.equalsIgnoreCase(rs.getString("is_faf"))) {
                isFAF = true;
            }
            if (YES.equalsIgnoreCase(rs.getString("is_proxy"))) {
                isProxy = true;
            }
            if (YES.equalsIgnoreCase(rs.getString("is_appsense"))) {
                isAppsense = true;
            }
            if (YES.equalsIgnoreCase(rs.getString("is_acl_variance"))) {
                isAcl = true;
            }
            if (YES.equalsIgnoreCase(rs.getString("ip_registration"))) {
                isIpReg = true;
            }
        }
        String fileName = null;
        HashMap<String, byte[]> attachments = new HashMap<String, byte[]>();
        byte[] fileToAttach = null;
        // Added for task 43752-starts
        if (YES.equalsIgnoreCase(isACV)) {

            log.debug("into isACV block");
            // For Firewall
            if (isFAF) {
                fileName = "FAF-" + connectionRequestId + ".xls";
                List<TIRequest> fw = getAllTiRequest(connectionRequestId, NO, "All");
                StringBuilder faf = new StringBuilder();

                for (TIRequest i : fw) {
                    log.debug("req id" + i.getId());

                    try {
                        log.info("getting firewllrules with tirequestid :" + i.getId() + " processId :"
                                + connectionRequestId + " VersionNumber :" + i.getVersionNumber());

                        AccessFormXsl accessFormXsl = getConnectionInfoForEnhancedExport(i.getId(),
                                connectionRequestId, new Long(i.getVersionNumber()), "FAF", "NO");

                        fileToAttach = CCRUtil.exportExcelAttachment(accessFormXsl, fileName.toString());

                    } catch (Exception e) {
                        log.error(e.getMessage());
                    }
                }
                attachments.put(fileName, fileToAttach);

            }
            // For IP
            if (isIpReg) {
                fileName = "IP-" + connectionRequestId + ".xls";
                List<TIRequest> fw = getAllTiRequest(connectionRequestId, NO, "All");
                StringBuilder faf = new StringBuilder();

                // byte[] fileToAttach = null;
                for (TIRequest i : fw) {
                    log.debug("req id" + i.getId());

                    try {
                        log.info("getting firewllrules with tirequestid :" + i.getId() + " processId :"
                                + connectionRequestId + " VersionNumber :" + i.getVersionNumber());
                        AccessFormXsl accessFormXsl = getConnectionInfoForEnhancedExport(i.getId(),
                                connectionRequestId, new Long(i.getVersionNumber()), "IPFAF", "NO");

                        fileToAttach = CCRUtil.exportExcelAttachment(accessFormXsl, fileName.toString());

                    } catch (Exception e) {
                        log.error(e.getMessage());
                    }
                }
                attachments.put(fileName, fileToAttach);
            }

            /*
             * if (isAppsense) { List<TIRequest> ip =
             * getAllTiRequestForPAF(connectionRequestId); StringBuilder ipfaf =
             * new StringBuilder(); fileName= "AAF-" + connectionRequestId +
             * ".xls"; for (TIRequest a : ip) { log.debug("req id" + a.getId());
             * try { AccessFormXsl appsenseAccessForm = null; AccessFormXsl
             * accessFormXsl = getConnectionInfo(a.getId(), connectionRequestId,
             * versionID,AAF_REQUEST_TYPE );
             * accessFormXsl.getAppsenseAccessformList(); appsenseAccessForm =
             * getAAFCombinationInfo(connectionRequestId,a.getId(), versionID);
             * accessFormXsl.setAppsenseAccessformList(appsenseAccessForm.
             * getAppsenseAccessformList());
             * accessFormXsl.setNwList(appsenseAccessForm.getNwList());
             * accessFormXsl.setUserList(appsenseAccessForm.getUserList());
             * fileToAttach = CCRUtil.exportExcelAttachment(accessFormXsl,
             * fileName.toString()); } catch (Exception e) {
             * log.error(e.getMessage()); } } attachments.put(fileName,
             * fileToAttach); } if (isAcl) { List<TIRequest> ip =
             * getAllTiRequestForPAF(connectionRequestId);
             * 
             * fileName = "ACL-" + connectionRequestId + ".xls"; for (TIRequest
             * a : ip) { log.debug("req id" + a.getId()); try { AccessFormXsl
             * accessFormXsl = getConnectionInfo(a.getId(), connectionRequestId,
             * versionID, "ACL");
             * accessFormXsl.setDocDetails(getSecACLInfo(a.getId(),
             * connectionRequestId, versionID)); fileToAttach =
             * CCRUtil.exportExcelAttachment(accessFormXsl,
             * fileName.toString()); } catch (Exception e) {
             * log.error(e.getMessage()); } } attachments.put(fileName,
             * fileToAttach); } if (isProxy) {
             * 
             * List<TIRequest> ip = getAllTiRequestForPAF(connectionRequestId);
             * 
             * fileName ="PAF-"+connectionRequestId+"."+versionID+".xls"; for
             * (TIRequest a : ip) { log.debug("req id" + a.getId()); try {
             * 
             * AccessFormXsl accessFormXsl = getConnectionInfo(a.getId(),
             * connectionRequestId, versionID, PAF_REQUEST_TYPE);
             * accessFormXsl.setProxyAccessformList
             * (getPAFCombinationInfo(connectionRequestId, a.getId(), versionID,
             * NO, null));
             * 
             * fileToAttach = CCRUtil.exportExcelAttachment(accessFormXsl,
             * fileName); } catch (Exception e) { log.error(e.getMessage()); } }
             * attachments.put(fileName, fileToAttach); }
             */

        } else {

            if (isFAF) {
                try {
                    log.info("getting firewallrules with tirequestid :" + tiRequestID + " processId :"
                            + connectionRequestId + " VersionNumber :" + tiRequestID);
                    fileName = "FAF-" + connectionRequestId + ".xls";
                    AccessFormXsl accessFormXsl = getConnectionInfoForEnhancedExport(tiRequestID, connectionRequestId,
                            new Long(versionID), "FAF", "NO");

                    fileToAttach = CCRUtil.exportExcelAttachment(accessFormXsl, fileName.toString());
                    attachments.put(fileName, fileToAttach);
                } catch (Exception e) {
                    log.error(e.getMessage());
                }

            }
            if (isIpReg) {

                try {
                    log.info("getting firewallrules with tirequestid :" + tiRequestID + " processId :"
                            + connectionRequestId + " VersionNumber :" + tiRequestID);
                    fileName = "IP-" + connectionRequestId + ".xls";
                    AccessFormXsl accessFormXsl = getConnectionInfoForEnhancedExport(tiRequestID, connectionRequestId,
                            new Long(versionID), "IPFAF", "NO");

                    fileToAttach = CCRUtil.exportExcelAttachment(accessFormXsl, fileName.toString());
                    attachments.put(fileName, fileToAttach);

                } catch (Exception e) {
                    log.error(e.getMessage());
                }

            }
           

        }
        return attachments;
    }

    /**
     * The method to retrieve PAF export
     * @param tiRequestID
     * @param connectionRequestId
     * @param versionID
     * @return String Containing AccessFormText for Proxy
     */
    @Transactional(readOnly = true)
    public String getProxyAccessFormText(Long tiRequestId, Long connectionRequestId, Long versionID) {
        String proxyAccessFormText = "";
        try {
            log.debug("Tranasation is Active"+TransactionSynchronizationManager.isActualTransactionActive());
            AccessFormXsl accessFormXsl = getConnectionInfo(tiRequestId, connectionRequestId, versionID, PAF_REQUEST_TYPE );
            accessFormXsl.setProxyAccessformList(getPAFCombinationInfo(connectionRequestId,tiRequestId, versionID, NO,null));
            proxyAccessFormText =  transformObjectXMLtoXSLTemplate(accessFormXsl, PAF_REQUEST_TYPE);
        } catch (Exception e) {
            log.error("Exception in getProxyAccessFormText : "+e, e);           
        }
        return proxyAccessFormText;
    }
    
    /**
     * The method to retrieve AAF form
     * @param tiRequestID
     * @param connectionRequestId
     * @param versionID
     * @return String Containing AccessFormText for Appsense
     */
    @Transactional(readOnly = true)
    public String getAppsenseAccessFormText(Long tiRequestId, Long connectionRequestId, Long versionID) {
        String appSenseAccessFormText = "";
        AccessFormXsl accessFormXsl = null;
        AccessFormXsl appsenseAccessForm = null;
        try {
            accessFormXsl = getConnectionInfo(tiRequestId, connectionRequestId, versionID,AAF_REQUEST_TYPE );
            accessFormXsl.getAppsenseAccessformList();
            appsenseAccessForm = getAAFCombinationInfo(connectionRequestId,tiRequestId, versionID);
            accessFormXsl.setAppsenseAccessformList(appsenseAccessForm.getAppsenseAccessformList());
            accessFormXsl.setNwList(appsenseAccessForm.getNwList());
            accessFormXsl.setUserList(appsenseAccessForm.getUserList());
            appSenseAccessFormText = transformObjectXMLtoXSLTemplate(accessFormXsl, AAF_REQUEST_TYPE);
        } catch (Exception e) {
            log.error("Exception in getAppsenseAccessFormText : "+e, e);            
        }
        return appSenseAccessFormText;
    }
    
    /**
     * The method to retrieve Firewall AccessFormText
     * @param tiRequestID
     * @param connectionRequestId
     * @param versionID
     * @return String Containing AccessFormText for Firewall
     */
    public String getFirewallAccessFormText(Long tiRequestId, Long connectionRequestId, Long versionID) {
        return getFirewallAccessFormText(tiRequestId, connectionRequestId, versionID, NO);
    }
    /**
     * The method to retrieve FAF
     * @param tiRequestID
     * @param connectionRequestId
     * @param versionID
     * @param isObjExpandable
     * @return String Containing AccessFormText for Firewall
     */
    @Transactional(readOnly = true)
    public String getFirewallAccessFormText(Long tiRequestId, Long connectionRequestId, Long versionID, String isObjExpandable) {
        RFCRequest rfcrequest = null;
        AccessFormXsl accessFormXsl = null;
        String firewallAccessFormText = "";
        try {           
            accessFormXsl = getConnectionInfo(tiRequestId, connectionRequestId, versionID, "FAF");
            accessFormXsl.setFwImplDetails(getCombinationInfo(tiRequestId, NO, rfcrequest, NO, isObjExpandable));
            firewallAccessFormText = transformObjectXMLtoXSLTemplate(accessFormXsl, FAF_REQUEST_TYPE);
        } catch (Exception e) {
            log.error("Exception in getFirewallAccessFormText : "+e, e);
        }
        return firewallAccessFormText;
    }

    /**
     * The method to retrieve FAF using RFC
     * @param RFCRequest
     * @return String Containing AccessFormText for Firewall
     */
    @Transactional(readOnly = true)
    public String getFirewallAccessFormTextByRFC(RFCRequest rfcRequest) {
        Long tiRequestId = 0l;
        Long conRequestId = 0l;
        Long versionID = 0l;
        String isIPReg = "";
        AccessFormXsl accessFormXsl = null;
        String firewallAccessFormTextByRFC = "";
        try {           
            tiRequestId = rfcRequest.getTiRequest().getId();
            conRequestId = rfcRequest.getTiRequest().getTiProcess().getId();
            versionID = Long.valueOf(rfcRequest.getTiRequest().getVersionNumber());
            isIPReg = rfcRequest.getIsIpReg();
            log.info("tiRequestId :: "+tiRequestId+", conRequestId :: "+conRequestId+", versionID :: "+versionID+", isIPReg :: "+isIPReg);
            accessFormXsl = getConnectionInfo(tiRequestId, conRequestId, versionID, isIPReg.equalsIgnoreCase(NO)?"FAF":"IPFAF");
            accessFormXsl.setFwImplDetails(getCombinationInfo(tiRequestId, isIPReg, rfcRequest, YES));
            firewallAccessFormTextByRFC = transformObjectXMLtoXSLTemplate(accessFormXsl, isIPReg.equalsIgnoreCase(NO)?"FAF":"IPFAF");
        } catch (Exception e) {
            log.error("Exception in getFirewallAccessFormTextByRFC : "+e, e);           
        }
        return firewallAccessFormTextByRFC;
    }

    /**
     * The method to retrieve PAF using RFC
     * @param RFCRequest
     * @return String Containing AccessFormText for Proxy
     */
    @Transactional(readOnly = true)
    public String getProxyAccessFormTextByRFC(RFCRequest rfcRequest) {
        Long tiRequestId = 0l;
        Long conRequestId = 0l;
        Long versionID = 0l;
        AccessFormXsl accessFormXsl = null;
        String proxyAccessFormTextByRFC = "";
        try {           
            tiRequestId = rfcRequest.getTiRequest().getId();
            conRequestId = rfcRequest.getTiRequest().getTiProcess().getId();
            versionID = Long.valueOf(rfcRequest.getTiRequest().getVersionNumber());         
            log.info("tiRequestId :: "+tiRequestId+", conRequestId :: "+conRequestId+", versionID :: "+versionID);
            accessFormXsl = getConnectionInfo(tiRequestId, conRequestId, versionID,"PAF");
            accessFormXsl.setProxyAccessformList(getPAFCombinationInfo(conRequestId,tiRequestId, versionID,YES,rfcRequest));
            proxyAccessFormTextByRFC = transformObjectXMLtoXSLTemplate(accessFormXsl, PAF_REQUEST_TYPE);
        } catch (Exception e) {
            log.error("Exception in getProxyAccessFormTextByRFC : "+e, e);          
        }
        return proxyAccessFormTextByRFC;
    }
    
    /**
     * The method to retrieve IP Registration AccessFormText
     * @param tiRequestID
     * @param connectionRequestId
     * @param versionID
     * @return String Containing AccessFormText for IP Registration
     */
    public String getIPRegistrationAccessFormText(Long tiRequestId, Long connectionRequestId, Long versionID) {
        return getIPRegistrationAccessFormText(tiRequestId, connectionRequestId, versionID, NO);
    }
    
    /**
     * The method to retrieve IP Registration AccessFormText
     * @param tiRequestID
     * @param connectionRequestId
     * @param versionID
     * @param isObjExpandable
     * @return String Containing AccessFormText for IP Registration
     */
    @Transactional(readOnly = true)
    public String getIPRegistrationAccessFormText(Long tiRequestId, Long connectionRequestId, Long versionID, String isObjExpandable) {
        RFCRequest rfcrequest = null;
        AccessFormXsl accessFormXsl = null;
        String ipRegAccessFormText = "";
        try {           
            accessFormXsl = getConnectionInfo(tiRequestId, connectionRequestId, versionID, "IPFAF");
            accessFormXsl.setFwImplDetails(getCombinationInfo(tiRequestId, YES, rfcrequest, NO, isObjExpandable));
            ipRegAccessFormText = transformObjectXMLtoXSLTemplate(accessFormXsl, IPFAF_REQUEST_TYPE);
        } catch (Exception e) {
            log.error("Exception in getIPRegistrationAccessFormText : "+e, e);
        }
        return ipRegAccessFormText;
    }
    
    /**
     * The method to retrieve SEC ACL AccessFormText
     * @param tiRequestID
     * @param connectionRequestId
     * @param versionID
     * @return String Containing AccessFormText for SEC ACL
     */
    @Transactional(readOnly = true)
    public String getSECACLAccessFormText(Long tiRequestId, Long connectionRequestId, Long versionID) {
        AccessFormXsl accessFormXsl = null;
        String aclAccessFormText = "";
        try {
            accessFormXsl = getConnectionInfo(tiRequestId, connectionRequestId, versionID, "ACL");
            accessFormXsl.setDocDetails(getSecACLInfo(tiRequestId, connectionRequestId, versionID));
            accessFormXsl.setaCLTechnicalDetails(getSecACLTechnicalInfo(tiRequestId, connectionRequestId));
            aclAccessFormText = transformObjectXMLtoXSLTemplate(accessFormXsl, ACL_REQUEST_TYPE);
        } catch (Exception e) {
            log.error("Exception in getSECACLAccessFormText : "+e, e);          
        }
        return aclAccessFormText;
    }
    
	/**
	 * Method to retrieve Sec ACL technical details for a given TiRequestId and Process Id
	 * @param tiRequestId
	 * @param connectionRequestId
	 * @return
	 * @throws Exception
	 */
	private ACLTechnicalDetails getSecACLTechnicalInfo(Long tiRequestId, Long connectionRequestId) throws Exception {
		ACLTechnicalDetails aCLTechnicalDetails = new ACLTechnicalDetails("", "");
		String queryToExecute = ccrQueries.getQueryByName(QueryConstants.GET_SEC_ACL_TECHNICAL_DETAILS);
		SqlRowSet result = jdbcTemplate.queryForRowSet(queryToExecute,
				new Object[] { tiRequestId, connectionRequestId });
		while (result.next()) {
			aCLTechnicalDetails.setAclName(result.getString(1));
			aCLTechnicalDetails.setDeviceOrRouter(result.getString(2));
			break;
		}
		return aCLTechnicalDetails;
	}

	/**
     * The method to retrieve details for Access Form and to set in XSLT
     * @param tiRequestID
     * @param connectionRequestId
     * @param versionID
     * @param requestType
     * @return AccessFormXsl containing XSL
     */
    public AccessFormXsl getConnectionInfo(Long tiRequestId, Long connectionRequestId, Long versionID, String requestType) throws Exception {
        log.info("AccessFormGenerator to xsl : tiRequestId : "+tiRequestId+" connectionRequestId : "+connectionRequestId+" versionID : "+versionID+" requestType : "+requestType);
        AccessFormXsl accessFormXsl = new AccessFormXsl();
        
        accessFormXsl.setConID(connectionRequestId);
        accessFormXsl.setVersion(versionID);
        
        
        //Original Requester Information
        accessFormXsl.setRequestor(getRequesterDetails(connectionRequestId));
        
        long planningId = getPlanningIdForTiRequestId(tiRequestId);
        if (planningId == 0)  {
            throw new Exception(
                    " No Planning Id is associated with the TiRequestId "
                    + tiRequestId);
        }
        PlanningEntity planningEntity = new PlanningEntity();
        planningEntity = getPlanningEntity(Long.valueOf(planningId));
        
        //Business Information
        RelationshipDTO relDTO  = new RelationshipDTO();
        relDTO = getRelationshipEntity(planningEntity.getRelationshipId());
        accessFormXsl.setRelDTO(relDTO);
        accessFormXsl.setConName(planningEntity.getConnectionName());
        
        //Current cycle Requester
        accessFormXsl.setCurrCycleRequestor(getRequesterDetails(planningEntity.getId()));
        
        log.debug("Current Cycle Requestor:"+accessFormXsl.getCurrCycleRequestor());
        
        String relationshipType = getRelationshipType(connectionRequestId);
        
        //for relationship type U turn and citi con need to take contacts from Requestor contacts.
        if (C3parStaticNames.U_TURN.equalsIgnoreCase(relationshipType) || C3parStaticNames.CITI_CON.equalsIgnoreCase(relationshipType)) {
            accessFormXsl.setCurrCycleTechnicalCoordinator(proxyPersistable.getCurrentCycleTechnicalCoOrdinatorDetails(connectionRequestId));
            accessFormXsl.setTechnicalCoordinator(proxyPersistable.getOriginalTechnicalCoOrdinatorDetails(connectionRequestId));
        } else {
            accessFormXsl.setCurrCycleTechnicalCoordinator(proxyPersistable.getCurrentCycleTargetTechnicalCoOrdinatorDetails(connectionRequestId));
            accessFormXsl.setTechnicalCoordinator(proxyPersistable.getOriginalTargetTechnicalCoOrdinatorDetails(connectionRequestId));
        }
        
        
        if (versionID.longValue() == 1) {
            String just = getCurrentBusJustfication(tiRequestId);
            //Current Business Justification
            accessFormXsl.setCurrentBusJus(just);
            //Original Business Justification
            accessFormXsl.setOriginalBusJus(just);
        } else {
            //Current Business Justification
            accessFormXsl.setCurrentBusJus(getCurrentBusJustfication(tiRequestId));
            //Original Business Justification
            accessFormXsl.setOriginalBusJus(getOrigBusJustification(connectionRequestId, versionID));
        }
        
        log.debug("Original BusinessJustification:"+accessFormXsl.getOriginalBusJus());
        //Application Details
        if(PAF_REQUEST_TYPE.equalsIgnoreCase(requestType)){
            accessFormXsl.setApplicationDetails(getProxyApplicationDetails(connectionRequestId));
        } else if(FAF_REQUEST_TYPE.equalsIgnoreCase(requestType)){ 
            accessFormXsl.setApplicationDetails(getFirewallRuleApplicationDetails(tiRequestId,NO));
        }else if(IPFAF_REQUEST_TYPE.equalsIgnoreCase(requestType)){ 
            accessFormXsl.setApplicationDetails(getFirewallRuleApplicationDetails(tiRequestId,YES));
        }  else{
            accessFormXsl.setApplicationDetails(getApplicationDetails(connectionRequestId));
        }
        
        log.debug("Application Details"+accessFormXsl.getApplicationDetails());
        
        //System ID and SOW
        
        Map<String, String> sowAndCmp = getCMPAndSOWByVersionWithoutType(connectionRequestId, versionID);
        accessFormXsl.setSystemID(sowAndCmp.get("CMP") !=null ? sowAndCmp.get("CMP") : "");
        accessFormXsl.setSOW(sowAndCmp.get("SOW") !=null ?sowAndCmp.get("SOW"): "" );
        log.debug("AccessFormGenerator:CMP/SOW"+accessFormXsl.getSystemID()+accessFormXsl.getSOW());
        
        //Business Contacts Information
        accessFormXsl.setBusinessContacts(getBusinessContactsDetails(connectionRequestId, versionID));
        log.debug("AccessFormGeneration:GetRole/Business Contact Information:"+accessFormXsl.getBusinessContacts());
        
        //Special Instructions/Completion Date/Change Number
        Map<String,Object> implInfo = null;
        implInfo = getImplementationInfo(connectionRequestId, versionID, requestType);
        if (implInfo.size() > 0) {
            String changeNo = (String)implInfo.get("CHANGE_NUMBER");
            String compDate = (String)implInfo.get("COMPLETION_DATE");
            String specialIns =(String)implInfo.get("SPL_INSTR");
            Long infoman = (Long)implInfo.get("INFOMAN_ID");
            accessFormXsl.setSpecialInstructions(specialIns !=null ? specialIns :"");
            accessFormXsl.setCompletionDate(compDate !=null ? compDate :"");
            accessFormXsl.setInfomanID(infoman !=null ? infoman :0);
            accessFormXsl.setChangeNumber(changeNo !=null ? changeNo : "");
            // Added for RTC 85240
            String gisSpecialIns =(String)implInfo.get("GIS_SPL_INSTR");
            accessFormXsl.setGisSpecialInstructions(gisSpecialIns != null ? gisSpecialIns : "");
            //Added for RTC 92857
            String tpaswgSpecialIns = (String)implInfo.get("TPASWG_SPL_INSTR");
            accessFormXsl.setTpaswgSpecialInstructions(tpaswgSpecialIns != null ? tpaswgSpecialIns : "");
            
            log.debug("Special Instructions : "+accessFormXsl.getSpecialInstructions()+" : Completion Date: "+accessFormXsl.getCompletionDate()
                    +" Infoman ID: "+accessFormXsl.getInfomanID()+" : ChangeNumber:"+accessFormXsl.getChangeNumber()
                    +" GIS Special instructions : "+accessFormXsl.getGisSpecialInstructions()
                    +" TPASWG Special instructions : "+accessFormXsl.getTpaswgSpecialInstructions());
        }
        
        //Implementation Status and High Risk
        if(requestType.equalsIgnoreCase(PAF_REQUEST_TYPE)){
            String implementer = getCurrentProcess_status(connectionRequestId,versionID,ActivityData.ACTIVITY_PROXY_IMP);
            if(isProxyHighRisk(tiRequestId)==true) {
                accessFormXsl.setRiskInformation("Yes");
            }else {
                accessFormXsl.setRiskInformation("No");
            }
            if(implementer != null){
                accessFormXsl.setImplStatus(implementer);   
            }else {
                accessFormXsl.setImplStatus("Not Scheduled");
            }
            
            
        }else if(requestType.equalsIgnoreCase(AAF_REQUEST_TYPE)){
            String implementer = getCurrentProcess_status(connectionRequestId,versionID,ActivityData.ACTIVITY_APPSENSE_IMP);
            
            if(isAppsenseHighRisk(tiRequestId)==true) {
                accessFormXsl.setRiskInformation("Yes");
            }else {
                accessFormXsl.setRiskInformation("No");
            }
            if(implementer != null){
                accessFormXsl.setImplStatus(implementer);   
            }else {
                accessFormXsl.setImplStatus("Not Scheduled");
            }
        } else if(requestType.equalsIgnoreCase(ACL_REQUEST_TYPE)){
            String implementer = getCurrentProcess_status(connectionRequestId,versionID,ActivityData.ACL_VARIANCE_IMP);
            
            if(implementer != null){
                accessFormXsl.setImplStatus(implementer);   
            }else {
                accessFormXsl.setImplStatus("Not Scheduled");
            }
        } 
        log.debug("Implementation Status : "+accessFormXsl.getImplStatus());
        //Appsense AD group Details
        if(AAF_REQUEST_TYPE.equalsIgnoreCase(requestType)){
            AppsenseADGroup appsenseADGroup = (AppsenseADGroup)getAppsenseADGroupName(connectionRequestId,AAF_REQUEST_TYPE);
            if(appsenseADGroup != null){
                accessFormXsl.setAppsenseADGroup(appsenseADGroup);
            }
        }
        
        //Cab Approvers for IP and FAF
        if(FAF_REQUEST_TYPE.equalsIgnoreCase(requestType) || IPFAF_REQUEST_TYPE.equalsIgnoreCase(requestType)){
            String cabApprovers = getCabApproversList(tiRequestId);
            accessFormXsl.setCabApprovers(cabApprovers);
            log.debug("AccessFormGenerator:Cab Approvers List"+accessFormXsl.getCabApprovers());
        }
        return accessFormXsl;
    }
    

    /**
     * The method to retrieve Application Details for both Firewall and IP
     * @param tiRequestID
     * @param isIPReg
     * @return List containing Application Details for both Firewall and IP
     */
    public ArrayList getFirewallRuleApplicationDetails(Long tiRequestId,String isIPReg) {       
        String queryToExecute = "";
        Map data = null;
        ArrayList returnList = null;
        List dataList = null;
        if(isIPReg != null && isIPReg.equalsIgnoreCase(YES)){
            queryToExecute =ccrQueries.getQueryByName(QueryConstants.ACCESSFORM_GETAPPLICATIONDETAILS_IPREG);
        }
        else{
            queryToExecute =ccrQueries.getQueryByName(QueryConstants.ACCESSFORM_GETAPPLICATIONDETAILS_FW);
        }               
        returnList = new ArrayList();
        try {
            data = runQuery(queryToExecute,6,new Object[]{tiRequestId.toString(),tiRequestId.toString()});          
            log.debug("Application details for Firewall and IPreg : "+data);
        } catch (Exception e) {
            log.error("Exception in getFirewallRuleApplicationDetails : "+e.toString(), e);
        }
        int counter = 1;
        if (data != null && data.size() > 0) {
            while (counter <= data.size()) {
                dataList =  (ArrayList) data.get(Integer.valueOf(counter));
                if (dataList != null && dataList.size() > 0) {
                    Application application = new Application();
                    Person person = new Person();
                    application.setApplicationID(Long.valueOf((String) dataList.get(0)));
                    application.setApplicationName((String) dataList.get(1));
                    person.setFullName((String) dataList.get(2));
                    person.setGeid((String) dataList.get(3));
                    application.setSecClassification((String) dataList.get(4));
                    application.setPersonaDataIndicator((String) dataList.get(5));
                    application.setAppOwner(person);
                    returnList.add(application);

                }
                counter = counter + 1;
            }
        }else{
            String query = "";
            if(isIPReg != null && isIPReg.equalsIgnoreCase(YES)){
                query =ccrQueries.getQueryByName(QueryConstants.ACCESSFORM_GETAPPLICATIONDETAILS_HISTORYTABLE_IPREG);
            }
            else{
                query =ccrQueries.getQueryByName(QueryConstants.ACCESSFORM_GETAPPLICATIONDETAILS_HISTORYTABLE_FW);
            }           
            
            data = new HashMap();
            returnList = new ArrayList();
            // Application application = new Application();
            dataList = null;
            

            try {
                data = runQuery(query, 6,new Object[]{tiRequestId.toString(),tiRequestId.toString()});
                log.debug("Application details for Firewall and IPreg"+data);
                
            } catch (Exception e) {
                log.error("Exception in getFirewallRuleApplicationDetails : "+e.toString(), e);
            }
            if (data != null && data.size() > 0) {
                while (counter <= data.size()) {
                    dataList = (ArrayList) data.get(Integer.valueOf(counter));
                    if (dataList != null && dataList.size() > 0) {
                        Application application = new Application();
                        Person person = new Person();
                        application.setApplicationID(Long.valueOf((String) dataList.get(0)));
                        application.setApplicationName((String) dataList.get(1));
                        person.setFullName((String) dataList.get(2));
                        person.setGeid((String) dataList.get(3));
                        application.setSecClassification((String) dataList.get(4));
                        application.setPersonaDataIndicator((String) dataList.get(5));
                        application.setAppOwner(person);
                        returnList.add(application);

                    }
                    counter = counter + 1;
                }
            }
            
        }
        return returnList;
        
    }
    
    /**
     * The method to retrieve CabApproversList
     * @param tiRequestID
     * @return String containing CabApproversList for a tiRequestId
     */
    public String getCabApproversList(long tiRequest) {
        StringBuilder cabApprovers= new StringBuilder();
        Map data = new HashMap();
        List dataList = null;
        
        String queryToExecute =ccrQueries.getQueryByName(QueryConstants.ACCESSFORM_GETCABAPPROVERLIST);
        try {
            data = runQuery(queryToExecute, 1,new Object[]{tiRequest});
                    
        } catch (Exception e) {
            log.error("Exception in getCabApproversList : "+e, e);
        }
        
        int counter = 1;
        if (data != null && data.size() > 0) {
            while (counter <= data.size()) {
                dataList = (ArrayList) data.get(Integer.valueOf(counter));
                if (dataList != null && dataList.size() > 0) {
                    if(counter !=1 ){
                    cabApprovers.append(",");
                    }
                    cabApprovers.append(dataList.get(0));
                }
                counter = counter + 1;
            }
        }
        log.debug("cab app" +cabApprovers.toString());
        return cabApprovers.toString(); 
    }
    
    /**
     * Gets the application details.
     *
     * @param connectionRequestId
     *            the connection request id
     * @return the application details
     */
    public ArrayList getApplicationDetails(Long connectionRequestId) {

        String queryToExecute =ccrQueries.getQueryByName(QueryConstants.ACCESSFORM_GETSECACLAPPLICATIONDETAILS);
        
        Map data = new HashMap();
        ArrayList returnList = new ArrayList();
        // Application application = new Application();
        List dataList = null;

        try {
            data = runQuery(queryToExecute, 6,new Object[] {connectionRequestId.toString(),connectionRequestId.toString()});
        } catch (Exception e) {
            log.error("Exception in getApplicationDetails : "+e, e);
        }
        int counter = 1;
        if (data != null && data.size() > 0) {
            while (counter <= data.size()) {
                dataList = (ArrayList) data.get(Integer.valueOf(counter));
                if (dataList != null && dataList.size() > 0) {
                    Application application = new Application();
                    Person person = new Person();
                    application.setApplicationID(Long.valueOf((String) dataList
                            .get(0)));
                    application.setName((String) dataList.get(1));
                    person.setFullName((String) dataList.get(2));
                    person.setGeid((String) dataList.get(3));
                    application.setSecClassification((String) dataList.get(4));
                    application.setPersonaDataIndicator((String) dataList.get(5));
                    application.setAppOwner(person);
                    returnList.add(application);

                }
                counter = counter + 1;
            }
        }
        return returnList;
    }
    
    /**
     * The method is to find Appsense Risk
     * @param tiRequestID
     * @return boolean
     */
    public boolean isAppsenseHighRisk(Long tirequestId) {
        boolean isAppsenseRisk=false;       
        try {
            String queryToExecute =ccrQueries.getQueryByName(QueryConstants.ACCESSFORM_ISAPPSENSEHIGHRISK);
            //comb(1,3) in the query below represent Add/Delete combination of Appsense
            SqlRowSet result  = jdbcTemplate.queryForRowSet(queryToExecute,new Object [] {tirequestId,tirequestId});
            
            while (result.next()) {
                isAppsenseRisk = true;
                break;
            }
            
        } catch (Exception ex) {
            log.error("Exception in isAppsenseHighRisk : "+ex, ex);
        } 
        return isAppsenseRisk;
    }
    
    /**
     * The method is to find Proxy Risk
     * @param tirequestId
     * @return boolean
     */
    public boolean isProxyHighRisk(Long tirequestId) {

        boolean isProxyRisk=false;
        try {
            
            String queryToExecute =ccrQueries.getQueryByName(QueryConstants.ACCESSFORM_ISPROXYHIGHRISK);
            SqlRowSet result  = jdbcTemplate.queryForRowSet(queryToExecute,new Object [] {tirequestId,tirequestId});
            while (result.next()) {
                isProxyRisk = true;
                break;
            }
        
        } catch (Exception ex) {
            log.error("Exception in isProxyHighRisk : "+ex, ex);
        } 
        return isProxyRisk;
    }
    
    // Get the process status of the process id
    /**
     * Gets the current process_status.
     *
     * @param conReqId
     *            the con req id
     * @param version_number
     *            the version_number
     * @param taskType
     *            the task type
     * @return the current process_status
     */
    public String getCurrentProcess_status(Long conReqId, Long version_number,
            String taskType) {
        String currentProcess = null;
        currentProcess = getStatusForProcessId(conReqId, version_number);
        if (currentProcess == null) {
            currentProcess = getAppsense_Proxy_IMPL(conReqId, version_number,
                    taskType);
        }
        return currentProcess;
    }
    
    /**
     * Gets the appsense_ proxy_ impl details
     *
     * @param conReqId
     *            the con req id
     * @param versionNumber
     *            the version number
     * @param fafType
     *            the faf type
     * @return the appsense_ proxy_ impl
     */
    public String getAppsense_Proxy_IMPL(Long conReqId, Long versionNumber,
            String fafType) {
        
        String recordType = null;
        try {
            
            String queryToExecute =ccrQueries.getQueryByName(QueryConstants.ACCESSFORM_GETAPPSENSE_PROXY_IMPL);
            SqlRowSet result  = jdbcTemplate.queryForRowSet(queryToExecute,new Object[]{conReqId,versionNumber,fafType});

        while (result.next()) {
                recordType = result.getString(1);
            }
        } catch (Exception e) {
            log.error("Exception in getAppsense_Proxy_IMPL : "+e, e);
        } 
        return recordType;
    }
    
    /**
     * Gets the status for process id.
     *
     * @param conReqId
     *            the con req id
     * @param version_number
     *            the version_number
     * @return the status for process id
     */
    public String getStatusForProcessId(Long conReqId, Long version_number) {
        
        String is_deletedFlag = null;
        
        String currentProcess = null;
        try {
            
            String sql = "select IS_DELETED from c3par.ti_request where process_id=? and version_number= ? ";
            SqlRowSet result  = jdbcTemplate.queryForRowSet(sql.toString(),new Object []{conReqId,version_number});
            
            if (result != null && result.next()) {
                is_deletedFlag = result.getString(1);

            }
            is_deletedFlag = (is_deletedFlag == null) ? "" : is_deletedFlag
                    .trim();

            if (is_deletedFlag != null
                    && is_deletedFlag.trim().equalsIgnoreCase(YES)) {
                currentProcess = "ABORTED";
            }
            log.info("currentProcess is::" + is_deletedFlag+ " for CON_REQ Id::" + conReqId);
            } catch (Exception e) {
                log.error("Exception in getStatusForProcessId : "+e, e);
            }
        return currentProcess;
    }
    
    
    /**
     * Get the CMP/ServiceNOW ID and SOW Details
     * @param processId
     * @param versionNumber
     * @return
     */
    public Map<String,String> getCMPAndSOWByVersionWithoutType(Long processId,Long versionNumber) {

        
        String sow = null;
        String cmp = null;
        Map<String,String> sowAndCmp = new HashMap<String,String>();
        
        try {
            
            StringBuilder sql = new StringBuilder();
            
            sql.append("select tir.SOW_NUMBER,tir.CMP_ID,tir.SERVICE_NOW_ID from ti_request tir  ");
            sql.append("where tir.process_id=? and ");
            sql.append("tir.version_number=?  and rownum = 1 ");
            
            SqlRowSet result  = jdbcTemplate.queryForRowSet(sql.toString(),new Object [] {processId,versionNumber});
            log.debug(sql.toString());
            
            
            
            if (result.next()) {
                sow = result.getString(1);
                if (result.getString(2)!= null && !result.getString(2).isEmpty()) {
                    cmp = result.getString(2);
                } else {
                    cmp = result.getString(3);
                }
                log.info("CMP value ::"+cmp);
                if(!StringUtil.isNullorEmpty(cmp)) {
                    sowAndCmp.put("CMP",cmp);
                } else {
                    Util util =new Util();
                    Long tiRequestId = util.getTIRequestIdForVersion(processId, versionNumber.intValue());
                    String orderItemId =getOrderItemIdforTIRequest(tiRequestId);
                    log.info("tiRequestId  "+tiRequestId+"  orderItemId "+orderItemId);
                    sowAndCmp.put("CMP",orderItemId);
                }
                sowAndCmp.put("SOW",sow);
            }
        
        } catch (Exception ex) {
            log.error("Exception in getCMPAndSOWByVersionWithoutType : "+ex, ex);
        }
        log.info("getCMPAndSOWByVersionWithoutType processId:versionNumber:CMP/SOW "+ processId +":"+versionNumber+":"+cmp+"/"+sow);
        return sowAndCmp;
    }

    private String getOrderItemIdforTIRequest(long tiRequestId) {
        String cmpOrderItems = "";
        List<String> cmpOrderItemList = null;
        String orderItemIdForTiRequestQry = null;
        int count = 0;
        try {
            if (tiRequestId > 0) {
                Object[] params = { tiRequestId };
                orderItemIdForTiRequestQry = ccrQueries
                        .getQueryByName(CCRCMPMappingConstants.CMP_ORDERITEMS_FOR_TI_REQUESTID);
                cmpOrderItemList = jdbcTemplate.query(orderItemIdForTiRequestQry, params, new RowMapper<String>() {
                    public String mapRow(ResultSet rs, int rowNum) throws SQLException {
                        return rs.getString(1);
                    }
                });
                for (String cmpOrderItemId : cmpOrderItemList) {
                    if (count == cmpOrderItemList.size() - 1) {
                        cmpOrderItems = cmpOrderItems + cmpOrderItemId;
                    } else {
                        cmpOrderItems = cmpOrderItems + cmpOrderItemId + ",";
                    }
                    count++;
                }
            }
        } catch (Exception e) {
            log.error("Exception occurred in getOrderItemIdforTIRequest  : " + e.toString());
            log.error(e.toString(), e);
        }
        return cmpOrderItems;
    }
    
    /**
     * The method to retrieve Current Business Justification
     * @param tiRequestId
     * @return
     */
    public String getCurrentBusJustfication(Long tiRequestId) {
        String sql = "select con.rationale from con_req con, ti_request_planning_xref x where "+
                     "con.id=x.planning_id and x.ti_request_id= ? ";

        Map data = new HashMap();
        String currentBusJustfication="";
        List dataList = null;

        try {
            data = runQuery(sql, 1,new Object[]{tiRequestId});
        } catch (Exception e) {
            log.error("Exception in getCurrentBusJustfication : "+e, e);
        }
        int counter = 1;
        if (data != null && data.size() > 0) {
            while (counter <= data.size()) {
                dataList = (ArrayList) data.get(Integer.valueOf(counter));
                if (dataList != null && dataList.size() > 0) {
                    currentBusJustfication=(String) dataList.get(0);
                    
                }
                counter = counter + 1;
            }
        }
        return currentBusJustfication;
    }
    
    /**
     * The method is to get Rationale details by version
     * @param processId
     * @param versionNumber
     * @param type
     * @return String containing Rationale details by version
     */
    public String getRationaleByVersion(Long processId,Long versionNumber,String type) {
        String rationale = null;
        String tableName ="";
        try {
            StringBuilder sql = new StringBuilder();
            if("PAF".equalsIgnoreCase(type)){
                tableName = "PRX_PAF_HISTORY";
            } else if("AAF".equalsIgnoreCase(type)){
                tableName = "APS_IMPL_HISTORY";
            } else if("FAF".equalsIgnoreCase(type)){
                tableName = "FAF_HISTORY";
            }
            
            if("FAF".equalsIgnoreCase(type)){
                sql.append("select cr.rationale from con_req cr,");
                sql.append(tableName);
                sql.append("  h where h.con_request_id=? and ");
                sql.append(" h.version_id=? and h.planning_id=cr.id ");
            } else if("AAF".equalsIgnoreCase(type) || "PAF".equalsIgnoreCase(type)){
                sql.append("select cr.rationale from ti_request tir,ti_request_planning_xref trpx,con_req cr,");
                sql.append(tableName);
                sql.append(" h where tir.process_id=? and ");
                sql.append("h.version_id=? and tir.id=h.ti_request_id and ");
                sql.append("tir.id=trpx.ti_request_id and trpx.planning_id=cr.id ");
            }
            
            if("ACL".equalsIgnoreCase(type)){
                sql.append("select cr.rationale from ti_request tir,ti_request_planning_xref trpx,con_req cr ");
                sql.append("where tir.process_id=? and tir.version_number=? and ");
                sql.append("tir.id=trpx.ti_request_id and trpx.planning_id=cr.id ");
            }
            
            SqlRowSet result  = jdbcTemplate.queryForRowSet(sql.toString(),new Object [] {processId,versionNumber});

            if (result.next()) {
                rationale = result.getString(1);
            }
        } catch (Exception ex) {
            log.error("Exception in getRationaleByVersion : "+ex, ex);
        } 
        log.info("type : "+type+" , processId : " + processId +" , versionNumber : "+versionNumber+" , rationale : "+rationale);
        return rationale;
    }
    
    /**
     * Gets the appsense ad group name.
     *
     * @param processID
     *            the process id
     * @param type
     *            the type
     * @return the appsense ad group name
     */
    public AppsenseADGroup getAppsenseADGroupName(Long processID, String type) {

        log.info("getAppsenseADGroupName method starts");
        String appsenseADGroupName = null;
        log.debug("processID :: " + processID);
        
        String sql = null;
        if (type.equals("AAF")) {
            sql = "select name,policy_id,policy_name from  ti_ad_group_name where id in (select distinct(aih.aps_ad_group_id) from APS_IMPL_HISTORY aih where aih.process_id=?)";
        }
        if (type.equals("PAF")) {
            sql = "select name,policy_id,policy_name from  ti_ad_group_name where id in (select distinct(pph.aps_ad_group_id) from prx_paf_history pph where pph.process_id=? and pph.aps_ad_group_id <> '0')";
        }
        AppsenseADGroup apsADGroupData = new AppsenseADGroup();
        try {
            SqlRowSet result  = jdbcTemplate.queryForRowSet(sql,new Object [] {processID.longValue()});

            if (result != null) {
                if (result.next()) {
                    apsADGroupData.setName((String) result.getString(1));
                    apsADGroupData.setPolicyID((String) result.getString(2));
                    apsADGroupData.setPolicyName((String) result.getString(3));
                    log.debug("appsenseADGroupName :: " + apsADGroupData);
                }
            }
        } catch (Exception ex) {
            log.error("Exception in getAppsenseADGroupName : "+ex, ex);
        } 
        log.info("getAppsADGroupDetails method ends");
        return apsADGroupData;
    }
    
    /**
     * Gets the proxy application details.
     *
     * @param connectionRequestId
     *            the connection request id
     * @return the proxy application details
     */
    public ArrayList getProxyApplicationDetails(Long connectionRequestId) {
        log.info("getProxyApplicationDetails(Long connectionRequestId) method starts");
        String queryToExecute =ccrQueries.getQueryByName(QueryConstants.ACCESSFORM_GETPROXY_APPLICATION_DETAILS);
        
        Map data = new HashMap();
        ArrayList<Application> returnList = new ArrayList<Application>();
        List dataList = null;

        try {
            data = runQuery(queryToExecute, 6,new Object[]{connectionRequestId.toString(),connectionRequestId.toString()});
        } catch (Exception e) {
            log.error(e);
        } 
        int counter = 1;
        if (data != null && data.size() > 0) {
            while (counter <= data.size()) {
                dataList = (ArrayList) data.get(Integer.valueOf(counter));
                if (dataList != null && dataList.size() > 0) {
                    Application application = new Application();
                    Person person = new Person();
                    application.setApplicationID(Long.valueOf((String) dataList
                            .get(0)));
                    application.setName((String) dataList.get(1));
                    person.setFullName((String) dataList.get(2));
                    person.setGeid((String) dataList.get(3));
                    application.setSecClassification((String) dataList.get(4));
                    application.setPersonaDataIndicator((String) dataList.get(5));
                    application.setAppOwner(person);
                    returnList.add(application);

                }
                counter = counter + 1;
            }
        }
        log
        .info("getProxyApplicationDetails(Long connectionRequestId) method ends");
        return returnList;
    }
    
    /**
     * Gets the business contacts details.
     *
     * @param connectionRequestId
     *            the connection request id
     * @param versionNo
     *            the version no
     * @return the business contacts details
     */
    public ArrayList<Person> getBusinessContactsDetails(Long connectionRequestId,Long versionNo) {
         
        String tableName="";
        String relationshipType="";
        
        try {
            relationshipType = getRelationshipType(connectionRequestId);
        } catch (Exception e1) {
            log.error("Exception in getBusinessContactsDetails : "+e1, e1);
        }
        if(relationshipType.equalsIgnoreCase("U_TURN") || relationshipType.equalsIgnoreCase("CITI_CON")){
            
            tableName="con_req_cit_rqcon_xref";
        }else {
            tableName="con_req_citi_contact_xref";
        }
            String sql = "SELECT distinct  rr.display_name,cc.first_name || ' ' || cc.last_name biso_name, cc.rits_id rits_id, cc.geid FROM ti_request_planning_xref trpx, ti_request tr, "+tableName+" crccx,planning p,citi_contact cc,role rr WHERE tr.process_id = ?"
                        + " AND trpx.ti_request_id = tr.id and tr.version_number = ?"
                        + " and trpx.planning_id = p.id and crccx.request_id = p.id and crccx.citi_contact_id = cc.id and crccx.role_id=rr.id and crccx.primary_contact = 'Y' and rr.name in ('Business_Owner','BISO','Business_Tester','Requestor')";
        
        Map data = new HashMap();
        List dataList = null;
        ArrayList<Person> returnList = new ArrayList<Person>();
        
        
        try {
            data = runQuery(sql, 4,new Object[]{connectionRequestId.toString(),versionNo});
        } catch (Exception e) {
            log.error("Exception in getBusinessContactsDetails : "+e, e);
        }
        int counter = 1;
        if (data != null && data.size() > 0) {
            while (counter <= data.size()) {
                dataList = (ArrayList) data.get(Integer.valueOf(counter));
                if (dataList != null && dataList.size() > 0) {
                    Person person = new Person();
                    Role role = new Role();
                    role.setName((String)dataList.get(0));
                    person.setRole(role);
                    person.setFullName((String) dataList.get(1));
                    person.setGeid((String) dataList.get(3));
                    returnList.add(person);
                }
                counter = counter + 1;
            }
        }
        return returnList;
    }
    
    /**
     * Gets the relationship type.
     *
     * @param conReqId
     *            the con req id
     * @return the relationship type
     * @throws Exception
     *             the exception
     */
    public String getRelationshipType(Long conReqId) throws Exception {
        String relationshipType = null;
        try {
            String sql = "SELECT B.RELATIONSHIP_TYPE FROM CON_REQ A,RELATIONSHIP B WHERE A.RELATIONSHIP_ID=B.ID AND A.ID =?";
            SqlRowSet result  = jdbcTemplate.queryForRowSet(sql,new Object [] {conReqId});
            if (result != null && result.next()) {
                relationshipType = result.getString(1);
            }
            relationshipType = (relationshipType == null) ? "": relationshipType.trim();
            log.info("relationshipType is::" + relationshipType+ "for CON_REQ Id::" + conReqId);
        } catch (Exception e) {
            log.error("Exception in getRelationshipType : "+e, e);
        } 
        return relationshipType;
    }
    
    /**
     * Gets the implementation info.
     *
     * @param processId
     *            the process id
     * @param versionId
     *            the version id
     * @param reqType
     *            the req type
     * @return the implementation info
     */
    public Map<String,Object> getImplementationInfo(Long processId, Long versionId, String reqType) {
        log.info("Get implementation info starts here : reqType : "+reqType +" processId : "+processId +" verisonId : "+versionId);
        HashMap<String,Object> reviewInfo = new HashMap<String,Object>();
        String queryToExecute = "";
        try {
            if (reqType.equalsIgnoreCase("AAF")) {
                queryToExecute =ccrQueries.getQueryByName(QueryConstants.ACCESSFORM_AAFIMPLINFO);
            } else if (reqType.equalsIgnoreCase("PAF")) {
                queryToExecute =ccrQueries.getQueryByName(QueryConstants.ACCESSFORM_PAFIMPLINFO);
            } else if (reqType.equalsIgnoreCase("FAF")) {
                queryToExecute =ccrQueries.getQueryByName(QueryConstants.ACCESSFORM_FAFIMPLINFO);
            } else if (reqType.equalsIgnoreCase("IPFAF")) {
                queryToExecute =ccrQueries.getQueryByName(QueryConstants.ACCESSFORM_IPFAFIMPLINFO);
            } else if (reqType.equalsIgnoreCase("ACL")) {
                queryToExecute =ccrQueries.getQueryByName(QueryConstants.ACCESSFORM_ACLIMPLINFO);
            }
            SqlRowSet result = null;
            if (reqType.equalsIgnoreCase("FAF") || reqType.equalsIgnoreCase("PAF")) {
                result  = jdbcTemplate.queryForRowSet(queryToExecute,new Object[]{processId,versionId,processId,versionId,processId,versionId});
            }else{
                result  = jdbcTemplate.queryForRowSet(queryToExecute,new Object[]{processId,versionId});
            }
            
            if (null != result && result.next()) {
                if (reqType.equalsIgnoreCase("IPFAF")) {
                    //Modified for task:45874 - added setter part
                    if (result.getString(1) != null) {
                        reviewInfo.put("SPL_INSTR", result.getString(1));
                    } else {
                        reviewInfo.put("SPL_INSTR", "");
                    }
                    if (result.getDate(2) != null) {
                        Date dt = result.getDate(2);
                        
                        reviewInfo.put("COMPLETION_DATE", (sdf.format(dt) ));
                    } else {
                        reviewInfo.put("COMPLETION_DATE", "");
                    }
                    if(result.getString(3)!=null){
                        reviewInfo.put("INFOMAN_ID",Long.valueOf(result.getString(3)));
                    }else{
                        reviewInfo.put("INFOMAN_ID",0L);
                    }
                } else {
                    if (result.getString(1) != null) {
                        reviewInfo.put("SPL_INSTR", result.getString(1));
                    } else {
                        reviewInfo.put("SPL_INSTR", "");
                    }
                    if (result.getDate(2) != null) {
                        Date dt = result.getDate(2);
                        reviewInfo.put("COMPLETION_DATE",(sdf.format(dt)));
                    } else {
                        reviewInfo.put("COMPLETION_DATE", "");
                    }
                    if(result.getString(3)!=null){
                        reviewInfo.put("INFOMAN_ID",Long.valueOf(result.getString(3)));
                    }else{
                        reviewInfo.put("INFOMAN_ID",0L);
                    }
                }
                // Added for RTC 85240
                if (reqType.equalsIgnoreCase("FAF") || reqType.equalsIgnoreCase("PAF")) {
                    if(result.getString(4) != null){
                        log.info("GIS special instructions from DB : "+result.getString(4));
                        reviewInfo.put("GIS_SPL_INSTR", result.getString(4));
                    }else{
                        reviewInfo.put("GIS_SPL_INSTR","");
                    }
                }
                
                // Added for RTC 92857
                if (reqType.equalsIgnoreCase("FAF") || reqType.equalsIgnoreCase("PAF")) {
                    if(result.getString(5) != null){
                        log.info("TPASWG special instructions from DB : "+result.getString(5));
                        reviewInfo.put("TPASWG_SPL_INSTR", result.getString(5));
                    }else{
                        reviewInfo.put("TPASWG_SPL_INSTR","");
                    }
                }
            }
            if(reqType.equalsIgnoreCase("PAF")){
                String changeno = "";
                String sql1 = "select rfc_id from rfc_request where ti_request_id in (select id from ti_request where process_id =" +processId+ " and version_number = "+versionId+" ) and rfc_type = 'Proxy'";
                SqlRowSet result1  = jdbcTemplate.queryForRowSet(sql1.toString());
                
                while(result1.next()) {
                    if (result1.getString(1) != null) {
                        if (changeno.isEmpty()) {
                            changeno = result1.getString(1);
                        }
                        changeno = changeno + "," + result1.getString(1);
                    }
                }
                reviewInfo.put("CHANGE_NUMBER", changeno);
                
            }else if(reqType.equalsIgnoreCase("FAF")){
                
                String sql1 = "select rfc_id from rfc_request where ti_request_id in (select id from ti_request where process_id =" +processId+ " and version_number = "+versionId+" ) and upper(rfc_type) = upper('Firewall') and is_ipreg = 'N' ";
                SqlRowSet result1  = jdbcTemplate.queryForRowSet(sql1.toString());
                
                if(result1.next()) {
                    reviewInfo.put("CHANGE_NUMBER", result1.getString(1));
                }
            }else if(reqType.equalsIgnoreCase("IPFAF")){
                
                String sql1 = "select rfc_id from rfc_request where ti_request_id in (select id from ti_request where process_id =" +processId+ " and version_number = "+versionId+" ) and upper(rfc_type) = upper('Firewall') and is_ipreg = 'Y' ";
                SqlRowSet result1  = jdbcTemplate.queryForRowSet(sql1.toString());
                if(result1.next()) {
                    reviewInfo.put("CHANGE_NUMBER", result1.getString(1));
                }
            }
        } catch (Exception ex) {
            log.error("Exception in getImplementationInfo : "+ex.toString(), ex);
        } 
        log.debug("GetImplementationInfo:"+reviewInfo.get("CHANGE_NUMBER")+" completion "+reviewInfo.get("COMPLETION_DATE")+" Infoman "+reviewInfo.get("INFOMAN_ID"));
        return reviewInfo;
    }
    
    /**
     * Gets the orig bus justification.
     *
     * @param connectionRequestId
     *            the connection request id
     * @param versionID
     *            the version id
     * @return the orig bus justification
     */
    @Transactional(readOnly = true)
    public String getOrigBusJustification(Long connectionRequestId,
            Long versionID) {

        String sql = "SELECT CONREQ.RATIONALE " 
                +" FROM TI_REQUEST_PLANNING_XREF TXREF,TI_REQUEST TREQ,CON_REQ CONREQ "
                +" WHERE TXREF.PLANNING_ID = ? "
                +"  AND TREQ.ID = TXREF.TI_REQUEST_ID AND CONREQ.ID = TREQ.PROCESS_ID";
        Map data = new HashMap();
        String busJustification = "";
        List dataList = null;

        try {
            data = runQuery(sql.toString(), 1,new Object[]{connectionRequestId});
        } catch (Exception e) {
            log.error("Exception in getOrigBusJustification : "+e, e);
        }
        int counter = 1;
        if (data != null && data.size() > 0) {
            while (counter <= data.size()) {
                dataList = (ArrayList) data.get(Integer.valueOf(counter));
                if (dataList != null && dataList.size() > 0) {
                    busJustification=(String) dataList.get(0);
                }
                counter = counter + 1;
            }
        }
        log.debug("GetOriginalBusinessJustification.."+busJustification);
        return busJustification;
    }
    
    /**
     * Gets the planning id for ti request id.
     *
     * @param tiRequestId
     *            the ti request id
     * @return the planning id for ti request id
     * @throws Exception
     *             the exception
     */
    public long getPlanningIdForTiRequestId(Long tiRequestId) throws Exception {
        long planningId = 0;
        
        if (tiRequestId != null && tiRequestId.longValue() > 0) {
            try {
                
                String sql = "select planning_id from c3par.ti_request_planning_xref where ti_request_id=?";
                SqlRowSet rs  = jdbcTemplate.queryForRowSet(sql.toString(),new Object [] {tiRequestId.longValue()});

                if (rs.next()) {
                    planningId = rs.getLong(1);
                }
                if (planningId == 0) {
                    String planTermSQL = " select max(planning_id) from c3par.ti_request_planning_xref where ti_request_id in (select b.id from c3par.ti_request a ,c3par.ti_request b where a.id=?  and a.process_id=b.process_id ) ";
                    SqlRowSet rs1  = jdbcTemplate.queryForRowSet(planTermSQL.toString(),new Object [] {tiRequestId.longValue()});;
                    
                    if (rs1.next()) {
                        planningId = rs1.getLong(1);
                    }
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        log.debug("Planning Id is " + planningId + " for tiRequestID "+ tiRequestId);
        return planningId;

    }
    
    /**
     * Gets the requester details.
     *
     * @param connectionRequestId
     *            the connection request id
     * @return the requester details
     */
    public Person getRequesterDetails(Long connectionRequestId) {

        String sql = "SELECT d.FIRST_NAME || ' ' || d.LAST_NAME name, d.SSO_ID soe_id, d.EMAIL e_mail FROM con_req a, c3par_users d WHERE A.ID = ?"
                    + " AND upper(a.requester_id) = upper(d.SSO_ID)";

        Map data = new HashMap();
        Person person = new Person();
        List dataList = null;

        try {
            data = runQuery(sql, 3,new Object[]{connectionRequestId.toString()});
        } catch (Exception e) {
            log.error("Exception in getRequesterDetails : "+e, e);
        }
        int counter = 1;
        if (data != null && data.size() > 0) {
            while (counter <= data.size()) {
                dataList = (ArrayList) data.get(Integer.valueOf(counter));
                if (dataList != null && dataList.size() > 0) {
                    person.setFullName((String) dataList.get(0));
                    person.setSoeID((String) dataList.get(1));
                    person.setEmailAddress((String) dataList.get(2));

                }
                counter = counter + 1;
            }
        }
        return person;
    }
    
    /**
     * Run query.
     *
     * @param statement the statement
     * @param columns the columns
     * @param type the type
     * @param c3parSession the c3par session
     * @param isTransaction the is transaction
     * @return the map
     * @throws Exception the exception
     */
    public Map runQuery(String statement, int columns) throws Exception {
        
            Map data = null;
            List dataList = null;
            int counter = 0;
            int rowId = 0;
            
            try {
                SqlRowSet result  = jdbcTemplate.queryForRowSet(statement);

                
                if (result != null) {
                    while (result.next()) {
                        if (data == null)
                            data = new HashMap();
                        rowId = rowId + 1;
                        counter = 1;
                        dataList = new ArrayList();
                        dataList.add(result.getString(counter));
                        data.put(Integer.valueOf(rowId), dataList);
                        while (counter < columns) {
                            counter = counter + 1;
                            dataList.add(result.getString(counter));
                        }
                    }
                
            } 
        } catch (Exception e) {
            log.error("Exception in runQuery : "+e, e);
        } 
        return data;
        

    }
    
    /**
     * Run query.
     *
     * @param statement the statement
     * @param columns the columns
     * @return the map
     * @throws Exception the exception
     */
    public Map runQuery(String statement, int columns,Object obj[]) throws Exception {
        
            Map data = null;
            List dataList = null;
            int counter = 0;
            int rowId = 0;
            
            try {
                SqlRowSet result  = jdbcTemplate.queryForRowSet(statement,obj);

                
                if (result != null) {
                    while (result.next()) {
                        if (data == null)
                            data = new HashMap();
                        rowId = rowId + 1;
                        counter = 1;
                        dataList = new ArrayList();
                        dataList.add(result.getString(counter));
                        data.put(Integer.valueOf(rowId), dataList);
                        while (counter < columns) {
                            counter = counter + 1;
                            dataList.add(result.getString(counter));
                        }
                    }
                
            } 
        } catch (Exception e) {
            log.error("Exception in runQuery : "+e, e);
        } 
        return data;
        

    }
    /**
     * Gets the planning entity.
     *
     * @param planningId the planning id
     * @return the planning entity
     */
    private PlanningEntity getPlanningEntity(Long planningId) {
        PlanningEntity planningEntity = new PlanningEntity();
        
        try {
            
            String sql ="select ID,RELATIONSHIP_ID,CONNECTION_NAME,RATIONALE from con_req where id=?";
            SqlRowSet rs  = jdbcTemplate.queryForRowSet(sql,new Object [] {planningId});

            if (rs.next()) {
                planningEntity.setId(Long.valueOf(rs.getLong(1)));
                planningEntity.setRelationshipId(Long.valueOf(rs.getLong(2)));
                planningEntity.setConnectionName(rs.getString(3));
                planningEntity.setRationale(rs.getString(4));
            }

        } catch (Exception e) {
            log.error("Exception in getPlanningEntity : "+e, e);
        }
        return planningEntity;
    }
    
    /**
     * Gets the relationship entity.
     *
     * @param planningId the planning id
     * @return the relationship entity
     */
    private RelationshipDTO getRelationshipEntity(Long planningId) {
        RelationshipDTO relDTO = new RelationshipDTO();
        
        StringBuilder sql = new StringBuilder();
        
        try {
            
            sql.append("SELECT DISTINCT REL.ID,REL.NAME,BU.BUSINESS_NAME  ");
            sql.append("FROM C3PAR.RELATIONSHIP REL ");
            sql.append("JOIN C3PAR.REL_CITI_HIERARCHY_XREF RXREF  ");
            sql.append("ON RXREF.RELATIONSHIP_ID = REL.ID ");
            sql.append("JOIN C3PAR.CITI_HIERARCHY_MASTER CITIHIERARCHYMASTER ");
            sql.append("ON CITIHIERARCHYMASTER.ID = RXREF.CITI_HIERARCHY_MASTER_ID ");
            sql.append("JOIN C3PAR.BUSINESS_UNIT BU ");
            sql.append("ON CITIHIERARCHYMASTER.BU_ID =BU.ID ");
            sql.append("WHERE REL.ID = ? ");
            
            SqlRowSet rs  = jdbcTemplate.queryForRowSet(sql.toString(),new Object [] {planningId});
            if (rs.next()) {
                relDTO.setId(Long.valueOf(rs.getLong(1)));
                relDTO.setName(rs.getString(2));
                relDTO.setBusinessName(rs.getString(3));
            }

        } catch (Exception e) {
            log.error("Exception in getRelationshipEntity : "+e, e);
        } 
        return relDTO;

    }
    
    public List<FafAccessForm> getCombinationInfo(Long tiRequestId, String isIPReg, RFCRequest rfcRequest, String isRFC){
        return getCombinationInfo(tiRequestId, isIPReg, rfcRequest, isRFC, NO);
    }
    
    /**
     * Gets the FAF combination info.
     *
     * @param tiRequest the ti request
     * @return the combination info
     */
    public List<FafAccessForm> getCombinationInfo(Long tiRequestId, String isIPReg, RFCRequest rfcRequest, String isRFC, String isObjExpandable){
        log.debug("getCombinationInfo "+tiRequestId);
        FAFRequest fafRequest = new FAFRequest() ;
        TIRequest tiRequest =null;
        if(TransactionSynchronizationManager.isActualTransactionActive()){
         tiRequest = fafRequest.getTIRequest(tiRequestId);
        }else{
          tiRequest = fafRequest.getTIRequestForGlobalTx(tiRequestId);  
        }
        fafRequest.setTiRequest(tiRequestId);
        fafRequest.setIsIPReg(isIPReg);
        fafRequest.setType("N");
        String fireflowFlag = NO;
        fireflowFlag = tiRequest.getFireflowFlag();
        List<FafAccessForm> fwImplDetailsList = new ArrayList<FafAccessForm>();
        
        if (NO.equals(fireflowFlag)) {
            List<FafFirewallRule> fireWallRuleList = null;
            try{
                if(isRFC != null && isRFC.equalsIgnoreCase(NO)){
                    fireWallRuleList=fafRequest.findRequestedRulesByRequest();                  
                }else{
                    fireWallRuleList=fafRequest.findRequestedRulesByLocation(rfcRequest.getRfcLocationID().getId(), tiRequestId, isIPReg, rfcRequest.getRequestType());
                }
            }catch(Exception e){
                log.error("Exception in getCombinationInfo : "+e, e);       
            }
            int ctr = 1;
            if(fireWallRuleList!=null){
                for (FafFirewallRule fafFireWallRule : fireWallRuleList) {
                    fwImplDetailsList.add(getDescription(fafRequest,tiRequestId,fafFireWallRule, fireflowFlag, ctr, isObjExpandable));
                    ctr++;
                }
            }
        } 
        return fwImplDetailsList;
    }
    
    /**
     * The method to get Firewall/IP Rule details 
     * @param tiRequest the ti request
     * @return the FafAccessForm info
     */
    private FafAccessForm getDescription(FAFRequest fafRequest, long TiRequest,Object obj, String fireflowFlag, int ctr, String isObjExpandable) {
        log.info("AccessFormGenerator :getDescription() method starts here ..");
        
        FafFirewallRule fafFireWallRule = new FafFirewallRule();
        StringBuilder firewallNames = new StringBuilder();
        String objectNameSIP = "";
        String objectNamePORT= "";
        StringBuilder sourceIP = new StringBuilder();
        StringBuilder destIP = new StringBuilder();
        StringBuilder port = new StringBuilder();
        StringBuilder protocol = new StringBuilder();
        String type = "";
        String fwGrp = "";
        FafAccessForm fwImplDetails = new FafAccessForm();
        fwImplDetails.setCombination(ctr++);
        
        if (NO.equals(fireflowFlag)) {
            fafFireWallRule = (FafFirewallRule) obj ;
            //fwType = fafFireWallRule.getPolicy().getFwType();
            type =String.valueOf(fafFireWallRule.getFafFireFlowTicket().getType());
            List<FafFirewallRulePolicy> fafFirewallRulePolicies = fafFireWallRule.getPolicies();

            int fCount = 0;
            for (FafFirewallRulePolicy fafFirewallRulePolicy:fafFirewallRulePolicies) {
                List<Firewall> firewallList= fafFirewallRulePolicy.getFirewallPolicy().getFirewalls();
                for (Firewall firewall : firewallList) {
                    firewallNames.append(firewall.getFirewallName());
                    fCount++;
                    if (fCount < firewallList.size()) {
                        firewallNames.append(" / ");
                    }
                }
            }
            fafFireWallRule.getFafFireFlowTicket().getType();
            if (fafFireWallRule.getFireWallRule() != null &&
                    fafFireWallRule.getFireWallRule().getSourceObject() != null ) {
                objectNameSIP = fafFireWallRule.getFireWallRule().getSourceObject().getIpAddress();
            }
            if (fafFireWallRule.getSourceNetworkZone() != null && fafFireWallRule.getSourceNetworkZone().getName().length() > 0) {
                fwImplDetails.setSrcZone(fafFireWallRule.getSourceNetworkZone().getName()+" "+objectNameSIP);
            }
            
            if (fafFireWallRule.getFireWallRule() != null &&
                    fafFireWallRule.getFireWallRule().getPortObject() != null ) {
                objectNamePORT = fafFireWallRule.getFireWallRule().getPortObject().getPortNumber();
            }
            List<FafFirewallRuleSourceIP> sourceIPs = fafFireWallRule.getSourceIPs();
            if (sourceIPs != null && !sourceIPs.isEmpty()) {
                for (FafFirewallRuleSourceIP fafFireWallRuleSourceIP : sourceIPs) { 
                    String templateFlag = fafFireWallRuleSourceIP.getIpAddress().getTemplateFlag();
                    if(null!=fafFireWallRuleSourceIP.getSourceIpsGroupName() && null!=fafFireWallRuleSourceIP.getSourceIpsGroupName().getIpGroupName()){
                        fwImplDetails.setSrcIPGroupName(fafFireWallRuleSourceIP.getSourceIpsGroupName().getIpGroupName());
                    }
                    if(isObjExpandable != null && isObjExpandable.equalsIgnoreCase("Y")
                            && templateFlag != null && templateFlag.equalsIgnoreCase("Y")){
                        List<FireWallRuleIP>  fireWallRuleIP = fafRequest.getIPsforTemplateObject(fafFireWallRuleSourceIP.getIpAddress().getId(), fafFireWallRuleSourceIP.getObjRuleID(), "N", fafRequest.getTiRequest());
                        //add template Ips into faf
                        for(FireWallRuleIP fireWallRuleSourceIP:fireWallRuleIP){
                            addTemplateIPs(sourceIP, fireWallRuleSourceIP, TiRequest);
                        }                   
                    }
                    else{
                        addSourceIP(sourceIP, fafFireWallRuleSourceIP, TiRequest);
                    }
                }
                fwImplDetails.setSrcIP(sourceIP.toString());

            }
            if (fafFireWallRule.getDestinationNetworkZone() != null && fafFireWallRule.getDestinationNetworkZone().getName().length() > 0) {
                fwImplDetails.setDestZone(fafFireWallRule.getDestinationNetworkZone().getName());
            }

            List<FafFirewallRuleDestinationIP> destinationIPs = fafFireWallRule.getDestinationIPs();
            if (destinationIPs != null && !destinationIPs.isEmpty())  {
                for (FafFirewallRuleDestinationIP fafFireWallRuleDestinationIP : destinationIPs) {
                    String templateFlag = fafFireWallRuleDestinationIP.getIpAddress().getTemplateFlag();
                    if(null!=fafFireWallRuleDestinationIP.getDestIpsGroupName() && null!=fafFireWallRuleDestinationIP.getDestIpsGroupName().getIpGroupName()){
                        fwImplDetails.setDestIPGroupName(fafFireWallRuleDestinationIP.getDestIpsGroupName().getIpGroupName());
                    }
                    if(isObjExpandable != null && isObjExpandable.equalsIgnoreCase("Y")
                            && templateFlag != null && templateFlag.equalsIgnoreCase("Y")){
                        List<FireWallRuleIP>  fireWallRuleIP = fafRequest.getIPsforTemplateObject(fafFireWallRuleDestinationIP.getIpAddress().getId(), fafFireWallRuleDestinationIP.getObjRuleID(), "N", fafRequest.getTiRequest());
                        //add template Ips into faf
                        for(FireWallRuleIP fireWallRuleDestIP:fireWallRuleIP){
                            addTemplateIPs(destIP, fireWallRuleDestIP, TiRequest);
                        }                   
                    }
                    else{
                        addDestinationIP(destIP,fafFireWallRuleDestinationIP,TiRequest);
                    }                   
                }
                
                fwImplDetails.setDestIP(destIP.toString());
            }
            List<FafFirewallRulePort> ports = fafFireWallRule.getPorts();

            if (ports != null && !ports.isEmpty()) {
                for (FafFirewallRulePort fafFireWallRulePort : ports) {
                    String templateFlag = fafFireWallRulePort.getPort().getTemplateFlag();
                    if(null!=fafFireWallRulePort.getPortsGroupName() && null!=fafFireWallRulePort.getPortsGroupName().getPortGroupName()){
                        fwImplDetails.setPortsGroupName(fafFireWallRulePort.getPortsGroupName().getPortGroupName());
                    }
                    if(isObjExpandable != null && isObjExpandable.equalsIgnoreCase("Y")
                            && templateFlag != null && templateFlag.equalsIgnoreCase("Y")){
                        List<FireWallRulePort>  fireWallRulePort = fafRequest.getPortsforTemplateObject( fafFireWallRulePort.getPort().getId(), fafFireWallRulePort.getObjRuleID(), "N", fafRequest.getTiRequest());
                        for(FireWallRulePort newFireWallRulePort:fireWallRulePort){
                            addTemplatePort(port, newFireWallRulePort, TiRequest);
                        }                       
                    }
                    else{
                        addPort(port, fafFireWallRulePort, TiRequest);
                    }
                }
                fwImplDetails.setPorts(port.toString()+" "+objectNamePORT);
            }
            if(fafFireWallRule.getFireWallRule() != null && fafFireWallRule.getFireWallRule().getRuleNumber() != null){
                fwImplDetails.setTupleNo(fafFireWallRule.getFireWallRule().getRuleNumber());
            }
            
            if(fafFireWallRule.getPolicies() != null && !fafFireWallRule.getPolicies().isEmpty()){
                List<FafFirewallRulePolicy> firewallRulePolicies = fafFireWallRule.getPolicies();
                StringBuilder policyName = new StringBuilder();
                for (FafFirewallRulePolicy fafFirewallRulePolicy : firewallRulePolicies) {
                    policyName.append(fafFirewallRulePolicy.getFirewallPolicy());
                    if (fafFirewallRulePolicy.getUpdatedTIRequest() != null && TiRequest != fafFirewallRulePolicy
                            .getUpdatedTIRequest().getId()) {
                        policyName.append(" *");
                    }                   
                }
                fwImplDetails.setFwPolicyName(policyName.toString());
            }
            if(fafFireWallRule.getPolicies() != null && !fafFireWallRule.getPolicies().isEmpty()){
                List<FafFirewallRulePolicy> firewallRulePolicies = fafFireWallRule.getPolicies();
                for (FafFirewallRulePolicy fafFirewallRulePolicy : firewallRulePolicies) {
                    fwImplDetails.setFwType(fafFirewallRulePolicy.getFirewallPolicy().getFwType());                 
                    //fwType.append("\n ");
                }
            }   
            
            //FAF Generation Changes for Allow/Deny : SRI - 19-Apr-2015
            if(fafFireWallRule != null && fafFireWallRule.getRuleType() != null){
                fwImplDetails.setRuleType(fafFireWallRule.getRuleType().equalsIgnoreCase("A")?"ALLOW":"DENY");
            }
            
            if(fafFireWallRule != null && !StringUtil.isNullorEmpty(fafFireWallRule.getSpecialInstruction())) {
            	fwImplDetails.setSpecialInstruction(fafFireWallRule.getSpecialInstruction());
            }
        } 
        if (!"".equals(type)){
            if("A".equals(type)){
                fwImplDetails.setReqType("ADD");
            }
            if("D".equals(type)){
                fwImplDetails.setReqType("DELETE");
            }
        }
        //Ostia/HighRisk:Task 35296 
        
        if(fafFireWallRule.getFireWallRule()!=null && fafFireWallRule.getFireWallRule().getRiskyRule()!=null){
            if(fafFireWallRule.getFireWallRule().getRiskyRule().equalsIgnoreCase(YES)){
                fwImplDetails.setOstiaRisk("Yes");
            }
            else{
                fwImplDetails.setOstiaRisk("No");
            }
        }
        log.debug("AccessFormGenerator:FAF Access Form details... "+fwImplDetails.getCombination()+"srczone : "+fwImplDetails.getSrcZone()+
                " srcIP : "+fwImplDetails.getSrcIP()+" tupleNumber : "+fwImplDetails.getTupleNo()+" dest zone : "+fwImplDetails.getDestZone()+" : DestIP : "+fwImplDetails.getDestIP()+
                " RequestType"+fwImplDetails.getReqType()+" Port : "+fwImplDetails.getPorts()+" Risk : "+fwImplDetails.getOstiaRisk()+" Policy : "+fwImplDetails.getFwPolicyName());
        return fwImplDetails;

    }
    
    private void addSourceIP(StringBuilder sourceIP, FafFirewallRuleSourceIP fafFireWallRuleSourceIP,long TiRequest){
        sourceIP.append(fafFireWallRuleSourceIP.getIpAddress().getIpAddress());
        if(fafFireWallRuleSourceIP.getNAT()!=null){
            sourceIP.append(" NAT - "+fafFireWallRuleSourceIP.getNAT());
        }
        if (fafFireWallRuleSourceIP.getObjRuleID() != null
                && fafFireWallRuleSourceIP.getObjRuleID().longValue() > 0) {
            if(fafFireWallRuleSourceIP.getIpAddress().getAFAObjectName() != null){
                sourceIP.append(" ("+ fafFireWallRuleSourceIP.getIpAddress().getAFAObjectName() + ")");
            }else{
                sourceIP.append(" ()");
            }
        }
        if (fafFireWallRuleSourceIP.getUpdatedTIRequest() != null &&
                TiRequest != fafFireWallRuleSourceIP.getUpdatedTIRequest().getId()) {
            sourceIP.append("  *");
        }
        if("Y".equals(fafFireWallRuleSourceIP.getIpAddress().getTpaFlag())){
            sourceIP.append("(TPA)");
        }
        if("Y".equals(fafFireWallRuleSourceIP.getIpAddress().getOfacFlag())){
            sourceIP.append("(OFAC)");
    }
        sourceIP.append("\n");
    }
    private void addTemplateIPs(StringBuilder ips, FireWallRuleIP fireWallRuleIP,long TiRequest){
        ips.append(fireWallRuleIP.getIpAddress().getIpAddress());
        if(fireWallRuleIP.getNAT()!=null){
            ips.append(" NAT - "+fireWallRuleIP.getNAT());
        }
        if (fireWallRuleIP.getObjRuleID() != null
                && fireWallRuleIP.getObjRuleID().longValue() > 0) {
            if(fireWallRuleIP.getIpAddress().getAFAObjectName() != null){
                ips.append(" ("+ fireWallRuleIP.getIpAddress().getAFAObjectName() + ")");
            }else{
                ips.append(" ()");
            }           
        }
        if (fireWallRuleIP.getUpdatedTIRequest() != null &&
                TiRequest != fireWallRuleIP.getUpdatedTIRequest().getId()) {
            ips.append("  *");
        }
        ips.append("\n");
    }   
    private void addDestinationIP(StringBuilder destIP, FafFirewallRuleDestinationIP fafFireWallRuleDestinationIP,long TiRequest){
        destIP.append(fafFireWallRuleDestinationIP.getIpAddress().getIpAddress());
        if(fafFireWallRuleDestinationIP.getNAT()!=null){
            destIP.append(" NAT - "+fafFireWallRuleDestinationIP.getNAT()
                    );
        }
        if (fafFireWallRuleDestinationIP.getObjRuleID() != null
                && fafFireWallRuleDestinationIP.getObjRuleID().longValue() > 0) {
            if( fafFireWallRuleDestinationIP.getIpAddress().getAFAObjectName() != null){
                destIP.append(" ("+ fafFireWallRuleDestinationIP.getIpAddress().getAFAObjectName() + ")");
            }else{
                destIP.append(" ()");
            }           
        }
        if (fafFireWallRuleDestinationIP.getUpdatedTIRequest() != null &&
                TiRequest != fafFireWallRuleDestinationIP.getUpdatedTIRequest().getId()) {
            destIP.append("  *");
        }
        if("Y".equals(fafFireWallRuleDestinationIP.getIpAddress().getTpaFlag())){
            destIP.append("(TPA)");
        }
        if("Y".equals(fafFireWallRuleDestinationIP.getIpAddress().getOfacFlag())){
            destIP.append("(OFAC)");}

        destIP.append("\n");
    }

    private void addPort(StringBuilder port, FafFirewallRulePort fafFireWallRulePort,long TiRequest){
        if (fafFireWallRulePort.getObjRuleID() != null
                && fafFireWallRulePort.getObjRuleID().longValue() > 0) {
            port.append(fafFireWallRulePort.getPort().toString());
            if(fafFireWallRulePort.getPort().getAFAObjectName()!= null){
                port.append(" (" + fafFireWallRulePort.getPort().getAFAObjectName() + ")");
            }else{
                port.append(" ()");
            }
        } else {
            if (fafFireWallRulePort.getPort().getProtocol().endsWith("_UUID")) {
                String port1 = fafFireWallRulePort.getPort().toString();
                if (fafFireWallRulePort.getServiceName() != null) {
                    port.append(port1).append("\t").append("|").append("\t")
                            .append(fafFireWallRulePort.getServiceName());
                } else {
                    port.append(port1);
                }
            } else {
                port.append(fafFireWallRulePort.getPort().toString());
            }
        }
        if (fafFireWallRulePort.getUpdatedTIRequest() != null &&
                TiRequest != fafFireWallRulePort.getUpdatedTIRequest().getId()) {
            port.append("  *");
        }
        port.append("\n");
    }
    private void addTemplatePort(StringBuilder port, FireWallRulePort fireWallRulePort,long TiRequest){
        if (fireWallRulePort.getObjRuleID() != null
                && fireWallRulePort.getObjRuleID().longValue() > 0) {
            port.append(fireWallRulePort.getPort().toString());
            if(fireWallRulePort.getPort().getAFAObjectName() != null){
                port.append(" ("+ fireWallRulePort.getPort().getAFAObjectName() + ")");
            }else{
                port.append(" ()");
            }           
        } else {
            port.append(fireWallRulePort.getPort().toString());
        }
        if (fireWallRulePort.getUpdatedTIRequest() != null &&
                TiRequest != fireWallRulePort.getUpdatedTIRequest().getId()) {
            port.append("  *");
        }
        port.append("\n");
    }   
    
    /**
     * The method to get Sec ACL Implementation Details
     * @param tiRequestId
     * @param connectionId
     * @param versionId
     * @return List containing Sec ACL Implementation Details
     */
    private List<String> getSecACLInfo(Long tiRequestId, Long connectionId, Long versionId) {
        List<String> docDetails = new ArrayList<String>();
        String acl_implementer = getCurrentProcess_status(connectionId,versionId,ActivityData.ACL_VARIANCE_IMP);
        if(acl_implementer==null)
        {
            acl_implementer="Not Scheduled"; 
        }
        ArrayList uploadedDocumentList = (ArrayList) getUploadedDocumentList(tiRequestId,"'ACL_Current','ACL_Changes'");
        if (uploadedDocumentList != null && uploadedDocumentList.size() > 0) {
            for (HashMap document : (ArrayList<HashMap>)uploadedDocumentList) {
                docDetails.add(document.get("CREATION_DATE")+"/"+document.get("DOC_TYPE")+"/"+document.get("DOC_NAME")+"/"+document.get("CREATOR_ID")+"\n");
            }
        }
        return docDetails;
    }
    
    /**
     * Gets the uploaded document list.
     *
     * @param tiRequestId
     *            the ti request id
     * @param doc_type
     *            the doc_type
     * @return the uploaded document list
     */
    public List getUploadedDocumentList(Long tiRequestId, String doc_type) {
        log.debug("getUploadedDocumentList() :: Starts");
        List dataList = new ArrayList();
        Map data = new HashMap();
        List returnList = new ArrayList();
        String sql = "SELECT dat.ID, dat.DOC_CONTENT_ID,dat.DOC_NAME, dat.DOC_TYPE, dat.DOC_MIME_TYPE,"
            + "dat.CONNECTION_ID,dat.TI_REQUEST_ID, dat.CREATOR_ID,dat.CREATION_DATE FROM TI_DOC_META_DATA dat "
            + " where dat.doc_type IN ("
            + doc_type
            + ") and dat.ti_request_id =" + tiRequestId;

        String docName = "";
        try {
            data = runQuery(sql, 9);
        } catch (Exception e) {
            log.error("Exception in getUploadedDocumentList : "+e, e);
        }
        int counter = 1;
        if (data != null && data.size() > 0) {
            while (counter <= data.size()) {
                dataList = (ArrayList) data.get(Integer.valueOf(counter));
                if (dataList != null && dataList.size() > 0) {
                    HashMap uploadedDocMap = new HashMap();
                    uploadedDocMap.put("ID", Long.valueOf((String) dataList
                            .get(0)));
                    uploadedDocMap.put("DOC_CONTENT_ID", (String) dataList
                            .get(1));
                    docName = dataList.get(2) != null ? dataList.get(2).toString():"";
                    uploadedDocMap.put("DOC_NAME", docName.substring(docName.indexOf(":") + 1));
                    uploadedDocMap.put("DOC_TYPE", (String) dataList.get(3));
                    uploadedDocMap.put("DOC_MIME_TYPE", (String) dataList
                            .get(4));
                    uploadedDocMap.put("CONNECTION_ID", Long
                            .valueOf((String) dataList.get(5)));
                    uploadedDocMap.put("TI_REQUEST_ID", Long
                            .valueOf((String) dataList.get(6)));
                    uploadedDocMap.put("CREATOR_ID", (String) dataList.get(7));
                    uploadedDocMap.put("CREATION_DATE", (String) dataList
                            .get(8));
                    returnList.add(uploadedDocMap);
                }
                counter = counter + 1;
            }
        }
        log.info("Size of return List::: " + returnList.size());
        return returnList;
    }
    
    /**
     * The method to get Appsense Details
     * @param processId
     * @param tiRequestId
     * @param version_export_id
     * @return AccessFormXsl containing Appsense Details
     */ 
    public AccessFormXsl getAAFCombinationInfo(Long processId,Long tiRequestId, Long version_export_id){
        log.debug("processId : "+processId+" , tiRequestId : "+tiRequestId+" , version_export_id : "+version_export_id);
        AccessFormXsl accessFormXsl = new AccessFormXsl();
        StringBuilder str = new StringBuilder();
        List<AAFAccessForm> appsenseAccessFormList = new ArrayList<AAFAccessForm>();
        List<AAFAccessForm> nwList = new ArrayList<AAFAccessForm>();
        List<AAFAccessForm> userList = new ArrayList<AAFAccessForm>();
        AAFAccessForm appsenseAccessForm = null;
        List<AppsenseAAFCombination> combinedExportList=new ArrayList<AppsenseAAFCombination>();
        combinedExportList.add(appsensePersistable.getApsNonNetworkCombination(processId, version_export_id, Long.valueOf(1), Long.valueOf(1)));
        combinedExportList.add(appsensePersistable.getApsNonNetworkCombination(processId, version_export_id, Long.valueOf(3), Long.valueOf(1)));
        combinedExportList.addAll(appsensePersistable.getApsNetworkCombFilter(processId, version_export_id, Long.valueOf(1), Long.valueOf(2)));
        combinedExportList.addAll(appsensePersistable.getApsNetworkCombFilter(processId, version_export_id, Long.valueOf(3), Long.valueOf(2)));
        combinedExportList.add(appsensePersistable.getApsUserCombination(processId, version_export_id, Long.valueOf(1), Long.valueOf(3)));
        combinedExportList.add(appsensePersistable.getApsUserCombination(processId, version_export_id, Long.valueOf(3), Long.valueOf(3)));
        
        if(combinedExportList.size() > 0){
            for(AppsenseAAFCombination appsType:combinedExportList){
                if(appsType.getNonNetworkApps() != null && !appsType.getNonNetworkApps().isEmpty()){
                    
                    for(int count=0;count < appsType.getNonNetworkApps().size();count++){
                        AppsenseAAFCombination nonNetwork = (AppsenseAAFCombination)appsType.getNonNetworkApps().get(count);
                        if(nonNetwork.getNonNetworkApps() != null && !nonNetwork.getNonNetworkApps().isEmpty()){
                            appsenseAccessForm = new AAFAccessForm();
                            if(1 == nonNetwork.getCombinationType()){
                                appsenseAccessForm.setNwCombType("Add Non Network Combination "+count + 1);
                                
                            }
                            if(3 == nonNetwork.getCombinationType()){
                                appsenseAccessForm.setNwCombType("Delete Non Network Combination "+count + 1 );
                                
                            }
                            appsenseAccessForm.setNwAppsenseType("Appsense Type:Non-Network Apps \n\n");
                            appsenseAccessForm.setAppsenseAppDetails(nonNetwork.getNonNetworkApps());
                            appsenseAccessFormList.add(appsenseAccessForm);
                            accessFormXsl.setAppsenseAccessformList(appsenseAccessFormList);
                            log.debug("Access Form Generator Non Network Apps:"+appsenseAccessForm.getAppsenseAppDetails());
                        }   
                        
                    }
                    
                }
                if(appsType.getFafType() == 2){
                    appsenseAccessForm = new AAFAccessForm();
                    if(appsType.getApsPorts() != null && !appsType.getApsPorts().isEmpty()){
                        if(appsType.getCombinationType() == 1){
                            appsenseAccessForm.setNwCombType("Add Network Combination "+appsType.getNetworkDetailCount());
                            
                        }
                        if(appsType.getCombinationType() == 3){
                            appsenseAccessForm.setNwCombType("Delete Network Combination "+appsType.getNetworkDetailCount());
                            
                        }
                        appsenseAccessForm.setNwAppsenseType("Appsense Type:Network Apps");
                        List<Application> appsTypeList = new ArrayList();
                        appsTypeList.add(appsType.getApsApplication());
                        appsenseAccessForm.setAppsenseAppDetails(appsTypeList);
                        appsenseAccessForm.setNwPortMasterList(appsType.getApsPorts());
                        nwList.add(appsenseAccessForm);
                        accessFormXsl.setNwList(nwList);
                        log.debug("Access Form Generator  Network Apps:"+appsenseAccessForm.getNwPortMasterList()+"++"+appsenseAccessForm.getAppsenseAppDetails());
                        
                    }
                }
                if(appsType.getApsUsers() != null && !appsType.getApsUsers().isEmpty()){
                    appsenseAccessForm = new AAFAccessForm();
                    for(int index = 0; index < appsType.getApsUsers().size(); index++){
                        AppsenseAAFCombination user = (AppsenseAAFCombination)appsType.getApsUsers().get(index);
                        if(user.getApsUsers() != null && !user.getApsUsers().isEmpty()){
                            if(user.getCombinationType() == 1){
                                appsenseAccessForm.setUserCombType("Add User Combination "+ index+1);
                                
                            }
                            if(appsType.getCombinationType() == 3){
                                appsenseAccessForm.setUserCombType("Delete User Combination "+ index+1);
                                
                            }
                            appsenseAccessForm.setUserAppsenseType("Appsense Type:User");
                            if(user.getApsUsers() != null && !user.getApsUsers().isEmpty()){
                                appsenseAccessForm.setUserRecordsList(user.getApsUsers());
                                userList.add(appsenseAccessForm);
                                accessFormXsl.setUserList(userList);
                                log.debug("Access Form Generator:USer Records:"+appsenseAccessForm.getUserRecordsList());
                            }   
                        }
                    }
                }
            }           
        }
        log.debug("AccessFormTextGenerator :: getAAFCombinationInfo :: ends :: "+str);
        return accessFormXsl;
    }

    /**
     * The method to get PAF details
     * @param connectionID
     * @param tiRequestId
     * @param versionID
     * @param isRFC
     * @param RFCRequest
     * @return List containing PAF details 
     */ 
    public List<PafAccessForm> getPAFCombinationInfo(Long connectionID,Long tiRequestId, Long versionID, String isRFC,RFCRequest rfcRequest){
        ProxyInstance proxyInstance = null;
        StringBuilder str = new StringBuilder();
        List<ProxyPAFCombination> proxyCombinationList = new ArrayList<ProxyPAFCombination>();
        List combTypeList=new ArrayList();
        combTypeList.add("1");
        combTypeList.add("3");
        
        if(isRFC != null && isRFC.equalsIgnoreCase(NO)){
            proxyCombinationList = proxyPersistable.getProxyCombinationExportFilter(connectionID, versionID, combTypeList);
        }else{
            proxyCombinationList = proxyPersistable.getProxyCombExpFilterForRFC(connectionID, versionID, rfcRequest.getId());
        }
        HashSet<String> sourceSet = new HashSet<String>();
        HashSet<String> destSet = new HashSet<String>();
        HashSet<String> portSet = new HashSet<String>();
        
        String tempRecordType = "",tempRegion = "",tempInstanceName = "",tempAction = "",isNew = "Y"
                ,tempDeleteInstanceName = "",addStatement="",addRedirect =""
                ,deleteStatement="",delRedirect ="",tempDelRegion = "";
        Long tempCombinationNumber = 0L;
        
        int deleteCount = 0,addCount = 0;
        List<PafAccessForm> pafAccessFormList = new ArrayList<PafAccessForm>();
        if(proxyCombinationList.size() > 0){
            log.debug("size ....."+proxyCombinationList.size());
            PafAccessForm pafAccessForm = new PafAccessForm();
           
            String differentiatingCondition = "";
            String tempDifferentiatingCondition="";
           
            for(ProxyPAFCombination proxyCombination:proxyCombinationList){
                proxyInstance = proxyCombination.getProxyInstance();
                log.debug("tempCombinationNumber"+tempCombinationNumber +":Combination Number from DB for current iteration= "+proxyCombination.getCombinationnumber());
                if((tempRecordType != null && !tempRecordType.equalsIgnoreCase(proxyInstance.getRecordType()))
                        || (tempRegion != null && !tempRegion.equalsIgnoreCase(proxyInstance.getRegion()))
                        || (tempInstanceName != null && !tempInstanceName.equalsIgnoreCase(proxyInstance.getName()))
                        || (tempAction != null && !tempAction.equalsIgnoreCase(proxyCombination.getAction()))
                        || (tempCombinationNumber != null && tempCombinationNumber.longValue()!=proxyCombination.getCombinationnumber().longValue())){
                    pafAccessForm = new PafAccessForm();
                    isNew = "Y";
                }else if(addCount > 0){
                    isNew = "N";
                }
                log.debug("getPAFCombinationInfo::addCount ....."+addCount+" - isNew::"+isNew);
                addCount++;
                if(!StringUtil.isNullorEmpty(proxyCombination.getSpecialInstruction())) {
                	pafAccessForm.setSpecialInstruction(proxyCombination.getSpecialInstruction());
                }
                if(proxyInstance!= null && proxyInstance.getRecordType() != null && "BASIC".equalsIgnoreCase(proxyInstance.getRecordType())){
                    
                    if(proxyCombination.getAction() != null && "1".equalsIgnoreCase(proxyCombination.getAction())){
                        pafAccessForm.setCombiType("Add");
                    }else if (proxyCombination.getAction() != null &&"3".equalsIgnoreCase(proxyCombination.getAction())){
                        pafAccessForm.setCombiType("Delete");
                    }
                    if(proxyInstance.getName() != null && proxyInstance.getRegion()!=null){
                    pafAccessForm.setRecType(proxyInstance.getRecordType());
                    pafAccessForm.setRegion(proxyInstance.getRegion());
                    pafAccessForm.setInstanceName(proxyInstance.getName());
                    }
                    if(proxyInstance.getIsNew() != null
                            && !YES.equalsIgnoreCase(proxyInstance.getIsNew())){
                        pafAccessForm.setPort(proxyInstance.getPortNumber());                               
                    }else if(proxyInstance.getIsNew() != null
                            && YES.equalsIgnoreCase(proxyInstance.getIsNew())){
                        if(proxyInstance.getPortNumber() != null 
                                && proxyInstance.getPortNumber().isEmpty()){
                            pafAccessForm.setPort("Unassigned(New Instance)");
                        }else{
                            pafAccessForm.setPort(proxyInstance.getPortNumber());   
                        }
                        pafAccessForm.setBusDesc(proxyInstance.getBusinessDesc());  
                    }   
                    pafAccessForm.setIntReqd(proxyInstance.getInternetAccess() !=null ? proxyInstance.getInternetAccess() : "");
                    pafAccessForm.setProxyDetails(proxyInstance.getPacFileReq() !=null ?proxyInstance.getPacFileReq() : "");
                    if(!StringUtil.isNullorEmpty(proxyInstance.getSpecialInstruction())) {
                    	pafAccessForm.setSpecialInstruction(proxyInstance.getSpecialInstruction());
                    }
                    if(isNew.equalsIgnoreCase("Y")){
                        pafAccessForm.setUrl(proxyCombination.getUrl());                        
                        pafAccessFormList.add(pafAccessForm);
                    }else{
                        pafAccessForm.setUrl(pafAccessForm.getUrl()+" \n"+proxyCombination.getUrl());   
                    }
                }
                else if(proxyInstance.getRecordType() != null &&
                        "PACFILE".equalsIgnoreCase(proxyInstance.getRecordType())){
                    StringBuilder proxyDetails = new StringBuilder();
                    if(proxyCombination.getAction() != null && "1".equalsIgnoreCase(proxyCombination.getAction())){
                        pafAccessForm.setCombiType("Add");
                    }else if (proxyCombination.getAction() != null && "3".equalsIgnoreCase(proxyCombination.getAction())){
                        pafAccessForm.setCombiType("Delete");
                    }
                    if(proxyInstance.getName() != null && proxyInstance.getRegion()!=null){
                        pafAccessForm.setRecType(proxyInstance.getRecordType());
                        pafAccessForm.setRegion(proxyInstance.getRegion());
                        pafAccessForm.setInstanceName(proxyInstance.getName());
                    }
                    pafAccessForm.setPort(proxyInstance.getPortNumber());
                
                    //combination, type, region, instance name , port
                    tempDifferentiatingCondition = pafAccessForm.getCombiType()+pafAccessForm.getRecType()+pafAccessForm.getRegion()+pafAccessForm.getInstanceName()+pafAccessForm.getPort();
                    if(!tempDifferentiatingCondition.equalsIgnoreCase(differentiatingCondition))
                    {
                        differentiatingCondition = tempDifferentiatingCondition;
                        //reset the other stuff.
                        addRedirect = "";
                        addStatement = "";
                    }
                     
                

                    String originalStatement = proxyCombination.getStatement();
                    if(proxyCombination.getStatement() != null && !addStatement.equalsIgnoreCase(proxyCombination.getStatement())){
                        addStatement = originalStatement;
                        proxyDetails.append("Pac File Required:"+(proxyInstance.getPacFileReq() !=null ? proxyInstance.getPacFileReq() : "" )+"\n");
                        proxyDetails.append("Internet Required:"+(proxyInstance.getInternetAccess() !=null ? proxyInstance.getInternetAccess() : "")+"\n");
                        proxyDetails.append("Statement:"+proxyCombination.getStatement()+"\n");
                        proxyDetails.append("\n");
                        if(proxyCombination.getStatementRedirect() != null 
                                && proxyCombination.getStatementRedirect().isEmpty()){
                            proxyDetails.append("Fully Qualified Domain Name or Application URL :\n");
                        }
                    }
                    if(proxyCombination.getStatementRedirect() != null && !proxyCombination.getStatementRedirect().isEmpty()){
                        String originalAddRedirect = proxyCombination.getStatementRedirect();
                        if(proxyCombination.getStatementRedirect() != null && !proxyCombination.getStatementRedirect().equalsIgnoreCase(addRedirect)){
                            addRedirect = originalAddRedirect;  
                            proxyDetails.append("Redirect To:"+proxyCombination.getStatementRedirect()+"\n");
                            proxyDetails.append("Fully Qualified Domain Name or Application URL :\n");                                  
                        }
                    }
                    proxyDetails.append(proxyCombination.getDomainName()+" \n");
                    if(!StringUtil.isNullorEmpty(proxyInstance.getSpecialInstruction())) {
                    	pafAccessForm.setSpecialInstruction(proxyInstance.getSpecialInstruction());
                    }
                    if(isNew.equalsIgnoreCase("Y")){
                        pafAccessForm.setDomainUrl(proxyDetails.toString());
                        pafAccessFormList.add(pafAccessForm);
                    }else{
                        pafAccessForm.setDomainUrl(pafAccessForm.getDomainUrl() + proxyDetails.toString());
                    }
                }
                else if(proxyInstance.getRecordType() != null &&
                            "PLUG".equalsIgnoreCase(proxyInstance.getRecordType())){
                    if(proxyCombination.getAction() != null && "1".equalsIgnoreCase(proxyCombination.getAction())){
                        pafAccessForm.setCombiType("Add");
                    }else if (proxyCombination.getAction() != null && "3".equalsIgnoreCase(proxyCombination.getAction())){
                        pafAccessForm.setCombiType("Delete");
                    }
                    pafAccessForm.setRecType(proxyInstance.getRecordType());
                    if("BASIC".equalsIgnoreCase(proxyCombination.getRequestType())){
                        pafAccessForm.setReqType("STANDARD");
                    }else{
                        pafAccessForm.setReqType(proxyCombination.getRequestType());
                    }
                    if(proxyInstance.getName() != null && proxyInstance.getRegion()!=null){
                        pafAccessForm.setRegion(proxyInstance.getRegion());
                        //pafAccessForm.setInstanceName(proxyInstance.getName());
                        //Set list of ip addresses here. 
                            StringBuffer sb = new StringBuffer("");
                            Util utility = new Util();
                            String key=proxyInstance.getRegion()+"-"+proxyInstance.getRecordType();
                            log.debug("Key = " +key);
                            List<String> tempList = utility.getProxySockIpList(key);
                            for(String currIpAddress:tempList ){
                                log.debug("Current sb value "+String.valueOf(sb));
                                sb.append(currIpAddress);
                                sb.append(" ");
                            }
                            
                        sb.deleteCharAt(sb.length()-1);
                        pafAccessForm.setProxyMasterIpAddress(sb.toString());
                        pafAccessForm.setInstanceName(proxyInstance.getName()+" : ");
                        pafAccessForm.setInstanceDescription(proxyInstance.getInstanceDesc());
                        
                        pafAccessForm.setPort(proxyInstance.getPortNumber());
                    }
                    
                    
                    if(isNew.equalsIgnoreCase("Y")){
                        
                        //Old logic , this is being retained in case things go wrong. 
                        pafAccessForm.setDomainUrl(proxyCombination.getSourceIp()+"/"+proxyCombination.getExternalIp()+"/"+proxyCombination.getPort());
                        
                        pafAccessForm.setSource(proxyCombination.getSourceIp());
                        pafAccessForm.setDest(proxyCombination.getExternalIp());
                        pafAccessForm.setComboport(proxyCombination.getPort());
                        pafAccessForm.setCombinationnumber(String.valueOf(proxyCombination.getCombinationnumber()));
                        pafAccessForm.setImplAssignedPort(String.valueOf(proxyCombination.getAssignedport()));
                        pafAccessFormList.add(pafAccessForm);
                        
                        //clear out the set. 
                        sourceSet = new HashSet<String>();
                        destSet  = new HashSet<String>();
                        portSet  = new HashSet<String>();
                        
                        //Set the values for this iteration.
                        sourceSet.add(proxyCombination.getSourceIp());
                        destSet.add(proxyCombination.getExternalIp());
                        portSet.add(proxyCombination.getPort());
                        
                    }else{
                        
                        if(!sourceSet.contains(proxyCombination.getSourceIp())){
                            //add it 
                            pafAccessForm.setSource(pafAccessForm.getSource()+"\n"+proxyCombination.getSourceIp());
                            sourceSet.add(proxyCombination.getSourceIp());
                        }
                        if(!destSet.contains(proxyCombination.getExternalIp())){
                            //add it 
                            pafAccessForm.setDest(pafAccessForm.getDest()+"\n"+proxyCombination.getExternalIp());
                            destSet.add(proxyCombination.getExternalIp());
                        }
                        if(!portSet.contains(proxyCombination.getPort())){
                            //add it 
                            pafAccessForm.setComboport(pafAccessForm.getComboport()+"\n"+proxyCombination.getPort());
                            portSet.add(proxyCombination.getPort());
                        }
                        pafAccessForm.setDomainUrl(pafAccessForm.getDomainUrl()+" \n"+proxyCombination.getSourceIp()+"/"+proxyCombination.getExternalIp()+"/"+proxyCombination.getPort());

                        if(proxyCombination.getAssignedport()!=null) {
                            pafAccessForm.setImplAssignedPort(String.valueOf(proxyCombination.getAssignedport()));
                        }
                        
                        if(proxyCombination.getCombinationnumber()!=null) {
                            pafAccessForm.setCombinationnumber(String.valueOf(proxyCombination.getCombinationnumber()));
                        }
                        //append
                    }                   
                }
                else if(proxyInstance.getRecordType() != null &&
                        "SOCKS".equalsIgnoreCase(proxyInstance.getRecordType())){                   
                    if(proxyCombination.getAction() != null && "1".equalsIgnoreCase(proxyCombination.getAction())){
                        pafAccessForm.setCombiType("Add");
                    }else if (proxyCombination.getAction() != null && "3".equalsIgnoreCase(proxyCombination.getAction())){
                        pafAccessForm.setCombiType("Delete");
                    }
                    if(proxyInstance.getName() != null && proxyInstance.getRegion()!=null){
                        pafAccessForm.setRecType(proxyInstance.getRecordType());
                        pafAccessForm.setRegion(proxyInstance.getRegion());
                    }
                    if(proxyInstance.getInstanceDesc() !=null){
                        pafAccessForm.setInstanceName(proxyInstance.getInstanceName());
                        pafAccessForm.setInstanceDescription(proxyInstance.getInstanceDesc());
                    }
                    
                    if(isNew.equalsIgnoreCase("Y")){
                        
                        //old
                        pafAccessForm.setDomainUrl(proxyCombination.getSourceIp()+"/"+proxyCombination.getExternalIp()+"/"+proxyCombination.getPort());
                        
                        pafAccessForm.setSource(proxyCombination.getSourceIp());
                        pafAccessForm.setDest(proxyCombination.getExternalIp());
                        pafAccessForm.setComboport(proxyCombination.getPort());
                        pafAccessForm.setCombinationnumber(String.valueOf(proxyCombination.getCombinationnumber()));
                        pafAccessForm.setClientRuleNumber(String.valueOf(proxyCombination.getClientrulenumber()));
                        pafAccessFormList.add(pafAccessForm);
                        
                        //clear out the set. 
                        sourceSet = new HashSet<String>();
                        destSet  = new HashSet<String>();
                        portSet  = new HashSet<String>();
                        
                        sourceSet.add(proxyCombination.getSourceIp());
                        destSet.add(proxyCombination.getExternalIp());
                        portSet.add(proxyCombination.getPort());
                        
                    }else{
                        
                        if(!sourceSet.contains(proxyCombination.getSourceIp())){
                            //add it 
                            pafAccessForm.setSource(pafAccessForm.getSource()+"\n"+proxyCombination.getSourceIp());
                            sourceSet.add(proxyCombination.getSourceIp());
                        }
                        if(!destSet.contains(proxyCombination.getExternalIp())){
                            //add it 
                            pafAccessForm.setDest(pafAccessForm.getDest()+"\n"+proxyCombination.getExternalIp());
                            destSet.add(proxyCombination.getExternalIp());
                        }
                        if(!portSet.contains(proxyCombination.getPort())){
                            //add it 
                            pafAccessForm.setComboport(pafAccessForm.getComboport()+"\n"+proxyCombination.getPort());
                            portSet.add(proxyCombination.getPort());
                        }
                        pafAccessForm.setDomainUrl(pafAccessForm.getDomainUrl()+" \n"+proxyCombination.getSourceIp()+"/"+proxyCombination.getExternalIp()+"/"+proxyCombination.getPort());
                        
                        //append
                    }   
                }else if(proxyInstance.getRecordType() != null &&
                        "FREEURL_ADD".equalsIgnoreCase(proxyInstance.getRecordType())){                     
                    if(proxyCombination.getAction() != null && "1".equalsIgnoreCase(proxyCombination.getAction())){
                        pafAccessForm.setCombiType("Add");
                    }else if (proxyCombination.getAction() != null && "3".equalsIgnoreCase(proxyCombination.getAction())){
                        pafAccessForm.setCombiType("Delete");
                    }
                    if(proxyInstance.getName() != null && proxyInstance.getRegion()!=null){
                        pafAccessForm.setRecType(proxyInstance.getRecordType());
                        pafAccessForm.setRegion(proxyInstance.getRegion());
                        pafAccessForm.setInstanceName(proxyInstance.getName());
                    }
                    if(proxyInstance.getInstanceDesc() !=null){
                        pafAccessForm.setInstanceDescription(proxyInstance.getInstanceDesc());
                    }
                    
                    if(isNew.equalsIgnoreCase("Y")){
                        pafAccessForm.setDomainUrl((proxyCombination.getDomainName() !=null ? proxyCombination.getDomainName() : "" )+"/"+(proxyCombination.getUrl() !=null ? proxyCombination.getUrl() : "" ));                        
                        pafAccessFormList.add(pafAccessForm);
                    }else{
                        pafAccessForm.setDomainUrl(pafAccessForm.getDomainUrl()+" \n"+(proxyCombination.getDomainName() !=null ? proxyCombination.getDomainName() : "" )+"/"+(proxyCombination.getUrl() !=null ? proxyCombination.getUrl() : "" ));                     
                    }
                }
                tempRecordType = proxyInstance.getRecordType();
                tempRegion = proxyInstance.getRegion();
                tempInstanceName = proxyInstance.getName();
                tempAction = proxyCombination.getAction();
                tempCombinationNumber= proxyCombination.getCombinationnumber();
            }
        }else{
            str.append("\n \n No Records !!!!!");
        }   
        log.debug("AccessFormTextGenerator :: getPAFCombinationInfo :: ends :: "+str);  
        return pafAccessFormList;
    }
    
    
    /**
     * The method to get list of TiRequestId's
     * @param processId
     * @param isIpReg
     * @param expType
     * @return List containing TiRequestId's
     */ 
    @Override
    public List<TIRequest> getAllTiRequest(Long processId, String isIpReg, String expType) {
        String condition = "" , type = "";
        SqlRowSet rs = null;
        List<TIRequest> tiRequests = null;
        /*List to hold the TiRequestId's*/
        try {
            tiRequests = new ArrayList<TIRequest>();
            if(isIpReg.equalsIgnoreCase(YES))
            {
                condition = "WHERE  UPPER(TTT.TASK)=UPPER('IP Registration Implementation') ";  
            }
            else
            {
                condition = "WHERE  (UPPER(TTT.TASK)=UPPER('Firewall Implementation') OR UPPER(TTT.TASK)=UPPER('Firewall ADR'))";
            }
            
            if(!expType.equalsIgnoreCase("Impl")){
                type = " union "+
                        "select id as id,version_number from ti_request where process_id= ? and version_number=(select max(version_number) " +
                        "from ti_request where process_id= ? and ti_request_type_id not in " +
                        "(select id from ti_request_type where request_type in ('ACV','ManageContacts','Temp Approval Expiration')))";
            }
            
            String query ="(SELECT distinct TI_REQUEST_ID as id , tir.version_number FROM "+
                                                    "TI_ACTIVITY_TRAIL TAT "+
                                                    "JOIN TI_REQUEST TIR ON TIR.ID=TAT.TI_REQUEST_ID "+
                                                    "JOIN TI_TASK_TYPE TTT ON TTT.ID=TAT.ACTIVITY_ID "+
                                                    condition+
                                                    " AND UPPER(TAT.ACTIVITY_STATUS)=UPPER('COMPLETED') "+
                                                    "AND TIR.PROCESS_ID= ? "+ type + ") ORDER BY 2";
            if(!expType.equalsIgnoreCase("Impl")){
            rs  = jdbcTemplate.queryForRowSet(query.toString(),new Object[]{processId,processId,processId});
            }
            else{
            rs  = jdbcTemplate.queryForRowSet(query.toString(),new Object[]{processId});
            }
            while(rs.next()) {
                TIRequest tr = new TIRequest();
                tr.setId(rs.getLong(1));
                tr.setVersionNumber(rs.getInt(2));
                tiRequests.add(tr);             
            }
        } catch (Exception e) {
            log.error("Exception in getAllTiRequest : "+e, e);
        }       
        return tiRequests;
    }
    
    /**
     * The method to get AccessFormText for Firewall
     * @param tiRequestId
     * @param connectionRequestId
     * @param expOption
     * @return String containing AccessFormText for Firewall
     */ 
    public String getAllFirewallAccessFormText(Long tiRequestId, Long connectionRequestId, String expOption){
        return getAllFirewallAccessFormText(tiRequestId, connectionRequestId, expOption, NO);
    }
    
    /**
     * The method to get AccessFormText for Firewall
     * @param tiRequestId
     * @param connectionRequestId
     * @param expOption
     * @param isObjExpandable
     * @return String containing AccessFormText for Firewall
     */ 
    @Transactional(readOnly = true)
    public String getAllFirewallAccessFormText(Long tiRequestId, Long connectionRequestId, String expOption, String isObjExpandable) {
        String firewallAccessFormText = "";
        /*String to hold the Firewall AccessFormText*/
        List<TIRequest> fw = null;
        StringBuilder faf = null;
        try {
            fw = getAllTiRequest(connectionRequestId, NO, expOption);
            faf = new StringBuilder();
            for (TIRequest i :fw){
                log.debug("req id" +i.getId());
                faf.append(getFirewallAccessFormText(i.getId(), connectionRequestId, Long.valueOf(i.getVersionNumber()),isObjExpandable));
            }
            firewallAccessFormText = faf.toString();
        } catch (Exception e) {
            log.error("Exception in getAllFirewallAccessFormText : "+e, e);         
        }
        return firewallAccessFormText;
    }
    
    /**
     * The method to get AccessFormText for IP Registration
     * @param tiRequestId
     * @param connectionRequestId
     * @param expOption
     * @return String containing AccessFormText for IP Registration
     */
    public String getAllIPRegistrationAccessFormText(Long tiRequestId, Long connectionRequestId, String expOption) {
        return getAllIPRegistrationAccessFormText(tiRequestId, connectionRequestId, expOption, NO);
    }

    /**
     * The method to get AccessFormText for IP Registration
     * @param tiRequestId
     * @param connectionRequestId
     * @param expOption
     * @param isObjExpandable
     * @return String containing AccessFormText for IP Registration
     */
    @Transactional(readOnly = true)
    public String getAllIPRegistrationAccessFormText(Long tiRequestId, Long connectionRequestId, String expOption, String isObjExpandable) {
        String ipRegAccessFormText = "";
        /*String to hold the IP Registration AccessFormText*/
        List<TIRequest> fw = null;
        StringBuilder faf = null;
        try {
            fw = getAllTiRequest(connectionRequestId, YES, expOption);
            faf = new StringBuilder();
            for (TIRequest i :fw){
                log.debug("req id" +i.getId()); 
                faf.append(getIPRegistrationAccessFormText(i.getId(), connectionRequestId, Long.valueOf(i.getVersionNumber()), isObjExpandable));
            }
            ipRegAccessFormText =  faf.toString();
        } catch (Exception e) {
            log.error("Exception in getAllIPRegistrationAccessFormText : "+e, e);           
        }
        return ipRegAccessFormText;
    }
    
    /**
     * The method to transform Xml
     * @nc43495
     * @param objectToTransform
     * @param requestType
     * @return String containing XSL contents
     */
    private String transformObjectXMLtoXSLTemplate(Object objectToTransform,String requestType) {
        TransformerFactory tFactory = TransformerFactory.newInstance();
        Transformer transformer;
        StringWriter outWriter = new StringWriter();
        StreamResult result = new StreamResult(outWriter);
        String xml = getAccessForm(requestType);
        //log.debug("XML Transformation:"+xml);
        try {
            transformer = tFactory.newTransformer(new StreamSource(new StringReader(xml)));
            transformer.transform(new javax.xml.transform.stream.StreamSource(new StringReader(convertoXML(objectToTransform).toString())), result);
        }
         catch (TransformerConfigurationException e) {
             log.error("TransformerConfigurationException in transformObjectXMLtoXSLTemplate : "+e, e);      
        } catch (TransformerException e) {
            log.error("TransformerException in transformObjectXMLtoXSLTemplate : "+e, e);           
        } catch (JAXBException e) {
            log.error("JAXBException in transformObjectXMLtoXSLTemplate : "+e, e);
        }
        return outWriter.getBuffer().toString();
    }
    
    /**
     * The Method to Convert XML to notepad after setting values
     * @nc43495
     * @param Object
     * @return StringWriter containing XML contents
     */
    private StringWriter convertoXML(Object o) throws JAXBException {
        
        JAXBContext context = JAXBContext.newInstance(o.getClass());
        Marshaller m = context.createMarshaller();
        m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        StringWriter sw = new StringWriter();
        
        //Converting supervisorEmail object to XML file
        m.marshal(o, sw );
        //commented by eg41091 for removing unwanted log
        //log.info("marshaller output "+sw.toString());
        
        //Apply the XML values to XSL Template using XSLT transformation
            StringWriter outWriter = new StringWriter();
            StreamResult result = new StreamResult(outWriter);
            
            
        return sw;
        
    }
    
    /**
     * The method to get getAccessForm based on the request Type
     * @nc43495
     * @param requestType
     * @return String containing AccessFormText
     */
    public String getAccessForm(String requestType){
        log.debug("AccessFormTextGenerator:starts");    
        Connection con = null; 
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String templateXML = "";
        /*String to hold the AppSense AccessFormText*/
        requestType = requestType+".xsl";
        log.debug("RequestTYpe : "+requestType);
        String sql = "select FILE_TEXT from c3par.CCR_Reference_Files where UPPER(FILE_NAME) ='"+requestType.toUpperCase()+"'";     
        try {
            con = DataSourceUtils.getConnection(dataSource);   
            stmt = con.prepareStatement(sql);           
            rs = stmt.executeQuery();
            while (rs.next())
            {
                Clob data = rs.getClob(1);
                
                if(data != null && data.length() > 0){
                    
                    templateXML = data.getSubString(1, (int) data.length());
                }
            }
        } catch (Exception e) {
            log.error("Exception in getAccessForm : "+e, e);
        }    
        finally {
            JdbcUtils.closeResultSet(rs);
            JdbcUtils.closeStatement(stmt);
            DataSourceUtils.releaseConnection(con, dataSource);
        }       
        log.debug("AccessFormTextGenerator:ends...");
        return templateXML;
    }
    
    /**
     * The method to get AccessFormText for Proxy
     * @nc43495
     * @param tiRequestId
     * @param connectionRequestId
     * @return String containing AccessFormText for Proxy
     */
    @Transactional(readOnly = true)
    public String getAllProxyAccessFormText(Long tiRequestId, Long connectionRequestId) {
        String proxyAccessFormText = "";
        /*String to hold the Proxy AccessFormText*/
        List<TIRequest> fw = null;
        StringBuilder paf = null;
        try {
            fw = getAllTiRequestForPAF(connectionRequestId);
            paf = new StringBuilder();
            for (TIRequest i :fw){
                log.debug("paf req id" + i.getId());
                paf.append(getProxyAccessFormText(i.getId(), connectionRequestId, Long.valueOf(i.getVersionNumber())));
            }
            proxyAccessFormText = paf.toString();
        } catch (Exception e) {
            log.error("Exception in getAllProxyAccessFormText : "+e, e);
        }
        return proxyAccessFormText;
    }
    
    /**
     * The method to get AccessFormText for AppSense
     * @nc43495
     * @param tiRequestId
     * @param connectionRequestId
     * @return String containing AccessFormText for AppSense
     */
    @Transactional(readOnly = true)
    public String getAllAppsenseAccessFormText(Long tiRequestId, Long connectionRequestId) {
        String appSenseAccessFormText = "";
        /*String to hold the AppSense AccessFormText*/
        List<TIRequest> fw = null;
        StringBuilder aaf = null;
        try {
            fw = getAllTiRequestForPAF(connectionRequestId);
            aaf = new StringBuilder();
            for (TIRequest i :fw){
                log.debug("aaf req id" + i.getId());
                aaf.append(getAppsenseAccessFormText(i.getId(), connectionRequestId, Long.valueOf(i.getVersionNumber())));
            }
            appSenseAccessFormText = aaf.toString();
        } catch (Exception e) {
            log.error("Exception in getAllAppsenseAccessFormText : "+e, e);     
        }
        return appSenseAccessFormText;
    }
    
    /**
     * The method to get AccessFormText for SEC ACL
     * @nc43495
     * @param tiRequestId
     * @param connectionRequestId
     * @return String containing AccessFormText for SEC ACL 
     */
    @Transactional(readOnly = true)
    public String getAllACLAccessFormText(Long tiRequestId, Long connectionRequestId) {
        String aclAccessFormText = "";
        /*String to hold the ACL AccessFormText*/
        List<TIRequest> fw = null;
        StringBuilder aaf = null;
        try {
            fw = getAllTiRequestForPAF(connectionRequestId);
            aaf = new StringBuilder();
            for (TIRequest i :fw){
                log.debug("acl req id" + i.getId());
                aaf.append(getSECACLAccessFormText(i.getId(), connectionRequestId, Long.valueOf(i.getVersionNumber())));
            }
            aclAccessFormText = aaf.toString();
        } catch (Exception e) {
            log.error("Exception in getAllACLAccessFormText : "+e, e);
        }
        return aclAccessFormText;
    }
    
    
    /**
     * The method to get TiRequests For PAF
     * @nc43495
     * @param processId
     * @return List containing all TIRequests for PAF
     */
    public List<TIRequest> getAllTiRequestForPAF(Long processId) {
        List<TIRequest> tiRequests = null;
        /*List to hold TIRequests for PAF*/
        try {
            tiRequests = new ArrayList<TIRequest>();            
            StringBuilder sql = new StringBuilder();
            sql.append("SELECT DISTINCT TI_REQUEST_ID AS ID ,");
            sql.append("TIR.VERSION_NUMBER ");
            sql.append("FROM TI_ACTIVITY_TRAIL TAT ");
            sql.append("JOIN TI_REQUEST TIR ");
            sql.append("ON TIR.ID=TAT.TI_REQUEST_ID ");
            sql.append("JOIN TI_TASK_TYPE TTT ");
            sql.append("ON TTT.ID                     =TAT.ACTIVITY_ID ");
            sql.append("WHERE UPPER(TAT.ACTIVITY_STATUS)=UPPER('COMPLETED') ");
            sql.append("AND TIR.PROCESS_ID            = ? ");
            sql.append("UNION ");
            sql.append("SELECT ID AS ID, ");
            sql.append("VERSION_NUMBER ");
            sql.append("FROM TI_REQUEST ");
            sql.append("WHERE PROCESS_ID  = ? ");
            sql.append("AND VERSION_NUMBER= ");
            sql.append("(SELECT MAX(VERSION_NUMBER) ");
            sql.append("FROM TI_REQUEST ");
            sql.append("WHERE PROCESS_ID            = ? ");
            sql.append("AND TI_REQUEST_TYPE_ID NOT IN ");
            sql.append("(SELECT ID ");
            sql.append(" FROM TI_REQUEST_TYPE ");
            sql.append(" WHERE REQUEST_TYPE IN ('ACV','ManageContacts','Temp Approval Expiration'))) ");
            
            SqlRowSet rs = jdbcTemplate.queryForRowSet(sql.toString(),new Object[]{processId,processId,processId});
            
            while(rs.next()) {
                TIRequest tr = new TIRequest();
                tr.setId(rs.getLong(1));
                tr.setVersionNumber(rs.getInt(2));
                tiRequests.add(tr);             
            }

        } catch (Exception e) {
            log.error("Exception in getAllTiRequestForPAF : "+e, e);
        } 
        
        return tiRequests;
    }

    /**
     * This method attaches attachment for all products
     * 
     * @param tiRequestID
     * @param connectionRequestId
     * @param versionID
     * @return
     * 
     */
    @Transactional(readOnly = true)
    public HashMap<String, String> getAllImplementedRule(Long tiRequestID, Long connectionRequestId, Long versionID,
            String isImpl) {

        boolean isFAF = false;
        boolean isProxy = false;
        boolean isAppsense = false;
        boolean isAcl = false;
        boolean isIpReg = false;

        SqlRowSet rs = getJdbcTemplate()
                .queryForRowSet(
                        new StringBuilder(
                                "select is_faf, is_proxy, is_appsense, is_acl_variance, ip_registration from ti_request_risk_flags ")
                                .append(" WHERE ti_request_id in (select id from ti_request where process_id=? and is_deleted = 'N' ) ")
                                .toString(), connectionRequestId);

        if (rs.next()) {
            if (YES.equalsIgnoreCase(rs.getString(IS_FAF))) {
                isFAF = true;
            }
            if (YES.equalsIgnoreCase(rs.getString(IS_PROXY))) {
                isProxy = true;
            }

            if (YES.equalsIgnoreCase(rs.getString(IP_REGISTRATION))) {
                isIpReg = true;
            }
        }

        HashMap<String, String> attachments = new HashMap<String, String>();

        if (YES.equalsIgnoreCase(isImpl)) {

            // For Firewall
            if (isFAF) {
                List<TIRequest> fw = getAllTiRequest(connectionRequestId, NO, IMPL);
                StringBuilder faf = new StringBuilder();
                for (TIRequest i : fw) {
                    faf.append(getFirewallAccessFormText(i.getId(), connectionRequestId,
                            Long.valueOf(i.getVersionNumber())));
                }
                attachments.put(new StringBuilder(FAF).append(connectionRequestId).append(EXT_TXT).toString(),
                        faf.toString());
            }
            // For IP
            if (isIpReg) {
                List<TIRequest> ip = getAllTiRequest(connectionRequestId, YES, IMPL);
                StringBuilder ipfaf = new StringBuilder();
                for (TIRequest a : ip) {
                    log.debug("req id" + a.getId());
                    ipfaf.append(getIPRegistrationAccessFormText(a.getId(), connectionRequestId,
                            Long.valueOf(a.getVersionNumber())));
                }
                attachments.put(new StringBuilder(IP).append(connectionRequestId).append(EXT_TXT).toString(),
                        ipfaf.toString());
            }

            if (isProxy) {
                List<TIRequest> ip = getAllTiRequestForPAF(connectionRequestId);
                StringBuilder ipfaf = new StringBuilder();
                for (TIRequest a : ip) {
                    log.debug("req id" + a.getId());
                    ipfaf.append(getProxyAccessFormText(a.getId(), connectionRequestId,
                            Long.valueOf(a.getVersionNumber())));
                }
                attachments.put(new StringBuilder(PAF).append(connectionRequestId).append(EXT_TXT).toString(),
                        ipfaf.toString());
            }

        }
        return attachments;
    }    
    
    /**
     * The method to retrieve details for Access Form and to set in XSLT
     * @param tiRequestID
     * @param connectionRequestId
     * @param versionID
     * @param requestType
     * @return AccessFormXsl containing XSL
     */
    public AccessFormXsl getConnectionInfoForEnhancedExport(Long tiRequestId, Long connectionRequestId, Long versionID, String requestType,String isObjectExpandable) throws Exception {
        log.info("AccessFormGenerator to xsl : tiRequestId : "+tiRequestId+" connectionRequestId : "+connectionRequestId+" versionID : "+versionID+" requestType : "+requestType);
        AccessFormXsl accessFormXsl = new AccessFormXsl();
        
        accessFormXsl.setConID(connectionRequestId);
        accessFormXsl.setVersion(versionID);
        
        
        //Original Requester Information
        accessFormXsl.setRequestor(getRequesterDetails(connectionRequestId));
        
        long planningId = getPlanningIdForTiRequestId(tiRequestId);
        if (planningId == 0)  {
            throw new Exception(
                    " No Planning Id is associated with the TiRequestId "
                    + tiRequestId);
        }
        PlanningEntity planningEntity = new PlanningEntity();
        planningEntity = getPlanningEntity(Long.valueOf(planningId));
        
        //Business Information
        RelationshipDTO relDTO  = new RelationshipDTO();
        relDTO = getRelationshipEntity(planningEntity.getRelationshipId());
        accessFormXsl.setRelDTO(relDTO);
        accessFormXsl.setConName(planningEntity.getConnectionName());
        
        //Current cycle Requester
        accessFormXsl.setCurrCycleRequestor(getRequesterDetails(planningEntity.getId()));
        
        log.debug("Current Cycle Requestor:"+accessFormXsl.getCurrCycleRequestor());
        
        String relationshipType = getRelationshipType(connectionRequestId);
        
        //for relationship type U turn and citi con need to take contacts from Requestor contacts.        
        if (C3parStaticNames.U_TURN.equalsIgnoreCase(relationshipType) || C3parStaticNames.CITI_CON.equalsIgnoreCase(relationshipType)) {
            accessFormXsl.setCurrCycleTechnicalCoordinator(proxyPersistable.getCurrentCycleTechnicalCoOrdinatorDetails(connectionRequestId));
            accessFormXsl.setTechnicalCoordinator(proxyPersistable.getOriginalTechnicalCoOrdinatorDetails(connectionRequestId));
        } else {
            accessFormXsl.setCurrCycleTechnicalCoordinator(proxyPersistable.getCurrentCycleTargetTechnicalCoOrdinatorDetails(connectionRequestId));
            accessFormXsl.setTechnicalCoordinator(proxyPersistable.getOriginalTargetTechnicalCoOrdinatorDetails(connectionRequestId));
        }
        
        if (versionID.longValue() == 1) {
            String just = getCurrentBusJustfication(tiRequestId);
            //Current Business Justification
            accessFormXsl.setCurrentBusJus(just);
            //Original Business Justification
            accessFormXsl.setOriginalBusJus(just);
        } else {
            //Current Business Justification
            accessFormXsl.setCurrentBusJus(getCurrentBusJustfication(tiRequestId));
            //Original Business Justification
            accessFormXsl.setOriginalBusJus(getOrigBusJustification(connectionRequestId, versionID));
        }
        
        log.debug("Original BusinessJustification:"+accessFormXsl.getOriginalBusJus());
        //Application Details
        if(PAF_REQUEST_TYPE.equalsIgnoreCase(requestType)){
            accessFormXsl.setApplicationDetails(getProxyApplicationDetails(connectionRequestId));
        } else if(FAF_REQUEST_TYPE.equalsIgnoreCase(requestType)){ 
            accessFormXsl.setApplicationDetails(getFirewallRuleApplicationDetails(tiRequestId,NO));
        }else if(IPFAF_REQUEST_TYPE.equalsIgnoreCase(requestType)){ 
            accessFormXsl.setApplicationDetails(getFirewallRuleApplicationDetails(tiRequestId,YES));
        }  else{
            accessFormXsl.setApplicationDetails(getApplicationDetails(connectionRequestId));
        }
        
        log.debug("Application Details"+accessFormXsl.getApplicationDetails());
        
        //System ID and SOW
        
        Map<String, String> sowAndCmp = getCMPAndSOWByVersionWithoutType(connectionRequestId, versionID);
        accessFormXsl.setSystemID(sowAndCmp.get("CMP") !=null ? sowAndCmp.get("CMP") : "");
        accessFormXsl.setSOW(sowAndCmp.get("SOW") !=null ?sowAndCmp.get("SOW"): "" );
        log.debug("AccessFormGenerator:CMP/SOW"+accessFormXsl.getSystemID()+accessFormXsl.getSOW());
        
        //Business Contacts Information
        accessFormXsl.setBusinessContacts(getBusinessContactsDetails(connectionRequestId, versionID));
        log.debug("AccessFormGeneration:GetRole/Business Contact Information:"+accessFormXsl.getBusinessContacts());
        
        //Special Instructions/Completion Date/Change Number
        Map<String,Object> implInfo = null;
        implInfo = getImplementationInfo(connectionRequestId, versionID, requestType);
        if (implInfo.size() > 0) {
            String changeNo = (String)implInfo.get("CHANGE_NUMBER");
            String compDate = (String)implInfo.get("COMPLETION_DATE");
            String specialIns =(String)implInfo.get("SPL_INSTR");
            Long infoman = (Long)implInfo.get("INFOMAN_ID");
            accessFormXsl.setSpecialInstructions(specialIns !=null ? specialIns :"");
            accessFormXsl.setCompletionDate(compDate !=null ? compDate :"");
            accessFormXsl.setInfomanID(infoman !=null ? infoman :0);
            accessFormXsl.setChangeNumber(changeNo !=null ? changeNo : "");
            // Added for RTC 85240
            String gisSpecialIns =(String)implInfo.get("GIS_SPL_INSTR");
            accessFormXsl.setGisSpecialInstructions(gisSpecialIns != null ? gisSpecialIns : "");
            //Added for RTC 92857
            String tpaswgSpecialIns = (String)implInfo.get("TPASWG_SPL_INSTR");
            accessFormXsl.setTpaswgSpecialInstructions(tpaswgSpecialIns != null ? tpaswgSpecialIns : "");
            
            log.debug("Special Instructions : "+accessFormXsl.getSpecialInstructions()+" : Completion Date: "+accessFormXsl.getCompletionDate()
                    +" Infoman ID: "+accessFormXsl.getInfomanID()+" : ChangeNumber:"+accessFormXsl.getChangeNumber()
                    +" GIS Special instructions : "+accessFormXsl.getGisSpecialInstructions()
                    +" TPASWG Special instructions : "+accessFormXsl.getTpaswgSpecialInstructions());
        }
        
        //Implementation Status and High Risk
        if(requestType.equalsIgnoreCase(PAF_REQUEST_TYPE)){
            String implementer = getCurrentProcess_status(connectionRequestId,versionID,ActivityData.ACTIVITY_PROXY_IMP);
            if(isProxyHighRisk(tiRequestId)==true) {
                accessFormXsl.setRiskInformation("Yes");
            }else {
                accessFormXsl.setRiskInformation("No");
            }
            if(implementer != null){
                accessFormXsl.setImplStatus(implementer);   
            }else {
                accessFormXsl.setImplStatus("Not Scheduled");
            }
            
            
        }else if(requestType.equalsIgnoreCase(AAF_REQUEST_TYPE)){
            String implementer = getCurrentProcess_status(connectionRequestId,versionID,ActivityData.ACTIVITY_APPSENSE_IMP);
            
            if(isAppsenseHighRisk(tiRequestId)==true) {
                accessFormXsl.setRiskInformation("Yes");
            }else {
                accessFormXsl.setRiskInformation("No");
            }
            if(implementer != null){
                accessFormXsl.setImplStatus(implementer);   
            }else {
                accessFormXsl.setImplStatus("Not Scheduled");
            }
        } else if(requestType.equalsIgnoreCase(ACL_REQUEST_TYPE)){
            String implementer = getCurrentProcess_status(connectionRequestId,versionID,ActivityData.ACL_VARIANCE_IMP);
            
            if(implementer != null){
                accessFormXsl.setImplStatus(implementer);   
            }else {
                accessFormXsl.setImplStatus("Not Scheduled");
            }
        } 
        log.debug("Implementation Status : "+accessFormXsl.getImplStatus());
        //Appsense AD group Details
        if(AAF_REQUEST_TYPE.equalsIgnoreCase(requestType)){
            AppsenseADGroup appsenseADGroup = (AppsenseADGroup)getAppsenseADGroupName(connectionRequestId,AAF_REQUEST_TYPE);
            if(appsenseADGroup != null){
                accessFormXsl.setAppsenseADGroup(appsenseADGroup);
            }
        }
        
        //Cab Approvers for IP and FAF
        if(FAF_REQUEST_TYPE.equalsIgnoreCase(requestType) || IPFAF_REQUEST_TYPE.equalsIgnoreCase(requestType)){
            RFCRequest rfcrequest = null;
            String cabApprovers = getCabApproversList(tiRequestId);
            accessFormXsl.setCabApprovers(cabApprovers);
            if(FAF_REQUEST_TYPE.equalsIgnoreCase(requestType)) {
            	accessFormXsl.setFwImplDetails(getCombinationInfo(tiRequestId, NO, rfcrequest, NO, isObjectExpandable));	
            } else if(IPFAF_REQUEST_TYPE.equalsIgnoreCase(requestType)) {
            	accessFormXsl.setFwImplDetails(getCombinationInfo(tiRequestId, YES, rfcrequest, NO, isObjectExpandable));
            }
            log.debug("AccessFormGenerator:Cab Approvers List"+accessFormXsl.getCabApprovers());
        }
        return accessFormXsl;
    }

}
