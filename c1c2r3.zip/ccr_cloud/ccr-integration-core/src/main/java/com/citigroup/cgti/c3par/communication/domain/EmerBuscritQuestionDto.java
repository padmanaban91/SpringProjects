package com.citigroup.cgti.c3par.communication.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class EmerBuscritQuestionDto {

    private List<EmerBuscritQuestionaries> emerBuscritQuestionariesList = new ArrayList<>();
    private String MDApprover;
    private Date MDApprovalDate;
    Map<String, String> emerBuscritQuestionAnswerMap = new LinkedHashMap<String,String>();
    private boolean isValidCmp;
    private boolean emerBuscrit;

    public String getMDApprover() {
        return MDApprover;
    }

    public void setMDApprover(String mDApprover) {
        MDApprover = mDApprover;
    }

    public Date getMDApprovalDate() {
        return MDApprovalDate;
    }

    public void setMDApprovalDate(Date mDApprovalDate) {
        MDApprovalDate = mDApprovalDate;
    }

    public Map<String, String> getEmerBuscritQuestionAnswerMap() {
        return emerBuscritQuestionAnswerMap;
    }

    public void setEmerBuscritQuestionAnswerMap(Map<String, String> emerBuscritQuestionAnswerMap) {
        this.emerBuscritQuestionAnswerMap = emerBuscritQuestionAnswerMap;
    }

    public List<EmerBuscritQuestionaries> getEmerBuscritQuestionariesList() {
        return emerBuscritQuestionariesList;
    }

    public void setEmerBuscritQuestionariesList(List<EmerBuscritQuestionaries> emerBuscritQuestionariesList) {
        this.emerBuscritQuestionariesList = emerBuscritQuestionariesList;
    }

    public boolean isValidCmp() {
        return isValidCmp;
    }

    public void setValidCmp(boolean isValidCmp) {
        this.isValidCmp = isValidCmp;
    }

	public boolean isEmerBuscrit() {
		return emerBuscrit;
	}

	public void setEmerBuscrit(boolean emerBuscrit) {
		this.emerBuscrit = emerBuscrit;
	}

}
