/*
 * 
 */
package com.citigroup.cgti.c3par.domain;

import java.io.Serializable;
import java.util.Date;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.citigroup.cgti.c3par.performer.dao.PerformerPagerDO;
import com.citigroup.cgti.c3par.performer.util.PerformerTypes;

// TODO: Auto-generated Javadoc
/**
 * The Class Application.
 */
@XmlRootElement
@XmlType(name="ApplicationEntity")
public class Application extends PerformerPagerDO implements Serializable {

    /** The function. */
    private String function;

    /** The app owner. */
    private Person appOwner = new Person();

    /** The application id. */
    private Long applicationID;

    /** The device model. */
    private String deviceModel;

    /** The device other text. */
    private String deviceOtherText;

    /** The device type id. */
    private Long deviceTypeId;

    /** The is device. */
    private String isDevice;

    /** The is csi. */
    private String isCSI;

    /** The selected. */
    private boolean selected;

    /** The app owner full name. */
    private String appOwnerFullName;

    /** The app owner geid. */
    private String appOwnerGEID;

    /** The app owner email. */
    private String appOwnerEmail;

    /** The application name. */
    private String applicationName;

    /** The va flag. */
    private String vaFlag;

    /** The va number. */
    private String vaNumber;

    /** The va sch date. */
    private Date vaSchDate;

    /** The va comments. */
    private String vaComments;

    /** The is black listed. */
    private String isBlackListed;

    /** The exe file name. */
    private String exeFileName;

    private String exeFileNameNonCSI;


    /** The network path. */
    private String networkPath;

    /** The app manager full name. */
    private String appManagerFullName;

    /** The app manager geid. */
    private String appManagerGEID;

    /** The app manager email. */
    private String appManagerEmail;

    private String secClassification;
    private String personaDataIndicator;
    
    private Date decommissisonNotifDate;
    
    private String isDeCommissioned;
    
    private String appType;
    /**
     * Instantiates a new application.
     */
    public Application() {

	// ---------------------
	setTableName(PerformerTypes.TI_APPLICATION_TABEL);
	setSequenceName(PerformerTypes.SEQ_TI_APPLICATION);

	// ---------------------
	addToDBMapping("function", "APPLICAITON_DESC", 1);
	addToDBMapping("applicationID", "APPLICATION_ID", 2);
	addToDBMapping("deviceModel", "DEVICE_MODEL", 3);
	addToDBMapping("deviceOtherText", "DEVICE_OTHER_TEXT", 4);
	addToDBMapping("deviceTypeId", "DEVICE_TYPE_ID", 5);
	addToDBMapping("isDevice", "IS_DEVICE", 6);
	addToDBMapping("isCSI", "IS_CSI", 7);
	addToDBMapping("appOwnerFullName", "APP_OWNER_FULL_NAME", 8);
	addToDBMapping("appOwnerGEID", "APP_OWNER_GEID", 9);
	addToDBMapping("appOwnerEmail", "APP_OWNER_EMAIL", 10);
	addToDBMapping("applicationName", "APPLICATION_NAME", 11);

	addToDBMapping("vaFlag", "VA_FLAG", 12);
	addToDBMapping("vaNumber", "VA_NUMBER", 13);
	addToDBMapping("vaSchDate", "VA_SCH_DATE", 14);
	addToDBMapping("vaComments", "VA_COMMENTS", 15);
	addToDBMapping("isBlackListed", "IS_BLACKLISTED", 16);
	addToDBMapping("exeFileName", "EXE_FILENAME", 17);
	addToDBMapping("networkPath", "NETWORK_PATH", 18);

	addToDBMapping("appManagerGEID", "APP_MGR_GEID", 19);
	addToDBMapping("appManagerEmail", "APP_MGR_EMAIL", 20);
	addToDBMapping("appManagerFullName", "APP_MGR_FULL_NAME", 21);
	addToDBMapping("secClassification", "sec_classification", 22);
	addToDBMapping("personaDataIndicator", "per_data_indicator", 23);

	// ---------------------

	addToNonPersistanceList("appOwner");
	addToNonPersistanceList("selected");
	addToNonPersistanceList("exeFileNameNonCSI");

    }

    /**
     * Gets the app owner email.
     * 
     * @return Returns the appOwnerEmail.
     */
    @XmlElement
    public String getAppOwnerEmail() {
	return appOwnerEmail;
    }

    /**
     * Sets the app owner email.
     * 
     * @param appOwnerEmail
     *            The appOwnerEmail to set.
     */
    public void setAppOwnerEmail(String appOwnerEmail) {
	this.appOwnerEmail = appOwnerEmail;
	getAppOwner().setEmailAddress(appOwnerEmail);
    }

    /**
     * Gets the app owner full name.
     * 
     * @return Returns the appOwnerFullName.
     */
    @XmlElement
    public String getAppOwnerFullName() {
	return appOwnerFullName;
    }

    /**
     * Sets the app owner full name.
     * 
     * @param appOwnerFullName
     *            The appOwnerFullName to set.
     */
    public void setAppOwnerFullName(String appOwnerFullName) {
	this.appOwnerFullName = appOwnerFullName;
	getAppOwner().setFullName(appOwnerFullName);
    }

    /**
     * Gets the app owner geid.
     * 
     * @return Returns the appOwnerGEID.
     */
    @XmlElement
    public String getAppOwnerGEID() {
	return appOwnerGEID;
    }

    /**
     * Sets the app owner geid.
     * 
     * @param appOwnerGEID
     *            The appOwnerGEID to set.
     */
    public void setAppOwnerGEID(String appOwnerGEID) {
	this.appOwnerGEID = appOwnerGEID;
	getAppOwner().setGeid(appOwnerGEID);
    }

    /**
     * Gets the device model.
     * 
     * @return the device model
     */
    @XmlElement
    public String getDeviceModel() {
	return deviceModel;
    }

    /**
     * Sets the device model.
     * 
     * @param deviceModel
     *            the new device model
     */
    public void setDeviceModel(String deviceModel) {
	this.deviceModel = deviceModel;
    }

    /**
     * Gets the device other text.
     * 
     * @return the device other text
     */
    @XmlElement
    public String getDeviceOtherText() {
	return deviceOtherText;
    }

    /**
     * Sets the device other text.
     * 
     * @param deviceOtherText
     *            the new device other text
     */
    public void setDeviceOtherText(String deviceOtherText) {
	this.deviceOtherText = deviceOtherText;
    }

    /**
     * Gets the device type id.
     * 
     * @return the device type id
     */
    @XmlElement
    public Long getDeviceTypeId() {
	return deviceTypeId;
    }

    /**
     * Sets the device type id.
     * 
     * @param deviceTypeId
     *            the new device type id
     */
    public void setDeviceTypeId(Long deviceTypeId) {
	this.deviceTypeId = deviceTypeId;
    }

    /**
     * Gets the app owner.
     * 
     * @return the app owner
     */
    @XmlElement
    public Person getAppOwner() {
	return appOwner;
    }

    /**
     * Sets the app owner.
     * 
     * @param appOwner
     *            the new app owner
     */
    public void setAppOwner(Person appOwner) {
	this.appOwner = appOwner;
	setAppOwnerFullName(appOwner.getFullName());
	setAppOwnerGEID(appOwner.getGeid());
	setAppOwnerEmail(appOwner.getEmailAddress());
    }

    /**
     * Gets the function.
     * 
     * @return the function
     */
    @XmlElement
    public String getFunction() {
	if (function != null && function.length() > 500)
	    return function.substring(0, 500);
	return function;
    }

    /**
     * Sets the function.
     * 
     * @param function
     *            the new function
     */
    public void setFunction(String function) {
	this.function = function;
    }

    /**
     * Gets the application id.
     * 
     * @return Returns the applicationID.
     */
    @XmlElement
    public Long getApplicationID() {
	return applicationID;
    }

    /**
     * Sets the application id.
     * 
     * @param applicationID
     *            The applicationID to set.
     */
    public void setApplicationID(Long applicationID) {
	this.applicationID = applicationID;
    }

    /**
     * Gets the checks if is csi.
     * 
     * @return the checks if is csi
     */
    public String getIsCSI() {
	return isCSI;
    }

    /**
     * Sets the checks if is csi.
     * 
     * @param isCSI
     *            the new checks if is csi
     */
    public void setIsCSI(String isCSI) {
	this.isCSI = isCSI;
    }

    /**
     * Gets the checks if is device.
     * 
     * @return the checks if is device
     */
    public String getIsDevice() {
	return isDevice;
    }

    /**
     * Sets the checks if is device.
     * 
     * @param isDevice
     *            the new checks if is device
     */
    public void setIsDevice(String isDevice) {
	this.isDevice = isDevice;
    }

    /*
     * (non-Javadoc)
     * @see com.citigroup.cgti.c3par.domain.Base#isSelected()
     */
    public boolean isSelected() {
	return selected;
    }

    /*
     * (non-Javadoc)
     * @see com.citigroup.cgti.c3par.domain.Base#setSelected(boolean)
     */
    public void setSelected(boolean selected) {
	this.selected = selected;
    }

    /**
     * Gets the application name.
     * 
     * @return the application name
     */
    public String getApplicationName() {
	return applicationName;
    }

    /**
     * Sets the application name.
     * 
     * @param applicationName
     *            the new application name
     */
    public void setApplicationName(String applicationName) {
	this.applicationName = applicationName;
    }

    /**
     * Checks if is empty.
     * 
     * @return true, if is empty
     */
    public boolean isEmpty() {

	if (isDevice != null && "Y".equalsIgnoreCase(isDevice)
		&& (deviceTypeId != null || deviceTypeId.longValue() > 0))
	    return false;
	if (isCSI != null && "Y".equalsIgnoreCase(isCSI)
		&& ((applicationID != null || (applicationID.longValue() > 0))))
	    return false;
	if (isCSI != null
		&& "N".equalsIgnoreCase(isCSI)
		&& (!(applicationName == null || ""
			.equalsIgnoreCase(applicationName.trim()))))
	    return false;

	return true;

    }

    /**
     * Gets the va comments.
     * 
     * @return the va comments
     */
    public String getVaComments() {
	return vaComments;
    }

    /**
     * Sets the va comments.
     * 
     * @param vaComments
     *            the new va comments
     */
    public void setVaComments(String vaComments) {
	this.vaComments = vaComments;
    }

    /**
     * Gets the va flag.
     * 
     * @return the va flag
     */
    public String getVaFlag() {
	return vaFlag;
    }

    /**
     * Sets the va flag.
     * 
     * @param vaFlag
     *            the new va flag
     */
    public void setVaFlag(String vaFlag) {
	this.vaFlag = vaFlag;
    }

    /**
     * Gets the va number.
     * 
     * @return the va number
     */
    public String getVaNumber() {
	return vaNumber;
    }

    /**
     * Sets the va number.
     * 
     * @param vaNumber
     *            the new va number
     */
    public void setVaNumber(String vaNumber) {
	this.vaNumber = vaNumber;
    }

    /**
     * Gets the va sch date.
     * 
     * @return the va sch date
     */
    public Date getVaSchDate() {
	return vaSchDate;
    }

    /**
     * Sets the va sch date.
     * 
     * @param vaSchDate
     *            the new va sch date
     */
    public void setVaSchDate(Date vaSchDate) {
	this.vaSchDate = vaSchDate;
    }

    /**
     * Gets the checks if is black listed.
     * 
     * @return the checks if is black listed
     */
    @XmlElement
    public String getIsBlackListed() {
	return isBlackListed;
    }

    /**
     * Sets the checks if is black listed.
     * 
     * @param isBlackListed
     *            the new checks if is black listed
     */
    public void setIsBlackListed(String isBlackListed) {
	this.isBlackListed = isBlackListed;
    }

    /**
     * Gets the exe file name.
     * 
     * @return the exe file name
     */
    @XmlElement
    public String getExeFileName() {
	return exeFileName;
    }

    /**
     * Sets the exe file name.
     * 
     * @param exeFileName
     *            the new exe file name
     */
    public void setExeFileName(String exeFileName) {
	this.exeFileName = exeFileName;
    }

    /**
     * Gets the network path.
     * 
     * @return the networkPath
     */
    @XmlElement
    public String getNetworkPath() {
	return networkPath;
    }

    /**
     * Sets the network path.
     * 
     * @param networkPath
     *            the networkPath to set
     */
    public void setNetworkPath(String networkPath) {
	this.networkPath = networkPath;
    }

    /**
     * Gets the app manager full name.
     * 
     * @return the app manager full name
     */
    @XmlElement
    public String getAppManagerFullName() {
	return appManagerFullName;
    }

    /**
     * Sets the app manager full name.
     * 
     * @param appManagerFullName
     *            the new app manager full name
     */
    public void setAppManagerFullName(String appManagerFullName) {
	this.appManagerFullName = appManagerFullName;
    }

    /**
     * Gets the app manager geid.
     * 
     * @return the app manager geid
     */
    @XmlElement
    public String getAppManagerGEID() {
	return appManagerGEID;
    }

    /**
     * Sets the app manager geid.
     * 
     * @param appManagerGEID
     *            the new app manager geid
     */
    public void setAppManagerGEID(String appManagerGEID) {
	this.appManagerGEID = appManagerGEID;
    }

    /**
     * Gets the app manager email.
     * 
     * @return the app manager email
     */
    @XmlElement
    public String getAppManagerEmail() {
	return appManagerEmail;
    }

    /**
     * Sets the app manager email.
     * 
     * @param appManagerEmail
     *            the new app manager email
     */
    public void setAppManagerEmail(String appManagerEmail) {
	this.appManagerEmail = appManagerEmail;
    }

    /**
     * Checks if is valid black list app.
     * Added for #10494
     * @return true, if is valid black list app
     */
    public boolean isValidBlackListApp() {
	boolean returnValue = true;
	returnValue = (applicationName != null && !"".equals(applicationName));
	return returnValue;
    }

    /**
     * Checks if is valid csi app.
     * Added for #10494
     * @return true, if is valid csi app
     */
    public boolean isValidCSIApp() {
	boolean returnValue = true;
	returnValue = (applicationID != null && applicationID != 0);
	return returnValue;
    }

    /**
     * Checks if is valid non csi app.
     * Added for #10494
     * @return true, if is valid non csi app
     */
    public boolean isValidNonCSIApp() {
	boolean returnValue = true;
	returnValue = ((applicationName != null && !"".equals(applicationName))
		&& (function != null && !"".equals(function))
		&& ( appOwnerFullName!= null && !"".equals(appOwnerFullName)) && (appOwnerGEID != null && !""
			.equals(appOwnerGEID)));
	return returnValue;

    }
    /**
     * @return the exeFileNameNonCSI
     */
    @XmlElement
    public String getExeFileNameNonCSI() {
	return exeFileNameNonCSI;
    }

    /**
     * @param exeFileNameNonCSI the exeFileNameNonCSI to set
     */
    public void setExeFileNameNonCSI(String exeFileNameNonCSI) {
	this.exeFileNameNonCSI = exeFileNameNonCSI;
    }
    @XmlElement
	public String getSecClassification() {
		return secClassification;
	}

	public void setSecClassification(String secClassification) {
		this.secClassification = secClassification;
	}
	@XmlElement
	public String getPersonaDataIndicator() {
		return personaDataIndicator;
	}

	public void setPersonaDataIndicator(String personaDataIndicator) {
		this.personaDataIndicator = personaDataIndicator;
	}
	@XmlElement
	public String getAppType() {
		StringBuilder str = new StringBuilder();
		if(this.getIsBlackListed() != null && this.getIsBlackListed().equalsIgnoreCase("Y")){
			str.append("BlackListed");
		}if(this.getIsCSI() != null && this.getIsCSI().equalsIgnoreCase("Y")){
			str.append("CSI");
		}if(this.getIsBlackListed() != null && this.getIsBlackListed().equalsIgnoreCase("N") 
				&& this.getIsCSI() != null && this.getIsCSI().equalsIgnoreCase("N")){
			str.append("NonCSI");
		}
		return str.toString();
	}

	public void setAppType(String appType) {
		this.appType = appType;
	}

	public Date getDecommissisonNotifDate() {
		return decommissisonNotifDate;
	}

	public void setDecommissisonNotifDate(Date decommissisonNotifDate) {
		this.decommissisonNotifDate = decommissisonNotifDate;
	}

    public String getIsDeCommissioned() {
        return isDeCommissioned;
    }

    public void setIsDeCommissioned(String isDeCommissioned) {
        this.isDeCommissioned = isDeCommissioned;
    }
	
	
}
