

/*
 * CONFIDENTIAL  AND PROPRIETARY
 * Copyright ? 2004 Mentisys, Inc. All rights reserved.
 * The contents of this material are confidential and proprietary to 
 * Mentisys, Inc. Unauthorized use, disclosure, or reproduction is 
 * strictly prohibited.
 */
package com.citigroup.cgti.c3par.dao.lookup;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import com.citigroup.cgti.c3par.model.*;
import com.citigroup.cgti.c3par.dao.*;
import com.mentisys.dao.*;
import com.mentisys.dao.query.*;


/**
 * The Class ResourceTypeLookup.
 */
public class ResourceTypeLookup
{

    /** The initialized. */
    private boolean		initialized = false;

    /** The ordered list. */
    private ArrayList 	orderedList = new ArrayList();

    /** The values by id. */
    private HashMap		valuesById = new HashMap();

    /** The values by name. */
    private HashMap		valuesByName = new HashMap();

    /** The values by perimeter. */
    private HashMap		valuesByPerimeter = new HashMap();

    /** The values by broad access ip. */
    private HashMap		valuesByBroadAccessIp = new HashMap();

    /** The values by status. */
    private HashMap		valuesByStatus = new HashMap();

    /** The values by created by. */
    private HashMap		valuesByCreatedBy = new HashMap();

    /** The values by created date. */
    private HashMap		valuesByCreatedDate = new HashMap();

    /** The values by modified by. */
    private HashMap		valuesByModifiedBy = new HashMap();

    /** The values by modified date. */
    private HashMap		valuesByModifiedDate = new HashMap();

    /** The instance. */
    static private ResourceTypeLookup instance = null;

    //======================================================================
    /**
     * Gets the single instance of ResourceTypeLookup.
     *
     * @return single instance of ResourceTypeLookup
     */
    synchronized static public ResourceTypeLookup getInstance()
    {
	if (instance == null)
	{
	    instance = new ResourceTypeLookup();
	}
	return instance;
    }

    //======================================================================
    /**
     * Gets the single instance of ResourceTypeLookup.
     *
     * @param session the session
     * @return single instance of ResourceTypeLookup
     * @throws DatabaseException the database exception
     */
    synchronized static public ResourceTypeLookup getInstance(DatabaseSession session) throws DatabaseException
    {
	if (instance == null)
	{
	    instance = new ResourceTypeLookup();
	    instance.initialize(session);	
	}
	else if(!instance.isInitialized())
	{
	    instance.initialize(session);	
	}
	return instance;
    }

    //======================================================================
    /**
     * Instantiates a new resource type lookup.
     */
    private ResourceTypeLookup()
    {
	super();
	initialized = false;
    }

    //======================================================================
    /**
     * Initialize.
     *
     * @param session the session
     * @throws DatabaseException the database exception
     */
    synchronized public void initialize(DatabaseSession session) throws DatabaseException
    {
	if (!initialized)
	{
	    ResourceTypeDAO dao = new ResourceTypeDAO(session);
	    ResourceTypeEntity entity = null;
	    Condition condition = new Condition();
	    condition.addOrderByField(ResourceTypeDAO.COLUMN_NAME);
	    try
	    {
		List list = dao.query(condition, false);
		Iterator it = list.iterator();

		while (it.hasNext())
		{
		    entity = (ResourceTypeEntity) it.next();
		    valuesById.put(entity.getId(), entity);
		    valuesByName.put(entity.getName(), entity);
		    valuesByPerimeter.put(entity.getPerimeter(), entity);
		    valuesByBroadAccessIp.put(entity.getBroadAccessIp(), entity);
		    valuesByStatus.put(entity.getStatus(), entity);
		    valuesByCreatedBy.put(entity.getCreatedBy(), entity);
		    valuesByCreatedDate.put(entity.getCreatedDate(), entity);
		    valuesByModifiedBy.put(entity.getModifiedBy(), entity);
		    valuesByModifiedDate.put(entity.getModifiedDate(), entity);
		    orderedList.add(entity);
		}
		initialized = true;

		it = list.iterator();
		while (it.hasNext())
		{
		    entity = (ResourceTypeEntity) it.next();
		    dao.loadReferences((ResourceTypeEntity)entity);
		}
	    }
	    catch (DatabaseException e)
	    {
		throw e;
	    }
	}
    }

    //======================================================================
    /**
     * Reset.
     */
    synchronized public void reset()
    {
	valuesById = new HashMap();
	orderedList = new ArrayList();
	initialized = false;
	valuesByName = new HashMap();
	valuesByPerimeter = new HashMap();
	valuesByBroadAccessIp = new HashMap();
	valuesByStatus = new HashMap();
	valuesByCreatedBy = new HashMap();
	valuesByCreatedDate = new HashMap();
	valuesByModifiedBy = new HashMap();
	valuesByModifiedDate = new HashMap();
    }

    //======================================================================
    /**
     * Gets the by id.
     *
     * @param id the id
     * @return the by id
     */
    synchronized public ResourceTypeEntity getById(Long id)
    {
	return (ResourceTypeEntity) valuesById.get(id);
    }

    //======================================================================
    /**
     * Gets the by id.
     *
     * @param session the session
     * @param id the id
     * @return the by id
     * @throws DatabaseException the database exception
     */
    synchronized public ResourceTypeEntity getById(DatabaseSession session, Long id) throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (ResourceTypeEntity) valuesById.get(id);
    }

    //======================================================================
    /**
     * Gets the by name.
     *
     * @param v the v
     * @return the by name
     */
    synchronized public ResourceTypeEntity getByName(String v)
    {
	return (ResourceTypeEntity) valuesByName.get(v);
    }

    //======================================================================
    /**
     * Gets the by name.
     *
     * @param session the session
     * @param v the v
     * @return the by name
     * @throws DatabaseException the database exception
     */
    synchronized public ResourceTypeEntity getByName(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (ResourceTypeEntity) valuesByName.get(v);
    }
    //======================================================================
    /**
     * Gets the by perimeter.
     *
     * @param v the v
     * @return the by perimeter
     */
    synchronized public ResourceTypeEntity getByPerimeter(String v)
    {
	return (ResourceTypeEntity) valuesByPerimeter.get(v);
    }

    //======================================================================
    /**
     * Gets the by perimeter.
     *
     * @param session the session
     * @param v the v
     * @return the by perimeter
     * @throws DatabaseException the database exception
     */
    synchronized public ResourceTypeEntity getByPerimeter(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (ResourceTypeEntity) valuesByPerimeter.get(v);
    }
    //======================================================================
    /**
     * Gets the by broad access ip.
     *
     * @param v the v
     * @return the by broad access ip
     */
    synchronized public ResourceTypeEntity getByBroadAccessIp(String v)
    {
	return (ResourceTypeEntity) valuesByBroadAccessIp.get(v);
    }

    //======================================================================
    /**
     * Gets the by broad access ip.
     *
     * @param session the session
     * @param v the v
     * @return the by broad access ip
     * @throws DatabaseException the database exception
     */
    synchronized public ResourceTypeEntity getByBroadAccessIp(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (ResourceTypeEntity) valuesByBroadAccessIp.get(v);
    }
    //======================================================================
    /**
     * Gets the by status.
     *
     * @param v the v
     * @return the by status
     */
    synchronized public ResourceTypeEntity getByStatus(String v)
    {
	return (ResourceTypeEntity) valuesByStatus.get(v);
    }

    //======================================================================
    /**
     * Gets the by status.
     *
     * @param session the session
     * @param v the v
     * @return the by status
     * @throws DatabaseException the database exception
     */
    synchronized public ResourceTypeEntity getByStatus(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (ResourceTypeEntity) valuesByStatus.get(v);
    }
    //======================================================================
    /**
     * Gets the by created by.
     *
     * @param v the v
     * @return the by created by
     */
    synchronized public ResourceTypeEntity getByCreatedBy(String v)
    {
	return (ResourceTypeEntity) valuesByCreatedBy.get(v);
    }

    //======================================================================
    /**
     * Gets the by created by.
     *
     * @param session the session
     * @param v the v
     * @return the by created by
     * @throws DatabaseException the database exception
     */
    synchronized public ResourceTypeEntity getByCreatedBy(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (ResourceTypeEntity) valuesByCreatedBy.get(v);
    }
    //======================================================================
    /**
     * Gets the by created date.
     *
     * @param v the v
     * @return the by created date
     */
    synchronized public ResourceTypeEntity getByCreatedDate(Date v)
    {
	return (ResourceTypeEntity) valuesByCreatedDate.get(v);
    }

    //======================================================================
    /**
     * Gets the by created date.
     *
     * @param session the session
     * @param v the v
     * @return the by created date
     * @throws DatabaseException the database exception
     */
    synchronized public ResourceTypeEntity getByCreatedDate(DatabaseSession session, Date v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (ResourceTypeEntity) valuesByCreatedDate.get(v);
    }
    //======================================================================
    /**
     * Gets the by modified by.
     *
     * @param v the v
     * @return the by modified by
     */
    synchronized public ResourceTypeEntity getByModifiedBy(String v)
    {
	return (ResourceTypeEntity) valuesByModifiedBy.get(v);
    }

    //======================================================================
    /**
     * Gets the by modified by.
     *
     * @param session the session
     * @param v the v
     * @return the by modified by
     * @throws DatabaseException the database exception
     */
    synchronized public ResourceTypeEntity getByModifiedBy(DatabaseSession session, String v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (ResourceTypeEntity) valuesByModifiedBy.get(v);
    }
    //======================================================================
    /**
     * Gets the by modified date.
     *
     * @param v the v
     * @return the by modified date
     */
    synchronized public ResourceTypeEntity getByModifiedDate(Date v)
    {
	return (ResourceTypeEntity) valuesByModifiedDate.get(v);
    }

    //======================================================================
    /**
     * Gets the by modified date.
     *
     * @param session the session
     * @param v the v
     * @return the by modified date
     * @throws DatabaseException the database exception
     */
    synchronized public ResourceTypeEntity getByModifiedDate(DatabaseSession session, Date v)
    throws DatabaseException
    {
	if (!initialized)
	{
	    initialize(session);
	}
	return (ResourceTypeEntity) valuesByModifiedDate.get(v);
    }

    //======================================================================
    /**
     * Gets the all.
     *
     * @return the all
     */
    synchronized public ArrayList getAll()
    {
	return orderedList;
    }

    //======================================================================
    /**
     * Checks if is initialized.
     *
     * @return true, if is initialized
     */
    synchronized public boolean isInitialized()
    {
	return initialized;
    }
}
