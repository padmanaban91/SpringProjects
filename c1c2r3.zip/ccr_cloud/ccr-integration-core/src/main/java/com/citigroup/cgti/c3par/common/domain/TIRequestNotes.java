package com.citigroup.cgti.c3par.common.domain;

import java.io.Serializable;
import java.util.Date;

import com.citigroup.cgti.c3par.domain.TIRequest;
import com.citigroup.cgti.c3par.user.domain.C3parUser;

/**
 * @author ac81662
 *
 */
public class TIRequestNotes implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private Long id;
    private TIRequest tiRequest;
    private Long tiProcessId;
    private C3parUser userParticipated;
    private String notes;
    private Date createdDate;
    
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public TIRequest getTiRequest() {
        return tiRequest;
    }
    public void setTiRequest(TIRequest tiRequest) {
        this.tiRequest = tiRequest;
    }
    public C3parUser getUserParticipated() {
        return userParticipated;
    }
    public void setUserParticipated(C3parUser userParticipated) {
        this.userParticipated = userParticipated;
    }
    public String getNotes() {
        return notes;
    }
    public void setNotes(String notes) {
        this.notes = notes;
    }
    public Date getCreatedDate() {
        return createdDate;
    }
    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }
    public Long getTiProcessId() {
        return tiProcessId;
    }
    public void setTiProcessId(Long tiProcessId) {
        this.tiProcessId = tiProcessId;
    }
    
}
