package com.citigroup.cgti.c3par.admin.domain;

import java.util.ArrayList;
import java.util.List;

import com.citigroup.cgti.c3par.fw.service.ResolveITQueueSenderImpl;
import com.citigroup.cgti.c3par.fw.service.ServiceNowQueueSenderImpl;

public class MessagePublisherProcess {
    public static String SERVICE_NOW = "ServiceNow";
    public static String RESOLVE_IT = "ResolveIT";

    private ServiceNowQueueSenderImpl serviceNowSender;
    private ResolveITQueueSenderImpl resolveITSender;

    private String xmlMessage;
    private List<String> sourceSystemList;
    private String senderSystem;

    public String getXmlMessage() {
        return xmlMessage;
    }

    public void setXmlMessage(String xmlMessage) {
        this.xmlMessage = xmlMessage;
    }

    public List<String> getSourceSystemList() {
        sourceSystemList = new ArrayList<String>();
        sourceSystemList.add(SERVICE_NOW);
        sourceSystemList.add(RESOLVE_IT);
        return sourceSystemList;
    }

    public void setSourceSystemList(List<String> sourceSystemList) {
        this.sourceSystemList = sourceSystemList;
    }

    public String getSenderSystem() {
        return senderSystem;
    }

    public void setSenderSystem(String senderSystem) {
        this.senderSystem = senderSystem;
    }

    public void sendMessage() {
        if (SERVICE_NOW.equals(senderSystem)) {
            serviceNowSender = new ServiceNowQueueSenderImpl();
            serviceNowSender.sendMesage(getXmlMessage());
        } else if (RESOLVE_IT.equals(senderSystem)) {
            resolveITSender = new ResolveITQueueSenderImpl();
            resolveITSender.sendMesage(getXmlMessage());
        }
    }
}
