package com.citigroup.cgti.c3par.communication.domain;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.log4j.Logger;

import com.citigroup.cgti.c3par.domain.C3PARMailMessage;
import com.citigroup.cgti.c3par.domain.MailMsgDisplayRow;

@XmlRootElement
public class CmpRequestDTO extends C3PARMailMessage{
	

	@SuppressWarnings("unused")
	private Logger log = Logger.getLogger(this.getClass().getName());
	
	private Date assignedDate;
	
	private String requestType;
	
	private String urgency;
	
	private String assistanceRequested;
	
	private String ccrId;
	
	private String chgId;
	
	private String chgDate;
	
	private String rqdAddInfo;
	
	private String businessResponse;

	private String implementedDate;	
	
	private String requesterSsoId;	
	
	private String bj;
	
	private String emailAddress;
	
	private String connName;
	
	private String role;
	
	private String textForSubject;

	private String addInfo;
	
	private String phoneNo;	
	
	private String reAssignedUser;
	
	private String reAssignedUserEmail;
	
	private String reAssignedUserPhone;
	
	private	String ssoId;
	
	private	String requestorName;
	
	private	String primaryOwnerName;
	
	private	String secondaryOwnerName;
	
	private	String isoName;
	
	private	String assignedUserName;
	
	private	String agentName;
	
	private	String agentPhone;
	
	private	String agentEmail;
	
	private	String cancelReason;
	
	private boolean secondTemplate;
	private boolean isEcmInput;

	private	HashMap<String, String> attachments;
	
	private String leadName;
	
	private String leadEmail;
	
	private String leadPhone;
	
	private String orderId;
	
	private String step;
	
	private String orderBy;
	
	private String orderFor;
	
	private String chooseEmail;
	
	private Date loggedDate;
	
	private Date dueDate;
	
	private String leadComments;
	/*Started For ECM FLOW*/
	private String reqAdditionalInfo;
	private String comments;
	private Long tiRequestId;
    private String cmpStatusUrl;
    private String mdQuestionUrl;
    
    private MailMsgDisplayRow [] questRow;
	
    private String managingDirectorName;
    private Long addInfoId;
    
    private String mgrCompletedReason;
    
    private String businessJustificationReqInfo;

    private String businessJustificationBUResponse;

    private String citiGrpDataReqInfo;

    private String citiGrpDataBUResponse;

    private String customerDataReqInfo;

    private String customerDataBUResponse;

    private String connectionFreqencyReqInfo;

    private String connectionFreqencyBUResponse;

    private String gocCodeReqInfo;

    private String gocCodeBUResponse;

    private String typeOfEntityReqInfo;

    private String typeOfEntityBUResponse;

    private String directAccessReqInfo;

    private String directAccessBUResponse;

    private String reasonReqInfo;

    private String reasonBUResponse;

    private String urgencyReqInfo;

    private String urgencyBUResponse;

    private String affectedBusinessReqInfo;

    private String affectedBusinessBUResponse;

    private String reqSSOId;

    private String buSSOId;
    
    private String citiGrpData;

    private String customerData;

    private String connectionFreqency;

    private String gocCode;

    private String typeOfEntity;

    private String directAccess;

    private String reason;

    private String cmpUrgency;

    private String affectedBusiness;
    
    private String reqInfoCreatedDate;

    private String reqInfoParticipant;

    private String reqInfo;
    
    private String regionReqInfo;

    private String regionBUResponse;

    private String sectorReqInfo;

    private String sectorBUResponse;

    private String businessUnitReqInfo;

    private String businessUnitBUResponse;

    private String companyNameReqInfo;

    private String companyNameBUResponse;

    private String tptContactNameReqInfo;

    private String tptContactNameBUResponse;

    private String caspSuppIdReqInfo;

    private String caspSuppIdBUResponse;

    private String tptContactTypeReqInfo;

    private String tptContactTypeBUResponse;

    private String caspDetailIdReqInfo;

    private String caspDetailIdBUResponse;

    private String tptContactPhoneReqInfo;

    private String tptContactPhoneBUResponse;

    private String tptContactEmailReqInfo;

    private String tptContactEmailBUResponse;

    private String businessUnit;

    private String companyName;

    private String tptContactName;

    private String caspSuppId;

    private String tptContactType;

    private String caspDetailId;

    private String tptContactPhone;

    private String tptContactEmail;
    
	private String tiMailAudtiId;

	private Map<String, String> emerBuscritQuesAndAnswers;
	
	private String orderItemId;
	
	private Date managingDirectorApprovalDate;
	
	/**
     * @return the tiRequestId
     */
    public Long getTiRequestId() {
        return tiRequestId;
    }

    /**
     * @param tiRequestId the tiRequestId to set
     */
    public void setTiRequestId(Long tiRequestId) {
        this.tiRequestId = tiRequestId;
    }

    public String getReqAdditionalInfo() {
		return reqAdditionalInfo;
	}

	public void setReqAdditionalInfo(String reqAdditionalInfo) {
		this.reqAdditionalInfo = reqAdditionalInfo;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}
	
	/*END  ECM FLOW*/
	
	
	
	

	private ChangeRequestDetails[] changeRequestDetails;
	

	public static class ChangeRequestDetails {

        

        private String chgNum;

           

        private String chgDate;
        		
    			@XmlElement
                public String getChgNum() {

                        return chgNum;

                }

                public void setChgNum(String chgNum) {

                        this.chgNum = chgNum;

                }

            	@XmlElement
                public String getChgDate() { 

                        return chgDate;

                }

                public void setChgDate(String chgDate) {

                        this.chgDate = chgDate;

                }

	}
    

	@XmlElement
	public String getLeadComments() {
		return leadComments;
	}

	public void setLeadComments(String leadComments) {
		this.leadComments = leadComments;
	}
	
	
	@XmlElement
	public String getChooseEmail() {
		return chooseEmail;
	}

	public void setChooseEmail(String chooseEmail) {
		this.chooseEmail = chooseEmail;
	}

	@XmlElement
	public String getChgDate() {
		return chgDate;
	}

	public void setChgDate(String chgDate) {
		this.chgDate = chgDate;
	}
	
	@XmlElement
	public String getRqdAddInfo() {
		return rqdAddInfo;
	}

	public void setRqdAddInfo(String rqdAddInfo) {
		this.rqdAddInfo = rqdAddInfo;
	}

	@XmlElement
	public String getBusinessResponse() {
		return businessResponse;
	}

	public void setBusinessResponse(String businessResponse) {
		this.businessResponse = businessResponse;
	}

	@XmlElement
	public String getReAssignedUser() {
		return reAssignedUser;
	}

	public void setReAssignedUser(String reAssignedUser) {
		this.reAssignedUser = reAssignedUser;
	}

	@XmlElement
	public String getRequestorName() {
		return requestorName;
	}

	public void setRequestorName(String requestorName) {
		this.requestorName = requestorName;
	}

	@XmlElement
	public String getPrimaryOwnerName() {
		return primaryOwnerName;
	}

	public void setPrimaryOwnerName(String primaryOwnerName) {
		this.primaryOwnerName = primaryOwnerName;
	}

	@XmlElement
	public String getSecondaryOwnerName() {
		return secondaryOwnerName;
	}

	public void setSecondaryOwnerName(String secondaryOwnerName) {
		this.secondaryOwnerName = secondaryOwnerName;
	}

	@XmlElement
	public String getIsoName() {
		return isoName;
	}

	public void setIsoName(String isoName) {
		this.isoName = isoName;
	}

	@XmlElement
	public String getAssignedUserName() {
		return assignedUserName;
	}

	public void setAssignedUserName(String assignedUserName) {
		this.assignedUserName = assignedUserName;
	}

	@XmlElement
	public String getAgentName() {
		return agentName;
	}

	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}

	@XmlElement
	public String getCancelReason() {
		return cancelReason;
	}

	public void setCancelReason(String cancelReason) {
		this.cancelReason = cancelReason;
	}

	@XmlElement
	public String getRequesterSsoId() {
		return requesterSsoId;
	}

	public void setRequesterSsoId(String requesterSsoId) {
		this.requesterSsoId = requesterSsoId;
	}	

	@XmlElement
	public String getAgentPhone() {
		return agentPhone;
	}

	public void setAgentPhone(String agentPhone) {
		this.agentPhone = agentPhone;
	}

	@XmlElement
	public String getAgentEmail() {
		return agentEmail;
	}

	public void setAgentEmail(String agentEmail) {
		this.agentEmail = agentEmail;
	}

	@XmlElement
	public String getSsoId() {
		return ssoId;
	}

	public void setSsoId(String ssoId) {
		this.ssoId = ssoId;
	}

	@XmlElement
	public boolean isSecondTemplate() {
		return secondTemplate;
	}

	public void setSecondTemplate(boolean secondTemplate) {
		this.secondTemplate = secondTemplate;
	}
	public boolean isEcmInput() {
        return isEcmInput;
    }

    public void setEcmInput(boolean isEcmInput) {
        this.isEcmInput = isEcmInput;
    }

    @XmlElement
	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	@XmlElement
	public String getAddInfo() {
		return addInfo;
	}

	public void setAddInfo(String addInfo) {
		this.addInfo = addInfo;
	}

	@XmlElement
	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	@XmlElement
	public String getConnName() {
		return connName;
	}

	public void setConnName(String connName) {
		this.connName = connName;
	}

	
	@XmlElement
	public Date getAssignedDate() {
		return assignedDate;
	}

	public void setAssignedDate(Date assignedDate) {
		this.assignedDate = assignedDate;
	}
	@XmlElement
	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}
	@XmlElement
	public String getUrgency() {
		return urgency;
	}

	public void setUrgency(String urgency) {
		this.urgency = urgency;
	}
	@XmlElement
	public String getAssistanceRequested() {
		return assistanceRequested;
	}

	public void setAssistanceRequested(String assistanceRequested) {
		this.assistanceRequested = assistanceRequested;
	}
	@XmlElement
	public String getCcrId() {
		return ccrId;
	}

	public void setCcrId(String ccrId) {
		this.ccrId = ccrId;
	}
	@XmlElement
	public String getChgId() {
		return chgId;
	}

	public void setChgId(String chgId) {
		this.chgId = chgId;
	}
	
	@XmlElement
	public String getImplementedDate() {
		return implementedDate;
	}

	public void setImplementedDate(String implementedDate) {
		this.implementedDate = implementedDate;
	}
	
	@XmlElement
	public String getBj() {
		return bj;
	}

	public void setBj(String bj) {
		this.bj = bj;
	}

	@XmlElement
	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@XmlElement
	public String getTextForSubject() {
		return textForSubject;
	}

	public void setTextForSubject(String textForSubject) {
		this.textForSubject = textForSubject;
	}

	public HashMap<String, String> getAttachments() {
		return attachments;
	}

	public void setAttachments(HashMap<String, String> attachments) {
		this.attachments = attachments;
	}

	public String getLeadName() {
		return leadName;
	}

	public void setLeadName(String leadName) {
		this.leadName = leadName;
	}

	public String getLeadEmail() {
		return leadEmail;
	}

	public void setLeadEmail(String leadEmail) {
		this.leadEmail = leadEmail;
	}

	public String getLeadPhone() {
		return leadPhone;
	}

	public void setLeadPhone(String leadPhone) {
		this.leadPhone = leadPhone;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getStep() {
		return step;
	}

	public void setStep(String step) {
		this.step = step;
	}

	public String getOrderBy() {
		return orderBy;
	}

	public void setOrderBy(String orderBy) {
		this.orderBy = orderBy;
	}

	public String getOrderFor() {
		return orderFor;
	}

	public void setOrderFor(String orderFor) {
		this.orderFor = orderFor;
	}

	public Date getLoggedDate() {
		return loggedDate;
	}

	public void setLoggedDate(Date loggedDate) {
		this.loggedDate = loggedDate;
	}

	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	@XmlElement
	public ChangeRequestDetails[] getChangeRequestDetails() {
		return changeRequestDetails;
	}

	public void setChangeRequestDetails(ChangeRequestDetails[] changeRequestDetails) {
		this.changeRequestDetails = changeRequestDetails;
	}

	@XmlElement
	public String getReAssignedUserEmail() {
		return reAssignedUserEmail;
	}

	public void setReAssignedUserEmail(String reAssignedUserEmail) {
		this.reAssignedUserEmail = reAssignedUserEmail;
	}

	@XmlElement
	public String getReAssignedUserPhone() {
		return reAssignedUserPhone;
	}

	public void setReAssignedUserPhone(String reAssignedUserPhone) {
		this.reAssignedUserPhone = reAssignedUserPhone;
	}
	
	
    /**
     * @return the cmpStatusUrl
     */
    public String getCmpStatusUrl() {
        return cmpStatusUrl;
    }

    /**
     * @param cmpStatusUrl
     *            the cmpStatusUrl to set
     */
    public void setCmpStatusUrl(String cmpStatusUrl) {
        this.cmpStatusUrl = cmpStatusUrl;
    }

    /**
     * @return the mdQuestionUrl
     */
    public String getMdQuestionUrl() {
        return mdQuestionUrl;
    }

    /**
     * @param mdQuestionUrl
     *            the mdQuestionUrl to set
     */
    public void setMdQuestionUrl(String mdQuestionUrl) {
        this.mdQuestionUrl = mdQuestionUrl;
    }

    /**
     * @return the questRow
     */
    public MailMsgDisplayRow[] getQuestRow() {
        return questRow;
    }

    /**
     * @param questRow
     *            the questRow to set
     */
    public void setQuestRow(MailMsgDisplayRow[] questRow) {
        this.questRow = questRow;
    }
	
    public String getManagingDirectorName() {
        return managingDirectorName;
    }

    public void setManagingDirectorName(String managingDirectorName) {
        this.managingDirectorName = managingDirectorName;
    }

    /**
     * @return the addInfoId
     */
    public Long getAddInfoId() {
        return addInfoId;
    }

    /**
     * @param addInfoId
     *            the addInfoId to set
     */
    public void setAddInfoId(Long addInfoId) {
        this.addInfoId = addInfoId;
    }

    /**
     * @return the mgrCompletedReason
     */
    public String getMgrCompletedReason() {
        return mgrCompletedReason;
    }

    /**
     * @param mgrCompletedReason
     *            the mgrCompletedReason to set
     */
    public void setMgrCompletedReason(String mgrCompletedReason) {
        this.mgrCompletedReason = mgrCompletedReason;
    }

    public String getBusinessJustificationReqInfo() {
        return businessJustificationReqInfo;
    }

    public void setBusinessJustificationReqInfo(String businessJustificationReqInfo) {
        this.businessJustificationReqInfo = businessJustificationReqInfo;
    }

    public String getBusinessJustificationBUResponse() {
        return businessJustificationBUResponse;
    }

    public void setBusinessJustificationBUResponse(String businessJustificationBUResponse) {
        this.businessJustificationBUResponse = businessJustificationBUResponse;
    }

    public String getCitiGrpDataReqInfo() {
        return citiGrpDataReqInfo;
    }

    public void setCitiGrpDataReqInfo(String citiGrpDataReqInfo) {
        this.citiGrpDataReqInfo = citiGrpDataReqInfo;
    }

    public String getCitiGrpDataBUResponse() {
        return citiGrpDataBUResponse;
    }

    public void setCitiGrpDataBUResponse(String citiGrpDataBUResponse) {
        this.citiGrpDataBUResponse = citiGrpDataBUResponse;
    }

    public String getCustomerDataReqInfo() {
        return customerDataReqInfo;
    }

    public void setCustomerDataReqInfo(String customerDataReqInfo) {
        this.customerDataReqInfo = customerDataReqInfo;
    }

    public String getCustomerDataBUResponse() {
        return customerDataBUResponse;
    }

    public void setCustomerDataBUResponse(String customerDataBUResponse) {
        this.customerDataBUResponse = customerDataBUResponse;
    }

    public String getConnectionFreqencyReqInfo() {
        return connectionFreqencyReqInfo;
    }

    public void setConnectionFreqencyReqInfo(String connectionFreqencyReqInfo) {
        this.connectionFreqencyReqInfo = connectionFreqencyReqInfo;
    }

    public String getConnectionFreqencyBUResponse() {
        return connectionFreqencyBUResponse;
    }

    public void setConnectionFreqencyBUResponse(String connectionFreqencyBUResponse) {
        this.connectionFreqencyBUResponse = connectionFreqencyBUResponse;
    }

    public String getGocCodeReqInfo() {
        return gocCodeReqInfo;
    }

    public void setGocCodeReqInfo(String gocCodeReqInfo) {
        this.gocCodeReqInfo = gocCodeReqInfo;
    }

    public String getGocCodeBUResponse() {
        return gocCodeBUResponse;
    }

    public void setGocCodeBUResponse(String gocCodeBUResponse) {
        this.gocCodeBUResponse = gocCodeBUResponse;
    }

    public String getTypeOfEntityReqInfo() {
        return typeOfEntityReqInfo;
    }

    public void setTypeOfEntityReqInfo(String typeOfEntityReqInfo) {
        this.typeOfEntityReqInfo = typeOfEntityReqInfo;
    }

    public String getTypeOfEntityBUResponse() {
        return typeOfEntityBUResponse;
    }

    public void setTypeOfEntityBUResponse(String typeOfEntityBUResponse) {
        this.typeOfEntityBUResponse = typeOfEntityBUResponse;
    }

    public String getDirectAccessReqInfo() {
        return directAccessReqInfo;
    }

    public void setDirectAccessReqInfo(String directAccessReqInfo) {
        this.directAccessReqInfo = directAccessReqInfo;
    }

    public String getDirectAccessBUResponse() {
        return directAccessBUResponse;
    }

    public void setDirectAccessBUResponse(String directAccessBUResponse) {
        this.directAccessBUResponse = directAccessBUResponse;
    }

    public String getReasonReqInfo() {
        return reasonReqInfo;
    }

    public void setReasonReqInfo(String reasonReqInfo) {
        this.reasonReqInfo = reasonReqInfo;
    }

    public String getReasonBUResponse() {
        return reasonBUResponse;
    }

    public void setReasonBUResponse(String reasonBUResponse) {
        this.reasonBUResponse = reasonBUResponse;
    }

    public String getUrgencyReqInfo() {
        return urgencyReqInfo;
    }

    public void setUrgencyReqInfo(String urgencyReqInfo) {
        this.urgencyReqInfo = urgencyReqInfo;
    }

    public String getUrgencyBUResponse() {
        return urgencyBUResponse;
    }

    public void setUrgencyBUResponse(String urgencyBUResponse) {
        this.urgencyBUResponse = urgencyBUResponse;
    }

    public String getAffectedBusinessReqInfo() {
        return affectedBusinessReqInfo;
    }

    public void setAffectedBusinessReqInfo(String affectedBusinessReqInfo) {
        this.affectedBusinessReqInfo = affectedBusinessReqInfo;
    }

    public String getAffectedBusinessBUResponse() {
        return affectedBusinessBUResponse;
    }

    public void setAffectedBusinessBUResponse(String affectedBusinessBUResponse) {
        this.affectedBusinessBUResponse = affectedBusinessBUResponse;
    }

    public String getReqSSOId() {
        return reqSSOId;
    }

    public void setReqSSOId(String reqSSOId) {
        this.reqSSOId = reqSSOId;
    }

    public String getBuSSOId() {
        return buSSOId;
    }

    public void setBuSSOId(String buSSOId) {
        this.buSSOId = buSSOId;
    }

    public String getCitiGrpData() {
        return citiGrpData;
    }

    public void setCitiGrpData(String citiGrpData) {
        this.citiGrpData = citiGrpData;
    }

    public String getCustomerData() {
        return customerData;
    }

    public void setCustomerData(String customerData) {
        this.customerData = customerData;
    }

    public String getConnectionFreqency() {
        return connectionFreqency;
    }

    public void setConnectionFreqency(String connectionFreqency) {
        this.connectionFreqency = connectionFreqency;
    }

    public String getGocCode() {
        return gocCode;
    }

    public void setGocCode(String gocCode) {
        this.gocCode = gocCode;
    }

    public String getTypeOfEntity() {
        return typeOfEntity;
    }

    public void setTypeOfEntity(String typeOfEntity) {
        this.typeOfEntity = typeOfEntity;
    }

    public String getDirectAccess() {
        return directAccess;
    }

    public void setDirectAccess(String directAccess) {
        this.directAccess = directAccess;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getCmpUrgency() {
        return cmpUrgency;
    }

    public void setCmpUrgency(String cmpUrgency) {
        this.cmpUrgency = cmpUrgency;
    }

    public String getAffectedBusiness() {
        return affectedBusiness;
    }

    public void setAffectedBusiness(String affectedBusiness) {
        this.affectedBusiness = affectedBusiness;
    }

    public String getReqInfoCreatedDate() {
        return reqInfoCreatedDate;
    }

    public void setReqInfoCreatedDate(String reqInfoCreatedDate) {
        this.reqInfoCreatedDate = reqInfoCreatedDate;
    }

    public String getReqInfoParticipant() {
        return reqInfoParticipant;
    }

    public void setReqInfoParticipant(String reqInfoParticipant) {
        this.reqInfoParticipant = reqInfoParticipant;
    }

    public String getReqInfo() {
        return reqInfo;
    }

    public void setReqInfo(String reqInfo) {
        this.reqInfo = reqInfo;
    }

    public String getRegionReqInfo() {
        return regionReqInfo;
    }

    public void setRegionReqInfo(String regionReqInfo) {
        this.regionReqInfo = regionReqInfo;
    }

    public String getRegionBUResponse() {
        return regionBUResponse;
    }

    public void setRegionBUResponse(String regionBUResponse) {
        this.regionBUResponse = regionBUResponse;
    }

    public String getSectorReqInfo() {
        return sectorReqInfo;
    }

    public void setSectorReqInfo(String sectorReqInfo) {
        this.sectorReqInfo = sectorReqInfo;
    }

    public String getSectorBUResponse() {
        return sectorBUResponse;
    }

    public void setSectorBUResponse(String sectorBUResponse) {
        this.sectorBUResponse = sectorBUResponse;
    }

    public String getBusinessUnitReqInfo() {
        return businessUnitReqInfo;
    }

    public void setBusinessUnitReqInfo(String businessUnitReqInfo) {
        this.businessUnitReqInfo = businessUnitReqInfo;
    }

    public String getBusinessUnitBUResponse() {
        return businessUnitBUResponse;
    }

    public void setBusinessUnitBUResponse(String businessUnitBUResponse) {
        this.businessUnitBUResponse = businessUnitBUResponse;
    }

    public String getCompanyNameReqInfo() {
        return companyNameReqInfo;
    }

    public void setCompanyNameReqInfo(String companyNameReqInfo) {
        this.companyNameReqInfo = companyNameReqInfo;
    }

    public String getCompanyNameBUResponse() {
        return companyNameBUResponse;
    }

    public void setCompanyNameBUResponse(String companyNameBUResponse) {
        this.companyNameBUResponse = companyNameBUResponse;
    }

    public String getTptContactNameReqInfo() {
        return tptContactNameReqInfo;
    }

    public void setTptContactNameReqInfo(String tptContactNameReqInfo) {
        this.tptContactNameReqInfo = tptContactNameReqInfo;
    }

    public String getTptContactNameBUResponse() {
        return tptContactNameBUResponse;
    }

    public void setTptContactNameBUResponse(String tptContactNameBUResponse) {
        this.tptContactNameBUResponse = tptContactNameBUResponse;
    }

    public String getCaspSuppIdReqInfo() {
        return caspSuppIdReqInfo;
    }

    public void setCaspSuppIdReqInfo(String caspSuppIdReqInfo) {
        this.caspSuppIdReqInfo = caspSuppIdReqInfo;
    }

    public String getCaspSuppIdBUResponse() {
        return caspSuppIdBUResponse;
    }

    public void setCaspSuppIdBUResponse(String caspSuppIdBUResponse) {
        this.caspSuppIdBUResponse = caspSuppIdBUResponse;
    }

    public String getTptContactTypeReqInfo() {
        return tptContactTypeReqInfo;
    }

    public void setTptContactTypeReqInfo(String tptContactTypeReqInfo) {
        this.tptContactTypeReqInfo = tptContactTypeReqInfo;
    }

    public String getTptContactTypeBUResponse() {
        return tptContactTypeBUResponse;
    }

    public void setTptContactTypeBUResponse(String tptContactTypeBUResponse) {
        this.tptContactTypeBUResponse = tptContactTypeBUResponse;
    }

    public String getCaspDetailIdReqInfo() {
        return caspDetailIdReqInfo;
    }

    public void setCaspDetailIdReqInfo(String caspDetailIdReqInfo) {
        this.caspDetailIdReqInfo = caspDetailIdReqInfo;
    }

    public String getCaspDetailIdBUResponse() {
        return caspDetailIdBUResponse;
    }

    public void setCaspDetailIdBUResponse(String caspDetailIdBUResponse) {
        this.caspDetailIdBUResponse = caspDetailIdBUResponse;
    }

    public String getTptContactPhoneReqInfo() {
        return tptContactPhoneReqInfo;
    }

    public void setTptContactPhoneReqInfo(String tptContactPhoneReqInfo) {
        this.tptContactPhoneReqInfo = tptContactPhoneReqInfo;
    }

    public String getTptContactPhoneBUResponse() {
        return tptContactPhoneBUResponse;
    }

    public void setTptContactPhoneBUResponse(String tptContactPhoneBUResponse) {
        this.tptContactPhoneBUResponse = tptContactPhoneBUResponse;
    }

    public String getTptContactEmailReqInfo() {
        return tptContactEmailReqInfo;
    }

    public void setTptContactEmailReqInfo(String tptContactEmailReqInfo) {
        this.tptContactEmailReqInfo = tptContactEmailReqInfo;
    }

    public String getTptContactEmailBUResponse() {
        return tptContactEmailBUResponse;
    }

    public void setTptContactEmailBUResponse(String tptContactEmailBUResponse) {
        this.tptContactEmailBUResponse = tptContactEmailBUResponse;
    }

    public String getBusinessUnit() {
        return businessUnit;
    }

    public void setBusinessUnit(String businessUnit) {
        this.businessUnit = businessUnit;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getTptContactName() {
        return tptContactName;
    }

    public void setTptContactName(String tptContactName) {
        this.tptContactName = tptContactName;
    }

    public String getCaspSuppId() {
        return caspSuppId;
    }

    public void setCaspSuppId(String caspSuppId) {
        this.caspSuppId = caspSuppId;
    }

    public String getTptContactType() {
        return tptContactType;
    }

    public void setTptContactType(String tptContactType) {
        this.tptContactType = tptContactType;
    }

    public String getCaspDetailId() {
        return caspDetailId;
    }

    public void setCaspDetailId(String caspDetailId) {
        this.caspDetailId = caspDetailId;
    }

    public String getTptContactPhone() {
        return tptContactPhone;
    }

    public void setTptContactPhone(String tptContactPhone) {
        this.tptContactPhone = tptContactPhone;
    }

    public String getTptContactEmail() {
        return tptContactEmail;
    }

    public void setTptContactEmail(String tptContactEmail) {
        this.tptContactEmail = tptContactEmail;
    }

    /**
     * @return the tiMailAudtiId
     */
    public String getTiMailAudtiId() {
        return tiMailAudtiId;
    }

    /**
     * @param tiMailAudtiId
     *            the tiMailAudtiId to set
     */
    public void setTiMailAudtiId(String tiMailAudtiId) {
        this.tiMailAudtiId = tiMailAudtiId;
    }
 
    public Map<String, String> getEmerBuscritQuesAndAnswers() {
		return emerBuscritQuesAndAnswers;
	}

	public void setEmerBuscritQuesAndAnswers(Map<String, String> emerBuscritQuesAndAnswers) {
		this.emerBuscritQuesAndAnswers = emerBuscritQuesAndAnswers;
	}
	
	public String getOrderItemId() {
		return orderItemId;
	}

	public void setOrderItemId(String orderItemId) {
		this.orderItemId = orderItemId;
	}
	
	public Date getManagingDirectorApprovalDate() {
		return managingDirectorApprovalDate;
	}

	public void setManagingDirectorApprovalDate(Date managingDirectorApprovalDate) {
		this.managingDirectorApprovalDate = managingDirectorApprovalDate;
	}
}