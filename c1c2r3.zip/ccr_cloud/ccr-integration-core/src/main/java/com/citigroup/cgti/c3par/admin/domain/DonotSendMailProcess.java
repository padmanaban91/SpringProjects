/**
 *
 */
package com.citigroup.cgti.c3par.admin.domain;

import java.util.List;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.util.CCRApplicationContextUtils;
import com.citigroup.cgti.c3par.util.CCRBeanFactory;

/**
 * @author pc79439
 * 
 */
public class DonotSendMailProcess {
	

    //properties used for pagination
    private int rowCount;
    private int offset;
    private int limit;
    private int pageNo;
    private int totalPages;
    private boolean paginationRequired;
    private String pageType;
    
	private String soeID;

	private List<DoNotSendMailList> donotSendMailList;
     CCRBeanFactory ccrBeanFactory;
	{
		ApplicationContext appContext=CCRApplicationContextUtils.getApplicationContext();
		ccrBeanFactory=(CCRBeanFactory)appContext.getBean("cCRBeanFactory");
	}
	
	public int getRowCount() {
		return rowCount;
	}

	public void setRowCount(int rowCount) {
		this.rowCount = rowCount;
	}

	public int getOffset() {
		return offset;
	}

	public void setOffset(int offset) {
		this.offset = offset;
	}

	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public int getPageNo() {
		return pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public int getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

	public boolean isPaginationRequired() {
		return paginationRequired;
	}

	public void setPaginationRequired(boolean paginationRequired) {
		this.paginationRequired = paginationRequired;
	}

	public String getPageType() {
		return pageType;
	}

	public void setPageType(String pageType) {
		this.pageType = pageType;
	}

	public String getSoeID() {
		return soeID;
	}

	public void setSoeID(String soeID) {
		this.soeID = soeID;
	}

	public List<DoNotSendMailList> getDonotSendMailList() {
		return donotSendMailList;
	}

	public void setDonotSendMailList(List<DoNotSendMailList> donotSendMailList) {
		this.donotSendMailList = donotSendMailList;
	}

	//To retrieve getDoNotSendEmailList
	
	public List<DoNotSendMailList> getDoNotSendEmailList() {
		return ccrBeanFactory.getDonotSendMailServicePersistable().getDoNotSendEmailList(this);
	}
	
	//To save DoNotSendEmailList
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void saveDoNotSendEmailList(String soeId) {
		ccrBeanFactory.getDonotSendMailServicePersistable().saveDoNotSendEmailList(soeId);
	}

	//To delete DoNotSendEmailList
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = false)
	public void deleteDoNotSendEmailList(List<String> soeId) {
		ccrBeanFactory.getDonotSendMailServicePersistable().deleteDoNotSendEmailList(soeId);
	}
	
}

