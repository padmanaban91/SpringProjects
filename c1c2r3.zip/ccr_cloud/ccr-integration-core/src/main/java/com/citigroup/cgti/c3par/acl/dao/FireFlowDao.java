/**
 *
 */

package com.citigroup.cgti.c3par.acl.dao;

import java.math.BigDecimal;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.citigroup.cgti.c3par.Exception.ApplicationException;
import com.citigroup.cgti.c3par.bpm.ejb.domain.FireFlowDTO;
import com.citigroup.cgti.c3par.domain.TIRequest;

// TODO: Auto-generated Javadoc
/**
 * The Class FireFlowDao.
 */
@Transactional
public class FireFlowDao /*extends HibernateDaoSupport*/ implements
FireFlowProcessPersistable {

    /** The log. */
    protected Logger log = Logger.getLogger(this.getClass().getName());
    
    //@Autowired
    private SessionFactory sessionFactory;
    
    

    public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	/* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.acl.dao.FireFlowProcessPersistable#getFireFlowRequests(com.citigroup.cgti.c3par.domain.TIRequest)
     */
    public List getFireFlowRequests(TIRequest tiRequest) {
	List list = null;
	//Session session = getSession();
	Session session =sessionFactory.getCurrentSession();
	try {
	    Criteria crit = session.createCriteria(FireFlowDTO.class);
	    crit.createAlias("tiRequest", "tiRequest");
	    crit.add(Restrictions.eq("tiRequest.tiProcess.id", tiRequest.getTiProcess().getId()));
	    list = crit.list();
	} catch (Exception e) {
	    log.error(e, e);
	    throw new ApplicationException(
		    " There was an exception while ACLVariance for the given TI Request ID::"
		    + tiRequest);
	}
	return list;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.acl.dao.FireFlowProcessPersistable#getFireFlowRequests(long, int, int)
     */
    public List getFireFlowRequests(long processId , int pageNo,
	    int pageSize) {
	List list = null;
	//Session session = getSession();
	Session session =sessionFactory.getCurrentSession();
	try {

	    Query query = session.createSQLQuery("select f.* from ti_fireflow_request f,ti_request t"+
		    " where t.id = f.ti_request_id and t.process_id="+processId+" order by t.id desc").addEntity(FireFlowDTO.class);
	    query.setFirstResult(pageSize * (pageNo - 1));
	    query.setMaxResults(pageSize);
	    list = query.list();
	} catch (Exception e) {
	    log.error(e, e);
	    throw new ApplicationException(
		    " There was an exception while ACLVariance for the given TI Request ID::"
		    + processId);
	}
	return list;
    }

    /* (non-Javadoc)
     * @see com.citigroup.cgti.c3par.acl.dao.FireFlowProcessPersistable#getTotalNumber(long)
     */
    public int getTotalNumber(long processId) {
	List total = null;
	Integer rowCount = Integer.valueOf(0);
	//Session session = getSession();
	Session session =sessionFactory.getCurrentSession();
	try {
	    Query query = session.createSQLQuery("select count(*) from ti_fireflow_request f,ti_request t"+
		    " where t.id = f.ti_request_id and t.process_id="+processId);

	    total = query.list();
	    if (!total.isEmpty()) {
		rowCount = ((BigDecimal)total.get(0)).intValue();
	    }
	} catch (Exception e) {
	    log.error(e, e);
	    throw new ApplicationException(
	    " There was an exception while getting Total Number for process id:");
	}
	log.debug("ManageProxyImpl:getTotalNumber: Exiting with process Id:");
	return rowCount.intValue();
    }

}