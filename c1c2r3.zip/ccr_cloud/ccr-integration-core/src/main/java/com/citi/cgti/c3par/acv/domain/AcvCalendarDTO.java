package com.citi.cgti.c3par.acv.domain;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.citigroup.cgti.c3par.common.domain.GenericLookup;
import com.citigroup.cgti.c3par.domain.Role;

/**
 * @author ky38518
 * 
 */
public class AcvCalendarDTO {

    private String year;
    private String soeId;
    private Map<String, Integer> acvMonthlyCcrCount = new LinkedHashMap<String, Integer>();
    private String ccrId;
    private String activity;
    private String conType;
    private String conName;
    private String assignedRole;
    private Integer noOfdaysInActivity;
    private String acvDate;
    private String selectedMonth;
    private List<AcvCalendarDTO> acvDetailList;
    private String currrentActivity;
    private String daysInAcv;
    private String realtionShip;
    private String tiRequestId;
    private String acvFlag;
    private String status;
    private List<String> yearList;
    private List<GenericLookup> acvExtensionOptionsList;
    private String acvExtensionType;
    private int acvExtensionValue = 0;
    private String acvExtendedDate;
    private String sow_number;
    private String comments;
    private boolean acvRoleEnabled;
    private String loggedInUser;
    private String roleName;
    private String searhByYear;
    private List<Role> actualRoleNameList;
    private List<String> selectedRoles;
    private String ccrEntitilementCMPProductURL;
    private String enablePreviousNext;
    
    private boolean adminRoleEnabled;
    private CommonsMultipartFile docForUpload;
    
    public String getEnablePreviousNext() {
		return enablePreviousNext;
	}

	public void setEnablePreviousNext(String enablePreviousNext) {
		this.enablePreviousNext = enablePreviousNext;
	}

	public String getCcrEntitilementCMPProductURL() {
        return ccrEntitilementCMPProductURL;
    }

    public void setCcrEntitilementCMPProductURL(String ccrEntitilementCMPProductURL) {
        this.ccrEntitilementCMPProductURL = ccrEntitilementCMPProductURL;
    }

    /**
     * @return selectedRoles
     */

    public List<String> getSelectedRoles() {
        return selectedRoles;
    }

    /**
     * @param selectedRoles
     */
    public void setSelectedRoles(List<String> selectedRoles) {
        this.selectedRoles = selectedRoles;
    }

    /**
     * @return roleName
     */
    public String getRoleName() {
        return roleName;
    }

    /**
     * @param roleName
     */
    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    /**
     * @return loggedInUser
     */
    public String getLoggedInUser() {
        return loggedInUser;
    }

    /**
     * @param loggedInUser
     */
    public void setLoggedInUser(String loggedInUser) {
        this.loggedInUser = loggedInUser;
    }

    /**
     * @return acvRoleEnabled
     */
    public boolean isAcvRoleEnabled() {
        return acvRoleEnabled;
    }

    /**
     * @param acvRoleEnabled
     */
    public void setAcvRoleEnabled(boolean acvRoleEnabled) {
        this.acvRoleEnabled = acvRoleEnabled;
    }

    /**
     * @return yearList
     */
    public List<String> getYearList() {
        return yearList;
    }

    /**
     * @param yearList
     */
    public void setYearList(List<String> yearList) {
        this.yearList = yearList;
    }

    /**
     * @return currrentActivity
     */
    public String getCurrrentActivity() {
        return currrentActivity;
    }

    public List<GenericLookup> getAcvExtensionOptionsList() {
        return acvExtensionOptionsList;
    }

    public void setAcvExtensionOptionsList(List<GenericLookup> acvExtensionOptionsList) {
        this.acvExtensionOptionsList = acvExtensionOptionsList;
    }

    public String getAcvExtensionType() {
        return acvExtensionType;
    }

    public void setAcvExtensionType(String acvExtensionType) {
        this.acvExtensionType = acvExtensionType;
    }

    public int getAcvExtensionValue() {
        return acvExtensionValue;
    }

    public void setAcvExtensionValue(int acvExtensionValue) {
        this.acvExtensionValue = acvExtensionValue;
    }

    public String getAcvExtendedDate() {
        return acvExtendedDate;
    }

    public void setAcvExtendedDate(String acvExtendedDate) {
        this.acvExtendedDate = acvExtendedDate;
    }

    /**
     * @param currrentActivity
     */
    public void setCurrrentActivity(String currrentActivity) {
        this.currrentActivity = currrentActivity;
    }

    /**
     * @return daysInAcv
     */
    public String getDaysInAcv() {
        return daysInAcv;
    }

    /**
     * @param daysInAcv
     */
    public void setDaysInAcv(String daysInAcv) {
        this.daysInAcv = daysInAcv;
    }

    /**
     * @return realtionShip
     */
    public String getRealtionShip() {
        return realtionShip;
    }

    /**
     * @param realtionShip
     */
    public void setRealtionShip(String realtionShip) {
        this.realtionShip = realtionShip;
    }

    /**
     * @return tiRequestId
     */
    public String getTiRequestId() {
        return tiRequestId;
    }

    /**
     * @param tiRequestId
     */
    public void setTiRequestId(String tiRequestId) {
        this.tiRequestId = tiRequestId;
    }

    /**
     * @return acvFlag
     */
    public String getAcvFlag() {
        return acvFlag;
    }

    /**
     * @param acvFlag
     */
    public void setAcvFlag(String acvFlag) {
        this.acvFlag = acvFlag;
    }

    /**
     * @return status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status
     */
    public void setStatus(String status) {
        this.status = status;
    }

    public AcvCalendarDTO() {
        acvMonthlyCcrCount = new LinkedHashMap<String, Integer>();
        acvMonthlyCcrCount.put("01", 0);
        acvMonthlyCcrCount.put("02", 0);
        acvMonthlyCcrCount.put("03", 0);
        acvMonthlyCcrCount.put("04", 0);
        acvMonthlyCcrCount.put("05", 0);
        acvMonthlyCcrCount.put("06", 0);
        acvMonthlyCcrCount.put("07", 0);
        acvMonthlyCcrCount.put("08", 0);
        acvMonthlyCcrCount.put("09", 0);
        acvMonthlyCcrCount.put("10", 0);
        acvMonthlyCcrCount.put("11", 0);
        acvMonthlyCcrCount.put("12", 0);
    }

    /**
     * @return selectedMonth
     */
    public String getSelectedMonth() {
        return selectedMonth;
    }

    /**
     * @param selectedMonth
     */
    public void setSelectedMonth(String selectedMonth) {
        this.selectedMonth = selectedMonth;
    }

    /**
     * @return year
     */
    public String getYear() {
        return year;
    }

    /**
     * @param year
     */
    public void setYear(String year) {
        this.year = year;
    }

    /**
     * @return soeId
     */
    public String getSoeId() {
        return soeId;
    }

    /**
     * @param soeId
     */
    public void setSoeId(String soeId) {
        this.soeId = soeId;
    }

    /**
     * @return acvMonthlyCcrCount
     */
    public Map<String, Integer> getAcvMonthlyCcrCount() {
        return acvMonthlyCcrCount;
    }

    /**
     * @param acvMonthlyCcrCount
     */
    public void setAcvMonthlyCcrCount(Map<String, Integer> acvMonthlyCcrCount) {
        this.acvMonthlyCcrCount = acvMonthlyCcrCount;
    }

    /**
     * @return ccrId
     */
    public String getCcrId() {
        return ccrId;
    }

    /**
     * @param ccrId
     */
    public void setCcrId(String ccrId) {
        this.ccrId = ccrId;
    }

    /**
     * @return activity
     */
    public String getActivity() {
        return activity;
    }

    /**
     * @param activity
     */
    public void setActivity(String activity) {
        this.activity = activity;
    }

    /**
     * @return conType
     */
    public String getConType() {
        return conType;
    }

    /**
     * @param conType
     */
    public void setConType(String conType) {
        this.conType = conType;
    }

    /**
     * @return conName
     */
    public String getConName() {
        return conName;
    }

    /**
     * @param conName
     */
    public void setConName(String conName) {
        this.conName = conName;
    }

    /**
     * @return assignedRole
     */
    public String getAssignedRole() {
        return assignedRole;
    }

    /**
     * @param assignedRole
     */
    public void setAssignedRole(String assignedRole) {
        this.assignedRole = assignedRole;
    }

    /**
     * @return noOfdaysInActivity
     */
    public Integer getNoOfdaysInActivity() {
        return noOfdaysInActivity;
    }

    /**
     * @param noOfdaysInActivity
     */
    public void setNoOfdaysInActivity(Integer noOfdaysInActivity) {
        this.noOfdaysInActivity = noOfdaysInActivity;
    }

    /**
     * @return acvDate
     */
    public String getAcvDate() {
        return acvDate;
    }

    /**
     * @param acvDate
     */
    public void setAcvDate(String acvDate) {
        this.acvDate = acvDate;
    }

    /**
     * @return acvDetailList
     */
    public List<AcvCalendarDTO> getAcvDetailList() {
        return acvDetailList;
    }

    /**
     * @param acvDetailList
     */
    public void setAcvDetailList(List<AcvCalendarDTO> acvDetailList) {
        this.acvDetailList = acvDetailList;
    }

    /**
     * @return
     */
    public String getSow_number() {
        return sow_number;
    }

    /**
     * @param sow_number
     */
    public void setSow_number(String sow_number) {
        this.sow_number = sow_number;
    }

    /**
     * @return comments
     */
    public String getComments() {
        return comments;
    }

    /**
     * @param comments
     */
    public void setComments(String comments) {
        this.comments = comments;
    }

    /**
     * 
     * @return searhByYear
     */

    public String getSearhByYear() {

        return searhByYear;

    }

    /**
     * 
     * @param searhByYear
     */

    public void setSearhByYear(String searhByYear) {

        this.searhByYear = searhByYear;

    }

    public List<Role> getActualRoleNameList() {
        return actualRoleNameList;
    }

    public void setActualRoleNameList(List<Role> actualRoleNameList) {
        this.actualRoleNameList = actualRoleNameList;
    }

    /**
     * @return the adminRoleEnabled
     */
    public boolean isAdminRoleEnabled() {
        return adminRoleEnabled;
    }

    /**
     * @param adminRoleEnabled
     *            the adminRoleEnabled to set
     */
    public void setAdminRoleEnabled(boolean adminRoleEnabled) {
        this.adminRoleEnabled = adminRoleEnabled;
    }

	public CommonsMultipartFile getDocForUpload() {
		return docForUpload;
	}

	public void setDocForUpload(CommonsMultipartFile docForUpload) {
		this.docForUpload = docForUpload;
	}
    

}
